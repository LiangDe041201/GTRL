#!/usr/bin/env bash
# ============================================================
# 【不推荐 / 本机实测会崩】带窗口启动 CARLA 服务器
#
# ⚠ 实测（本机 RTX5070 + 驱动 570 + CARLA 0.9.15）：带窗口启动后 60s 内报
#       LowLevelFatalError: GameThread timed out waiting for RenderThread
#       Signal 11 → 段错误退出
#   （UE4.26 在软件 Vulkan/lavapipe 下无法完成窗口呈现）。
#   ⇒ 想看训练画面请用【离屏服务器 + 客户端相机窗口】：
#        bash start_headless_server.sh            # 服务器（离屏，稳定）
#        DSH_VIEW=1 ... python train_dcarl_turn.py  # 训练端 pygame 窗口（前视+俯视）
#   本脚本仅保留，供你在自己的桌面会话里再验证一次。
# ============================================================
# 启动 CARLA 服务器（**带窗口**，用于可视化观察训练）
#
# 与 start_headless_server.sh 的区别：不加 -RenderOffScreen，
# 服务器会打开 UE4 窗口，训练端配合 DSH_RENDER=1
# （TestScenario_Town03_turn.py 会设 no_rendering_mode=False）
# 即可用旁观者俯视视角看到 ego 与车流的博弈过程。
#
# 代价：
#   1) 仿真明显变慢（渲染占用 GPU/CPU）；
#   2) UE4 渲染内存会随回合累积，长训练（经验上 ~40 回合以上）有崩溃风险
#      —— 这正是原版训练默认关闭渲染的原因。长跑请分段进行，
#      每段结束后用同一个 DSH_SAVE_DIR 续跑（回合数与模型都会从目录恢复）。
#
# 用法：
#   bash start_server_window.sh                 # 默认 ~/carla
#   bash start_server_window.sh /path/to/carla  # 指定 CARLA 根目录
#   CARLA_ROOT=/path/to/carla bash start_server_window.sh
#
# 另开一个终端跑训练：
#   cd Algorithms && export PYTHONPATH="${PYTHONPATH}:$(pwd)/.."
#   DSH_RENDER=1 DSH_SAVE_DIR=$PWD/<run_dir> DSH_EPISODES=100 \
#     DSH_EFE=0 DSH_PAPER_REWARD=0 DSH_METHOD=GTRL DSH_GAMMA=0.995 \
#     /home/liangde/miniconda3/envs/carla0.9.15/bin/python train_dcarl_turn.py
# ============================================================
set -e

CARLA_ROOT="${1:-${CARLA_ROOT:-$HOME/carla}}"

if [ ! -f "$CARLA_ROOT/CarlaUE4.sh" ]; then
    echo "[start_server_window] 找不到 $CARLA_ROOT/CarlaUE4.sh，请传入正确的 CARLA 根目录" >&2
    exit 1
fi

echo "[start_server_window] CARLA_ROOT = $CARLA_ROOT"
echo "[start_server_window] 带窗口启动（可视化）；训练端请设 DSH_RENDER=1"
cd "$CARLA_ROOT"

# 低画质以降低负载；不加 -RenderOffScreen 才有窗口
RUN_CMD="./CarlaUE4.sh -quality-level=Low"

# 规避新内核上 UE4.26 的 ASLR 启动崩溃（setarch -R = 本进程关闭地址随机化）
if command -v setarch >/dev/null 2>&1; then
    echo "[start_server_window] 启动命令: setarch $(uname -m) -R $RUN_CMD"
    exec setarch "$(uname -m)" -R $RUN_CMD
else
    echo "[start_server_window] 未找到 setarch，直接启动: $RUN_CMD"
    exec $RUN_CMD
fi
