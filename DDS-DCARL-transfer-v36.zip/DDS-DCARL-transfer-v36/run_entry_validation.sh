#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUTF8=1
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/Algorithms"
exec "${PYTHON_BIN:-python}" -u Tools/run_dense_validation_v30.py --learner entry_v35 \
    --train-episodes 60 --train-seed 501 --eval-seeds 511,512 --eval-episodes 2 "$@"
