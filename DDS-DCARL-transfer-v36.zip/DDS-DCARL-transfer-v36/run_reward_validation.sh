#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUTF8=1
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/Algorithms"
exec "${PYTHON_BIN:-python}" -u Tools/run_dense_validation_v30.py --learner reward_v36 \
    --train-episodes 150 --train-seed 501 --eval-seeds 511,512,513,514,515 --eval-episodes 6 "$@"
