#!/usr/bin/env bash
# Optional v27 EFE diagnostics; independent of the current v28 default workflow.
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUTF8=1
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
cd "$SCRIPT_DIR/Algorithms"
exec "$PYTHON_BIN" -u Tools/run_efe_shadow_validation_v27.py "$@"
