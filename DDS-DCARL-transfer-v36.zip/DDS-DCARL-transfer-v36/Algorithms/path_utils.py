#!/usr/bin/env python3
"""
统一的数据/图像保存路径工具。

所有保存路径锚定到 Algorithms 目录（通过 __file__ 定位，与项目结构相对，可移植）：
  - Saved_DCARL_model/   R-tree 与训练数据 pkl
  - training_polt/       训练曲线图片
  - record_turn.txt      环境统计

这样无论从哪个目录启动训练，数据都固定落在 Algorithms/ 下，
换机器、换用户名、换启动目录都不需要任何改动。
"""
import os

_SAVE_ROOT = os.path.dirname(os.path.abspath(__file__))   # = Algorithms 目录


def get_save_root():
    """Algorithms 目录（train_dcarl_turn.py 所在目录）"""
    return _SAVE_ROOT


def get_model_dir():
    """R-tree / 训练数据 pkl 目录: Algorithms/Saved_DCARL_model

    可用环境变量 DSH_SAVE_DIR 重定向到独立目录，便于多配置 A/B（每组数据完全隔离）。
    """
    return os.environ.get('DSH_SAVE_DIR', os.path.join(_SAVE_ROOT, "Saved_DCARL_model"))


def get_plot_dir():
    """训练曲线图片目录: Algorithms/training_polt（可用 DSH_PLOT_DIR 重定向）"""
    return os.environ.get('DSH_PLOT_DIR', os.path.join(_SAVE_ROOT, "training_polt"))
