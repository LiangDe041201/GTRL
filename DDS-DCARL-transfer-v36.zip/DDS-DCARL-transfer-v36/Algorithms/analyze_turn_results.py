#!/usr/bin/env python3
"""
DCARL 转弯训练结果快速分析工具

用法:
    python analyze_turn_results.py
    python analyze_turn_results.py --console console_log.txt
    python analyze_turn_results.py --save-dir /path/to/Saved_DCARL_model   # 数据在别处时

数据默认从 Algorithms/Saved_DCARL_model 读取（锚定到项目目录，与启动位置无关）。
"""
import argparse
import os
import pickle
import numpy as np

# 默认保存目录锚定到 Algorithms（与训练代码一致）
try:
    from path_utils import get_model_dir, get_save_root
    SAVE_DIR = get_model_dir()
    RECORD_FILE = os.path.join(get_save_root(), "record_turn.txt")
except ImportError:
    SAVE_DIR = os.path.join(os.getcwd(), "Saved_DCARL_model")
    RECORD_FILE = os.path.join(os.getcwd(), "record_turn.txt")


def load_pkl(path):
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            return pickle.load(f)
    except Exception as e:
        print(f"  [警告] 读取 {path} 失败: {e}")
        return None


def print_rewards_summary(ep):
    print("=" * 70)
    print("[1] 回合奖励 (turn_episode_rewards.pkl)")
    print("=" * 70)
    if not ep:
        print("  未找到该文件 → 训练可能没有跑完任何回合，或运行目录不对")
        return
    ep_nums = [float(x[0]) for x in ep]
    rewards = [float(x[1]) for x in ep]
    rates = [float(x[2]) if len(x) > 2 else np.nan for x in ep]

    print(f"  回合总数: {len(ep)}")
    n = len(rewards)
    head = np.mean(rewards[:min(5, n)])
    tail = np.mean(rewards[-min(10, n):]) if n >= 1 else np.nan
    print(f"  前 {min(5, n)} 回合平均奖励: {head:+.1f}")
    print(f"  最近 {min(10, n)} 回合平均奖励: {tail:+.1f}")
    print("  奖励趋势（每10回合均值）:")
    for i in range(0, n, 10):
        seg = rewards[i:i + 10]
        seg_r = np.nanmean(rates[i:i + 10]) if not np.all(np.isnan(rates[i:i + 10])) else np.nan
        print(f"    Epoch {i + 1:>4}~{i + len(seg):>4}: reward={np.mean(seg):+8.1f}  activate={seg_r:.2f}")
    if n >= 30 and tail > head + 20:
        print(f"\n  ✅ 结论: 奖励随训练上升 ({head:+.1f} → {tail:+.1f})，修改初步有效")
    elif n >= 30 and tail > -50:
        print(f"\n  ✅ 结论: 奖励已脱离 -190 平台期（近期均值 {tail:+.1f}），修改生效")
    elif n >= 30:
        print(f"\n  ⚠️ 结论: 奖励仍偏低（近期 {tail:+.1f}），需要进一步排查")
    else:
        print(f"\n  ℹ️ 结论: 回合数不足30，暂时无法下结论")


def print_env_record(rec_path):
    print("=" * 70)
    print("[2] 环境统计 (record_turn.txt)")
    print("=" * 70)
    if not os.path.exists(rec_path):
        print("  未找到 record_turn.txt")
        return
    lines = []
    with open(rec_path, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                lines.append(line)
    if not lines:
        print("  文件为空")
        return
    last = lines[-1].split(",")
    try:
        task = int(last[0]); stuck = int(last[2]); coll = int(last[3])
        stuck_r = float(last[4]); coll_r = float(last[5]); pass_r = float(last[6])
        print(f"  总任务数: {task}  卡死: {stuck}  碰撞: {coll}")
        print(f"  卡死率: {stuck_r:.3f}  碰撞率: {coll_r:.3f}  通过率: {pass_r:.3f}")
        half = max(1, len(lines) // 2)
        first = lines[:half]; last_half = lines[half:]
        def rate(seg):
            try:
                return float(seg[-1].split(",")[6])
            except Exception:
                return float("nan")
        print(f"  通过率趋势: 前半段={rate(first):.3f} → 后半段={rate(last_half):.3f}")
    except Exception as e:
        print(f"  解析失败: {e}  原始行: {last}")


def print_rtree_summary():
    print("=" * 70)
    print("[3] R-tree 数据质量 (rtree_env_data.pkl)")
    print("=" * 70)
    data = load_pkl(os.path.join(SAVE_DIR, "rtree_env_data.pkl"))
    if not data:
        print("  未找到 rtree_env_data.pkl")
        return
    locs = data.get("locations", [])
    dim = data.get("dim", None)
    print(f"  数据条数: {len(locs)}  状态维度: {dim}")
    if dim is None and locs:
        dim = len(np.asarray(locs[0][0]).flatten())
        print(f"  (从数据推断维度: {dim})")
    if dim == 3:
        print("  ❌ 状态维度=3 → 说明跑的是【旧代码】，本次 P0 修改没有生效！")
        print("     请确认: 1) 是否用修改后的 dds_dcarl_turn.py 2) 是否删除了旧的 Saved_DCARL_model")
    elif dim == 5:
        print("  ✅ 状态维度=5 → 新 5 维状态编码已生效")
    if not locs:
        return
    actions = []
    rewards = []
    for item in locs:
        try:
            _, _, a, r = item
            actions.append(int(a))
            rewards.append(float(r))
        except Exception:
            pass
    actions = np.array(actions); rewards = np.array(rewards)
    print("  动作分布 (action 0=刹停, 1~7=速度档):")
    for a in range(8):
        mask = actions == a
        cnt = int(mask.sum())
        if cnt > 0:
            print(f"    action {a}: {cnt:>5} 条  奖励均值={np.mean(rewards[mask]):+7.1f}  std={np.std(rewards[mask]):.1f}")
        else:
            print(f"    action {a}:     0 条")
    nz = int((actions != 0).sum()) if len(actions) else 0
    if len(actions) and nz == 0:
        print("  ⚠️ 全部数据都是 action 0（旧规则动作）→ 探索没有产生非规则动作数据，激活未真正发生")
    elif len(actions) and nz > 0:
        print(f"  ✅ 存在 {nz} 条非规则动作数据 → 探索/激活已产生差异化经验")

def print_console_summary(console_path):
    print("=" * 70)
    print("[4] 控制台日志 (causal_window 趋势)")
    print("=" * 70)
    if not console_path or not os.path.exists(console_path):
        print("  未提供控制台日志（可用 --console 参数）")
        return
    causal = []
    with open(console_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "causal_window" in line:
                try:
                    val = float(line.split("causal_window=")[1].split(",")[0])
                    causal.append(val)
                except Exception:
                    pass
    if not causal:
        print("  日志中未找到 causal_window 行")
        return
    causal = np.array(causal)
    n = len(causal)
    print(f"  causal_window 样本数: {n}")
    print(f"  前 10% 均值: {np.mean(causal[:max(1, n // 10)]):+8.1f}")
    print(f"  后 10% 均值: {np.mean(causal[-max(1, n // 10):]):+8.1f}")
    step = max(1, n // 5)
    for i in range(0, n, step):
        seg = causal[i:i + step]
        print(f"    [{i + 1:>5}~{i + len(seg):>5}] causal_window 均值={np.mean(seg):+8.1f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--console", default=None, help="控制台输出保存的 txt 文件路径")
    ap.add_argument("--save-dir", default=None, help="Saved_DCARL_model 目录（默认: Algorithms/Saved_DCARL_model）")
    ap.add_argument("--record", default=None, help="record_turn.txt 路径（默认: Algorithms/record_turn.txt）")
    args = ap.parse_args()

    global SAVE_DIR, RECORD_FILE
    if args.save_dir:
        SAVE_DIR = args.save_dir
    if args.record:
        RECORD_FILE = args.record

    print("\n========== DCARL Turn 训练结果分析 ==========")
    print(f"数据目录: {SAVE_DIR}")

    ep = load_pkl(os.path.join(SAVE_DIR, "turn_episode_rewards.pkl"))
    print_rewards_summary(ep)
    print_env_record(RECORD_FILE)
    print_rtree_summary()
    print_console_summary(args.console)
    print("\n========== 分析结束 ==========")


if __name__ == "__main__":
    main()

