#!/usr/bin/env python3
"""
转弯场景 DCARL 训练入口

用法（所有路径均为相对路径，换机器无需改动）:
  export CARLA_ROOT=/path/to/carla_0.9.15          # 设置 CARLA 根目录（自动发现失败时才需要）
  export PYTHONPATH="${PYTHONPATH}:$(pwd)/.."       # 项目根目录
  cd Algorithms
  python train_dcarl_turn.py
"""

import sys
import os

# Set the planner profile before importing modules with an action-space layout.
os.environ.setdefault('DSH_CONTROL_PROFILE', 'paper_v11')
if os.environ['DSH_CONTROL_PROFILE'] in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
    os.environ.setdefault('DSH_ACTION_MODE', '2d')
    os.environ.setdefault('DSH_LAT_LEVELS', 'tight')

# 确保项目根目录在 path 中
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ===== 可复现性：DSH_SEED=N 时固定全局随机种子 =====
# 【为什么需要】同一套代码、同一套配置下，两条 100 回合的曲线可能差 10 倍
# （实测 expD_brake100: 83% 碰撞 vs t1_arch_spd: 15% 碰撞，前 3 回合完全相同、
#   第 4 回合才分叉 —— 属于随机种子导致的策略分叉，而不是环境差异）。
# 做 A/B 对照（比如 zone A 半径、EFE 开关、可视化开关）时必须同种子，
# 否则两臂的差异无法归因。默认不设置（保持原随机行为）。
_SEED = os.environ.get('DSH_SEED')
if _SEED:
    import random as _random
    import numpy as _np
    _s = int(_SEED)
    _random.seed(_s)
    _np.random.seed(_s)
    print(f"[Train]: DSH_SEED={_s} 已固定 random / numpy 随机种子（可复现 A/B）")

# 从转弯场景导入环境和 DCARL 模型
from Test_Scenarios.TestScenario_Town03_turn import CarEnv_Town03_Turn
from Agent.drl_library.dds_dcarl.dds_dcarl_turn import DCARL_Turn

# ===== 【§72 修复·双保险】导入之后再播种一次 =====
#   被导入的模块在**模块级**执行过 seed(42)（见 dds_dcarl_turn.py /
#   LaneTrajectoryPlanner.py），会覆盖上面按 DSH_SEED 的播种。导入完成后重播一次。
if _SEED is not None:
    import random as _r2
    import numpy as _n2
    _r2.seed(int(_SEED)); _n2.random.seed(int(_SEED))
    print("[Train]: §72 导入后重新播种 DSH_SEED=%s（修复模块级 seed(42) 覆盖）" % _SEED)

# 训练参数（可用环境变量 DSH_EPISODES 覆盖，便于 A/B 每组固定回合数）
EPISODES = int(os.environ.get('DSH_EPISODES', 2000))

if __name__ == '__main__':
    print("=" * 60)
    print("  DDS-DCARL Turn Scenario Training")
    print("  转弯场景 DCARL 训练")
    print("=" * 60)

    # 创建转弯环境
    env = CarEnv_Town03_Turn()

    # 创建 DCARL 模型（保留博弈论 + 信任集框架）
    model = DCARL_Turn(env, batch_size=20)

    try:
        # 开始训练
        model.evaluate(max_episodes=EPISODES)
    except KeyboardInterrupt:
        print("\n[Train]: 用户中断训练")
    finally:
        # 关掉可视化窗口 / 交互诊断日志（DSH_VIEW / DSH_ILOG 开启时才有实际资源）
        for _obj, _name in ((getattr(model, 'view', None), 'view'),
                            (getattr(model, 'ilog', None), 'ilog')):
            if _obj is not None:
                try:
                    _obj.close()
                except Exception:
                    pass
        env.cleanup()
        print("[Train]: 训练结束，资源已清理")
