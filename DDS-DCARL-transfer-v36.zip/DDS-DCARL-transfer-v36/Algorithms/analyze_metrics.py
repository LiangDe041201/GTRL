#!/usr/bin/env python3
"""
回合指标汇总/对比（对齐论文 Table II/III、Fig.5-11）。

用法（从 Algorithms 目录）:
    python analyze_metrics.py [DIR1] [DIR2] ...        # 每个 DIR 为含 turn_metrics.pkl 的目录
    python analyze_metrics.py                          # 默认读 Saved_DCARL_model

每行输出：回合数 / 碰撞率 / 成功率 / 卡死率 / lcttc_rv / lcttc_fv /
          横饱 / 纵饱 / 接管率 / 前段碰撞 / 后段碰撞（看 RL 是否在学）。
"""
import math
import os
import pickle
import sys

import numpy as np

SAVE_DIR = os.path.join(os.getcwd(), "Saved_DCARL_model")


def load_pkl(path):
    try:
        with open(path, "rb") as f:
            return pickle.load(f)
    except Exception as e:
        print(f"  [warn] 读取 {path} 失败: {e}")
        return None


def _finite_mean(vals):
    fs = [float(v) for v in vals if v is not None and math.isfinite(float(v))]
    return float(np.mean(fs)) if fs else float("nan")


def summarize_one(d):
    metrics = load_pkl(os.path.join(d, "turn_metrics.pkl"))
    if not metrics:
        print(f"  {d}: 无 turn_metrics.pkl")
        return None
    ep = load_pkl(os.path.join(d, "turn_episode_rewards.pkl")) or []

    n = len(metrics)
    terms = [m.get('terminal') for m in metrics]
    n_coll = sum(1 for t in terms if t == 'collision')
    n_comp = sum(1 for t in terms if t == 'complete')
    n_stuck = sum(1 for t in terms if t == 'stuck')
    # 前段 / 后段碰撞率（看 RL 是否在学）
    h = n // 2
    c1 = sum(1 for t in terms[:h] if t == 'collision') / h if h else float('nan')
    c2 = sum(1 for t in terms[h:] if t == 'collision') / max(n - h, 1)

    lrv = [m.get('lcttc_rv_mean') for m in metrics]
    lfv = [m.get('lcttc_fv_mean') for m in metrics]
    lat = [m.get('lat_sat_rate') for m in metrics]
    long_ = [m.get('long_sat_rate') for m in metrics]
    mf = [m.get('mpc_fail_rate') for m in metrics]
    take = []
    for x in ep:
        if isinstance(x, (tuple, list)) and len(x) >= 4:
            take.append(float(x[3]))

    return {
        'dir': d,
        'n': n,
        'coll_rate': n_coll / n if n else float('nan'),
        'suc_rate': n_comp / n if n else float('nan'),
        'stuck_rate': n_stuck / n if n else float('nan'),
        'lcttc_rv': _finite_mean(lrv),
        'lcttc_fv': _finite_mean(lfv),
        'lat_sat': _finite_mean(lat),
        'long_sat': _finite_mean(long_),
        'mpc_fail': _finite_mean(mf),
        'takeover': _finite_mean(take),
        'coll_first': c1,
        'coll_second': c2,
    }


def main():
    dirs = sys.argv[1:] or [SAVE_DIR]
    rows = [r for r in (summarize_one(d) for d in dirs) if r]

    print("=" * 118)
    print("回合指标对比")
    print("=" * 118)
    if not rows:
        print("  没有可用数据")
        return
    print(f"{'目录':<24}{'n':>4}{'碰撞':>7}{'成功':>7}{'卡死':>7}{'LCTTC_rv':>9}"
          f"{'横饱':>7}{'纵饱':>7}{'MPC败':>7}{'接管':>7}{'前段碰撞':>9}{'后段碰撞':>9}")
    print("-" * 118)
    for r in rows:
        print(f"{r['dir'][-22:]:<24}{r['n']:>4}{r['coll_rate']*100:>6.1f}%"
              f"{r['suc_rate']*100:>6.1f}%{r['stuck_rate']*100:>6.1f}%"
              f"{r['lcttc_rv']:>9.3f}"
              f"{r['lat_sat']*100:>6.1f}%{r['long_sat']*100:>6.1f}%{r['mpc_fail']*100:>6.1f}%{r['takeover']:>7.3f}"
              f"{r['coll_first']*100:>8.1f}%{r['coll_second']*100:>8.1f}%")
    print("-" * 118)
    print("说明: 碰撞率越低越好; 成功率=terminal=='complete'; LCTTC_rv 越大越安全(论文GTRL>CG>SG);")
    print("      横/纵饱=MPC 控制饱和率(Table II/III); 接管率=RL 覆盖默认策略频率(Fig.11);")
    print("      前段/后段碰撞率=-前半/后半回合碰撞率, 后段明显低于前段说明 RL 在学。")


if __name__ == "__main__":
    main()
