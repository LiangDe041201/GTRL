#!/usr/bin/env python3
"""交互诊断日志分析 —— 直接回答两个问题：

  Q1 障碍车（RV）是不是**提前刹车**，把环境变简单了？
  Q2 如果是，是"我们自己的 zone A 规则"逼它让行，还是博弈本身让它让行？

用法（在 Algorithms 目录下）：
    python analyze_interaction.py <运行目录> [<运行目录2> ...]

读取 <运行目录>/interaction_{rv,ego,summary}.csv（由 DSH_ILOG=1 生成），
输出关键统计表；不依赖 pandas / CARLA。
"""
import csv
import math
import os
import statistics as st
import sys


# ------------------------------------------------------------
def _read_csv(path):
    if not os.path.exists(path):
        return []
    with open(path, newline='') as f:
        rows = list(csv.DictReader(f))
    return rows


def _num(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _pct(a, b):
    return (100.0 * a / b) if b else 0.0


def _q(vals, p):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    k = (len(vals) - 1) * p
    lo, hi = int(math.floor(k)), int(math.ceil(k))
    if lo == hi:
        return vals[lo]
    return vals[lo] * (hi - k) + vals[hi] * (k - lo)


def _fmt(v, nd=2):
    return '-' if v is None else f"{v:.{nd}f}"


# ------------------------------------------------------------
def analyze(run_dir):
    name = os.path.basename(os.path.abspath(run_dir))
    summ = _read_csv(os.path.join(run_dir, 'interaction_summary.csv'))
    rv = _read_csv(os.path.join(run_dir, 'interaction_rv.csv'))
    ego = _read_csv(os.path.join(run_dir, 'interaction_ego.csv'))

    print('=' * 92)
    print(f'运行目录: {name}   （回合 {len(summ)}，RV 帧 {len(rv)}，ego 帧 {len(ego)}）')
    print('=' * 92)
    if not summ:
        print('  !! 未找到 interaction_summary.csv —— 该运行没有开 DSH_ILOG=1 日志')
        return

    n = len(summ)
    eps = [r.get('episode') for r in summ]
    if len(set(eps)) == 1:
        print('  ⚠ 警告: summary 的 episode 列全为同一个值 —— 这份日志由旧版代码产生'
              '（回合计数器未重置）。')
        print('     → 逐回合计数是**累计值**：下面各项**比例仍然有效**，但总量被放大约 N/2 倍；'
              'first_brake_* / rv_v_at_commit 只反映第 1 回合。')
    coll = sum(1 for r in summ if r.get('collision') == '1')
    stuck = sum(1 for r in summ if r.get('stuck') == '1')
    comp = n - coll - stuck
    print(f'结果: 碰撞 {_pct(coll, n):.1f}% ({coll}) | 成功 {_pct(comp, n):.1f}% ({comp}) '
          f'| 卡死 {_pct(stuck, n):.1f}% ({stuck})')

    # ---- Q2：让行原因分布（谁是"环境变简单"的推手）----
    keys = ['yield_zoneA', 'yield_committed', 'yield_emergency', 'yield_bernoulli',
            'rush_bernoulli']
    tot = {k: sum(int(r.get(k) or 0) for r in summ) for k in keys}
    nd = sum(tot.values())
    print('-' * 92)
    print('【Q2】RV 决策原因分布（全部回合合计）')
    print(f'  总决策次数            : {nd}')
    print(f'  让行·zoneA  (强制)    : {tot["yield_zoneA"]:6d}  ({_pct(tot["yield_zoneA"], nd):5.1f}%)'
          '   ← 我们自己的规则逼它让行（环境被变简单的直接证据）')
    print(f'  让行·committed        : {tot["yield_committed"]:6d}  ({_pct(tot["yield_committed"], nd):5.1f}%)')
    print(f'  让行·emergency        : {tot["yield_emergency"]:6d}  ({_pct(tot["yield_emergency"], nd):5.1f}%)')
    print(f'  让行·bernoulli(博弈)  : {tot["yield_bernoulli"]:6d}  ({_pct(tot["yield_bernoulli"], nd):5.1f}%)'
          '   ← 真正的博弈让行')
    print(f'  抢行·bernoulli        : {tot["rush_bernoulli"]:6d}  ({_pct(tot["rush_bernoulli"], nd):5.1f}%)')

    # ---- Q1：提前刹车 ----
    neb = sum(int(r.get('n_early_brake') or 0) for r in summ)
    nza = sum(int(r.get('n_zoneA_brake') or 0) for r in summ)
    ncb = sum(int(r.get('n_committed_brake') or 0) for r in summ)
    nob = sum(int(r.get('n_other_brake') or 0) for r in summ)
    nbr = neb + nza + ncb + nob
    print('-' * 92)
    print('【Q1】RV 首次刹车事件分类（按 ego 当时位置，互斥）')
    print(f'  刹车事件总数          : {nbr}')
    print(f'  提前刹车(ego >12m)    : {neb:6d}  ({_pct(neb, nbr):5.1f}%)'
          '   ← RV 自己早刹，与我们的规则无关')
    print(f'  zone A 生效时刹(<8m)  : {nza:6d}  ({_pct(nza, nbr):5.1f}%)'
          '   ← 我们自己的规则在起作用')
    print(f'  ego 已越过才刹        : {ncb:6d}  ({_pct(ncb, nbr):5.1f}%)')
    print(f'  过渡带(8~12m)         : {nob:6d}  ({_pct(nob, nbr):5.1f}%)')

    cat = [r.get('first_brake_cat') for r in summ if r.get('first_brake_cat')]
    if cat:
        from collections import Counter
        print(f'  逐回合"首次刹车类别"分布: {dict(Counter(cat))}')

    arc = [ _num(r.get('first_brake_ego_arc')) for r in summ ]
    ed = [ _num(r.get('first_brake_ego_dist')) for r in summ ]
    rvd = [ _num(r.get('first_brake_rv_dist')) for r in summ ]
    rvv = [ _num(r.get('first_brake_rv_v')) for r in summ ]
    print(f'  首次刹车时 ego 距冲突点(m): 中位 {_fmt(_q(ed, .5))}  '
          f'[P25 {_fmt(_q(ed, .25))}, P75 {_fmt(_q(ed, .75))}]')
    print(f'  首次刹车时 ego 弧长(m)    : 中位 {_fmt(_q(arc, .5))}  '
          f'[P25 {_fmt(_q(arc, .25))}, P75 {_fmt(_q(arc, .75))}]   (停止线 ~5m)')
    print(f'  首次刹车时 RV 距冲突点(m) : 中位 {_fmt(_q(rvd, .5))}   车速中位 {_fmt(_q(rvv, .5))} m/s')

    # ---- Q1b：刹车"起因"归因（决策驱动 vs 阻抗驱动）----
    # 决策区入口就在 x≈conflict_x+25（离冲突点约 25m），所以"ego 还在 12m 外就刹车"
    # 绝大多数只是"进区第一帧按让行决策" —— 这**不是**"提前刹车把环境变简单"。
    # 用"距上次决策的帧数"把两者分开。
    onsets = [r for r in rv if r.get('brake_onset') == '1']
    if onsets:
        since = [_num(r.get('since_decision')) for r in onsets]
        since = [s for s in since if s is not None]
        if since:
            dec_driven = sum(1 for s in since if s <= 3)
            print(f'  刹车起因归因（采样 {len(since)} 次刹车起点）:')
            print(f'    决策驱动(距上次决策 ≤3 帧): {_pct(dec_driven, len(since)):5.1f}%'
                  '   ← 进决策区按让行决策，属正常博弈，不是"提前刹车"')
            print(f'    阻抗驱动(远离决策时刻)    : {_pct(len(since) - dec_driven, len(since)):5.1f}%'
                  '   ← IDM 跟车/前车减速导致')
            print(f'    距上次决策帧数 中位 {_fmt(_q(since, .5), 1)}')
    if rv and 'since_decision' not in rv[0]:
        print('  （提示：本目录的 interaction_rv.csv 是旧版格式，缺少 since_decision 列，'
              '无法做刹车起因归因）')

    # ---- 通过瞬间的间隙质量 ----
    vcommit = [_num(r.get('rv_v_at_commit')) for r in summ if r.get('rv_v_at_commit')]
    dcommit = [_num(r.get('rv_dist_at_commit')) for r in summ if r.get('rv_dist_at_commit')]
    print('-' * 92)
    print('ego 越过冲突点(committed)瞬间的 RV 状态（间隙质量）')
    print(f'  观测到的回合数        : {sum(1 for r in summ if r.get("n_commit_observed") not in (None, "", "0"))}')
    print(f'  RV 车速 中位          : {_fmt(_q(vcommit, .5))} m/s   '
          f'[P25 {_fmt(_q(vcommit, .25))}, P75 {_fmt(_q(vcommit, .75))}]')
    print(f'  RV 距冲突点 中位      : {_fmt(_q(dcommit, .5))} m')

    # ---- 按结果分组，看环境难度是否随结果变化 ----
    print('-' * 92)
    print('按回合结果分组（看"提前刹车/zoneA 让行"是否与成功相关）')
    print(f'  {"结果":<8}{"回合":>6}{"平均提前刹车":>14}{"zoneA让行占比":>16}'
          f'{"平均RV最低速":>14}{"平均决策数":>12}{"平均帧数":>10}')
    for label, flt in (('成功', lambda r: r.get('collision') != '1' and r.get('stuck') != '1'),
                       ('碰撞', lambda r: r.get('collision') == '1'),
                       ('卡死', lambda r: r.get('stuck') == '1')):
        grp = [r for r in summ if flt(r)]
        if not grp:
            continue
        m_eb = st.mean([float(r.get('n_early_brake') or 0) for r in grp])
        za = sum(int(r.get('yield_zoneA') or 0) for r in grp)
        dd = sum(int(r.get('n_decision') or 0) for r in grp)
        mv = [ _num(r.get('rv_min_v')) for r in grp ]
        mv = [x for x in mv if x is not None]
        fr = [ _num(r.get('frames')) for r in grp ]
        fr = [x for x in fr if x is not None]
        print(f'  {label:<8}{len(grp):>6}{m_eb:>14.2f}{_pct(za, dd):>15.1f}%'
              f'{(st.mean(mv) if mv else float("nan")):>14.2f}{dd / len(grp):>12.1f}'
              f'{(st.mean(fr) if fr else float("nan")):>10.0f}')
    print('  （成功回合若"平均帧数"远大于碰撞回合 ⇒ 多半是"等到车流走完再过"，'
          '不是插入到间隙里）')

    # ---- 安全性：来自 ego 日志 ----
    if ego:
        lc = [_num(r.get('lcttc_rv')) for r in ego]
        lc = [x for x in lc if x is not None]
        tw = [_num(r.get('thw_boundary_rv')) for r in ego]
        tw = [x for x in tw if x is not None]
        print('-' * 92)
        print('ego 侧安全量（逐帧）')
        print(f'  LCTTC_rv  均值 {_fmt(st.mean(lc) if lc else None)}  中位 {_fmt(_q(lc, .5))}')
        print(f'  THW_boundary 均值 {_fmt(st.mean(tw) if tw else None)}  中位 {_fmt(_q(tw, .5))}')

        # ---- ★"冻住/爬行"诊断（奖励劫持的直接证据）----
        # 为什么单列：等待补偿 +5/帧 时，ego 学会把车停在路口（v→0）拿稳定正回报，
        # 而撞车才有 -300；实测该策略下 episode 回报甚至为正（G 最高 +1293）。
        vs = [_num(r.get('ego_v')) for r in ego]
        crawl = sum(1 for x in vs if x is not None and x < 0.5)
        run = best = 0
        for x in vs:
            if x is not None and x < 0.5:
                run += 1
                best = max(best, run)
            else:
                run = 0
        vv = [x for x in vs if x is not None]
        print(f'  爬行帧(v<0.5 m/s)占比    : {_pct(crawl, len(vv)):5.1f}%'
              f'   最长连续爬行 {best} 帧 = {best * 0.05:.1f} s'
              + ('   ← ★奖励劫持迹象（等待补偿过高时出现）' if _pct(crawl, len(vv)) > 25 else ''))
        print(f'  ego 平均车速             : {_fmt(st.mean(vv) if vv else None)} m/s')
        nrv = sum(1 for r in ego if r.get('efe_active') == '1')
        print(f'  EFE 生效帧数          : {nrv} / {len(ego)}'
              + ('   (EFE 已开启)' if nrv else '   (本运行 EFE 关闭)'))

    # ---- 结论提示 ----
    print('=' * 92)
    zoneA_share = _pct(tot['yield_zoneA'], nd)
    ze_share = _pct(nza, max(nbr, 1))
    eb_share = _pct(neb, max(nbr, 1))
    if zoneA_share >= 30 or ze_share >= 30:
        print('判读: ★环境被"我们自己的 zone A 规则"显著简化★ —— zoneA 让行占全部决策 '
              f'{zoneA_share:.1f}%，刹车事件中 zoneA 时点占 {ze_share:.1f}%。'
              '\n      碰撞率下降**不能全部**归因于 ego 策略学习，必须补 '
              'DSH_ZONE_A_R=0 的对照实验。')
    elif eb_share >= 50:
        print(f'判读: RV 提前刹车比例较高（{eb_share:.1f}%，ego 还在 12m 外就刹），'
              f'但 zoneA 时点只占 {ze_share:.1f}% ⇒ 早刹主要来自 IDM/博弈本身，'
              '\n      不是我们的规则造成的。环境"偏简单"这一点仍需在报告里如实说明。')
    else:
        print(f'判读: 提前刹车占比 {eb_share:.1f}%、zoneA 刹车时点占比 {ze_share:.1f}%、'
              f'zoneA 让行占决策 {zoneA_share:.1f}% ⇒ 未发现"环境被人为变简单"的证据。')
    print('=' * 92)


def main(argv):
    dirs = argv[1:]
    if not dirs:
        print(__doc__)
        return 1
    for d in dirs:
        analyze(d)
        print()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
