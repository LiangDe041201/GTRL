#!/usr/bin/env python3
"""
离线对拍检查入口（无 CARLA 依赖）。

用法（从 Algorithms 目录）:
    python offline_check.py

约定：每个阶段向本文件追加 check_phaseN() 并注册到 main()。
全部 PASS 才允许把整个 DDS-DCARL 文件夹拷贝到有 CARLA 的机器上跑真实训练。
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_HERE)          # DDS-DCARL-Turn
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


# ============================================================
# 阶段 0：场景快照与确定性 fixture
# ============================================================
def check_phase0():
    from Planning_library.scenario_snapshot import make_fixture

    ok = True

    def expect(cond, msg):
        nonlocal ok
        ok &= bool(cond)
        print(("  PASS  " if cond else "  FAIL  ") + msg)

    print("=" * 60)
    print("阶段 0：场景快照与确定性 fixture")
    print("=" * 60)

    # 0a. 本检查进程不得依赖 carla
    expect("carla" not in sys.modules, "离线环境未 import carla")

    # 0b. 6 种典型局面可构造
    snaps = [make_fixture(i) for i in range(1, 7)]
    expect(len(snaps) == 6, f"6 种 fixture 全部可构造 (got {len(snaps)})")

    # 0c. 确定性：同一 case 两次构造逐字段一致
    a, b = make_fixture(1), make_fixture(1)
    same = (a.ego.x == b.ego.x and a.ego.y == b.ego.y
            and a.t_ego == b.t_ego and a.committed == b.committed
            and len(a.vehicles) == len(b.vehicles)
            and all(v1.x == v2.x and v1.v == v2.v
                    for v1, v2 in zip(a.vehicles, b.vehicles)))
    expect(same, "fixture 构造确定性（同一 case 两次构造一致）")

    # 0d. 语义检查：坐标 / 时间差语义与计划一致
    s1 = snaps[0]
    rv1 = [v for v in s1.vehicles if v.role == "rv"][0]
    expect(rv1.x > s1.conflict_xy[0] and rv1.vx < 0,
           f"case1 rv 位于冲突点东侧、向西逼近 (x={rv1.x}, vx={rv1.vx})")
    expect(abs(s1.t_ego - 0.5) < 1e-9, f"case1 t_ego=0.5s (got {s1.t_ego})")
    delta_t1 = (rv1.x - s1.conflict_xy[0]) / rv1.v - s1.t_ego
    expect(abs(delta_t1 - 2.9) < 1e-9, f"case1 Δt=t_veh-t_ego≈2.9s (got {delta_t1:.2f})")

    s3 = snaps[2]
    rv3 = [v for v in s3.vehicles if v.role == "rv"][0]
    t_veh3 = (rv3.x - s3.conflict_xy[0]) / rv3.v
    expect(t_veh3 <= s3.t_ego, f"case3 rv 不晚于自车到冲突点 (t_veh={t_veh3:.2f} <= t_ego={s3.t_ego:.2f})")

    s6 = snaps[5]
    expect(s6.committed and s6.ego.y < s6.conflict_xy[1],
           f"case6 已越过冲突点 (committed, ego.y={s6.ego.y})")

    print("-" * 60)
    print("阶段 0：%s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


# ============================================================
# 阶段 1：④ 边界安全接线（rv/fv 识别 + LCTTC/THW_boundary + 奖励安全项）
# ============================================================
def check_phase1():
    import math

    import numpy as np

    from Planning_library.scenario_snapshot import make_fixture
    from Planning_library.gap_analysis import identify_gap_vehicles, compute_gap_metrics
    from Planning_library.reward_components import boundary_safety_reward

    ok = True
    skipped = []

    def expect(cond, msg):
        nonlocal ok
        ok &= bool(cond)
        print(("  PASS  " if cond else "  FAIL  ") + msg)

    print("=" * 60)
    print("阶段 1：④ 边界安全接线（rv/fv 识别 + LCTTC/THW_boundary + 奖励）")
    print("=" * 60)

    # 1a. rv/fv 识别
    s1 = make_fixture(1)
    ids1 = identify_gap_vehicles(s1)
    expect(ids1["rv"] is not None and ids1["rv"].x == 40.0,
           f"case1 识别 rv（东侧 40m, x={ids1['rv'].x if ids1['rv'] else None}）")
    expect(ids1["fv"] is not None and ids1["fv"].x == 8.0,
           f"case1 识别 fv（x=8, t_veh=0.2s 先于自车到, x={ids1['fv'].x if ids1['fv'] else None}）")
    expect(ids1["n_vehicles"] == 2 and ids1["t_veh_min"] == 0.2,
           f"case1 统计 n_vehicles=2, t_veh_min=0.2 (got {ids1['n_vehicles']}, {ids1['t_veh_min']})")

    s3 = make_fixture(3)
    ids3 = identify_gap_vehicles(s3)
    expect(ids3["rv"] is not None and ids3["rv"].x == 11.0,
           "case3 rv 是最近的晚到车 (x=11, t_veh=t_ego=0.5)")
    expect(ids3["fv"] is not None and ids3["fv"].x == 8.0,
           "case3 fv 是先到车 (x=8)")

    # 1b. LCTTC 语义：rv 越近越危险
    m1 = compute_gap_metrics(s1)
    m3 = compute_gap_metrics(s3)
    expect(m1["lcttc_rv"] > m3["lcttc_rv"],
           f"case1 rv LCTTC({m1['lcttc_rv']:.2f}) > case3 rv LCTTC({m3['lcttc_rv']:.2f})")
    expect(m3["lcttc_rv"] < 2.0, f"case3 rv LCTTC 较小（{m3['lcttc_rv']:.2f}s，rv 逼近）")
    expect(math.isinf(m1["lcttc_fv"]) or m1["lcttc_fv"] > 0.0,
           "case1 fv 的 LCTTC 为有限正值（跟随通过车）")

    # 1c. 奖励分段（对齐论文式 65：主体用 THW_boundary）
    inf = float("inf")
    r_committed = boundary_safety_reward(0.5, 0.5, 0.5, committed=True, n_vehicles=1)
    expect(r_committed == 0.0, f"committed -> 0 (got {r_committed})")
    r_none = boundary_safety_reward(inf, inf, inf, committed=False, n_vehicles=0)
    # 【P1-f】空路口默认中性 0（旧值 +2/帧 = "什么都不做也白拿"）
    expect(r_none == 0.0, f"无车 -> 0（P1-f 中性化；旧口径 +2 需显式传参）(got {r_none})")
    expect(boundary_safety_reward(inf, inf, inf, committed=False, n_vehicles=0,
                                  no_vehicle_bonus=2.0) == 2.0, "无车 -> 旧口径 +2 仍可显式复现")
    r_danger = boundary_safety_reward(0.3, inf, 0.3, committed=False, n_vehicles=1)
    expect(r_danger < -30.0, f"THW=0.3/LCTTC=0.3 大负（{r_danger:.1f}）")
    r_safe = boundary_safety_reward(2.5, 2.5, 3.0, committed=False, n_vehicles=1)
    expect(r_safe == 20.0, f"式65: 10·min(2,THW=3)=20（{r_safe:.1f}）")
    # 【P1-f】无 RV（THW=inf）必须中性 0 —— 这是"减速制造没有对手 ⇒ 白拿满分"的劫持源
    r_norv = boundary_safety_reward(inf, inf, inf, committed=False, n_vehicles=4)
    expect(r_norv == 0.0, f"【P1-f】无 RV(THW=inf) -> 0，不得为满额 +20 (got {r_norv})")
    expect(boundary_safety_reward(inf, inf, inf, committed=False, n_vehicles=4,
                                  missing_thw_neutral=False) == 20.0,
           "旧口径(+20/帧，劫持源)可显式打开做消融对照")
    expect(r_norv > r_danger, "反劫持不变式：'没有对手'(0) 必须优于'真危险'(-39)")
    r_yield = boundary_safety_reward(0.3, inf, 0.3, committed=False, n_vehicles=1,
                                     yield_wait=True, yield_wait_bonus=5.0)
    # 【P1-f(b)】等待补偿改为追加项，不再短路危险惩罚：3.0 + 5.0 - 42 = -34
    expect(r_yield == -34.0, f"旧口径等待补偿(bonus=5)为追加项, 不豁免危险惩罚 (got {r_yield})")
    # 【P1 修复·奖励劫持】默认等待补偿改为 0：等待必须比过弯**更差**，否则 RL 会学会停车
    # （实测 expE_p0_100：低速帧逐帧 +20.41 连续 150 帧，ego 停在路口里被撞）
    r_yield0 = boundary_safety_reward(0.3, inf, 0.3, committed=False, n_vehicles=1,
                                      yield_wait=True, yield_wait_bonus=0.0)
    expect(r_yield0 < 0.0, f"【P1】等待补偿默认 0，且危险惩罚仍生效 (got {r_yield0})")
    r_mid = boundary_safety_reward(inf, inf, 1.2, committed=False, n_vehicles=1)
    expect(r_mid == 12.0, f"式65: 10·min(2,THW=1.2)=12（{r_mid:.1f}）")

    # 1d. MPC 边界 THW 序列（需要 casadi；缺失则 SKIP）
    try:
        from Agent.game_theory.MPC import MPCController
        mpc = MPCController(N=5, dt=0.1, d_safe=2.7, thw_min=0.5,
                            max_speed=10.0, enable_lead_follow_cost=True)
        rv = s3.vehicles[1]  # case3 的 rv（x=9, v=10）
        seq = mpc._compute_thw_boundary_sequence(6.0, -135.0, -math.pi / 2, 6.0, rv)
        expect(seq.shape == (1, 6) and bool(np.all(np.isfinite(seq))),
               f"MPC thw_boundary 序列形状/有限性 (shape={seq.shape}, min={float(seq.min()):.2f})")
        expect(float(seq.min()) < float(seq.max()),
               "MPC thw_boundary 序列随时间变化（rv 逼近）")
    except ImportError as e:
        skipped.append(f"MPC 边界 THW（casadi 缺失: {e}）")
        print("  SKIP  MPC 边界 THW 序列（casadi 未安装，跳过节）")

    print("-" * 60)
    print("阶段 1：%s%s" % ("ALL PASS" if ok else "SOME FAIL",
                           ("（SKIP: " + "; ".join(skipped) + "）") if skipped else ""))
    return ok


# ============================================================
# 阶段 2：① Cournot 零和博弈接线（支付矩阵 + 期望支付 + 让行概率）
# ============================================================
def check_phase2():
    from Planning_library.cournot_game import build_payoff_matrix, cournot_decision
    from Planning_library.rv_decision import rv_yield_probability

    print("=" * 60)
    print("阶段 2：① Cournot 博弈接线（支付矩阵 + 期望支付 + rv 让行概率）")
    print("=" * 60)
    ok = True
    for name, cond in [
        ("博弈耦合：p_yield=0.9 -> ego_go（RV 大概率让行 → 出发）",
         cournot_decision(12.0, 9.0, v_go=5.0, p_yield=0.9)['ego_go']),
        ("博弈耦合：p_yield=0.1 -> 停车（RV 抢行风险 > 等待代价）",
         not cournot_decision(12.0, 9.0, v_go=5.0, p_yield=0.1)['ego_go']),
        ("支付矩阵零和：U_rv = -U_ego（2x2 形状）",
         len(build_payoff_matrix(12.0, 9.0)) == 2
         and len(build_payoff_matrix(12.0, 9.0)[0]) == 2),
        ("让行概率确定性且限幅 [0.1, 0.9]",
         rv_yield_probability({'x': 6.0, 'y': -130.0, 'v': 5.0},
                              {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0},
                              6.0, 4.0) == rv_yield_probability(
             {'x': 6.0, 'y': -130.0, 'v': 5.0},
             {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0}, 6.0, 4.0)),
        ("双侧THW安全项：THW高收益 > THW低收益（此消彼长）",
         build_payoff_matrix(16.0, 24.6, thw_rv=2.0, thw_fv=2.0)[1][1]
         > build_payoff_matrix(16.0, 24.6, thw_rv=0.5, thw_fv=0.5)[1][1]),
        ("双侧THW安全项（式24）：任一侧贴近危险(THW<TH_th)都会压低U_safe（平方偏差），两侧对称",
         build_payoff_matrix(16.0, 24.6, thw_rv=2.0, thw_fv=0.5, u_safe_mode='eq24')[1][1]
         == build_payoff_matrix(16.0, 24.6, thw_rv=0.5, thw_fv=2.0, u_safe_mode='eq24')[1][1]
         and build_payoff_matrix(16.0, 24.6, thw_rv=2.0, thw_fv=2.0, u_safe_mode='eq24')[1][1]
         > build_payoff_matrix(16.0, 24.6, thw_rv=0.5, thw_fv=0.5, u_safe_mode='eq24')[1][1]),
    ]:
        print("  %s -> %s" % (name, "PASS" if cond else "FAIL"))
        ok &= bool(cond)
    print("-" * 60)
    print("阶段 2：%s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


# ============================================================
# 阶段 3：P0 修复对拍（g_d 米制口径 / zone A 作用对象 / 车流物理一致性）
# ============================================================
def check_phase3():
    from Planning_library.gap_analysis import fv_rv_spatial_gap
    from Planning_library.game_reward import (gap_dist_reward, gap_rate_reward,
                                              game_reward, GAP_LO, GAP_MID, GAP_HI, GAP_MAX)
    from Planning_library.rv_decision import (select_conflict_rv, time_to_cover,
                                              rv_yield_probability, idm_leader_index)

    print("=" * 60)
    print("阶段 3：P0 修复（式62 g_d 米制 / zone A 只作用于冲突车 / 车流 IDM 一致）")
    print("=" * 60)

    class V:
        def __init__(self, vid, x, v=0.0, length=3.6):
            self.id, self.x, self.v, self.length = vid, x, v, length

    # --- 式62 的 g_d 是"米"：断点 2.5/3.5/5.0/7.0 ---
    g_small = fv_rv_spatial_gap({'rv': V(1, 6.0), 'fv': V(2, 0.0)})    # 6 − 3.6 = 2.4 m
    g_ok = fv_rv_spatial_gap({'rv': V(1, 8.6), 'fv': V(2, 0.0)})       # 8.6 − 3.6 = 5.0 m
    g_far = fv_rv_spatial_gap({'rv': V(1, 12.0), 'fv': V(2, 0.0)})     # 12 − 3.6 = 8.4 m

    # --- 车流物理一致性：出生中心距必须 ≥ IDM 平衡中心距 g0 + v·T + 车长 ---
    def _idm_equilibrium_center(v, g0=2.0, T=0.5, L=3.6):
        return g0 + v * T + L

    for vfree in (6.0, 10.0):
        print("  v_free=%.0f m/s → IDM 平衡中心距 = %.1f m (净间隙 %.1f m)"
              % (vfree, _idm_equilibrium_center(vfree), _idm_equilibrium_center(vfree) - 3.6))

    # --- 时间可覆盖性：ego 清空冲突点的时间 vs 车流覆盖时长 ---
    t_clear_ego = time_to_cover(14.0, 5.0, 5.0)                    # 自车 5 m/s 走 14 m

    ok = True
    for name, cond in [
        ("式62 g_d 为米制：FV–RV 中心距 − 车长（RV 在东、FV 在西）",
         abs(g_small - 2.4) < 1e-6 and abs(g_ok - 5.0) < 1e-6),
        ("式62 断点量纲正确：g_d=2.4→惩罚, 5.0→正奖励, 8.4→0",
         gap_dist_reward(g_small) < 0 < gap_dist_reward(g_ok) and gap_dist_reward(g_far) == 0.0),
        ("式62 断点值 = 论文原值 (2.5/3.5/5.0/7.0)",
         (GAP_LO, GAP_MID, GAP_HI, GAP_MAX) == (2.5, 3.5, 5.0, 7.0)),
        ("式63 ġ：间隙张开(>0.5)得正、闭合(≤−0.1)重罚",
         gap_rate_reward(0.8) > 0 > gap_rate_reward(-0.5)),
        ("式64 r_game = r_gap-rate + 0.5·r_gap-dist",
         abs(game_reward(0.8, 5.0) - (gap_rate_reward(0.8) + 0.5 * gap_dist_reward(5.0))) < 1e-9),
        ("博弈未进行(FV/RV 缺一) → g_d=None（调用方按 GAP_IDLE=7.0 处理 → 式62 = 0）",
         fv_rv_spatial_gap({'rv': V(1, 6.0), 'fv': None}) is None
         and gap_dist_reward(7.0) == 0.0),
        ("zone A 作用对象：只选与 ego 时空冲突的那一辆（远车不被强制让行）",
         select_conflict_rv([{'id': 1, 'x': 17.0, 'v': 10.0},
                             {'id': 2, 'x': 40.0, 'v': 10.0}],
                            -7.1, t_ego=2.0, clear_time=1.0, margin=0.5)[0] == 1),
        ("zone A 作用对象：全部都很远时 → 无车被强制让行",
         select_conflict_rv([{'id': 1, 'x': 60.0, 'v': 10.0}],
                            -7.1, t_ego=1.0, clear_time=1.0)[0] is None),
        ("【旧 bug 回归】IDM 前车识别：升序列表中第 i 辆的前车是 i−1（原写法恒为 None）",
         idm_leader_index([0.0, 8.6, 17.2, 25.8], 1) == 0
         and idm_leader_index([0.0, 8.6, 17.2, 25.8], 0) is None),
        ("式61 t_avail 用 t_ego（ego 到冲突点时间）：t_ego 越小 → 让行概率越高",
         rv_yield_probability({'x': 6.0, 'y': -130.0, 'v': 5.0},
                              {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0},
                              6.0, 4.0, t_ego=1.0)
         > rv_yield_probability({'x': 6.0, 'y': -130.0, 'v': 5.0},
                                {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0},
                                6.0, 4.0, t_ego=8.0)),
        ("IDM 平衡中心距与「出生间隔 × 车速」一致（不再出现 v=10 + 0.5s = 5m 这种死结）",
         abs(_idm_equilibrium_center(6.0) - 8.6) < 1e-9
         and _idm_equilibrium_center(6.0) / 6.0 > 1.0),
        ("车流覆盖时长 ≥ ego 清空冲突点时间（≥1 个可插入窗口）",
         (14 * (2.0 + 6.0 * 0.5 + 3.6) / 6.0) > t_clear_ego),
    ]:
        print("  %s -> %s" % (name, "PASS" if cond else "FAIL"))
        ok &= bool(cond)
    print("-" * 60)
    print("阶段 3：%s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


# ============================================================
# 阶段 5：【创新点④·P1-g】边界安全"保守确定性策略"动作屏蔽
#   实测依据 expF_paper100（100 回合，碰撞 77%）：lcttc_rv<1.0s 的 1491 帧里
#   1240 帧（83%）最终动作不是刹车 ⇒ ④ 此前只进奖励/WCV，从未约束动作空间。
# ============================================================
def check_phase5():
    from Planning_library.boundary_safety import (
        boundary_shield_active, boundary_shield_mask,
        SHIELD_LCTTC_DEFAULT, SHIELD_LCTTC_CRITICAL)
    print("=" * 60)
    print("阶段 5：④ 边界安全动作屏蔽（保守确定性策略）")
    print("=" * 60)
    ok = True
    SPEEDS = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0]
    INF = float('inf')
    for name, cond in [
        ("非危险 -> 全放行（不能因'没测到'锁死自车）",
         boundary_shield_mask(SPEEDS, INF, INF, False, 3.0) == [True] * 8
         and boundary_shield_mask(SPEEDS, float('nan'), INF, False, 3.0) == [True] * 8),
        ("第一档 lcttc=0.5s -> 只许不加速（ego_v=3.0 时 0/1/2/3 档）",
         boundary_shield_mask(SPEEDS, 0.5, INF, False, 3.0)
         == [True, True, True, True, False, False, False, False]),
        ("第二档 lcttc=0.05s（临界）-> 只剩刹车",
         boundary_shield_mask(SPEEDS, 0.05, INF, False, 2.8) == [True] + [False] * 7),
        ("committed=True -> 不屏蔽（加速驶离才是保守动作）",
         boundary_shield_mask(SPEEDS, 0.0, INF, True, 2.0) == [True] * 8),
        ("至少保留一个可执行档位",
         any(boundary_shield_mask([5.0, 6.0, 8.0], 0.05, INF, False, 0.0))),
        ("expF 实测撞车帧 (ego_v=2.825, lcttc=0.009, action=3) 被拦下",
         boundary_shield_active(0.009, INF, False)
         and not boundary_shield_mask(SPEEDS, 0.009, INF, False, 2.825)[3]),
        ("阈值常量自洽 (critical < default)",
         SHIELD_LCTTC_CRITICAL < SHIELD_LCTTC_DEFAULT),
        # 【S5-③】屏蔽层只约束纵向：速度有重复档时（2d 动作空间 a=i_sp*3+i_lat），
        #   "只剩刹车"必须是**整个最慢速度层**（3 个横向都放行），否则会退化成
        #   "只放行 index0 = (v=0, di=-1.5)"，等于屏蔽层每帧偷偷向左切 1.5 m。
        #   实测 expKK_2d_100：shield 帧 5669/5669 全是 action 0，占全部帧 46%。
        ("[S5-③] 2d 临界档放行整个最慢速度层（横向不被砍到只剩一个）",
         boundary_shield_mask([0.0, 0.0, 0.0, 4.0, 4.0, 4.0], 0.05, INF, False, 6.0)
         == [True, True, True, False, False, False]),
        ("[S5-③] 2d 第一档按速度层放行，横向三种齐全",
         boundary_shield_mask([0.0, 0.0, 0.0, 4.0, 4.0, 4.0], 0.5, INF, False, 2.0)
         == [True, True, True, False, False, False]),
        # 注：`shield_fallback_action` / `BRAKE_ACTION` 的检查放在
        #     `Test_Scenarios/test_shield_lateral_invariance.py`（那个文件 import carla，
        #     而本文件阶段 0 断言"离线环境未 import carla"，不能引 LaneTrajectoryPlanner）。
    ]:
        print("  %s -> %s" % (name, "PASS" if cond else "FAIL"))
        ok &= bool(cond)
    print("-" * 60)
    print("阶段 5：%s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


# ============================================================
# 阶段 4：车流队列离线仿真 —— 证明"死结"被修好 + 让行能张开间隙
# ============================================================
def _simulate_queue(v_free=6.0, interval=None, n=14, dt=0.05, T=6.0,
                    yield_idx=None, yield_from=200, yield_target=3.0,
                    yield_decel=2.5, veh_len=3.6, g0=2.0, idm_T=0.5,
                    a=2.0, b=2.5, delta=4.0):
    """离线复现 CrossTrafficManager 的车流纵向逻辑（出生 + IDM + 让行限速趋近）。

    坐标约定：车流向 −x 方向行驶；**index 0 = 队首（x 最小，最靠西）**，
    index 越大越靠东（越靠后）。车距 = x[i] − x[i−1] − 车身长。

    返回：
      min_center 全程最小中心距 (m)；min_clear 全程最小净间隙 (m)
      min_v 全程最小车速；gap_ahead_of_yield 让行车辆与其前车的末态中心距
      collision = 净间隙 < 0（"后车碰前车"）
    """
    from Planning_library.rv_decision import idm_acceleration, idm_equilibrium_speed
    center0 = g0 + v_free * idm_T + veh_len
    interval = interval if interval is not None else center0 / v_free
    clear_gap = interval * v_free - veh_len
    # 【关键】出生速度取该间隙下的 IDM 稳态车速（v0 只是空路期望速度），
    # 否则出生瞬间必然有一段减速暂态 —— 那正是"幽灵刹车"的来源。
    v_spawn = idm_equilibrium_speed(clear_gap, v0=v_free, T=idm_T, g0=g0,
                                    a=a, b=b, delta=delta)
    xs = [i * (interval * v_free) for i in range(n)]      # 0 在最小 x（队首）
    vs = [float(v_spawn)] * n
    # yield_idx 可以是单个索引或索引集合（集合 = 让行编队，P1-d）
    _yidx = set()
    if yield_idx is not None:
        _yidx = {int(yield_idx)} if isinstance(yield_idx, int) else set(yield_idx)
    min_center, min_clear, min_v = float('inf'), float('inf'), float('inf')
    for f in range(int(T / dt)):
        new_vs = list(vs)
        for i in range(n):
            if i == 0:
                continue                                  # 队首无前车（自由流）
            gap = (xs[i] - xs[i - 1]) - veh_len
            acc = idm_acceleration(vs[i], vs[i - 1], gap, v0=v_free, T=idm_T,
                                   g0=g0, a=a, b=b, delta=delta)
            new_vs[i] = max(0.0, vs[i] + acc * dt)
            min_clear = min(min_clear, gap)
        # 【顺序很关键】让行在 IDM 之后施加（与 CrossTrafficManager 的实现顺序一致）：
        # 若放在 IDM 之前会被 IDM 覆盖掉（间隙变大 → IDM 立刻要求加速回来）。
        for _yi in _yidx:
            if f >= yield_from:
                _tgt = float(yield_target)
                if new_vs[_yi] > _tgt:
                    new_vs[_yi] = max(_tgt, new_vs[_yi] - yield_decel * dt)
                else:
                    new_vs[_yi] = min(new_vs[_yi], max(_tgt, 0.5))
        vs = new_vs
        for i in range(n):
            xs[i] -= vs[i] * dt
        for i in range(1, n):
            min_center = min(min_center, xs[i] - xs[i - 1])
        min_v = min(min_v, min(vs))
    centers = [(xs[i] - xs[i - 1]) for i in range(1, n)]
    # 【P1-d】ego 可用的插入窗口 = 编队"队首的前车车尾"到"编队最后一辆的车头"
    #   即 x[last_y] − x[first_y − 1] − 车身长（编队车一起后退时窗口持续张开）
    window = None
    if _yidx:
        _first, _last = min(_yidx), max(_yidx)
        if _first - 1 >= 0:
            window = xs[_last] - xs[_first - 1] - veh_len
    return {'min_center': min_center, 'min_clear': min_clear, 'min_v': min_v,
            'centers_end': centers[-3:], 'centers': centers,
            'gap_ahead_of_yield': (centers[min(_yidx) - 1] if _yidx
                                   and min(_yidx) - 1 >= 0 else None),
            'window': window,
            'v_yield_end': (vs[min(_yidx)] if _yidx else None),
            'v_free': v_free, 'interval': interval, 'v_spawn': v_spawn,
            'clear_gap': clear_gap,
            'collision': min_clear < 0.0}


def check_phase4():
    from Planning_library.rv_decision import idm_equilibrium_center, time_to_cover

    print("=" * 60)
    print("阶段 4：车流队列离线仿真（旧配置 vs P0 修复后的配置）")
    print("=" * 60)

    # 旧配置：v_free=10, 出生间隔 0.5 s（= 5 m 中心距，远小于 IDM 平衡中心距 10.6 m）
    old = _simulate_queue(v_free=10.0, interval=0.5, n=10)
    # 新配置：v_free=6, 出生间隔由 IDM 安全距离反推
    new = _simulate_queue(v_free=6.0, interval=None, n=14)
    # 【P1-d 对照 1】让行幅度：旧目标 3.0 m/s（≈巡航，差 1.4）vs 新目标 0.3×巡航（差 ~3.1）
    _ratio = 0.3                                   # = CrossTrafficManager 的 DSH_RV_YIELD_RATIO
    _new_tgt = _ratio * new['v_spawn']
    new_y = _simulate_queue(v_free=6.0, interval=None, n=14, yield_idx=2,
                            yield_from=100, T=10.0, yield_target=_new_tgt)
    new_y_old_tgt = _simulate_queue(v_free=6.0, interval=None, n=14, yield_idx=2,
                                    yield_from=100, T=10.0, yield_target=3.0)
    # 【P1-d 对照 2】让行编队：只让 1 辆 vs 让行向后传播 1 辆（2 辆一起让）
    new_y_platoon = _simulate_queue(v_free=6.0, interval=None, n=14,
                                    yield_idx={2, 3}, yield_from=100, T=10.0)

    eq6, eq10 = idm_equilibrium_center(6.0), idm_equilibrium_center(10.0)
    t_clear_ego = time_to_cover(14.0, 5.0, 5.0)      # 自车 5 m/s 走 14 m 清空冲突点
    cover_s = 14 * eq6 / 6.0

    print("  旧配置(v=10, 0.5s):     最小中心距 %.2f m, 最小净间隙 %.2f m, 最小车速 %.2f m/s"
          "   ← 队列被压到停车" % (old['min_center'], old['min_clear'], old['min_v']))
    print("  新配置(v0=6, IDM 安全): 设计净间隙 %.2f m → 稳态车速 %.2f m/s；"
          "仿真最小中心距 %.2f m, 最小净间隙 %.2f m, 最小车速 %.2f m/s"
          % (new['clear_gap'], new['v_spawn'], new['min_center'],
             new['min_clear'], new['min_v']))
    print("  单辆让行(旧目标 3.0):   让行车末速 %.2f m/s；其前方末态中心距 %.2f m；"
          "ego 窗口 %.2f m" % (new_y_old_tgt['v_yield_end'],
                             new_y_old_tgt['gap_ahead_of_yield'], new_y_old_tgt['window']))
    print("  单辆让行(新目标 %.2f):  让行车末速 %.2f m/s；其前方末态中心距 %.2f m；"
          "ego 窗口 %.2f m" % (new_y['v_yield_end'], new_y['v_yield_end'],
                             new_y['gap_ahead_of_yield'], new_y['window']))
    print("  让行编队(k=1, 2 辆让行):  ego 窗口 %.2f m  (≈ %.1f s @%.1f m/s)"
          % (new_y_platoon['window'],
             new_y_platoon['window'] / max(new_y_platoon['v_spawn'], 0.1),
             new_y_platoon['v_spawn']))
    print("  车流覆盖时长 ≈ %.0f s；ego 清空冲突点 ≈ %.1f s" % (cover_s, t_clear_ego))

    _w1 = new_y['window'] or 0.0
    _w2 = new_y_platoon['window'] or 0.0
    _w_old = new_y_old_tgt['window'] or 0.0

    ok = True
    for name, cond in [
        ("旧配置物理不可能：出生中心距(5m) < IDM 平衡中心距(%.1f m)" % eq10,
         5.0 < eq10),
        ("旧配置离线复现'幽灵刹车把队列压停'：最小车速 < 1 m/s",
         old['min_v'] < 1.0),
        ("新配置：无幽灵刹车（最小净间隙 > 0，即不发生'后车碰前车'）",
         new['min_clear'] > 0.0 and not new['collision']),
        ("新配置：队列稳定（最小车速 ≥ 0.97·稳态车速 %.2f m/s）" % new['v_spawn'],
         new['min_v'] >= 0.97 * new['v_spawn']),
        ("新配置：设计间隙落在论文式62 的奖励区间（3.5~5.0 m）",
         3.5 <= new['clear_gap'] <= 5.0),
        ("新配置：稳态车速 < 空路期望速度（论文的'低速高密度'）",
         new['v_spawn'] < new['v_free']),
        ("新配置：队列不过度压缩（最小中心距 > 0.95·设计中心距）",
         new['min_center'] > 0.95 * (new['clear_gap'] + 3.6)),
        ("★让行能张开间隙：让行车辆前方的中心距明显大于平衡值（+1 m 以上）",
         new_y['gap_ahead_of_yield'] is not None
         and new_y['gap_ahead_of_yield'] > eq6 + 1.0),
        ("【P1-d】让行幅度：新目标(0.3×巡航)张开窗口 > 旧目标(3.0 m/s)",
         _w1 > _w_old),
        ("【P1-d】旧目标单辆车窗口(%.1f m) 小于 ego 左转所需距离(%.1f m) → 以前窗口偏紧"
         % (_w_old, t_clear_ego * 5.0),
         _w_old < t_clear_ego * 5.0),
        ("【P1-d】新目标单辆车窗口(%.1f m) ≥ ego 左转所需距离(%.1f m)"
         % (_w1, t_clear_ego * 5.0),
         _w1 >= t_clear_ego * 5.0),
        ("【P1-d】让行编队(k=1)窗口(%.1f m ≈ %.1f s) 进一步大于单辆车窗口"
         % (_w2, _w2 / max(new_y_platoon['v_spawn'], 0.1)),
         _w2 > _w1),
        ("车流覆盖时长(%.0f s) ≥ ego 清空冲突点时间(%.1f s)" % (cover_s, t_clear_ego),
         cover_s >= t_clear_ego),
    ]:
        print("  %s -> %s" % (name, "PASS" if cond else "FAIL"))
        ok &= bool(cond)
    print("-" * 60)
    print("阶段 4：%s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


# ============================================================
# main：注册所有阶段检查
# ============================================================
def main():
    try:
        results = [check_phase0(), check_phase1(), check_phase2(),
                   check_phase3(), check_phase4(), check_phase5()]
    except ImportError as e:
        print("离线对拍中止：缺少依赖 (%s)" % e)
        print("请用装有 numpy /（可选 casadi）的 Python 运行本脚本，"
              "例如训练用的 conda 环境：<env>/bin/python offline_check.py")
        return 2
    print("=" * 60)
    if all(results):
        print("离线对拍：全部阶段 PASS，可以拷贝到 CARLA 机器")
        return 0
    print("离线对拍：存在 FAIL，禁止拷贝")
    return 1


if __name__ == "__main__":
    sys.exit(main())
