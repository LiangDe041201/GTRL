#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""落地验收脚本 —— 只认数，不认代码状态（PLAN §37.6）。

用法：
    python acceptance_check.py <run_dir>

判据（用户口径，全部从**运行时日志**判，不接受代码审查结论）：
  V1 动作分布：12 个动作**每一个样本数 > 0**（任何一个为 0 ⇒ 没落地）
  V2 纵向 J  ：所有决策里纵向动作**不恒定**（恒定 ⇒ 没落地二维）
  V3 式(24)  ：不同动作的 U_comfort **不相同**（全相同 ⇒ 舒适项没接）
  V4 ④屏蔽  ：**纵向与横向都屏**（只屏纵向 ⇒ 没扩 2D）
  V5 元判据  ：数据必须来自真实运行的日志（"已接线、默认关""函数已写、未 import" 一律不算）
  V6 无静默异常：`info_err`/`causal_err` 必须为空（本会话已 4 次栽在 except: pass）
  V8 等待位不变量：`clamp_stopped=1` 且 `wait_standoff<=0` 的帧数须为 0，
     且碰撞帧的 `wait_standoff` 中位须 > 0（车头不得停在交叉带内，见 §51.3）
  W6 奖励与安全相关且**分离度足够**：高奖励半区碰撞率 ≤ 低奖励半区 × 0.6，
     且成功率方向一致（仅"没有反向"不足以证明奖励能区分好坏，见 §48 收紧）
  W7 奖励峰值不在低速：奖励最高 1% 帧的速度中位不得远低于全体（防"停下来刷分"）
  W8 配对变更不产生尖峰：对手换车帧的 |reward| 不得是尖峰（防"换车刷分"）

退出码 0 = 全部通过；1 = 有判据未通过。
"""
import csv
import math
import os
import sys
from collections import Counter, defaultdict

N_ACTIONS = 12
N_LAT = 3
#: 式(24) 的权重与阈值（与 cournot_game.build_payoff_matrix 的默认一致）
W_COMF, J_TH, STEER_TH = 0.3, 0.5, 0.3


def _f(row, key):
    v = row.get(key)
    if v in (None, '', 'None'):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _a2v(a):
    """动作 -> 纵向速度档（与 LaneTrajectoryPlanner.action_speed 的 2d 口径一致）。"""
    try:
        i = int(float(a))
    except (TypeError, ValueError):
        return None
    return [0.0, 0.0, 0.0, 2.0, 2.0, 2.0, 4.0, 4.0, 4.0, 6.0, 6.0, 6.0][i] if 0 <= i < 12 else None


def _a2lat(a):
    try:
        i = int(float(a))
    except (TypeError, ValueError):
        return None
    return [-1.5, 0.0, 1.5][i % N_LAT] if 0 <= i < 12 else None


def check(run_dir):
    csv_path = os.path.join(run_dir, 'interaction_ego.csv')
    if not os.path.isfile(csv_path):
        print('❌ 找不到 %s（V5：必须来自真实运行的日志）' % csv_path)
        return 1, {}
    rows = [r for r in csv.DictReader(open(csv_path))]
    if not rows:
        print('❌ 日志为空')
        return 1, {}
    n = len(rows)
    res, info = {}, {}

    # ---------- V1 动作分布：12 个动作都要有样本 ----------
    acts = Counter()
    for r in rows:
        a = _f(r, 'action')
        if a is not None:
            acts[int(a)] += 1
    missing = [a for a in range(N_ACTIONS) if acts.get(a, 0) == 0]
    res['V1 动作分布(12 个都有样本)'] = (not missing)
    info['V1'] = '帧=%d，出现动作 %d/%d；缺: %s' % (n, len(acts), N_ACTIONS, missing or '无')
    info['V1_dist'] = {a: acts.get(a, 0) for a in range(N_ACTIONS)}

    # ---------- V2 纵向 J 不恒定 ----------
    vs = [_a2v(_f(r, 'action')) for r in rows]
    vs = [v for v in vs if v is not None]
    uniq_v = sorted(set(vs))
    even = Counter(vs)
    # 要求：纵向档至少 2 种**且**每种都占了非平凡比例（>2%），否则等于没落地
    nontrivial = [v for v in uniq_v if even[v] > 0.02 * max(len(vs), 1)]
    res['V2 纵向 J 不恒定'] = (len(nontrivial) >= 2)
    info['V2'] = ('纵向档取值=%s；占比>2%% 的档=%s（需 ≥2 种）'
                  % (uniq_v, nontrivial))
    info['V2_dist'] = {v: even[v] for v in uniq_v}

    # ---------- V3 式(24) 舒适项随动作变化 ----------
    by_act = defaultdict(list)
    for r in rows:
        a = _f(r, 'action')
        cj, cs = _f(r, 'comfort_j'), _f(r, 'comfort_s')
        if a is None or cj is None or cs is None:
            continue
        # U_comfort = −w·[(J−J_TH)² + (ψ−ψ_TH)²]
        by_act[int(a)].append(-W_COMF * ((cj - J_TH) ** 2 + (cs - STEER_TH) ** 2))
    med = {}
    for a, us in by_act.items():
        us = sorted(us)
        med[a] = us[len(us) // 2]
    distinct = len({round(v, 6) for v in med.values()})
    res['V3 式(24) 舒适项随动作不同'] = (distinct >= 2)
    info['V3'] = '有舒适项数据的动作数=%d，其中位数去重后=%d 种（需 ≥2）' % (len(med), distinct)
    info['V3_med'] = {a: round(v, 4) for a, v in sorted(med.items())}

    # ---------- V4 ④屏蔽 纵向+横向都屏 ----------
    lat_screened_frames = sum(1 for r in rows if (_f(r, 'lat_screened') or 0) > 0)
    lat_mask_with_zero = sum(1 for r in rows
                             if (r.get('lat_mask') or '') and '0' in str(r.get('lat_mask')))
    shield_frames = sum(1 for r in rows if (r.get('decision_src') or '') == 'shield')
    # 横向屏蔽必须真的发生过（有帧屏蔽了横向档），否则"只屏纵向"
    res['V4 ④屏蔽含横向分量'] = (lat_screened_frames > 0 and lat_mask_with_zero > 0)
    info['V4'] = ('shield 帧=%d；横向被屏的帧=%d；lat_mask 含 0 的帧=%d（两者都需 >0）'
                  % (shield_frames, lat_screened_frames, lat_mask_with_zero))

    # ---------- V5 元判据：检查这些列是否真的来自运行期 ----------
    have_cols = all(k in rows[0] for k in
                    ('comfort_j', 'comfort_s', 'lat_mask', 'lat_screened', 'v_ref'))
    res['V5 运行时日志含验收列'] = have_cols
    info['V5'] = '日志列齐全=%s' % have_cols

    # ---------- W6 奖励与安全**相关**（奖励必须能区分好坏回合）----------
    import os as _os
    rec_path = _os.path.join(run_dir, 'record_turn.txt')
    coll_by_ep, succ_by_ep, rw_by_ep = {}, {}, {}
    # ⚠️【读数修正 2026-09-23】`record_turn.txt` 每行是**累计量**：
    #     tasks, cases, stuck_num, collision_num, stuck_rate, collision_rate, pass_rate
    #   其中各 `*_rate` 是"到该回合为止的累计率"，**不是该回合的结果**。
    #   旧实现直接拿 `c[5]/c[6]` 当每回合标签 ⇒ W6 比的是累计率（混淆统计）。
    #   正确做法：由 `*_num` 的**增量**导出每回合三分类，并校验增量恰好和为 1。
    _rec_ok = True
    if _os.path.isfile(rec_path):
        _prev = [0, 0, 0]   # stuck_num, collision_num, success_num 的累计
        for line in open(rec_path).read().strip().split('\n'):
            c = [x.strip() for x in line.split(',')]
            if len(c) < 7:
                continue
            try:
                _ep = c[0]
                _stuck = int(float(c[2])); _coll = int(float(c[3])); _cases = int(float(c[1]))
                _d_stuck = _stuck - _prev[0]
                _d_coll = _coll - _prev[1]
                _succ_cum = _cases - _stuck - _coll
                _d_succ = _succ_cum - _prev[2]
                _prev = [_stuck, _coll, _succ_cum]
                if _d_stuck + _d_coll + _d_succ != 1 or min(_d_stuck, _d_coll, _d_succ) < 0:
                    _rec_ok = False
                coll_by_ep[_ep] = 1.0 if _d_coll > 0 else 0.0
                succ_by_ep[_ep] = 1.0 if _d_succ > 0 else 0.0
            except ValueError:
                _rec_ok = False
    for r in rows:
        rw = _f(r, 'reward')
        if rw is not None:
            k = r['episode']
            rw_by_ep[k] = rw_by_ep.get(k, 0.0) + rw
    common = [k for k in coll_by_ep if k in rw_by_ep]
    w6_ok, w6_msg = True, '累计奖励/碰撞率：'
    if len(common) >= 8:
        _sorted = sorted(rw_by_ep[j] for j in common)
        _med = _sorted[len(common)//2]
        hi = [k for k in common if rw_by_ep[k] >= _med]
        lo = [k for k in common if k not in hi]
        ch = sum(coll_by_ep[k] for k in hi)/max(len(hi),1)
        cl = sum(coll_by_ep[k] for k in lo)/max(len(lo),1)
        sh = sum(succ_by_ep[k] for k in hi)/max(len(hi),1)
        sl = sum(succ_by_ep[k] for k in lo)/max(len(lo),1)
        # 【§48 收紧】旧判据只要求 `ch <= cl`，而实测"9pp 差距"也能过 ——
        #  那**不足以**证明奖励能区分好坏：它只说明奖励没反向。
        #  真正有意义的是**分离度**：高奖励半区的碰撞率必须显著低于低奖励半区
        #  （阈值 60%，即至少 40% 的相对改善），并且不能靠"两边都撞"凑出来。
        #  同时要求高奖励半区的**成功率**不低于低奖励半区（方向一致性）。
        _sep = (cl <= 1e-9) or (ch <= 0.6 * cl)
        _dir = (sh >= sl - 1e-9)
        _informative = (cl > 1e-9) or (sh > 1e-9)   # 低奖励半区不能全 0（否则无信息）
        w6_ok = bool(_sep and _dir and _informative and _rec_ok)
        # 【§52 消息修复】必须把**每一条**子判据的结果都打出来。
        #   旧消息只打了分离度与方向两条，于是在"两条都 PASS 却整体 FAIL"时
        #   （真实原因是第三条 `_informative`：两半区都 0% 碰撞且 0% 成功 ⇒ 奖励无信息）
        #   报错信息完全无法定位 —— 这是我实测踩到的。
        w6_msg += ('高奖励半区 碰撞=%.2f/成功=%.2f vs 低奖励半区 碰撞=%.2f/成功=%.2f；'
                   '[1]分离度(高奖励碰撞≤低奖励×0.6)→%s  [2]成功率方向一致→%s  '
                   '[3]有信息量(低奖励半区不全 0)→%s  [4]record_turn 增量校验→%s'
                   % (ch, sh, cl, sl,
                      'PASS' if _sep else 'FAIL', 'PASS' if _dir else 'FAIL',
                      'PASS' if _informative else 'FAIL（两半区碰撞与成功全为 0 ⇒ 奖励无可区分信息）',
                      'PASS' if _rec_ok else 'FAIL'))
    else:
        w6_ok, w6_msg = False, '回合数不足（需 ≥8 个有奖励列的回合）或无奖励列，无法验证'
    if not _rec_ok:
        # 增量校验失败 ⇒ record_turn.txt 的读数语义与预期不符 ⇒ 绝不放过
        w6_ok = False
        w6_msg += '；⚠️ record_turn.txt 增量校验失败（每回合三分类增量之和≠1）⇒ FAIL'
    res['W6 奖励与安全相关且分离度足够(≤0.6×)'] = w6_ok
    info['W6'] = w6_msg

    # ---------- W7 奖励峰值**不得**集中在低速（否则存在"停下来刷分"通道）----------
    pairs = [(x, v) for x, v in
             ((_f(r, 'reward'), _f(r, 'ego_v')) for r in rows)
             if x is not None and v is not None]
    w7_ok, w7_msg = False, '奖励列缺失'
    if pairs:
        pairs.sort(key=lambda p: -p[0])
        top = pairs[:max(1, len(pairs)//100)]              # 奖励最高 1%
        vs = sorted(v for _, v in top)
        med = vs[len(vs)//2]
        allv = sorted(v for _, v in pairs)
        allmed = allv[len(allv)//2]
        # 最高奖励帧的速度中位，必须**不低于**全体中位的一半（否则峰值在"停着"处）
        w7_ok = (med >= 0.5 * max(allmed, 0.1))
        w7_msg = '奖励最高 1%% 帧的 ego_v 中位=%.2f vs 全体中位=%.2f（前者不得远低于后者）' % (med, allmed)
    res['W7 奖励峰值不在低速（无"停下来刷分"通道）'] = w7_ok
    info['W7'] = w7_msg

    # ---------- W8 分类/配对变更帧**不得**产生奖励尖峰 ----------
    w8_ok, w8_msg = True, '无 rv_id 列或无法验证'
    if 'rv_id' in rows[0]:
        prev, sw_rewards, oth_rewards = None, [], []
        for r in rows:
            rid = (r.get('rv_id') or '')
            rw = _f(r, 'reward')
            if rw is None:
                prev = rid
                continue
            if prev is not None and rid != prev:
                sw_rewards.append(abs(rw))
            else:
                oth_rewards.append(abs(rw))
            prev = rid
        if sw_rewards and oth_rewards:
            sw_rewards.sort(); oth_rewards.sort()
            sw_med = sw_rewards[len(sw_rewards)//2]
            oth_p99 = oth_rewards[min(len(oth_rewards)-1, int(0.99*len(oth_rewards)))]
            w8_ok = (sw_med <= max(oth_p99, 1.0))
            w8_msg = ('配对切换帧 |reward| 中位=%.2f vs 非切换帧 |reward| P99=%.2f（切换帧不得是尖峰）'
                      % (sw_med, oth_p99))
    res['W8 配对变更帧不产生奖励尖峰'] = w8_ok
    info['W8'] = w8_msg

    # ---------- V6 无被静默吞掉的异常 ----------
    #   本会话已 4 次栽在 `except: pass` 上（④屏蔽 TypeError 让屏蔽层假死 280 次、
    #   window_causal 只 print、信息集填充全空、`_conf` NameError 让式(62-68)
    #   整段静默失效 1117/1117 帧）。任何被吞掉的异常都必须让验收**失败**。
    _has_cols = ('info_err' in rows[0]) and ('causal_err' in rows[0])
    bad_err = [(r.get('info_err') or '') for r in rows] + [(r.get('causal_err') or '') for r in rows]
    bad_err = [e for e in bad_err if e]
    # 列缺失 ⇒ **FAIL**（不能因为"读不到"就判通过 —— 那正是 V5 要禁止的）
    res['V6 无被静默吞掉的异常'] = (len(bad_err) == 0) and _has_cols
    info['V6'] = (('列缺失（info_err/causal_err），无法验证 ⇒ FAIL' if not _has_cols else
                   '异常非空帧数=%d' % len(bad_err)) +
                  (('；样例: %s' % bad_err[0]) if bad_err else ''))

    # ---------- V7 §48 客观奖励项真的在跑（不是"已接线、默认关"） ----------
    #   用户口径：「函数已写、环境未 import」不算落地。因此这里要求
    #   (1) 新列必须在运行时**存在**（缺列 ⇒ FAIL，绝不放行）；
    #   (2) 三项分量都必须有**非零帧**（全零 ⇒ 等于没接）；
    #   (3) 三项分量都必须有**足够多的不同取值**（常数 ⇒ 等于没接，是死信号）；
    #   (4) `obj_err` 必须为空（异常被吞 ⇒ FAIL，同 V6 纪律）。
    _obj_cols = ['r_safe_obj', 'r_prox_obj', 'r_pet_obj', 'pbrs_shaping', 'obj_err']
    _miss_obj = [c for c in _obj_cols if c not in rows[0]]
    _KEY_V7 = 'V7 客观奖励三项运行时有非零/非常数样本'
    if _miss_obj:
        # 表头都缺 ⇒ logger 没改 / import 断了 ⇒ **接线坏了**，FAIL
        res[_KEY_V7] = False
        info['V7'] = '列缺失 %s ⇒ FAIL（接线坏了，无法验证落地）' % _miss_obj
    elif not any((r.get('r_safe_obj') or '') not in ('', 'None') for r in rows):
        # 表头在、值全空、且 obj_err 也全空 ⇒ `DSH_OBJ_REWARD=0` 的**按设计消融**，
        #   不是"接线坏了"。这种情况标 N/A 并从总判定中排除（消融臂不应被误报）。
        #   ⚠️ 但若 obj_err 非空，说明开了却每帧抛异常 ⇒ 仍属 FAIL（下面 else 分支处理）。
        _any_err = any(r.get('obj_err') for r in rows)
        if _any_err:
            res[_KEY_V7] = False
            info['V7'] = '客观项值全空但 obj_err 非空 ⇒ FAIL（开了但每帧抛异常）'
        else:
            res[_KEY_V7] = None      # None = N/A，不计入 ok_all
            info['V7'] = 'N/A（本臂 DSH_OBJ_REWARD=0，按设计关闭；接线由表头存在性证明）'
    else:
        _det = {}
        _allok = True
        for c in ('r_safe_obj', 'r_prox_obj', 'r_pet_obj'):
            _v = [float(r[c]) for r in rows if (r.get(c) or '') not in ('', 'None')]
            _nz = sum(1 for x in _v if abs(x) > 1e-9)
            _nd = len(set(round(x, 6) for x in _v))
            if _nz == 0 or _nd < 10:
                _allok = False
            _det[c] = '非零=%d/%d 取值种数=%d' % (_nz, len(_v), _nd)
        _oerr = [r.get('obj_err') for r in rows if r.get('obj_err')]
        if _oerr:
            _allok = False
        res['V7 客观奖励三项运行时有非零/非常数样本'] = _allok
        info['V7'] = ('；'.join('%s(%s)' % (k, v) for k, v in _det.items()) +
                      '；obj_err 非空帧=%d' % len(_oerr) +
                      (('；样例: %s' % _oerr[0]) if _oerr else ''))

    # ---------- V8 【§51.3】等待位不变量：车头不得停在交叉带内 ----------
    #   为什么必须有这条：这个 bug（车头停在带内 ⇒ 被过路车侧刮）**此前没有任何列能看见**，
    #   是靠事后把 collision.csv 与 ego.csv 逐帧对齐才挖出来的。实证（3 seed × 20 回合）：
    #   32/32 碰撞帧 `clamp_stopped=1` 且 `wait_standoff <= 0`；`committed=1` 出现 0 帧。
    #   判据（三条必须同时成立）：
    #     (1) `wait_overshoot_num` 列必须存在（缺列 ⇒ FAIL，不允许"读不到就放过"）
    #     (2) `clamp_stopped=1` 且 `wait_standoff <= 0` 的帧数必须为 0
    #         （= 钳位在"车头已进带"的状态下仍在生效 ⇒ 等待位纪律失效）
    #     (3) 碰撞帧的 `wait_standoff` 中位必须 > 0（被撞时车头必须在带外）
    _KEY_V8 = 'V8 等待位不变量(wait_standoff>0 或未钳位)'
    if 'wait_overshoot_num' not in rows[0]:
        res[_KEY_V8] = False
        info['V8'] = '列缺失 wait_overshoot_num ⇒ FAIL（接线坏了，无法验证）'
    else:
        _bad = 0
        for r in rows:
            _cs = _f(r, 'clamp_stopped')
            _sd = _f(r, 'wait_standoff')
            if _cs is not None and int(_cs) == 1 and _sd is not None and _sd <= 0.0:
                _bad += 1
        # 碰撞帧的 standoff
        _col_path = _os.path.join(run_dir, 'interaction_collision.csv')
        _cst = []
        if _os.path.isfile(_col_path):
            _ego_idx = {}
            for r in rows:
                _ego_idx[(r.get('episode'), r.get('frame'))] = r
            for c in csv.DictReader(open(_col_path)):
                r = _ego_idx.get((c.get('episode'), c.get('frame')))
                if r is None:
                    continue
                _sd = _f(r, 'wait_standoff')
                if _sd is not None:
                    _cst.append(_sd)
        _med = (sorted(_cst)[len(_cst) // 2] if _cst else None)
        _ok3 = (_med is None) or (_med > 0.0)      # 无碰撞记录 ⇒ 不算违反
        res[_KEY_V8] = bool(_bad == 0 and _ok3)
        info['V8'] = ('钳位且车头进带的帧=%d（须为 0）；碰撞帧 wait_standoff 中位=%s（须>0，n=%d）'
                      % (_bad, ('None' if _med is None else '%.3f' % _med), len(_cst)))

    # ---------- 输出 ----------
    print('=' * 72)
    print('落地验收：%s' % run_dir)
    print('=' * 72)
    ok_all = True
    # 【§51.3 工具修复】总判定与明细打印**共用同一个列表**。
    #   bug：此前总判定列表是 (V1..V6, W6..W8)，而 V7/V8 只被计算和打印、
    #   **从未计入 `ok_all`** ⇒ 两个检查器是装饰性的，打印"全部通过 ✅"时
    #   并不包含它们。用单一列表（`CHECKS`）驱动两处，从结构上杜绝再次分叉。
    CHECKS = ['V1 动作分布(12 个都有样本)', 'V2 纵向 J 不恒定',
              'V3 式(24) 舒适项随动作不同', 'V4 ④屏蔽含横向分量',
              'V5 运行时日志含验收列', 'V6 无被静默吞掉的异常',
              'V7 客观奖励三项运行时有非零/非常数样本',
              'V8 等待位不变量(wait_standoff>0 或未钳位)',
              'W6 奖励与安全相关且分离度足够(≤0.6×)',
              'W7 奖励峰值不在低速（无"停下来刷分"通道）',
              'W8 配对变更帧不产生奖励尖峰']
    _missing = [k for k in CHECKS if k not in res]
    if _missing:
        # 列表里有、但没人计算 ⇒ 这是**接线错误**，必须显形而不是静默跳过
        print('  ⚠️ 判定列表含未计算的检查项: %s' % _missing)
        ok_all = False
    for k in CHECKS:
        v = res.get(k)
        if v is None:
            print('  %-34s -> N/A（本臂按设计关闭，不计入总判定）' % k)
            continue
        ok_all &= bool(v)
        print('  %-34s -> %s' % (k, 'PASS' if v else 'FAIL'))
    print('-' * 72)
    for k in ('V1', 'V1_dist', 'V2', 'V2_dist', 'V3', 'V3_med', 'V4', 'V5', 'V6',
              'V7', 'V8', 'W6', 'W7', 'W8'):
        print('  %-8s %s' % (k, info.get(k)))
    print('-' * 72)
    print('结论：%s' % ('全部通过 ✅' if ok_all else '**未通过** ❌（按用户口径 = 没落地）'))
    return (0 if ok_all else 1), info


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    rc, _ = check(sys.argv[1])
    sys.exit(rc)
