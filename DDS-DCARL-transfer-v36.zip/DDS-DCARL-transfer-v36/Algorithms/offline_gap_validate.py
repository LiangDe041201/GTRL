#!/usr/bin/env python3
"""【§59 离线验证】占用窗调度判据 vs 标量阈值判据 —— 用已有日志重建"真实到达序列"。

【为什么要这个脚本】
§54–§58 的结论是：现用的碰撞预测（`lcttc`/`thw` 标量阈值）**不是**一个可用于
"授权进入"的判据 —— 它的 PPV 只有 7%（基准率 3.65%），且 `min` 聚合会丢掉
"对每一辆车分别做时序合取"这一结构。本脚本**不依赖 CARLA**，直接用日志里的
车辆真实位置轨迹重建到达时刻，检验下面的问题：

  Q1 到达时刻预测准不准？      预测 `rv_t_veh` vs **真实**到达（由后续帧的实际位置求得）
  Q2 授权侧：现在被放行的决定，按真实到达序列是否本来就该拒？（碰撞的直接原因）
  Q3 拒绝侧：现在被拒的决定，按真实到达序列是否本来存在可行窗口？（卡死的直接原因）
  Q4 若改用"最早可行窗口"调度判据，两侧各能改善多少？

【方法：真实到达怎么来】
交叉车流沿 −x 流动、单车排（实测 98% 恰在 y=−138）。对每个 `rv_id` 跟踪其
`rv_x` 时间序列，找它**实际跨过**冲突点 x 的那一帧 ⇒ 该车的真实到达时刻。
从帧 f 看它，真实剩余到达时间 = (cross_frame − f) × dt。这是**数据里的事实**，
不是模型外推，因此可用作判据的"标准答案"。

用法：
  python offline_gap_validate.py expS91_FW_ON expS88_CX4 ...
"""
import collections
import csv
import math
import os
import statistics as st
import sys

DT = 0.05
#: 冲突点 x：实测自车左转路径进入车流带的 x（§55，`band_entry_x`=4.05）
CONFLICT_X = float(os.environ.get('OV_CONFLICT_X', '4.0'))
#: 车辆自身占用冲突区的时间兜底（车身长/车速）；与 boundary_safety 的默认一致
VEH_CLEAR = float(os.environ.get('OV_VEH_CLEAR', '1.0'))


def _f(row, col):
    v = row.get(col)
    if v in (None, '', 'None'):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _rows(path):
    if not os.path.isfile(path):
        return []
    with open(path) as fh:
        return list(csv.DictReader(fh))


def load_run(run_dir):
    """返回 (ego_by_key, veh_traj, collisions)。"""
    ego, veh, coll = {}, collections.defaultdict(list), []
    for r in _rows(os.path.join(run_dir, 'interaction_ego.csv')):
        ego[(r['episode'], int(r['frame']))] = r
    for r in _rows(os.path.join(run_dir, 'interaction_rv.csv')):
        x = _f(r, 'rv_x')
        if x is None:
            continue
        veh[(r['episode'], r['rv_id'])].append(
            (int(r['frame']), x, _f(r, 'rv_v'), _f(r, 'rv_t_veh')))
    for c in _rows(os.path.join(run_dir, 'interaction_collision.csv')):
        if c.get('episode') not in (None, '', 'episode'):
            coll.append((c['episode'], int(c['frame'])))
    for k in veh:
        veh[k].sort()
    return ego, veh, coll


def true_crossing(series):
    """该车实际跨过 CONFLICT_X 的帧号（取首次 x <= CONFLICT_X）。无则 None。"""
    for fr, x, _v, _t in series:
        if x <= CONFLICT_X:
            return fr
    return None


#: 交叉车流 IDM 稳态巡航速度（实测日志：8.6 m 中心距 → 4.41 m/s）
_CRUISE = float(os.environ.get('OV_CRUISE', '4.41'))
#: 单车让行概率（traffic manager 用 Bernoulli p=0.50 决定 yield/rush）
_P_YIELD = float(os.environ.get('OV_P_YIELD', '0.5'))


def _no_overlap(t_list, t0, t1):
    """占用窗 [t0,t1] 内无到达，且窗前那辆已清空 ⇒ 可安全进入。"""
    for tv in t_list:
        if t0 <= tv <= t1:
            return False
    before = [tv for tv in t_list if tv < t0]
    if before and (max(before) + VEH_CLEAR > t0):
        return False
    return True


def analyze(run_dir, verbose=True):
    ego, veh, coll = load_run(run_dir)
    if not ego:
        print('  [%s] 无数据' % run_dir)
        return None
    cross = {}
    for (ep, vid), series in veh.items():
        cf = true_crossing(series)
        if cf is not None:
            cross[(ep, vid)] = cf
    coll_set = set(coll)

    # ---------- Q1 到达时刻预测误差 ----------
    err = []          # (horizon_pred, signed_error)  signed = true - predicted
    for (ep, vid), series in veh.items():
        cf = cross.get((ep, vid))
        if cf is None:
            continue
        for fr, x, _v, tpred in series:
            if tpred is None or not math.isfinite(tpred):
                continue
            if x <= CONFLICT_X:
                continue
            t_true = (cf - fr) * DT
            if t_true < 0:
                continue
            err.append((tpred, t_true - tpred))

    # ---------- Q2/Q3 决策帧上的判据对比 ----------
    # 决策帧定义：自车在等待位、慢速、尚未进带、有接近车
    by_ep = collections.defaultdict(list)
    for (ep, fr) in ego:
        by_ep[ep].append(fr)
    for ep in by_ep:
        by_ep[ep].sort()

    n_dec = 0
    # 标量判据（现状）：用日志里的 gap_ok / entry_granted
    scl_auth = scl_ref = 0
    # 调度判据（新）：用**真实**到达序列，检验"占用窗内无到达"是否成立
    sch_auth = 0
    # 交叉表（在两组都给出结论的帧上）
    both = 0
    scl_auth_sch_ref = 0      # 标量放行、调度拒绝（⇒ 标量错放）
    scl_ref_sch_auth = 0      # 标量拒绝、调度放行（⇒ 标量误拒）
    # 分类到"事后真的撞了"的帧
    auth_then_collide = 0
    auth_frames = 0
    ref_frames_with_window = 0
    for ep in by_ep:
        # 该回合每帧的"在册车辆 x"
        per_frame = collections.defaultdict(dict)
        for (e2, vid), series in veh.items():
            if e2 != ep:
                continue
            for fr, x, v, _t in series:
                per_frame[fr][vid] = x
        for fr in by_ep[ep]:
            r = ego[(ep, fr)]
            sd = _f(r, 'wait_standoff')
            v = _f(r, 'ego_v')
            teg, clr = _f(r, 't_ego_go'), _f(r, 'clr_go')
            if sd is None or v is None or teg is None or clr is None:
                continue
            if sd < 1.5 or v > 1.0:          # 必须在等待位、慢速
                continue
            # 该帧所有仍在冲突点以东（还没过）的车
            t_true = []
            for vid, x in per_frame.get(fr, {}).items():
                cf = cross.get((ep, vid))
                if cf is None or cf <= fr or x <= CONFLICT_X:
                    continue
                t_true.append((cf - fr) * DT)
            if not t_true:
                continue
            t_true.sort()
            n_dec += 1
            t0, t1 = teg, teg + clr
            # 调度判据：占用窗内不得有到达；且窗前那辆车必须已清空
            ok = True
            for tv in t_true:
                if t0 <= tv <= t1:
                    ok = False
                    break
            if ok:
                before = [tv for tv in t_true if tv < t0]
                if before and (max(before) + VEH_CLEAR > t0):
                    ok = False
            # 标量判据（现状）
            gap_ok = _f(r, 'gap_ok')
            granted = _f(r, 'entry_granted')
            if gap_ok is None:
                continue
            s_auth = bool(gap_ok >= 0.5)
            s_auth &= bool(granted >= 0.5) if granted is not None else True
            if s_auth:
                scl_auth += 1
                auth_frames += 1
            else:
                scl_ref += 1
                if ok:
                    ref_frames_with_window += 1
            if ok:
                sch_auth += 1
            both += 1
            if s_auth and not ok:
                scl_auth_sch_ref += 1
            if (not s_auth) and ok:
                scl_ref_sch_auth += 1
            # 该帧放行后 4 s 内是否真的撞了
            if s_auth:
                for k in range(0, int(4.0 / DT) + 1):
                    if (ep, fr + k) in coll_set:
                        auth_then_collide += 1
                        break

    # ---------- Q5 可实现的"最坏情况"判据（用日志的 rv_x/rv_v 现场重算） ----------
    #   这才是能真写进代码的版本：到达时刻按 max(v_now, 巡航) + IDM 加速度估算。
    try:
        from Planning_library.rv_decision import time_to_cover as _ttc
        from Planning_library.boundary_safety import worst_case_arrival_time as _wcat
    except Exception:
        _wcat = None
    impl_auth = impl_wrong_auth = impl_missed = 0
    if _wcat is not None:
        for ep in by_ep:
            per_frame = collections.defaultdict(dict)
            for (e2, vid), series in veh.items():
                if e2 != ep:
                    continue
                for fr, x, v, _t in series:
                    per_frame[fr][vid] = (x, v)
            for fr in by_ep[ep]:
                r = ego[(ep, fr)]
                sd = _f(r, 'wait_standoff'); v = _f(r, 'ego_v')
                teg, clr = _f(r, 't_ego_go'), _f(r, 'clr_go')
                if sd is None or v is None or teg is None or clr is None:
                    continue
                if sd < 1.5 or v > 1.0:
                    continue
                t_true, t_impl = [], []
                for vid, xv in per_frame.get(fr, {}).items():
                    x, vv = xv
                    if x <= CONFLICT_X:
                        continue
                    cf = cross.get((ep, vid))
                    if cf is None or cf <= fr:
                        continue
                    t_true.append((cf - fr) * DT)
                    tv = max(float(vv or 0.0), 0.1)
                    w = _wcat(_ttc, x - CONFLICT_X, tv, max(tv, _CRUISE), 2.0, 3.0)
                    if w is not None and math.isfinite(float(w)):
                        t_impl.append(float(w))
                if not t_true:
                    continue
                t0, t1 = teg, teg + clr
                ok_true = _no_overlap(t_true, t0, t1)
                ok_impl = _no_overlap(t_impl, t0, t1)
                if ok_impl:
                    impl_auth += 1
                    if not ok_true:
                        impl_wrong_auth += 1
                else:
                    if ok_true:
                        impl_missed += 1

    # ---------- Q6 机会约束判据（chance-constrained）扫描 ----------
    #   §58 的教训：对手会"因为我在等而让行，又突然恢复巡航"。所以到达时刻是**随机变量**：
    #     · 让行分支 (prob p_yield)：维持当前速度 ⇒ T_yield = d / max(v_now, 0.1)
    #     · 抢行分支 (prob 1-p_yield)：加速到巡航 ⇒ T_rush = worst_case_arrival_time(...)
    #   碰撞风险 = P(存在某辆车落在我的占用窗内)。授权 ⟺ 风险 ≤ δ。
    #   δ→0 退化为"一律最坏情况"(=Q5)；δ→1 退化为"永远放行"。
    #   扫描 δ 得到 (假放行率, 放行数) 的权衡曲线 ⇒ 判断该场景**是否可解**。
    sweep = {}
    if _wcat is not None:
        for delta in (0.0, 0.02, 0.05, 0.10, 0.20, 0.30, 0.50, 0.75, 1.0):
            sweep[delta] = {'auth': 0, 'wrong': 0, 'missed': 0}
        for ep in by_ep:
            per_frame = collections.defaultdict(dict)
            for (e2, vid), series in veh.items():
                if e2 != ep:
                    continue
                for fr, x, v, _t in series:
                    per_frame[fr][vid] = (x, v)
            for fr in by_ep[ep]:
                r = ego[(ep, fr)]
                sd = _f(r, 'wait_standoff'); v = _f(r, 'ego_v')
                teg, clr = _f(r, 't_ego_go'), _f(r, 'clr_go')
                if sd is None or v is None or teg is None or clr is None:
                    continue
                if sd < 1.5 or v > 1.0:
                    continue
                cand = []
                for vid, xv in per_frame.get(fr, {}).items():
                    x, vv = xv
                    if x <= CONFLICT_X:
                        continue
                    cf = cross.get((ep, vid))
                    if cf is None or cf <= fr:
                        continue
                    d = x - CONFLICT_X
                    vn = max(float(vv or 0.0), 0.1)
                    t_y = d / vn
                    tr = _wcat(_ttc, d, vn, max(vn, _CRUISE), 2.0, 3.0)
                    tr = float(tr) if (tr is not None and math.isfinite(float(tr))) else t_y
                    cand.append((t_y, tr))
                    if len(cand) >= 12:
                        break
                if not cand:
                    continue
                t_true = [(cross.get((ep, vid)) - fr) * DT
                          for vid in per_frame.get(fr, {}) if False]  # 占位，不用
                # 真实到达（用于判定该决定是否正确）
                tt = []
                for vid, xv in per_frame.get(fr, {}).items():
                    if xv[0] <= CONFLICT_X:
                        continue
                    cf = cross.get((ep, vid))
                    if cf is None or cf <= fr:
                        continue
                    tt.append((cf - fr) * DT)
                if not tt:
                    continue
                t0, t1 = teg, teg + clr
                ok_true = _no_overlap(tt, t0, t1)
                # 枚举抢行子集算风险
                k = len(cand)
                pg = _P_YIELD
                risk = 0.0
                for mask in range(1 << k):
                    pr = 1.0
                    for i in range(k):
                        pr *= ((1.0 - pg) if (mask >> i) & 1 else pg)
                    if pr <= 1e-12:
                        continue
                    arr = [cand[i][1] if (mask >> i) & 1 else cand[i][0] for i in range(k)]
                    if not _no_overlap(arr, t0, t1):
                        risk += pr
                for delta in sweep:
                    if risk <= delta + 1e-12:
                        sweep[delta]['auth'] += 1
                        if not ok_true:
                            sweep[delta]['wrong'] += 1
                    else:
                        if ok_true:
                            sweep[delta]['missed'] += 1

    out = {'run': run_dir, 'n_coll': len(coll), 'n_veh_ids': len(veh),
           'sweep': sweep,
           'impl_auth': impl_auth, 'impl_wrong_auth': impl_wrong_auth,
           'impl_missed': impl_missed,
           'n_dec': n_dec, 'scl_auth': scl_auth, 'scl_ref': scl_ref,
           'sch_auth': sch_auth, 'both': both,
           'auth_then_collide': auth_then_collide,
           'scl_auth_sch_ref': scl_auth_sch_ref,
           'scl_ref_sch_auth': scl_ref_sch_auth,
           'ref_with_window': ref_frames_with_window, 'err': err}
    if verbose:
        print('=' * 78)
        print('%s   碰撞=%d  车辆id数=%d  决策帧=%d' % (run_dir, len(coll), len(veh), n_dec))
        if err:
            e = [x[1] for x in err]
            late = sum(1 for x in e if x > 0)
            print('  Q1 到达预测误差 (真实−预测, >0 表示**预测偏晚**):')
            print('     n=%d  中位=%+.2f s  均值=%+.2f  P10=%+.2f  P90=%+.2f  |误差|>1s 占比=%.2f'
                  % (len(e), st.median(e), sum(e) / len(e),
                     sorted(e)[int(.1 * len(e))], sorted(e)[int(.9 * len(e))],
                     sum(1 for x in e if abs(x) > 1.0) / len(e)))
            print('     预测偏晚(危险方向)占比=%.3f   偏早占比=%.3f' % (late / len(e), 1 - late / len(e)))
        print('  Q2/Q3 决策帧对比:')
        print('     标量判据(现状): 放行=%d  拒绝=%d' % (scl_auth, scl_ref))
        print('     调度判据(真实到达): 放行=%d  (占决策帧 %.3f)' % (sch_auth, sch_auth / max(n_dec, 1)))
        print('     ★ 标量放行但调度拒绝(标量**错放**，直接对应碰撞) = %d' % scl_auth_sch_ref)
        print('     ★ 标量拒绝但调度放行(标量**误拒**，直接对应卡死) = %d' % scl_ref_sch_auth)
        print('     标量放行后 4s 内真的撞了 = %d / %d' % (auth_then_collide, auth_frames))
        print('  Q5 可实现版(最坏情况恢复巡航): 放行=%d' % impl_auth)
        print('     其中**按真实到达本不该放行** = %d  (假放行率=%.2f)'
              % (impl_wrong_auth, impl_wrong_auth / max(impl_auth, 1)))
        print('     调度判据放行却被它拒掉(错失窗口) = %d' % impl_missed)
    return out


def main():
    runs = sys.argv[1:]
    if not runs:
        print(__doc__)
        return 1
    print('冲突点 x = %.2f   车辆占用兜底 = %.2f s   dt = %.2f s' % (CONFLICT_X, VEH_CLEAR, DT))
    allerr = []
    agg = collections.Counter()
    agg_sweep = {}
    for r in runs:
        o = analyze(r)
        if o:
            allerr += o['err']
            if o.get('sweep'):
                for dl, v6 in o['sweep'].items():
                    if dl not in agg_sweep:
                        agg_sweep[dl] = collections.Counter()
                    agg_sweep[dl].update(v6)
            for k in ('n_coll', 'n_dec', 'scl_auth', 'scl_ref', 'sch_auth',
                      'scl_auth_sch_ref', 'scl_ref_sch_auth', 'auth_then_collide',
                      'impl_auth', 'impl_wrong_auth', 'impl_missed'):
                agg[k] += o[k]
    print()
    print('=' * 78)
    print('汇总（%d 个 run）' % len(runs))
    if allerr:
        e = [x[1] for x in allerr]
        late = sum(1 for x in e if x > 0)
        print('  Q1 到达预测: n=%d  中位=%+.2f s  |误差|>1s 占比=%.2f  预测偏晚占比=%.3f'
              % (len(e), st.median(e), sum(1 for x in e if abs(x) > 1.0) / len(e), late / len(e)))
    print('  决策帧=%d  标量放行=%d  标量拒绝=%d  调度放行=%d'
          % (agg['n_dec'], agg['scl_auth'], agg['scl_ref'], agg['sch_auth']))
    print('  ★ 标量错放=%d（碰撞侧）    ★ 标量误拒=%d（卡死侧）'
          % (agg['scl_auth_sch_ref'], agg['scl_ref_sch_auth']))
    print('  标量放行后 4s 内碰撞=%d / 放行帧 %d'
          % (agg['auth_then_collide'], agg['scl_auth']))
    print()
    print('  Q6 机会约束判据扫描（p_yield=%.2f）—— 判断场景可解性：' % _P_YIELD)
    print('     %-8s %8s %10s %10s %12s' % ('δ', '放行帧', '假放行', '假放行率', '错失窗口'))
    for dl in sorted(agg_sweep):
        c = agg_sweep[dl]
        print('     %-8.2f %8d %10d %10.3f %12d'
              % (dl, c['auth'], c['wrong'], c['wrong'] / max(c['auth'], 1), c['missed']))
    if agg['impl_auth']:
        print('  Q5 可实现最坏情况判据: 放行=%d  假放行=%d (%.2f)  错失窗口=%d (占调度可放行的 %.2f)'
              % (agg['impl_auth'], agg['impl_wrong_auth'],
                 agg['impl_wrong_auth'] / max(agg['impl_auth'], 1),
                 agg['impl_missed'], agg['impl_missed'] / max(agg['sch_auth'], 1)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
