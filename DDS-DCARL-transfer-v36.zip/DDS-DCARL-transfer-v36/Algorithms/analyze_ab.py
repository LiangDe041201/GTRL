#!/usr/bin/env python3
"""A/B 两臂逐回合对照（读 record_turn.txt，无需 CARLA）。

`record_turn.txt` 每行 7 个字段（累计量）：
    task, case, stuck_num, collision_num, stuck_rate, collision_rate, pass_rate

用法：
    python analyze_ab.py expF_paper100 expJ_paper_p2_100
    python analyze_ab.py expF_paper100 expJ_paper_p2_100 --n 40

为什么需要这个脚本：`pass_rate`/`collision_rate` 都是**累计**值，直接看末行会被
开局几个回合主导（实测：某臂开局 11 连撞，末行通过率就被稀释到很低，看不出
"稳态其实已经一致"）。本脚本从累计量**还原逐回合结局**，并给出分区间统计。

注意：两臂必须用同一 `DSH_SEED` 且回合数可比，否则逐回合对齐没有意义。
"""
import argparse
import os
import sys
from collections import Counter


def load(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(',')]
            if len(parts) < 7:
                continue
            try:
                rows.append([float(x) for x in parts])
            except ValueError:
                continue
    return rows


def per_episode(rows):
    """从累计计数还原逐回合结局。

    某回合碰撞数相比上一回合增加 -> 'collision'；卡死数增加 -> 'stuck'；否则 'complete'。
    """
    out, pc, ps = [], 0, 0
    for r in rows:
        c, s = int(r[3]), int(r[2])
        if c > pc:
            out.append('collision')
        elif s > ps:
            out.append('stuck')
        else:
            out.append('complete')
        pc, ps = c, s
    return out


def summarize(tag, eps, ranges):
    n = len(eps)
    if n == 0:
        print(f"{tag}: 无数据")
        return
    c = Counter(eps)
    print(f"{tag}  （{n} 回合）")
    print(f"  逐回合：成功 {c['complete']:>3} ({c['complete'] / n * 100:5.1f}%)   "
          f"碰撞 {c['collision']:>3} ({c['collision'] / n * 100:5.1f}%)   "
          f"卡死 {c['stuck']:>3} ({c['stuck'] / n * 100:5.1f}%)")
    for lo, hi in ranges:
        sub = eps[lo:min(hi, n)]
        if not sub:
            continue
        cc = Counter(sub)
        m = len(sub)
        print(f"    第 {lo + 1:>3}-{min(hi, n):>3} 回合："
              f"成功 {cc['complete'] / m * 100:5.1f}%  碰撞 {cc['collision'] / m * 100:5.1f}%")


def main():
    ap = argparse.ArgumentParser(description="A/B 两臂逐回合对照")
    ap.add_argument('armA', help="对照臂运行目录（内含 record_turn.txt）")
    ap.add_argument('armB', help="实验臂运行目录")
    ap.add_argument('--n', type=int, default=0,
                    help="只比较前 N 回合（默认取两臂共同的最长长度）")
    args = ap.parse_args()

    def rp(d):
        return d if d.endswith('.txt') else os.path.join(d, 'record_turn.txt')

    A, B = load(rp(args.armA)), load(rp(args.armB))
    if not A or not B:
        print(f"读不到数据：A={len(A)} 行, B={len(B)} 行")
        print("检查路径下是否有 record_turn.txt")
        return 1
    n = args.n if args.n > 0 else min(len(A), len(B))
    A, B = A[:n], B[:n]
    print("=" * 74)
    print(f"A（对照）= {args.armA}")
    print(f"B（实验）= {args.armB}")
    print(f"比较长度 = {n} 回合")
    print("=" * 74)
    rng = [(i, i + 20) for i in range(0, n, 20)]
    ea, eb = per_episode(A), per_episode(B)
    summarize("A", ea, rng)
    print()
    summarize("B", eb, rng)
    print()
    # 逐回合并排（累计碰撞数 + 该回合结局）
    print("逐回合（A结局/A累计碰撞 | B结局/B累计碰撞）：")
    for i in range(n):
        if i % 10 == 0:
            print(f"  {'回合':>6}  {'A':>16}  {'B':>16}")
        print(f"  {i + 1:>6}  {ea[i]:>10}/{int(A[i][3]):<5}  {eb[i]:>10}/{int(B[i][3]):<5}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
