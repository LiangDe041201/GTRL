# -*- coding: utf-8 -*-
"""③ S5-③ 回归测试：④ 屏蔽层**只能**约束纵向，绝不能改横向。

背景（实测定位）：
  `speed` 动作空间里 index 0 = 纯刹车（横向固定 di=0），于是屏蔽层、
  规则兜底、探索候选保底共 6 处把字面量 `0` 当刹车用 —— 那时是对的。
  引入 `2d` 空间（`a = i_speed*3 + i_lat`，`i_lat=0` 是 `di=-1.5 m`）后
  这 6 处没跟着改，屏蔽层于是在**每个**屏蔽帧都下发"刹停 + 向左切 1.5 m"。
  expKK_2d_100 实测：`decision_src=='shield'` 的 5669 帧**全部** action 0，
  屏蔽帧占全部帧 46%。本测试锁死这个语义。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Agent.tools_dds.LaneTrajectoryPlanner import (      # noqa: E402
    ACTION_MODE, ACTION_SPEEDS, N_ACTIONS, BRAKE_ACTION, action_speed,
    action_lateral, shield_fallback_action, slowest_speed_actions)
from Planning_library.boundary_safety import boundary_shield_mask  # noqa: E402


def test_brake_action_is_neutral_lateral():
    """规范刹车动作的横向必须是中性（0 m），不能在 2d 下退化成 -1.5 m。"""
    assert ACTION_MODE == '2d', '本测试针对 2d 动作空间，当前 ACTION_MODE=%r' % ACTION_MODE
    assert abs(action_lateral(BRAKE_ACTION)) < 1e-9, \
        'BRAKE_ACTION=%d 的横向是 %.2f m，应当是 0' % (BRAKE_ACTION, action_lateral(BRAKE_ACTION))
    assert abs(action_speed(BRAKE_ACTION)) < 1e-9
    assert BRAKE_ACTION != 0, 'BRAKE_ACTION 不应等于 index 0（2d 下那是 di=-1.5）'


def test_slowest_speed_actions_is_a_full_layer():
    """'只允许最慢档' 是**一个速度层**（3 个横向），不是单个动作。"""
    layer = slowest_speed_actions()
    assert len(layer) == 3, layer
    assert all(abs(action_speed(a)) < 1e-9 for a in layer)
    laterals = sorted(action_lateral(a) for a in layer)
    assert laterals == [-1.5, 0.0, 1.5], laterals


def test_shield_mask_critical_tier_keeps_all_laterals():
    """临界档（lcttc<0.3s）只砍速度，不应把横向也砍到只剩一个。"""
    m = boundary_shield_mask(ACTION_SPEEDS, lcttc_rv=0.01, thw_boundary_rv=None,
                             committed=False, ego_v=6.0)
    assert sum(m) == 3, '临界档放行了 %d 个动作，应当是最慢速度层的 3 个' % sum(m)
    assert m == [ACTION_SPEEDS[a] <= 1e-9 for a in range(N_ACTIONS)], m


def test_shield_mask_first_tier_no_accel_keeps_all_laterals():
    """第一档（lcttc<0.8s）只允许不加速，同样按速度层放行。"""
    m = boundary_shield_mask(ACTION_SPEEDS, lcttc_rv=0.5, thw_boundary_rv=None,
                             committed=False, ego_v=4.0)
    for a in range(N_ACTIONS):
        assert m[a] == (ACTION_SPEEDS[a] <= 4.0 + 1e-9), (a, ACTION_SPEEDS[a], m[a])
    # 每个被允许的速度层，横向三种都必须齐全
    for v in sorted({ACTION_SPEEDS[a] for a in range(N_ACTIONS) if m[a]}):
        n = sum(1 for a in range(N_ACTIONS) if m[a] and abs(ACTION_SPEEDS[a] - v) < 1e-9)
        assert n == 3, '速度层 %.1f 只放行了 %d 个横向' % (v, n)


def test_fallback_preserves_requested_lateral():
    """兜底动作必须保留被拦下动作的横向分量。"""
    m = boundary_shield_mask(ACTION_SPEEDS, lcttc_rv=0.01, thw_boundary_rv=None,
                             committed=False, ego_v=6.0)
    allowed = [a for a in range(N_ACTIONS) if m[a]]
    for wanted in range(N_ACTIONS):
        fb = shield_fallback_action(wanted, allowed)
        assert abs(action_lateral(fb) - action_lateral(wanted)) < 1e-9, \
            '想选 action %d(di=%.1f) 被屏蔽后兜底成 %d(di=%.1f)' % (
                wanted, action_lateral(wanted), fb, action_lateral(fb))
        assert abs(action_speed(fb)) < 1e-9, '兜底动作必须是最慢档'


def test_fallback_never_returns_index0_for_neutral_requests():
    """回归点：旧实现恒返回 index 0。中性横向请求必须落到中性横向动作上。"""
    m = boundary_shield_mask(ACTION_SPEEDS, lcttc_rv=0.01, thw_boundary_rv=None,
                             committed=False, ego_v=6.0)
    allowed = [a for a in range(N_ACTIONS) if m[a]]
    for wanted in [1, 4, 7, 10]:            # 规则/中性横向动作
        fb = shield_fallback_action(wanted, allowed)
        assert fb == 1, '中性请求 %d 兜底成 %d，应为 1' % (wanted, fb)


def test_fallback_handles_empty_allowed():
    assert shield_fallback_action(5, []) == 5


if __name__ == '__main__':
    fns = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in fns:
        fn()
        print('ok  %s' % fn.__name__)
    print('\nALL %d PASSED' % len(fns))
