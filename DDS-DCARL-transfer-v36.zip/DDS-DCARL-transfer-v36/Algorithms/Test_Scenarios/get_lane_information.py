import carla
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import LineCollection

def get_lane_boundaries(waypoint, distance=50.0, interval=1.0):
    """
    获取车道的左右边界点
    :param waypoint: 车道中心线的路点
    :param distance: 向前查询的距离（米）
    :param interval: 采样间隔（米）
    :return: (left_boundary, right_boundary) 左右边界点列表
    """
    left_boundary = []
    right_boundary = []
    
    # 获取左侧边界点
    left_waypoint = waypoint.get_left_lane() if waypoint.lane_id > 0 else waypoint
    if left_waypoint:
        for i in range(int(distance/interval)):
            left_loc = left_waypoint.transform.location
            left_boundary.append(left_loc)
            # 可视化左侧边界点（红色）
            world.debug.draw_point(
                left_loc,
                size=0.1,
                color=carla.Color(255, 0, 0),  # 红色
                life_time=50.0
            )
            next_left = left_waypoint.next(interval)
            if next_left:
                left_waypoint = next_left[0]
            else:
                break
    
    # 获取右侧边界点
    right_waypoint = waypoint.get_right_lane() if waypoint.lane_id < 0 else waypoint
    if right_waypoint:
        for i in range(int(distance/interval)):
            right_loc = right_waypoint.transform.location
            right_boundary.append(right_loc)
            # 可视化右侧边界点（蓝色）
            world.debug.draw_point(
                right_loc,
                size=0.1,
                color=carla.Color(0, 0, 255),  # 蓝色
                life_time=50.0
            )
            next_right = right_waypoint.next(interval)
            if next_right:
                right_waypoint = next_right[0]
            else:
                break
    
    # 绘制车道边界线
    if left_boundary:
        world.debug.draw_arrow(
            left_boundary[0], left_boundary[-1],
            thickness=0.1, arrow_size=0.1,
            color=carla.Color(255, 0, 0),  # 红色
            life_time=50.0
        )
    
    if right_boundary:
        world.debug.draw_arrow(
            right_boundary[0], right_boundary[-1],
            thickness=0.1, arrow_size=0.1,
            color=carla.Color(0, 0, 255),  # 蓝色
            life_time=50.0
        )
    
    return left_boundary, right_boundary

def visualize_lane_centerline(world, waypoint, distance=200.0, interval=2.0):
    """
    在CARLA中可视化车道中心线
    
    参数:
        world: carla.World对象
        waypoint: 起始路点
        distance: 要追踪的距离(米)
        interval: 采样间隔(米)
    """
    # 收集所有路点
    waypoints = []
    current_waypoint = waypoint
    total_distance = 0.0

    # 清除之前的可视化
    world.debug.draw_point(waypoint.transform.location, size=0.2, color=carla.Color(0, 0, 0), life_time=0)
    
    while total_distance < distance:
        waypoints.append(current_waypoint)
        next_waypoints = current_waypoint.next(interval)
        if not next_waypoints:
            break
        
        # 绘制当前路点
        world.debug.draw_point(
            current_waypoint.transform.location,
            size=0.1,
            color=carla.Color(0, 0, 255),  # 蓝色表示中间点
            life_time=50.0
        )
        
        # 绘制到下一个路点的线
        next_waypoint = next_waypoints[0]
        world.debug.draw_line(
            current_waypoint.transform.location + carla.Location(z=0.5),
            next_waypoint.transform.location + carla.Location(z=0.5),
            thickness=0.1,
            color=carla.Color(255, 0, 0),  # 红色线条
            life_time=50.0
        )
        
        current_waypoint = next_waypoint
        total_distance += interval
    
    # 标记终点
    world.debug.draw_point(
        current_waypoint.transform.location,
        size=0.2,
        color=carla.Color(255, 0, 0),  # 红色表示终点
        life_time=50.0
    )
    
    print(f"\n已可视化 {len(waypoints)} 个路点，总距离: {total_distance:.1f} 米")

# 连接服务器
client = carla.Client('localhost', 2000)
world = client.get_world()

# 如果当前地图不是Town03,则加载Town03地图.
if world.get_map().name != 'Carla/Maps/Town03':    
    world = client.load_world('Town03') 

carla_map = world.get_map()

# 设置要查询的坐标点（x, y, z）
target_location = carla.Location(x=18, y=204, z=0.0)  # 修改为你的目标坐标

# 获取该位置最近的路点
waypoint = carla_map.get_waypoint(
    target_location,                    # 目标位置
    project_to_road=True,               # 如果点不在道路上，则投影到最近的道路
    lane_type=carla.LaneType.Driving    # 只查询可驾驶车道
)

if waypoint:
    print("\n" + "="*54)
    print(f"位置: {target_location}")
    print("="*54)
    print(f"道路ID: {waypoint.road_id}")
    print(f"车道ID: {waypoint.lane_id} ({'正向' if waypoint.lane_id > 0 else '反向'})")

    print(f"车道宽度: {waypoint.lane_width:.2f}米")
    print(f"车道类型: {waypoint.lane_type}")

    # print("\n车道边界信息:")
    # left_boundary, right_boundary = get_lane_boundaries(waypoint, distance=100.0, interval=1.0)
    # print(f"左侧边界点数量: {len(left_boundary)}")
    # print(f"右侧边界点数量: {len(right_boundary)}")
    
    # 车道标记信息
    left_marking = waypoint.left_lane_marking
    right_marking = waypoint.right_lane_marking
    print(f"左侧标线类型: {left_marking.type}")
    print(f"右侧标线类型: {right_marking.type}")
    print(f"变道规则: {waypoint.lane_change}")  # Both/Left/Right/None
    
    # 获取并显示路点在世界坐标系中的旋转
    rotation = waypoint.transform.rotation
    print(f"路点朝向: 俯仰={rotation.pitch:.1f}°, 横滚={rotation.roll:.1f}°, 偏航={rotation.yaw:.1f}°")
    
    # 可视化显示（在CARLA模拟器中）
    world.debug.draw_point(
        waypoint.transform.location, 
        size=0.1, 
        color=carla.Color(0, 255, 0),  # 绿色
        life_time=50.0  # 显示50秒
    )
    visualize_lane_centerline(world, waypoint)
else:
    print(f"\n在位置 {target_location} 没有找到可驾驶车道")