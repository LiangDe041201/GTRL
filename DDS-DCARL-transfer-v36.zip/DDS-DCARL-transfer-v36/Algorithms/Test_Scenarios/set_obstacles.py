import carla
import random
 
client = carla.Client('localhost', 2000)
client.set_timeout(10.0)  # Set timeout for client
carla_world = client.get_world()

# 如果当前地图不是Town03,则加载Town03地图.
if carla_world.get_map().name != 'Carla/Maps/Town03':    
    carla_world = client.load_world('Town03')

# 获取蓝图库
blueprint_library = carla_world.get_blueprint_library()

# 打印所有可用的静态道具蓝图
print("可用的静态道具蓝图:")
static_props = []
for bp in blueprint_library.filter('static.*'):
    print(f"- {bp.id}")
    static_props.append(bp)

# # 尝试找到合适的障碍物蓝图
# obstacle_bp = None
# for pattern in ['static.prop.*', 'static.*barrier*', 'static.*fence*', 'static.*construction*']:
#     props = list(blueprint_library.filter(pattern))
#     if props:
#         obstacle_bp = random.choice(props)
#         print(f"\n使用障碍物: {obstacle_bp.id}")
#         break

# if not obstacle_bp and static_props:
#     obstacle_bp = static_props[12]  # 使用第一个可用的静态道具
#     print(f"\n未找到围栏，使用默认障碍物: {obstacle_bp.id}")

# if not obstacle_bp:
#     raise Exception("未找到可用的障碍物蓝图！")

# 直接指定使用 streetbarrier
obstacle_bp = blueprint_library.find('static.prop.streetbarrier')
if not obstacle_bp:
    raise Exception("未找到 streetbarrier 障碍物！")
print(f"\n使用障碍物: {obstacle_bp.id}")

# 定义障碍物的位置 (x, y, z)
obstacle_locations = [
    carla.Transform(carla.Location(x=0, y=201, z=0), carla.Rotation(yaw=0)),
    carla.Transform(carla.Location(x=5, y=201, z=0), carla.Rotation(yaw=0)),
    carla.Transform(carla.Location(x=10, y=201, z=5), carla.Rotation(yaw=0)),
    carla.Transform(carla.Location(x=15, y=201, z=5), carla.Rotation(yaw=0))
]

# 生成障碍物
for i, transform in enumerate(obstacle_locations):
    try:
        obstacle = carla_world.spawn_actor(obstacle_bp, transform)
        print(f'生成障碍物 {i+1} 在位置 {transform.location} (类型: {obstacle_bp.id})')
    except Exception as e:
        print(f'无法生成障碍物 {i+1}: {str(e)}')

print('\n障碍物生成完成！')
print('如果位置不合适，请调整 obstacle_locations 中的坐标') 




# - static.prop.haybalelb             干草捆
# - static.prop.barbeque              烧烤架
# - static.prop.garbage04             垃圾桶
# - static.prop.maptable              地图桌子
# - static.prop.swingcouch            摇椅
# - static.prop.trampoline            弹跳床
# - static.prop.chainbarrierend       链式围栏末端
# - static.prop.creasedbox02          折叠箱
# - static.prop.plantpot01            绿植盆栽
# - static.prop.plantpot08            绿植盆栽
# - static.prop.box03                 箱子
# - static.prop.warningconstruction   警告标志
# - static.prop.barrel                桶
# - static.prop.streetbarrier         街道围栏
# - static.prop.garbage06             垃圾桶
# - static.prop.plantpot06            绿植盆栽
# - static.prop.busstop               停车站
# - static.prop.garbage01             垃圾桶
# - static.prop.trashcan03            垃圾桶
# - static.prop.pergola               阳台
# - static.prop.wateringcan           浇水壶
# - static.prop.garbage03             垃圾桶
# - static.prop.mailbox               邮箱
# - static.prop.bin                   垃圾桶
# - static.prop.fountain              喷泉
# - static.prop.guitarcase            吉他箱
# - static.prop.gnome                 小矮人
# - static.prop.garbage05             垃圾桶
# - static.prop.gardenlamp            花园灯
# - static.prop.plantpot03            绿植盆栽
# - static.prop.plantpot07            绿植盆栽
# - static.prop.shoppingtrolley       购物车
# - static.prop.trafficcone02         交通锥
# - static.prop.plantpot05            绿植盆栽
# - static.prop.mesh                  网格
# - static.prop.atm                   ATM机
# - static.prop.shoppingbag           购物袋
# - static.prop.shoppingcart          购物车
# - static.prop.plantpot04            绿植盆栽
# - static.prop.plastictable          塑料桌子
# - static.prop.streetsign04          交通标志
# - static.prop.streetsign            交通标志
# - static.prop.plasticbag            塑料袋
# - static.prop.trafficwarning        交通警告
# - static.prop.trashcan05            垃圾桶
# - static.prop.plasticchair          塑料椅子
# - static.prop.trashcan01            垃圾桶
# - static.prop.travelcase            行李箱
# - static.prop.trashbag              垃圾袋
# - static.prop.busstoplb             停车站
# - static.prop.calibrator            标定器
# - static.prop.brokentile03          破碎瓷砖
# - static.prop.briefcase             行李箱
# - static.prop.trafficcone01         交通锥
# - static.prop.vendingmachine        自动贩卖机
# - static.prop.garbage02             垃圾桶
# - static.prop.purse                 手提包
# - static.prop.motorhelmet           自行车头盔
# - static.prop.bench02               基础座椅
# - static.prop.dirtdebris03          破碎泥土
# - static.prop.platformgarbage01     平台垃圾桶
# - static.prop.kiosk_01              信息亭
# - static.prop.doghouse              狗窝
# - static.prop.swing                 摇椅
# - static.prop.advertisement         广告牌
# - static.prop.creasedbox01          折叠箱
# - static.prop.streetfountain        街道喷泉
# - static.prop.streetsign01          交通标志
# - static.prop.constructioncone      交通锥
# - static.prop.dirtdebris01          破碎泥土
# - static.prop.box02                 箱子
# - static.prop.box01                 箱子
# - static.prop.warningaccident       警告标志
# - static.prop.trashcan02            垃圾桶
# - static.prop.haybale               干草捆
# - static.prop.colacan               酸性罐头
# - static.prop.clothesline           洗衣绳
# - static.prop.foodcart              食物车
# - static.prop.slide                 滑梯
# - static.prop.clothcontainer        衣物容器
# - static.prop.dirtdebris02          破碎泥土
# - static.prop.glasscontainer        玻璃容器
# - static.trigger.friction            摩擦
# - static.prop.container             容器
# - static.prop.chainbarrier          链式围栏
# - static.prop.mobile                移动的
# - static.prop.bike helmet           自行车头盔
# - static.prop.table                 桌子
# - static.prop.creasedbox03          折叠箱
# - static.prop.brokentile04          破碎瓷砖
# - static.prop.trashcan04            垃圾桶
# - static.prop.bench01               基础座椅
# - static.prop.brokentile02          破碎瓷砖
# - static.prop.brokentile01          破碎瓷砖
# - static.prop.ironplank             铁板
# - static.prop.plantpot02            绿植盆栽
# - static.prop.bench03               基础座椅