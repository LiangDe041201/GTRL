#!/usr/bin/env python3
"""交叉口交通流管理器 —— 在交叉口东侧东西向道路上生成直行交通流
车辆沿东西方向直线行驶穿过交叉口，与左转的 ego 车辆形成博弈场景
使用 IDM 跟车模型，产生自然的车流间距变化"""
import carla, math, os, numpy as np
import csv
import json
from pathlib import Path
from Planning_library.rv_decision import (decide_rv_behavior, select_conflict_rv,
                                          idm_acceleration,
                                          idm_leader_index, platoon_ids_behind,
                                          traffic_speed_step, ego_intent)
from Planning_library.interaction_logger import get_logger
from Planning_library.traffic_spacing import FlowSpacing, box_bounds, spawn_clearance
from Planning_library.traffic_flow_v30 import TrafficSupplyV30

class CrossTrafficManager:
    """恒定巡航 + 安全跟车 + RV 让行；生成车距按实速与真实车身核对。

    v12 的普通目标净距默认 5 m，巡航约 4.412 m/s，车长从首次 actor
    包围盒校准。长生成间隔、让行、博弈和自车控制仍是独立的参数/机制。
    """

    def __init__(self, world, carla_map, traffic_v, flow_volume=0.3, dt=0.05):
        self.world = world
        self.map = carla_map
        # 自由流速度：论文标称 10 m/s，但论文同时声明"低速高密度、车距接近一个车身"；
        # 10 m/s 与 5 m 间距不可共存（见类文档），故默认降到 6 m/s 使 IDM 有平衡解。
        self.desired_speed = float(os.environ.get('DSH_TRAFFIC_V', str(traffic_v)))
        self.dt = dt                      # 仿真步长（同步模式固定 0.05s）
        #: 【式(18)】`{carla_id: 'yield'|'rush'}` —— 对手**真实动作**的共享记录。
        #:   为什么按 id 索引：管理器里的 `v` 是 CARLA actor，而 ego 侧的 `conf['rv_veh']`
        #:   是 dynamic_map 的**独立包装对象**，`setattr` 到前者后者读不到（实测熵恒为 0）。
        self.rv_behavior_by_id = {}

        # ===== IDM 参数 =====
        self.idm_T = 0.5          # 安全时距（秒）
        self.idm_g0 = 2.0         # 最小间距（米）
        self.idm_a = 2.0
        self.idm_b = 2.5
        self.idm_delta = 4.0
        # 车流车辆车身长度（mini.cooper_s ≈ 3.6 m）；用于"净间隙"与安全距离计算
        self.veh_len = float(os.environ.get('DSH_RV_LEN', '3.6'))
        self.interactions_enabled = True
        self.interaction_revision = os.environ.get('DSH_TRAFFIC_INTERACTION', 'legacy')
        if self.interaction_revision not in ('legacy', 'v17'):
            raise ValueError('Unknown traffic interaction revision')
        self.spacing_trial = 0
        self._spawn_bbox = None
        self._spacing_directory = os.environ.get('DSH_SAVE_DIR')
        self._spawn_frames_by_id = {}

        # ===== 固定生成点 =====
        self.cross_start = carla.Transform(
            carla.Location(x=20.0, y=-138.0, z=0.3),
            carla.Rotation(yaw=180.0)
        )
        print("[CrossTraffic] 车流起点 = (", round(self.cross_start.location.x,1), ",", round(self.cross_start.location.y,1), ") yaw=", round(self.cross_start.rotation.yaw,1))

        self.vehicle_bp = None
        self.managed_ids = []
        self._init_blueprint()

        # ===== 生成控制 =====
        self._spawned_first = False
        self._spawned_count = 0
        self._ego_near_intersection = False
        self._max_vehicles = int(os.environ.get('DSH_RV_MAX', '14'))
        self._spawn_frame = 0               # 仿真帧计数（替代墙钟 time.time，消除机器负载/训练时长导致的非平稳）
        self._last_spawn_frame = -100000
        # ===== 第 gap_after_count 辆后插入一个长间隙，给 ego 一个"走/等"的选择窗口 =====
        self._gap_after_count = int(os.environ.get('DSH_GAP_AFTER', '5'))
        self._gap_interval = float(os.environ.get('DSH_GAP_SEC', '3.0'))   # 秒
        self._gap_interval_frames = max(1, int(round(self._gap_interval / max(dt, 1e-3))))
        self.flow_policy = TrafficSupplyV30(os.environ.get('DSH_TRAFFIC_FLOW_MODE', 'legacy'),
                                           seed=int(os.environ.get('DSH_SEED', '0')))
        self.flow_policy.interval_frames(0, 1, self._gap_after_count, self._gap_interval_frames)
        self._flow_episode = 0  # reset owns this identity; logger begins its episode later.
        self._spawn_ordinals = {}
        self._flow_spawn_event = None

        self.spacing = FlowSpacing(free_speed=self.desired_speed,
            clear_gap=os.environ.get('DSH_TRAFFIC_CLEAR_GAP', '5.0'), length=self.veh_len, dt=dt,
            cruise_speed=os.environ.get('DSH_RV_CRUISE_SPEED'),
            interval=os.environ.get('DSH_TRAFFIC_INTERVAL'),
            min_center=os.environ.get('DSH_RV_MIN_SPACING'), g0=self.idm_g0, headway=self.idm_T)
        self._sync_spacing()
        print('[CrossTraffic] '+json.dumps(self.spacing.metadata()))
        # ===== 让行/抢行决策（对标论文 §VI-A + PRB_STA 原版 RV 模型）=====
        # 【§62】RV 让行/抢行重决策周期改为可配（默认仍是 2.0 s）。
        #   ⚠ 注意：这里改的是**对手(RV)**，不是 ego。ego 每帧都决策（20 Hz）。
        #   周期越短 ⇒ 对手在 ego 的 ~4 s 穿越窗内翻转 yield↔rush 的次数越多
        #   （2.0s→~2 次；0.5s→~8 次）⇒ 行为更不稳定。对机会约束判据而言，
        #   这**可能推高风险估计（更保守/更卡死）**，也可能因响应更快而更早让开。
        #   符号不确定 ⇒ 默认保持 2.0，单独 A/B。
        # 【§64 B 方案】意图耦合强度：0=关闭（旧行为），默认 0.8。
        #   自车"车头贴线"（intent→1）时，对手让行概率被抬高。
        self.rv_intent_gain = float(os.environ.get('DSH_RV_INTENT_GAIN', '0.8'))
        self.rv_decision_sec = float(os.environ.get('DSH_RV_DECISION_SEC', '2.0'))
        self.rv_cycle_frames = max(1, int(round(self.rv_decision_sec / max(dt, 1e-3))))
        self._last_intent = 0.0
        #: 交叉带半宽（与 boundary_safety.BAND_HALF_DEFAULT 一致）
        self.band_half = 1.0
        # ===== 【P1-d】让行幅度：从"绝对 3.0 m/s"改为"巡航速度的比例" =====
        #   背景：P0-3 把车流改成 v_free=6 → IDM 稳态巡航只有 4.41 m/s；
        #   而让行目标仍是 3.0 m/s ⇒ **让行与巡航只差 1.4 m/s**，间隙几乎张不开
        #   （旧配置 10 m/s 让到 3.0，差 7 m/s，所以以前感觉"让行很有效"）。
        #   现在默认 yield_target = 0.3 × 巡航速度 ≈ 1.3 m/s（差 ~3.1 m/s，张开速度翻倍）；
        #   DSH_RV_YIELD_SPEED 仍可设绝对值覆盖，DSH_RV_YIELD_RATIO 调比例。
        self.rv_yield_ratio = float(os.environ.get('DSH_RV_YIELD_RATIO', '0.3'))
        _ys_env = os.environ.get('DSH_RV_YIELD_SPEED')
        self.rv_yield_target = (float(_ys_env) if _ys_env is not None
                                else max(0.0, self.rv_yield_ratio * self.rv_cruise_speed))
        # 【P1-d】让行沿队列向后传播的车数（0=旧行为，只让被切入的那一辆）
        self.yield_propagate = int(os.environ.get('DSH_YIELD_PROPAGATE', '1'))
        # 【P0-1】让行减速速率 (m/s²)：不再用 min(v, target) 硬截断（那等于瞬时变速，
        #   会把出生间距瞬间压掉），改为按此速率趋向目标速度。
        self.rv_yield_decel = float(os.environ.get('DSH_RV_DECEL', '2.5'))
        # ===== 【§55 基准点修复】冲突点 x =====
        # 旧值 `-7.1`（硬编码）与实测**相差 11~13 m**，且方向使预测**系统性偏晚**。
        # 实测证据（15/15 次碰撞，跨 5 个不同配置的 run）：
        #   · 碰撞时**碰撞车** `x` 中位 **5.64**（范围 3.05~6.52）
        #   · 碰撞时**自车** `x` ≈ **4.1~4.5**（车头正压在带北边缘 y=−137）
        #   ⇒ 自车左转路径进入车流带的 x ≈ **4.0**，而不是 −7.1，也不是路口中心 6.0。
        # 为什么这个偏移是致命的：车流沿 **−x** 向西流（从 x=20 出发），所以
        #   `conflict_x=−7.1` 是**已经开过去**的位置 ⇒ 每辆车的 `rv_dist_conflict`
        #   都多算了 ~11~13 m ⇒ 预测到达时间普遍**偏晚 Δt ≈ 13.1/v**
        #   （v=2.33 时晚 5.6 s、v=4.41 时晚 3.0 s）。
        #   实测铁证：某次授权时 `rv_dist_conflict=18.98`、预测 `rv_t_veh=8.13 s`，
        #   而实际 **1.95 s** 后就撞上（该车距真实冲突点只有 6.2 m）。
        # ⇒ 安全判据一直在一辆"3~5.6 s 之后才到"的假象上做出"可以进"的决定。
        self.conflict_x = float(os.environ.get('DSH_CONFLICT_X', '4.0'))
        self.conflict_y = -138.0          # 冲突点 y
        self._rv_state = {}               # actor_id -> {'counter':..,'behavior':..,'target':..,'decided':..}
        # 【论文 §VI-A zone A】ego 距冲突点 < 该半径视为"进入 A 区"；
        #   【P0-1】但只对**与 ego 时空冲突的那一辆 RV** 强制让行（论文语义：
        #   "when the LCV enters zone A, **the** RV is required to yield"），
        #   而不是对决策窗内所有 RV 无差别强制让行（那会把整条车流压死）。
        self.zone_a_radius = float(os.environ.get('DSH_ZONE_A_R', '8.0'))
        # 判定"冲突车"的裕度（s）：到达冲突点时间差 < 清空时间 + 该裕度 → 视为冲突
        self.conflict_margin = float(os.environ.get('DSH_CONFLICT_MARGIN', '0.5'))
        # 【P0-4】ego 越过冲突点(committed)后的强制让行策略：
        #   'rear'(默认, 选项2) 只对"会撞到 ego 车尾的那一辆 RV"强制让行
        #   'all'              旧行为：对决策窗内每一辆 RV 强制让行（对照用）
        self.committed_yield = os.environ.get('DSH_COMMITTED_YIELD', 'rear')
        # 【交互诊断】逐帧 RV 刹车/让行原因 + 逐回合汇总（见 Planning_library/interaction_logger.py）
        self.ilog = get_logger()
        print("[CrossTraffic] RV 让行决策已启用 "
              f"(conflict_x={self.conflict_x}, 重决策周期 {self.rv_cycle_frames}帧, "
              f"zoneA_R={self.zone_a_radius}m, 仅对冲突车强制让行, "
              f"让行目标={self.rv_yield_target:.2f} m/s(巡航{self.rv_cruise_speed:.2f} 的"
              f"{self.rv_yield_ratio:.0%})，让行向后传播 {self.yield_propagate} 辆)")

    def _init_blueprint(self):
        bp = self.world.get_blueprint_library().filter('vehicle.mini.cooper_s')[0]
        if bp.has_attribute('color'):
            bp.set_attribute('color', '0,0,255')
        self.vehicle_bp = bp

    def _sync_spacing(self):
        self.veh_len = self.spacing.length
        self.rv_clear_gap = self.spacing.target_clear_gap
        self.rv_cruise_speed = self.spacing.cruise_speed
        self._spawn_interval = self.spacing.interval_seconds
        self._spawn_interval_frames = self.spacing.interval_frames
        self._spawn_center_gap = self.spacing.predicted_center

    def spacing_metadata(self):
        value = dict(self.spacing.metadata(), interactions_enabled=self.interactions_enabled,
                    gap_after=self._gap_after_count, long_interval_seconds=self._gap_interval,
                    interaction_revision=self.interaction_revision,
                    following_max_deceleration=5. if self.interaction_revision == 'v17' else None)
        if self.flow_policy.continuous:
            value.update(self.flow_policy.metadata(self._max_vehicles, self._gap_after_count),
                flow_center_y=float(self.cross_start.location.y), conflict_x=self.conflict_x,
                spawn_x=float(self.cross_start.location.x), expected_sample_dt=self.dt,
                supply_start='original_ego_30m_trigger_and_first_arrival_alignment',
                supply_end='episode_reset_or_termination_only')
        return value

    def _write_spacing_metadata(self):
        if self._spacing_directory:
            destination = Path(self._spacing_directory)
            destination.mkdir(parents=True, exist_ok=True)
            (destination/'traffic_spacing_metadata.json').write_text(
                json.dumps(self.spacing_metadata(), indent=2), encoding='utf8')

    def _record_spacing(self, filename, values):
        if not self._spacing_directory:
            return
        destination = Path(self._spacing_directory)/filename
        destination.parent.mkdir(parents=True, exist_ok=True)
        row = dict(episode=getattr(getattr(self, 'ilog', None), 'episode', 0),
                   trial=self.spacing_trial, frame=self._spawn_frame, **values)
        new = not destination.exists()
        with destination.open('a', newline='', encoding='utf8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(row))
            if new:
                writer.writeheader()
            writer.writerow(row)

    @staticmethod
    def _bounds(actor):
        return box_bounds(actor.bounding_box.get_world_vertices(actor.get_transform()))

    def start_flow(self, delay_seconds=0., trial=None):
        if not math.isfinite(delay_seconds) or delay_seconds < 0.:
            raise ValueError('Invalid initial traffic delay')
        if trial is not None:
            self.spacing_trial = trial
        delay = int(math.ceil(delay_seconds/self.dt-1e-9))
        self._ego_near_intersection = True
        self._last_spawn_frame = self._spawn_frame-self._spawn_interval_frames+delay
        self._write_spacing_metadata()

    def reset(self):
        for a in self.world.get_actors(self.managed_ids):
            if a is not None:
                a.destroy()
        self.managed_ids = []
        self._spawned_first = False
        self._spawned_count = 0
        self._spawn_frame = 0
        self._last_spawn_frame = -100000
        self._ego_near_intersection = False
        self._rv_state = {}
        self._spawn_frames_by_id = {}
        self.rv_behavior_by_id.clear()
        if self.flow_policy.continuous:
            self._flow_episode += 1
        self._spawn_ordinals = {}
        self._flow_spawn_event = None

    def init_traffic_flow(self):
        return []

    def _get_alive_vehicles(self):
        return [a for a in self.world.get_actors(self.managed_ids) if a is not None and a.is_alive]

    def _idm_acceleration(self, v, front_v, gap):
        """IDM 跟车加速度（委托纯函数，见 Planning_library.rv_decision.idm_acceleration）。"""
        return idm_acceleration(v, front_v, gap, v0=self.desired_speed,
                                T=self.idm_T, g0=self.idm_g0, a=self.idm_a,
                                b=self.idm_b, delta=self.idm_delta)

    def spawn_one_vehicle(self, interval_kind='ordinary'):
        existing = [(v.id, self._bounds(v)) for v in self._get_alive_vehicles()]
        def record(event, gap=None, leader=None, actor=None):
            if self.flow_policy.continuous:
                self._flow_spawn_event = event
            values = dict(event=event, actor_id=actor,
                leader_id=leader, projected_clear_gap=gap, pose_source='requested_spawn_transform',
                target_clear_gap=self.spacing.target_clear_gap,
                cruise_speed=self.rv_cruise_speed, measured_length=self.spacing.length,
                length_source=self.spacing.length_source, planned_interval_s=self._spawn_interval,
                actual_interval_s=(self._spawn_frame-self._last_spawn_frame)*self.dt
                    if self._spawned_count else None, interval_kind=interval_kind)
            if self.flow_policy.continuous:
                values.update(flow_mode=self.flow_policy.mode, flow_episode=self._flow_episode,
                    requested_spawn_ordinal=self._spawned_count+1,
                    spawn_ordinal=self._spawned_count+1 if event=='spawned' else None)
            self._record_spacing('traffic_spawns.csv', values)
        for attempt in range(3):
            try:
                offset_x = 0.0 if attempt == 0 else (0.5 if attempt % 2 == 0 else -0.5) * (attempt // 2 + 1)
                offset_y = 0.0 if attempt == 0 else (0.3 if attempt % 3 == 0 else -0.3) * (attempt // 3 + 1)
                adjusted_t = carla.Transform(
                    carla.Location(
                        self.cross_start.location.x + offset_x,
                        self.cross_start.location.y + offset_y,
                        0.3
                    ),
                    self.cross_start.rotation
                )
                if self._spawn_bbox is not None:
                    candidate = box_bounds(self._spawn_bbox.get_world_vertices(adjusted_t))
                    gap, leader = spawn_clearance(candidate, existing)
                    if gap is not None and gap+1e-6 < self.spacing.target_clear_gap:
                        record('deferred', gap, leader)
                        return None  # time elapsed alone cannot grant spawning
                v = self.world.try_spawn_actor(self.vehicle_bp, adjusted_t)
                if v is not None:
                    try:
                        # A newly spawned actor is absent from the current cached snapshot.
                        # Its box is available, but get_transform() is not an observation yet.
                        # Project the real box at the requested pose; the next ordinary step
                        # logs the first observed pose without adding an extra world.tick().
                        projected = box_bounds(v.bounding_box.get_world_vertices(adjusted_t))
                        if self._spawned_count == 0:
                            self.spacing.set_length(projected[1]-projected[0], source='actor_bbox_world_vertices')
                            self._spawn_bbox = v.bounding_box
                            self._sync_spacing()
                            self._write_spacing_metadata()
                        gap, leader = spawn_clearance(projected, existing)
                        if gap is not None and gap+1e-6 < self.spacing.target_clear_gap:
                            v.destroy()
                            record('deferred_actual_bbox', gap, leader)
                            return None
                    except Exception:
                        v.destroy()
                        raise
                    v.set_target_velocity(
                        carla.Vector3D(x=-self.rv_cruise_speed, y=0.0, z=0.0))
                    record('spawned', gap, leader, v.id)
                    self.managed_ids.append(v.id)
                    self._spawn_frames_by_id[v.id] = self._spawn_frame
                    self._spawned_first = True
                    self._spawned_count += 1
                    if self.flow_policy.continuous:
                        self._spawn_ordinals[v.id] = self._spawned_count
                    print(f"[CrossTraffic] 生成车辆 #{self._spawned_count} id={v.id} "
                          f"v={self.rv_cruise_speed:.2f} m/s")
                    return v
            except RuntimeError:
                pass
        record('spawn_failed')
        return None

    def _vehicle_should_destroy(self, vl):
        return vl.x < self.cross_start.location.x - 70

    def run_step(self, ego):
        sigs = []
        cid = -1
        mttc = float('inf')
        vs = self._get_alive_vehicles()
        self._spawn_frame += 1   # 每帧 +1（同步模式下一帧=0.05s）
        # ===== 交互诊断日志（回答"RV 是否提前刹车使环境变简单"）=====
        ilog = self.ilog
        ilog.tick()
        
        ex = ego.get_location().x
        ey = ego.get_location().y
        ev = ego.get_velocity()
        es = math.sqrt(ev.x**2 + ev.y**2 + ev.z**2)
        
        # ===== IDM 更新已有车辆 =====
        vehicle_data = []
        for v in vs:
            observed_transform = v.get_transform() if self.flow_policy.continuous else None
            vl = observed_transform.location if observed_transform is not None else v.get_location()
            vv = v.get_velocity()
            speed = math.sqrt(vv.x**2 + vv.y**2 + vv.z**2)
            vehicle_data.append({
                'actor': v,
                'id': v.id,
                'x': vl.x,
                'y': vl.y,
                'speed': speed,
                'velocity': vv,
                'bounds': (box_bounds(v.bounding_box.get_world_vertices(observed_transform))
                           if observed_transform is not None else self._bounds(v))
            })
            if observed_transform is not None:
                vehicle_data[-1].update(observed_yaw_rad=math.radians(observed_transform.rotation.yaw),
                    observed_length=2.*float(v.bounding_box.extent.x),
                    observed_width=2.*float(v.bounding_box.extent.y))
        vehicle_data.sort(key=lambda d: d['x'])

        # ===== 【P0-1】选出"与 ego 时空冲突的那一辆 RV"（论文 zone A 的唯一作用对象）=====
        # 论文 §VI-A："when the LCV enters zone A, **the** RV is required to yield" ——
        # zone A 是 ego 的位置条件，但被强制让行的是**与 ego 冲突的那一辆**，
        # 而不是决策窗内的所有车（原实现对窗内每辆车都强制让行 → 全队同时刹车 →
        # 队列压成 3.7 m → 缝隙永远打不开）。
        ego_committed = ey < self.conflict_y - 1.0
        _dist_ego_conflict = math.hypot(ex - self.conflict_x, ey - self.conflict_y)
        ego_in_zone_a = _dist_ego_conflict < self.zone_a_radius
        # 自车清空冲突点所需时间（与 ego 侧 _action_would_conflict 同口径：4m 车身 / 车速）
        _clear_ego = 4.0 / max(es, 0.5)
        # 自车到冲突点时间（式61 的 t_avail 口径：LCV 进入 A 区的时间）
        _t_ego_proxy = _dist_ego_conflict / max(es, 0.5)
        _conflict_rv_id = None
        _best_dt = float('inf')
        if ego_in_zone_a and not ego_committed:
            # 纯函数（可离线单测）：只选"与 ego 时空冲突的那一辆"
            _conflict_rv_id, _best_dt = select_conflict_rv(
                vehicle_data, self.conflict_x, _t_ego_proxy, _clear_ego,
                margin=self.conflict_margin)

        # ===== 【P0-4 选项2】ego 已越过冲突点后：只对"会撞到 ego 车尾的那一辆"强制让行 =====
        # 论文说"游戏在 LCV 完成变道后结束"，但我们的 committed 只是"沿路径越过冲突点 1m"，
        # ego 车身还有一段留在交叉口里 → 完全取消让行会让 ego 被直行车追尾。
        # 折中：只让"在 ego 车尾驶离它所在 x 之前就会到达该 x"的那一辆 RV 让行，
        # 其余车恢复 IDM/伯努利（原实现对窗内**每一辆**都强制让行，
        # 实测占全部决策 20.6%，也是队列塌陷的贡献项）。
        _committed_rv_id = None
        if ego_committed and self.committed_yield == 'rear':
            try:
                _ego_len = float(getattr(ego, 'bounding_box').extent.x) * 2.0
            except Exception:
                _ego_len = 4.5
            # ego 车尾驶离"当前 ego 车头所在 x"所需时间（保守：整车长 + 余量）
            _t_rear_clear = (_ego_len + 1.0) / max(es, 0.5)
            _best_rear = float('inf')
            for _d in vehicle_data:
                if _d['x'] <= ex:          # 已经越过 ego 当前位置（或正在驶离）
                    continue
                _t_hit = (_d['x'] - ex) / max(_d['speed'], 0.1)
                if _t_hit < _t_rear_clear + self.conflict_margin and _t_hit < _best_rear:
                    _best_rear, _committed_rv_id = _t_hit, _d['id']

        # 【旧 bug 修复】前车 = x 比本车小（更靠西）且最近的那一辆。
        #   原写法在 x 升序列表里从 i+1 往后找 x < x_i，条件恒不成立 →
        #   front_data 恒为 None → IDM 跟车/避撞项从未生效 → RV 互相顶到一起。
        _xs = [d['x'] for d in vehicle_data]
        _ids_asc = [d['id'] for d in vehicle_data]
        # 【P1-d】让行编队：被切入的那一辆（或 committed 后挡 ego 车尾的那一辆）
        #   一旦自己决定"让行"，就把让行沿队列向后传播 k 辆（它自己也含在集合里）。
        _partner_id = _conflict_rv_id if _conflict_rv_id is not None else _committed_rv_id
        _platoon_ids = platoon_ids_behind(_ids_asc, _partner_id, self.yield_propagate)
        _platoon_active = False
        _platoon_target = self.rv_yield_target
        ego_bounds = self._bounds(ego) if self.interaction_revision == 'v17' else None

        for i, data in enumerate(vehicle_data):
            v = data['actor']
            current_speed = data['speed']
            _fi = idm_leader_index(_xs, i)
            front_data = vehicle_data[_fi] if _fi is not None else None
            # ===== 【§63 恒定速度 + 安全距离跟车】=====
            # 用户口径：①生成后**匀速直线**；②前车让行 ⇒ 后车跟着减速保持安全距离；
            #   ③前车后车距离大 ⇒ **不加速**，保持匀速 —— 那个空位留给 ego 插入。
            # 为什么要改（实测根因）：旧式用 `desired_speed=6.0` 作 v0，于是
            #   ①无前车/间距大时会**自由流加速到 6.0**，把让行刚打开的间隙关掉；
            #   ②IDM 平衡净间距 s*(v)=g0+v·T 最大只有 5.0 m，而 ego 穿越需要 8.5 m
            #     ⇒ 稳态车流永远插不进去；唯一机会是暂态间隙，而它 ~2 s 就被关掉，
            #     而 ego 需要窗口维持 t_ego_go(2.2)+clr_go(3.9)=6.1 s。
            #   ⇒ 窗口寿命 2 s vs 需求 6.1 s，这是机会约束风险中位 0.88 的根因。
            # 新式：恒定速度 `v_const = rv_cruise_speed`（4.41），**绝不超过它**，
            #   但允许从低速**恢复**回来（用户确认）。规则见纯函数
            #   `rv_decision.traffic_speed_step`（有离线单测）。
            if front_data is not None:
                gap = data['bounds'][0] - front_data['bounds'][1]
                front_speed = front_data['speed']
            else:
                gap, front_speed = float('inf'), None
            following_gap, following_speed = gap, front_speed
            following_id = None if front_data is None else front_data['id']
            following_role = 'none' if front_data is None else 'background'
            if ego_bounds is not None:
                # Westbound traffic: use the nearest physical leader, including
                # an ego that has actually entered this vehicle's corridor.
                overlaps = min(data['bounds'][3], ego_bounds[3])-max(data['bounds'][2], ego_bounds[2]) > .05
                ego_gap = data['bounds'][0]-ego_bounds[1]
                if ex < data['x'] and overlaps and ego_gap < following_gap:
                    following_gap, following_speed = ego_gap, max(0., -ev.x)
                    following_id, following_role = ego.id, 'ego'
            new_speed, acc = traffic_speed_step(
                current_speed, following_speed, following_gap, v_const=self.rv_cruise_speed,
                T=self.idm_T, g0=self.idm_g0, a=self.idm_a, b=self.idm_b,
                delta=self.idm_delta, dt=self.dt)
            if self.interaction_revision == 'v17' and following_id is not None:
                # Full closing-speed term, before the gap is already below
                # g0+v*T. No .5m/s floor behind a stopped leader. The emergency
                # deceleration limit is explicit; a late cut-in is not a
                # promise that collision can physically be avoided.
                acc = max(-5., min(self.idm_a, idm_acceleration(current_speed,
                    following_speed, max(following_gap, .01), v0=self.desired_speed,
                    T=self.idm_T, g0=self.idm_g0, a=self.idm_a, b=self.idm_b,
                    delta=self.idm_delta)))
                new_speed = max(0., min(self.rv_cruise_speed, current_speed+acc*self.dt))

            # ===== 让行/抢行决策（对标论文 §VI-A + PRB_STA 原版 RV 模型）=====
            # 【边缘触发】决策区 = 冲突点以东 (conflict_x+2, conflict_x+25)：
            # 车辆从东侧驶入决策区即触发首次决策（此时离冲突点还有 ~2.5s，来得及
            # 减速让行）；在区内每 rv_cycle_frames 帧（2s）重决策一次。
            # 注意：不能用固定周期计数——交叉车在决策区内只停留 ~2.3s，固定 2s
            # 周期会恰好错过（原 bug：rv# 决策永远不触发）。
            st = self._rv_state.setdefault(v.id, {
                'counter': 0, 'behavior': 'rush', 'target': self.rv_cruise_speed,
                'decided': False})
            if self.flow_policy.continuous and 'decision_ordinal' not in st:
                st.update(decision_ordinal=0, decision_uniform=None, decision_used_uniform=False,
                          decision_reason=None, decision_yield_probability=None)
            in_zone = data['x'] > self.conflict_x + 2.0 and data['x'] < self.conflict_x + 25.0
            # 【诊断/控制】ego 侧量
            # 【§64 B 方案】自车进入意图（纯几何：车头到交叉带北边缘的净空）
            _intent = ego_intent(ey, self.conflict_y, self.band_half)
            self._last_intent = float(_intent)
            _ego_dist = math.hypot(data['x'] - ex, data['y'] - ey)
            _ttc_proxy = _ego_dist / max(es + data['speed'], 0.1)
            # 【P0-1】zone A 只对本车"是那辆冲突车"且 ego 在 A 区时生效
            _ink = (v.id == _conflict_rv_id)
            # 【P0-4 选项2】committed 后只对"会撞 ego 车尾"的那一辆强制让行
            _cmt = bool(ego_committed and v.id == _committed_rv_id)
            if ego_committed and self.committed_yield == 'all':
                _cmt = True                      # 旧行为（对照用）
            # 【P0-3】不再用 speed>0.1 作为进入决策的前置条件：停停走走时
            #   data['speed'] 会在 0.1 附近抖动 → 每帧走 else 分支重置 decided →
            #   每帧重决策（实测最多一回合 149 次）。现在只看"是否在决策区内"。
            if in_zone and self.interactions_enabled:
                st['counter'] += 1
                if not st['decided'] or st['counter'] >= self.rv_cycle_frames:
                    st['counter'] = 0
                    st['decided'] = True
                    # 【论文式61】传入 RV 真实加速度量：acc_follow=IDM 跟车加速度，
                    #   acc_current=实际施加加速度 (new_speed-speed)/dt，acc_max=IDM 最大加速度
                    _acc_cur = (new_speed - current_speed) / max(self.dt, 1e-6)
                    decision_rng = None
                    if self.flow_policy.continuous:
                        st['decision_ordinal'] += 1
                        decision_rng = self.flow_policy.decision_random(self._flow_episode,
                            self._spawn_ordinals[v.id], st['decision_ordinal'])
                    d = decide_rv_behavior(
                        {'x': ex, 'y': ey, 'v': es},
                        {'x': data['x'], 'y': data['y'], 'v': data['speed'],
                         'vx': -data['speed']},
                        self.conflict_x, _cmt, _ttc_proxy,
                        acc_current=_acc_cur, acc_follow=acc, acc_max=self.idm_a,
                        zone_a=_ink, t_ego=_t_ego_proxy,
                        yield_target_speed=self.rv_yield_target,
                        intent=_intent, intent_gain=self.rv_intent_gain, rng=decision_rng)
                    if self.flow_policy.continuous:
                        st.update(decision_uniform=decision_rng.value,
                            decision_used_uniform=d['reason']=='bernoulli', decision_reason=d['reason'],
                            decision_yield_probability=d['yield_prob'])
                    st['acc'] = _acc_cur
                    st['acc_follow'] = acc
                    st['behavior'] = d['behavior']
                    # 【式(18)】把本次"让行/抢行"决策写回**车辆对象**，
                    #   让 ego 侧能把对手的**真实动作序列**记进历史路径 p_t（式12），
                    #   进而按论文口径算对手动作频率熵（此前 _last_rv_action 只被读、从未被写，
                    #   导致式(18) 的消费者恒为 0 = 假落地）。
                    try:
                        setattr(v, '_dsh_rv_behavior', d['behavior'])
                    except Exception:
                        pass
                    try:
                        self.rv_behavior_by_id[int(v.id)] = str(d['behavior'])
                    except Exception:
                        pass
                    st['target'] = d['target_speed']
                    # 【诊断】记录本次让行/抢行决策的原因（zoneA/committed/emergency/bernoulli）
                    ilog.rv_decision(v.id, d['behavior'], d['reason'],
                                     p_yield=d.get('yield_prob'), ttc=_ttc_proxy,
                                     zone_a=_ink, rv_x=data['x'],
                                     rv_v=data['speed'], arc_to_cross=(
                                         (ilog.last_ego() or {}).get('arc')),
                                     committed=ego_committed)
                    print(f"[CrossTraffic] rv#{v.id} {d['reason']}: {d['behavior']} "
                          f"(p={d['yield_prob']:.2f}, ttc={_ttc_proxy:.2f}, x={data['x']:.1f}, "
                          f"zoneA={int(_ink)})")
                    # 【P1-d】被切入的那一辆决定让行 → 激活让行编队（沿队列向后传播）
                    if v.id == _partner_id and d['behavior'] == 'yield':
                        _platoon_active = True
                        _platoon_target = float(d['target_speed'])
            else:
                # 驶离决策区（已过冲突点/未接近）：恢复原速
                st['decided'] = False
                st['behavior'] = 'rush'
                st['target'] = self.rv_cruise_speed
            # 【P1-d】让行编队：被切入车决定让行后，它后面的 k 辆也一起让行
            #   （否则后车立刻跟进补位 → ego 进得去出不来，窗口只有一个间隙）
            if (in_zone and _platoon_active and v.id in _platoon_ids
                    and v.id != _partner_id):
                st['behavior'] = 'yield'
                st['target'] = _platoon_target
            # 【P0-1】让行 = 以受限减速度趋向让行目标（不再 min(v,target) 硬截断：
            #   硬截断等于瞬时变速，一帧内把出生间距压掉 → 队列压死/后车碰前车）
            if st['behavior'] == 'yield':
                _tgt = max(float(st['target']), 0.0)
                _max_drop = self.rv_yield_decel * self.dt
                if new_speed > _tgt:
                    new_speed = max(_tgt, new_speed - _max_drop)
                else:
                    new_speed = min(new_speed, max(_tgt, 0.5))
            if self.interaction_revision == 'v17':
                # Yield and following must share one final deceleration bound.
                new_speed = max(0., current_speed-5.*self.dt, new_speed)
            v.set_target_velocity(carla.Vector3D(x=-new_speed, y=0.0, z=0.0))
            spacing_sample = dict(actor_id=v.id,
                pose_source='actor_snapshot',
                leader_id=None if front_data is None else front_data['id'], x=data['x'], y=data['y'],
                observed_speed=current_speed, commanded_speed=new_speed,
                actual_clear_gap=None if front_data is None else gap,
                target_clear_gap=self.spacing.target_clear_gap,
                following_safe_gap=self.idm_g0+current_speed*self.idm_T,
                following_acceleration=acc, behavior=st['behavior'],
                interaction_revision=self.interaction_revision,
                following_leader_id=following_id, following_leader_role=following_role,
                following_gap=None if following_id is None else following_gap,
                following_leader_speed=following_speed,
                commanded_acceleration=(new_speed-current_speed)/self.dt,
                policy='interactive' if self.interactions_enabled else 'cruise_only_probe',
                age_s=(self._spawn_frame-self._spawn_frames_by_id.get(v.id, self._spawn_frame))*self.dt,
                at_conflict=int(abs(data['x']-self.conflict_x) <= 5.))
            if self.flow_policy.continuous:
                spacing_sample.update(flow_episode=self._flow_episode,
                    spawn_ordinal=self._spawn_ordinals[v.id],
                    observed_yaw_rad=data['observed_yaw_rad'],
                    observed_length=data['observed_length'], observed_width=data['observed_width'],
                    rv_decision_ordinal=st['decision_ordinal'],rv_decision_uniform=st['decision_uniform'],
                    rv_decision_used_uniform=st['decision_used_uniform'],rv_decision_active=st['decided'],
                    rv_decision_reason=st['decision_reason'],
                    rv_decision_yield_probability=st['decision_yield_probability'])
            self._record_spacing('traffic_spacing_samples.csv', spacing_sample)

            # 【诊断】观测窗口内逐帧记录 RV 状态，并检测"首次刹车"事件
            if -20.0 <= (data['x'] - self.conflict_x) <= 35.0:
                ilog.rv_row(v.id, data['x'], data['y'], new_speed,
                            behavior=st.get('behavior'), reason=None,
                            target_speed=st.get('target'),
                            zone_a=_ink, in_zone=in_zone,
                            ego_dist=_dist_ego_conflict,
                            ego_arc=(ilog.last_ego() or {}).get('arc'),
                            conflict_x=self.conflict_x, conflict_y=self.conflict_y,
                            committed=ego_committed, ttc_boundary=_ttc_proxy, dt=0.05,
                            ego_x=ex, ego_y=ey, ego_v=es)
            
            d = math.sqrt((data['x'] - ex)**2 + (data['y'] - ey)**2)
            if d < 50 and d > 0.5 and new_speed > 0.1:
                ttc = d / (es + new_speed + 0.01)
                if ttc < mttc:
                    mttc = ttc
                    cid = v.id
            
            if self._vehicle_should_destroy(v.get_location()):
                v.destroy()
                if v.id in self.managed_ids:
                    self.managed_ids.remove(v.id)
                if self.flow_policy.continuous:
                    self._rv_state.pop(v.id, None)
                    self._spawn_frames_by_id.pop(v.id, None)
                    self._spawn_ordinals.pop(v.id, None)
                    self.rv_behavior_by_id.pop(int(v.id), None)
        
        # ===== 触发车流生成（无条件：任何速度都生成车流）=====
        dist_to_intersection = math.sqrt((ex - 6.0)**2 + (ey - (-138.0))**2)

        if dist_to_intersection < 30.0 and not self._ego_near_intersection:
            # 无条件生成（ego 一定会进入 30m 范围）。
            # 首车时机按 ego 预计到达时间微调（速度下限 5 m/s，避免起步低速导致延误），
            # 使 ego 到达路口时车流正在经过（而非已经离开）→ 快慢都有博弈。
            ego_eta = dist_to_intersection / max(es, 5.0)      # 预计到达冲突点时间 (s)
            # 首车从生成点到冲突点的实际耗时（随 DSH_TRAFFIC_V 变化；原来硬编码 1.75s
            # 是按 10 m/s 估的，改成 6 m/s 后必须重算，否则首车会晚到/早到）
            t_first_to_conflict = (self.cross_start.location.x - self.conflict_x) \
                / self.rv_cruise_speed
            first_delay_s = max(0.0, ego_eta - t_first_to_conflict)
            self.start_flow(first_delay_s)
            if self.flow_policy.continuous:
                print('[CrossTraffic] continuous_v30: ordinary safe spawn every %.2fs; '
                      'no artificial gaps or cumulative vehicle limit until episode ends' % self._spawn_interval)
            else:
                _cover = self._max_vehicles * self._spawn_interval
                print(f"[CrossTraffic] 生成车流（ego 预计 {ego_eta:.1f}s 到达，首车延迟 {first_delay_s:.1f}s，"
                      f"首车到冲突点需 {t_first_to_conflict:.1f}s；共{self._max_vehicles}辆 × "
                      f"{self._spawn_interval:.2f}s ≈ 覆盖 {_cover:.0f}s，"
                      f"每{self._gap_after_count}辆后间隙{self._gap_interval:.1f}s"
                      f"（共约{max(0, self._max_vehicles // max(self._gap_after_count,1))}个窗口），"
                      f"车流总时长≈{self._max_vehicles * self._spawn_interval + max(0, self._max_vehicles // max(self._gap_after_count,1)) * max(0.0, self._gap_interval - self._spawn_interval):.1f}s")
        
        # ===== 按时间间隔生成（第 gap_after_count 辆后插入长间隙，给 ego 选择窗口）=====
        spawn_due = spawn_attempted = spawn_succeeded = False
        self._flow_spawn_event = None
        if self._ego_near_intersection and self.flow_policy.can_spawn(self._spawned_count, self._max_vehicles):
            interval_frames = self.flow_policy.interval_frames(self._spawned_count,
                self._spawn_interval_frames, self._gap_after_count, self._gap_interval_frames)
            # 【§52 车队+大间隙】旧式是 `== self._gap_after_count` ⇒ **全程只插一个**间隙。
            #   实测那唯一的 3.0 s 窗口比自车所需净空还短（需求 (4.5+4.0)/v_go + 1.0：
            #   v_go=3 m/s → 3.83 s、4 m/s → 3.13 s），于是"等间隙插入"根本不可行。
            #   改成**周期性**：每 `_gap_after_count` 辆后插一个 `_gap_interval` 的窗口。
            #   这同时更贴近真实无信号路口：上游信号放行 ⇒ 车流本来就是"车队 + 车队间空档"。
            #   `DSH_GAP_AFTER<=0` 可关闭（退化为纯等间距车流）。
            if self._spawn_frame - self._last_spawn_frame >= interval_frames:
                spawn_due = spawn_attempted = True
                v = self.spawn_one_vehicle('long' if interval_frames == self._gap_interval_frames
                                           and self._gap_after_count > 0 and self._spawned_count > 0
                                           and self._spawned_count % self._gap_after_count == 0 else 'ordinary')
                if v is not None:
                    spawn_succeeded = True
                    self._last_spawn_frame = self._spawn_frame
                    if self.flow_policy.continuous:
                        print('[CrossTraffic] 按实测车距持续生成 #%d (no finite cap)' % self._spawned_count)
                    else:
                        print(f"[CrossTraffic] 按实测车距生成 #{self._spawned_count}/{self._max_vehicles}")
        if self.flow_policy.continuous:
            next_due = (self._last_spawn_frame+self._spawn_interval_frames
                        if self._ego_near_intersection else None)
            self._record_spacing('traffic_flow_events_v30.csv', dict(flow_revision='traffic_flow_v30',
                flow_mode=self.flow_policy.mode, flow_episode=self._flow_episode,
                supply_active=self._ego_near_intersection, observed_actor_count=len(vehicle_data),
                live_managed_actor_count=len(self._get_alive_vehicles()), spawned_count=self._spawned_count,
                spawn_due=spawn_due, spawn_attempted=spawn_attempted, spawn_succeeded=spawn_succeeded,
                spawn_deferred=self._flow_spawn_event in ('deferred','deferred_actual_bbox'),
                spawn_outcome=self._flow_spawn_event, next_spawn_due_frame=next_due))
        
        return sigs, cid, mttc


def _nang(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a
