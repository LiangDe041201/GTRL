import carla
 
client = carla.Client('localhost', 2000)
carla_world = client.get_world()

# 如果当前地图不是Town03,则加载Town03地图.
if carla_world.get_map().name != 'Carla/Maps/Town03':    
    carla_world = client.load_world('Town03')  

#获取CARLA世界中的spectator
spectator = carla_world.get_spectator()
 
# 获取观察者的当前变换（包括位置、旋转等）
transform = spectator.get_transform()

print("\n" + "="*115)
print(transform)
print("="*115)
