#!/usr/bin/env python3
"""
转弯场景的 CARLA 仿真环境
基于原版 TestScenario_Town03_dds.py 改造

场景描述:
  - 地图: CARLA Town03
  - 自车: Lincoln MKZ 2020，从交叉口入口出发
  - 起点: (5.78, -103.23, 0.28) yaw=-89°
  - 终点: (6.70, -149.22, 0.28) yaw=-179°
  - 转弯角度: 约 90° 左转（从向西转为向南）
  - 博弈对象: 交叉方向来车（蓝色 Mini Cooper 车队）
"""

import glob
import os
import sys

# ==================== CARLA PythonAPI 自动定位（可移植，不依赖具体用户名/绝对路径）====================
def _setup_carla_pythonapi():
    """
    自动定位 CARLA PythonAPI 并加入 sys.path。
    查找优先级:
      1) 环境变量 CARLA_ROOT（推荐: export CARLA_ROOT=/path/to/carla_0.9.15）
      2) 用户主目录下的常见安装位置（Software/Carla0_9_15, Carla0_9_15, carla, CARLA, Downloads/CARLA_0.9.15 等）
      3) 本脚本所在目录向上查找（项目与 CARLA 相邻部署时）
      4) 旧硬编码路径（若仍存在，兼容旧机器）
    返回: 定位到的 CARLA 根目录；失败返回 None。
    """
    roots = []

    # 1) 环境变量
    _env = os.environ.get("CARLA_ROOT")
    if _env:
        roots.append(_env)

    # 2) 用户主目录常见位置
    _home = os.path.expanduser("~")
    for _base in ("Software/Carla0_9_15", "Software/Carla_0.9.15", "Carla0_9_15",
                  "Carla", "carla", "CARLA", "Carla_0.9.15", "carla_0.9.15",
                  "Downloads/CARLA_0.9.15"):
        roots.append(os.path.join(_home, _base))
    # 2b) 主目录下大小写不敏感地补充 carla* 目录（Linux 区分大小写，实际目录常为 ~/Carla）
    try:
        for _name in sorted(os.listdir(_home)):
            _p = os.path.join(_home, _name)
            if _name.lower().startswith("carla") and os.path.isdir(_p):
                roots.append(_p)
    except OSError:
        pass

    # 3) 脚本所在目录向上查找
    _here = os.path.dirname(os.path.abspath(__file__))
    for _up in range(0, 5):
        roots.append(os.path.abspath(os.path.join(_here, *([".."] * _up))))

    # 4) 旧硬编码路径（兼容）
    roots.append("/home/liangde/carla")

    _seen = set()
    for _root in roots:
        if _root in _seen:
            continue
        _seen.add(_root)
        _egg_matches = sorted(glob.glob(os.path.join(_root, "PythonAPI/carla/dist/*.egg")))
        if _egg_matches:
            # 优先挑选与当前 Python 版本匹配的 egg（dist 目录可能同时含 py2.7 / py3.7 多个）
            _ver = "py%d.%d" % (sys.version_info[0], sys.version_info[1])
            _match = [e for e in _egg_matches if _ver in os.path.basename(e)]
            sys.path.append(_match[0] if _match else _egg_matches[0])
            _carla_dir = os.path.join(_root, "PythonAPI/carla")
            if os.path.isdir(_carla_dir):
                sys.path.append(_carla_dir)
            return _root
        _carla_dir = os.path.join(_root, "PythonAPI/carla")
        if os.path.isdir(_carla_dir):
            sys.path.append(_carla_dir)
            return _root
    return None


_carla_root = _setup_carla_pythonapi()
if _carla_root is None:
    print("[TurnEnv] 警告: 未找到 CARLA PythonAPI，将尝试直接 import carla。"
          "如失败请设置环境变量 CARLA_ROOT 指向 CARLA 根目录")
else:
    print(f"[TurnEnv] 使用 CARLA PythonAPI: {_carla_root}")

import carla
import time
import numpy as np
import math
import random
import json
from pathlib import Path
import gym
from carla import Location, Rotation, Transform, Vector3D, VehicleControl
from gym import core, spaces

from agents.navigation.global_route_planner import GlobalRoutePlanner

# 复用原版工具模块
import sys as _sys
_sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from Agent.tools_dds.dynamic_map import Lanepoint, Lane, Vehicle
from Agent.tools_dds.tools import *
from Planning_library.coordinates import Coordinates
from Test_Scenarios.cross_traffic_manager import CrossTrafficManager
from Planning_library.turn_completion import completion_metrics
from Planning_library.actuator_interface import physical_geometry, ackermann_target
from Planning_library.pedal_control import PedalController, PedalControllerV10, PedalControllerV11, brake_deceleration, signed_speed
from Planning_library.synchronous_control import configure_physics, submit_control


# ======================= 场景参数（用户提供的实际坐标）=======================

# 起点: 交叉口入口，面向西（yaw=-89°）
start_point = Transform()
start_point.location.x = 5.78
start_point.location.y = -103.23
start_point.location.z = 0.28
start_point.rotation.pitch = 0
start_point.rotation.yaw = -89
start_point.rotation.roll = 0

# 自车生成点
ego_spawn_point = Transform()
ego_spawn_point.location.x = 5.78
ego_spawn_point.location.y = -103.23
ego_spawn_point.location.z = 0.28
ego_spawn_point.rotation.pitch = 0
ego_spawn_point.rotation.yaw = -89
ego_spawn_point.rotation.roll = 0

# 目标点: 左转90°后向南（yaw=-179°）
goal_point = Transform()
goal_point.location.x = -21
goal_point.location.y = -138.51
goal_point.location.z = 0.28
goal_point.rotation.pitch = 0
goal_point.rotation.yaw = -179
goal_point.rotation.roll = 0

# 交叉口中心: ego左转路径与东西向交叉流道路的交汇点
# ego沿南北向道路(x≈6)行驶→左转→与东西向道路(y≈-138)上的交叉流博弈
INTERSECTION_CENTER = (6.00, -138.00)


class CarEnv_Town03_Turn:
    """转弯场景的 CARLA 强化学习环境"""

    def __init__(self):
        self.last_action = [0, 0]
        self.goal_pose = (goal_point.location.x, goal_point.location.y,
                          math.radians(goal_point.rotation.yaw))
        self.completion_mode = os.environ.get('DSH_TURN_COMPLETE_MODE', 'strict').lower()
        if self.completion_mode not in ('strict', 'legacy'):
            raise ValueError('DSH_TURN_COMPLETE_MODE must be strict or legacy')
        self.completion_diag = {}
        self.last_control = {}
        self.native_control = os.environ.get('DSH_CONTROL_PROFILE') == 'paper_v8'
        self.pedal_control = os.environ.get('DSH_CONTROL_PROFILE') in ('paper_v9', 'paper_v10', 'paper_v11')
        self.synchronous_control = os.environ.get('DSH_CONTROL_PROFILE') in ('paper_v10', 'paper_v11')
        traffic_mode = os.environ.get('DSH_TRAFFIC', 'on')
        if traffic_mode not in ('on', 'off'):
            raise ValueError('DSH_TRAFFIC must be on or off')
        self.traffic_enabled = traffic_mode == 'on'
        print('[TurnEnv] completion_mode=' + self.completion_mode)

        # ===== CARLA 连接 =====
        self.client = carla.Client("localhost", 2000)
        # 【超时可调】原来硬编码 10 s。切地图（load_world）在本机实测会超过 10 s，
        #   于是 `get_map()` 抛 "time-out of 10000ms" 并**中断整个初始化**（实测踩过）。
        #   加载/渲染模式下切图更慢，故改成环境变量可调；默认 30 s（更宽容，不影响训练语义）。
        self.client.set_timeout(float(os.environ.get('DSH_CARLA_TIMEOUT', '30.0')))
        self.world = self.client.get_world()
        if self.native_control and not hasattr(carla, 'VehicleAckermannControl'):
            raise RuntimeError('paper_v8 requires the CARLA Ackermann API (validated target: 0.9.15)')

        if self.world.get_map().name != 'Carla/Maps/Town03':
            # 【切图重试】服务器未预载 Town03 时需要 load_world。这一步在低配/渲染模式下
            #   可能超过任一固定超时；重试比一次失败就崩更实用。
            _last = None
            for _attempt in range(3):
                try:
                    self.world = self.client.load_world('Town03')
                    break
                except Exception as _e:      # noqa: BLE001 - 需要显形并重试
                    _last = _e
                    print(f"[TurnEnv] load_world('Town03') 第 {_attempt+1}/3 次失败: {_e!r}")
                    time.sleep(5.0)
            else:
                raise RuntimeError(f'无法加载 Town03（已重试 3 次）: {_last!r}')

        self.map = self.world.get_map()

        self.world.set_weather(carla.WeatherParameters(
            cloudiness=50, precipitation=30.0, sun_altitude_angle=60.0
        ))

        settings = self.world.get_settings()
        self.spectator = self.world.get_spectator()
        # 【稳定性】连接时关闭服务器渲染线程（no_rendering_mode=True）：
        # 防 UE4 渲染内存在长训练(~40回合)时累积导致服务器崩溃——这是标准 RL
        # 训练做法，也是代码主人"黑屏跑"建议的实现。服务器端用 -RenderOffScreen
        # 启动即可；碰撞传感器是物理层，不受影响。
        #
        # 【可视化】DSH_RENDER=1 → 打开服务器渲染 + 旁观者俯视 ego（spectator_update）；
        #   DSH_VIEW=1   → 客户端相机 + pygame 窗口（见 Planning_library/live_view.py）：
        #   相机传感器需要渲染管线，故它也要求 no_rendering_mode=False。
        #   两者都要求服务器用 start_headless_server.sh（-RenderOffScreen）启动：
        #   带窗口启动服务器在软件 Vulkan 下会 RenderThread 超时崩溃。
        self.render = (os.environ.get('DSH_RENDER', '0') == '1'
                       or os.environ.get('DSH_VIEW', '0') == '1')
        settings.no_rendering_mode = not self.render
        if self.render:
            print("[TurnEnv] 渲染已打开（DSH_RENDER/DSH_VIEW）：仿真会变慢")
        self.dt = 0.05
        settings.fixed_delta_seconds = self.dt
        settings.substepping = True
        settings.max_substep_delta_time = 0.02
        settings.max_substeps = 10
        settings.synchronous_mode = True
        self.world.apply_settings(settings)
        if self.synchronous_control:
            self.physics_timing = configure_physics(self.world, self.dt, .005)

        self.free_traffic_lights(self.world)

        self.tm = self.client.get_trafficmanager(8000)
        self.tm.set_random_device_seed(0)

        actors = self.world.get_actors().filter('vehicle*')
        for actor in actors:
            actor.destroy()

        self.debug = self.world.debug
        # 【稳定性】关闭 per-frame debug 绘制：减少渲染负载/泄漏，
        # 配合服务器 -nullrhi 无渲染启动，避免长训练(~40回合)时 UE4 崩溃。
        self.should_debug = False

        self.global_routing()

        # ===== RL 设置 =====
        self.action_space = spaces.Discrete(11)
        self.low = np.array([0] * 20, dtype=np.float64)
        self.high = np.array([1] * 20, dtype=np.float64)
        self.observation_space = spaces.Box(self.low, self.high, dtype=np.float64)
        self.action_dimension = 11
        self.state_dimension = 20

        # ===== 自车设置 =====
        self.ego_vehicle_bp = random.choice(
            self.world.get_blueprint_library().filter('vehicle.lincoln.mkz_2020')
        )
        if self.ego_vehicle_bp.has_attribute('color'):
            self.ego_vehicle_bp.set_attribute('color', '255,0,0')
            self.ego_vehicle_bp.set_attribute('role_name', "ego_vehicle")
        self.ego_collision_bp = self.world.get_blueprint_library().find('sensor.other.collision')

        self.ego_vehicle = None
        self.ego_vehicle_collision_sign = False
        # 【诊断埋点】碰撞的**真实对方**（此前只记了一个布尔值，真实 actor 被丢弃，
        #   导致离线分析只能拿"末帧离 ego 最近的 RV"当代理）。见 _on_ego_collision。
        self.ego_collision_event = None
        self.stuck_time = None
        self.sim_frame = 0               # 仿真帧计数（卡死检测用，替代墙钟）
        self._stuck_start_frame = None
        self.initial_yaw = 0.0

        # ===== 交通流设置 =====
        self.traffic_flow_speed = 10
        self.traffic_flow_volume = 0.4
        # 交叉流"空路期望速度"(m/s)。论文 §VI-A 标称 10 m/s，但同时声明场景是
        # "低速高密度、车距接近一个车身"：10 m/s 与 5 m 间距在 IDM 下不可共存
        # （期望安全中心距 = g0 + v·T + 车长 = 10.6 m），必然导致幽灵刹车/队列压死。
        # 故默认取 6 m/s：IDM 安全中心距 8.6 m → 净间隙 5.0 m，正好落在论文式62
        # 的 3.5~5.0 m 奖励区间；可用 DSH_TRAFFIC_V 覆盖（10 会回到旧口径的物理冲突区）。
        self.cross_traffic_v = float(os.environ.get('DSH_TRAFFIC_V', '6.0'))
        self.cross_traffic_volume = 0.4    # 保留字段（实际生成间隔由 IDM 安全距离反推）
        self.cross_traffic = CrossTrafficManager(
            self.world, self.map, self.cross_traffic_v, self.cross_traffic_volume
        )

        # ===== 冲突信息（博弈链路用）=====
        self.cross_conflict_id = -1
        self.cross_conflict_ttc = float('inf')

        # ===== 记录（可用 DSH_SAVE_DIR 重定向，便于多配置 A/B 隔离）=====
        self.log_dir = os.path.join(
            os.environ.get('DSH_SAVE_DIR',
                           os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),  # Test_Scenarios -> Algorithms
            "record_turn.txt")
        os.makedirs(os.path.dirname(self.log_dir), exist_ok=True)
        self.task_num = 0
        self.stuck_num = 0
        self.collision_num = 0
        self.case_id = 0

        self.set_fixed_vehicle_points()
        self.has_set = np.zeros(1000000)
        self.stopped_time = np.zeros(1000000)
        self.vehicles_with_bbox = []
        self.state_obj = []

    def free_traffic_lights(self, carla_world):
        for tl in carla_world.get_actors().filter('*traffic_light*'):
            tl.set_green_time(5)
            tl.set_red_time(5)

    def global_routing(self):
        grp = GlobalRoutePlanner(self.map, sampling_resolution=1)
        current_route = grp.trace_route(
            carla.Location(start_point.location.x, start_point.location.y, start_point.location.z),
            carla.Location(goal_point.location.x, goal_point.location.y, goal_point.location.z)
        )
        self.ref_path = Lane()
        t_array = []
        for wp in current_route:
            lanepoint = Lanepoint()
            lanepoint.position.x = wp[0].transform.location.x
            lanepoint.position.y = wp[0].transform.location.y
            self.ref_path.central_path.append(lanepoint)
            t_array.append(lanepoint)
        self.ref_path.central_path_array = np.array(t_array)
        self.ref_path.speed_limit = 60 / 3.6
        ref_path_ori = convert_path_to_ndarray(self.ref_path.central_path)
        self.ref_path_array = dense_polyline2d(ref_path_ori, 2)
        self.ref_path_tangets = np.zeros(len(self.ref_path_array))
        if os.environ.get('DSH_FORECAST_MODEL') in ('route_v17','route_v18'):
            from Planning_library.forecast_v17 import road_continuation
            self.forecast_ref_path_array = road_continuation(self.ref_path_array, current_route[-1][0])

    def set_fixed_vehicle_points(self):
        """转弯场景无需固定车辆——博弈对象由 CrossTrafficManager 动态生成"""
        self.spawn_env_vehicle_points = []

    def reset(self, train=True):
        self.completion_diag = {}
        self.last_control = {}
        self.vehicles_with_bbox = []
        self.state_obj = []
        self.spawn_ego_veh()
        self.spawn_fixed_veh()
        self.cross_traffic.reset()
        if self.traffic_enabled:
            for spawn_pt in self.cross_traffic.init_traffic_flow():
                self.cross_traffic.spawn_vehicle(spawn_pt)
        self.world.tick()
        self.stuck_time = None
        self.sim_frame = 0
        self._stuck_start_frame = None
        self.initial_yaw = math.radians(self.ego_vehicle.get_transform().rotation.yaw)
        state, state_ori = self.wrap_state()
        self.last_state = state_ori
        self.record_information_txt()
        self.task_num += 1
        self.case_id += 1
        self.driving_speed = []
        self.cross_conflict_id = -1
        self.cross_conflict_ttc = float('inf')
        return state, state_ori

    def step(self, action, trust_RL=True, game_fall=False, target_speed=None):
        # v9 uses explicit feedback pedals; v8 native behavior is preserved for
        # reproducibility. Neither requested acceleration is a measurement.
        a_cmd = float(action[0])
        before = self.world.get_snapshot()
        velocity = self.ego_vehicle.get_velocity()
        speed_before = math.hypot(velocity.x, velocity.y)
        explicit = getattr(self, 'pedal_control', False)
        synchronized = getattr(self, 'synchronous_control', False)
        if synchronized:
            ego_before = before.find(self.ego_vehicle.id)
            if ego_before is None:
                raise RuntimeError('Ego missing from pre-control snapshot')
            velocity = ego_before.get_velocity()
            speed_before = math.hypot(velocity.x, velocity.y)
        if explicit:
            if target_speed is None:
                raise ValueError('paper_v9 needs the final target speed for execution')
            transform_before = ego_before.get_transform() if synchronized else self.ego_vehicle.get_transform()
            signed_before = signed_speed(velocity, transform_before.rotation.yaw)
            request = self.pedal_controller.command(a_cmd, speed_before, target_speed, action[1])
            if not synchronized:
                self.ego_vehicle.apply_control(carla.VehicleControl(**request))
        elif getattr(self, 'native_control', False):
            if target_speed is None:
                raise ValueError('paper_v8 needs the final target speed for execution')
            request = ackermann_target(a_cmd, speed_before, target_speed, action[1],
                                       self.control_geometry['max_steer'])
            self.ego_vehicle.apply_ackermann_control(carla.VehicleAckermannControl(**request))
        else:
            throttle = float(np.clip(a_cmd/2., 0., 1.)) if a_cmd >= 0. else 0.
            brake = float(np.clip(-a_cmd/3., 0., 1.)) if a_cmd < 0. else 0.
            steer = float(np.clip(action[1], -1., 1.))
            self.ego_vehicle.apply_control(carla.VehicleControl(throttle=throttle, brake=brake, steer=steer))

        if getattr(self, 'traffic_enabled', True):
            _, conflict_id, conflict_ttc = self.cross_traffic.run_step(self.ego_vehicle)
        else:
            from Planning_library.interaction_logger import get_logger
            get_logger().tick()
            conflict_id, conflict_ttc = -1, float('inf')
        self.cross_conflict_id = conflict_id
        self.cross_conflict_ttc = conflict_ttc if conflict_ttc < float('inf') else float('inf')
        if synchronized:
            submit_control(self.client, carla.command, self.ego_vehicle.id, carla.VehicleControl(**request))
        tick_frame = self.world.tick()
        self.sim_frame += 1
        after = self.world.get_snapshot()
        elapsed = after.timestamp.elapsed_seconds-before.timestamp.elapsed_seconds
        velocity = self.ego_vehicle.get_velocity()
        if synchronized:
            if after.frame != tick_frame:
                raise RuntimeError('Returned tick frame differs from received snapshot')
            ego_after = after.find(self.ego_vehicle.id)
            if ego_after is None:
                raise RuntimeError('Ego missing from post-control snapshot')
            velocity = ego_after.get_velocity()
        speed_after = math.hypot(velocity.x, velocity.y)
        if getattr(self, 'native_control', False) or explicit:
            if abs(elapsed-self.dt) > 1e-4 or after.frame-before.frame != 1:
                raise RuntimeError('Unexpected simulator tick: frames=%s dt=%s; check other clients'
                                   % (after.frame-before.frame, elapsed))
            applied = self.ego_vehicle.get_control()
            throttle, brake, steer = float(applied.throttle), float(applied.brake), float(applied.steer)
            delta = steer*self.control_geometry['max_steer']
        else:
            delta = float(action[1])
        self.last_control = dict(a_cmd=a_cmd, delta_rad=delta, throttle=throttle, brake=brake, steer=steer,
            actuator_mode=('feedback_pedal_v11' if getattr(self.pedal_controller, 'revision', 10) == 11 else 'feedback_pedal_v10') if synchronized else ('feedback_pedal_v9' if explicit else (
                'ackermann' if getattr(self, 'native_control', False) else 'legacy_pedal')),
            sim_frame_before=before.frame, sim_frame_after=after.frame,
            sim_time_before=before.timestamp.elapsed_seconds, sim_time_after=after.timestamp.elapsed_seconds,
            sim_dt=elapsed, ego_v_before=speed_before, ego_v_after=speed_after,
            ego_acc_measured=(speed_after-speed_before)/elapsed if elapsed > 0. else None,
            actuator_speed_target=request['speed'] if getattr(self, 'native_control', False) else None,
            actuator_accel_limit=request['acceleration'] if getattr(self, 'native_control', False) else None,
            physical_max_steer=getattr(self, 'control_geometry', {}).get('max_steer'),
            wheelbase=getattr(self, 'control_geometry', {}).get('wheelbase'))
        if explicit:
            transform_after = ego_after.get_transform() if synchronized else self.ego_vehicle.get_transform()
            signed_after = signed_speed(velocity, transform_after.rotation.yaw)
            if synchronized:
                self.pedal_controller.acknowledge_pedals(throttle, brake, steer)
            self.pedal_controller.observe(signed_before, signed_after, elapsed)
            acceleration = ego_after.get_acceleration() if synchronized else self.ego_vehicle.get_acceleration()
            forward = transform_after.get_forward_vector()
            self.last_control.update(
                actuator_speed_target=max(0., float(target_speed)), actuator_accel_limit=3.,
                ego_v_signed_before=signed_before, ego_v_signed_after=signed_after,
                ego_acc_signed=self.pedal_controller.raw_acceleration,
                ego_acc_sensor=float(acceleration.x*forward.x+acceleration.y*forward.y),
                actuator_filtered_acc=self.pedal_controller.acceleration,
                actuator_integral=self.pedal_controller.integral, actuator_pedal_mode=self.pedal_controller.mode,
                requested_throttle=request['throttle'], requested_brake=request['brake'],
                requested_steer=request['steer'], brake_static_gain=self.pedal_controller.brake_gain,
                gear=int(applied.gear), reverse=int(applied.reverse), hand_brake=int(applied.hand_brake),
                manual_gear_shift=int(applied.manual_gear_shift))
            if synchronized:
                self.last_control.update(control_transport='batch_sync_pre_tick', control_submit_ok=1,
                    control_tick_frame=tick_frame, control_feedback_frame=self.world.get_snapshot().frame,
                    physics_max_substep_dt=self.physics_timing['max_substep_delta_time'],
                    brake_release_active=int(self.pedal_controller.release_active),
                    brake_release_seconds=self.pedal_controller.release_seconds,
                    brake_release_events=self.pedal_controller.release_events,
                    actuator_a_target=self.pedal_controller.target_acceleration)
        self.update_vehicle_bboxes()

        state, state_ori = self.wrap_state()
        ego_speed = math.sqrt(state_ori[2]**2 + state_ori[3]**2)
        self.driving_speed.append(ego_speed)

        if self.should_debug:
            ego_z = self.ego_vehicle.get_location().z
            start_loc = carla.Location(x=self.last_state[0], y=self.last_state[1], z=ego_z + 0.1)
            end_loc = carla.Location(x=state_ori[0], y=state_ori[1], z=ego_z + 0.1)
            color = carla.Color(r=13, g=13, b=13, a=255) if trust_RL else carla.Color(r=255, g=255, b=255, a=255)
            self.debug.draw_line(start_loc, end_loc, color=color, life_time=10)
        self.last_state = state_ori

        # 奖励
        # 1. 先计算物理量（注意顺序：先算曲率，再算安全速度）
        curvature = self._get_current_curvature()
        safe_speed = self._safe_turn_speed(curvature)
        
        # 2. 速度奖励
        speed_reward = min(ego_speed, safe_speed) if curvature > 0.01 else ego_speed
        
        # 3. 舒适度惩罚
        acc = self.ego_vehicle.get_acceleration()
        acc_mag = math.sqrt(acc.x**2 + acc.y**2 + acc.z**2)
        comfort_penalty = -1.0 * (acc_mag ** 2) if acc_mag > 2 else 0.0
        
        # 4. 超速惩罚
        overspeed_penalty = -10.0 * max(0, ego_speed - safe_speed) if curvature > 0.01 else 0.0
        
        # 5. 横向偏移惩罚
        lat_error = self._get_lateral_error()
        lane_penalty = -5.0 * (lat_error ** 2)
        
        # 6. 碰撞与完成奖励
        collision_penalty = -200 if self.ego_vehicle_collision_sign else 0
        turn_bonus = 50.0 if self._turn_complete() else 0.0

        reward = np.array([speed_reward, comfort_penalty, overspeed_penalty + lane_penalty, collision_penalty + turn_bonus])

        done = False
        if self.ego_vehicle_collision_sign:
            self.collision_num += 1
            done = True
            print("[TurnEnv]: Collision!")
        elif self._turn_complete():
            done = True
            avg_speed = sum(self.driving_speed) / len(self.driving_speed) if self.driving_speed else 0
            print(f"[TurnEnv]: Turn complete! Avg speed: {avg_speed:.2f} m/s")
        elif self.ego_vehicle_stuck():
            self.stuck_num += 1
            done = True
            print("[TurnEnv]: Stuck!")
        return state, reward, done, state_ori

    def wrap_state(self, use_ego_coordinate=True):
        ego_state = [
            self.ego_vehicle.get_location().x,
            self.ego_vehicle.get_location().y,
            self.ego_vehicle.get_velocity().x,
            self.ego_vehicle.get_velocity().y,
            math.radians(self.ego_vehicle.get_transform().rotation.yaw),
        ]
        state_ori = ego_state.copy()
        state = ego_state.copy() if not use_ego_coordinate else self._to_ego_coord(ego_state)
        for obj in self.state_obj[:3]:
            obj_state = [
                obj.get_location().x, obj.get_location().y,
                obj.get_velocity().x, obj.get_velocity().y,
                math.radians(obj.get_transform().rotation.yaw),
            ]
            state_ori += obj_state
            if use_ego_coordinate:
                coord = Coordinates(ego_state[0], ego_state[1], ego_state[4])
                state += list(coord.transfer_coordinate(*obj_state))
        return np.array(state[:20]), np.array(state_ori[:20])

    def _to_ego_coord(self, ego_state):
        coord = Coordinates(ego_state[0], ego_state[1], ego_state[4])
        return list(coord.transfer_coordinate(*ego_state[:5]))

    def _get_current_curvature(self):
        if hasattr(self, 'ref_path_array') and len(self.ref_path_array) > 3:
            ego_x = self.ego_vehicle.get_location().x
            ego_y = self.ego_vehicle.get_location().y
            distances = np.sqrt((self.ref_path_array[:, 0] - ego_x)**2 + (self.ref_path_array[:, 1] - ego_y)**2)
            idx = np.argmin(distances)
            i1, i2, i3 = max(0, idx - 5), idx, min(len(self.ref_path_array) - 1, idx + 5)
            if i3 - i1 > 3:
                return self._calc_curvature(i1, i2, i3)
        return 0.0

    def _calc_curvature(self, i1, i2, i3):
        a = math.sqrt((self.ref_path_array[i2][0] - self.ref_path_array[i1][0])**2 + (self.ref_path_array[i2][1] - self.ref_path_array[i1][1])**2)
        b = math.sqrt((self.ref_path_array[i3][0] - self.ref_path_array[i2][0])**2 + (self.ref_path_array[i3][1] - self.ref_path_array[i2][1])**2)
        c = math.sqrt((self.ref_path_array[i3][0] - self.ref_path_array[i1][0])**2 + (self.ref_path_array[i3][1] - self.ref_path_array[i1][1])**2)
        if a * b * c < 1e-10:
            return 0.0
        s = (a + b + c) / 2.0
        area = math.sqrt(max(0, s * (s-a) * (s-b) * (s-c)))
        if area < 1e-10:
            return 0.0
        return 1.0 / ((a * b * c) / (4.0 * area))

    def _safe_turn_speed(self, curvature):
        if abs(curvature) < 1e-6:
            return 16.67
        return np.clip(math.sqrt(0.7 * 9.8 / abs(curvature)), 1.0, 16.67)

    def _get_lateral_error(self):
        if hasattr(self, 'ref_path_array') and len(self.ref_path_array) > 0:
            ego_x = self.ego_vehicle.get_location().x
            ego_y = self.ego_vehicle.get_location().y
            distances = np.sqrt((self.ref_path_array[:, 0] - ego_x)**2 + (self.ref_path_array[:, 1] - ego_y)**2)
            idx = np.argmin(distances)
            rx, ry = self.ref_path_array[idx][0], self.ref_path_array[idx][1]
            return math.sqrt((ego_x - rx)**2 + (ego_y - ry)**2)
        return 0.0

    def _distance_to_goal(self):
        ego_loc = self.ego_vehicle.get_location()
        return math.sqrt((ego_loc.x - goal_point.location.x)**2 + (ego_loc.y - goal_point.location.y)**2)

    def _turn_complete(self):
        transform = self.ego_vehicle.get_transform()
        goal = goal_point.location
        metrics = completion_metrics(
            transform.location.x, transform.location.y,
            math.radians(transform.rotation.yaw), goal.x, goal.y,
            math.radians(goal_point.rotation.yaw), getattr(self, 'ref_path_array', None))
        metrics['legacy_complete'] = bool(self._turn_complete_legacy())
        self.completion_diag = metrics
        if getattr(self, 'completion_mode', 'strict') == 'legacy':
            return metrics['legacy_complete']
        return metrics['strict_complete']

    def _turn_complete_legacy(self):
        """保留旧判据供对照；两种完成信号都会写入诊断日志。"""
        current_yaw = math.radians(self.ego_vehicle.get_transform().rotation.yaw)
        yaw_change = abs(_normalize_angle(current_yaw - self.initial_yaw))
        if yaw_change <= 1.4:
            return False

        distance_to_goal = self._distance_to_goal()
        # ===== 【修改1】从 8.0 米改到 4.0 米 =====
        if distance_to_goal < 4.0:
            return True

        if hasattr(self, 'ref_path_array') and len(self.ref_path_array) > 0:
            ego_x = self.ego_vehicle.get_location().x
            ego_y = self.ego_vehicle.get_location().y
            distances = np.sqrt((self.ref_path_array[:, 0] - ego_x)**2 + (self.ref_path_array[:, 1] - ego_y)**2)
            idx = np.argmin(distances)
            progress = idx / max(1, len(self.ref_path_array) - 1)
            # ===== 【修改2】progress 从 0.85 改到 0.90，距离从 20.0 改到 12.0 =====
            return progress > 0.90 and distance_to_goal < 12.0

        return False

    def ego_vehicle_stuck(self, stay_thres=None):
        # ===== 【P0 修复】基于仿真帧的卡死检测（旧版用墙钟 time.time：训练机负载高时，
        # 停车让行(3~5 仿真秒)会被误判为卡死 → 规则层被迫蠕动躲卡死 → 反而被车流撞上）。
        # 帧数×dt 才是真正的仿真时长。
        #
        # 【P1-c 放宽】阈值 15s → DSH_STUCK_SEC(默认 40s)：
        #   ① 博弈本身可能判定"确实无法插入"，此时**等整列车流离开后再左转是合法策略**
        #      （导师确认）；P0-3 之后车流是 14 辆 × 1.43s ≈ 20s 连续流，
        #      15s 会在车流还没走完时就判卡死（−100），等于禁止"等待"这条合法策略。
        #   ② 注意：这里只放松**判定**，不再恢复"等待 +5/帧"的奖励
        #      （那会造成奖励劫持，见 reward_components 注释）。
        #      现在是靠**终局**给激励：完成 +150 / 超时 −100 / 碰撞 −300
        #      ⇒ 只要 P(碰撞) < 83%，"尝试过弯"的期望值就优于"一直等到超时"，
        #        所以放宽阈值不会退化成"永远不尝试"。
        #   可用 DSH_STUCK_SEC 覆盖（对照实验：15 = 旧行为）。
        if stay_thres is None:
            stay_thres = float(os.environ.get('DSH_STUCK_SEC', '40.0'))
        if self._stuck_start_frame is None:
            self._stuck_start_frame = self.sim_frame
            return False
        v = self.ego_vehicle.get_velocity()
        speed = math.sqrt(v.x**2 + v.y**2 + v.z**2)
        if speed < 0.2:
            if (self.sim_frame - self._stuck_start_frame) * self.dt > stay_thres:
                return True
        else:
            self._stuck_start_frame = self.sim_frame
        return False

    def _on_ego_collision(self, event):
        """碰撞传感器回调：记录**真实碰撞对象**及其当时状态。

        【为什么要这个埋点】此前监听器只做 `setattr(self, 'ego_vehicle_collision_sign', True)`，
        真实碰撞 actor 被丢弃。于是离线分析只能拿"末帧离 ego 最近的 RV"当**代理**，
        无法回答"到底撞的是谁、它当时是让行还是抢行、速度多少"。
        有了这个埋点，A/B/C/D 分类从"代理推断"变成"事实"。

        在回调线程里就地读值（actor 事后可能被销毁）；只记**第一次**碰撞
        （一次碰撞会触发多次回调，否则会覆盖成最后一次的状态）。
        """
        self.ego_vehicle_collision_sign = True
        if getattr(self, 'ego_collision_event', None) is not None:
            return
        info = {'frame': int(getattr(self, 'sim_frame', -1))}
        try:
            oa = event.other_actor
            info['other_id'] = int(getattr(oa, 'id', -1))
            try:
                info['other_type'] = str(oa.type_id)
            except Exception:
                info['other_type'] = ''
            try:
                info['other_role'] = str(oa.attributes.get('role_name', ''))
            except Exception:
                info['other_role'] = ''
            try:
                tf = oa.get_transform()
                info['other_x'] = float(tf.location.x)
                info['other_y'] = float(tf.location.y)
                info['other_yaw'] = float(tf.rotation.yaw)
            except Exception:
                pass
            try:
                ov = oa.get_velocity()
                info['other_v'] = float(math.sqrt(ov.x ** 2 + ov.y ** 2 + ov.z ** 2))
            except Exception:
                info['other_v'] = None
        except Exception as e:
            info['error'] = f'{type(e).__name__}: {e}'
        try:
            etf = event.actor.get_transform()
            info['ego_x'] = float(etf.location.x)
            info['ego_y'] = float(etf.location.y)
        except Exception:
            pass
        self.ego_collision_event = info

    def spawn_ego_veh(self):
        if self.ego_vehicle is not None:
            self.ego_collision_sensor.destroy()
            self.ego_vehicle.destroy()
        self.ego_vehicle = self.world.spawn_actor(self.ego_vehicle_bp, ego_spawn_point)
        self.ego_collision_sensor = self.world.spawn_actor(
            self.ego_collision_bp, Transform(),
            attach_to=self.ego_vehicle, attachment_type=carla.AttachmentType.Rigid
        )
        self.ego_collision_sensor.listen(self._on_ego_collision)
        self.ego_vehicle_collision_sign = False
        self.ego_collision_event = None
        if getattr(self, 'pedal_control', False):
            initial_control = carla.VehicleControl(brake=.05, hand_brake=False, reverse=False)
            if self.synchronous_control:
                submit_control(self.client, carla.command, self.ego_vehicle.id, initial_control)
            else:
                self.ego_vehicle.apply_control(initial_control)
        elif getattr(self, 'native_control', False):
            if not hasattr(self.ego_vehicle, 'apply_ackermann_control'):
                raise RuntimeError('Server/client lacks native Ackermann control; use CARLA 0.9.15')
            self.ego_vehicle.apply_ackermann_control(
                carla.VehicleAckermannControl(speed=0., acceleration=1.))
        for _ in range(20):
            self.world.tick()
        if getattr(self, 'native_control', False) or getattr(self, 'pedal_control', False):
            if self.native_control and not hasattr(self.ego_vehicle, 'apply_ackermann_control'):
                raise RuntimeError('Server/client lacks native Ackermann control; use CARLA 0.9.15')
            physics = self.ego_vehicle.get_physics_control()
            self.control_geometry = physical_geometry(physics)
            if self.synchronous_control:
                # A declared conservative audit model, not identified physics.
                self.control_geometry.update(brake_response_jerk=.5, execution_horizon=6.)
            if self.pedal_control:
                controller_type = PedalControllerV10 if self.synchronous_control else PedalController
                if os.environ.get('DSH_CONTROL_PROFILE') == 'paper_v11':
                    controller_type = PedalControllerV11
                    self.control_geometry['low_speed_brake_taper'] = .5
                self.pedal_controller = controller_type(brake_deceleration(physics),
                    self.control_geometry['max_steer'], self.dt)
            metadata = dict(profile='paper_v10' if self.synchronous_control else (
                    'paper_v9' if self.pedal_control else 'paper_v8'),
                actuator='feedback_pedal_v10' if self.synchronous_control else (
                    'feedback_pedal_v9' if self.pedal_control else 'carla_native_ackermann'),
                client_version=self.client.get_client_version(), server_version=self.client.get_server_version(),
                geometry=self.control_geometry, mass=float(physics.mass), blueprint=self.ego_vehicle.type_id,
                traffic='on' if self.traffic_enabled else 'off', dt=self.dt,
                wheel_positions_cm=[[float(w.position.x), float(w.position.y), float(w.position.z)]
                                    for w in physics.wheels],
                steering_curve=[[float(p.x), float(p.y)] for p in physics.steering_curve],
                ackermann_settings=str(self.ego_vehicle.get_ackermann_controller_settings()))
            if self.pedal_control:
                metadata.update(brake_static_gain=self.pedal_controller.brake_gain,
                    wheel_brakes=[dict(radius_cm=float(w.radius), max_brake_torque_nm=float(w.max_brake_torque),
                        max_handbrake_torque_nm=float(w.max_handbrake_torque),
                        damping_rate=float(w.damping_rate), tire_friction=float(w.tire_friction)) for w in physics.wheels],
                    drivetrain={key: getattr(physics, key) for key in (
                        'max_rpm', 'moi', 'damping_rate_full_throttle', 'damping_rate_zero_throttle_clutch_engaged',
                        'damping_rate_zero_throttle_clutch_disengaged', 'use_gear_autobox',
                        'gear_switch_time', 'clutch_strength', 'final_ratio')},
                    pedal_gains=dict(throttle_acceleration_gain=3., coast_compensation=.35,
                        acceleration_kp=.25, acceleration_ki=.4, throttle_max=.65,
                        brake_max=.4, brake_rise_acceleration_per_s=3., throttle_rise_per_s=1.))
                if self.synchronous_control:
                    metadata.update(physics_timing=dict(self.physics_timing),
                        control_transport='batch_sync_pre_tick')
                    metadata['pedal_gains'].update(brake_feedback='incremental_measured_acceleration',
                        brake_correction_per_s=.8, brake_rise_acceleration_per_s=.75,
                        brake_release_min_seconds=.25, brake_release_stable_seconds=.15,
                        brake_release_stable_acceleration=1.5)
            destination = os.environ.get('DSH_SAVE_DIR')
            if isinstance(getattr(self, 'pedal_controller', None), PedalControllerV11):
                metadata.update(profile='paper_v11', actuator='feedback_pedal_v11')
                metadata['pedal_gains'].update(low_speed_threshold=1.2, low_speed_target_gain=1.5,
                    low_speed_brake_cap=.12, hold_brake=.02, throttle_rise_per_s=.5,
                    stationary_throttle_cap=.35, throttle_speed_gain=.25,
                    brake_rise_acceleration_per_s=2.,
                    positive_acceleration_release=4.5, calibrated=False)
            if destination:
                folder = Path(destination)
                folder.mkdir(parents=True, exist_ok=True)
                (folder/'control_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf8')
            print('[TurnEnv] execution: '+json.dumps(metadata))
        if self.ego_vehicle is not None and not (getattr(self, 'native_control', False) or
                                                getattr(self, 'pedal_control', False)):
            yaw = math.radians(ego_spawn_point.rotation.yaw)
            self.ego_vehicle.set_target_velocity(carla.Vector3D(
                x=math.cos(yaw) * 10 / 3.6, y=math.sin(yaw) * 10 / 3.6, z=0.0
            ))

    def spawn_fixed_veh(self):
        actor_list = self.world.get_actors()
        for v in actor_list.filter("*vehicle*"):
            if v.attributes.get('role_name') != "ego_vehicle":
                v.destroy()
        time.sleep(0.5)
        for transform, bp, autopilot, _ in self.spawn_env_vehicle_points:
            vehicle = self.world.spawn_actor(bp, transform)
            if autopilot:
                vehicle.set_autopilot(True, self.tm.get_port())

    def update_vehicle_bboxes(self):
        for vehicle in self.vehicles_with_bbox:
            if vehicle is not None and vehicle.is_active:
                bbox = vehicle.bounding_box
                transform = vehicle.get_transform()
                vertices = [
                    carla.Location(x=bbox.extent.x, y=bbox.extent.y, z=bbox.extent.z),
                    carla.Location(x=-bbox.extent.x, y=bbox.extent.y, z=bbox.extent.z),
                    carla.Location(x=-bbox.extent.x, y=-bbox.extent.y, z=bbox.extent.z),
                    carla.Location(x=bbox.extent.x, y=-bbox.extent.y, z=bbox.extent.z),
                ]
                world_v = [transform.transform(v + bbox.location) for v in vertices]
                for e in [(0,1),(1,2),(2,3),(3,0)]:
                    self.world.debug.draw_line(world_v[e[0]], world_v[e[1]], thickness=0.1, color=carla.Color(0,255,0), life_time=0.1)

    def record_information_txt(self):
        if self.task_num > 0:
            stuck_rate = float(self.stuck_num) / float(self.task_num)
            collision_rate = float(self.collision_num) / float(self.task_num)
            pass_rate = 1 - (collision_rate + stuck_rate)
            with open(self.log_dir, 'a') as fw:
                fw.write(f"{self.task_num}, {self.case_id}, {self.stuck_num}, {self.collision_num}, {stuck_rate:.3f}, {collision_rate:.3f}, {pass_rate:.3f}\n")
            print(f"[TurnEnv]: Task={self.task_num}, Stuck={self.stuck_num}, Collision={self.collision_num}")

    def spectator_update(self):
        ego_loc = self.ego_vehicle.get_transform().location
        self.spectator.set_transform(
            carla.Transform(ego_loc + carla.Location(z=25, y=0, x=5), carla.Rotation(pitch=-90, yaw=180))
        )

    def draw_traj(self, trajectories):
        """
        函数功能:绘制轨迹,不考虑轨迹值.
        输入:
            trajectories:轨迹列表.
        输出:
            无
        """
        if self.should_debug:
            for j, trajectory in enumerate(trajectories):
                traj = trajectory[0]
                thickness = 0.1     # 设置固定的线宽为0.05
                for i in range(len(traj.x)-1):
                    start_loc = carla.Location(x = traj.x[i],y = traj.y[i],z = 0.5)
                    end_loc = carla.Location(x = traj.x[i+1],y = traj.y[i+1],z = 0.5)
                    self.debug.draw_arrow(start_loc, end_loc, thickness = thickness, arrow_size=0.01, life_time = 0.5)
            self.world.tick()

    def draw_traj_HRL(self, trajectories, HRL_state_value, rule_act_idx):
        """
        函数功能:可视化不同轨迹，通过颜色区分规则选择的轨迹，通过线宽表示轨迹价值，用于调试和可视化分析
        输入:
            trajectories:轨迹列表.
            state_value:状态值.
            HRL_state_value:层次强化学习的状态值.
            rule_act_idx:规则动作索引.
        输出:
            无
        """
        if self.should_debug:
            if len(trajectories) == 1:
                traj = trajectories[0][0]
                traj_value = 0.1
                value_thickness = 0.1
                color = carla.Color(r=13, g=13, b=13, a=255)

                # 绘制轨迹
                for i in range(len(traj.x)-1):
                    start_loc = carla.Location(x = traj.x[i],y = traj.y[i],z = 0.5)
                    end_loc = carla.Location(x = traj.x[i+1],y = traj.y[i+1],z = 0.5)

                    # 不想绘制可以隐藏下面这行代码
                    # self.debug.draw_arrow(start_loc, end_loc, thickness = value_thickness, arrow_size=0.01, color=color, life_time = 2)
                    self.debug.draw_line(start_loc, end_loc, thickness = value_thickness, color=color, life_time = 2)

                self.world.tick()

            else:
                # 获取HRL状态值的最大值和最小值，用于后续的归一化处理
                max_value = max(HRL_state_value)
                min_value = min(HRL_state_value)

                for j, trajectory in enumerate(trajectories):
                    # 计算轨迹值
                    traj = trajectory[0]
                    traj_value = (HRL_state_value[j+1] - min_value) / (max_value - min_value)
                    
                    # 设置线宽范围：0.01到0.根据轨迹值计算实际线宽
                    min_thickness = 0.01
                    max_thickness = 0.1
                    value_thickness = float(min_thickness + (max_thickness - min_thickness)*traj_value)
                    # value_thickness = 0.1
                    
                    # 规则动作选择的轨迹用红色表示，其他轨迹用深灰色表示
                    if j == rule_act_idx - 1:
                        color = carla.Color(r=255, g=0, b=0, a=255)
                    else:
                        color = carla.Color(r=13, g=13, b=13, a=255)

                    # 绘制轨迹
                    for i in range(len(traj.x)-1):
                        start_loc = carla.Location(x = traj.x[i],y = traj.y[i],z = 1.5)
                        end_loc = carla.Location(x = traj.x[i+1],y = traj.y[i+1],z = 1.5)

                        # 不想绘制可以隐藏下面这行代码
                        # self.debug.draw_arrow(start_loc, end_loc, thickness = value_thickness, arrow_size=0.01, color=color, life_time = 2)
                        self.debug.draw_line(start_loc, end_loc, thickness = value_thickness, color=color, life_time = 2)

                self.world.tick()

    def cleanup(self):
        print("[TurnEnv]: Cleaning up...")
        settings = self.world.get_settings()
        settings.synchronous_mode = False
        self.world.apply_settings(settings)
        for actor in self.world.get_actors().filter('vehicle*'):
            actor.destroy()
        print("[TurnEnv]: Done.")


def _normalize_angle(angle):
    while angle > math.pi:
        angle -= 2 * math.pi
    while angle < -math.pi:
        angle += 2 * math.pi
    return angle
