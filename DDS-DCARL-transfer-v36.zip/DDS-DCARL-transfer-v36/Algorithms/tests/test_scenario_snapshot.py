#!/usr/bin/env python3
"""阶段 0：场景快照 fixture 的单元测试（纯 stdlib unittest，无需 CARLA）。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.scenario_snapshot import make_fixture


class TestScenarioSnapshot(unittest.TestCase):

    def test_fixture_determinism(self):
        a, b = make_fixture(1), make_fixture(1)
        self.assertEqual(a.ego.x, b.ego.x)
        self.assertEqual(a.ego.y, b.ego.y)
        self.assertEqual(a.t_ego, b.t_ego)
        self.assertEqual(len(a.vehicles), len(b.vehicles))
        self.assertEqual([v.x for v in a.vehicles], [v.x for v in b.vehicles])

    def test_case1_gap_sufficient(self):
        s = make_fixture(1)
        rv = [v for v in s.vehicles if v.role == "rv"][0]
        t_veh = (rv.x - s.conflict_xy[0]) / rv.v
        self.assertGreater(t_veh - s.t_ego, 2.5)  # Δt≈2.9s，间隙充足

    def test_case3_gap_insufficient(self):
        s = make_fixture(3)
        rv = [v for v in s.vehicles if v.role == "rv"][0]
        t_veh = (rv.x - s.conflict_xy[0]) / rv.v
        self.assertLessEqual(t_veh, s.t_ego)  # rv 不晚于自车到冲突点，应让行

    def test_case6_committed(self):
        s = make_fixture(6)
        self.assertTrue(s.committed)
        self.assertLess(s.ego.y, s.conflict_xy[1])

    def test_all_cases_build(self):
        for i in range(1, 7):
            s = make_fixture(i)
            self.assertIsNotNone(s.ego)
            self.assertEqual(len(s.conflict_xy), 2)

    def test_invalid_case_raises(self):
        with self.assertRaises(ValueError):
            make_fixture(99)


if __name__ == "__main__":
    unittest.main()
