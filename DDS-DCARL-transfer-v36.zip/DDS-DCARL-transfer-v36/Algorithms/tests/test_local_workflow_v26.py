"""Local-map regression must detect API fallback and preserve failed evidence."""
import contextlib
import hashlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import test_rolling_workflow_v25 as old_fixtures


class LocalWorkflowTests(unittest.TestCase):
    def workflow(self):
        try: return importlib.import_module('Tools.run_local_road_validation_v26')
        except ImportError: self.fail('No v26 local-road validation workflow')

    def boundary(self,cmd,queries=0,missing=False):
        result=old_fixtures.RollingWorkflowV25Tests().boundary(cmd)
        root=Path(cmd[cmd.index('--output-root')+1])
        for directory in root.glob('T*_seed*'):
            xodr=b'<OpenDRIVE/>'; (directory/'public_map_v24.xodr').write_bytes(xodr)
            corridor=dict(revision='analytic_local_road_v26',runtime_map_queries=False,
                geometry='line_arc_piecewise_cubic_lanes_2d',bounds_xyxy=[0.,0.,20.,20.],
                setup_map_queries=20,route_samples=20,setup_map_exports=1,setup_ms=2.,
                opendrive_sha256=hashlib.sha256(xodr).hexdigest())
            meta=json.loads((directory/'rolling_metadata_v24.json').read_text())
            meta['corridor']=corridor
            (directory/'rolling_metadata_v24.json').write_text(json.dumps(meta),encoding='utf8')
            if not missing:
                (directory/'local_road_region_v26.json').write_text(json.dumps(corridor),encoding='utf8')
            records=[json.loads(v) for v in (directory/'matrix_decisions.jsonl').read_text().splitlines()]
            records=records+records
            for i,row in enumerate(records,1):
                row['frame']=i; p=row['rolling_trajectory']
                p['road_revision']='analytic_local_road_v26'
                p['map_statistics'].update(map_queries=queries,map_cache_hits=0,map_query_ms=0.,local_points=33,local_query_ms=.1)
            (directory/'matrix_decisions.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records),encoding='utf8')
        return result

    def test_default_is_a_16_episode_engineering_regression_and_full_plan_is_explicit(self):
        w=self.workflow(); stages=w.build_plan(Path('unused'))
        self.assertEqual([s['episodes_total'] for s in stages],[4,12])
        self.assertTrue(all(s['arguments'][-2:]==['--road-audit','local_v26'] for s in stages))
        full=w.build_plan(Path('unused'),full_learning=True)
        self.assertEqual([s['episodes_total'] for s in full],[4,12,20,12])

    def test_nonzero_runtime_map_queries_fail_before_probe_and_keep_archive(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd,queries=1)),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(out)])
            self.assertNotEqual(code,0); self.assertFalse((out/'01_probe').exists())
            self.assertTrue(Path(str(out)+'.tar.gz').exists())
            report=json.loads((out/'ROLLING_REPORT.json').read_text())
            self.assertGreater(report['v26_local_road']['errors']['runtime_map_api'],0)

    def test_missing_map_snapshot_is_not_accepted(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd,missing=True)),contextlib.redirect_stdout(io.StringIO()):
                self.assertNotEqual(w.main(['--output-root',str(out)]),0)

    def test_default_completes_without_training_expansion_or_benefit_claim(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd)),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(w.main(['--output-root',str(out)]),0)
            report=json.loads((out/'ROLLING_REPORT.json').read_text())
            self.assertEqual(report['actual_episodes'],16)
            self.assertTrue(report['v26_local_road']['ok'])
            self.assertFalse(report['benefit_established']); self.assertFalse(report['efe_enabled'])
            self.assertFalse((out/'02_train').exists())

    def test_optional_full_protocol_still_checks_the_frozen_model(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd)),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(w.main(['--output-root',str(out),'--full-learning']),0)
            report=json.loads((out/'ROLLING_REPORT.json').read_text())
            self.assertEqual(report['actual_episodes'],48)
            self.assertTrue(report['frozen_checkpoint_unchanged'])
            self.assertTrue(report['v26_local_road']['ok'])
            self.assertFalse(report['benefit_established'])


if __name__=='__main__': unittest.main()
