"""Exercise the trajectory pilot's planning, failed-run retention and archive."""
import contextlib
import csv
import importlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch


class TrajectoryWorkflowTests(unittest.TestCase):
    def workflow(self):
        try:
            return importlib.import_module('Tools.run_trajectory_validation_v21')
        except ImportError:
            self.fail('The v21 trajectory workflow is not implemented')

    def run_fixture(self, output, arguments, failed=False, mismatch=False,
                    collision=False, missing_physical=False):
        """Replace only the external CARLA process, preserving real artifacts."""
        args = list(arguments)
        value = lambda flag: args[args.index(flag)+1]
        stage = Path(value('--output-root'))
        stage.mkdir(parents=True)
        self.assertIn('--keep-going', args)
        self.assertEqual(value('--control-profile'), 'paper_v11')
        self.assertEqual(value('--traffic-interaction'), 'v17')
        self.assertEqual(value('--method'), 'CG')
        self.assertEqual(value('--completion-mode'), 'strict')
        runs = []
        for seed in map(int, value('--seeds').split(',')):
            for arm in value('--arms').split(','):
                directory = stage/('%s_seed%d' % (arm, seed))
                directory.mkdir()
                summaries, rows = [], []
                episodes = int(value('--episodes'))
                for episode in range(1, episodes+1):
                    is_collision = collision and arm == 'P1_defer_v21' and seed == 31 and episode == 1
                    outcome = 'collision' if is_collision else 'complete'
                    frames = 4 if is_collision else 2
                    summaries.append(dict(episode=episode, outcome=outcome, frames=frames))
                    for frame in range(1, frames+1):
                        row = dict(episode=episode, frame=frame, ego_x=frame, ego_y=0,
                            ego_v=1, ego_v_after=1, a_cmd=0, delta_rad=0, steer=0,
                            actuator_speed_target=1, guard_action='mpc', mpc_audit_override=0,
                            goal_remaining=10, wait_standoff=5, guard_safe=1)
                        if mismatch and arm == 'P0_observe_v21':row['ego_x'] += 1
                        if missing_physical:row.pop('delta_rad')
                        rows.append(row)
                for name, data in (('interaction_summary.csv', summaries),
                                   ('interaction_ego.csv', rows)):
                    with (directory/name).open('w', newline='', encoding='utf8') as stream:
                        writer = csv.DictWriter(stream, fieldnames=list(data[0]))
                        writer.writeheader();writer.writerows(data)
                counts = {}
                for r in summaries:counts[r['outcome']] = counts.get(r['outcome'], 0)+1
                result = dict(complete=True, finished_episodes=episodes, expected_episodes=episodes,
                    ego_log_complete=True, outcomes=counts, execution_contract_ok=True,
                    trajectory_probe_contract_ok=True)
                metrics = {'P0_observe_v21': (2, 4, 3, 0),
                           'P1_defer_v21': (3, 6, 4, 2),
                           'P2_proceed_v21': (4, 8, 5, 1)}.get(arm)
                if metrics is not None:
                    result.update(zip(('trajectory_probe_active_rows',
                        'trajectory_probe_generated_variants', 'trajectory_probe_eligible_variants',
                        'trajectory_probe_changed_requests'), metrics))
                (directory/'result.json').write_text(json.dumps(result), encoding='utf8')
                (directory/'run.log').write_text('fixture CARLA boundary\n', encoding='utf8')
                runs.append(dict(arm=arm, seed=seed, environment_seed=seed,
                    directory='/remote/not/on/this/computer', status='complete', result=result))
        if failed:
            runs[0]['status'] = 'forecast_error'
            runs[0]['result']['forecast_contract_ok'] = False
        manifest = dict(runs=runs, collection_finished=True, overall_success=not failed,
                        planned_runs=len(runs), episodes=int(value('--episodes')))
        (stage/'manifest.json').write_text(json.dumps(manifest), encoding='utf8')
        return subprocess.CompletedProcess(args, 10 if failed else 0)

    def test_dry_run_plans_31_episodes_without_creating_output(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'new'
            script = Path(w.__file__)
            run = subprocess.run([sys.executable, str(script), '--dry-run',
                                  '--output-root', str(output)], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stderr)
            stages = [json.loads(line) for line in run.stdout.splitlines()]
            self.assertEqual([s['episodes_total'] for s in stages], [4, 27])
            self.assertEqual(stages[0]['arguments'][stages[0]['arguments'].index('--arms')+1],
                             'M6_matrix_v18,P0_observe_v21')
            self.assertEqual(stages[1]['arguments'][stages[1]['arguments'].index('--arms')+1],
                             'P0_observe_v21,P1_defer_v21,P2_proceed_v21')
            self.assertFalse(output.exists())
            self.assertFalse(Path(str(output)+'.tar.gz').exists())

    def test_complete_collection_keeps_collision_and_all_episode_duration(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            stages = w.build_plan(output)
            for stage in stages:
                self.run_fixture(output, stage['arguments'], collision=True)
            report = w.collect_report(output, stages)
            self.assertTrue(report['collection_ok'])
            self.assertFalse(report['all_episodes_successful'])
            group = report['stages'][1]['arms']['P1_defer_v21']
            self.assertEqual(group['n'], 9)
            self.assertEqual(group['collisions'], 1)
            self.assertAlmostEqual(group['mean_all_episode_s'], 1./9.)
            self.assertAlmostEqual(group['mean_completed_s'], .1)
            paired = report['comparisons']['defer_vs_observe']
            self.assertEqual(paired['paired_episodes'], 9)
            self.assertEqual(paired['pairs'][0]['treatment_outcome'], 'collision')
            self.assertFalse(report['benefit_established'])

    def test_probe_counts_add_across_seeds_and_show_missing_baseline_metrics(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            stages = w.build_plan(output)
            for stage in stages:self.run_fixture(output, stage['arguments'])
            report = w.collect_report(output, stages)
            group = report['stages'][1]['arms']['P1_defer_v21']
            self.assertIsNotNone(group.get('probe'), 'Missing aggregated probe effectiveness counts')
            self.assertEqual(group['probe'], dict(active_rows=9, generated_variants=18,
                eligible_variants=12, changed_requests=6, reported_runs=3, missing_runs=0))
            baseline = report['stages'][0]['arms']['M6_matrix_v18']['probe']
            self.assertEqual(baseline['changed_requests'], 0)
            self.assertEqual(baseline['reported_runs'], 0)
            self.assertEqual(baseline['missing_runs'], 1)
            text = (output/'COMPARISON.txt').read_text()
            self.assertIn('probe_changed=6 probe_eligible=12 probe_metric_runs=3 probe_missing_runs=0', text)

    def test_partial_probe_metrics_are_not_reported_as_complete(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            stages = w.build_plan(output)
            for stage in stages:self.run_fixture(output, stage['arguments'])
            path = output/'01_probe/P2_proceed_v21_seed33/result.json'
            row = json.loads(path.read_text());row.pop('trajectory_probe_active_rows')
            path.write_text(json.dumps(row), encoding='utf8')
            report = w.collect_report(output, stages)
            group = report['stages'][1]['arms']['P2_proceed_v21']
            self.assertIsNotNone(group.get('probe'), 'Missing probe metric availability bookkeeping')
            self.assertEqual(group['probe']['active_rows'], 8)
            self.assertEqual(group['probe']['changed_requests'], 3)
            self.assertEqual(group['probe']['reported_runs'], 2)
            self.assertEqual(group['probe']['missing_runs'], 1)

    def test_observe_mismatch_blocks_probe_and_archives_evidence(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            def external(command, **kwargs):
                return self.run_fixture(output, command[3:], mismatch=True)
            with patch.object(w.subprocess, 'run', side_effect=external), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertNotEqual(code, 0)
            self.assertFalse((output/'01_probe').exists())
            report = json.loads((output/'TRAJECTORY_REPORT.json').read_text())
            self.assertFalse(report['smoke_observe_identity']['ok'])
            workflow = json.loads((output/'WORKFLOW.json').read_text())
            self.assertFalse(workflow['overall_success'])
            with tarfile.open(str(output)+'.tar.gz') as archive:
                names = archive.getnames()
            self.assertTrue(any(n.endswith('/TRAJECTORY_REPORT.json') for n in names))
            self.assertTrue(any(n.endswith('/run.log') for n in names))

    def test_missing_physical_column_cannot_pass_observe_identity(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            stages = w.build_plan(output)
            self.run_fixture(output, stages[0]['arguments'], missing_physical=True)
            report = w.collect_report(output, stages)
            self.assertFalse(report['smoke_observe_identity']['ok'])
            self.assertFalse(report['collection_ok'])

    def test_formal_contract_failure_retains_every_run_and_nonzero_exit(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            def external(command, **kwargs):
                return self.run_fixture(output, command[3:], failed='01_probe' in command[-1])
            with patch.object(w.subprocess, 'run', side_effect=external), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertNotEqual(code, 0)
            report = json.loads((output/'TRAJECTORY_REPORT.json').read_text())
            self.assertEqual(report['stages'][1]['collected_runs'], 9)
            self.assertFalse(report['collection_ok'])
            self.assertTrue((output/'01_probe/P2_proceed_v21_seed33/run.log').is_file())
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())

    def test_process_start_error_is_recorded_and_archived(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'result'
            with patch.object(w.subprocess, 'run', side_effect=OSError('cannot start child')), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertNotEqual(code, 0)
            workflow = json.loads((output/'WORKFLOW.json').read_text())
            self.assertFalse(workflow['overall_success'])
            self.assertIn('cannot start child', workflow['error'])
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())

    def test_existing_output_and_archive_are_not_overwritten(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'old';output.mkdir()
            marker = output/'keep.txt';marker.write_text('keep')
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                w.main(['--output-root', str(output)])
            self.assertEqual(marker.read_text(), 'keep')
            output2 = Path(temp)/'new'
            archive = Path(str(output2)+'.tar.gz');archive.write_bytes(b'keep archive')
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                w.main(['--output-root', str(output2)])
            self.assertEqual(archive.read_bytes(), b'keep archive')
            self.assertFalse(output2.exists())

    def test_invalid_budget_or_duplicate_seeds_rejected_before_writes(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)/'new'
            for arguments in (['--probe-episodes', '0'], ['--seeds', '31,31'],
                              ['--seeds', '30,31']):
                with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                    w.main(arguments+['--output-root', str(output)])
                self.assertFalse(output.exists())


if __name__ == '__main__':unittest.main()
