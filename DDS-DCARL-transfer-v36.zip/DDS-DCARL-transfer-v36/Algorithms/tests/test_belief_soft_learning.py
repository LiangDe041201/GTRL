"""Mathematical and runtime-integration checks of paper IV-A/B learning."""
import ast
import csv
import json
import math
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as S
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Planning_library.belief_space import (
    DrivingBelief, TYPES, belief_step, probability)
from Planning_library.soft_bellman import (
    BeliefSoftLearner, baseline_prior, bellman_target, information_cost, soft_value_policy,
    negative_efe_return_range)
from Tools.validate_belief_learning import validate_belief_learning
from Planning_library.information_set import InformationSetTracker, with_beta
from Planning_library.scenario_snapshot import VehicleState
from Planning_library.vehicle_observation import (
    vehicle_id, longitudinal_acceleration, motion_observation, following_acceleration)
from Planning_library.rv_decision import rv_yield_probability


CONTEXT = np.zeros(len(BeliefSoftLearner.CONTEXT_WIDTHS))
BELIEF = np.ones(6) / 6.


class TestBeliefFilter(unittest.TestCase):
    def test_exact_bayes_prediction_and_observation_evidence(self):
        b = [.6, .4]
        t = [[.8, .2], [.1, .9]]
        z = [[.9, .1], [.2, .8]]
        post, evidence, predicted = belief_step(b, t, z, 0)
        np.testing.assert_allclose(predicted, [.52, .48])
        np.testing.assert_allclose(evidence, [.564, .436])
        np.testing.assert_allclose(post, [.468/.564, .096/.564])

    def test_impossible_observation_is_visible(self):
        with self.assertRaisesRegex(ValueError, 'zero probability'):
            belief_step([1., 0.], np.eye(2), np.eye(2), 1)

    def test_invalid_probabilities_and_nonstochastic_transition_are_rejected(self):
        for p in ([0., 0.], [1., -.1], [float('nan'), 1.]):
            with self.assertRaises(ValueError):
                probability(p)
        with self.assertRaises(ValueError):
            belief_step([.5, .5], [[.2, .2], [.5, .5]], np.eye(2), 0)

    def test_private_type_is_static_but_intention_transitions(self):
        filter_ = DrivingBelief()
        t = filter_.transition(dict(zip(TYPES, [.9, .5, .1])))
        for state in range(6):
            self.assertEqual(np.count_nonzero(t[state, :2*(state//2)]), 0)
            self.assertEqual(np.count_nonzero(t[state, 2*(state//2+1):]), 0)
            self.assertGreater(t[state, 2*(state//2)], 0.)
            self.assertGreater(t[state, 2*(state//2)+1], 0.)

    def test_candidate_predictions_do_not_update_the_posterior(self):
        filter_ = DrivingBelief()
        original = filter_.observe(7, 1)
        conservative = filter_.predicted_yield(7, {t: .9 for t in TYPES})
        aggressive = filter_.predicted_yield(7, {t: .1 for t in TYPES})
        np.testing.assert_array_equal(filter_.vector(7), original)
        self.assertGreater(conservative['normal'], aggressive['normal'])
        self.assertFalse(filter_.pending)

    def test_executed_action_affects_next_belief(self):
        a, b = DrivingBelief(persistence=0.), DrivingBelief(persistence=0.)
        a.observe(7, 1)
        b.observe(7, 1)
        a.execute(7, dict(zip(TYPES, [.9, .5, .1])))
        b.execute(7, dict(zip(TYPES, [.1, .5, .9])))
        a.observe(7, 0)
        b.observe(7, 0)
        self.assertGreater(a.type_posterior()['conservative'], b.type_posterior()['conservative'])
        self.assertLess(a.theta(), b.theta())

    def test_actor_identity_and_episode_reset_prevent_posterior_leakage(self):
        filter_ = DrivingBelief()
        first = filter_.observe(101, 0)
        second = filter_.observe(102, 2)
        self.assertFalse(np.allclose(first, second))
        np.testing.assert_array_equal(filter_.vector(101), first)
        filter_.reset()
        np.testing.assert_allclose(filter_.vector(101), BELIEF)
        self.assertEqual(filter_.updates, 0)

    def test_absent_actor_is_a_separate_uniform_belief(self):
        filter_ = DrivingBelief()
        filter_.observe(1, 0)
        np.testing.assert_allclose(filter_.observe(None, 0), BELIEF)
        self.assertIsNone(filter_.last_evidence)


class TestSoftBellmanMath(unittest.TestCase):
    def test_negative_efe_range_follows_preference_and_entropy_bounds(self):
        preference = [.94, .02, .03, .01]
        expected = (math.log(100.) + math.log(4.)) / .02
        self.assertAlmostEqual(negative_efe_return_range(preference, 1., 1., .98), expected)
        self.assertAlmostEqual(negative_efe_return_range(preference, 2., 0., .9), 2.*math.log(100.)/.1)

    def test_negative_weights_cannot_claim_a_negative_efe_return_bound(self):
        with self.assertRaises(ValueError):
            negative_efe_return_range([.8, .2], 1., -1., .98)

    def test_nonuniform_baseline_exact_partition_and_policy(self):
        value, policy = soft_value_policy([0., 2.], [.8, .2], .5)
        z = .8 + .2 * math.exp(4.)
        self.assertAlmostEqual(value, .5 * math.log(z))
        np.testing.assert_allclose(policy, [.8/z, .2*math.exp(4.)/z])

    def test_variational_identity_includes_information_cost_exactly_once(self):
        q, p0, alpha = np.asarray([1., -2., 4.]), [.7, .2, .1], 1.3
        value, pi = soft_value_policy(q, p0, alpha)
        self.assertAlmostEqual(value, float(pi.dot(q))-information_cost(pi, p0, alpha), places=12)

    def test_equal_values_recover_the_baseline(self):
        value, pi = soft_value_policy([3., 3., 3.], [.7, .2, .1], .4)
        np.testing.assert_allclose(pi, [.7, .2, .1])
        self.assertAlmostEqual(value, 3.)
        self.assertAlmostEqual(information_cost(pi, [.7, .2, .1], .4), 0.)

    def test_low_and_high_temperature_limits(self):
        _, low = soft_value_policy([0., 2.], [.9, .1], 1e-6)
        _, high = soft_value_policy([0., 2.], [.9, .1], 1e8)
        np.testing.assert_allclose(low, [0., 1.])
        np.testing.assert_allclose(high, [.9, .1], atol=1e-7)

    def test_large_values_and_small_alpha_stay_finite(self):
        value, pi = soft_value_policy([1e6, 1e6-1.], [.9, .1], 1e-6)
        self.assertTrue(math.isfinite(value))
        self.assertAlmostEqual(pi.sum(), 1.)
        self.assertGreater(pi[0], .99999)

    def test_baseline_zero_support_cannot_be_resurrected_by_high_q(self):
        value, pi = soft_value_policy([0., 1e10], [1., 0.], 1.)
        self.assertEqual(value, 0.)
        np.testing.assert_array_equal(pi, [1., 0.])
        self.assertTrue(math.isinf(information_cost([0., 1.], [1., 0.], 1.)))

    def test_safe_prior_smoothing_is_not_exploration_epsilon(self):
        p = baseline_prior(4, 1, [0, 1, 3], .06)
        np.testing.assert_allclose(p, [.02, .96, 0., .02])
        self.assertGreater(information_cost([1., 0., 0., 0.], p, 1.), 0.)

    def test_bellman_terminal_has_no_bootstrap(self):
        self.assertEqual(bellman_target(-7., .9, [1000., 2000.], [.5, .5], 1., terminal=True), -7.)

    def test_operator_is_discount_contractive(self):
        q, shifted = [2., -1.], [3., -2.]
        first = bellman_target(3., .9, q, [.8, .2], .7)
        second = bellman_target(3., .9, shifted, [.8, .2], .7)
        self.assertLessEqual(abs(first-second), .9 * np.max(np.abs(np.asarray(q)-shifted)) + 1e-12)


class TestEmpiricalLearning(unittest.TestCase):
    def learner(self, **kwargs):
        return BeliefSoftLearner(2, **kwargs)

    def begin(self, learner, context=CONTEXT, belief=BELIEF, episode=1, allowed=(0, 1)):
        return learner.begin(context, belief, 0, allowed, episode)

    def action(self, learner, action):
        learner.select(explore_action=action)
        learner.start_action(action)

    def test_full_belief_not_just_type_mean_conditions_values(self):
        learner = self.learner()
        first = self.begin(learner, belief=[.5, 0., 0., 0., .5, 0.])
        second = self.begin(learner, belief=[0., 0., 1., 0., 0., 0.])
        # Both have mean type .5, yet their uncertainty and support differ.
        self.assertNotEqual(first, second)
        self.assertEqual(len(learner.nodes), 2)

    def test_observation_context_and_safety_mask_also_condition_state(self):
        learner = self.learner()
        a = self.begin(learner)
        changed = CONTEXT.copy()
        changed[5] = 30.
        b = self.begin(learner, context=changed)
        c = self.begin(learner, allowed=(0,))
        self.assertEqual(len({a, b, c}), 3)

    def test_shared_grid_cell_keeps_the_current_unquantized_belief(self):
        learner = self.learner()
        first = self.begin(learner)
        different = BELIEF.copy()
        different[0] += .01
        different[1] -= .01
        second = self.begin(learner, belief=different)
        self.assertEqual(first, second)
        learner.select()
        np.testing.assert_allclose(learner.last['belief'], different)
        self.assertFalse(np.allclose(learner.last['belief'], learner.nodes[first]['belief']))

    def test_macro_discount_and_recursive_credit_assignment(self):
        learner = self.learner(gamma=.9)
        first = self.begin(learner, allowed=(0,))
        self.action(learner, 0)
        learner.record_reward(2.)
        learner.record_reward(4.)
        other = CONTEXT.copy()
        other[5] = 20.
        final = self.begin(learner, context=other, allowed=(0,))
        self.action(learner, 0)
        learner.record_reward(10.)
        learner.finish()
        self.assertAlmostEqual(learner.q[first][0], 2.+.9*4.+.9**2*10.)
        self.assertAlmostEqual(learner.q[final][0], 10.)
        self.assertEqual(learner.records[0]['steps'], 2)
        self.assertAlmostEqual(learner.records[0]['discount'], .81)

    def test_successor_uses_soft_partition_not_hard_max_or_sampled_return(self):
        learner = self.learner(gamma=.9)
        first = self.begin(learner, allowed=(0,))
        self.action(learner, 0)
        learner.record_reward(1.)
        other = CONTEXT.copy()
        other[5] = 20.
        final = self.begin(learner, context=other)
        self.action(learner, 0)
        learner.record_reward(0.)
        learner.finish()
        self.begin(learner, context=other, episode=2)
        self.action(learner, 1)
        learner.record_reward(4.)
        learner.finish()
        expected = math.log(.975 + .025*math.exp(4.))
        self.assertAlmostEqual(learner.q[first][0], 1.+.9*expected)
        self.assertNotAlmostEqual(learner.q[first][0], 1.+.9*4.)
        self.assertNotAlmostEqual(learner.q[first][0], 1.)
        self.assertEqual(learner.residual, 0.)

    def test_terminal_never_bootstraps_from_next_episode(self):
        learner = self.learner()
        first = self.begin(learner)
        self.action(learner, 0)
        learner.record_reward(-3.)
        learner.finish()
        self.begin(learner, episode=2)
        self.assertIsNone(learner.records[0]['next'])
        self.assertEqual(learner.q[first][0], -3.)

    def test_correlated_decisions_in_one_episode_count_as_one_cluster(self):
        learner = self.learner()
        first = self.begin(learner)
        for _ in range(5):
            self.action(learner, 0)
            learner.record_reward(1.)
            self.begin(learner)
        learner.finish()
        self.assertEqual(len(learner.records), 5)
        self.assertEqual(learner.confidence(first)[0]['n'], 1)

    def test_bellman_and_confidence_use_the_same_episode_cluster_weights(self):
        learner = self.learner(gamma=.5)
        key = self.begin(learner, allowed=(0,))
        # Episode one has nine self-transitions and a terminal reward of ten.
        for step in range(10):
            if step:
                self.begin(learner, allowed=(0,))
            self.action(learner, 0)
            learner.record_reward(10. if step == 9 else 0.)
        learner.finish()
        self.begin(learner, allowed=(0,), episode=2)
        self.action(learner, 0)
        learner.record_reward(0.)
        learner.finish()
        # Q = ((9*.5*Q+10)/10 + 0)/2, not a frame-weighted mean.
        self.assertAlmostEqual(learner.q[key][0], 1./(2.-.9*.5), places=5)
        self.assertAlmostEqual(learner.confidence(key)[0]['mean'], learner.q[key][0], places=5)

    def test_insufficient_evidence_keeps_baseline_behavior(self):
        learner = self.learner()
        self.begin(learner)
        learner.q[learner.current][1] = 1e6
        action, _ = learner.select()
        self.assertEqual(action, 0)
        self.assertEqual(learner.last['certified'], [])
        self.assertEqual(learner.last['soft_policy'][1], 1.)

    def test_evidence_gate_then_soft_behavior_and_kl(self):
        learner = self.learner(range_fallback=1000.)
        for episode in range(20):
            self.begin(learner, episode=episode)
            self.action(learner, episode % 2)
            learner.record_reward(1000. * (episode % 2))
            learner.finish()
        self.begin(learner, episode=21)
        action, _ = learner.select(rng=np.random.RandomState(1))
        self.assertEqual(action, 1)
        self.assertEqual(learner.last['certified'], [1])
        self.assertGreater(learner.last['information_cost'], 0.)
        self.assertEqual(learner.last['samples'], {0: 10, 1: 10})

    def test_forced_segment_is_not_an_original_action_sample(self):
        learner = self.learner()
        self.begin(learner)
        self.action(learner, 0)
        learner.record_reward(10.)
        learner.record_reward(10., forced=True)
        learner.finish()
        self.assertFalse(learner.records)

    def test_action_rewrite_does_not_keep_original_behavior_cost(self):
        learner = self.learner()
        self.begin(learner)
        learner.select(explore_action=1)
        learner.start_action(0)
        self.assertIsNone(learner.last['information_cost'])
        self.assertFalse(learner.last['behavior_model_valid'])
        learner.record_reward(10.)
        learner.finish()
        self.assertFalse(learner.records)

    def test_model_roundtrip_and_configuration_mismatch(self):
        with tempfile.TemporaryDirectory() as directory:
            learner = self.learner(out_dir=directory)
            key = self.begin(learner)
            self.action(learner, 0)
            learner.record_reward(2.)
            learner.finish()
            loaded = self.learner(out_dir=directory)
            np.testing.assert_array_equal(learner.q[key], loaded.q[key])
            self.assertEqual(learner.records, loaded.records)
            with self.assertRaisesRegex(ValueError, 'fresh result directory'):
                self.learner(out_dir=directory, alpha=2.)


def production_methods(*names):
    path = ROOT / 'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    selected = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name in names]
    ns = dict(np=np, os=os, math=math, N_ACTIONS=2, BELIEF_TYPES=TYPES,
              shield_fallback_action=lambda rule, allowed: allowed[0], BRAKE_ACTION=0,
              with_beta=with_beta, ego_intent=lambda *args: .5, _BAND_HALF=1.,
              vehicle_id=vehicle_id, longitudinal_acceleration=longitudinal_acceleration,
              motion_observation=motion_observation, following_acceleration=following_acceleration,
              rv_yield_probability=rv_yield_probability)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), ns)
    return ns


class TestProductionIntegration(unittest.TestCase):
    class NoOracle:
        @property
        def cross_traffic(self):
            raise AssertionError('Simulator decision labels must not enter learning')

    def motion_agent(self):
        rv = S(carla_id=42, x=5., y=7., v=3., vx=-3., vy=0., ax=1., ay=0., yaw=0.)
        methods = production_methods('_observed_rv_action', '_update_information_set', '_update_yield_history')
        agent = S(belief_tracker=DrivingBelief(), info_track=InformationSetTracker(),
                  _info_ep=None, type_inf=S(theta=lambda: .5, posterior=dict(zip(TYPES, [1./3]*3))),
                  env=self.NoOracle(), _type_yield_threshold=lambda: 2.,
                  dynamic_map=S(ego_vehicle=S(y=5.), objects=[rv]),
                  _intent_hist=[[0, 0] for _ in range(4)], _yield_last={}, _yield_hist={}, _clr_err=None)
        agent._observed_rv_action = lambda vehicle: methods['_observed_rv_action'](agent, vehicle)
        return methods, agent, rv

    def test_information_history_uses_observed_motion_and_true_vehicle_identity(self):
        methods, agent, rv = self.motion_agent()
        ego = S(x=0., y=5., v=2., yaw=0.)
        methods['_update_information_set'](agent, 1, 0, dict(rv_veh=rv), ego, 1, 3.)
        self.assertIsNone(agent._info_err)
        self.assertEqual(agent.info_track.history.actions_of(42), ('yield',))
        self.assertEqual(agent.info_track.history.actions_of(1), ())
        self.assertEqual(agent.info_track.info_set(0)['states'][0][0][-1], 0.)
        self.assertEqual(agent.info_track.info_set(0)['states'][42][0][-1], .5)

    def test_yield_history_does_not_access_simulator_decision_labels(self):
        for tracker in (None, DrivingBelief()):
            with self.subTest(belief=tracker is not None):
                methods, agent, _ = self.motion_agent()
                agent.belief_tracker = tracker
                methods['_update_yield_history'](agent, dict(conflict_y=0.))
                self.assertIsNone(agent._clr_err)
                self.assertEqual(agent._yield_hist, {42: (1, 1)})

    def test_information_set_uses_real_snapshot_for_both_learning_modes(self):
        for tracker in (None, DrivingBelief()):
            methods, agent, _ = self.motion_agent()
            agent.belief_tracker = tracker
            rv = VehicleState(veh_id=42, x=5., y=7., v=3., vx=-3.,
                              acc=-1., acc_source='velocity_difference')
            methods['_update_information_set'](
                agent, 1, 0, dict(rv_veh=rv), S(x=0., y=5., v=2., yaw=0.), 1, 3.)
            self.assertIsNone(agent._info_err)
            self.assertEqual(agent.info_track.history.actions_of(42), ('yield',))
            self.assertEqual(agent.info_track.history.actions_of(1), ())
            self.assertEqual(agent.info_track.info_set(0)['states'][42][0][3], -1.)

    def test_risk_probability_uses_normalized_observations_without_an_oracle(self):
        from Planning_library.objective_reward import _veh_list
        method = production_methods('_p_yield_safe')['_p_yield_safe']
        rv = VehicleState(veh_id=42, x=30., y=-138., v=3., vx=-3., yaw=math.pi,
                          acc=-1., acc_source='velocity_difference')
        agent = S(dynamic_map=S(ego_vehicle=S(x=6., y=-125., v=3.), objects=[rv]),
                  type_inf=S(theta=lambda: .5), env=self.NoOracle(), _clr_err=None,
                  _intent_hist=[[0, 0] for _ in range(5)], _last_intent_ego=0.,
                  intent_min_obs=5, p_yield_prior_k=2., p_yield_z=1., _yield_hist={})
        p, prior, estimate, count = method(
            agent, _veh_list([rv])[0], dict(conflict_x=6., t_ego=4.), None)
        self.assertIsNone(agent._clr_err)
        self.assertTrue(.05 <= p <= .95)
        self.assertEqual(prior, estimate)
        self.assertEqual(count, 0)

    def test_task_reward_is_not_charged_policy_kl_a_second_time(self):
        method = production_methods('_belief_learning_reward')['_belief_learning_reward']
        self.assertEqual(method(S(belief_reward_mode='task_ambiguity'), -12., 0), -12.)

    def test_negative_efe_is_full_efe_and_does_not_hide_a_terminal_bonus(self):
        method = production_methods('_belief_learning_reward')['_belief_learning_reward']
        agent = S(belief_reward_mode='negative_efe', _efe_last=dict(active=True, reward={1: -2.3}))
        self.assertEqual(method(agent, -3000., 1), -2.3)
        self.assertEqual(method(agent, 140., 1), -2.3)

    def test_failed_efe_prediction_cannot_be_silently_learned_as_zero(self):
        method = production_methods('_belief_learning_reward')['_belief_learning_reward']
        agent = S(belief_reward_mode='negative_efe', _efe_last=dict(active=False, error='bad model'))
        with self.assertRaisesRegex(RuntimeError, 'failed EFE'):
            method(agent, 0., 1)

    def test_no_active_game_has_zero_analytic_efe_reward(self):
        method = production_methods('_belief_learning_reward')['_belief_learning_reward']
        agent = S(belief_reward_mode='negative_efe', _efe_last=dict(active=False))
        self.assertEqual(method(agent, 140., 1), 0.)

    def test_hybrid_uses_belief_recursion_and_does_not_add_efe_twice(self):
        method = production_methods('act_hybrid')['act_hybrid']
        learner = BeliefSoftLearner(2)
        learner.begin(CONTEXT, BELIEF, 0, [0, 1], 1)
        agent = S(belief_learner=learner, use_wcv_bcv=True, _takeover_num=0)
        action, _ = method(agent, None, None, 0, None, action_num=1,
                           explore_action=1, efe_values={0: 1e9, 1: -1e9})
        self.assertEqual(action, 1)
        self.assertEqual(learner.last['source'], 'explore')

    def test_runtime_context_uses_real_actor_id_and_full_probability_vector(self):
        method = production_methods('_begin_belief_decision')['_begin_belief_decision']
        learner = BeliefSoftLearner(2)
        agent = S(belief_learner=learner, belief_tracker=DrivingBelief(), type_inf=S(),
                  dynamic_map=S(ego_vehicle=S(x=1., y=2., v=3., yaw=.1)),
                  env=None, _type_yield_threshold=lambda: 2.,
                  _shield_allowed_actions=lambda *args: [True, True])
        rv = VehicleState(veh_id=42, x=6., y=8., v=1., acc=-1.,
                          acc_source='velocity_difference')
        method(agent, [0.]*5, [0.]*8, 0, dict(rv_veh=rv, rv_acc=-1.), 1)
        self.assertEqual(agent._belief_actor, 42)
        self.assertEqual(agent.belief_tracker.updates, 1)
        self.assertIn(42, agent.belief_tracker.tracks)
        self.assertFalse(np.allclose(agent.belief_tracker.vector(42), BELIEF))
        self.assertEqual(len(learner.nodes[learner.current]['belief']), 6)
        self.assertEqual(learner.nodes[learner.current]['context'][13], 1.)
        self.assertEqual(learner.nodes[learner.current]['context'][14:18], [1., 2., 3., .1])
        np.testing.assert_allclose(list(agent.type_inf.posterior.values()), [1./3]*3)

    def test_real_snapshot_pipeline_keeps_identity_motion_and_belief_evidence(self):
        from Planning_library.define_state_space_turn import crossing_conflict_detail
        from Planning_library.vehicle_observation import MotionHistory
        path = np.array([[6., -120.], [6., -130.], [6., -140.], [0., -145.]])
        env = self.NoOracle()
        env.ref_path_array = path
        env.INTERSECTION_CENTER = (6., -138.)
        ego = S(carla_id=10, x=6., y=-125., v=3., vx=0., vy=-3., yaw=-math.pi/2)
        rv = S(carla_id=42, x=40., y=-138., v=4., vx=-4., vy=0., yaw=math.pi)
        motion = MotionHistory()
        motion.update([ego, rv], 1.)
        rv.v = 3.95
        rv.vx = -3.95
        motion.update([ego, rv], 1.05)
        dynamic_map = S(ego_vehicle=ego, objects=[rv], env=env)
        conf = crossing_conflict_detail(dynamic_map, env)
        self.assertIsInstance(conf['rv_veh'], VehicleState)
        self.assertEqual(conf['rv_actor_id'], 42)
        self.assertAlmostEqual(conf['rv_acc'], -1.)
        learner = BeliefSoftLearner(2)
        agent = S(belief_learner=learner, belief_tracker=DrivingBelief(), type_inf=S(),
                  dynamic_map=dynamic_map, env=env, _type_yield_threshold=lambda: 2.,
                  _shield_allowed_actions=lambda *args: [True, True])
        method = production_methods('_begin_belief_decision')['_begin_belief_decision']
        method(agent, [0.]*5, [0.]*8, 0, conf, 1)
        self.assertEqual(agent._belief_actor, 42)
        self.assertEqual(agent.belief_tracker.updates, 1)
        self.assertAlmostEqual(learner.current_context[-2], -1.)
        agent.belief_tracker.execute(42, dict(zip(TYPES, [.9, .5, .1])))
        method(agent, [0.]*5, [0.]*8, 0, conf, 1)
        self.assertNotAlmostEqual(agent.type_inf.posterior[TYPES[0]],
                                  agent.type_inf.posterior[TYPES[2]])
        other = VehicleState(veh_id=43, x=45., y=-138., v=4.)
        method(agent, [0.]*5, [0.]*8, 0, dict(rv_veh=other), 1)
        self.assertEqual(set(agent.belief_tracker.tracks), {42, 43})
        agent.belief_tracker.reset()
        self.assertFalse(agent.belief_tracker.tracks)

    def test_committed_clearance_preserves_the_existing_shield_exception(self):
        method = production_methods('_begin_belief_decision')['_begin_belief_decision']
        learner = BeliefSoftLearner(2)
        agent = S(belief_learner=learner, belief_tracker=DrivingBelief(), type_inf=S(),
                  dynamic_map=S(ego_vehicle=S(x=1., y=2., v=3., yaw=.1)), env=None,
                  _type_yield_threshold=lambda: 2., _shield_allowed_actions=lambda *args: [True, False],
                  shield_respect_commit=True, _last_committing=True, _last_wait_standoff=0., wait_margin=1.)
        method(agent, [0.]*5, [0.]*8, 1, dict(rv_veh=None, committed=True), 1)
        self.assertEqual(learner.nodes[learner.current]['allowed'], [0, 1])
        self.assertEqual(learner.nodes[learner.current]['rule'], 1)


class TestReturnedLearningEvidence(unittest.TestCase):
    def run_fixture(self, directory):
        root = Path(directory)
        learner = BeliefSoftLearner(2, out_dir=root)
        snapshots = []
        for step in range(2):
            context = CONTEXT.copy()
            context[5] = 10.*step
            learner.begin(context, BELIEF, 0, [0, 1], 1)
            learner.select(explore_action=0)
            learner.start_action(0)
            snapshots.append(dict(learner.last))
            learner.record_reward(2.)
        learner.finish()
        rows = []
        for snapshot in snapshots:
            row = dict(learning_mode='soft_belief', learning_reward_mode='task_ambiguity',
                       belief_rv_id='42', belief_vector=json.dumps(snapshot['belief']),
                       belief_entropy=snapshot['belief_entropy'], belief_evidence=.3,
                       behavior_model_valid='1', learning_decision='1')
            row.update({key: json.dumps(snapshot[key]) for key in
                        ('soft_policy', 'baseline_policy', 'behavior_policy')})
            row.update({key: snapshot[key] for key in
                        ('soft_value', 'soft_information_cost', 'information_cost')})
            rows.append(row)
        self.write_rows(root, rows)
        return root, rows

    def write_rows(self, root, rows):
        with (root/'interaction_ego.csv').open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    def test_intact_real_model_and_csv_evidence_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            root, _ = self.run_fixture(directory)
            result = validate_belief_learning(root)
            self.assertTrue(result['learning_mechanisms_ok'], result)
            self.assertEqual(result['belief_transition_rows'], 2)
            self.assertEqual(result['belief_update_decisions'], 2)

    def test_kl_is_recomputed_from_distributions(self):
        with tempfile.TemporaryDirectory() as directory:
            root, rows = self.run_fixture(directory)
            rows[0]['information_cost'] = 123.
            self.write_rows(root, rows)
            result = validate_belief_learning(root)
            self.assertFalse(result['learning_mechanisms_ok'])
            self.assertEqual(result['invalid_belief_log_rows'], 1)

    def test_changed_macro_discount_is_detected_even_when_both_logs_match(self):
        with tempfile.TemporaryDirectory() as directory:
            root, _ = self.run_fixture(directory)
            path = root/'belief_soft_model.json'
            model = json.loads(path.read_text(encoding='utf-8'))
            model['records'][0]['discount'] = .1
            path.write_text(json.dumps(model), encoding='utf-8')
            (root/'belief_transitions.jsonl').write_text(
                '\n'.join(json.dumps(record) for record in model['records']), encoding='utf-8')
            result = validate_belief_learning(root)
            self.assertFalse(result['learning_mechanisms_ok'])
            self.assertIn('option discount', result['learning_validation_errors'][0])

    def test_missing_belief_vector_cannot_pass_as_an_enabled_flag(self):
        with tempfile.TemporaryDirectory() as directory:
            root, rows = self.run_fixture(directory)
            rows[0]['belief_vector'] = ''
            self.write_rows(root, rows)
            self.assertFalse(validate_belief_learning(root)['learning_mechanisms_ok'])

    def test_missing_model_is_reported_without_an_analysis_crash(self):
        with tempfile.TemporaryDirectory() as directory:
            result = validate_belief_learning(directory)
            self.assertFalse(result['learning_mechanisms_ok'])
            self.assertTrue(result['learning_validation_errors'])


if __name__ == '__main__':
    unittest.main()
