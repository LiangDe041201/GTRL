"""Versioned repair workflow must gate training on independent CG references."""
import contextlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import test_rolling_workflow_v24 as old_fixtures


class RollingWorkflowV25Tests(unittest.TestCase):
    def workflow(self):
        try: return importlib.import_module('Tools.run_rolling_validation_v25')
        except ImportError: self.fail('The v25 reference-isolation workflow is missing')

    def boundary(self, cmd, contaminated=False, missing_timing=False):
        root=Path(cmd[cmd.index('--output-root')+1])
        result=old_fixtures.RollingWorkflowTests().boundary(cmd)
        for directory in root.glob('T*_seed*'):
            metadata=dict(execution_revision='isolated_cg_v25',audit_revision='shared_forecast_v25')
            (directory/'rolling_metadata_v24.json').write_text(json.dumps(metadata),encoding='utf8')
            profile={key:1. for key in ('generation_ms','mpc_reset_ms','mpc_solve_ms','execution_ms',
                'score_ms','prediction_ms','road_audit_ms','selection_ms','cg_restore_ms','feedback_road_ms')}
            profile.update(prediction_calls=2,prediction_hits=2)
            if missing_timing: profile.pop('road_audit_ms')
            payload=dict(execution_revision='isolated_cg_v25',cg_reference_hash='a'*64,
                baseline_path_hash='b'*64 if contaminated else 'a'*64,timing=profile,replanned=True,
                map_statistics=dict(map_queries=10,map_cache_hits=2,map_query_ms=.5,audit_calls=1))
            records=[dict(episode=1,frame=i,rolling_trajectory=payload) for i in (1,2)]
            (directory/'matrix_decisions.jsonl').write_text(
                ''.join(json.dumps(r)+'\n' for r in records),encoding='utf8')
        return result

    def test_default_plan_repeats_probes_and_freezes_an_unseen_seed_evaluation(self):
        w=self.workflow()
        stages=w.build_plan(Path('unused'))
        self.assertEqual([s['episodes_total'] for s in stages],[4,12,20,12])
        self.assertEqual(stages[1]['episodes_per_run'],3)
        self.assertTrue(set(stages[2]['seeds']).isdisjoint(stages[3]['seeds']))
        self.assertIn('--rolling-checkpoint',stages[3]['arguments'])

    def test_cg_reference_leak_stops_before_training_and_retains_archive(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'result'
            def run(cmd,**kw):
                return self.boundary(cmd,contaminated=Path(cmd[cmd.index('--output-root')+1]).name=='01_probe')
            with patch.object(w.subprocess,'run',side_effect=run),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(output)])
            self.assertNotEqual(code,0)
            self.assertFalse((output/'02_train').exists())
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())
            report=json.loads((output/'ROLLING_REPORT.json').read_text())
            self.assertGreater(report['v25_runtime']['reference_error_frames'],0)

    def test_missing_timing_is_rejected_instead_of_claiming_optimization_measured(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd,missing_timing=True)),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(output)])
            self.assertNotEqual(code,0)
            self.assertFalse((output/'01_probe').exists())

    def test_complete_workflow_keeps_frozen_checkpoint_and_makes_no_benefit_claim(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd)),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(output)])
            self.assertEqual(code,0)
            report=json.loads((output/'ROLLING_REPORT.json').read_text())
            self.assertEqual(report['actual_episodes'],48)
            self.assertTrue(report['frozen_checkpoint_unchanged'])
            self.assertFalse(report['benefit_established'])
            self.assertEqual(report['v25_runtime']['reference_error_frames'],0)


if __name__=='__main__': unittest.main()
