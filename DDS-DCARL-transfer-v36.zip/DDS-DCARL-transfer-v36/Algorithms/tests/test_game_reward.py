#!/usr/bin/env python3
"""论文奖赏合成（式62-68）单元测试（纯 stdlib，无 CARLA）。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.game_reward import (
    gap_dist_reward, gap_rate_reward, game_reward,
    thw_reward, yaw_reward, lat_reward, total_reward, COMPLETE_REWARD,
)


class TestGapDistReward(unittest.TestCase):
    """式62：间隙 g_d 分段奖励。"""

    def test_piecewise_endpoints(self):
        # 按论文分段：g=2.5 -> -20；g=3.5 -> +20；g=5.0 -> +65；g>=7 -> 0
        self.assertAlmostEqual(gap_dist_reward(2.5), -20.0)
        self.assertAlmostEqual(gap_dist_reward(3.5), 20.0)
        self.assertAlmostEqual(gap_dist_reward(5.0), 65.0)
        self.assertAlmostEqual(gap_dist_reward(7.0), 0.0)

    def test_small_gap_penalized(self):
        self.assertLess(gap_dist_reward(1.0), -20.0)

    def test_rise_then_fall(self):
        self.assertGreater(gap_dist_reward(4.0), gap_dist_reward(3.0))
        self.assertLess(gap_dist_reward(6.0), gap_dist_reward(5.0))


class TestGapRateReward(unittest.TestCase):
    """式63：间隙变化率 ġ 分段奖励。"""

    def test_piecewise(self):
        self.assertAlmostEqual(gap_rate_reward(1.0), 40.0)     # 40*1.0
        self.assertAlmostEqual(gap_rate_reward(0.3), 6.0)      # 20*0.3
        self.assertAlmostEqual(gap_rate_reward(0.0), 0.0)      # 中性
        self.assertAlmostEqual(gap_rate_reward(-0.5), -30.0)   # 60*(-0.5)

    def test_negative_rate_penalized(self):
        self.assertLess(gap_rate_reward(-0.2), 0.0)


class TestGameReward(unittest.TestCase):
    """式64：r_game = r_gap-rate + 0.5·r_gap-dist；完成时 140。"""

    def test_in_progress_combination(self):
        self.assertAlmostEqual(game_reward(0.3, 3.5, complete=False),
                               20.0 * 0.3 + 0.5 * gap_dist_reward(3.5))

    def test_complete_overrides(self):
        self.assertAlmostEqual(game_reward(0.0, 3.5, complete=True), COMPLETE_REWARD)


class TestThwReward(unittest.TestCase):
    """式65：r_thw = 10·min(2, THW)。"""

    def test_eq65(self):
        self.assertEqual(thw_reward(5.0), 20.0)
        self.assertEqual(thw_reward(1.2), 12.0)
        # 【P1-f】论文式65 只对"存在 RV 边界"定义；无 RV(THW=inf/NaN) ⇒ 中性 0。
        #   旧口径(=+20)可被"减速制造无对手"套利，需显式打开，仅作消融对照。
        self.assertEqual(thw_reward(float('inf')), 0.0)
        self.assertEqual(thw_reward(float('nan')), 0.0)
        self.assertEqual(thw_reward(float('inf'), missing_thw_neutral=False), 20.0)

    def test_no_rv_farming_regression(self):
        """无 RV 时不得拿到正奖励；真安全(有 RV 且 THW≥2)才拿满 +20。"""
        self.assertLessEqual(thw_reward(float('inf')), 0.0)
        self.assertGreater(thw_reward(3.0), thw_reward(float('inf')))


class TestYawReward(unittest.TestCase):
    """式66（ψ = 【横摆角】取绝对值 |ψ|）：
       p_yaw = 1.0·|ψ|² + 4.0·max(|ψ|−0.2,0)² + 25.0·max(|ψ|−0.4,0)²
       r_yaw = −10·min(p_yaw, 5)
    """

    def test_zero_at_rest(self):
        self.assertAlmostEqual(yaw_reward(0.0), 0.0)

    def test_capped_at_minus_50(self):
        # p_yaw 上限 5 → r_yaw 下限 −50
        self.assertAlmostEqual(yaw_reward(10.0), -50.0)

    def test_monotonic_worse_with_larger_angle(self):
        self.assertLess(yaw_reward(2.0), yaw_reward(0.5))

    def test_below_first_threshold(self):
        # |ψ|=0.2 时 4·max(0.2−0.2,0)=0、25·max(0.2−0.4,0)=0 → p_yaw=0.04
        self.assertAlmostEqual(yaw_reward(0.2), -10.0 * min(0.2 ** 2, 5.0))

    def test_symmetric_in_sign(self):
        # 左右横摆对称惩罚
        self.assertAlmostEqual(yaw_reward(0.5), yaw_reward(-0.5))


class TestLatReward(unittest.TestCase):
    """式67（改造后）：r_lat 默认是**有界指数**，`shape='quad'` 复现论文原式。"""

    def test_zero_when_aligned(self):
        self.assertAlmostEqual(lat_reward(-138.5, -138.5), 0.0)

    def test_default_shape_is_bounded(self):
        """【2026-10-12】默认形状有界（≥ −w），且大偏差处斜率饱和。

        依据：UniPD thesis 指出二次惩罚会导致过度保守行为
        （见 PAPER_DRAFT/EVIDENCE_reward_literature.md L1）。
        """
        for dy in (0.1, 1.0, 2.0, 3.8, 10.0, 100.0):
            self.assertGreaterEqual(lat_reward(dy, 0.0), -10.0 - 1e-9)
        d_small = lat_reward(2.0, 0.0) - lat_reward(0.5, 0.0)
        d_large = lat_reward(10.0, 0.0) - lat_reward(2.0, 0.0)
        self.assertLess(abs(d_large), abs(d_small), '指数形状应在大偏差处斜率饱和')

    def test_paper_quadratic_available_for_ablation(self):
        """`shape='quad'` 必须复现论文原式（消融对照用）。"""
        self.assertAlmostEqual(lat_reward(2.0, 0.0, shape='quad'), -40.0)
        self.assertAlmostEqual(lat_reward(1.0, 0.0, shape='quad'), -10.0)

    def test_linear_shape(self):
        """`shape='linear'`：r = −w·min(|Δy|,scale)/scale。"""
        self.assertAlmostEqual(lat_reward(0.75, 0.0, shape='linear', scale=1.5, w=10.0), -5.0)
        self.assertAlmostEqual(lat_reward(3.0, 0.0, shape='linear', scale=1.5, w=10.0), -10.0)


class TestTotalReward(unittest.TestCase):
    """式68：r_total = r_game + r_thw + r_yaw + r_lat。"""

    def test_sum(self):
        self.assertAlmostEqual(total_reward(140.0, 20.0, -5.0, -2.0), 153.0)

    def test_complete_beats_collision_like(self):
        good = total_reward(game_reward(0.3, 3.5), thw_reward(2.0), yaw_reward(0.1), lat_reward(0, 0))
        done = total_reward(game_reward(0, 0, complete=True), thw_reward(2.0), yaw_reward(0.1), lat_reward(0, 0))
        self.assertGreater(done, good)


if __name__ == "__main__":
    unittest.main()
