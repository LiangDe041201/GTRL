#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【修复 D3】式24 的对手耦合通道回归测试（纯函数，无 CARLA）。

验证项目额外的“让行改善 THW”假设及其关闭口径。
论文 §III.C 允许当前观测状态下的单侧优化，并不要求两列不同。
这里的 0.5 s 修正是工程近似；这些测试只约束开启该假设时的实现，
不能作为“是否存在博弈”或“是否忠实复现论文”的一般判据。
"""
import math
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import Planning_library.cournot_game as CG
from Planning_library.cournot_game import build_payoff_matrix, _rv_thw_eff

#: 生产口径：调用点会传 jerk/steer（由候选轨迹推出）
_PROD = dict(jerk=0.3, steer=0.2)


def _U(thw_rv=1.0, thw_fv=2.0, mode='eq24', coupling=True, **kw):
    """构造支付矩阵，并临时设定耦合开关。"""
    old = CG.EQ24_RV_COUPLING
    CG.EQ24_RV_COUPLING = coupling
    try:
        return build_payoff_matrix(5.0, 12.0, v_go=4.0, thw_rv=thw_rv, thw_fv=thw_fv,
                                   u_safe_mode=mode, thw_th=1.5, **_PROD, **kw)
    finally:
        CG.EQ24_RV_COUPLING = old


class TestCournotOpponentCoupling(unittest.TestCase):

    # ---------- Conditional engineering hypothesis, not a game-theory criterion ----------
    def test_payoff_depends_on_rv_action_in_production(self):
        """开启 THW 改善假设且低于阈值时，支付应体现该假设。"""
        U = _U(thw_rv=1.0, coupling=True)
        self.assertNotAlmostEqual(
            U[1][0], U[1][1], places=9,
            msg='开启额外耦合假设时，低于阈值的 THW 应体现让行改善')

    def test_ablation_reproduces_rank1(self):
        """`DSH_U_SAFE_EQ24_RV=0` 必须**完整复现**修复前的秩1行为（消融可复现）。"""
        U = _U(thw_rv=1.0, coupling=False)
        self.assertAlmostEqual(U[1][0], U[1][1], places=9,
                               msg='关闭耦合后两列应完全相同（秩1）')

    def test_rush_yield_differ_by_bonus(self):
        """安全项本身必须等于解析值；且**支付的差值**等于安全项的差值。

        为什么测"差值"而不是"绝对值"：支付的绝对值 = speed + safe + comf，
        其中 speed/comf 只依赖 `ego_action`（jerk/steer 由候选轨迹提供）
        ⇒ 对 `rv_action` 做差可把 speed/comf 完全消掉。
        """
        from Planning_library.cournot_game import _safe_from_thw
        w, th = 1.0, 1.5
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = True
        try:
            s_rush = _safe_from_thw(1.0, 2.0, 0, th, w, mode='eq24')
            s_yield = _safe_from_thw(1.0, 2.0, 1, th, w, mode='eq24')
            U = _U(thw_rv=1.0, thw_fv=2.0, w_safe=w)   # _U 内部已固定 thw_th=1.5
        finally:
            CG.EQ24_RV_COUPLING = old
        # rush : -w·[(1.0-1.5)² + (2.0-1.5)²] = -0.5
        # yield: -w·[(1.5-1.5)² + (2.0-1.5)²] = -0.25   （RV 侧被 +0.5）
        self.assertAlmostEqual(s_rush, -w * (0.25 + 0.25), places=6)
        self.assertAlmostEqual(s_yield, -w * (0.00 + 0.25), places=6)
        self.assertAlmostEqual(U[1][0] - U[1][1], s_rush - s_yield, places=6,
                               msg='支付的 rv_action 差值必须完全来自安全项')

    # ---------- 方向必须物理正确 ----------
    def test_direction_correct_in_risk_regime(self):
        """风险区间（thw_rv < thw_th）内，RV **让行**必须使"走"更有利。

        这是耦合方向的物理检验：让行 ⇒ 间隙打开 ⇒ 走更安全。
        """
        for thw_rv in (0.2, 0.5, 1.0):
            U = _U(thw_rv=thw_rv, thw_fv=2.0, coupling=True)
            self.assertLess(U[1][0] - U[1][1], 0.0,
                            f'thw_rv={thw_rv}: 让行(rv_action=1)应比抢行更有利')

    def test_monotone_improvement_with_yield(self):
        """thw_rv 越小（越危险），让行带来的收益应越大。"""
        gains = []
        for thw_rv in (0.2, 0.5, 1.0):
            U = _U(thw_rv=thw_rv, thw_fv=2.0, coupling=True)
            gains.append(U[1][1] - U[1][0])          # yield − rush
        self.assertGreater(gains[0], gains[1])
        self.assertGreater(gains[1], gains[2])

    # ---------- 不该变的不要变 ----------
    def test_wait_row_is_rv_independent(self):
        """'等'行不应依赖对手动作（等待不取决于是谁抢/让）⇒ 修复不得改变它。"""
        U_off = _U(coupling=False)
        U_on = _U(coupling=True)
        self.assertAlmostEqual(U_off[0][0], U_on[0][0], places=9)
        self.assertAlmostEqual(U_off[0][1], U_on[0][1], places=9)

    def test_left_turn_pen_unaffected(self):
        """`left_turn_pen` 本来就有耦合 ⇒ 开关不应改变它（避免修一处坏一处）。"""
        a = _U(mode='left_turn_pen', coupling=True)
        b = _U(mode='left_turn_pen', coupling=False)
        for i in range(2):
            for j in range(2):
                self.assertAlmostEqual(a[i][j], b[i][j], places=9)

    # ---------- 辅助函数 ----------
    def test_rv_thw_eff_helper(self):
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = True
        try:
            self.assertAlmostEqual(_rv_thw_eff(1.0, 1), 1.0 + CG.RV_YIELD_THW_BONUS)
            self.assertAlmostEqual(_rv_thw_eff(1.0, 0), 1.0)
            self.assertAlmostEqual(_rv_thw_eff(1.0, 1) - _rv_thw_eff(1.0, 0),
                                   CG.RV_YIELD_THW_BONUS, places=9)
        finally:
            CG.EQ24_RV_COUPLING = old

    def test_rv_thw_eff_ablation(self):
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = False
        try:
            self.assertAlmostEqual(_rv_thw_eff(1.0, 1), 1.0)
            self.assertAlmostEqual(_rv_thw_eff(1.0, 0), 1.0)
        finally:
            CG.EQ24_RV_COUPLING = old

    def test_rv_thw_eff_does_not_raise(self):
        for bad in (None, 'x', float('nan')):
            try:
                _rv_thw_eff(bad, 1)
            except (TypeError, ValueError):
                self.fail(f'输入 {bad!r} 不应抛异常')

    # ---------- 物理约束：bonus 只能改善到阈值为止 ----------
    def test_yield_bonus_capped_at_threshold(self):
        """`THW_RV` 已 ≥ 阈值时，让行**不得**改变它。

        否则"本来已安全"会被推离阈值 ⇒ 让行反被判为更危险（符号错误）。
        该约束由既有用例 `test_thw_high_safer_than_low` 的失败暴露。
        """
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = True
        try:
            for v in (1.5, 2.0, 3.0, 10.0):
                self.assertAlmostEqual(_rv_thw_eff(v, 1, 1.5), v, places=9,
                                       msg=f'thw_rv={v} 已在阈值，让行不应改变它')
        finally:
            CG.EQ24_RV_COUPLING = old

    def test_yield_bonus_partial_near_threshold(self):
        """略低于阈值时，只抬到阈值（不越过）。"""
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = True
        try:
            self.assertAlmostEqual(_rv_thw_eff(1.2, 1, 1.5), 1.5, places=9)
            self.assertAlmostEqual(_rv_thw_eff(1.0, 1, 1.5), 1.5, places=9)
            self.assertAlmostEqual(_rv_thw_eff(0.5, 1, 1.5), 1.0, places=9)
        finally:
            CG.EQ24_RV_COUPLING = old

    def test_yield_never_worse_than_rush(self):
        """对任意 `thw_rv`，让行后的有效 THW 必须 ≥ 抢行（让行不能有害）。"""
        old = CG.EQ24_RV_COUPLING
        CG.EQ24_RV_COUPLING = True
        try:
            for v in (0.0, 0.2, 0.5, 1.0, 1.2, 1.5, 2.0, 5.0):
                self.assertGreaterEqual(_rv_thw_eff(v, 1, 1.5) + 1e-12,
                                        _rv_thw_eff(v, 0, 1.5),
                                        msg=f'thw_rv={v}: 让行不应比抢行更差')
        finally:
            CG.EQ24_RV_COUPLING = old

    def test_monotone_in_thw_with_cap(self):
        """加上限后，"THW 越高越安全（到阈值为止）"的单调性必须恢复。

        这正是既有用例 `test_thw_high_safer_than_low` 断言的性质。
        """
        U_hi = _U(thw_rv=2.0, thw_fv=2.0, coupling=True)
        U_lo = _U(thw_rv=0.5, thw_fv=0.5, coupling=True)
        self.assertGreater(U_hi[1][1], U_lo[1][1],
                           '双侧 THW 更高 ⇒ 走+让 的收益应更高（单调性）')

    # ---------- 缺失 THW 不得凭空产生偏差 ----------
    def test_missing_rv_thw_no_phantom_deviation(self):
        """RV 侧 THW 缺失时，不得因 bonus 而凭空产生偏差（否则"缺信息"伪装成"安全/危险"）。"""
        U = _U(thw_rv=float('inf'), thw_fv=2.0, coupling=True)
        for row in U:
            for v in row:
                self.assertTrue(math.isfinite(v), '缺失 THW 不应产生非有限支付')

    def test_both_sides_present_and_missing(self):
        """四种 THW 组合都不得抛异常，且有限。"""
        for rv in (0.5, 2.0, float('inf')):
            for fv in (0.5, 2.0, float('inf')):
                U = _U(thw_rv=rv, thw_fv=fv, coupling=True)
                for row in U:
                    for v in row:
                        self.assertTrue(math.isfinite(v), f'rv={rv}, fv={fv} 产生非有限值')

    def test_build_payoff_default_mode_is_eq24(self):
        """默认模式必须仍是论文原式 `eq24`（修的是式内耦合，不是换模式）。"""
        import inspect
        sig = inspect.signature(build_payoff_matrix)
        self.assertEqual(sig.parameters['u_safe_mode'].default, 'eq24')


if __name__ == '__main__':
    unittest.main(verbosity=2)
