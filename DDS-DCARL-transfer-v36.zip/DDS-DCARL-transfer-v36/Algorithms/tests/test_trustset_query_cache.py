"""Query-local samples must not leak into later WCV/BCV comparisons."""
import contextlib
import io
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Planning_library.active_inference import takeover_rule
from Planning_library.trustset_dds import Trustset


class _Neighborhood:
    def __init__(self, rows=()):
        self.rows = list(rows)

    def search(self, state):
        return list(self.rows)


class TestQueryCache(unittest.TestCase):
    def setUp(self):
        # Exercise real confidence calculations without loading saved experiments.
        self.ts = Trustset.__new__(Trustset)
        self.ts.dateset_rtree = {}
        self.ts.sample = {}
        self.ts.diag = {}
        self.ts.reward_range_env = '80'
        self.ts.var_weight = 1.0
        self.ts.driving_style = [1, 1, 1, 1]
        self.ts.Rtree_env = _Neighborhood()
        self.ts.Rtree_lane = _Neighborhood()
        self.state = np.zeros(5)
        self.sign = np.zeros(8)

    def row(self, action, reward, sign=None):
        return (self.state, self.sign if sign is None else sign, action, reward)

    def query(self, last_action=11, rule_action=4):
        with contextlib.redirect_stdout(io.StringIO()):
            return [self.ts.TS_traj_ConfidenceValue(
                self.state, self.sign, action, rule_action, last_action)
                for action in range(last_action + 1)]

    def test_repeated_query_cannot_turn_one_sample_into_takeover_evidence(self):
        self.ts.Rtree_env.rows = [self.row(4, 0.0)] * 10 + [self.row(11, 1000.0)]
        for _ in range(20):
            values = self.query()
            action, took_over = takeover_rule(
                {a: v for a, v in enumerate(values) if a != 4}, values[4], 4)
            self.assertEqual((action, took_over), (4, False))
            self.assertEqual(self.ts.dateset_rtree[11], [1000.0])

    def test_last_action_is_removed_when_neighborhood_changes(self):
        self.ts.Rtree_env.rows = [self.row(11, 1000.0)] * 10
        self.query()
        self.ts.Rtree_env.rows = [self.row(4, 0.0)] * 10
        values = self.query()
        self.assertEqual(values[11], -1e9)
        self.assertEqual(self.ts.dateset_rtree.get(11, []), [])

    def test_environment_filter_cannot_reuse_previously_matching_samples(self):
        self.ts.Rtree_env.rows = [self.row(11, 1000.0)] * 10
        self.query()
        self.sign = np.full(8, 100.0)
        values = self.query()
        self.assertEqual(values[11], -1e9)
        self.assertEqual(sum(map(len, self.ts.dateset_rtree.values())), 0)

    def test_empty_query_and_smaller_action_space_clear_all_cached_actions(self):
        self.ts.Rtree_env.rows = [self.row(23, 1.0)] * 10
        self.query(last_action=23)
        self.ts.Rtree_env.rows = []
        self.query()
        self.assertEqual(sum(map(len, self.ts.dateset_rtree.values())), 0)
        self.assertNotIn(23, self.ts.dateset_rtree)

    def test_lane_query_clears_samples_left_by_trajectory_query(self):
        self.ts.Rtree_env.rows = [self.row(11, 1.0)] * 10
        self.query()
        self.ts.TS_lane_ConfidenceValue(np.zeros(3), np.zeros((4, 2)), 0, 1, 3)
        self.assertEqual(sum(map(len, self.ts.dateset_rtree.values())), 0)
        self.assertNotIn(11, self.ts.dateset_rtree)

    def test_diagnostics_count_trajectory_confidence_calls(self):
        self.query()
        self.assertEqual(self.ts.diag.get('calls', 0), 12)


if __name__ == '__main__':
    unittest.main()
