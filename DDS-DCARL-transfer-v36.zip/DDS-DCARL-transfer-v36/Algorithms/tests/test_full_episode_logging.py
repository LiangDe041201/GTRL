"""Run the real reward dispatch and CSV writer without importing CARLA."""
import ast
import csv
import json
import math
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Planning_library.interaction_logger import EGO_COLUMNS, InteractionLogger
from Tools.run_relay_validation import summarize


class TestEpisodeRewardDispatch(unittest.TestCase):
    def dispatch(self, rl_active, collision=False):
        path = ROOT / 'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        # Execute the production block from terminal reward calculation to storage.
        # This includes the RL/non-RL dispatch, so a branch bypass is observable.
        body = next(n.body for n in ast.walk(tree) if isinstance(n, ast.While) and
                    any(isinstance(s, ast.Assign) and any(isinstance(t, ast.Name) and
                            t.id == 'terminal_reward' for t in s.targets) for s in n.body))
        start = next(i for i, s in enumerate(body) if isinstance(s, ast.Assign) and
                     any(isinstance(t, ast.Name) and t.id == 'terminal_reward' for t in s.targets))
        end = next(i for i, s in enumerate(body[start:], start) if isinstance(s, ast.Expr) and
                   isinstance(s.value, ast.Call) and isinstance(s.value.func, ast.Attribute) and
                   isinstance(s.value.func.value, ast.Name) and
                   s.value.func.value.id == 'traj_passed_data')
        calls = []
        def reward(*args, **kwargs):
            calls.append(kwargs)
            return 140. if kwargs['turn_completed'] else kwargs['terminal_reward']
        agent = S(env=S(ego_vehicle_collision_sign=collision, _turn_complete=lambda: True),
                  dynamic_map=None, terminal_scale=10., rgame_complete=True,
                  compute_causal_reward=reward, belief_learner=None)
        namespace = dict(self=agent, done=True, rl_active=rl_active, rule_action=4,
                         hybrid_action=4, used_trajectory=None, last_rl_action_in_window=None,
                         _efe_amb={4: .7}, reward=np.asarray([1., 2., 3., 50.]), os=os, np=np)
        with patch.dict(os.environ, {'DSH_FORCE_COMPLETE': '0'}):
            exec(compile(ast.Module(body=body[start:end], type_ignores=[]), str(path), 'exec'),
                 namespace)
        return namespace['causal_r'], calls

    def test_completion_reward_runs_in_non_learning_phase(self):
        value, calls = self.dispatch(False)
        self.assertEqual(len(calls), 1)
        self.assertEqual(value, 140.)
        self.assertIsNone(calls[0]['efe_ambiguity'])

    def test_collision_terminal_is_not_lost_in_non_learning_phase(self):
        value, calls = self.dispatch(False, collision=True)
        self.assertEqual(len(calls), 1)
        self.assertEqual(value, -3000.)
        self.assertFalse(calls[0]['turn_completed'])

    def test_learning_phase_keeps_its_current_action_ambiguity(self):
        _, calls = self.dispatch(True)
        self.assertEqual(calls[0]['efe_ambiguity'], {4: .7})

    def test_time_gap_rate_starts_fresh_after_episode_reset(self):
        path = ROOT / 'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and
                      n.name == '_paper_gap_and_rate')
        namespace = dict(os=os, math=math)
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(path), 'exec'), namespace)
        agent = S(_last_gap_for_rate=None)
        with patch.dict(os.environ, {'DSH_GAP_MODE': 'time'}):
            self.assertEqual(namespace['_paper_gap_and_rate'](agent, {'thw_boundary_rv': 5.}),
                             (5., 0.))
            self.assertAlmostEqual(namespace['_paper_gap_and_rate'](
                agent, {'thw_boundary_rv': 6.})[1], 20.)


class TestControlLog(unittest.TestCase):
    def test_controls_and_completion_roundtrip_without_column_shift(self):
        with tempfile.TemporaryDirectory() as directory:
            log = InteractionLogger(out_dir=directory, enabled=True)
            log.begin_episode(1)
            log.ego_row(ego=S(x=1., y=2., v=3.), action=4, rl_active=False,
                        control=dict(a_mpc=-1., delta_mpc_rad=-.2, a_cmd=-1.,
                                     delta_rad=-.2, throttle=0., brake=1./3., steer=-.2,
                                     mpc_l=.4, mpc_epsi=.15, mpc_solve_ok=True,
                                     planning_status='planner_stop', trajectory_force_stop=True,
                                     trajectory_speed_limit=0., execution_reason='planner_stop',
                                     v_ref_before_guard=6., goal_remaining=12.,
                                     geometry_source='road_recovery', a_prev=-.9, steer_prev=-.1,
                                     game_controller='mpc_cournot', stackelberg_active=False,
                                     mpc_game=dict(enabled=True, active=True, rv_id=42, fv_id=43,
                                         safety_mode='deficit', speed=.1, safety=.5,
                                         comfort=.2, total=.8),
                                     learning=dict(learning_mode='soft_belief', belief_rv_id=42,
                                         belief=[.1,.2,.1,.2,.1,.3], belief_entropy=1.2,
                                         belief_evidence=.3, soft_policy=[.25,.75],
                                         baseline_policy=[.9,.1], behavior_policy=[0.,1.],
                                         soft_value=5., soft_information_cost=.5,
                                         information_cost=2.3, bellman_residual=.01,
                                         bellman_sweeps=5, learning_decision=True,
                                         behavior_model_valid=True)),
                        completion=dict(strict_complete=False, legacy_complete=True,
                                        goal_distance=8., path_distance=7.,
                                        heading_error=.1, path_progress=.95))
            log.close()
            with (Path(directory) / 'interaction_ego.csv').open(newline='', encoding='utf-8-sig') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(list(row), EGO_COLUMNS)
            for key, expected in {'rl_active': '0', 'mpc_solve_ok': '1',
                                  'complete_strict': '0', 'complete_legacy': '1',
                                  'trajectory_force_stop': '1', 'planning_status': 'planner_stop',
                                  'execution_guard_reason': 'planner_stop',
                                  'mpc_geometry_source': 'road_recovery',
                                  'learning_mode': 'soft_belief', 'belief_rv_id': '42',
                                  'learning_decision': '1', 'behavior_model_valid': '1',
                                  'game_controller': 'mpc_cournot', 'mpc_game_enabled': '1',
                                  'mpc_game_active': '1', 'mpc_game_rv_id': '42',
                                  'mpc_game_fv_id': '43', 'stackelberg_active': '0'}.items():
                self.assertEqual(row[key], expected)
            for key, expected in {'a_cmd': -1., 'delta_mpc_rad': -.2, 'mpc_epsi': .15,
                                  'goal_path_distance': 7., 'goal_progress': .95,
                                  'trajectory_speed_limit': 0., 'v_ref_before_guard': 6.,
                                  'goal_remaining': 12., 'a_prev': -.9, 'steer_prev': -.1,
                                  'soft_value': 5., 'information_cost': 2.3,
                                  'soft_information_cost': .5, 'bellman_residual': .01,
                                  'mpc_game_total_cost': .8, 'mpc_game_safety_cost': .5}.items():
                self.assertAlmostEqual(float(row[key]), expected)
            self.assertEqual(json.loads(row['belief_vector']), [.1,.2,.1,.2,.1,.3])
            self.assertEqual(json.loads(row['baseline_policy']), [.9,.1])


class TestRunSummary(unittest.TestCase):
    def summary(self, frames, columns=EGO_COLUMNS, overrides=None,
                expected_game=None, expected_method=None):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path / 'interaction_summary.csv').write_text(
                'episode,outcome,frames\n1,complete,2\n', encoding='utf-8')
            (path / 'run.log').write_text('', encoding='utf-8')
            with (path / 'interaction_ego.csv').open('w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=columns)
                writer.writeheader()
                for frame in frames:
                    row = dict(episode=1, frame=frame, rl_active=0,
                               complete_fired=int(frame == 2),
                               complete_strict=int(frame == 2), complete_legacy=int(frame == 2),
                               a_mpc=0., a_cmd=0., delta_mpc_rad=0., steer=0., v_ref=2.,
                               a_prev=0., steer_prev=0., trajectory_force_stop=0,
                               planning_status='normal', mpc_geometry_source='planned')
                    row.update((overrides or {}).get(frame, {}))
                    writer.writerow({k: v for k, v in row.items() if k in columns})
            return summarize(path, 1, 0, expected_game=expected_game, expected_method=expected_method)

    def test_game_validation_requires_real_cost_and_method_isolation(self):
        game = dict(game_controller='mpc_cournot', mpc_game_enabled=1, mpc_game_active=1,
                    mpc_game_rv_id=42, mpc_game_fv_id='', mpc_game_safety_mode='deficit',
                    mpc_game_speed_cost=.1, mpc_game_safety_cost=.5,
                    mpc_game_comfort_cost=.2, mpc_game_total_cost=.8, stackelberg_active=0)
        result = self.summary([1, 2], overrides={1: game, 2: game},
                              expected_game=True, expected_method='CG')
        self.assertTrue(result['game_contract_ok'])
        self.assertEqual(result['mpc_game_active_rows'], 2)
        self.assertEqual(result['mpc_game_nonzero_cost_rows'], 2)
        for bad in (dict(mpc_game_total_cost=.9), dict(stackelberg_active=1),
                    dict(mpc_game_active=0), dict(mpc_game_rv_id='')):
            result = self.summary([1, 2], overrides={1: game, 2: dict(game, **bad)},
                                  expected_game=True, expected_method='CG')
            self.assertFalse(result['game_contract_ok'])
        result = self.summary([1, 2], overrides={1: game, 2: game}, expected_game=False)
        self.assertFalse(result['game_contract_ok'])

    def test_game_off_does_not_need_active_participants(self):
        off = dict(game_controller='none', mpc_game_enabled=0, mpc_game_active=0,
                   mpc_game_speed_cost=0., mpc_game_safety_cost=0.,
                   mpc_game_comfort_cost=0., mpc_game_total_cost=0., stackelberg_active=0)
        result = self.summary([1, 2], overrides={1: off, 2: off},
                              expected_game=False, expected_method='CG')
        self.assertTrue(result['game_contract_ok'])

    def test_full_log_counts_non_learning_frames_and_terminal_reward(self):
        result = self.summary([1, 2])
        self.assertTrue(result['complete'])
        self.assertEqual(result['nonrl_log_rows'], 2)
        self.assertEqual(result['completion_reward_log_rows'], 1)
        self.assertTrue(result['execution_contract_ok'])

    def test_summary_counts_measured_and_modelled_acceleration_separately(self):
        result = self.summary([1, 2], overrides={
            1: dict(rv_acc_source='unavailable', rv_acc_follow_pred=.5,
                    rv_acc_follow_source='idm_from_observation'),
            2: dict(rv_acc_observed=-1., rv_acc_source='velocity_difference',
                    rv_acc_follow_pred=.4, rv_acc_follow_source='idm_from_observation')})
        self.assertTrue(result['complete'])
        self.assertEqual(result['rv_acc_observed_rows'], 1)
        self.assertEqual(result['rv_acc_follow_prediction_rows'], 2)
        self.assertEqual(result['rv_acc_sources'], {'unavailable': 1, 'velocity_difference': 1})

    def test_finished_episode_with_missing_or_duplicate_frames_is_incomplete(self):
        for frames in ([1], [1, 1]):
            self.assertFalse(self.summary(frames)['complete'])

    def test_old_log_without_control_and_completion_columns_is_incomplete(self):
        result = self.summary([1, 2], columns=['episode', 'frame'])
        self.assertFalse(result['complete'])
        self.assertIn('mpc_epsi', result['missing_log_columns'])

    def test_control_bound_and_stop_errors_are_not_reported_as_success(self):
        result = self.summary([1, 2], overrides={2: dict(a_mpc=3.8, a_cmd=1., v_ref=0.)})
        self.assertTrue(result['complete'])  # Completion means logs and episodes are intact.
        self.assertFalse(result['execution_contract_ok'])
        self.assertEqual(result['control_bound_violations'], {'a_mpc': 1})
        self.assertEqual(result['stop_target_positive_acceleration_rows'], 1)

    def test_planner_stop_and_actual_feedback_must_survive_dispatch(self):
        result = self.summary([1, 2], overrides={
            1: dict(a_cmd=-.8, planning_status='planner_stop', trajectory_force_stop=1),
            2: dict(a_prev=0.)})
        self.assertFalse(result['execution_contract_ok'])
        self.assertEqual(result['planner_stop_positive_target_rows'], 1)
        self.assertEqual(result['applied_feedback_mismatch_rows'], 1)

    def test_invalid_control_values_cannot_pass_validation(self):
        result = self.summary([1, 2], overrides={2: dict(a_cmd='nan')})
        self.assertFalse(result['execution_contract_ok'])
        self.assertEqual(result['invalid_control_rows'], 1)


if __name__ == '__main__':
    unittest.main()
