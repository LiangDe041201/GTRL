"""Checks tied to recorded v10 defects and collection integrity, without CARLA."""
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

import numpy as np
from Planning_library.pedal_control import PedalControllerV10, PedalControllerV11
from Planning_library.control_probe import StopRestartProbe
from Planning_library.execution_guard import rollout
from Tools import run_relay_validation as relay
from Tools.run_actuator_sweep import cases, run_case, main as sweep_main
from Tools.validate_control_health import validate_control_health

GAIN = 3200./(.355*1696.)


class TestLowSpeedControl(unittest.TestCase):
    def test_recorded_shock_entry_releases_accumulated_brake(self):
        old, new = PedalControllerV10(GAIN, 1.2), PedalControllerV11(GAIN, 1.2)
        for controller in (old, new):
            controller.brake, controller.raw_acceleration = .149098, -1.578172
        previous = old.command(-2.423383, .761180, 0., 0.)
        corrected = new.command(-2.423383, .761180, 0., 0.)
        self.assertGreater(previous['brake'], .15)
        self.assertLess(corrected['brake'], .073)
        self.assertAlmostEqual(new.target_acceleration, -1.5*.761180)
        self.assertEqual(corrected['throttle'], 0.)

    def test_brake_cap_falls_with_speed_instead_of_retaining_integral_torque(self):
        controller = PedalControllerV11(GAIN, 1.2)
        outputs = []
        for speed in (1.19, 1., .76, .4, .12):
            controller.brake = .3
            outputs.append(controller.command(-3., speed, 0., 0.)['brake'])
        self.assertEqual(outputs, sorted(outputs, reverse=True))
        self.assertLess(outputs[-1], .003)
        self.assertEqual(controller.command(-3., .01, 0., 0.)['brake'], .02)

    def test_stationary_drive_cannot_wind_up_to_old_throttle_saturation(self):
        controller = PedalControllerV11(GAIN, 1.2)
        for _ in range(100):
            request = controller.command(2., 0., 4., 0.)
        self.assertLessEqual(request['throttle'], .35)
        self.assertEqual(controller.integral, 0.)

    def test_measured_positive_surge_releases_throttle(self):
        controller = PedalControllerV11(GAIN, 1.2)
        controller.throttle = .3
        controller.observe(.223004, .681793, .05)
        self.assertEqual(controller.command(2., .681793, 4., 0.)['throttle'], 0.)

    def test_nonfinite_request_is_rejected(self):
        with self.assertRaises(ValueError):
            PedalControllerV11(GAIN, 1.2).command(-3., math.nan, 0., 0.)

    def test_audit_does_not_credit_unavailable_low_speed_braking(self):
        ego = S(x=0., y=0., yaw=0., v=1., vx=1., vy=0.)
        path = np.c_[np.linspace(0., 30., 61), np.zeros(61)]
        geometry = dict(wheelbase=2.86, max_steer=1.2)
        args = (ego, path, 0., -3., 0., dict(a=-3., df=0.))
        old, _ = rollout(*args, geometry, horizon=2.3, lag=0.)
        new, _ = rollout(*args, dict(geometry, low_speed_brake_taper=.5), horizon=2.3, lag=0.)
        self.assertGreater(new[0, -1], old[0, -1]+.5)


class TestVariedProbe(unittest.TestCase):
    def test_case_speed_really_changes_target_and_transition_threshold(self):
        slow, fast = StopRestartProbe(cruise_speed=2.), StopRestartProbe(cruise_speed=4.)
        self.assertEqual(slow.target(5.), 2.)
        self.assertEqual(fast.target(5.), 4.)
        for probe in (slow, fast):
            for _ in range(90):
                probe.observe(2.)
        self.assertEqual(slow.phase, 'decelerate')
        self.assertEqual(fast.phase, 'cruise')
        with self.assertRaises(ValueError):
            StopRestartProbe(cruise_speed=math.nan)

    def test_sweep_has_all_18_explicit_speed_torque_cases(self):
        plan = cases()
        self.assertEqual(len(plan), 18)
        self.assertEqual(len({c['case_id'] for c in plan}), 18)
        self.assertEqual({c['launch_speed'] for c in plan}, {1., 2., 3.})
        self.assertEqual({c['pulse_brake'] for c in plan}, {0., .01, .15})
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(sweep_main(['--dry-run']), 0)
        self.assertEqual(len(json.loads(stream.getvalue())['cases']), 18)

    def test_sweep_reaches_low_speed_and_preserves_shock_sample(self):
        class Environment:
            dt = .05
            def reset(self, train):
                self.pedal_controller = PedalControllerV11(GAIN, 1.2)
                self.speed, self.frame = 0., 0
            def step(self, action, target_speed):
                before = self.speed
                command = self.pedal_controller.command(*[action[0], before, target_speed, 0.])
                self.speed = (max(0., self.speed-.1) if self.pedal_controller.pulse
                              else min(target_speed, self.speed+.1))
                self.frame += 1
                self.last_control = dict(command, ego_v_before=before, ego_v_after=self.speed,
                    ego_acc_measured=(self.speed-before)/self.dt, control_submit_ok=1,
                    control_transport='batch_sync_pre_tick', control_tick_frame=self.frame,
                    control_feedback_frame=self.frame, sim_frame_after=self.frame,
                    sim_frame_before=self.frame-1, sim_dt=.05,
                    **{'requested_'+k: command[k] for k in ('throttle', 'brake', 'steer')})
                return None, None, False, None
        sink = []
        result = run_case(Environment(), cases()[0], sink)
        self.assertTrue(result['technical_ok'])
        self.assertTrue(result['stopped'])
        self.assertTrue(result['reached_below_0_8'])
        class Shock(Environment):
            def step(self, *args, **kwargs):
                result = super().step(*args, **kwargs)
                if self.pedal_controller.pulse:
                    self.last_control['ego_acc_measured'] = -11.2793
                return result
        sink = []
        result = run_case(Shock(), cases()[0], sink)
        self.assertTrue(result['technical_ok'])
        self.assertTrue(result['physical_shock'])
        self.assertEqual(result['pulse_frames'], 1)
        self.assertEqual(sink[-1]['ego_acc_measured'], -11.2793)


class TestCollectionIntegrity(unittest.TestCase):
    def test_default_pair_has_identical_common_control_and_no_rl_efe(self):
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(relay.main(['--dry-run']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertTrue(all(c['DSH_CONTROL_PROFILE'] == 'paper_v11' and c['DSH_EFE'] == '0' for c in configs))
        self.assertEqual({k for k in configs[0] if configs[0][k] != configs[1][k]},
                         {'DSH_METHOD', 'DSH_TAKE_COURNOT'})

    def test_keep_going_collects_four_runs_but_returns_failure_and_manifest(self):
        good = dict(complete=True, outcomes={'complete': 2}, execution_contract_ok=True, game_contract_ok=True)
        bad = dict(good, complete=False)
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)/'results'
            with patch.object(relay.subprocess, 'run', return_value=S(returncode=0)) as process, \
                    patch.object(relay, 'summarize', side_effect=[bad, good, good, good]), \
                    contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                code = relay.main(['--output-root', str(output), '--control-profile', 'legacy',
                                   '--episodes', '2', '--seeds', '1,2', '--keep-going'])
            self.assertEqual(process.call_count, 4)
            self.assertEqual(code, 1)
            manifest = json.loads((output/'manifest.json').read_text(encoding='utf8'))
            self.assertFalse(manifest['overall_success'])
            self.assertTrue(manifest['collection_finished'])
            self.assertEqual(len(manifest['runs']), 4)
            self.assertEqual(len(manifest['failures']), 1)
            self.assertTrue((output/'C1_cg_seed2/result.json').is_file())

    def test_v11_health_does_not_ignore_positive_acceleration_spike(self):
        row = dict(ego_acc_measured='9.175787', mpc_solve_ok='1')
        health = validate_control_health([row], {'complete': 1}, traffic='off', profile='paper_v11')
        self.assertEqual(health['severe_acceleration_rows'], 1)
        self.assertFalse(health['empty_road_health_ok'])
        self.assertIn('severe_acceleration', health['empty_road_health_errors'])


if __name__ == '__main__':
    unittest.main()
