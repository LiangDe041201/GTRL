"""Offline diagnostics use future truth only as scores and detect altered payoffs."""
import csv
import json
import math
from pathlib import Path
import tempfile
import unittest

from Planning_library.matrix_turn_game_v14 import MatrixTurnGameV14
from Tools.replay_matrix_v14 import motion_replay,snapshot_replay
from tests.test_matrix_turn_game_v13 import vehicle,candidate,GEOMETRY,PATH


class TestOfflineReplay(unittest.TestCase):
    def test_fixed_slow_observations_favour_the_observed_motion_forecast(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);run=root/'M1_matrix_seed4';run.mkdir()
            (root/'manifest.json').write_text(json.dumps(dict(runs=[dict(arm='M1_matrix',seed=4)])))
            (run/'traffic_spacing_metadata.json').write_text(json.dumps(dict(cruise_speed=4.4,measured_length=4.)))
            with (run/'traffic_spacing_samples.csv').open('w',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=['episode','frame','actor_id','x','y','observed_speed',
                                                         'behavior','commanded_speed'])
                writer.writeheader()
                for frame in range(1,201):
                    writer.writerow(dict(episode=3,frame=frame,actor_id=2,x=20.-.375*frame*.05,y=0.,
                                         observed_speed=.375,behavior='secret',commanded_speed=99.))
            (run/'matrix_decisions.jsonl').write_text('\n'.join(json.dumps(dict(episode=3,frame=f,
                active=True,rv_id=2)) for f in (20,40,60,80))+'\n')
            result=motion_replay(root,seed=4,episode=3)
            self.assertEqual(result['considered_frames'],4)
            for horizon in result['horizons_seconds'].values():
                self.assertEqual(horizon['n'],4)
                self.assertLess(horizon['v14_mean_position_error_m'],1e-10)
                self.assertGreater(horizon['v13_mean_position_error_m'],.5)

    def test_snapshot_scores_reproduce_and_payoff_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as folder:
            ego,rv=vehicle(speed=0.),vehicle(2,7.6,0.,math.pi,.375,0.)
            game=MatrixTurnGameV14(GEOMETRY,directory=folder)
            game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,4.,(-20.,0.,math.pi))
            game.choose(ego,[rv],rv,{},[candidate(0.,-.3),candidate(4.,.1)],PATH,dict(a=0.,df=0.))
            game.record(1,1,.1,0.,4.,dict(action='mpc',override=False,safe=True),
                dict(a_cmd=.1,delta_rad=0.,actuator_speed_target=4.,control_submit_ok=1))
            path=Path(folder)/'matrix_snapshots.jsonl'
            self.assertTrue(snapshot_replay(path)['replay_ok'])
            row=json.loads(path.read_text());row['decision']['payoff_matrix'][1][0]+=1.
            path.write_text(json.dumps(row)+'\n')
            self.assertFalse(snapshot_replay(path)['replay_ok'])


if __name__=='__main__':
    unittest.main()
