"""Real snapshot/production adapter regressions; no CARLA installation required."""
import ast
import math
from pathlib import Path
import sys
from types import SimpleNamespace as S
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Planning_library.scenario_snapshot import VehicleState
from Planning_library.vehicle_observation import (
    vehicle_id, longitudinal_acceleration, motion_observation, MotionHistory,
    following_acceleration)
from Planning_library.rv_decision import idm_acceleration
from Planning_library.define_state_space_turn import crossing_conflict_detail
from Planning_library.objective_reward import _veh_list


def car(actor=42, speed=4., x=20., y=-138.):
    return S(carla_id=actor, x=x, y=y, yaw=math.pi, v=speed,
             vx=-speed, vy=0., ax=0., ay=0., acc=None, acc_source='unavailable',
             boxx=3.6, boxy=1.8)


class TestObservedMotion(unittest.TestCase):
    def test_identity_survives_snapshot_and_normalization(self):
        for obj in (car(), VehicleState(veh_id=42), S(veh_id=-1, carla_id=42), {'id': 42}):
            self.assertEqual(vehicle_id(obj), 42)
        self.assertEqual(vehicle_id(S(veh_id=0)), 0)
        self.assertIsNone(vehicle_id(None))
        for invalid in (-1, None, True, float('nan'), float('inf'), 1.5):
            self.assertIsNone(vehicle_id(S(veh_id=invalid)))
        row = _veh_list([car(actor=0)])[0]
        self.assertEqual(row['id'], 0)
        self.assertEqual(row['length'], 3.6)
        self.assertIsNone(row['acc'])

    def test_initial_default_axes_are_not_measured_acceleration(self):
        self.assertIsNone(longitudinal_acceleration(car()))
        self.assertIsNone(longitudinal_acceleration(VehicleState(veh_id=42)))

    def test_braking_projection_uses_direction_of_motion(self):
        rv = car()
        rv.ax, rv.acc_source = 1., 'velocity_difference'
        self.assertEqual(longitudinal_acceleration(rv), -1.)
        self.assertEqual(motion_observation(rv, 2.), 0)
        rv.ax = -1.
        self.assertEqual(motion_observation(rv, 2.), 2)

    def test_velocity_differences_duplicate_frames_and_real_elapsed_time(self):
        history, rv = MotionHistory(), car()
        history.update([rv], 1.)
        self.assertIsNone(rv.acc)
        rv.v, rv.vx = 3.9, -3.9
        history.update([rv], 1.1)
        self.assertAlmostEqual(rv.acc, -1.)
        reread = car(speed=3.9)
        history.update([reread], 1.1)
        self.assertAlmostEqual(reread.acc, -1.)
        self.assertEqual(reread.acc_source, 'velocity_difference')
        reread.v, reread.vx = 3.5, -3.5
        history.update([reread], 1.3)
        self.assertAlmostEqual(reread.acc, -2.)

    def test_disappearance_reset_and_invalid_time_require_new_evidence(self):
        for timestamp in (None, float('nan'), .5):
            history, rv = MotionHistory(), car()
            history.update([rv], 1.)
            history.update([rv], timestamp)
            self.assertIsNone(rv.acc)
        history, rv = MotionHistory(), car()
        history.update([rv], 1.)
        history.update([], 1.05)
        history.update([rv], 1.1)
        self.assertIsNone(rv.acc)
        history.reset()
        history.update([rv], 1.15)
        self.assertIsNone(rv.acc)

    def test_different_vehicles_are_not_used_as_temporal_neighbors(self):
        history = MotionHistory()
        history.update([car(actor=1, speed=8.)], 1.)
        rv = car(actor=2, speed=1.)
        history.update([rv], 1.05)
        self.assertIsNone(rv.acc)

    def test_observed_zero_has_a_source(self):
        history, rv = MotionHistory(), car()
        history.update([rv], 1.)
        history.update([rv], 1.05)
        self.assertEqual(rv.acc, 0.)
        self.assertEqual(rv.acc_source, 'velocity_difference')


class TestFollowingPrediction(unittest.TestCase):
    def test_nearest_visible_leader_and_body_gap(self):
        rv = VehicleState(veh_id=42, x=20., y=-138., yaw=math.pi, v=4., vx=-4., length=4.)
        front = VehicleState(veh_id=43, x=10., y=-138., yaw=math.pi, v=3., vx=-3., length=4.)
        behind = VehicleState(veh_id=44, x=25., y=-138., yaw=math.pi, v=1., vx=-1.)
        crossing = VehicleState(veh_id=45, x=19., y=-138., yaw=-math.pi/2, v=2., vy=-2.)
        result = following_acceleration(rv, [rv, behind, crossing, front])
        self.assertAlmostEqual(result, idm_acceleration(4., 3., 6., v0=6.))
        self.assertAlmostEqual(result, following_acceleration(
            dict(id=42, x=20., y=-138., yaw=math.pi, v=4., vx=-4., vy=0., length=4.),
            [rv, front, crossing]))

    def test_free_flow_with_no_visible_leader_is_an_explicit_prediction(self):
        rv = VehicleState(veh_id=42, yaw=math.pi, v=4., vx=-4.)
        self.assertAlmostEqual(following_acceleration(rv, [rv]),
                               idm_acceleration(4., 4., float('inf'), v0=6.))
        self.assertIsNone(following_acceleration(None, []))

    def test_conflict_snapshot_never_reads_private_traffic_state(self):
        class Environment:
            INTERSECTION_CENTER = (6., -138.)
            ref_path_array = np.array([[6., -120.], [6., -130.], [6., -140.], [0., -145.]])

            @property
            def cross_traffic(self):
                raise AssertionError('A decision input must not read private simulator state')

        env = Environment()
        ego = S(carla_id=10, x=6., y=-125., v=3., vx=0., vy=-3., yaw=-math.pi/2)
        rv = car(x=40.)
        rv.acc, rv.acc_source = -1.25, 'velocity_difference'
        conf = crossing_conflict_detail(S(ego_vehicle=ego, objects=[rv], env=env), env)
        self.assertIsInstance(conf['rv_veh'], VehicleState)
        self.assertEqual(conf['rv_actor_id'], 42)
        self.assertEqual(conf['rv_acc'], -1.25)
        self.assertEqual(conf['game_state']['rv']['acc'], -1.25)
        self.assertEqual(conf['rv_veh'].length, 3.6)
        self.assertEqual(conf['rv_acc_source'], 'velocity_difference')
        self.assertEqual(conf['rv_acc_follow_source'], 'idm_from_observation')
        rv.acc, rv.acc_source = None, 'unavailable'
        conf = crossing_conflict_detail(S(ego_vehicle=ego, objects=[rv], env=env), env)
        self.assertIsNone(conf['rv_acc'])
        self.assertEqual(conf['rv_acc_source'], 'unavailable')


class TestProductionDynamicMap(unittest.TestCase):
    def dynamic_map(self):
        path = ROOT/'Agent/tools_dds/dynamic_map.py'
        classes = [node for node in ast.parse(path.read_text(encoding='utf-8-sig')).body
                   if isinstance(node, ast.ClassDef)]
        ns = dict(math=math, np=np, MotionHistory=MotionHistory)
        exec(compile(ast.Module(body=classes, type_ignores=[]), str(path), 'exec'), ns)
        dynamic_map = ns['DynamicMap']()
        dynamic_map.get_lane_information = lambda world: 0
        return dynamic_map

    def test_actual_production_update_passes_observed_velocity_and_simulation_time(self):
        def actor(actor_id, role, x, y, vx, vy, yaw):
            result = S(id=actor_id, attributes={'role_name': role}, velocity=S(x=vx, y=vy, z=0.),
                       bounding_box=S(extent=S(x=1.8, y=.9)))
            result.get_location = lambda: S(x=x, y=y)
            result.get_velocity = lambda: result.velocity
            result.get_transform = lambda: S(rotation=S(yaw=yaw))
            result.get_angular_velocity = lambda: S(x=0., y=0., z=0.)
            return result

        ego = actor(10, 'ego_vehicle', 6., -125., 0., -3., -90.)
        rv = actor(42, 'cross', 40., -138., -4., 0., 0.)

        class ActorList(list):
            def filter(self, pattern):
                return self if pattern == '*vehicle*' else []

        world = S(seconds=1.)
        world.get_actors = lambda: ActorList([ego, rv])
        world.get_snapshot = lambda: S(timestamp=S(elapsed_seconds=world.seconds))
        env, dynamic_map = S(world=world), self.dynamic_map()
        dynamic_map.update_map(env)
        self.assertEqual(dynamic_map.ego_vehicle.carla_id, 10)
        self.assertEqual(dynamic_map.objects[0].vx, -4.)  # Not speed*cos(yaw).
        self.assertIsNone(dynamic_map.objects[0].acc)
        rv.velocity.x, world.seconds = -3.95, 1.05
        dynamic_map.update_map(env)
        self.assertAlmostEqual(dynamic_map.objects[0].acc, -1.)
        dynamic_map.update_map(env)
        self.assertAlmostEqual(dynamic_map.objects[0].acc, -1.)
        dynamic_map.reset_motion_history()
        world.seconds = 1.1
        dynamic_map.update_map(env)
        self.assertIsNone(dynamic_map.objects[0].acc)


if __name__ == '__main__':
    unittest.main()
