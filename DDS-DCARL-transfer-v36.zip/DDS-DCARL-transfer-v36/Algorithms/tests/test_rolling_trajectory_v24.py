"""Local actions must replan from the real state without inventing road tails."""
import math
from types import SimpleNamespace as S
import unittest
import numpy as np

try:
    from Planning_library.rolling_trajectory_v24 import RollingFamily, path_cost
except ImportError:
    RollingFamily = path_cost = None


class RollingTrajectoryTests(unittest.TestCase):
    def family(self):
        self.assertIsNotNone(RollingFamily, 'Rolling local trajectory actions are missing')
        return RollingFamily([[0., 0.], [30., 0.], [100., 0.]])

    def test_local_plan_starts_at_real_pose_and_ends_at_declared_offset(self):
        f = self.family()
        p = f.generate(S(x=2., y=.1, yaw=.03, v=2.), {'a':0., 'df':.02}, 2.8, .2, 4.)
        np.testing.assert_allclose(p['path'][0], [2.,.1], atol=1e-9)
        self.assertAlmostEqual(p['poses'][0,2], .03, places=8)
        self.assertAlmostEqual(p['curvature'][0], math.tan(.02)/2.8, places=8)
        self.assertAlmostEqual(p['path'][-1,1], .2, places=8)
        self.assertLess(p['path'][-1,0], 40.)
        self.assertAlmostEqual(p['d_d'][-1],0.,places=9)
        self.assertAlmostEqual(p['d_dd'][-1],0.,places=9)

    def test_next_decision_reconstructs_the_same_action_from_new_observation(self):
        f = self.family()
        a = f.generate(S(x=2.,y=0.,yaw=0.,v=2.), {'a':0.,'df':0.},2.8,.2,4.)
        b = f.generate(S(x=3.,y=.05,yaw=.01,v=2.), {'a':0.,'df':.01},2.8,.2,4.)
        self.assertGreater(b['start_arc'],a['start_arc'])
        np.testing.assert_allclose(b['path'][0],[3.,.05],atol=1e-9)
        self.assertFalse(np.array_equal(a['path'],b['path']))

    def test_terminal_actions_make_opposite_local_geometries(self):
        f=self.family(); ego=S(x=2.,y=0.,yaw=0.,v=2.)
        left=f.generate(ego,{'a':0.,'df':0.},2.8,-.2,4.)
        right=f.generate(ego,{'a':0.,'df':0.},2.8,.2,4.)
        self.assertLess(left['path'][-1,1],-.19)
        self.assertGreater(right['path'][-1,1],.19)
        self.assertGreater(path_cost(left['path']),0.)
        self.assertAlmostEqual(path_cost(left['path']),path_cost(right['path']),places=6)

    def test_too_short_public_reference_is_rejected_instead_of_extrapolated(self):
        self.assertIsNotNone(RollingFamily)
        f=RollingFamily([[0.,0.],[10.,0.]])
        with self.assertRaises(ValueError):
            f.generate(S(x=9.,y=0.,yaw=0.,v=2.),{'a':0.,'df':0.},2.8,.2,4.)

    def test_fixed_rule_compares_the_same_local_length_instead_of_diluting_cost_with_a_long_tail(self):
        self.family()
        x=np.linspace(0.,20.,101); y=.2*np.sin(x/4.)
        short=np.c_[x,y]
        long=np.vstack((short,[[v,y[-1]] for v in np.linspace(20.2,80.,300)]))
        self.assertAlmostEqual(path_cost(short),path_cost(long),places=8)


if __name__=='__main__': unittest.main()
