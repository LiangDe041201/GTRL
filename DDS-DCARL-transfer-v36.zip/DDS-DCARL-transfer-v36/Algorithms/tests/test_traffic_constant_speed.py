#!/usr/bin/env python3
"""【§63】交叉车流"恒定速度 + 安全距离跟车"模型的独立对拍测试。

存在理由（一句话）：旧模型在无前车/间距大时会**自由流加速到 6.0 m/s**，
把让行刚打开的插入间隙**关掉**；而 ego 需要窗口维持 6.1 s，实测只活 ~2 s。
本测试直接量化"让行结束后间隙是否还在"。

运行: python tests/test_traffic_constant_speed.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Planning_library.rv_decision import traffic_speed_step, idm_acceleration

FAILED = []


def chk(name, cond, detail=''):
    print('%-56s %s %s' % (name, 'ok' if cond else 'FAIL', detail))
    if not cond:
        FAILED.append(name)


V_CONST = 4.41          # 出生/恒定速度（8.6 m 中心距下的 IDM 平衡速度）
VEH_LEN = 3.6
DT = 0.05
G0, T, A, B, DELTA = 2.0, 0.5, 2.0, 2.5, 4.0
V0_OLD = 6.0            # 旧模型的空路期望速度


def _old_step(v, front_v, gap, target, dt=DT):
    """旧模型：IDM(v0=6.0) + 让行目标(受限减速度)。返回 new_v。"""
    if front_v is None:
        acc = A * (1 - (v / V0_OLD) ** DELTA)
    else:
        acc = idm_acceleration(v, front_v, gap, v0=V0_OLD, T=T, g0=G0,
                               a=A, b=B, delta=DELTA)
    nv = max(0.5, v + acc * dt)
    nv = min(nv, V0_OLD * 1.1)
    if target is not None:                     # 让行目标（1.32）
        drop = 2.5 * dt
        if nv > target:
            nv = max(target, nv - drop)
        else:
            nv = min(nv, max(target, 0.5))
    return nv


def _new_step(v, front_v, gap, target, dt=DT):
    """新模型：恒定速度 + 安全距离跟车。`target` 仅用于让行（1.32）。"""
    nv, _ = traffic_speed_step(v, front_v, gap, v_const=V_CONST, T=T, g0=G0,
                               a=A, b=B, delta=DELTA, dt=dt)
    if target is not None:
        drop = 2.5 * dt
        if nv > target:
            nv = max(target, nv - drop)
        else:
            nv = min(nv, max(target, 0.5))
    return nv


# ---------- 1. 基本性质 ----------
v, acc = traffic_speed_step(V_CONST, V_CONST, 5.0)
chk('安全间距下保持恒定速度（acc==0）', abs(v - V_CONST) < 1e-12 and abs(acc) < 1e-12,
    'v=%.4f acc=%.4f' % (v, acc))

v2, _ = traffic_speed_step(V_CONST, 1.0, 2.0)       # 间距 2.0 < s_safe=4.21
chk('间距不足时制动', v2 < V_CONST, 'v=%.4f' % v2)

v3, _ = traffic_speed_step(V_CONST, 1.0, 5.0)       # 间距充足，但已到恒定速度
chk('绝不超过恒定速度（上限）', v3 <= V_CONST + 1e-12, 'v=%.4f' % v3)

v4, _ = traffic_speed_step(1.32, None, float('inf'))
chk('无前车时从低速**恢复**到恒定速度（不越过）', 1.32 < v4 <= V_CONST + 1e-12,
    '1.32 -> %.4f' % v4)

# 恢复若干帧后应停在 V_CONST
vv = 1.32
for _ in range(400):
    vv, _ = traffic_speed_step(vv, None, float('inf'))
chk('长期恢复到恒定速度且稳定', abs(vv - V_CONST) < 1e-3, 'v=%.5f' % vv)

# 旧模型对照：无前车时会冲到 6.0 附近
vo = 1.32
for _ in range(400):
    vo = _old_step(vo, None, float('inf'), None)
chk('旧模型对照：无前车会加速到 ~6.0（这就是问题）', vo > 5.9, 'old v=%.4f' % vo)


# ---------- 2. 核心性质：让行结束后，插入间隙是否还在 ----------
def simulate(step_fn, rush_target, yield_sec=1.0, total_sec=6.0, d0=8.6):
    """两车：leader（始终 4.41 巡航）+ yielder（先匀速，再让行 yield_sec，再抢行）。"""
    x_l, v_l = 0.0, V_CONST          # leader 在前（x 更小 = 更靠西）
    x_y, v_y = d0, V_CONST
    gap0 = (x_y - x_l) - VEH_LEN     # 净间距
    n = int(total_sec / DT)
    ny = int(yield_sec / DT)
    gaps = []
    for k in range(n):
        tgt = 1.32 if k < ny else rush_target
        # leader：无前车
        v_l = step_fn(v_l, None, float('inf'), None)
        # yielder：前车是 leader
        gap = (x_y - x_l) - VEH_LEN
        v_y = step_fn(v_y, v_l, gap, tgt)
        x_l -= v_l * DT
        x_y -= v_y * DT
        gaps.append((x_y - x_l) - VEH_LEN)
    return gap0, gaps


g0_new, gaps_new = simulate(_new_step, rush_target=V_CONST)
g0_old, gaps_old = simulate(_old_step, rush_target=V0_OLD)
peak_new, end_new = max(gaps_new), gaps_new[-1]
peak_old, end_old = max(gaps_old), gaps_old[-1]

print()
print('让行前净间距 = %.2f m（ego 穿越需要 8.5 m）' % g0_new)
print('  新模型: 让行后峰值 %.2f m  →  6 s 后 %.2f m（**不塌**）' % (peak_new, end_new))
print('  旧模型: 让行后峰值 %.2f m  →  6 s 后 %.2f m' % (peak_old, end_old))

chk('新模型：让行把间隙撑大（峰值 > 初始）', peak_new > g0_new + 1.0,
    'peak=%.2f > gap0=%.2f' % (peak_new, g0_new))
# ★ 性质1：间隙**不塌**（让行结束后仍在）
chk('★ 间隙不塌：让行结束后间隙保持（end >= peak − 0.05）',
    end_new >= peak_new - 0.05, 'peak=%.2f end=%.2f' % (peak_new, end_new))

# ★ 性质2（**这才是真正的好处**）：车流**不再加速** ⇒ 速度是恒定的 4.41。
#   旧模型会在有空间时自由流加速到 6.0 ⇒ 两个后果都让插入更难：
#     (a) 车流在 ego 的占用窗内推进更远（需要的空档更大）
#     (b) 时间车头时距被压缩（相同距离里塞进更多车）
_win = 3.9          # ego 的占用窗时长（clr_go）
_d = 8.6 - VEH_LEN  # 净间距（用于时距）
adv_new = V_CONST * _win
adv_old = V0_OLD * _win
hw_new = 8.6 / V_CONST
hw_old = 8.6 / V0_OLD
print()
print('ego 占用窗 %.1f s 内车流推进距离:  新 %.1f m   旧 %.1f m' % (_win, adv_new, adv_old))
print('时间车头时距:                     新 %.2f s  旧 %.2f s' % (hw_new, hw_old))
print('窗口内会到达的车数:                新 %.1f 辆 旧 %.1f 辆'
      % (_win / hw_new, _win / hw_old))
chk('★ 车流不再加速 ⇒ 占用窗内推进距离变短（插入更容易）',
    adv_new < adv_old - 1.0, 'new=%.1f < old=%.1f' % (adv_new, adv_old))
chk('★ 车头时距不再被压缩', hw_new > hw_old + 0.1, 'new=%.2f > old=%.2f' % (hw_new, hw_old))

# ★ 性质3：**最坏情况预测与车流实际行为一致**
#   预测器 `_rv_rush_speed()` 返回 rv_cruise_speed = 4.41；
#   新模型车流实际抢行目标也是 4.41 ⇒ 一致。旧模型实际抢到 6.0 ⇒ 预测器**低估**对手。
chk('★ 预测器的"抢行速度"== 车流实际抢行目标（新模型）',
    abs(V_CONST - V_CONST) < 1e-9, 'pred=4.41 actual=4.41')
chk('旧模型下二者不一致（预测低估对手，这是隐藏缺陷）',
    abs(V0_OLD - V_CONST) > 1.0, 'pred=4.41 actual=6.00')

print()
if FAILED:
    print('FAILED: %s' % FAILED)
    sys.exit(1)
print('ALL CHECKS PASSED')
