#!/usr/bin/env python3
"""阶段 1：间隙前/后车识别与边界度量的单元测试（纯 stdlib + numpy，无需 CARLA）。"""
import math
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.scenario_snapshot import make_fixture
from Planning_library.gap_analysis import identify_gap_vehicles, compute_gap_metrics


class TestGapAnalysis(unittest.TestCase):

    def test_case1_rv_far_fv_passed(self):
        s = make_fixture(1)
        ids = identify_gap_vehicles(s)
        self.assertIsNotNone(ids["rv"])
        self.assertEqual(ids["rv"].x, 40.0)
        self.assertIsNotNone(ids["fv"])
        self.assertEqual(ids["fv"].x, 8.0)  # t_veh=0.2s < t_ego，ego 跟在它后面
        self.assertEqual(ids["n_vehicles"], 2)
        self.assertAlmostEqual(ids["t_veh_min"], 0.2)

    def test_case3_rv_nearest(self):
        s = make_fixture(3)
        ids = identify_gap_vehicles(s)
        self.assertIsNotNone(ids["rv"])
        self.assertEqual(ids["rv"].x, 11.0)  # 与自车同时到冲突点
        self.assertIsNotNone(ids["fv"])
        self.assertEqual(ids["fv"].x, 8.0)

    def test_lcttc_rv_increases_with_distance(self):
        m1 = compute_gap_metrics(make_fixture(1))  # rv 40m
        m3 = compute_gap_metrics(make_fixture(3))  # rv 9m
        self.assertGreater(m1["lcttc_rv"], m3["lcttc_rv"])

    def test_committed_fixture_still_counts(self):
        s = make_fixture(6)
        ids = identify_gap_vehicles(s)
        self.assertEqual(ids["n_vehicles"], 1)  # committed 由调用方处理，识别照常

    def test_metrics_return_all_keys(self):
        m = compute_gap_metrics(make_fixture(1))
        for k in ("lcttc_rv", "lcttc_fv", "thw_boundary_rv", "thw_boundary_fv", "d_ab_rv", "d_ab_fv"):
            self.assertIn(k, m)

    def test_danger_point_pair_detected(self):
        # ④ 危险点识别：端对端排列的两矩形，最近点对应落在相对端（同高、相距最短距离）。
        from Planning_library.boundary_safety import make_rect, closest_boundary_points
        ra = make_rect(0.0, 0.0, 0.0, 4.5, 2.0)   # x∈[-2.25,2.25]
        rb = make_rect(6.0, 0.0, 0.0, 4.5, 2.0)   # x∈[3.75,8.25]
        cp = closest_boundary_points(ra, rb)
        self.assertAlmostEqual(cp['d'], 1.5, places=3)       # 边界距离 6-4.5=1.5
        self.assertIsNotNone(cp['pa'])
        self.assertIsNotNone(cp['pb'])
        # 最近点在相对端：同一高度（y 相近）、水平相距 d
        self.assertAlmostEqual(abs(cp['pa'][0] - cp['pb'][0]), 1.5, places=3)
        self.assertAlmostEqual(abs(cp['pa'][1] - cp['pb'][1]), 0.0, places=3)

    def test_boundary_metrics_return_danger_points(self):
        # boundary_metrics 应额外返回危险点（最近点对）字段
        from Planning_library.boundary_safety import boundary_metrics
        m = boundary_metrics(0.0, 0.0, 0.0, 8.0,
                             10.0, 0.0, math.pi, 8.0, dt=0.1)
        self.assertIn('danger_pt_ego', m)
        self.assertIn('danger_pt_veh', m)
        self.assertIsNotNone(m['danger_pt_ego'])
        self.assertIsNotNone(m['danger_pt_veh'])


class TestFvRvSpatialGap(unittest.TestCase):
    """【论文式62 的 g_d】FV–RV 空间净间隙（米）。"""

    def test_from_fixture(self):
        from Planning_library.gap_analysis import fv_rv_spatial_gap
        s = make_fixture(1)
        ids = identify_gap_vehicles(s)
        g = fv_rv_spatial_gap(ids)
        # case1: rv.x=40, fv.x=8（RV 在东侧、FV 已接近冲突点）→ g_d = 40 − 8 − L
        L = 0.5 * (ids['rv'].length + ids['fv'].length)
        self.assertAlmostEqual(g, 40.0 - 8.0 - L, places=6)

    def test_negative_gap_reported(self):
        """重叠时返回负值——负间隙本身就是"不可插入"的真实信号。"""
        from Planning_library.gap_analysis import fv_rv_spatial_gap

        class V:
            def __init__(self, x, length=3.6):
                self.x, self.length = x, length
        g = fv_rv_spatial_gap({'rv': V(5.0), 'fv': V(3.0)})
        self.assertAlmostEqual(g, 5.0 - 3.0 - 3.6, places=6)
        self.assertLess(g, 0.0)

    def test_missing_side_returns_none(self):
        from Planning_library.gap_analysis import fv_rv_spatial_gap

        class V:
            def __init__(self, x, length=4.0):
                self.x, self.length = x, length
        self.assertIsNone(fv_rv_spatial_gap({'rv': V(10.0), 'fv': None}))
        self.assertIsNone(fv_rv_spatial_gap({'rv': None, 'fv': V(3.0)}))
        self.assertIsNone(fv_rv_spatial_gap({}))

    def test_gap_in_paper_reward_sweet_spot(self):
        """IDM 安全中心距（6 m/s 自由流：g0+vT+车长 = 8.6 m）对应的净间隙
        应落在论文式62 的 3.5~5.0 m 奖励区间内。"""
        from Planning_library.gap_analysis import fv_rv_spatial_gap
        from Planning_library.game_reward import gap_dist_reward

        class V:
            def __init__(self, x, length=3.6):
                self.x, self.length = x, length
        center = 2.0 + 6.0 * 0.5 + 3.6          # = 8.6 m
        g = fv_rv_spatial_gap({'rv': V(center), 'fv': V(0.0)})
        self.assertAlmostEqual(g, center - 3.6, places=6)   # = 5.0 m 净间隙
        self.assertGreaterEqual(g, 3.5)
        self.assertLessEqual(g, 5.0)
        self.assertGreater(gap_dist_reward(g), 20.0)        # 式62 给正奖励


if __name__ == "__main__":
    unittest.main()
