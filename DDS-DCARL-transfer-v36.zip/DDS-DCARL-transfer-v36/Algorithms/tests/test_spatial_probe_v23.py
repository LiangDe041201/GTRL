"""Spatial candidates keep CG history and own their prediction/execution path."""
import contextlib
import io
import unittest
from types import SimpleNamespace as S
import numpy as np
import test_trajectory_probe_v21 as fixtures
from Planning_library.road_corridor_v23 import RoadCorridor

try:
    from Planning_library.spatial_probe_v23 import SpatialProbeV23
except ImportError:
    SpatialProbeV23 = None


class SpatialProbeTests(unittest.TestCase):
    def fixture(self, mode='plus', lookup=None):
        self.assertIsNotNone(SpatialProbeV23, 'Spatial candidates are not wired to real MPC')
        f = fixtures.TrajectoryProbeTests().fixture('observe')
        corridor = RoadCorridor(lookup or (lambda x, y: (1, 0, -1)), [(1, 0, -1)])
        probe = SpatialProbeV23(mode, f[0].geometry, f[6][2:], corridor)
        return probe, f

    def request(self, p, f, selected=1):
        with contextlib.redirect_stdout(io.StringIO()):
            return p.propose(f[1], f[2], selected, f[4].last, f[5], False, (6., -138.))

    def test_spatial_candidate_changes_geometry_while_preserving_the_cg_speed_target(self):
        p, f = self.fixture()
        out = self.request(p, f)
        self.assertTrue(p.last['changed_request'], p.last['proposal_status'])
        self.assertEqual(out[1]['target'], f[2][1]['target'])
        self.assertGreater(np.max(out[1]['path'][:, 0])-6., .49)
        self.assertIs(out[0], f[2][0])
        self.assertTrue(p.last['request']['road_predictions_ok'])

    def test_observe_keeps_original_controls_and_does_not_mutate_base_path(self):
        p, f = self.fixture('observe')
        saved = f[2][1]['controller'].last_pathway.copy()
        out = self.request(p, f)
        self.assertIs(out[1], f[2][1])
        np.testing.assert_array_equal(f[2][1]['controller'].last_pathway, saved)

    def test_a_body_outside_public_road_is_not_given_control(self):
        p, f = self.fixture(lookup=lambda x, y: (1, 0, -1) if abs(x-6.) <= 1.1 else None)
        out = self.request(p, f)
        self.assertIs(out[1], f[2][1])
        self.assertFalse(p.last['changed_request'])
        self.assertEqual(p.last['proposal_status'], 'path_outside_corridor')

    def test_defer_retains_both_original_paths_so_common_clear_backup_cannot_mix_paths(self):
        p, f = self.fixture()
        out = self.request(p, f, selected=0)
        self.assertIs(out[0], f[2][0])
        self.assertIs(out[1], f[2][1])
        self.assertFalse(p.last['changed_request'])

    def test_final_guard_rejection_restores_the_original_solver_and_path_before_submission(self):
        p, f = self.fixture()
        out = self.request(p, f)
        original, changed = f[2][1]['controller'], out[1]['controller']
        current = p.activate(original, changed)
        result = p.review_execution(current, f[1].ego_vehicle, f[1].objects, f[5]['previous'],
            dict(action='brake', override=True, safe=True))
        self.assertIs(result['controller'], original)
        self.assertFalse(p.last['changed_request'])
        self.assertTrue(p.last['retracted'])
        self.assertEqual(p.last['request']['path_hash'], p.last['baseline_path_hash'])

    def test_actual_observed_body_is_checked_after_submission(self):
        p, f = self.fixture(lookup=lambda x, y: (1, 0, -1) if abs(x-6.) < 3. else None)
        self.request(p, f)
        p.pose_reader = lambda: S(location=S(x=100., y=0.), rotation=S(yaw=0.))
        try:
            p.feedback(1, 1, dict(action='mpc'),
                dict(control_submit_ok=1, a_cmd=0., delta_rad=0., actuator_speed_target=4.))
        except AttributeError:
            self.fail('Observed body geometry is not connected to the spatial feedback')
        self.assertFalse(p.last['feedback']['observed_body']['accepted'])
        self.assertIn('observed_pose', p.last['feedback'])
        self.assertEqual(p.last['feedback']['observed_pose'][:2], [100., 0.])


if __name__ == '__main__':
    unittest.main()
