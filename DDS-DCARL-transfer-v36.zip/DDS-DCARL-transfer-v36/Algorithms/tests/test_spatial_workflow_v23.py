"""Small geometric pilot keeps frozen identity and preserves failed evidence."""
import contextlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import test_trajectory_workflow_v21 as old_fixtures


class SpatialWorkflowTests(unittest.TestCase):
    def workflow(self):
        try:
            return importlib.import_module('Tools.run_spatial_validation_v23')
        except ImportError:
            self.fail('The spatial candidate remote protocol is missing')

    def boundary(self, cmd, failure=False, mismatch=False):
        helper = old_fixtures.TrajectoryWorkflowTests()
        output = Path(cmd[cmd.index('--output-root')+1])
        result = helper.run_fixture(output, cmd, failed=failure)
        for directory in output.glob('S*_seed*'):
            file = directory/'result.json'
            data = json.loads(file.read_text(encoding='utf8'))
            n = 2*int(cmd[cmd.index('--episodes')+1])
            data.update(spatial_probe_contract_ok=True,
                spatial_probe_counts=dict(rows=n, changed_requests=0, eligible_candidates=0),
                spatial_probe_statuses=dict(inactive=n))
            file.write_text(json.dumps(data), encoding='utf8')
        if mismatch and output.name == '00_smoke':
            file = output/'S0_observe_v23_seed60/interaction_ego.csv'
            import csv
            with file.open(newline='', encoding='utf8') as f:
                rows = list(csv.DictReader(f))
            rows[0]['ego_x'] = '99'
            with file.open('w', newline='', encoding='utf8') as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
        return result

    def test_default_plan_has_20_executions_and_a_center_geometry_control(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            stages = w.build_plan(output)
            self.assertEqual([s['episodes_total'] for s in stages], [4, 16])
            self.assertEqual(stages[1]['arms'], ['S0_observe_v23', 'S1_center_v23', 'S2_plus_v23', 'S3_minus_v23'])
            self.assertFalse(output.exists())

    def test_real_report_and_archive_are_written_without_claiming_learning_benefit(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            with patch.object(w.subprocess, 'run', side_effect=lambda cmd, **kw: self.boundary(cmd)), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertEqual(code, 0)
            report = json.loads((output/'SPATIAL_REPORT.json').read_text(encoding='utf8'))
            self.assertEqual(report['actual_episodes'], 20)
            self.assertFalse(report['learning_enabled'])
            self.assertFalse(report['benefit_established'])
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())

    def test_identity_failure_prevents_formal_stage_and_preserves_archive(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            with patch.object(w.subprocess, 'run', side_effect=lambda cmd, **kw: self.boundary(cmd, mismatch=True)), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertNotEqual(code, 0)
            self.assertFalse((output/'01_probe').exists())
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())


if __name__ == '__main__':
    unittest.main()
