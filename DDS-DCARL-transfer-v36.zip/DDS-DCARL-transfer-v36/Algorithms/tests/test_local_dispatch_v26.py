"""Exercise the actual CLI and driver corridor selection branch."""
import ast
import contextlib
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

from Tools.run_relay_validation import main
from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner


class LocalDispatchTests(unittest.TestCase):
    def test_cli_forwards_the_local_mode_and_keeps_the_same_game_and_learning(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            code=main(['--dry-run','--arms','T2_train_v24','--traffic-interaction','v17',
                       '--road-audit','local_v26'])
        self.assertEqual(code,0)
        c=json.loads(out.getvalue())['effective']
        self.assertEqual(c['DSH_ROAD_AUDIT'],'local_v26')
        self.assertEqual((c['DSH_COURNOT_MODE'],c['DSH_FORECAST_MODEL'],c['DSH_ROLLING_PHASE']),
                         ('matrix_v18','route_v18','train'))
        self.assertEqual((c['DSH_EFE'],c['DSH_BELIEF_MIN_EPISODES']),('0','10'))

    def test_driver_constructs_the_selected_corridor_before_the_rolling_owner(self):
        path=Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree=ast.parse(path.read_text(encoding='utf8'))
        block=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
                   and isinstance(n.test,ast.Name) and n.test.id=='_rolling_phase')
        for mode,expected in (('local_v26','local'),('carla_v25','legacy')):
            calls=[]
            def factory(name):
                def create(*a,**kw): calls.append(name); return S(metadata=dict(revision=name))
                return S(from_carla=create)
            stub=S(env=S(map=object(),ego_vehicle=S(get_location=lambda:S(z=0.))))
            def rolling(*args,**kw):
                self.assertEqual(calls,[expected]); return S(corridor=args[3])
            namespace=dict(self=stub,os=os,_rolling_phase='train',_prediction_geometry={'forecast_route':[[0.,0.],[1.,0.]]},
                _probe_controllers=[object()]*5,MODEL_DIR='unused',matrix_game=S(cruise=4.4),
                LocalRoadCorridorV26=factory('local'),RoadCorridorV24=factory('legacy'),RollingPlannerV24=rolling)
            namespace['select_rolling_planner']=lambda revision,mode: namespace[select_rolling_planner(revision,mode).__name__]
            with patch.dict(os.environ,dict(DSH_ROAD_AUDIT=mode,DSH_EFE='0')),patch.dict('sys.modules',
                    {'carla':S(Location=S,LaneType=S(Driving='Driving'))}):
                exec(compile(ast.Module(body=[block],type_ignores=[]),'<real corridor setup>','exec'),namespace)
            self.assertEqual(stub.trajectory_probe.corridor.metadata['revision'],expected)


if __name__=='__main__': unittest.main()
