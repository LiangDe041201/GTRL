#!/usr/bin/env python3
"""对手隐藏类型推断（论文式17 类型空间 + §IV-C 频率统计 + 式55 ambiguity）单元测试。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.type_inference import (
    uniform_prior, posterior_update, posterior_entropy, posterior_mean_theta,
    invert_theta_from_frequency, TypeInference, RV_THETA,
)

EGO = {'x': 6.0, 'y': -130.0, 'v': 5.0}
RV = {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0}


class TestPosteriorUpdate(unittest.TestCase):

    def test_prior_uniform(self):
        pr = uniform_prior()
        self.assertAlmostEqual(sum(pr.values()), 1.0)
        self.assertAlmostEqual(pr['normal'], 1.0 / 3.0)

    def test_yield_observation_shifts_to_conservative(self):
        # 观测到"让行" → 后验应偏向"保守(易让行)"类型
        prior = uniform_prior()
        # conservative(θ=0.2) 让行概率最高；aggressive(θ=0.8) 最低
        yp = {'aggressive': 0.2, 'normal': 0.5, 'conservative': 0.8}
        post = posterior_update(prior, yp, observed_yield=True)
        self.assertGreater(post['conservative'], post['aggressive'])
        self.assertAlmostEqual(sum(post.values()), 1.0)

    def test_rush_observation_shifts_to_aggressive(self):
        prior = uniform_prior()
        yp = {'aggressive': 0.2, 'normal': 0.5, 'conservative': 0.8}
        post = posterior_update(prior, yp, observed_yield=False)
        self.assertGreater(post['aggressive'], post['conservative'])

    def test_entropy_bounds(self):
        # 均匀先验 → 最大熵 log2(3)；退化到单一类型 → 熵 0
        self.assertAlmostEqual(posterior_entropy(uniform_prior()), 1.5849625, places=6)
        self.assertAlmostEqual(
            posterior_entropy({'aggressive': 1.0, 'normal': 0.0, 'conservative': 0.0}), 0.0)

    def test_mean_theta(self):
        post = {'aggressive': 0.0, 'normal': 0.0, 'conservative': 1.0}
        self.assertAlmostEqual(posterior_mean_theta(post), RV_THETA['conservative'])


class TestThetaInversion(unittest.TestCase):

    def test_invert_recovers_theta(self):
        # 取一个已知 θ 生成 p̂（选择**非限幅**态势，保证反解唯一），再反解应还原
        th_true = 0.7
        from Planning_library.rv_decision import rv_yield_probability
        # ttc=0.9 时 acc_need≈0 → eta≈0 → p=1.0−θ ∈ 内部，不被 clip
        p_hat = rv_yield_probability(EGO, RV, 6.0, 0.9, theta=th_true)
        self.assertTrue(0.1 < p_hat < 0.9, f"p_hat 应落在限幅区间内: {p_hat}")
        th, res = invert_theta_from_frequency(p_hat, EGO, RV, 6.0, 0.9)
        self.assertAlmostEqual(th, th_true, places=2)
        self.assertLess(res, 1e-3)


class TestTypeInferenceOnline(unittest.TestCase):

    def test_converges_toward_aggressive_when_always_rushing(self):
        ti = TypeInference()
        for _ in range(20):
            ti.observe(EGO, RV, 6.0, observed_yield=False, ttc_boundary=1.0)
        # 一直抢行 → θ 应偏向"激进"，且不确定性下降
        self.assertGreater(ti.theta(), RV_THETA['normal'])
        self.assertLess(ti.ambiguity(), posterior_entropy(uniform_prior()))

    def test_converges_toward_conservative_when_always_yielding(self):
        ti = TypeInference()
        for _ in range(20):
            ti.observe(EGO, RV, 6.0, observed_yield=True, ttc_boundary=1.0)
        self.assertLess(ti.theta(), RV_THETA['normal'])

    def test_frequency(self):
        ti = TypeInference()
        for i in range(10):
            ti.observe(EGO, RV, 6.0, observed_yield=(i < 3), ttc_boundary=1.0)
        self.assertAlmostEqual(ti.empirical_yield_frequency(), 0.3)


if __name__ == "__main__":
    unittest.main()
