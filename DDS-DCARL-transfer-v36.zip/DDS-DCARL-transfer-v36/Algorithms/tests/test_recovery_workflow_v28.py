"""A matched candidate-pool comparison, without another 200-episode training."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

try:
    from Tools.run_recovery_validation_v28 import build_plan,main
except ImportError:build_plan=main=None


class RecoveryWorkflowTests(unittest.TestCase):
    def test_default_plan_compares_cg_and_fixed_candidates_on_same_twenty_episodes(self):
        self.assertIsNotNone(build_plan,'No matched candidate-pool diagnostic workflow')
        stages=build_plan(Path('output'))
        self.assertEqual(sum(s['episodes_total'] for s in stages),20)
        self.assertEqual(stages[0]['arms'],['M6_matrix_v18','T1_fixed_v24'])
        self.assertEqual(stages[0]['seeds'],[104,105])
        args=stages[0]['arguments']
        self.assertEqual(args[args.index('--road-audit')+1],'local_v26')
        self.assertNotIn('--rolling-checkpoint',args)

    def test_dry_run_creates_no_result_and_forwards_explicit_counts(self):
        self.assertIsNotNone(main,'No runnable v28 workflow')
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)/'no_output';capture=io.StringIO()
            with contextlib.redirect_stdout(capture):
                self.assertEqual(main(['--dry-run','--episodes','3','--seeds','104','--output-root',str(output)]),0)
            self.assertEqual(json.loads(capture.getvalue())['episodes_total'],6)
            self.assertFalse(output.exists())

    def test_failed_child_retains_partial_evidence_in_one_archive(self):
        self.assertIsNotNone(main,'No failure-preserving v28 workflow')
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)/'partial'
            with patch('Tools.run_recovery_validation_v28.subprocess.run',return_value=S(returncode=3)):
                with contextlib.redirect_stdout(io.StringIO()):
                    status=main(['--episodes','1','--seeds','104','--output-root',str(output)])
            self.assertEqual(status,3)
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())
            workflow=json.loads((output/'WORKFLOW.json').read_text(encoding='utf8'))
            self.assertFalse(workflow['overall_success'])


if __name__=='__main__':unittest.main()
