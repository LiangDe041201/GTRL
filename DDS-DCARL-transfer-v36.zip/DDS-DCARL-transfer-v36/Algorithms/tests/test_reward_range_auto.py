#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【修复 D1】式44 的 (R_max − R_min) 解析逻辑回归测试（纯逻辑，不建 R-tree）。

背景（HANDOFF_2026-10-10.md §14）
------------------------------------------------------------------
论文式44：δ = (R_max − R_min)·√(ln(1/Pf)/(2n))。
原实现把 (R_max − R_min) **硬编码为 80**，而实测回报 G（n=42645）：

    min/max = −37012 / +822   ⇒ 全极差  37834
    p5 / p95 = −1366 / +403   ⇒ 稳健极差  1769
    p1 / p99                  ⇒ 稳健极差 ~3300

n=12967 时 δ 仅 0.86，而逐动作 G 标准差是 300~2600 ⇒ **WCV/BCV 失去统计保守性**。
离线复算：range=80 ⇒ 95.6% 状态"可接管"；range=3300 ⇒ 2.7%；range=37834 ⇒ 0.0%。
⇒ 机制在噪声上接管，是全开(57%)低于纯规则(76%)的重要原因之一。

修复：`DSH_REWARD_RANGE='auto'`（新默认）从已存回报的经验分位数自适应估计；
`=80` 可**完整复现修复前行为**（消融）。

⚠️ 本文件只验证解析/缓存/回退逻辑，不断言"分位数截断是合法 Hoeffding 界"
   —— 那是一个**有意的实用折中**，已在源码注释中显式声明。
"""
import math
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.trustset_dds import Trustset

_ENV_KEYS = ('DSH_REWARD_RANGE', 'DSH_REWARD_RANGE_FALLBACK', 'DSH_REWARD_RANGE_Q_LO',
             'DSH_REWARD_RANGE_Q_HI', 'DSH_REWARD_RANGE_MIN_N')


class _FakeTree:
    """最小的 Rtree_env 替身：只需要 `locations`（元素含第 4 位 = 回报 G）。"""

    def __init__(self, returns=()):
        self.locations = [(np.zeros(5), np.zeros(8), 0, float(r)) for r in returns]


def _mk(returns=(), env_range='auto', q_lo='0.01', q_hi='0.99', min_n='200',
        fallback='3300'):
    """构造一个**不触碰文件系统**的 Trustset 实例（只设解析逻辑需要的属性）。"""
    for k in _ENV_KEYS:
        os.environ.pop(k, None)
    os.environ['DSH_REWARD_RANGE'] = env_range
    os.environ['DSH_REWARD_RANGE_Q_LO'] = q_lo
    os.environ['DSH_REWARD_RANGE_Q_HI'] = q_hi
    os.environ['DSH_REWARD_RANGE_MIN_N'] = min_n
    os.environ['DSH_REWARD_RANGE_FALLBACK'] = fallback
    ts = Trustset.__new__(Trustset)          # 不调用 __init__ ⇒ 不建 R-tree
    ts.reward_range_env = env_range
    ts.reward_range_fallback = float(fallback)
    ts.reward_range_q_lo = float(q_lo)
    ts.reward_range_q_hi = float(q_hi)
    ts.reward_range_min_n = int(min_n)
    ts._rr_cache = None
    ts._rr_cache_next_n = 0
    ts._rr_last_source = 'init'
    ts.Rtree_env = _FakeTree(returns)
    return ts


class TestRewardRangeFix(unittest.TestCase):

    def tearDown(self):
        for k in _ENV_KEYS:
            os.environ.pop(k, None)

    # ---------- 显式值：消融可复现性（最重要） ----------
    def test_explicit_80_reproduces_old_behaviour(self):
        """`DSH_REWARD_RANGE=80` 必须**精确**返回 80 ⇒ 修复前行为可完整复现（消融）。"""
        ts = _mk([1.0, 2.0, 3.0], env_range='80')
        self.assertEqual(ts.effective_reward_range(), 80.0)
        self.assertEqual(ts.reward_range, 80.0)          # property 路径同样生效
        self.assertIn('explicit', ts._rr_last_source)

    def test_explicit_arbitrary_value(self):
        ts = _mk([1.0], env_range='1769.5')
        self.assertAlmostEqual(ts.effective_reward_range(), 1769.5, places=6)

    def test_explicit_beats_data(self):
        """显式值必须**优先于**数据估计（否则消融实验无法固定参数）。"""
        ts = _mk(list(range(500)), env_range='80')
        self.assertEqual(ts.effective_reward_range(), 80.0)

    # ---------- auto：分位数估计 ----------
    def test_auto_percentile_exact(self):
        """auto 必须等于 (p_hi − p_lo) 的解析值。

        取 g = linspace(−1000, 1000, 1001)：p1 ⇒ −980、p99 ⇒ +980 ⇒ 极差 1960。
        """
        ts = _mk(np.linspace(-1000.0, 1000.0, 1001), env_range='auto')
        self.assertAlmostEqual(ts.effective_reward_range(), 1960.0, places=6)
        self.assertIn('auto', ts._rr_last_source)

    def test_auto_matches_numpy(self):
        """与 numpy 分位数公式一致（防止参数被悄悄改动）。"""
        g = np.array([-37.0, -5.0, 0.0, 3.0, 9.0] * 100, dtype=float)
        ts = _mk(g, env_range='auto')
        expect = float(np.percentile(g, 99) - np.percentile(g, 1))
        self.assertAlmostEqual(ts.effective_reward_range(), expect, places=6)

    def test_full_range_via_quantiles(self):
        """`Q_LO=0 Q_HI=1` ⇒ 全极差（对照用）。"""
        g = np.linspace(-1000.0, 1000.0, 1001)
        ts = _mk(g, env_range='auto', q_lo='0', q_hi='1')
        self.assertAlmostEqual(ts.effective_reward_range(), 2000.0, places=6)

    # ---------- 回退路径 ----------
    def test_fallback_when_too_few_samples(self):
        """样本不足 ⇒ 回退默认值，且来源可诊断。"""
        ts = _mk([1.0, 2.0, 3.0], env_range='auto', min_n='200')
        self.assertAlmostEqual(ts.effective_reward_range(), 3300.0, places=6)
        self.assertIn('fallback', ts._rr_last_source)
        self.assertIn('样本不足', ts._rr_last_source)

    def test_fallback_on_empty_tree(self):
        ts = _mk([], env_range='auto', fallback='1234')
        self.assertAlmostEqual(ts.effective_reward_range(), 1234.0, places=6)

    def test_fallback_on_degenerate_returns(self):
        """所有回报相同 ⇒ 极差为 0 ⇒ 必须回退（8δ=0 会让界失去意义）。"""
        ts = _mk([5.0] * 300, env_range='auto', fallback='777')
        self.assertAlmostEqual(ts.effective_reward_range(), 777.0, places=6)
        self.assertIn('fallback', ts._rr_last_source)

    def test_nonfinite_returns_filtered(self):
        """NaN/Inf 必须被过滤，不能污染分位数。"""
        g = [float('nan')] * 100 + [float('inf')] * 100 + list(range(400))
        ts = _mk(g, env_range='auto')
        v = ts.effective_reward_range()
        self.assertTrue(math.isfinite(v), f'结果应为有限值，实际 {v}')
        self.assertGreater(v, 0.0)

    def test_bad_env_values_fall_back_to_auto(self):
        """非法/非正/空字符串 ⇒ 不能抛异常，应退化到 auto。"""
        for bad in ('', 'abc', '0', '-5', 'nan', 'inf'):
            ts = _mk(np.linspace(0.0, 100.0, 300), env_range=bad)
            v = ts.effective_reward_range()
            self.assertTrue(math.isfinite(v) and v > 0.0,
                            f'env={bad!r} 时结果应有限且为正，实际 {v}')

    def test_no_exception_on_broken_tree(self):
        """Rtree 异常不得冒泡（本方法在每帧热路径上）。"""
        ts = _mk([], env_range='auto', fallback='99')

        class _Boom:
            @property
            def locations(self):
                raise RuntimeError('boom')

        ts.Rtree_env = _Boom()
        self.assertAlmostEqual(ts.effective_reward_range(), 99.0, places=6)
        self.assertIn('异常', ts._rr_last_source)

    # ---------- 缓存 ----------
    def test_cache_reused_when_data_unchanged(self):
        ts = _mk(np.linspace(0.0, 1000.0, 500), env_range='auto')
        v1 = ts.effective_reward_range()
        n_calls_before = ts._rr_cache_next_n
        v2 = ts.effective_reward_range()
        self.assertEqual(v1, v2)
        self.assertEqual(ts._rr_cache_next_n, n_calls_before)

    def test_cache_refreshes_when_data_grows(self):
        """样本量增长 ≥20% ⇒ 必须重算（否则永远停在旧范围）。"""
        ts = _mk(np.linspace(0.0, 100.0, 300), env_range='auto')
        v1 = ts.effective_reward_range()
        # 追加大量**更宽**的回报 ⇒ 范围应变大
        ts.Rtree_env.locations += [(np.zeros(5), np.zeros(8), 0, r)
                                   for r in np.linspace(-5000.0, 5000.0, 300)]
        v2 = ts.effective_reward_range()
        self.assertGreater(v2, v1, '数据增长后范围应被重新估计')

    def test_min_n_boundary(self):
        """样本数恰为 min_n 时应走 auto（不被回退）；少 1 个则回退。"""
        ts = _mk(np.linspace(0.0, 1000.0, 200), env_range='auto', min_n='200')
        ts.effective_reward_range()
        self.assertIn('auto', ts._rr_last_source)
        ts2 = _mk(np.linspace(0.0, 1000.0, 199), env_range='auto', min_n='200')
        ts2.effective_reward_range()
        self.assertIn('fallback', ts2._rr_last_source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
