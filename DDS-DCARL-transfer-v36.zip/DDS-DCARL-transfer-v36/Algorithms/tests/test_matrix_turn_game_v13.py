"""Counterfactual payoffs, real MPC candidates, authority and merge regressions."""
import ast
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

import numpy as np

from Planning_library.cournot_game import expected_payoff_response, cournot_decision
from Planning_library.cournot_mpc import game_configuration
from Planning_library.matrix_turn_game import (
    MatrixTurnGame, MergePhase, rv_action_track, observable_tracks, score_candidates,
    solve_candidates, rectangle_gaps)
from Planning_library.paper_turn_control import rectangle_gap
from Planning_library.scenario_snapshot import VehicleState
from Tools.validate_matrix_game import validate_matrix_game
from Tools.run_relay_validation import main as relay_main


GEOMETRY = dict(wheelbase=2.86, max_steer=.6, execution_horizon=6.,
                brake_response_jerk=.5, low_speed_brake_taper=.5)
PATH = np.array([[0., y] for y in np.linspace(8., -20., 281)])


def vehicle(identity=1, x=0., y=6., yaw=-math.pi/2, speed=2., acceleration=None):
    return VehicleState(veh_id=identity, x=x, y=y, yaw=yaw, v=speed,
        vx=speed*math.cos(yaw), vy=speed*math.sin(yaw), length=4., width=1.8,
        acc=acceleration, acc_source='unavailable' if acceleration is None else 'velocity_difference')


def candidate(target, acceleration):
    return dict(target=target, a=acceleration, delta=0., solve_ok=True, plan=None, times=None, prediction=None)


class TestResponseAndGeometry(unittest.TestCase):
    def test_batch_clearance_matches_public_scalar_test_for_rotated_rectangles(self):
        rng=np.random.RandomState(13)
        states=np.zeros((7,101)); states[0:2]=rng.normal(size=(2,101))*10.
        states[6]=rng.uniform(-math.pi,math.pi,101)
        track=np.column_stack((rng.normal(size=(101,2))*10.,rng.uniform(-math.pi,math.pi,101)))
        ego,other=vehicle(),vehicle(2)
        expected=[rectangle_gap(states[0,k],states[1,k],states[6,k],4.,1.8,
            x,y,yaw,4.,1.8) for k,(x,y,yaw) in enumerate(track)]
        np.testing.assert_allclose(rectangle_gaps(states,ego,other,track),expected,rtol=1e-12,atol=1e-12)

    def test_both_wait_cells_and_zero_sum_are_used(self):
        matrix = [[-1., -3.], [-8., 2.]]
        low, high = [expected_payoff_response(matrix, p) for p in (.1, .9)]
        self.assertEqual((low['ego_action'], high['ego_action']), (0, 1))
        self.assertAlmostEqual(high['u_wait'], -2.8)
        self.assertIsNone(high['pure_nash'])
        self.assertEqual(high['rv_payoff_matrix'], [[1., 3.], [8., -2.]])
        for bad in (math.nan, -.1, 1.1):
            with self.assertRaises(ValueError):
                expected_payoff_response(matrix, bad)

    def test_merge_finishes_in_target_lane_without_crossing_its_far_edge(self):
        phase = MergePhase()
        ego = vehicle(y=-134.)
        self.assertEqual(phase.update(ego, 1., (4., -138.), (-21., -138.51, math.pi)), 'approach')
        ego.x, ego.y, ego.yaw = -2., -138.51, math.pi
        for _ in range(5):
            result = phase.update(ego, -2., (4., -138.), (-21., -138.51, math.pi))
        self.assertEqual(result, 'merged')
        phase.reset()
        ego.yaw = -math.pi/2
        for _ in range(8):
            result = phase.update(ego, -2., (4., -138.), (-21., -138.51, math.pi))
        self.assertEqual(result, 'merging')

    def test_rv_columns_are_bounded_motion_not_thw_bonus_or_teleport(self):
        rv = vehicle(2, 15., 0., math.pi, 4.)
        times = np.arange(0., 3.01, .05)
        rush = rv_action_track(rv, [rv], times, 4.4, False)
        yielding = rv_action_track(rv, [rv], times, 4.4, True)
        self.assertLess(rush[-1, 0], yielding[-1, 0])
        speeds = -np.diff(yielding[:, 0])/.05
        self.assertLessEqual(max(abs(np.diff(speeds)/.05)), 2.501)
        # A stopped leader very close cannot be resolved by teleporting RV to rest.
        front = vehicle(3, 10.8, 0., math.pi, 0.)
        blocked = rv_action_track(rv, [rv, front], times, 4.4, False)
        first_speed = -(blocked[1, 0]-blocked[0, 0])/.05
        self.assertGreater(first_speed, 3.8)

    def test_missing_acceleration_is_not_a_measured_zero_or_certain_yield(self):
        game = MatrixTurnGame(GEOMETRY)
        rv = vehicle(2, 12., 0., math.pi, 4.)
        self.assertEqual(len(observable_tracks(rv, [0., .5, 1.])), 1)
        self.assertEqual(game.yield_probability(rv, [rv])[0], .5)
        rv.acc, rv.acc_source = -1., 'velocity_difference'
        self.assertGreater(game.yield_probability(rv, [rv])[0], .5)
        front = vehicle(3, 5., 0., math.pi, 3.)
        rv.x = 12.
        probability, source = game.yield_probability(rv, [rv, front])
        self.assertEqual(probability, .5)
        self.assertIn('following', source)


class TestPayoffAndAuthority(unittest.TestCase):
    def test_rolling_defer_and_legacy_stop_have_declared_distinct_targets(self):
        ego, rv = vehicle(), vehicle(2, 12., 0., math.pi, 4.)
        conf = dict(rv_veh=rv, conflict_x=0., conflict_y=0., arc_to_cross=6.)
        new = MatrixTurnGame(GEOMETRY)
        _, targets = new.prepare(ego, [rv], conf, 4., 4., (-20., 0., math.pi))
        self.assertTrue(new.last['active'])
        self.assertGreater(targets[0], 0.)
        self.assertLess(targets[0], targets[1])
        old = MatrixTurnGame(GEOMETRY, legacy=True)
        self.assertEqual(old.prepare(ego, [rv], conf, 4., 4., (-20., 0., math.pi))[1], [0., 4.])

    def test_both_rows_use_both_rv_tracks_and_physical_risk(self):
        ego, rv = vehicle(y=5.), vehicle(2, 10., 0., math.pi, 4.)
        plans = [candidate(0., -.1), candidate(4., .1)]
        matrix, terms = score_candidates(ego, [rv], rv, plans, GEOMETRY, PATH,
                                        dict(a=0., df=0.), 4.4)
        self.assertEqual(np.shape(matrix), (2, 2))
        self.assertTrue(np.isfinite(matrix).all())
        self.assertGreater(terms[1][0]['progress'], terms[0][0]['progress'])
        self.assertNotEqual(matrix[1][0], matrix[1][1])
        self.assertEqual(terms[1][0]['progress'], terms[1][1]['progress'])

    def test_risk_free_progress_does_not_get_punished_for_large_clearance(self):
        ego = vehicle()
        plans = [candidate(0., -.1), candidate(4., .1)]
        utilities = []
        for y in (40., 60.):
            other = vehicle(2, 10., y, math.pi, 4.)
            matrix, _ = score_candidates(ego, [other], None, plans, GEOMETRY, PATH,
                                          dict(a=0., df=0.), 4.4)
            utilities.append(matrix[1][0])
        self.assertAlmostEqual(*utilities)

    def test_choice_and_actual_control_coverage_are_checked_and_tampering_fails(self):
        ego, rv = vehicle(), vehicle(2, 12., 0., math.pi, 4.)
        conf = dict(rv_veh=rv, conflict_x=0., conflict_y=0., arc_to_cross=6.)
        plans = [candidate(1., -.1), candidate(4., .1)]
        with tempfile.TemporaryDirectory() as folder:
            game = MatrixTurnGame(GEOMETRY, directory=folder)
            game.prepare(ego, [rv], conf, 4., 4., (-20., 0., math.pi))
            with patch('Planning_library.matrix_turn_game.score_candidates',
                       return_value=([[-1., -1.], [1., 1.]], [[{}, {}], [{}, {}]])):
                self.assertEqual(game.choose(ego, [rv], rv, conf, plans, PATH, dict(a=0., df=0.)), 1)
            applied = dict(a_cmd=.1, delta_rad=0., actuator_speed_target=4., control_submit_ok=1)
            game.record(1, 1, .1, 0., 4., dict(action='mpc', override=False, safe=True), applied)
            row = dict(episode='1', frame='1', a_mpc='.1', delta_mpc_rad='0', a_cmd='.1',
                steer='0', physical_max_steer='.6', v_ref='4', guard_action='mpc',
                actuator_speed_target='4',
                mpc_audit_override='0', mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10', ego_v='2')
            result = validate_matrix_game(folder, [row], 'matrix_v13')
            self.assertTrue(result['matrix_contract_ok'], result)
            row['a_mpc'] = '-.1'
            self.assertFalse(validate_matrix_game(folder, [row], 'matrix_v13')['matrix_contract_ok'])

    def test_failed_candidate_cannot_be_reported_as_valid_best_response(self):
        ego, rv = vehicle(), vehicle(2, 12., 0., math.pi, 4.)
        conf = dict(rv_veh=rv, conflict_x=0., conflict_y=0., arc_to_cross=6.)
        game = MatrixTurnGame(GEOMETRY)
        game.prepare(ego, [rv], conf, 4., 4., (-20., 0., math.pi))
        plans = [candidate(1., -.1), candidate(4., .1)]
        plans[1]['solve_ok'] = False
        with patch('Planning_library.matrix_turn_game.score_candidates',
                   return_value=([[-1., -1.], [1., 1.]], [[{}, {}], [{}, {}]])):
            selected = game.choose(ego, [rv], rv, conf, plans, PATH, dict(a=0., df=0.))
        self.assertEqual(selected, 0)
        self.assertEqual(game.last['decision_mode'], 'optimizer_failure_override')

    def test_configuration_and_production_branch_keep_one_game_owner(self):
        for mode in ('matrix', 'matrix_legacy'):
            config = game_configuration('CG', mode=mode)
            self.assertTrue(config['matrix'])
            self.assertFalse(config['mpc'])
            self.assertFalse(config['learning'])
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(relay_main(['--dry-run','--method','CG',
                '--arms','B0_rule,M0_legacy_matrix,M1_matrix,C1_cg']), 0)
        configs = [json.loads(s)['effective'] for s in stream.getvalue().splitlines()]
        self.assertTrue(all(c['DSH_CONTROL_PROFILE']=='paper_v11' and c['DSH_EFE']=='0' for c in configs))
        source=(Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf-8-sig')
        tree=ast.parse(source)
        branches=[n for n in ast.walk(tree) if isinstance(n, ast.If)
                  and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name)
                  and n.test.left.id == 'matrix_game']
        self.assertTrue(any(any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name)
                               and c.func.id == 'solve_candidates' for c in ast.walk(n)) for n in branches))

    def test_production_candidate_dispatch_executes_selected_solver_and_entry_authority(self):
        source=(Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf-8-sig')
        tree=ast.parse(source)
        block=next(n for n in ast.walk(tree) if isinstance(n, ast.If)
            and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name)
            and n.test.left.id == 'matrix_game' and any(isinstance(c, ast.Call)
            and isinstance(c.func, ast.Name) and c.func.id=='solve_candidates' for c in ast.walk(n)))
        ego, rv = vehicle(), vehicle(2,12.,0.,math.pi,4.)
        game=MatrixTurnGame(GEOMETRY)
        primary=S(last_u=dict(a=.1,df=0.), last_pathway=PATH, last_solve_ms=1.)
        peer=S(last_u=dict(a=.1,df=0.), last_pathway=PATH, last_solve_ms=2.)
        self_stub=S(dynamic_map=S(ego_vehicle=ego, objects=[rv]),
                    env=S(goal_pose=(-20.,0.,math.pi)), turn_feasibility=S(last={}))
        candidates=[dict(candidate(1.,-.1),controller=peer),dict(candidate(4.,.1),controller=primary)]
        ns=dict(self=self_stub,matrix_game=game,matrix_peer=peer,mpc_controller=primary,
            _conf=dict(rv_veh=rv,conflict_x=0.,conflict_y=0.,arc_to_cross=6.),_sd=4.,v_ref=4.,
            road_right=False,_previous_control=dict(a=.1,df=0.),solve_candidates=lambda *a:candidates)
        with patch('Planning_library.matrix_turn_game.score_candidates',
                   return_value=([[1.,1.],[-1.,-1.]],[[{},{}],[{},{}]])):
            # ast.Module without type_ignores remains valid on the CARLA Python 3.7 host.
            module=ast.Module(body=[block])
            if hasattr(module,'type_ignores') or 'type_ignores' in getattr(ast.Module,'_fields',()):
                module.type_ignores=[]
            exec(compile(module,'<production matrix authority>','exec'),ns)
        self.assertIs(ns['mpc_controller'],peer)
        self.assertIs(ns['matrix_peer'],primary)
        self.assertEqual(ns['v_ref'],1.)
        self.assertFalse(self_stub._last_entry_granted)
        self.assertEqual(self_stub._last_cournot_gate_reason,'matrix_waiting')


class TestActualMPCPair(unittest.TestCase):
    def test_actual_solvers_share_applied_control_and_have_no_continuous_game(self):
        from Agent.game_theory.MPC import MPCController
        ego = vehicle(x=0., y=6., yaw=-math.pi/2, speed=2.)
        lane = S(front_vehicles=[], rear_vehicles=[])
        dynamic = S(ego_vehicle=ego, objects=[], lanes=[lane])
        with contextlib.redirect_stdout(io.StringIO()):
            controllers=[MPCController(N=16, dt=.05, d_safe=2.7, thw_min=.5,
                enable_lead_follow_cost=False, enable_boundary_thw=False,
                enable_cournot_cost=False, cost_profile='paper_v11', step_dts=[.05]*6+[.2]*10,
                vehicle_geometry=dict(l_f=1.43, l_r=1.43, max_steer=.6)) for _ in range(2)]
            controllers[0].reset_global_path(PATH, dynamic)
            controllers[0].geometry_source='road_recovery'
            controllers[0].geometry_force_stop=True
            controls=solve_candidates(controllers[0],controllers[1],dynamic,4.,1.,False,(0.,0.),True)
        self.assertEqual([c['target'] for c in controls], [1.,4.])
        self.assertTrue(all(c['solve_ok'] for c in controls))
        self.assertTrue(all(c['prediction'].shape == (7,17) for c in controls))
        self.assertFalse(any(c['controller'].enable_cournot_cost for c in controls))
        self.assertTrue(all(c['controller'].geometry_source=='road_recovery' for c in controls))
        self.assertTrue(all(c['controller'].geometry_force_stop for c in controls))
        self.assertLess(controls[0]['a'], controls[1]['a'])
        for controller in controllers:
            controller.acknowledge_applied_control(-.2,.01)
        self.assertEqual(controllers[0].last_u,controllers[1].last_u)


if __name__ == '__main__':
    unittest.main()
