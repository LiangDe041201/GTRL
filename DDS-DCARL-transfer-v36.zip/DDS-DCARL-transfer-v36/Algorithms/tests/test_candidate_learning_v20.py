"""Regularized authority and physical candidate eligibility regressions."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

try:
    from Planning_library.candidate_learning_v20 import CandidateLearnerV20 as Learner
    from Planning_library.matrix_turn_game_v20 import MatrixTurnGameV20 as Game
except ImportError:
    # Exercise the old behavior during the red phase instead of failing imports.
    from Planning_library.candidate_learning_v19 import CandidateLearner as Learner
    from Planning_library.matrix_turn_game_v19 import MatrixTurnGameV19 as Game


class RegularizedAuthorityTests(unittest.TestCase):
    def trained(self, gain, **kwargs):
        learner=Learner(alpha=.1, **kwargs)
        context=np.zeros(len(learner.CONTEXT_WIDTHS))
        for episode in range(40):
            learner.begin(context,np.ones(6)/6.,0,[0,1],episode)
            action=episode%2
            learner.select(explore_action=action);learner.start_action(action)
            learner.record_reward(gain*action);learner.finish()
        learner.begin(context,np.ones(6)/6.,0,[0,1],41)
        return learner

    def test_raw_advantage_smaller_than_current_information_cost_cannot_take_over(self):
        learner=self.trained(.1)
        action,_=learner.select()
        self.assertEqual(action,0, 'Raw WCV passes but deterministic net value is worse')
        self.assertEqual(learner.last['selection_rule'],'regularized_wcv')
        self.assertGreater(learner.last['bounds'][1]['wcv'],learner.last['bounds'][0]['bcv'])
        self.assertLess(learner.last['regularized_bounds'][1]['wcv'],
                        learner.last['regularized_bounds'][0]['bcv'])

    def test_sufficient_repeated_net_gain_still_has_real_authority(self):
        learner=self.trained(2.)
        self.assertEqual(learner.select()[0],1)
        self.assertEqual(learner.last['source'],'takeover')
        self.assertEqual(learner.last['behavior_policy'],[0.,1.])

    def test_current_cost_is_not_subtracted_again_from_bellman_reward(self):
        learner=self.trained(2.)
        learner.select()
        np.testing.assert_allclose(learner.q[learner.current],[0.,2.])
        self.assertEqual(learner.records[1]['reward'],2.)
        self.assertAlmostEqual(learner.last['information_cost'],-.1*np.log(.025))

    def test_unknown_frozen_state_is_reported_on_every_visit(self):
        with tempfile.TemporaryDirectory() as d:
            Learner(out_dir=d).save()
            frozen=Learner(phase='eval',checkpoint=Path(d)/'belief_soft_model.json')
            for episode in (1,2):
                frozen.begin(np.zeros(len(frozen.CONTEXT_WIDTHS)),np.ones(6)/6.,0,[0,1],episode)
                self.assertEqual(frozen.select()[0],0)
                self.assertTrue(frozen.last['unseen_state'])
                frozen.finish()

    def test_old_checkpoint_cannot_be_used_with_new_action_and_value_semantics(self):
        from Planning_library.candidate_learning_v19 import CandidateLearner
        with tempfile.TemporaryDirectory() as d:
            CandidateLearner(out_dir=d).save()
            with self.assertRaises(ValueError):
                Learner(phase='eval',checkpoint=Path(d)/'belief_soft_model.json')


class ExecutableCandidateTests(unittest.TestCase):
    def test_a_guard_rejected_alternative_is_masked_but_cg_default_is_preserved(self):
        from test_candidate_learning_v19 import MatrixIntegrationTests
        from test_forecast_v18 import vehicle
        ego,path,g,u,rv,cs,conf=MatrixIntegrationTests().fixture()
        rv=vehicle(357,5.,-138.,np.pi,3.);conf['rv_veh']=rv
        game=Game(g,epsilon=1.)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        selected=game.choose(ego,[rv],rv,conf,cs,path,u)
        row=game.last['learning']
        self.assertTrue(row['active'])
        self.assertTrue(all(not c['accepted'] for c in row['candidate_execution']))
        self.assertEqual(row['allowed'],[row['cg']])
        self.assertEqual(selected,row['cg'])

    def test_candidate_rejection_ends_an_option_without_waiting_for_its_period(self):
        from test_candidate_learning_v19 import MatrixIntegrationTests
        from test_forecast_v18 import vehicle
        ego,path,g,u,rv,cs,conf=MatrixIntegrationTests().fixture()
        game=Game(g,epsilon=1.,decision_period=.5)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        selected=game.choose(ego,[rv],rv,conf,cs,path,u)
        self.assertEqual(game.last['learning']['allowed'],[0,1])
        game.feedback(1,1,dict(override=False,unavoidable=False,action='mpc'),
            dict(a_cmd=cs[selected]['a'],delta_rad=cs[selected]['delta'],
                 actuator_speed_target=cs[selected]['target'],ego_v_after=ego.v,control_submit_ok=1))
        rv=vehicle(357,5.,-138.,np.pi,3.);conf['rv_veh']=rv
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        selected=game.choose(ego,[rv],rv,conf,cs,path,u)
        self.assertTrue(game.last['learning']['decision'])
        self.assertEqual(game.last['learning']['allowed'],[selected])
        self.assertEqual(len(game.learner.records),1)
        self.assertEqual(game.learner.records[0]['steps'],1)

    def test_learning_off_keeps_the_frozen_cg_choice_and_payoffs(self):
        from test_candidate_learning_v19 import MatrixIntegrationTests
        from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
        ego,path,g,u,rv,cs,conf=MatrixIntegrationTests().fixture()
        games=[MatrixTurnGameV18(g),Game(g,learning_phase='off')]
        for game in games:
            game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        choices=[game.choose(ego,[rv],rv,conf,cs,path,u) for game in games]
        self.assertEqual(choices[0],choices[1])
        self.assertEqual(games[0].last['payoff_matrix'],games[1].last['payoff_matrix'])

    def test_only_alternatives_accepted_by_common_guard_are_offered_to_learning(self):
        from test_candidate_learning_v19 import MatrixIntegrationTests
        from Planning_library.execution_guard import select_execution
        from Planning_library.trajectory_guard import execution_acceleration
        ego,path,g,u,rv,cs,conf=MatrixIntegrationTests().fixture()
        game=Game(g,epsilon=1.)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        original=copy.deepcopy(cs)
        selected=game.choose(ego,[rv],rv,conf,cs,path,u)
        row=game.last['learning']
        self.assertIn('candidate_execution',row)
        self.assertIn(row['cg'],row['allowed'])
        for i,c in enumerate(cs):
            _,audit=select_execution(ego,[rv],path,c['target'],
                execution_acceleration(c['a'],ego.v,c['target']),c['delta'],u,g,
                prediction=c['prediction'],prediction_times=c['times'],plan=c['plan'],
                solve_ok=c['solve_ok'],allow_clear=False)
            expected=audit['action']=='mpc' and audit['safe'] and not audit['override']
            self.assertEqual(row['candidate_execution'][i]['accepted'],expected)
            if i!=row['cg'] and i in row['allowed']:self.assertTrue(expected)
        self.assertIn(selected,row['allowed'])
        self.assertEqual(cs[0]['target'],original[0]['target'])
        np.testing.assert_array_equal(cs[1]['plan'],original[1]['plan'])


if __name__=='__main__':unittest.main()
