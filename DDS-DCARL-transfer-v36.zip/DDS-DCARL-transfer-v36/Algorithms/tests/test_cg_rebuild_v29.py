"""Migration reuses actual transitions, not old values or invented episodes."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from Planning_library.rolling_learning_v24 import RollingLearner
from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29

try:
    from Tools.rebuild_cg_learning_v29 import rebuild
except ImportError:
    rebuild=None


def fixture():
    old=RollingLearner()
    context=[0.]*16;beta=dict(alpha=1.,beta=1.)
    # Identical physical/belief bins but different observed geometry strata.
    first=old.begin(context,beta,1,[0,1],[1.,0.,9.,9.,9.,9.],1)
    second=old.begin(context,beta,0,[0,1],[0.,1.,9.,9.,9.,9.],1)
    records=[]
    for ep in range(1,11):
        records.extend([
            dict(state=first,action=0,episode=ep,context=context,beta=beta,
                 reward=.01,discount=old.gamma**10,steps=10,interventions=0,next=second,
                 original_extra={'owner':'actual_carla_action','ids':[ep,0]}),
            dict(state=second,action=1,episode=ep,context=context,beta=beta,
                 reward=5.,discount=old.gamma,steps=1,interventions=0,next=None)])
    return dict(signature=old.signature(),nodes=old.nodes,records=records,
                q={k:[999.]*6 for k in old.nodes}),first,second


class CGRebuildTests(unittest.TestCase):
    def call(self,*args,**kwargs):
        self.assertIsNotNone(rebuild,'No audited real-experience rebuild for CG baseline learning')
        return rebuild(*args,**kwargs)

    def paths(self,tmp,data):
        root=Path(tmp);source=root/'old.json';output=root/'new.json';audit=root/'audit.json'
        source.write_text(json.dumps(data),encoding='utf8')
        return source,output,audit

    def test_new_signature_uniform_reference_and_fitted_values_preserve_actual_records(self):
        data,first,second=fixture()
        with tempfile.TemporaryDirectory() as tmp:
            source,out,audit=self.paths(tmp,data);before=source.read_bytes()
            report=self.call(source,out,audit,max_sweeps=200)
            saved=json.loads(out.read_text(encoding='utf8'))
            self.assertEqual(saved['signature']['schema'],'cg_trajectory_learning_v29')
            self.assertEqual(saved['records'],data['records'])
            self.assertEqual(set(saved['nodes']),{first,second})
            self.assertEqual(saved['nodes'][first]['proposal_geometry_stratum'],1)
            self.assertEqual(saved['nodes'][second]['proposal_geometry_stratum'],0)
            for node in saved['nodes'].values():
                self.assertEqual(node['default'],0)
                self.assertEqual(node['prior'],[.5,.5,0.,0.,0.,0.])
            self.assertAlmostEqual(saved['q'][second][1],5.)
            self.assertEqual(saved['q'][first][1],0.)  # Never executed here.
            self.assertGreater(saved['q'][first][0],0.)
            loaded=CGTrajectoryLearnerV29(phase='eval',checkpoint=out)
            self.assertEqual(loaded.records,data['records'])
            self.assertEqual(source.read_bytes(),before)
            self.assertTrue(report['source_unchanged'])
            self.assertEqual(report['source_sha256'],hashlib.sha256(before).hexdigest())
            self.assertEqual(report['real_transition_records'],20)
            self.assertEqual(report['real_episode_count'],10)
            self.assertEqual(report['synthetic_transition_records'],0)
            self.assertEqual(report['new_CARLA_episodes'],0)
            self.assertTrue(report['bellman_converged'])
            self.assertEqual(json.loads(audit.read_text(encoding='utf8')),report)

    def test_old_signature_and_geometry_key_mismatch_are_rejected_before_writing(self):
        for change in ('signature','stratum','missing_cg'):
            data,first,second=fixture()
            if change=='signature':data['signature']['reward']='some_other_reward'
            elif change=='stratum':data['nodes'][first]['default']=0
            else:data['nodes'][first]['allowed']=[1]
            with tempfile.TemporaryDirectory() as tmp:
                source,out,audit=self.paths(tmp,data)
                with self.assertRaises(ValueError):self.call(source,out,audit)
                self.assertFalse(out.exists());self.assertFalse(audit.exists())

    def test_repeated_records_do_not_manufacture_independent_episode_coverage(self):
        data,first,second=fixture()
        for record in data['records']:record['episode']=1
        with tempfile.TemporaryDirectory() as tmp:
            source,out,audit=self.paths(tmp,data)
            report=self.call(source,out,audit,max_sweeps=200)
            self.assertEqual(report['real_episode_count'],1)
            self.assertEqual(report['max_state_action_episode_coverage'],1)
            self.assertEqual(report['cg_comparisons_meeting_coverage'],0)

    def test_existing_output_or_audit_cannot_be_overwritten(self):
        data,first,second=fixture()
        for name in ('output','audit'):
            with tempfile.TemporaryDirectory() as tmp:
                source,out,audit=self.paths(tmp,data);target=out if name=='output' else audit
                target.write_text('keep this evidence',encoding='utf8')
                with self.assertRaises(FileExistsError):self.call(source,out,audit)
                self.assertEqual(target.read_text(encoding='utf8'),'keep this evidence')

    def test_invalid_transition_discount_is_not_reinterpreted_as_new_experience(self):
        data,first,second=fixture();data['records'][0]['discount']=.1
        with tempfile.TemporaryDirectory() as tmp:
            source,out,audit=self.paths(tmp,data)
            with self.assertRaises(ValueError):self.call(source,out,audit)
            self.assertFalse(out.exists())

    def test_sweep_budget_reports_nonconvergence_without_creating_evidence(self):
        data,first,second=fixture()
        # One synchronous backup cannot yet pass the terminal value backward.
        with tempfile.TemporaryDirectory() as tmp:
            source,out,audit=self.paths(tmp,data)
            report=self.call(source,out,audit,max_sweeps=1)
            self.assertFalse(report['bellman_converged'])
            self.assertGreater(report['bellman_residual'],1.e-7)
            self.assertEqual(report['bellman_sweeps'],1)
            self.assertEqual(report['real_episode_count'],10)
            self.assertEqual(report['new_CARLA_episodes'],0)


if __name__=='__main__':unittest.main()
