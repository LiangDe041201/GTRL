"""Only the external CARLA subprocess boundary is replaced in these checks."""
import contextlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

from Tools import run_learning_validation_v19 as workflow


class LearningWorkflowTests(unittest.TestCase):
    def run_case(self,failure=None,corrupt=False):
        directory=tempfile.TemporaryDirectory();self.addCleanup(directory.cleanup)
        output=Path(directory.name)/'output with spaces'
        calls=[]
        def external_carla_process(command,**kwargs):
            tool=Path(command[2]).name
            calls.append(tool)
            if tool=='summarize_matrix_comparison.py':return S(returncode=0)
            p=Path(command[command.index('--output-root')+1]);p.mkdir()
            manifest=dict(overall_success=p.name!=failure,runs=[])
            (p/'manifest.json').write_text('{' if corrupt else json.dumps(manifest),encoding='utf8')
            (p/'run.log').write_text('external CARLA boundary fixture',encoding='utf8')
            return S(returncode=17 if p.name==failure else 0)
        with patch.object(workflow.subprocess,'run',side_effect=external_carla_process):
            with contextlib.redirect_stdout(io.StringIO()):
                try:code=workflow.main(['--output-root',str(output),'--train-episodes','1','--eval-episodes','1'])
                except ValueError:code='unhandled_json_error'
        return output,code,calls

    def test_success_has_three_stages_and_exactly_one_archive(self):
        output,code,calls=self.run_case()
        self.assertEqual(code,0)
        self.assertEqual(len(calls),4)
        self.assertEqual(len(list(output.parent.glob('*.tar.gz'))),1)
        with tarfile.open(str(output)+'.tar.gz') as stream:
            self.assertTrue(any(n.endswith('02_eval/run.log') for n in stream.getnames()))

    def test_each_failed_stage_stops_later_simulation_and_preserves_exit_status(self):
        for stage,count in [('00_smoke',1),('01_train',2),('02_eval',3)]:
            output,code,calls=self.run_case(stage)
            self.assertEqual(code,17)
            self.assertEqual(len(calls),count)
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())

    def test_partial_manifest_is_archived_instead_of_losing_the_failed_run(self):
        output,code,calls=self.run_case('00_smoke',corrupt=True)
        self.assertEqual(code,17)
        self.assertTrue(Path(str(output)+'.tar.gz').is_file())
        with tarfile.open(str(output)+'.tar.gz') as stream:
            self.assertTrue(any(n.endswith('00_smoke/manifest.json') for n in stream.getnames()))


if __name__=='__main__':unittest.main()
