"""Selection-first execution keeps exact solve and experience ownership aligned."""
import unittest
from types import SimpleNamespace as S
from unittest.mock import patch

from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
from Planning_library.joint_planner_v32 import ACTION_PAIRS, JointPlannerV32
from Planning_library.rolling_planner_v24 import RollingPlannerV24
from Tools.run_dense_validation_v30 import build_plan
from Tools.validate_rolling_v24 import _validate_learner


class SelectFirstTests(unittest.TestCase):
    def test_default_skips_solve_and_alternative_solves_only_once(self):
        cls = select_rolling_planner('select_first_v33')
        self.assertEqual(cls.EXTRA_CONTROLLERS, 1)
        candidate = dict(target=3., path='candidate_path')
        base = dict(target=0., path='cg_path')
        for request, eligible in ((0, False), (1, True), (1, False)):
            with self.subTest(request=request, eligible=eligible):
                planner = object.__new__(cls)
                planner.profiles = {}
                planner._timing = {}
                planner._base = base

                def select(*args):
                    planner.action = request
                    planner.last = dict(actual_action=request, requested_action=request, candidates=[{'id':'cg'}],
                                        request={'id':'screened'}, decision_ms=0.)
                    return [candidate if request else base, {}]

                proof = dict(id='exact', eligible=eligible)
                with patch.object(JointPlannerV32, 'propose', side_effect=select), patch.object(
                        RollingPlannerV24, '_solve', return_value=(candidate,proof,3.)) as mpc:
                    result=planner.propose(None,[base,{'target':4.,'controller':S(last_pathway=[])}],0,{},None,False,None)
                self.assertEqual(mpc.call_count, int(bool(request)))
                self.assertEqual(planner.last['extra_solve_count'], int(bool(request)))
                self.assertIs(result[0],candidate if request and eligible else base)
                self.assertEqual(planner.last['actual_action'],request if eligible else 0)
                if request and not eligible:
                    self.assertTrue(planner.last['retracted'])
                    self.assertEqual(planner.last['requested_action'],1)

    def test_checkpoint_signature_and_runner_separate_the_new_decision_rule(self):
        cls=select_rolling_planner('select_first_v33')
        self.assertEqual(cls.LEARNER_CLASS.ACTION_PAIRS,ACTION_PAIRS)
        self.assertNotEqual(cls.LEARNER_CLASS().signature(),JointPlannerV32.LEARNER_CLASS().signature())
        train,evaluate=build_plan('unused',4,2,[511,512],learner='select_first_v33')
        self.assertEqual(train['arms'],['U7_select_train_v33'])
        self.assertEqual(evaluate['arms'],['M6_matrix_v18','U8_select_eval_v33'])

    def test_held_cg_requires_a_matching_preceding_audit_rejection(self):
        cls=select_rolling_planner('select_first_v33')
        learner=cls.LEARNER_CLASS()
        count=len(ACTION_PAIRS)
        learner.begin([0.]*16,{'alpha':1.,'beta':1.},0,[0,1],[0.]*count,1)
        self.assertEqual(learner.choose(1.,S(random_sample=lambda:0.,choice=lambda options:1)),1)
        history=(7,dict(learner.last))
        held=dict(cls.LEARNER_METADATA,learning=dict(learner.last),generation_id=7,decision=False,
                  requested_action=0,actual_action=0,allowed=[0],exact_audit_rejected=False,retracted=False)
        _validate_learner(held,'train','select_first_v33',count,previous_audit_hold=history)
        for invalid in (None,(8,history[1]),(7,dict(history[1],requested=2))):
            with self.assertRaises(ValueError):
                _validate_learner(held,'train','select_first_v33',count,previous_audit_hold=invalid)


if __name__=='__main__':
    unittest.main()
