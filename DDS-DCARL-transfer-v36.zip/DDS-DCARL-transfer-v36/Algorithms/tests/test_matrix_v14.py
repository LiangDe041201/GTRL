"""Observable-memory, counterfactual motion, authority and snapshot regressions."""
import ast
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

import numpy as np

from Planning_library.cournot_game import expected_payoff_response
from Planning_library.cournot_mpc import game_configuration
from Planning_library.execution_guard import select_execution
from Planning_library.matrix_motion_v14 import MotionHistory, rv_action_track
from Planning_library.matrix_turn_game import (
    MatrixTurnGame, score_candidates as old_score, solve_candidates)
from Planning_library.matrix_turn_game_v14 import MatrixTurnGameV14, score_candidates
from Tools.run_relay_validation import main as relay_main
from Tools.validate_matrix_game import validate_matrix_game
from tests.test_matrix_turn_game_v13 import vehicle,candidate,GEOMETRY,PATH


class TestObservableMotion(unittest.TestCase):
    def test_steady_slow_history_survives_zero_acceleration_and_ignores_private_labels(self):
        history=MotionHistory(4.4);rv=vehicle(2,12.,0.,math.pi,.375,0.)
        for frame in range(1,31):
            rv.x-=.375*.05;history.observe([rv],frame)
            p,source,evidence=history.estimate(rv,[rv])
        self.assertGreater(p,.75);self.assertLessEqual(p,.8)
        self.assertEqual(source,'sustained_low_speed_unblocked')
        self.assertGreaterEqual(evidence['span_s'],.5)
        rv.behavior='rush';rv.reason='zoneA';rv.target_speed=99.
        self.assertEqual(history.estimate(rv,[rv])[0],p)
        rv.acc=1.5;rv.v+=.075;rv.vx=-rv.v
        history.observe([rv],31)
        p,source,_=history.estimate(rv,[rv])
        self.assertLess(p,.5);self.assertEqual(source,'observed_recovery')

    def test_following_slowdown_is_not_treated_as_independent_yield_evidence(self):
        history=MotionHistory(4.4)
        rv,front=vehicle(2,12.,0.,math.pi,.375,0.),vehicle(3,7.,0.,math.pi,.2,0.)
        for frame in range(1,31):
            history.observe([rv,front],frame);p,source,_=history.estimate(rv,[rv,front])
        self.assertEqual(p,.5);self.assertIn('leader',source)

    def test_actor_histories_do_not_mix_and_disappearance_resets_evidence(self):
        history=MotionHistory(4.4)
        slow,fast=vehicle(2,12.,0.,math.pi,.375,0.),vehicle(3,30.,0.,math.pi,4.4,0.)
        for frame in range(1,31):
            history.observe([slow,fast],frame)
            slow_p=history.estimate(slow,[slow])[0];fast_p=history.estimate(fast,[fast])[0]
        self.assertGreater(slow_p,.7);self.assertLess(fast_p,.3)
        history.observe([],35)
        self.assertEqual(history.estimate(slow,[])[0],.5)
        history.observe([slow],36)
        self.assertEqual(history.estimate(slow,[slow])[0],.5)

    def test_missing_acceleration_starts_neutral_then_uses_actual_speed_differences(self):
        history=MotionHistory(4.4);rv=vehicle(2,12.,0.,math.pi,2.)
        history.observe([rv],1)
        self.assertEqual(history.estimate(rv,[rv])[0],.5)
        self.assertIsNone(history.estimate(rv,[rv])[2]['acceleration'])
        rv.v=1.95;rv.vx=-1.95;history.observe([rv],2)
        self.assertAlmostEqual(history.estimate(rv,[rv])[2]['acceleration'],-1.)

    def test_continue_column_does_not_invent_recovery_for_a_steady_slow_rv(self):
        rv=vehicle(2,12.,0.,math.pi,.375,0.)
        times=np.linspace(0.,6.,61)
        continuing=rv_action_track(rv,[rv],times,4.4,False)
        yielding=rv_action_track(rv,[rv],times,4.4,True)
        np.testing.assert_allclose(continuing[:,0],12.-.375*times,atol=1e-12)
        np.testing.assert_allclose(continuing,yielding,atol=1e-12)

    def test_observed_recovery_is_forecast_for_one_second_and_yield_does_not_accelerate(self):
        rv=vehicle(2,12.,0.,math.pi,.375,1.5)
        times=np.linspace(0.,2.,41)
        continuing=rv_action_track(rv,[rv],times,4.4,False)
        yielding=rv_action_track(rv,[rv],times,4.4,True)
        self.assertAlmostEqual(continuing[-1,0],9.,places=9)
        self.assertAlmostEqual(yielding[-1,0],12.-.375*2.,places=9)

    def test_late_leader_does_not_teleport_the_rv_to_a_safe_stop(self):
        rv,front=vehicle(2,12.,0.,math.pi,4.,0.),vehicle(3,7.8,0.,math.pi,0.,0.)
        track=rv_action_track(rv,[rv,front],np.array([0.,.05,.1]),4.4,False)
        self.assertLess(track[-1,0],11.7)
        self.assertGreater(track[-1,0],11.5)


class TestV14Decision(unittest.TestCase):
    def test_observed_slow_motion_removes_a_synthetic_wait_trap_without_reweighting(self):
        ego=vehicle(speed=0.);rv=vehicle(2,7.6,0.,math.pi,.375,0.)
        candidates=[candidate(0.,-.3),candidate(4.,.1)]
        old,_=old_score(ego,[rv],rv,candidates,GEOMETRY,PATH,dict(a=0.,df=0.),4.4)
        new,_=score_candidates(ego,[rv],rv,candidates,GEOMETRY,PATH,dict(a=0.,df=0.),4.4)
        self.assertEqual(expected_payoff_response(old,.5)['ego_action'],0)
        self.assertEqual(expected_payoff_response(new,.5)['ego_action'],1)
        self.assertGreater(new[1][0],new[0][0])

    def test_observed_fast_conflict_still_penalizes_going(self):
        ego=vehicle(speed=0.);rv=vehicle(2,12.,0.,math.pi,4.4,0.)
        candidates=[candidate(0.,-.3),candidate(4.,.1)]
        matrix,parts=score_candidates(ego,[rv],rv,candidates,GEOMETRY,PATH,dict(a=0.,df=0.),4.4)
        self.assertGreater(parts[1][0]['risk'],parts[0][0]['risk'])
        self.assertLess(matrix[1][0],matrix[0][0])

    def test_near_zero_defer_targets_become_stop_with_release_hysteresis(self):
        game=MatrixTurnGameV14(GEOMETRY);ego=vehicle();rv=vehicle(2,12.,0.,math.pi,1.32,0.)
        conf=dict(rv_veh=rv,conflict_x=0.,conflict_y=0.)
        self.assertEqual(game.prepare(ego,[rv],conf,4.,2.06,(-20.,0.,math.pi))[1][0],0.)
        self.assertEqual(game.prepare(ego,[rv],conf,4.,5.,(-20.,0.,math.pi))[1][0],0.)
        self.assertGreaterEqual(game.prepare(ego,[rv],conf,4.,12.,(-20.,0.,math.pi))[1][0],.5)

    def test_equivalent_targets_are_not_a_fake_wait_game(self):
        game=MatrixTurnGameV14(GEOMETRY);ego=vehicle();rv=vehicle(2,5.,0.,math.pi,4.4,0.)
        _,targets=game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,18.,(-20.,0.,math.pi))
        self.assertEqual(targets,[4.,4.]);self.assertFalse(game.last['active'])
        with patch('Planning_library.matrix_turn_game_v14.score_candidates',side_effect=AssertionError('duplicate solve')):
            self.assertEqual(game.choose(ego,[rv],rv,{},[candidate(4.,.1)]*2,PATH,dict(a=0.,df=0.)),1)

    def test_v14_geometry_matches_public_steering_cap_and_reset_clears_memory(self):
        game=MatrixTurnGameV14(dict(GEOMETRY,max_steer=1.22))
        self.assertEqual(game.geometry['max_steer'],1.)
        game.history.observe([vehicle(2)],1);game.last_action=0;game._defer_stopped=True
        game.reset();self.assertFalse(game.history.actors);self.assertIsNone(game.last_action)
        self.assertFalse(game._defer_stopped)

    def test_switch_cost_applies_only_to_risk_free_alternatives(self):
        ego,rv=vehicle(),vehicle(2,12.,0.,math.pi,4.,0.)
        game=MatrixTurnGameV14(GEOMETRY)
        game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,4.,(-20.,0.,math.pi))
        game.last_action,game.last_rv=0,2
        def terms(values,risks):
            return [[dict(progress=values[i][j]+4.*risks[i][j],stopped_fraction=0.,comfort=0.,
                          risk=risks[i][j],utility=values[i][j],switch_cost=0.,actors=[])
                     for j in range(2)] for i in range(2)]
        values=[[.3,.3],[.31,.31]]
        with patch('Planning_library.matrix_turn_game_v14.score_candidates',
                   return_value=(values,terms(values,[[0.,0.],[0.,0.]]))):
            self.assertEqual(game.choose(ego,[rv],rv,{},[candidate(1.,0.),candidate(4.,.1)],PATH,dict(a=0.,df=0.)),0)
        self.assertEqual(game.last['switch_penalty'],.03)
        game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,4.,(-20.,0.,math.pi))
        values=[[-4.,-4.],[.3,.3]]
        with patch('Planning_library.matrix_turn_game_v14.score_candidates',
                   return_value=(values,terms(values,[[1.,1.],[0.,0.]]))):
            self.assertEqual(game.choose(ego,[rv],rv,{},[candidate(1.,0.),candidate(4.,.1)],PATH,dict(a=0.,df=0.)),1)
        self.assertEqual(game.last['switch_penalty'],0.)

    def test_v14_record_checks_components_and_writes_replayable_observations_only(self):
        ego,rv=vehicle(speed=0.),vehicle(2,7.6,0.,math.pi,.375,0.)
        with tempfile.TemporaryDirectory() as folder:
            game=MatrixTurnGameV14(GEOMETRY,directory=folder)
            game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,4.,(-20.,0.,math.pi))
            candidates=[candidate(0.,-.3),candidate(4.,.1)]
            self.assertEqual(game.choose(ego,[rv],rv,{},candidates,PATH,dict(a=0.,df=0.)),1)
            rv.behavior='unobservable_secret'
            game.record(1,1,.1,0.,4.,dict(action='mpc',override=False,safe=True),
                dict(a_cmd=.1,delta_rad=0.,actuator_speed_target=4.,control_submit_ok=1))
            row=dict(episode='1',frame='1',a_mpc='.1',delta_mpc_rad='0',a_cmd='.1',delta_rad='0',
                v_ref='4',actuator_speed_target='4',guard_action='mpc',mpc_audit_override='0',
                mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10',ego_v='0')
            result=validate_matrix_game(folder,[row],'matrix_v14')
            self.assertTrue(result['matrix_contract_ok'],result)
            text=(Path(folder)/'matrix_snapshots.jsonl').read_text(encoding='utf8')
            snapshot=json.loads(text);self.assertNotIn('unobservable_secret',text)
            self.assertEqual(snapshot['rv_id'],2);self.assertEqual(snapshot['path'],PATH.tolist())
            record_path=Path(folder)/'matrix_decisions.jsonl';record=json.loads(record_path.read_text())
            record['components'][1][0]['risk']+=1.;record_path.write_text(json.dumps(record)+'\n')
            self.assertFalse(validate_matrix_game(folder,[row],'matrix_v14')['matrix_contract_ok'])

    def test_new_mode_is_isolated_and_production_constructor_keeps_v13_comparison(self):
        config=game_configuration('CG',mode='matrix_v14')
        self.assertTrue(config['matrix']);self.assertFalse(config['mpc']);self.assertFalse(config['learning'])
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(relay_main(['--dry-run','--arms','M1_matrix,M2_matrix_v14']),0)
        plans=[json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertEqual({k for k in plans[0] if plans[0][k]!=plans[1][k]},{'DSH_COURNOT_MODE'})
        source=Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree=ast.parse(source.read_text(encoding='utf-8-sig'))
        node=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and
                  any(isinstance(t,ast.Name) and t.id=='matrix_class' for t in n.targets))
        expression=compile(ast.Expression(body=node.value),'<production version dispatch>','eval')
        for mode,expected in (('matrix',MatrixTurnGame),('matrix_v14',MatrixTurnGameV14)):
            self.assertIs(eval(expression,dict(self=S(cournot_mode=mode),MatrixTurnGame=MatrixTurnGame,
                                               MatrixTurnGameV14=MatrixTurnGameV14)),expected)


class TestActualV14MPC(unittest.TestCase):
    def test_actual_selected_candidate_passes_the_unchanged_public_execution_guard(self):
        from Agent.game_theory.MPC import MPCController
        ego,rv=vehicle(speed=0.),vehicle(2,7.6,0.,math.pi,.375,0.)
        dynamic=S(ego_vehicle=ego,objects=[rv],lanes=[S(front_vehicles=[],rear_vehicles=[])])
        game=MatrixTurnGameV14(GEOMETRY)
        _,targets=game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=0.,conflict_y=0.),4.,4.,(-20.,0.,math.pi))
        with contextlib.redirect_stdout(io.StringIO()):
            controllers=[MPCController(N=16,dt=.05,d_safe=2.7,thw_min=.5,
                enable_lead_follow_cost=False,enable_boundary_thw=False,enable_cournot_cost=False,
                cost_profile='paper_v11',step_dts=[.05]*6+[.2]*10,
                vehicle_geometry=dict(l_f=1.43,l_r=1.43,max_steer=.6)) for _ in range(2)]
            controllers[0].reset_global_path(PATH,dynamic)
            previous=dict(controllers[0].last_u)
            candidates=solve_candidates(*controllers,dynamic,targets[1],targets[0],False,(0.,0.),True)
        self.assertTrue(all(c['solve_ok'] for c in candidates))
        selected=game.choose(ego,[rv],rv,{},candidates,PATH,previous)
        self.assertEqual(selected,1)
        chosen=candidates[selected]
        actual,audit=select_execution(ego,[rv],PATH,chosen['target'],chosen['a'],chosen['delta'],
            previous,GEOMETRY,prediction=chosen['prediction'],prediction_times=chosen['times'],
            plan=chosen['plan'],solve_ok=chosen['solve_ok'])
        self.assertTrue(audit['safe']);self.assertFalse(audit['override'])
        self.assertEqual(actual['target'],4.)


if __name__=='__main__':
    unittest.main()
