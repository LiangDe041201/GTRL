#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【修复 D3'】① Cournot 授权口径的回归测试（纯函数，无 CARLA）。

背景
------------------------------------------------------------------
修复前：`_risk_gate_ok = (not risk_only_gate) or bool(_gap_ok)` 位于
`if _gap_ok:` 的 **else 分支内** ⇒ `_gap_ok` 恒为 False ⇒ 默认配置下
`_risk_gate_ok` **恒 False** ⇒ 唯一能授权①的分支**不可达**
⇒ ①"零和 Cournot 博弈"对决策影响为 **0**
（实证：`DSH_TAKE_COURNOT=0/1` 的 `action` 列 5651/5651 帧完全相同）。

关键洞察：`_gap_ok = (risk ≤ risk_max) and (streak ≥ stable_n)`
⇒ 它为 False 有**两种成因**：
  (a) `risk > risk_max`                 ⇒ **真危险，任何口径都不得放行**
  (b) `risk ≤ risk_max` 但稳定帧数未满足 ⇒ 风险可接受，仅"稳定性"未达
修复前把两者混为一谈（恒 False）⇒ ① 永久无权力。

修复：显式三态（`DSH_COURNOT_AUTHORITY`）
  'gate'（默认）: 风险门唯一授权，①仅咨询  ← = 修复**前**的实际行为（但现在是显式的）
  'risk'（推荐）: ①可在 `commit_risk ≤ cournot_risk_max` 时授权
                  ⇒ **替代稳定性要求，但不越过风险值上限**（安全）
  'game'        : ①判走即授权（论文字面；会越过风险值上限，风险最高，仅供消融）

本文件重点验证**安全性质**：'risk' 口径**永远不得**在风险值超限或数据陈旧时放行。
"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.cournot_game import resolve_cournot_gate, COURNOT_AUTHORITY_MODES


class TestCournotGate(unittest.TestCase):

    # ---------- 默认口径：与修复前实际行为一致 ----------
    def test_default_gate_reproduces_old_behaviour(self):
        """'gate' 口径必须**恒不放行** ⇒ 完整复现修复前的实际行为（消融基线）。"""
        for risk in (0.0, 0.1, 0.30, 0.9):
            for fresh in (True, False):
                ok, reason, _ = resolve_cournot_gate(True, 'gate', risk, fresh, 0.30)
                self.assertFalse(ok, f'gate 口径不应放行 (risk={risk}, fresh={fresh})')
                self.assertEqual(reason, 'gate_only')

    def test_default_authority_is_gate(self):
        """默认口径必须是 'gate'（不改变既有行为）。"""
        self.assertIn('gate', COURNOT_AUTHORITY_MODES)

    def test_unknown_authority_falls_back_to_gate(self):
        """未识别的口径值必须退化为最安全的 'gate'（不得意外放行）。"""
        for bad in ('', None, 'GATE ', 'typo', 'risk2'):
            if bad == 'GATE ':
                continue                     # 大小写/空格应被规范化 ⇒ 见下一个用例
            ok, reason, _ = resolve_cournot_gate(True, bad, 0.1, True, 0.30)
            self.assertFalse(ok, f'未知口径 {bad!r} 不应放行')

    def test_authority_is_case_insensitive(self):
        ok, reason, _ = resolve_cournot_gate(True, ' GATE ', 0.1, True, 0.30)
        self.assertFalse(ok)
        ok2, reason2, _ = resolve_cournot_gate(True, 'RISK', 0.1, True, 0.30)
        self.assertTrue(ok2)

    # ---------- 风险门关闭（消融） ----------
    def test_risk_gate_off_always_grants(self):
        ok, reason, _ = resolve_cournot_gate(False, 'gate', 0.99, False, 0.30)
        self.assertTrue(ok, '关闭风险门后应无条件放行（消融口径）')
        self.assertEqual(reason, 'risk_gate_off')

    # ---------- 'risk'：推荐的启用方式 ----------
    def test_risk_mode_grants_when_risk_value_ok(self):
        """成因 (b)：风险值合格、仅稳定性未满足 ⇒ ①**可以**授权。"""
        ok, reason, rvok = resolve_cournot_gate(True, 'risk', 0.10, True, 0.30)
        self.assertTrue(ok)
        self.assertEqual(reason, 'authority_risk_ok')
        self.assertTrue(rvok)

    def test_risk_mode_boundary_is_inclusive(self):
        """`commit_risk == cournot_risk_max` 必须放行（判据是 ≤）。"""
        ok, _, _ = resolve_cournot_gate(True, 'risk', 0.30, True, 0.30)
        self.assertTrue(ok)

    # ---------- 🔴 安全关键：绝不放行的两种情形 ----------
    def test_risk_mode_never_grants_when_risk_exceeds_max(self):
        """成因 (a)：**风险值超限 ⇒ 任何口径都不得放行**（安全关键）。

        这正是"①替代稳定性要求但不越过风险值上限"的核心保证。
        """
        for risk in (0.3001, 0.31, 0.5, 0.99, 1.0):
            ok, reason, rvok = resolve_cournot_gate(True, 'risk', risk, True, 0.30)
            self.assertFalse(ok, f'risk={risk} 超限却放行了！')
            self.assertEqual(reason, 'authority_risk_blocked')
            self.assertFalse(rvok)

    def test_risk_mode_never_grants_on_stale_risk(self):
        """🔴 **陈旧风险值绝不能用于授权**。

        `_last_commit_risk` 修复前不逐帧重置 ⇒ 进入区外会保留旧值。
        若用它授权，等于用"某历史帧的低风险"批准当前进入 —— 危险。
        """
        for risk in (0.0, 0.05, 0.1, 0.29):
            ok, reason, rvok = resolve_cournot_gate(True, 'risk', risk, False, 0.30)
            self.assertFalse(ok, f'陈旧 risk={risk} 却被用于授权！')
            self.assertFalse(rvok)

    def test_risk_mode_never_grants_without_risk_value(self):
        ok, reason, rvok = resolve_cournot_gate(True, 'risk', None, True, 0.30)
        self.assertFalse(ok)
        self.assertFalse(rvok)

    def test_risk_mode_threshold_is_configurable(self):
        """放宽阈值（`DSH_COURNOT_RISK_MAX`）后，原本被挡的 risk 应可放行。"""
        self.assertFalse(resolve_cournot_gate(True, 'risk', 0.45, True, 0.30)[0])
        self.assertTrue(resolve_cournot_gate(True, 'risk', 0.45, True, 0.50)[0])

    # ---------- 'game'：论文字面（消融用） ----------
    def test_game_mode_always_grants(self):
        for risk in (0.0, 0.5, 1.0):
            ok, reason, _ = resolve_cournot_gate(True, 'game', risk, False, 0.30)
            self.assertTrue(ok, 'game 口径=论文字面，①判走即授权')
            self.assertEqual(reason, 'authority_game')

    # ---------- 健壮性 ----------
    def test_bad_risk_values_do_not_raise(self):
        for bad in ('x', None, float('nan'), float('inf')):
            try:
                ok, reason, rvok = resolve_cournot_gate(True, 'risk', bad, True, 0.30)
            except (TypeError, ValueError):
                self.fail(f'risk={bad!r} 不应抛异常')
            if bad in (float('inf'), float('nan')):
                self.assertFalse(ok, f'risk={bad!r} 不应被当作"合格"')

    def test_bad_threshold_does_not_raise(self):
        for bad in ('x', None):
            try:
                resolve_cournot_gate(True, 'risk', 0.1, True, bad)
            except (TypeError, ValueError):
                self.fail(f'threshold={bad!r} 不应抛异常')

    # ---------- 两种成因的完整真值表 ----------
    def test_two_causes_truth_table(self):
        """完整真值表：验证"两种成因被正确区分"这一核心修复。"""
        cases = [
            # (risk, fresh, 期望 gate, 期望 risk, 期望 game)
            (0.10, True,  False, True,  True),    # 成因(b) 风险合格、稳定性未达
            (0.50, True,  False, False, True),    # 成因(a) 风险超限
            (0.10, False, False, False, True),    # 数据陈旧
            (None, True,  False, False, True),    # 无风险数据
        ]
        for risk, fresh, e_gate, e_risk, e_game in cases:
            g = resolve_cournot_gate(True, 'gate', risk, fresh, 0.30)[0]
            r = resolve_cournot_gate(True, 'risk', risk, fresh, 0.30)[0]
            m = resolve_cournot_gate(True, 'game', risk, fresh, 0.30)[0]
            tag = f'risk={risk}, fresh={fresh}'
            self.assertEqual(g, e_gate, f'gate 口径 {tag}')
            self.assertEqual(r, e_risk, f'risk 口径 {tag}')
            self.assertEqual(m, e_game, f'game 口径 {tag}')

    def test_risk_mode_is_strictly_between_gate_and_game(self):
        """'risk' 必须严格介于 'gate'（从不放行）与 'game'（总是放行）之间。"""
        for risk, fresh in ((0.10, True), (0.50, True), (0.10, False)):
            g = resolve_cournot_gate(True, 'gate', risk, fresh, 0.30)[0]
            r = resolve_cournot_gate(True, 'risk', risk, fresh, 0.30)[0]
            m = resolve_cournot_gate(True, 'game', risk, fresh, 0.30)[0]
            self.assertLessEqual(g, r)
            self.assertLessEqual(r, m)


if __name__ == '__main__':
    unittest.main(verbosity=2)
