#!/usr/bin/env python3
"""【P2 博弈区间】rv/fv 角色划分与"博弈进行中"判定的单元测试（纯 stdlib，无 CARLA）。

被修的两个缺陷（都在左转适配中才暴露）：

P2-a 角色划分依赖**瞬时车速**：
    `t_ego = arc_to_cross / max(ego.v, 0.1)`，判据 `t_veh >= t_ego` 决定谁是 RV。
    自车一减速 `t_ego → ∞` ⇒ **所有交叉车都被重分类成"已先通过"的 fv**
    ⇒ `rv` 角色为空 ⇒ `lcttc_rv = inf`、`THW_boundary = inf`。
    后果：① 博弈在状态层面静默消失；② 奖励把 `inf` 当成"最安全"发满额安全分
    （P1-f：实测 expE_p0_100 第 4 回合连续 150 帧 +20.41 = 20 + 0.5×0.85）。
    修法：角色划分改用**计划到达时间** `t_ego_plan = arc / max(v, DSH_T_EGO_V_MIN)`，
    自车"想开多慢"不再改变"谁是对手"。

P2-b 没有显式的"博弈进行中"判定：
    补上 `game_active = (not committed) and 窗口内存在接近车 and (rv 或 fv 存在)`，
    其中窗口是**空间**量（到冲突点纵向距离 <= game_window），与自车速度无关。
"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.gap_analysis import identify_gap_vehicles, compute_gap_metrics
from Planning_library.scenario_snapshot import VehicleState, ScenarioSnapshot

CONFLICT_X, CONFLICT_Y = 6.0, -138.0
ARC = 3.0


def _ego(v, y=-135.0, committed=False):
    return VehicleState(x=CONFLICT_X, y=y, yaw=-3.141592653589793 / 2, v=v,
                        vx=0.0, vy=-v, length=4.5, width=2.0, role="ego", veh_id=0)


def _cross(x, v, vid):
    """交叉车（向西行驶），y 在交叉道路中心线上。"""
    return VehicleState(x=x, y=CONFLICT_Y, yaw=3.141592653589793, v=v, vx=-v, vy=0.0,
                        length=4.0, width=2.0, role="none", veh_id=vid)


def _snap(ego_v, cross_specs, committed=False, t_ego_plan=None, game_window=45.0):
    """cross_specs: [(x, v), ...]。t_ego_plan=None 时回落到瞬时 t_ego（旧口径）。"""
    vs = [_cross(x, v, 10 + i) for i, (x, v) in enumerate(cross_specs)]
    t_ego = ARC / max(ego_v, 0.1)
    return ScenarioSnapshot(ego=_ego(ego_v, committed=committed), vehicles=vs,
                            conflict_xy=(CONFLICT_X, CONFLICT_Y),
                            arc_to_cross=ARC, t_ego=t_ego, committed=committed,
                            t_ego_plan=t_ego_plan, game_window=game_window)


class TestRoleModePlanStopsFarming(unittest.TestCase):
    """P2-a：减速不得改变对手集合。"""

    #: 一辆远车（x=40 → 距冲突点 34 m，v=10 → t_veh=3.4s）
    FAR = [(40.0, 10.0)]

    def test_slow_ego_keeps_same_rv_in_plan_mode(self):
        """计划口径：自车 6 m/s 与 0.3 m/s 得到**同一个 rv**。"""
        # CARLA 侧就是这么构造的：t_ego_plan 用计划车速（下限 DSH_T_EGO_V_MIN=3.0）
        t_plan = ARC / 3.0
        fast = identify_gap_vehicles(_snap(6.0, self.FAR, t_ego_plan=t_plan), role_mode='plan')
        slow = identify_gap_vehicles(_snap(0.3, self.FAR, t_ego_plan=t_plan), role_mode='plan')
        self.assertIsNotNone(fast['rv'], "6 m/s 时应识别出 rv")
        self.assertIsNotNone(slow['rv'], "0.3 m/s 蠕动时 rv 不得消失")
        self.assertEqual(fast['rv'].veh_id, slow['rv'].veh_id,
                         "自车减速后对手必须还是同一辆")
        self.assertEqual(fast['game_active'], slow['game_active'])

    def test_time_mode_reproduces_the_bug(self):
        """旧口径反证：同一场景下慢速自车把 rv '变没'了 —— 这就是被修的洞。"""
        fast = identify_gap_vehicles(_snap(6.0, self.FAR), role_mode='time')
        slow = identify_gap_vehicles(_snap(0.3, self.FAR), role_mode='time')
        self.assertIsNotNone(fast['rv'], "6 m/s（t_ego=0.5s < t_veh=3.4s）-> rv 存在")
        self.assertIsNone(slow['rv'],
                          "0.3 m/s（t_ego=10s > t_veh）-> 旧口径下 rv 消失（BUG 复现）")
        # 且旧口径下所有车都被归成 fv 或无人认领
        self.assertTrue(slow['game_active'] in (True, False))  # 仅确认不抛异常

    def test_no_rv_when_no_cross_vehicle_at_all(self):
        ids = identify_gap_vehicles(_snap(0.3, [], t_ego_plan=ARC / 3.0), role_mode='plan')
        self.assertIsNone(ids['rv'])
        self.assertIsNone(ids['fv'])
        self.assertFalse(ids['game_active'], "没有交叉车就没有博弈")

    def test_metrics_expose_game_active(self):
        met = compute_gap_metrics(_snap(0.3, self.FAR, t_ego_plan=ARC / 3.0), role_mode='plan')
        self.assertTrue(met['game_active'])
        self.assertIsNotNone(met['rv'], "compute_gap_metrics 必须把 rv 透出来（供审计）")


class TestGameActive(unittest.TestCase):
    """P2-b：显式「博弈进行中」判定。"""

    NEAR = [(12.0, 10.0)]

    def test_active_when_not_committed_and_vehicle_in_window(self):
        ids = identify_gap_vehicles(_snap(3.0, self.NEAR, t_ego_plan=ARC / 3.0))
        self.assertTrue(ids['game_active'])

    def test_inactive_when_committed(self):
        ids = identify_gap_vehicles(_snap(3.0, self.NEAR, committed=True,
                                          t_ego_plan=ARC / 3.0))
        self.assertFalse(ids['game_active'],
                         "已越过冲突点 => 博弈结束（论文：由 LCV 质心是否越过车道线决定）")

    def test_inactive_when_vehicle_outside_spatial_window(self):
        # x=100 -> 距冲突点 94 m > 窗口 45 m：不计入博弈
        far = [(100.0, 10.0)]
        ids = identify_gap_vehicles(_snap(3.0, far, t_ego_plan=ARC / 3.0, game_window=45.0))
        self.assertFalse(ids['game_active'], "窗口外的车不该构成博弈")
        self.assertEqual(ids['n_vehicles'], 0)
        # 把窗口放大后同一辆车就参与博弈了
        ids2 = identify_gap_vehicles(_snap(3.0, far, t_ego_plan=ARC / 3.0, game_window=120.0))
        self.assertTrue(ids2['game_active'])

    def test_game_active_independent_of_ego_speed(self):
        """核心不变式：博弈是否进行，不能由自车当前速度决定。"""
        t_plan = ARC / 3.0
        for v in (0.0, 0.3, 1.0, 3.0, 6.0, 8.0):
            ids = identify_gap_vehicles(_snap(v, self.NEAR, t_ego_plan=t_plan),
                                        role_mode='plan')
            self.assertTrue(ids['game_active'],
                            f"ego_v={v} 时博弈应仍进行中（与速度无关）")


class TestSwapSafety(unittest.TestCase):
    """重新划分后 rv/fv 的语义仍然自洽：rv 晚于自车到，fv 早于自车到。"""

    def test_rv_is_the_later_vehicle_and_fv_the_earlier(self):
        # 自车 plan 速度 3 m/s、arc=3 -> t_plan=1.0s
        # x=12 -> t_veh=(12-6)/10=0.6s < 1.0 -> fv（先到）
        # x=25 -> t_veh=(25-6)/10=1.9s > 1.0 -> rv（后到）
        # 注意 rv_t_veh / fv_t_veh 是**与 t_plan 的时间差**（dt），不是绝对到达时间。
        ids = identify_gap_vehicles(_snap(3.0, [(12.0, 10.0), (25.0, 10.0)],
                                         t_ego_plan=ARC / 3.0), role_mode='plan')
        self.assertIsNotNone(ids['fv'])
        self.assertIsNotNone(ids['rv'])
        self.assertAlmostEqual(ids['fv'].x, 12.0, msg="fv 应是先到的那辆")
        self.assertAlmostEqual(ids['rv'].x, 25.0, msg="rv 应是后到的那辆")
        t_fv = abs(12.0 - CONFLICT_X) / 10.0
        t_rv = abs(25.0 - CONFLICT_X) / 10.0
        self.assertLess(t_fv, ARC / 3.0, "fv 必须早于自车计划到达")
        self.assertGreater(t_rv, ARC / 3.0, "rv 必须晚于自车计划到达")
        self.assertAlmostEqual(ids['fv_t_veh'], ARC / 3.0 - t_fv)
        self.assertAlmostEqual(ids['rv_t_veh'], t_rv - ARC / 3.0)
        # 米制净间隙 g_d = x_RV − x_FV − L = 25 − 12 − 4 = 9
        from Planning_library.gap_analysis import fv_rv_spatial_gap
        self.assertAlmostEqual(fv_rv_spatial_gap(ids), 9.0)


if __name__ == "__main__":
    unittest.main()
