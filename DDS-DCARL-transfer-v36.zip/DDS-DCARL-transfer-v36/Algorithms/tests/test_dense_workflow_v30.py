"""Dense-scene training must precede a separate, frozen paired comparison."""
import importlib
import json
import os
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
from unittest.mock import patch


class DenseWorkflowTests(unittest.TestCase):
    def workflow(self):
        try:
            return importlib.import_module('Tools.run_dense_validation_v30')
        except ModuleNotFoundError:
            self.fail('The continuous-scene training/frozen-evaluation workflow is missing')

    def test_default_is_150_new_training_then_150_evaluation_per_arm(self):
        workflow = self.workflow()
        stages = workflow.build_plan(Path('dense-output'))
        self.assertEqual([row['episodes_total'] for row in stages], [150, 300])
        self.assertEqual(stages[0]['arms'], ['U1_cg_train_v29'])
        self.assertEqual(stages[0]['seeds'], [201])
        self.assertEqual(stages[1]['arms'], ['M6_matrix_v18', 'U2_cg_eval_v29'])
        self.assertEqual(stages[1]['episodes_per_run'], 30)
        self.assertEqual(stages[1]['seeds'], [211, 212, 213, 214, 215])
        for row in stages:
            args = row['arguments']
            self.assertEqual(args[args.index('--traffic-clear-gap')+1], '8.0')
            self.assertEqual(args[args.index('--traffic-flow-mode')+1], 'continuous_v30')
            self.assertNotIn('--replay-source', args)
            self.assertEqual(args[args.index('--rolling-learner')+1], 'cg_v29')
        self.assertNotIn('--rolling-checkpoint', stages[0]['arguments'])
        self.assertIn('--rolling-checkpoint', stages[1]['arguments'])

    def test_evaluation_seeds_cannot_overlap_training_or_repeat(self):
        workflow = self.workflow()
        for seeds in ([201], [211, 211], []):
            with self.subTest(seeds=seeds), self.assertRaises(ValueError):
                workflow.build_plan(Path('out'), eval_seeds=seeds)
        for train, evaluate in ((0, 30), (150, 0)):
            with self.assertRaises(ValueError):
                workflow.build_plan(Path('out'), train_episodes=train, eval_episodes=evaluate)

    def fixture(self, workflow, directory):
        from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
        stages = workflow.build_plan(directory)
        train = stages[0]
        root = directory/train['name']
        run = root/'U1_cg_train_v29_seed201'
        checkpoint = run/'rolling_model/rolling_model.json'
        checkpoint.parent.mkdir(parents=True)
        checkpoint.write_text(json.dumps(dict(signature=CGTrajectoryLearnerV29().signature(),
            records=[], nodes={}, q={})), encoding='utf8')
        result = dict(complete=True, ego_log_complete=True, finished_episodes=150,
                      expected_episodes=150, execution_contract_ok=True)
        (run/'result.json').write_text(json.dumps(result), encoding='utf8')
        config = dict(workflow.scenario_configuration(), DSH_ROLLING_PHASE='train',
                      DSH_ROLLING_LEARNER='cg_v29', DSH_SEED='201')
        manifest = dict(episodes=150, overall_success=True, collection_finished=True,
            common=config, source_sha256={'train_dcarl_turn.py':'a'*64},
            runs=[dict(arm='U1_cg_train_v29', seed=201, environment_seed=201,
                       status='complete', config=config)])
        (root/'manifest.json').write_text(json.dumps(manifest), encoding='utf8')
        return train, checkpoint, root/'manifest.json'

    def test_checkpoint_is_bound_to_finished_new_scene_and_remains_read_only(self):
        workflow = self.workflow()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            train, checkpoint, manifest = self.fixture(workflow, root)
            before = checkpoint.read_bytes()
            seal = workflow.seal_checkpoint(root, train)
            self.assertEqual(seal['finished_training_episodes'], 150)
            self.assertEqual(seal['real_record_episode_coverage'], 0)
            self.assertEqual(workflow.verify_checkpoint(root, train)['checkpoint_sha256'],
                             seal['checkpoint_sha256'])
            self.assertEqual(checkpoint.read_bytes(), before)
            checkpoint.write_text('{}', encoding='utf8')
            with self.assertRaises(ValueError):
                workflow.verify_checkpoint(root, train)

    def test_incomplete_training_or_different_traffic_cannot_be_sealed(self):
        workflow = self.workflow()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            train, checkpoint, manifest_path = self.fixture(workflow, root)
            original = json.loads(manifest_path.read_text(encoding='utf8'))
            bad = json.loads(json.dumps(original))
            bad['runs'][0]['config']['DSH_TRAFFIC_CLEAR_GAP'] = '5.0'
            manifest_path.write_text(json.dumps(bad), encoding='utf8')
            with self.assertRaises(ValueError):
                workflow.seal_checkpoint(root, train)
            manifest_path.write_text(json.dumps(original), encoding='utf8')
            result_path = checkpoint.parent.parent/'result.json'
            result = json.loads(result_path.read_text(encoding='utf8'))
            result['finished_episodes'] = 149
            result_path.write_text(json.dumps(result), encoding='utf8')
            with self.assertRaises(ValueError):
                workflow.seal_checkpoint(root, train)

    def test_changed_training_manifest_invalidates_the_checkpoint_scene_evidence(self):
        workflow = self.workflow()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            train, checkpoint, manifest = self.fixture(workflow, root)
            workflow.seal_checkpoint(root, train)
            manifest.write_text(manifest.read_text(encoding='utf8')+'\n', encoding='utf8')
            with self.assertRaises(ValueError):
                workflow.verify_checkpoint(root, train)

    def test_evaluation_cannot_silently_change_scene_sources_or_enable_exploration(self):
        workflow = self.workflow()
        self.assertTrue(hasattr(workflow, 'validate_stage_manifest'),
                        'Every arm needs the same actual runtime scene/source contract')
        stage = workflow.build_plan(Path('out'), eval_seeds=[211])[1]
        config = dict(workflow.scenario_configuration(), DSH_ROLLING_LEARNER='cg_v29', DSH_SEED='211')
        runs = [dict(arm='M6_matrix_v18', seed=211, environment_seed=211, config=dict(config)),
                dict(arm='U2_cg_eval_v29', seed=211, environment_seed=211,
                     config=dict(config, DSH_ROLLING_PHASE='eval', DSH_ROLLING_EPSILON='0'))]
        manifest = dict(runs=runs, source_sha256={'train_dcarl_turn.py':'a'*64})
        self.assertIsNone(workflow.validate_stage_manifest(manifest, stage, manifest['source_sha256']))
        for field, value in [('DSH_TRAFFIC_CLEAR_GAP', '5.0'), ('DSH_ROLLING_EPSILON', '.3')]:
            bad = json.loads(json.dumps(manifest))
            bad['runs'][1]['config'][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                workflow.validate_stage_manifest(bad, stage, manifest['source_sha256'])
        with self.assertRaises(ValueError):
            workflow.validate_stage_manifest(manifest, stage, {'train_dcarl_turn.py':'b'*64})

    def test_report_keeps_actual_flow_classification_separate_from_task_success(self):
        workflow = self.workflow()
        from test_continuous_traffic_v30 import fixture
        from Tools.run_trajectory_validation_v21 import PHYSICAL_FIELDS
        import csv
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            stages = workflow.build_plan(root, train_episodes=1, eval_episodes=1, eval_seeds=[211])
            for stage in stages:
                parent = root/stage['name']; parent.mkdir()
                runs = []
                for arm in stage['arms']:
                    seed = stage['seeds'][0]
                    directory = parent/('%s_seed%d' % (arm, seed)); directory.mkdir()
                    ego, traffic, spawns, flow, metadata = fixture()
                    # One physical merge can be followed by a task collision.
                    for index, row in enumerate(ego):
                        row.update(dict.fromkeys((key for key in PHYSICAL_FIELDS if key not in row), '0'))
                        row.update(ego_v_after='4', goal_remaining='20', ego_acc_measured='0',
                                   guard_selected_gap='1', wait_standoff='1', mpc_l='0')
                    for row in traffic: row['commanded_acceleration'] = '0'
                    outcome = 'collision' if arm == 'U2_cg_eval_v29' else 'complete'
                    files = dict(interaction_ego=ego, traffic_spacing_samples=traffic,
                                 traffic_spawns=spawns, traffic_flow_events_v30=flow,
                                 interaction_summary=[dict(episode=1, frames=3, outcome=outcome)])
                    for name, rows in files.items():
                        with (directory/(name+'.csv')).open('w', newline='', encoding='utf8') as stream:
                            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                            writer.writeheader(); writer.writerows(rows)
                    (directory/'traffic_spacing_metadata.json').write_text(json.dumps(metadata), encoding='utf8')
                    result = dict(complete=True, ego_log_complete=True, finished_episodes=1,
                                  expected_episodes=1, execution_contract_ok=True)
                    if arm.startswith('U'):
                        result.update(rolling_counts=dict(rows=3, takeovers=0), rolling_actual_actions={'0':3})
                    (directory/'result.json').write_text(json.dumps(result), encoding='utf8')
                    phase = {'U1_cg_train_v29':'train', 'U2_cg_eval_v29':'eval'}.get(arm)
                    config = dict(workflow.scenario_configuration(), DSH_ROLLING_LEARNER='cg_v29', DSH_SEED=str(seed))
                    if phase: config['DSH_ROLLING_PHASE'] = phase
                    if phase == 'eval': config['DSH_ROLLING_EPSILON'] = '0'
                    runs.append(dict(arm=arm, seed=seed, environment_seed=seed, status='complete', config=config))
                (parent/'manifest.json').write_text(json.dumps(dict(runs=runs, episodes=1,
                    overall_success=True, collection_finished=True, source_sha256={})), encoding='utf8')
            from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
            checkpoint = root/'01_train/U1_cg_train_v29_seed201/rolling_model/rolling_model.json'
            checkpoint.parent.mkdir(parents=True)
            checkpoint.write_text(json.dumps(dict(signature=CGTrajectoryLearnerV29().signature(),
                records=[], nodes={}, q={})), encoding='utf8')
            workflow.seal_checkpoint(root, stages[0])
            with patch.object(workflow, 'inspect_runtime', return_value=dict(ok=True, errors={})): 
                report = workflow.collect_report(root, stages)
            self.assertTrue(report['collection_ok'], report)
            treatment = report['stages'][1]['arms']['U2_cg_eval_v29']
            self.assertEqual(treatment['insertion_classifications'], {'in_flow_merge':1})
            self.assertEqual(treatment['task_successful_in_flow_merges'], 0)
            self.assertEqual(treatment['collisions'], 1)
            self.assertFalse(report['benefit_established'])
            checkpoint.write_text(checkpoint.read_text(encoding='utf8')+'\n', encoding='utf8')
            with patch.object(workflow, 'inspect_runtime', return_value=dict(ok=True, errors={})): 
                tampered = workflow.collect_report(root, stages)
            self.assertFalse(tampered['collection_ok'],
                             'Final report must reject changed model evidence just like the runner')
            self.assertFalse(tampered.get('checkpoint_evidence_ok', True))
            (root/'WORKFLOW.json').write_text(json.dumps(dict(stages=stages)), encoding='utf8')
            with patch.object(workflow, 'inspect_runtime', return_value=dict(ok=True, errors={})): 
                self.assertEqual(workflow.main(['--report-only', '--output-root', str(root)]), 11)
            # Remote launch must not depend on a developer's Algorithms PYTHONPATH.
            import numpy
            environment = dict(os.environ, PYTHONPATH=str(Path(numpy.__file__).resolve().parent.parent))
            process = subprocess.run([sys.executable, str(Path(workflow.__file__).resolve()),
                '--report-only', '--output-root', str(root)], cwd=str(root), env=environment,
                capture_output=True, universal_newlines=True, timeout=30.)
            self.assertEqual(process.returncode, 11, process.stderr)
            self.assertIn('"collection_ok": false', process.stdout)


if __name__ == '__main__':
    unittest.main()
