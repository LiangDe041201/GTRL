"""Regressions for v9 delayed feedback and recorded brake release cycling."""
import ast
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

import numpy as np

from Planning_library.pedal_control import PedalControllerV10, signed_speed
from Planning_library.synchronous_control import configure_physics, submit_control
from Planning_library.control_probe import StopRestartProbe
from Tools.run_actuator_probe import ProbeController, run_case, main as probe_main
from Tools.validate_control_health import validate_control_health

ROOT = Path(__file__).resolve().parents[1]
GAIN = 3200./(.355*1696.)  # v9 returned wheel torque, radius and mass


class TestSynchronousControl(unittest.TestCase):
    def test_batch_waits_for_response_without_tick_cue(self):
        calls = []
        def apply(batch, tick):
            calls.append((batch, tick))
            return [S(error='')]
        command = S(ApplyVehicleControl=lambda actor, control: (actor, control))
        self.assertTrue(submit_control(S(apply_batch_sync=apply), command, 42, {'brake': .01}))
        self.assertEqual(calls, [([(42, {'brake': .01})], False)])

    def test_failed_or_missing_response_is_not_accepted(self):
        command = S(ApplyVehicleControl=lambda actor, control: None)
        for response in ([], [S(error='actor not found')]):
            with self.assertRaises(RuntimeError):
                submit_control(S(apply_batch_sync=lambda batch, tick: response), command, 42, {})

    def test_effective_physics_settings_are_checked(self):
        settings = S()
        world = S(get_settings=lambda: settings, apply_settings=lambda s: None)
        result = configure_physics(world)
        self.assertEqual(result['max_substep_delta_time'], .005)
        self.assertGreaterEqual(result['max_substeps']*.005, .05)
        self.assertTrue(result['synchronous_mode'])

    def test_server_ignoring_settings_fails(self):
        settings = S()
        world = S(get_settings=lambda: settings,
                  apply_settings=lambda s: setattr(s, 'max_substep_delta_time', .02))
        with self.assertRaises(RuntimeError):
            configure_physics(world)

    def test_actual_environment_uses_batch_before_exactly_one_tick_and_snapshot_data(self):
        path = ROOT/'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(path.read_text(encoding='utf8'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CarEnv_Town03_Turn')
        step = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'step')
        body = []
        for node in step.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Tuple) for t in node.targets):
                if any(isinstance(n, ast.Attribute) and n.attr == 'wrap_state' for n in ast.walk(node)):
                    break
            body.append(node)
        step.body = body+[ast.Return(value=ast.Attribute(value=ast.Name(id='self', ctx=ast.Load()),
            attr='last_control', ctx=ast.Load()))]
        events, control = [], {}
        transform = S(rotation=S(yaw=0.), get_forward_vector=lambda: S(x=1., y=0.))
        class World:
            frame = 0
            def get_snapshot(self):
                actor = S(get_velocity=lambda: S(x=2.-.025*self.frame, y=0.),
                    get_transform=lambda: transform, get_acceleration=lambda: S(x=-.5, y=0.))
                return S(frame=self.frame, timestamp=S(elapsed_seconds=self.frame*.05), find=lambda i: actor)
            def tick(self):
                events.append('tick')
                self.frame += 1
                return self.frame
        world = World()
        def batch(commands, tick):
            self.assertFalse(tick)
            events.append('batch')
            control.update(commands[0][1], gear=1)
            return [S(error='')]
        # Poison actor velocity: correct code must use the selected snapshots.
        actor = S(id=42, get_velocity=lambda: S(x=99., y=0.), get_control=lambda: S(**control))
        env = S(world=world, client=S(apply_batch_sync=batch), ego_vehicle=actor,
            native_control=False, pedal_control=True, synchronous_control=True,
            pedal_controller=PedalControllerV10(GAIN, 1.2), control_geometry=dict(max_steer=1.2, wheelbase=2.86),
            physics_timing=dict(max_substep_delta_time=.005), dt=.05, sim_frame=0, traffic_enabled=True,
            cross_traffic=S(run_step=lambda ego: (None, -1, float('inf'))), update_vehicle_bboxes=lambda: None)
        namespace = dict(np=np, math=math, signed_speed=signed_speed, submit_control=submit_control,
            carla=S(VehicleControl=lambda **kw: kw,
                command=S(ApplyVehicleControl=lambda actor, request: (actor, request))))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[step], type_ignores=[])), str(path), 'exec'), namespace)
        result = namespace['step'](env, [-3., .2], target_speed=0.)
        self.assertEqual(events, ['batch', 'tick'])
        self.assertEqual(result['ego_v_before'], 2.)
        self.assertAlmostEqual(result['ego_acc_measured'], -.5)
        self.assertEqual(result['control_tick_frame'], result['control_feedback_frame'])
        self.assertEqual(result['actuator_mode'], 'feedback_pedal_v10')
        self.assertEqual(result['throttle'], 0.)


class TestMeasuredBraking(unittest.TestCase):
    def test_audit_does_not_assume_instant_braking_for_the_new_servo(self):
        from Planning_library.execution_guard import rollout, select_execution
        geometry = dict(wheelbase=2.86, max_steer=1.2)
        slow = dict(geometry, brake_response_jerk=.5, execution_horizon=6.)
        ego = S(x=0., y=0., yaw=0., v=3., vx=3., vy=0., length=4., width=2.)
        obstacle = S(veh_id=9, x=8., y=0., yaw=0., v=0., vx=0., vy=0., length=4., width=2.)
        path = np.c_[np.linspace(0., 50., 101), np.zeros(101)]
        previous = dict(a=0., df=0.)
        fast, times = rollout(ego, path, 0., -3., 0., previous, geometry, horizon=6., lag=0.)
        states, _ = rollout(ego, path, 0., -3., 0., previous, slow, horizon=6., lag=0.)
        self.assertGreater(states[0, -1], fast[0, -1]+2.)
        selected, audit = select_execution(ego, [obstacle], path, 0., -3., 0., previous,
            slow, prediction=fast, prediction_times=times)
        self.assertFalse(audit['safe'])
        self.assertTrue(audit['unavoidable'])
        self.assertEqual(selected['actor'], 9)

    def test_initial_brake_step_at_returned_physics_gain_is_smaller(self):
        controller = PedalControllerV10(GAIN, 1.2)
        request = controller.command(-3., 3.77, 0., 0.)
        self.assertAlmostEqual(request['brake'], .75*.05/GAIN)
        self.assertLess(request['brake'], .008)
        self.assertEqual(request['throttle'], 0.)

    def test_measured_deceleration_prevents_unconditional_brake_ramp(self):
        controller = PedalControllerV10(GAIN, 1.2)
        controller.brake = .15
        controller.observe(3.2, 3.04, .05)  # -3.2 while the request is -3
        request = controller.command(-3., 3.04, 0., 0.)
        self.assertLess(request['brake'], .15)

    def test_recorded_shock_does_not_rearm_after_one_calm_frame(self):
        controller = PedalControllerV10(GAIN, 1.2)
        # Reproduce the v9 raw evidence, not a model claimed to match CARLA.
        speeds = [3.192195, 2.632935, 2.230158, 2.220822, 1.051448, 1.199451]
        for before, after in zip(speeds, speeds[1:]):
            controller.observe(before, after, .05)
            request = controller.command(-3., after, 0., 0.)
            self.assertEqual(request['brake'], 0.)
        self.assertTrue(controller.release_active)

    def test_release_requires_both_minimum_time_and_stable_observations(self):
        controller = PedalControllerV10(GAIN, 1.2)
        controller.observe(3., 2., .05)
        for _ in range(4):
            controller.observe(2., 2., .05)
            self.assertEqual(controller.command(-3., 2., 0., 0.)['brake'], 0.)
        controller.observe(2., 2., .05)
        self.assertFalse(controller.release_active)
        self.assertGreater(controller.command(-3., 2., 0., 0.)['brake'], 0.)

    def test_stop_and_restart_at_real_brake_gain_with_declared_model_uncertainty(self):
        for drive_gain, brake_ratio, lag in [(2., .7, .15), (3., 1., .2), (5., 1.4, .3)]:
            controller, probe = PedalControllerV10(GAIN, 1.2), StopRestartProbe()
            speed, acceleration = 0., 0.
            for _ in range(600):
                target = probe.target(4.)
                command = max(-3., min(2., 1.5*(target-speed)))
                request = controller.command(command, speed, target, 0.)
                equilibrium = drive_gain*request['throttle']-GAIN*brake_ratio*request['brake']-.35
                acceleration += .05/(lag+.05)*(equilibrium-acceleration)
                after = max(0., speed+.05*acceleration)
                controller.observe(speed, after, .05)
                probe.observe(after)
                speed = after
                if probe.phase in ('done', 'failed'):
                    break
            self.assertEqual(probe.phase, 'done', (drive_gain, brake_ratio, lag, probe.failure))


class FakeProbeEnvironment:
    def __init__(self):
        self.dt, self.cleaned = .05, False
    def reset(self, train):
        self.speed, self.frame = 0., 0
        self.pedal_controller = PedalControllerV10(GAIN, 1.2)
    def step(self, action, target_speed):
        request = self.pedal_controller.command(*[action[0], self.speed, target_speed, action[1]])
        before = self.speed
        self.speed = max(0., before-.05*(.2+request['brake']*GAIN)) if self.pedal_controller.pulse else min(2.1, before+.1)
        self.frame += 1
        self.last_control = dict(request, ego_v_before=before, ego_v_after=self.speed,
            ego_acc_measured=(self.speed-before)/.05, sim_dt=.05,
            sim_frame_before=self.frame-1, sim_frame_after=self.frame, control_tick_frame=self.frame,
            control_feedback_frame=self.frame, control_submit_ok=1, control_transport='batch_sync_pre_tick',
            **{'requested_'+key: request[key] for key in ('throttle', 'brake', 'steer')})
        return None, None, False, None
    def cleanup(self):
        self.cleaned = True


class TestIndependentProbe(unittest.TestCase):
    def test_probe_retains_partial_rows_after_runtime_error(self):
        class Broken(FakeProbeEnvironment):
            def step(self, action, target_speed):
                if self.frame == 7:
                    raise RuntimeError('offline injected submission failure')
                return super().step(action, target_speed)
        env = Broken()
        with tempfile.TemporaryDirectory() as directory, patch.dict('os.environ', {}, clear=False):
            output = Path(directory)/'failed_probe'
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(probe_main(['--output-root', str(output)], env_factory=lambda: env), 6)
            result = json.loads((output/'result.json').read_text(encoding='utf8'))
            self.assertFalse(result['ok'])
            self.assertIn('submission failure', result['error'])
            self.assertEqual(len((output/'actuator_probe.csv').read_text(encoding='utf8').splitlines()), 8)
        self.assertTrue(env.cleaned)

    def test_shock_stops_open_loop_brake_after_triggering_sample(self):
        class Shock(FakeProbeEnvironment):
            def step(self, action, target_speed):
                answer = super().step(action, target_speed)
                if self.pedal_controller.pulse:
                    self.last_control['ego_acc_measured'] = -20.
                return answer
        rows, result = run_case(Shock(), 'light_brake')
        self.assertFalse(result['ok'])
        self.assertEqual(result['pulse_frames'], 1)
        self.assertEqual(rows[-1]['ego_acc_measured'], -20.)
        self.assertIn('severe_deceleration', result['errors'])

    def test_no_mpc_coast_and_light_brake_have_exact_open_loop_commands(self):
        for mode, brake in [('coast', 0.), ('light_brake', .01)]:
            rows, result = run_case(FakeProbeEnvironment(), mode)
            self.assertTrue(result['ok'], result)
            pulse = [row for row in rows if row['diagnostic_phase'] == 'pulse']
            self.assertEqual(len(pulse), 20)
            self.assertTrue(all(row['throttle'] == row['steer'] == 0. and row['brake'] == brake for row in pulse))
            self.assertFalse(result['mpc_used'])

    def test_probe_launcher_saves_results_and_cleans_up(self):
        env = FakeProbeEnvironment()
        with tempfile.TemporaryDirectory() as directory, patch.dict('os.environ', {}, clear=False):
            output = Path(directory)/'probe'
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(probe_main(['--output-root', str(output)], env_factory=lambda: env), 0)
            result = json.loads((output/'result.json').read_text(encoding='utf8'))
            self.assertTrue(result['ok'])
            self.assertTrue((output/'actuator_probe.csv').exists())
        self.assertTrue(env.cleaned)

    def test_probe_dry_run_does_not_import_carla(self):
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(probe_main(['--dry-run']), 0)
        self.assertFalse(json.loads(stream.getvalue())['mpc_used'])

    def test_default_pair_uses_v10_and_differs_only_in_game(self):
        from Tools.run_relay_validation import main
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(main(['--dry-run', '--control-profile', 'paper_v10']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertTrue(all(c['DSH_CONTROL_PROFILE'] == 'paper_v10' for c in configs))
        self.assertEqual({k for k in configs[0] if configs[0][k] != configs[1][k]},
                         {'DSH_METHOD', 'DSH_TAKE_COURNOT'})

    def test_feedback_lag_is_not_hidden_by_new_health_check(self):
        row = dict(control_profile='paper_v10', actuator_mode='feedback_pedal_v10', sim_dt='.05',
            sim_frame_before='1', sim_frame_after='2', ego_v_before='2', ego_v_after='2',
            ego_acc_measured='0', a_cmd='0', actuator_speed_target='4', actuator_accel_limit='3',
            ego_v_signed_before='2', ego_v_signed_after='2', ego_acc_signed='0', ego_acc_sensor='0',
            throttle='.1', brake='0', steer='0', requested_throttle='.1', requested_brake='0', requested_steer='0',
            reverse='0', hand_brake='0', manual_gear_shift='0', gear='1', guard_safe='1',
            guard_unavoidable='0', guard_action='mpc', mpc_solve_ok='1', episode='1',
            control_transport='batch_sync_pre_tick', control_submit_ok='1', control_tick_frame='2',
            control_feedback_frame='2', physics_max_substep_dt='.005')
        self.assertTrue(validate_control_health([row], {}, profile='paper_v10')['actuator_contract_ok'])
        row['throttle'] = '.08'
        result = validate_control_health([row], {}, profile='paper_v10')
        self.assertFalse(result['actuator_contract_ok'])
        self.assertEqual(result['actuator_contract_errors']['pedal_feedback_throttle'], 1)


if __name__ == '__main__':
    unittest.main()
