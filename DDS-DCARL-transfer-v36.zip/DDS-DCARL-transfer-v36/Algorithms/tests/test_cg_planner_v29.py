"""Real MPC integration: CG baseline, trusted path ownership, actual credit."""
import ast
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import test_rolling_planner_v24 as fixtures

try:
    from Planning_library.cg_trajectory_planner_v29 import CGTrajectoryPlannerV29, select_rolling_planner
except ImportError:
    CGTrajectoryPlannerV29=select_rolling_planner=None


class CGPlannerTests(unittest.TestCase):
    def fixture(self,phase='train',directory=None):
        self.assertIsNotNone(CGTrajectoryPlannerV29,'CG-baseline learner has no execution owner')
        old,f=fixtures.RollingPlannerTests().fixture(phase)
        p=CGTrajectoryPlannerV29(phase,old.geometry,old.controllers,old.corridor,
            epsilon=0.,seed=7,directory=directory)
        return p,f

    def test_untrusted_real_candidates_preserve_the_exact_cg_request(self):
        p,f=self.fixture(); nominal=f[2][1]
        path=nominal['controller'].last_pathway.copy()
        out=fixtures.RollingPlannerTests().request(p,f)
        self.assertIs(out[1],nominal)
        self.assertEqual(p.last['actual_action'],0)
        self.assertEqual(p.last['learning']['default'],0)
        self.assertEqual(p.last['learning']['source'],'cg_default')
        self.assertGreater(len(p.last['allowed']),1)
        np.testing.assert_array_equal(nominal['controller'].last_pathway,path)

    def test_learned_advantage_controls_the_audited_path_and_retraction_credits_cg(self):
        p,f=self.fixture(); fx=fixtures.RollingPlannerTests()
        fx.request(p,f)
        context=p.last['learning_context'];beta=p.last['beta'];allowed=p.last['allowed']
        costs=[1e6]*6
        for c in p.last['candidates']:costs[c['action']]=c['cost']
        action=next(a for a in allowed if a)
        for episode in range(1,25):
            p.learner.begin(context,beta,0,allowed,costs,episode)
            p.learner.start(0 if episode<=12 else action)
            p.learner.reward(.01 if episode<=12 else .1)
            p.learner.finish()
        p.age=.5;out=fx.request(p,f)
        self.assertEqual(p.last['learning']['source'],'takeover')
        self.assertEqual(p.last['actual_action'],action)
        chosen=out[1];self.assertEqual(p.last['request']['path_hash'],
            next(c for c in p.last['candidates'] if c['action']==action)['path_hash'])
        self.assertIs(chosen['controller'],p.controllers[action-1])
        current=p.activate(f[2][1]['controller'],chosen['controller'])
        result=p.review_execution(current,f[1].ego_vehicle,f[1].objects,f[5]['previous'],
            dict(action='brake',override=True,safe=True))
        self.assertIs(result['controller'],f[2][1]['controller'])
        fx.feedback(p,outcome='complete')
        self.assertEqual(p.learner.records[-1]['action'],0)
        self.assertTrue(p.last['retracted'])

    def test_metadata_declares_the_new_baseline_and_signature(self):
        with tempfile.TemporaryDirectory() as t:
            p,f=self.fixture(directory=t);fixtures.RollingPlannerTests().request(p,f)
            meta=json.loads((Path(t)/'rolling_metadata_v24.json').read_text(encoding='utf8'))
            for obj in (meta,p.last):
                self.assertEqual(obj['learner_revision'],'cg_trajectory_learning_v29')
                self.assertEqual(obj['baseline_action'],0)
                self.assertEqual(obj['reference_policy'],'uniform_admissible_v29')
            self.assertEqual(meta['signature'],p.learner.signature())

    def test_dispatch_is_explicit_and_rejects_unwired_efe(self):
        self.assertIsNotNone(select_rolling_planner)
        from Planning_library.rolling_planner_v24 import RollingPlannerV24
        from Planning_library.rolling_shadow_v27 import RollingShadowPlannerV27
        self.assertIs(select_rolling_planner('legacy_v24','off'),RollingPlannerV24)
        self.assertIs(select_rolling_planner('legacy_v24','shadow'),RollingShadowPlannerV27)
        self.assertIs(select_rolling_planner('cg_v29','off'),CGTrajectoryPlannerV29)
        for args in [('cg_v29','shadow'),('unknown','off'),('legacy_v24','unknown')]:
            with self.assertRaises(ValueError):select_rolling_planner(*args)
        source=Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree=ast.parse(source.read_text(encoding='utf8'))
        calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)
               and isinstance(n.func,ast.Name) and n.func.id=='select_rolling_planner']
        self.assertEqual(len(calls),1,'Actual driver must use the tested dispatcher')

    def test_new_arms_opt_in_without_changing_old_arms(self):
        from Tools.run_relay_validation import ARMS,COMMON,effective_configuration
        for arm,phase in [('U0_cg_observe_v29','observe'),('U1_cg_train_v29','train'),('U2_cg_eval_v29','eval')]:
            c=effective_configuration(COMMON,arm)
            self.assertEqual(c['DSH_ROLLING_LEARNER'],'cg_v29')
            self.assertEqual(c['DSH_ROLLING_PHASE'],phase)
            self.assertEqual(c['DSH_EFE'],'0')
        self.assertEqual(effective_configuration(COMMON,'T2_train_v24')['DSH_ROLLING_LEARNER'],'legacy_v24')


if __name__=='__main__':unittest.main()
