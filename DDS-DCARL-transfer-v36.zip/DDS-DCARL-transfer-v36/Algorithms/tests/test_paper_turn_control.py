"""v7 regression cases from returned CARLA failures; no CARLA installation."""
import ast
import math
from pathlib import Path
from types import SimpleNamespace as S
import unittest
import os
import copy
import csv
import io
import json
import tempfile
from contextlib import redirect_stdout
from unittest.mock import patch

import numpy as np
from Planning_library.paper_turn_control import (
    TurnFeasibility, reset_driving_state, nearby_vehicles, motion_forecast,
    rectangle_gap, symbolic_interaction_cost, baseline_geometry_cost, prediction_clearance)


def vehicle(actor=42, x=8., y=0., yaw=math.pi, v=4.):
    return S(veh_id=actor, x=x, y=y, yaw=yaw, v=v,
             vx=v*math.cos(yaw), vy=v*math.sin(yaw), length=4., width=2.)


class TestPaperTurn(unittest.TestCase):
    def test_stopped_ego_detects_approaching_vehicle(self):
        value = symbolic_interaction_cost(0., 0., 0., 0.,
                    [6., 0., math.pi, 4., 2., -4., 0.], [4.5, 2.])
        self.assertGreater(float(value), 0.)
        safe = symbolic_interaction_cost(0., 0., 0., 0.,
                    [6., 0., math.pi, 4., 2., 4., 0.], [4.5, 2.])
        self.assertEqual(float(safe), 0.)

    def test_passed_scalar_conflict_point_is_not_a_clear_body(self):
        ego = vehicle(actor=0, x=0., y=2., yaw=-math.pi/2, v=0.)
        threat = vehicle(x=-1., y=0.)
        self.assertLessEqual(rectangle_gap(ego.x, ego.y, ego.yaw, 4., 2.,
                             threat.x, threat.y, threat.yaw, 4., 2.), 0.)
        self.assertEqual(nearby_vehicles([threat], ego), [threat])
        self.assertEqual(motion_forecast(threat, [0., .05, .3])[2][0], -2.2)

    def test_episode_reset_clears_driving_memory_and_preserves_learner(self):
        memory = object()
        a = S(_commit_latched=True, _latch_age=99, _risk_ok_streak=10,
              _last_committing=True, belief_learner=memory, turn_feasibility=TurnFeasibility())
        a.turn_feasibility.launched = True
        reset_driving_state(a)
        self.assertFalse(a._commit_latched)
        self.assertFalse(a._last_committing)
        self.assertEqual(a._risk_ok_streak, 0)
        self.assertFalse(a.turn_feasibility.launched)
        self.assertIs(a.belief_learner, memory)

    def test_one_gate_rejects_collision_and_accepts_empty_road(self):
        ego = vehicle(actor=0, x=0., y=6., yaw=-math.pi/2, v=0.)
        path = np.c_[np.zeros(40), np.linspace(6., -30., 40)]
        gate = TurnFeasibility()
        self.assertEqual(gate.target(ego, [], path, 4., 3., -3.), 4.)
        obstacle = vehicle(x=0., y=0., v=0.)
        speed = gate.target(ego, [obstacle], path, 4., 2., -3.)
        self.assertEqual(speed, 0.)
        self.assertFalse(gate.last['safe'])
        self.assertEqual(gate.last['conflict_id'], 42)

    def test_no_role_filter_and_all_gate_vehicles_are_visible(self):
        ego = vehicle(actor=0, x=0., y=0., v=0.)
        objects = [vehicle(actor=i, x=i+5., y=0.) for i in range(10, 18)]
        self.assertEqual(len(nearby_vehicles(objects, ego)), 6)
        self.assertEqual(len(nearby_vehicles(objects, ego, limit=None)), 8)

    def test_unidentified_obstacle_still_enters_common_feasibility(self):
        ego = vehicle(actor=0, x=0., y=0., v=0.)
        obstacle = vehicle(actor=-1, x=1., y=0., v=0.)
        self.assertEqual(nearby_vehicles([obstacle], ego), [])
        self.assertEqual(nearby_vehicles([obstacle], ego, limit=None), [obstacle])

    def test_actual_optimizer_prediction_checks_role_free_objects(self):
        ego = vehicle(actor=0, x=0., y=0., yaw=0., v=2.)
        states = np.zeros((7, 3)); states[0, :] = [0., 1., 2.]
        gap, actor = prediction_clearance(states, [0., .5, 1.],
                                         [vehicle(x=5., y=0., v=0.)], ego)
        self.assertLess(gap, 0.)
        self.assertEqual(actor, 42)

    def test_geometry_score_does_not_reward_faster_speed(self):
        x = list(np.linspace(0., 20., 30))
        path = S(x=x, y=[0.]*30, s_ddd=[0.]*30, d_ddd=[0.]*30)
        self.assertEqual(baseline_geometry_cost(path), 0.)
        path.d_ddd = [1.]*30
        self.assertGreater(baseline_geometry_cost(path), 0.)

    def test_production_v7_dispatch_skips_legacy_decisions(self):
        source = Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree = ast.parse(source.read_text(encoding='utf-8'))
        block = next(node for node in ast.walk(tree) if isinstance(node, ast.If)
            and ast.dump(node.test) == ast.dump(ast.parse('self.paper_control', mode='eval').body)
            and any(isinstance(n, ast.Attribute) and n.attr == 'target'
                    for stmt in node.body for n in ast.walk(stmt)))
        calls = [n.func.id if isinstance(n.func, ast.Name) else n.func.attr
                 for stmt in block.body for n in ast.walk(stmt)
                 if isinstance(n, ast.Call) and isinstance(n.func, (ast.Name, ast.Attribute))]
        self.assertNotIn('cournot_decision', calls)
        self.assertNotIn('commit_risk', calls)
        self.assertNotIn('observe', calls)

    def test_production_polynomials_and_geometry_selection_execute(self):
        from Agent.tools_dds.tools import Frenet_path
        source = Path(__file__).resolve().parents[1]/'Agent/tools_dds/LaneTrajectoryPlanner.py'
        tree = ast.parse(source.read_text(encoding='utf-8'))
        names = ('Werling', 'quintic_polynomial', 'quartic_polynomial')
        definitions = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name in names]
        ns = dict(np=np, math=math, copy=copy, _os=os, Frenet_path=Frenet_path,
                  clean_path=lambda points: points if len(points) >= 3 else None,
                  KJ=1., KT=.1, KLAT=1., KLON=1., DT=.3, ACTION_MODE='2d',
                  TURN_2D_LATERALS=[-.4, 0., .4],
                  _adaptive_trajectory_horizon=lambda speed: 6.)
        exec(compile(ast.Module(body=definitions, type_ignores=[]), str(source), 'exec'), ns)
        planner = ns['Werling'].__new__(ns['Werling'])
        planner._lane_width = 3.
        planner.all_trajectory, planner.draw_trajectory, planner.path_i = [], [], 0
        planner.get_last_final_point = lambda dynamic: []
        planner.cal_montage_curvature = lambda *args: (0., 0., 0.)
        start = S(s0=0., c_d=0., c_d_d=0., c_d_dd=0.)
        csp = S(calc_position=lambda s: (s, 0.), calc_yaw=lambda s: 0.)
        dynamic = S(ego_vehicle=vehicle(actor=0, x=0., y=0., yaw=0., v=2.))
        with patch.dict(os.environ, {'DSH_CONTROL_PROFILE': 'paper_v7'}):
            result, speed, _ = planner.frenet_optimal_planning(
                csp, 2., start, 4., 0., dynamic, 0., 0)
        self.assertIsNotNone(result)
        self.assertGreater(len(result.x), 10)
        self.assertAlmostEqual(result.d[-1], 0.)
        self.assertGreater(speed, 3.)

    def test_pair_configuration_disables_learning_and_keeps_common_controls(self):
        from Tools.run_relay_validation import main
        stream = io.StringIO()
        with redirect_stdout(stream):
            self.assertEqual(main(['--episodes', '3', '--arms', 'B0_rule,C1_cg',
                                   '--control-profile', 'paper_v7', '--dry-run']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        for config in configs:
            self.assertEqual(config['DSH_EFE'], '0')
            self.assertEqual(config['DSH_WCV_BCV'], '0')
            self.assertEqual(config['DSH_CONTROL_PROFILE'], 'paper_v7')
        differing = {key for key in configs[0] if configs[0][key] != configs[1][key]}
        self.assertEqual(differing, {'DSH_METHOD', 'DSH_TAKE_COURNOT'})

    def test_new_diagnostics_roundtrip_without_role_mislabeling(self):
        from Planning_library.interaction_logger import InteractionLogger
        with tempfile.TemporaryDirectory() as directory:
            log = InteractionLogger(out_dir=directory, enabled=True)
            log.begin_episode(1)
            log.ego_row(ego=S(x=0., y=0., v=0.), control=dict(control_profile='paper_v7',
                prediction_horizon=2.3, mpc_solve_ms=23.5,
                mpc_audit_gap=-.1, mpc_audit_actor=179, mpc_audit_override=True,
                feasibility=dict(phase='waiting', safe=False, min_gap=-.2,
                                 conflict_id=179, threat_ids=[179, 180]),
                mpc_game=dict(participant_ids=[179, 180])))
            log.close()
            with (Path(directory)/'interaction_ego.csv').open(newline='', encoding='utf-8-sig') as f:
                row = next(csv.DictReader(f))
        self.assertEqual(row['mpc_game_participant_ids'], '179;180')
        self.assertEqual(row['feasibility_conflict_id'], '179')
        self.assertEqual(row['mpc_game_rv_id'], '')
        self.assertEqual(float(row['mpc_prediction_horizon']), 2.3)
        self.assertEqual(float(row['mpc_solve_ms']), 23.5)
        self.assertEqual(row['mpc_audit_override'], '1')
        self.assertEqual(row['mpc_audit_actor'], '179')


class TestPaperOptimizer(unittest.TestCase):
    def controller(self, enabled, speed=0., objects=None):
        from Agent.game_theory.MPC import MPCController
        controller = MPCController(16, .05, 2.7, .5, enable_lead_follow_cost=False,
            enable_boundary_thw=False, enable_cournot_cost=enabled,
            cost_profile='paper_v7', step_dts=[.05]*6+[.2]*10)
        ego = vehicle(actor=0, x=0., y=0., yaw=0., v=speed)
        dynamic = S(ego_vehicle=ego, lanes=[S(front_vehicles=[], rear_vehicles=[])])
        controller.reset_global_path(np.c_[np.arange(60.), np.zeros(60)], dynamic)
        controller.set_game_context(dict(observed_vehicles=objects or [], committed=True), ego)
        return controller, dynamic

    def test_no_opponent_has_no_game_weight_side_effect(self):
        commands = []
        for enabled in (False, True):
            controller, dynamic = self.controller(enabled, speed=2.)
            commands.append(controller.solve(dynamic, 4., False))
            self.assertTrue(controller._solve_ok)
            self.assertAlmostEqual(controller.prediction_times[-1], 2.3)
            self.assertAlmostEqual(controller.last_game_diag['total'], 0.)
        np.testing.assert_allclose(commands[0], commands[1], atol=1e-4)

    def test_brake_release_not_delayed_by_far_opponent(self):
        sequences = []
        for enabled in (False, True):
            controller, dynamic = self.controller(enabled, objects=[vehicle(x=25., y=25.)])
            controller.last_u = dict(a=-3., df=0.)
            sequence = []
            for _ in range(35):
                acceleration, steering = controller.solve(dynamic, 4., False)
                self.assertTrue(controller._solve_ok)
                controller.acknowledge_applied_control(acceleration, steering)
                sequence.append(acceleration)
            self.assertTrue(any(a >= 0. for a in sequence))
            sequences.append(sequence)
        np.testing.assert_allclose(sequences[0], sequences[1], atol=.015)

    def test_game_changes_control_and_keeps_passed_participant(self):
        commands = []
        for enabled in (False, True):
            controller, dynamic = self.controller(enabled, speed=3.,
                objects=[vehicle(x=7., y=0., v=0.)])
            commands.append(controller.solve(dynamic, 4., False))
            self.assertTrue(controller._solve_ok)
            if enabled:
                self.assertEqual(controller.last_game_diag['participant_ids'], [42])
                self.assertGreater(controller.last_game_diag['safety'], 0.)
                self.assertEqual(controller.last_game_diag['speed'], 0.)
                self.assertEqual(controller.last_game_diag['comfort'], 0.)
        self.assertGreater(float(np.linalg.norm(np.subtract(*commands))), .01)


if __name__ == '__main__':
    unittest.main()
