"""Guard-only CG recovery is not an optimized spatial candidate."""
import copy
from types import SimpleNamespace as S
import unittest

from Planning_library.rolling_planner_v24 import RollingPlannerV24
from Tools.validate_rolling_v24 import validate_rolling_record
import test_rolling_validation_v24 as fixtures


class RollingContractTests(unittest.TestCase):
    def evidence(self):
        return fixtures.RollingValidationTests().evidence()

    def project(self,row):
        p=row['rolling_trajectory']
        for c in p['candidates']:
            candidate=dict(c,controller=S(a_min=-3.,a_max=2.,max_steering=1.))
            c.update(RollingPlannerV24.description(candidate,c['action'],c['intent'],c['path']))
        p['request']=copy.deepcopy(next(c for c in p['candidates'] if c['action']==p['actual_action']))

    def test_failed_cg_is_explicit_guard_recovery_without_claiming_optimized_eligibility(self):
        row,ego=self.evidence();p=row['rolling_trajectory']; c=p['candidates'][0]
        c.update(solve_ok=False,plan=None,prediction=None,plan_hash=None,prediction_hash=None)
        self.project(row)
        self.assertIn('control_evidence',c,'No distinction between optimizer evidence and recovery ownership')
        self.assertTrue(c['control_evidence']['fallback_only'])
        self.assertFalse(c['control_evidence']['optimizer_valid'])
        # This failed base candidate was not selected; a separately valid new
        # candidate must retain its existing final safety review.
        self.assertEqual(validate_rolling_record(row,ego,'train'),{})

    def test_clipped_raw_solver_first_control_is_kept_and_audited_separately(self):
        row,ego=self.evidence();p=row['rolling_trajectory'];c=p['candidates'][0]
        c['plan'][0][0]=2.0000000183393296;c['a']=2.
        import hashlib,struct
        values=[v for r in c['plan'] for v in r]
        c['plan_hash']=hashlib.sha256(struct.pack('<%dd'%len(values),*values)).hexdigest()
        self.project(row)
        self.assertIn('control_evidence',c,'Raw and requested controls are not recorded separately')
        self.assertEqual(c['control_evidence']['raw_first'][0],2.0000000183393296)
        row['candidate_a'][row['selected']]=2.
        p['base_candidates'][row['selected']]['a']=2.
        self.assertEqual(validate_rolling_record(row,ego,'train'),{})

    def test_projection_cannot_hide_large_violations_or_change_interior_controls(self):
        for value in (3.,1.5):
            row,ego=self.evidence();c=row['rolling_trajectory']['candidates'][0]
            c['plan'][0][0]=value;c['a']=2.
            import hashlib,struct
            values=[v for r in c['plan'] for v in r]
            c['plan_hash']=hashlib.sha256(struct.pack('<%dd'%len(values),*values)).hexdigest()
            self.project(row)
            self.assertIn('first_control',validate_rolling_record(row,ego,'train'))

    def test_selected_failed_base_requires_real_final_guard_intervention(self):
        row,ego=self.evidence();p=row['rolling_trajectory'];c=p['candidates'][0]
        c.update(solve_ok=False,plan=None,prediction=None,plan_hash=None,prediction_hash=None)
        p.update(actual_action=0,changed_request=False,retracted=True,request_id=c['id'])
        self.project(row)
        row.update(pre_audit_a=c['a'],pre_audit_delta=c['delta'],pre_audit_target=c['target'],
            guard_action='brake',guard_override=True,applied_a=-2.,applied_delta=0.,applied_target=0.)
        p['feedback'].update(actual_action=0,guard_action='brake',intervention=True,
            applied_a=-2.,applied_delta=0.,applied_target=0.,reward=1./3600.)
        self.assertEqual(validate_rolling_record(row,ego,'train'),{})
        row.update(guard_action='mpc',guard_override=False)
        p['feedback'].update(guard_action='mpc')
        self.assertIn('fallback_execution',validate_rolling_record(row,ego,'train'))

    def test_guard_recovery_marker_cannot_qualify_a_failed_spatial_candidate(self):
        row,ego=self.evidence(); p=row['rolling_trajectory']
        c=next(c for c in p['candidates'] if c['action']!=0)
        c.update(solve_ok=False,plan=None,prediction=None,plan_hash=None,prediction_hash=None)
        self.project(row)
        self.assertTrue(validate_rolling_record(row,ego,'train'))


if __name__=='__main__':unittest.main()
