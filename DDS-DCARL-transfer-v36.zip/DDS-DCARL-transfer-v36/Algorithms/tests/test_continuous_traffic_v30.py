"""Actual box/supply evidence distinguishes flow insertion from unknown tails."""
import csv
import hashlib
import json
import math
from pathlib import Path
import tempfile
import unittest

try:
    from Tools import validate_continuous_traffic_v30 as audit
except ImportError:
    audit=None


def fixture():
    metadata=dict(flow_revision='traffic_flow_v30',flow_mode='continuous_v30',
        continuous_supply=True,finite_spawn_limit=None,artificial_long_gaps_enabled=False,
        flow_center_y=0.,conflict_x=4.,expected_sample_dt=.05)
    ego=[];traffic=[];flow=[]
    for frame,x,y,front,rear in ((1,8.,4.,4.,14.),(2,5.,1.5,0.,10.),(3,0.,0.,-5.,6.)):
        ego.append(dict(episode=1,frame=frame,ego_x=x,ego_y=y,ego_yaw=math.pi,
            ego_length=4.,ego_width=2.,ego_v=4.))
        for actor,position in ((1,front),(2,rear)):
            traffic.append(dict(episode=1,frame=frame,actor_id=actor,x=position,y=0.,
                observed_yaw_rad=math.pi,observed_length=2.,observed_width=2.,
                observed_speed=4.,pose_source='actor_snapshot'))
        flow.append(dict(episode=1,frame=frame,flow_mode='continuous_v30',supply_active=True,
            observed_actor_count=2,live_managed_actor_count=2,spawned_count=2))
    spawns=[dict(episode=1,frame=1,event='spawned',actor_id=actor,interval_kind='ordinary') for actor in (1,2)]
    return ego,traffic,spawns,flow,metadata


class ContinuousTrafficAuditTests(unittest.TestCase):
    def call(self,data):
        self.assertIsNotNone(audit,'No common-source continuous-flow audit')
        return audit.analyze_rows(*data)

    def test_actual_front_rear_and_continued_supply_witness_an_in_flow_merge(self):
        result=self.call(fixture())
        self.assertTrue(result['continuous_traffic_contract_ok'])
        self.assertEqual(result['continuous_traffic_classification_counts'],{'in_flow_merge':1})
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['first_overlap_frame'],2)
        self.assertEqual(ep['aligned_cleared_frame'],3)
        self.assertAlmostEqual(ep['insertion_duration_s'],.05)
        self.assertEqual(ep['minimum_witnessed_pair_gap_m'],8.)
        self.assertGreater(ep['minimum_front_clearance_m'],0.)
        self.assertGreater(ep['minimum_rear_clearance_m'],0.)

    def test_continuous_supply_without_a_rear_witness_stays_unknown_not_infinite_safety(self):
        data=list(fixture())
        data[1]=[row for row in data[1] if row['actor_id']==1]
        data[2]=data[2][:1]
        for row in data[3]:row.update(observed_actor_count=1,live_managed_actor_count=1,spawned_count=1)
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['classification'],'indeterminate')
        self.assertIn('rear',ep['reason'])
        self.assertIsNone(ep['minimum_rear_clearance_m'])
        self.assertIsNone(ep['minimum_witnessed_pair_gap_m'])

    def test_confirmed_finite_supply_exhaustion_and_passed_tail_are_separate(self):
        data=list(fixture())
        data[1]=[row for row in data[1] if row['actor_id']==1]
        data[2]=data[2][:1]
        data[4].update(flow_mode='finite_v30',continuous_supply=False,finite_spawn_limit=1)
        for row in data[3]:row.update(flow_mode='finite_v30',supply_active=False,
            observed_actor_count=1,live_managed_actor_count=1,spawned_count=1)
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['classification'],'after_tail_merge')
        self.assertIsNone(ep['minimum_rear_clearance_m'])

    def test_missing_common_ego_yaw_is_not_replaced_with_gtrl_only_observations(self):
        data=fixture();data[0][1].pop('ego_yaw')
        result=self.call(data)
        self.assertFalse(result['continuous_traffic_contract_ok'])
        self.assertEqual(result['continuous_traffic_episodes'][0]['classification'],'indeterminate')
        self.assertIn('ego_geometry',result['continuous_traffic_errors'])

    def test_source_actor_count_mismatch_and_missing_rv_geometry_remain_invalid(self):
        for change in ('row_missing','box_missing'):
            data=fixture()
            if change=='row_missing':data[1].pop(2)
            else:data[1][2].pop('observed_width')
            with self.subTest(change=change):
                result=self.call(data)
                self.assertFalse(result['continuous_traffic_contract_ok'])
                self.assertEqual(result['continuous_traffic_episodes'][0]['classification'],'indeterminate')

    def test_artificial_long_gap_cannot_be_certified_as_continuous_supply(self):
        data=fixture();data[2][1]['interval_kind']='long'
        result=self.call(data)
        self.assertFalse(result['continuous_traffic_contract_ok'])
        self.assertIn('artificial_long_gap',result['continuous_traffic_errors'])
        self.assertEqual(result['continuous_traffic_episodes'][0]['classification'],'indeterminate')

    def test_missing_flow_frame_is_unknown_even_when_metadata_promises_continuity(self):
        data=fixture();data[3].pop(1)
        result=self.call(data)
        self.assertFalse(result['continuous_traffic_contract_ok'])
        self.assertIn('flow_frame_coverage',result['continuous_traffic_errors'])

    def test_complete_observations_without_finished_merge_are_not_collection_failure(self):
        data=fixture()
        for row in data[0]:row['ego_y']=4.
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        self.assertEqual(result['continuous_traffic_episodes'][0]['classification'],'indeterminate')
        self.assertIn('overlap',result['continuous_traffic_episodes'][0]['reason'])

    def test_vehicle_outside_flow_strip_cannot_supply_a_rear_witness(self):
        data=fixture()
        for row in data[1]:
            if row['actor_id']==2:row['y']=10.
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['classification'],'indeterminate')
        self.assertIsNone(ep['minimum_rear_clearance_m'])

    def test_finite_queue_tail_still_overlapping_at_entry_is_not_after_tail(self):
        data=list(fixture())
        data[1]=[row for row in data[1] if row['actor_id']==1]
        data[1][1]['x']=4.5
        data[2]=data[2][:1]
        data[4].update(flow_mode='finite_v30',continuous_supply=False,finite_spawn_limit=1)
        for row in data[3]:row.update(flow_mode='finite_v30',supply_active=False,
            observed_actor_count=1,live_managed_actor_count=1,spawned_count=1)
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['classification'],'indeterminate')
        self.assertLess(ep['minimum_front_clearance_m'],0.)

    def test_intermediate_pair_does_not_replace_rear_evidence_at_merge_completion(self):
        data=list(fixture())
        data[1]=[row for row in data[1] if not (row['frame']==3 and row['actor_id']==2)]
        data[3][-1].update(observed_actor_count=1,live_managed_actor_count=1)
        result=self.call(data)
        self.assertTrue(result['continuous_traffic_contract_ok'])
        ep=result['continuous_traffic_episodes'][0]
        self.assertEqual(ep['classification'],'indeterminate')
        self.assertEqual(ep['front_rear_witness_frames'],1)
        self.assertFalse(ep['front_rear_witness_at_alignment'])

    def test_directory_api_reads_both_arms_identically_and_never_writes_input(self):
        self.assertIsNotNone(audit,'No directory audit')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);data=fixture()
            names=('interaction_ego.csv','traffic_spacing_samples.csv','traffic_spawns.csv','traffic_flow_events_v30.csv')
            for name,rows in zip(names,data[:4]):
                with (root/name).open('w',newline='',encoding='utf8') as stream:
                    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
            (root/'traffic_spacing_metadata.json').write_text(json.dumps(data[4]),encoding='utf8')
            before={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in root.iterdir()}
            result=audit.validate_continuous_traffic(root)
            self.assertTrue(result['continuous_traffic_contract_ok'])
            self.assertEqual(audit.validate_directory(root),result)
            after={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in root.iterdir()}
            self.assertEqual(before,after)


if __name__=='__main__':unittest.main()
