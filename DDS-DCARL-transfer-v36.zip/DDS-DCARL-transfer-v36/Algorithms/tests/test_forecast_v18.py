"""Curated numeric regressions, not a copy of the returned experiment data."""
import math
import contextlib
import io
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace as S
import unittest

import numpy as np

from Planning_library.forecast_v16 import predict
from Planning_library.execution_guard import clearance,select_execution


def trigger_case():
    # v17 seed5/E4/frame498 public state and optimized proceed controls.
    path = np.array([
        [4.187911,-131.993863],[3.892120,-132.373441],[3.580961,-132.740438],
        [3.255776,-133.094998],[2.917576,-133.437110],[2.567698,-133.767409],
        [2.200099,-134.077962],[1.819921,-134.372545],[1.431521,-134.656614],
        [1.023797,-134.912217],[.611099,-135.159185],[.185406,-135.383591],
        [-.245454,-135.597391],[-.684532,-135.794324],[-1.126142,-135.985293],
        [-1.572791,-136.164394],[-2.020211,-136.341474],[-2.472633,-136.505444],
        [-2.925055,-136.669414],[-3.382892,-136.817396],[-3.841857,-136.962044],
        [-4.303483,-137.097536],[-4.768483,-137.221423],[-5.233482,-137.345311]])
    public = np.array([[5.560020,-102.898003],[6.115094,-125.392553],
        [6.074210,-127.435254],[5.690837,-129.439955],[4.908854,-131.326461],
        [3.771040,-133.020183],[2.332316,-134.466837],[.636862,-135.605211],
        [-1.220489,-136.459869],[-3.139690,-137.165857],[-5.106285,-137.726230],
        [-7.109268,-138.137849],[-9.137430,-138.398416],[-11.179341,-138.511320],
        [-13.224442,-138.555650],[-19.359779,-138.687088],[-61.350143,-139.586655]])
    plan = np.array([
        [1.202609,1.125818,1.050107,.975697,.902778,.831508,.795386,.554369,
         .350997,.181798,.040721,-.079552,-.186528,-.286986,-.186176,-.085708],
        [-.284953,-.275642,-.267351,-.261781,-.258807,-.257418,-.256079,-.264105,
         -.269553,-.273192,-.276275,-.279960,-.285320,-.292548,-.295250,-.258686]])
    ego = vehicle(352,2.667722,-133.693604,-2.273539,3.478487,1.402186)
    geometry = dict(wheelbase=2.860475,max_steer=1.,execution_horizon=6.,
        forecast_model='route_v18',forecast_route=public.tolist(),navigation_end_is_stop=False)
    return ego,path,plan,np.r_[0.,np.cumsum([.05]*6+[.2]*10)],geometry,dict(a=1.280224,df=-.288998)


def vehicle(identifier,x,y,yaw,v,acc=0.):
    return S(veh_id=identifier,x=x,y=y,yaw=yaw,v=v,vx=v*math.cos(yaw),vy=v*math.sin(yaw),
             acc=acc,acc_source='velocity_difference',length=4.892382 if identifier==352 else 3.8058,
             width=1.836713 if identifier==352 else 1.970276)


class ForecastV18Tests(unittest.TestCase):
    def test_four_arm_plan_keeps_background_traffic_and_learning_settings_equal(self):
        from Tools.run_relay_validation import main
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(main(['--dry-run','--method','CG','--traffic-interaction','v17',
                '--arms','B4_rule_v17,M5_matrix_v17,B5_rule_v18,M6_matrix_v18']),0)
        configurations = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertEqual([c['DSH_FORECAST_MODEL'] for c in configurations],
                         ['route_v17','route_v17','route_v18','route_v18'])
        self.assertTrue(all(c['DSH_TRAFFIC_INTERACTION']=='v17' and c['DSH_EFE']=='0'
                            and c['DSH_WCV_BCV']=='0' for c in configurations))

    def test_journal_links_matrix_guard_and_applied_control_and_rejects_bad_metadata(self):
        from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
        from Planning_library.forecast_v18 import prediction_geometry
        from Planning_library.forecast_v16 import ForecastRecorder
        from Tools.validate_forecast_v16 import validate_forecast
        from Tools.validate_matrix_game import validate_matrix_game
        ego,path,plan,times,g,previous = trigger_case()
        g = prediction_geometry(g,g['forecast_route'],g['forecast_route'][:-1])
        rv = vehicle(357,15.124321,-137.999023,3.140871,3.48765,-.659875)
        with tempfile.TemporaryDirectory() as directory:
            game = MatrixTurnGameV18(g,directory=directory)
            game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=4.,conflict_y=-138.),4.,.846,(-21.,-138.51,-3.12))
            cs = [dict(target=0.,a=1.18,delta=-.28,solve_ok=True,prediction=None,plan=None,times=None),
                  dict(target=4.,a=plan[0,0],delta=plan[1,0],solve_ok=True,prediction=None,plan=plan,times=times)]
            selected = cs[game.choose(ego,[rv],rv,{},cs,path,previous)]
            chosen,audit = select_execution(ego,[rv],path,selected['target'],selected['a'],selected['delta'],
                previous,g,plan=selected['plan'],prediction_times=selected['times'])
            applied = dict(a_cmd=chosen['a'],delta_rad=chosen['delta'],
                           actuator_speed_target=chosen['target'],control_submit_ok=1)
            game.record(1,1,selected['a'],selected['delta'],selected['target'],audit,applied)
            ForecastRecorder(directory,g).record(1,1,audit,applied)
            row = dict(episode='1',frame='1',a_mpc=str(selected['a']),delta_mpc_rad=str(selected['delta']),
                a_cmd=str(chosen['a']),delta_rad=str(chosen['delta']),v_ref=str(chosen['target']),
                actuator_speed_target=str(chosen['target']),guard_action=audit['action'],
                mpc_audit_override=str(int(audit['override'])),guard_safe=str(int(audit['safe'])),
                mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10',ego_v=str(ego.v))
            self.assertTrue(validate_forecast(directory,[row],revision='route_v18')['forecast_contract_ok'])
            self.assertTrue(validate_matrix_game(directory,[row],'matrix_v18')['matrix_contract_ok'])
            meta_path = Path(directory)/'forecast_metadata.json'
            meta = json.loads(meta_path.read_text()); meta['candidate_conditioned'] = False
            meta_path.write_text(json.dumps(meta))
            self.assertFalse(validate_forecast(directory,[row],revision='route_v18')['forecast_contract_ok'])

    def test_a_stop_that_enters_the_band_is_not_an_admissible_safe_retreat(self):
        ego,path,plan,times,g,previous = trigger_case()
        chosen,audit = select_execution(ego,[],path,0.,-3.,plan[1,0],previous,g,
            prediction=np.zeros((7,2)),prediction_times=np.array([0.,.05]))
        self.assertFalse(audit['safe'])
        self.assertTrue(audit['unavoidable'])
        self.assertFalse(any(c['admissible'] for c in audit['candidates']))

    def test_the_existing_proceed_candidate_is_checked_when_a_stop_cannot_be_executed(self):
        ego,path,plan,times,g,previous = trigger_case()
        alternative = dict(target=4.,a=float(plan[0,0]),delta=float(plan[1,0]),
                           solve_ok=True,prediction=None,times=times,plan=plan)
        chosen,audit = select_execution(ego,[],path,0.,-3.,plan[1,0],previous,g,
            prediction=np.zeros((7,2)),prediction_times=np.array([0.,.05]),alternative=alternative)
        self.assertTrue(audit['safe'])
        self.assertEqual(chosen['action'],'clear')
        self.assertEqual(chosen['target'],4.)

    def test_all_unsafe_options_still_choose_less_collision_penetration_over_stop_admissibility(self):
        ego = vehicle(352,0.,-133.,-math.pi/2.,3.5)
        obstacle = vehicle(9,0.,-139.,math.pi,0.)
        path = [[0.,-130.],[0.,-150.]]
        g = dict(wheelbase=2.86,max_steer=1.,forecast_model='route_v18',
                 forecast_route=[[0.,-130.],[0.,-180.]],navigation_end_is_stop=False,execution_horizon=6.)
        chosen,audit = select_execution(ego,[obstacle],path,4.,1.2,0.,dict(a=0.,df=0.),g)
        self.assertTrue(audit['unavoidable'])
        self.assertFalse(audit['safe'])
        self.assertEqual(chosen['action'],'brake')

    def test_matrix_excludes_an_infeasible_stop_before_expected_payoff_selection(self):
        from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
        ego,path,plan,times,g,previous = trigger_case()
        rv = vehicle(357,15.124321,-137.999023,3.140871,3.48765,-.659875)
        game = MatrixTurnGameV18(g)
        game.prepare(ego,[rv],dict(rv_veh=rv,conflict_x=4.,conflict_y=-138.),4.,.846,(-21.,-138.51,-3.12))
        cs = [dict(target=0.,a=1.18,delta=-.28,solve_ok=True,prediction=None,plan=None,times=None),
              dict(target=4.,a=plan[0,0],delta=plan[1,0],solve_ok=True,prediction=None,plan=plan,times=times)]
        self.assertEqual(game.choose(ego,[rv],rv,{},cs,path,previous),1)
        self.assertFalse(game.last['components'][0][0]['stop_feasible'])
        self.assertFalse(game.last['components'][0][0]['admissible'])
        self.assertTrue(game.last['components'][1][0]['admissible'])

    def test_mpc_tail_transition_retains_the_proceed_candidate_at_the_returned_trigger(self):
        ego,path,plan,times,g,previous = trigger_case()
        for lag in (0.,.4):
            states,ts,d = predict(ego,path,4.,plan[0,0],plan[1,0],previous,g,
                horizon=6.,lag=lag,plan=plan,plan_times=times)
            self.assertTrue(d['valid'],d)
            self.assertEqual(ts[-1],6.)
            self.assertGreater(d['progress_m'],15.)
            self.assertLessEqual(d['max_cross_track'],2.)
            self.assertGreater(states[5,-1],3.5)

    def test_first_forecast_interval_matches_the_actual_execution_period(self):
        g = dict(wheelbase=2.86,max_steer=1.,forecast_model='route_v18',
                 forecast_route=[[0.,0.],[60.,0.]],navigation_end_is_stop=False)
        states,times,d = predict(vehicle(352,0.,0.,0.,0.),[[0.,0.],[20.,0.]],4.,2.,0.,
            dict(a=0.,df=0.),g,lag=0.)
        self.assertAlmostEqual(times[1],.05)
        self.assertAlmostEqual(states[5,1],.1)

    def test_free_slow_opponent_still_has_recovery_risk(self):
        ego = vehicle(352,0.,-130.,-math.pi/2.,2.)
        rv = vehicle(245,6.875,-138.,math.pi,1.323136)
        ts = np.arange(0.,3.01,.1)
        states = np.zeros((7,len(ts))); states[0],states[1],states[6] = ego.x,ego.y,ego.yaw
        states[1] = -130.-2.*ts
        states[5] = 2.
        # The ego enters the corridor late; no leader blocks the RV's initial
        # recovery. Bounded braking cannot undo an already overlapping cut-in.
        gap,_ = clearance(states,ts,[rv],ego,geometry={'forecast_model':'route_v18'})
        self.assertLess(gap,0.)

    def test_a_stopped_obstructed_rear_car_does_not_create_a_permanent_deadlock(self):
        ego = vehicle(352,.260464,-135.095016,-2.628698,0.)
        rv = vehicle(357,8.775781,-137.996094,3.140901,0.)
        ts = np.arange(0.,6.01,.1)
        states = np.zeros((7,len(ts))); states[0],states[1],states[6] = ego.x,ego.y,ego.yaw
        gap,_ = clearance(states,ts,[rv],ego,geometry={'forecast_model':'route_v18'})
        self.assertGreaterEqual(gap,.2)

    def test_unblocked_recovery_is_preserved_without_a_leader(self):
        from Planning_library.opponent_forecast_v18 import tracks
        rv = vehicle(357,6.875,-138.,math.pi,1.323136)
        ts = np.arange(0.,3.01,.1)
        family = tracks(rv,ts)
        self.assertLess(min(track[-1,0] for track in family),-1.25)
        self.assertGreater(max(track[-1,0] for track in family),0.)

    def test_forecast_restarts_when_the_candidate_ego_frees_the_corridor(self):
        from Planning_library.opponent_forecast_v18 import tracks
        ego = vehicle(352,0.,-138.,math.pi,0.)
        rv = vehicle(357,8.,-138.,math.pi,0.)
        ts = np.arange(0.,6.01,.1)
        stopped = np.zeros((7,len(ts))); stopped[1],stopped[6] = -138.,math.pi
        moving = stopped.copy(); moving[0] = -2.*np.maximum(ts-2.,0.)
        stationary = tracks(rv,ts,ego=ego,ego_states=stopped)
        following = tracks(rv,ts,ego=ego,ego_states=moving)
        self.assertLess(min(t[-1,0] for t in following),min(t[-1,0] for t in stationary)-2.)

    def test_late_cut_in_cannot_teleport_a_fast_rear_car_to_a_safe_stop(self):
        from Planning_library.opponent_forecast_v18 import tracks
        ego = vehicle(352,0.,-138.,math.pi,0.)
        rv = vehicle(357,4.,-138.,math.pi,4.)
        ts = np.arange(0.,1.01,.05)
        stopped = np.zeros((7,len(ts))); stopped[1],stopped[6] = -138.,math.pi
        family = tracks(rv,ts,ego=ego,ego_states=stopped)
        for track in family:
            # Even maximum 5m/s² braking travels ~1.6m before stopping.
            self.assertLess(track[-1,0],3.)
            speeds = -np.diff(track[:,0])/.05
            self.assertLessEqual(float(np.max(speeds)),4.6)
            self.assertGreaterEqual(float(np.min(np.diff(speeds)/.05)),-5.01)
            self.assertLessEqual(float(np.max(np.diff(speeds)/.05)),2.01)

    def test_unknown_actor_ids_do_not_discard_a_visible_leader(self):
        from Planning_library.opponent_forecast_v18 import tracks
        rear,front = vehicle(None,0.,-138.,math.pi,0.),vehicle(None,-8.,-138.,math.pi,0.)
        family = tracks(rear,np.arange(0.,6.01,.1),objects=[rear,front])
        self.assertGreater(min(t[-1,0] for t in family),-4.)

    def test_a_zero_duration_opponent_forecast_is_rejected(self):
        from Planning_library.opponent_forecast_v18 import tracks
        with self.assertRaises(ValueError):
            tracks(vehicle(1,0.,0.,0.,1.),[0.])


if __name__ == '__main__':
    unittest.main()
