"""Independent evidence must reject invented controls and unsupported trust."""
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest

import test_trajectory_evolution_v22 as fixtures
from Planning_library.execution_guard import select_execution
from Planning_library.trajectory_guard import execution_acceleration


class EvolutionValidationTests(unittest.TestCase):
    def validator(self):
        try:
            from Tools.validate_trajectory_evolution_v22 import validate_evolution_record
        except ImportError:
            self.fail('Independent evolution/execution audit is missing')
        return validate_evolution_record

    def evidence(self):
        runtime, old = fixtures.EvolutionRuntimeTests().fixture()
        context = runtime.context(old[1], old[4].last, old[5]['previous'], old[2][1]['target'])
        l = runtime.learner
        l.begin(context, dict(alpha=1., beta=1.), 1, 1); l.select(.75, True, forced_ratio=1.); l.start(1.)
        l.reward(1.); l.finish()
        with contextlib.redirect_stdout(io.StringIO()):
            output = runtime.propose(old[1], old[2], 1, old[4].last, old[5], False, (6., -138.))
        c = output[1]
        applied, audit = select_execution(old[1].ego_vehicle, old[1].objects,
            old[2][1]['controller'].last_pathway, c['target'],
            execution_acceleration(c['a'], old[1].ego_vehicle.v, c['target']), c['delta'],
            old[5]['previous'], runtime.geometry, prediction=c['prediction'], prediction_times=c['times'], plan=c['plan'])
        runtime.feedback(1, 1, audit, dict(control_submit_ok=1, ego_v_after=2., a_cmd=applied['a'],
            delta_rad=applied['delta'], actuator_speed_target=applied['target']))
        row = copy.deepcopy(old[4].last)
        row.update(trajectory_evolution=copy.deepcopy(runtime.last), episode=1, frame=1,
            pre_audit_a=c['a'], pre_audit_delta=c['delta'], pre_audit_target=c['target'],
            applied_a=applied['a'], applied_delta=applied['delta'], applied_target=applied['target'],
            guard_action=audit['action'], guard_override=audit['override'], guard_safe=audit['safe'], control_submit_ok=1)
        ego = dict(episode='1', frame='1', a_mpc=str(c['a']), delta_mpc_rad=str(c['delta']),
            a_cmd=str(applied['a']), delta_rad=str(applied['delta']), ego_v_after='2',
            actuator_speed_target=str(round(applied['target'], 6)), v_ref=str(round(applied['target'], 3)),
            guard_action=audit['action'], mpc_audit_override=str(int(audit['override'])),
            mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10', ego_v='2',
            a_prev=str(round(old[5]['previous']['a'], 3)), steer_prev=str(round(old[5]['previous']['df'], 3)))
        return row, ego

    def test_real_candidate_and_measured_feedback_pass_independent_audit(self):
        validate = self.validator(); row, ego = self.evidence()
        self.assertTrue(row['trajectory_evolution']['changed_request'])
        self.assertEqual(validate(row, ego, 'train'), {})

    def test_modified_target_or_unlisted_request_is_rejected(self):
        validate = self.validator(); row, ego = self.evidence()
        row['trajectory_evolution']['request']['target'] += .1
        self.assertTrue(validate(row, ego, 'train'))

    def test_feedback_cannot_be_credited_to_a_different_parameter(self):
        validate = self.validator(); row, ego = self.evidence()
        row['trajectory_evolution']['feedback']['requested_ratio'] = 1.
        self.assertIn('feedback', validate(row, ego, 'train'))

    def test_optimistic_or_fabricated_takeover_without_local_coverage_is_rejected(self):
        validate = self.validator(); row, ego = self.evidence()
        row['trajectory_evolution']['learning']['source'] = 'takeover'
        row['trajectory_evolution']['learning']['certified'] = True
        self.assertIn('unsupported_takeover', validate(row, ego, 'train'))

    def test_original_game_matrix_is_still_checked_alongside_new_control_owner(self):
        self.validator(); row, ego = self.evidence()
        from Tools.validate_matrix_game import validate_matrix_game
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'matrix_decisions.jsonl'
            path.write_text(json.dumps(row)+'\n', encoding='utf8')
            result = validate_matrix_game(d, [ego], 'matrix_v18', expected_evolution='train')
            self.assertTrue(result['matrix_contract_ok'], result)
            row['payoff_matrix'][0][0] += 1.
            path.write_text(json.dumps(row)+'\n', encoding='utf8')
            self.assertFalse(validate_matrix_game(d, [ego], 'matrix_v18', expected_evolution='train')['matrix_contract_ok'])


if __name__ == '__main__':
    unittest.main()
