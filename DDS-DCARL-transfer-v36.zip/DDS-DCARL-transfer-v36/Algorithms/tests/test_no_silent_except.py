# -*- coding: utf-8 -*-
"""左转代码规范 R5 的可执行检查：禁止静默吞异常。

背景（PLAN §42.1）：本会话**4 次**被 `except: pass` 坑，每次都是"看起来接线了、实际没跑"：
  1. ④屏蔽 `TypeError` ⇒ 屏蔽层假死 280 帧，我据此误判"屏蔽无效"
  2. `window_causal` 算了只 `print` ⇒ 式(38) 假落地
  3. 信息集填充内部 `except` ⇒ 四列全空，我误判"接线了"
  4. `_conf` NameError ⇒ **式(62)–(68) 整段静默失效 1117/1117 帧**，我据此报了错误基线

规范：**任何 try/except 必须把异常记到某个属性/日志，不允许裸 `pass`。**
本测试用 AST 扫描（不是正则，避免误判字符串/注释），对每个 `except` 块检查：
  · 若块体只有 `pass` / `...` / `continue` ⇒ **违规**
  · 若块体里有赋值（如 `self._xxx_err = ...`）/ `raise` / 函数调用 / 日志 ⇒ 合规

白名单：明确的"可忽略"位置（如析构、可选依赖探测）需在此显式登记并写明理由。
"""
import ast
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: 扫描范围（左转相关的主干模块；不含 tests）
TARGETS = [
    'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py',
    'Agent/tools_dds/LaneTrajectoryPlanner.py',
    'Planning_library/boundary_safety.py',
    'Planning_library/active_inference.py',
    'Planning_library/cournot_game.py',
    'Planning_library/game_reward.py',
    'Planning_library/information_set.py',
    'Planning_library/comfort_metrics.py',
    'Planning_library/interaction_logger.py',
    'Planning_library/define_state_space_turn.py',
    'Planning_library/trustset_dds.py',
    'Test_Scenarios/cross_traffic_manager.py',
]

#: 允许静默的白名单：`(文件, 行号)`；每条都要写理由（"无法记日志"才算数）
ALLOW = {
    # 例：('Planning_library/xxx.py', 123),   # 理由: ...
}

#: 块体里出现这些"无害语句"时仍然视为静默
_SILENT = (ast.Pass, ast.Continue, ast.Break)


def _is_silent(body):
    """块体是否等价于 `pass`（只有 Pass/Continue/Break/Ellipsis 表达式）。"""
    if not body:
        return True
    for st in body:
        if isinstance(st, _SILENT):
            continue
        if isinstance(st, ast.Expr) and isinstance(st.value, ast.Constant):
            continue          # `...` / 字符串
        return False          # 有任何"有副作用"的语句 ⇒ 不算静默
    return True


def _scan(path):
    p = os.path.join(ROOT, path)
    if not os.path.isfile(p):
        return []
    src = open(p, encoding='utf-8', errors='ignore').read()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return [('%s: 语法错误 %s' % (path, e), 0)]
    bad = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if (path, node.lineno) in ALLOW:
                continue
            if _is_silent(node.body):
                bad.append(('❌ 静默 except（块体等价 pass）', node.lineno))
            elif isinstance(node.type, ast.Name) and node.type.id == 'Exception':
                # Exception 捕获但块体里没有"记录异常"的痕迹 ⇒ 提示（不判失败）
                names = {n.id for n in ast.walk(ast.Module(body=node.body, type_ignores=[]))
                         if isinstance(n, ast.Name)}
                if not ({'_err', '_e', 'err', 'exc'} & {x for x in names}) and \
                        not any(isinstance(n, ast.Attribute) and
                                str(getattr(n, 'attr', '')).endswith('_err')
                                for n in ast.walk(ast.Module(body=node.body, type_ignores=[]))):
                    bad.append(('⚠️ except Exception 但未记录异常（建议 self._xxx_err=…）',
                                node.lineno))
    return bad


#: 【棘轮基线】历史上就存在的静默 except 数量（按文件）。
#: 规则：**不允许新增**（超出基线即失败）；修一个就把基线减一。
#: 这样 R5 立刻可执行，又不必为 33 处存量做高风险的一次性重构。
_BASELINE = {
    'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py': 17,
    'Agent/tools_dds/LaneTrajectoryPlanner.py': 0,
    'Planning_library/boundary_safety.py': 3,
    'Planning_library/active_inference.py': 0,
    'Planning_library/cournot_game.py': 0,
    'Planning_library/game_reward.py': 0,
    'Planning_library/information_set.py': 0,
    'Planning_library/comfort_metrics.py': 0,
    'Planning_library/interaction_logger.py': 6,
    'Planning_library/define_state_space_turn.py': 4,
    'Planning_library/trustset_dds.py': 0,
    'Test_Scenarios/cross_traffic_manager.py': 3,
}


def test_no_new_silent_except():
    """R5 棘轮：静默 except 数量不得超过基线（**不允许新增**）。"""
    import collections
    cnt = collections.Counter()
    warn_unlogged = []
    for t in TARGETS:
        for msg, ln in _scan(t):
            if msg.startswith('❌'):
                cnt[t] += 1
            else:
                warn_unlogged.append('%s:%s %s' % (t, ln, msg))
    print('\n--- R5 棘轮扫描 ---')
    print('%-58s %6s %8s %s' % ('文件', '当前', '基线', '判定'))
    over = []
    for t in TARGETS:
        cur, base = cnt.get(t, 0), _BASELINE.get(t, 0)
        verdict = 'OK' if cur <= base else '**超出**'
        if cur > base:
            over.append('%s: 当前 %d > 基线 %d' % (t, cur, base))
        print('%-58s %6d %8d %s' % (t, cur, base, verdict))
    print('合计 %d（基线 %d）；未记录异常的 except Exception: %d 处（建议修，不判失败）'
          % (sum(cnt.values()), sum(_BASELINE.values()), len(warn_unlogged)))
    assert not over, ('R5 违规（新增了静默 except）:\n  ' + '\n  '.join(over) +
                      '\n修法：except Exception as e: self._xxx_err = '
                      '"%%s: %%s" %% (type(e).__name__, e)，并加日志列 + 验收检查。')


def test_silent_except_detector_works():
    """自检：扫描器必须能识别 `except: pass`，且放过"记录了异常"的写法。"""
    good = ast.parse('try:\n    x=1\nexcept Exception as e:\n    self._err = str(e)\n')
    bad = ast.parse('try:\n    x=1\nexcept Exception:\n    pass\n')
    ok = ast.parse('try:\n    x=1\nexcept Exception as e:\n    print(e)\n')
    assert not _is_silent(good.body[0].handlers[0].body), '记录了异常 ⇒ 不应判静默'
    assert _is_silent(bad.body[0].handlers[0].body), 'pass ⇒ 应判静默'
    assert not _is_silent(ok.body[0].handlers[0].body), '有 print ⇒ 不算静默'


if __name__ == '__main__':
    fns = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in fns:
        fn()
        print('ok  %s' % fn.__name__)
    print('\nALL %d PASSED' % len(fns))
