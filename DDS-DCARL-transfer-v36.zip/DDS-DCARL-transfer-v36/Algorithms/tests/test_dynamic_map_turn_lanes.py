import math
import os
import sys
import types

import numpy as np

# 相对路径：Algorithms/tests -> Algorithms
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class FakeWaypoint:
    def __init__(self, road_id, lane_id, x, y, left=None, right=None):
        self.road_id = road_id
        self.lane_id = lane_id
        self.transform = types.SimpleNamespace(
            location=types.SimpleNamespace(x=x, y=y, z=0.0),
            rotation=types.SimpleNamespace(yaw=0.0),
        )
        self.lane_type = "Driving"
        self._left = left
        self._right = right

    def get_left_lane(self):
        return self._left

    def get_right_lane(self):
        return self._right

    def next(self, distance):
        return []


class FakeMap:
    def __init__(self):
        self.left_lane = FakeWaypoint(1, 2, 0.0, 0.0)
        self.right_lane = FakeWaypoint(1, 1, 0.0, 0.0)
        self.center_lane = FakeWaypoint(1, 0, 0.0, 0.0, left=self.left_lane, right=self.right_lane)
        self._topology = [(self.center_lane, self.center_lane)]

    def get_waypoint(self, location, project_to_road=True, lane_type=None):
        return self.center_lane

    def get_topology(self):
        return self._topology


class FakeWorld:
    def __init__(self):
        self._map = FakeMap()

    def get_map(self):
        return self._map


def test_left_turn_preference_prefers_left_lane_near_intersection():
    from Agent.tools_dds.LanePlanner_trans import LanePlanner

    planner = LanePlanner()
    planner.dynamic_map = types.SimpleNamespace(
        ego_vehicle=types.SimpleNamespace(x=0.0, y=-15.0, v=8.0, yaw=math.radians(-90), lane_idx=0),
        lanes=[object(), object()],
        env=types.SimpleNamespace(INTERSECTION_CENTER=(0.0, -10.0)),
    )

    assert planner._get_turn_preference_lane(0) == 1
