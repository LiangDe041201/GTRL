"""Independent numeric examples for general conditional EFE and time costs."""
import copy
import math
import unittest

import numpy as np

try:
    from Planning_library.efe_core_v27 import evaluate_efe,integrated_cost
except ImportError:
    evaluate_efe=integrated_cost=None


class EFECoreTests(unittest.TestCase):
    def score(self,z,b,p):
        self.assertIsNotNone(evaluate_efe,'No conditional EFE kernel for rolling candidates')
        return evaluate_efe(z,b,p)

    def test_hidden_outcomes_have_zero_conditional_entropy_despite_uncertain_marginal(self):
        s=self.score([[1.,0.,0.,0.],[0.,0.,0.,1.]],[.5,.5],[.25]*4)
        self.assertAlmostEqual(s['risk'],math.log(2.))
        self.assertEqual(s['ambiguity'],0.)
        self.assertAlmostEqual(s['marginal_entropy'],math.log(2.))
        self.assertAlmostEqual(s['mutual_information'],math.log(2.))
        self.assertAlmostEqual(s['normalized_efe'],.5)

    def test_same_marginal_with_noisy_conditionals_has_a_different_efe(self):
        s=self.score([[.5,0.,0.,.5],[.5,0.,0.,.5]],[.5,.5],[.25]*4)
        self.assertAlmostEqual(s['risk'],math.log(2.))
        self.assertAlmostEqual(s['ambiguity'],math.log(2.))
        self.assertAlmostEqual(s['efe'],math.log(4.))
        self.assertAlmostEqual(s['mutual_information'],0.)
        self.assertAlmostEqual(s['normalized_efe'],1.)

    def test_hidden_state_and_outcome_dimensions_are_not_hardcoded_to_six_and_four(self):
        s=self.score([[1.,0.],[0.,1.],[1.,0.]],[.25,.5,.25],[.5,.5])
        self.assertEqual(s['marginal'],[.5,.5])
        self.assertAlmostEqual(s['risk'],0.)
        self.assertEqual(s['ambiguity'],0.)
        self.assertAlmostEqual(s['normalized_efe'],0.)

    def test_known_clear_and_wait_preferences_produce_hand_derived_costs(self):
        p=[.94,.02,.03,.01]
        clear=self.score([[1.,0.,0.,0.]],[1.],p)
        wait=self.score([[0.,0.,1.,0.]],[1.],p)
        self.assertAlmostEqual(clear['efe'],-math.log(.94))
        self.assertAlmostEqual(wait['efe'],-math.log(.03))
        self.assertLess(clear['efe'],wait['efe'])
        self.assertAlmostEqual(clear['maximum_efe'],-math.log(.01))

    def test_invalid_probabilities_are_rejected_instead_of_silently_normalized(self):
        self.assertIsNotNone(evaluate_efe)
        cases=[([],[],[.5,.5]),([[1.,0.]],[.8],[.5,.5]),
               ([[.2,.2]],[1.],[.5,.5]),([[-.1,1.1]],[1.],[.5,.5]),
               ([[float('nan'),1.]],[1.],[.5,.5]),([[1.,0.]],[1.],[1.,0.]),
               ([[1.,0.]],[.5,.5],[.5,.5]),([[1.,0.]],[1.],[.2,.2,.6]),
               ([[1.,0.]],[float('inf')],[.5,.5])]
        for args in cases:
            with self.subTest(args=args),self.assertRaises(ValueError): evaluate_efe(*args)

    def test_finite_extreme_preference_does_not_overflow_or_discard_zero_mass(self):
        s=self.score([[0.,1.]],[1.],[1.,1.e-250])
        self.assertAlmostEqual(s['efe'],250.*math.log(10.))
        self.assertTrue(math.isfinite(s['normalized_efe']))
        self.assertAlmostEqual(s['normalized_efe'],1.)

    def test_evaluation_does_not_mutate_the_belief_or_conditionals(self):
        z=np.array([[1.,0.],[0.,1.]]); b=np.array([.4,.6]); p=np.array([.5,.5])
        original=copy.deepcopy((z,b,p)); self.score(z,b,p)
        for a,v in zip((z,b,p),original): np.testing.assert_array_equal(a,v)

    def test_cost_integral_is_invariant_to_control_frame_rate(self):
        self.assertIsNotNone(integrated_cost,'No simulation-time cost integration')
        s=self.score([[.5,.5]],[1.],[.5,.5])
        self.assertAlmostEqual(sum(integrated_cost(s,.05) for _ in range(20)),1.)
        self.assertAlmostEqual(sum(integrated_cost(s,.1) for _ in range(10)),1.)
        for dt in (0.,-1.,float('nan')):
            with self.assertRaises(ValueError): integrated_cost(s,dt)


if __name__=='__main__': unittest.main()
