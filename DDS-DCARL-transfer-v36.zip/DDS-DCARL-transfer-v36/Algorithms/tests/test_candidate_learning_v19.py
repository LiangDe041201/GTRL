"""Behavioral checks of candidate learning; no CARLA connection required."""
import copy
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace as S
import unittest

import numpy as np

from Planning_library.soft_bellman import BeliefSoftLearner


class CandidateLearningTests(unittest.TestCase):
    def api(self):
        try:
            from Planning_library import candidate_learning_v19 as api
        except ImportError:
            self.fail('The common-candidate learning interface has not been implemented')
        return api

    def test_joint_state_ambiguity_does_not_include_intention_mixture_entropy(self):
        api = self.api()
        conditional = np.array([[1.,0.,0.,0.], [0.,1.,0.,0.]]*3)
        r = api.joint_efe(conditional, np.ones(6)/6.)
        self.assertAlmostEqual(r['ambiguity'], 0.)
        self.assertAlmostEqual(r['marginal'][0], .5)
        self.assertAlmostEqual(r['marginal'][1], .5)
        self.assertAlmostEqual(r['reward'], -r['risk']-r['ambiguity'])

    def test_collision_probability_is_not_hidden_by_a_stalled_candidate(self):
        api = self.api()
        p = api.outcome_distribution(dict(min_gap=-2., forecast_valid=True,
            forecasts=[dict(min_standoff=4.,progress_m=0.)]), 4.)
        self.assertGreater(p[3], .999)
        self.assertLess(p[2], .001)

    def test_guard_clearance_field_is_not_mistaken_for_an_absent_opponent(self):
        api=self.api()
        p=api.outcome_distribution(dict(gap=-2.,forecast_valid=True,
            forecasts=[dict(min_standoff=1.,progress_m=1.)]),1.)
        self.assertGreater(p[3],.999)

    def test_same_candidate_forecasts_supply_both_intention_columns(self):
        api = self.api()
        clear = dict(min_gap=2., forecast_valid=True,
                     forecasts=[dict(min_standoff=-5.,progress_m=15.)])
        blocked = dict(min_gap=-2.,forecast_valid=True,
                       forecasts=[dict(min_standoff=1.,progress_m=1.)])
        result = api.candidate_efe([[clear,blocked],[clear,clear]],np.ones(6)/6.,4.)
        self.assertEqual(np.asarray(result[0]['conditional']).shape,(6,4))
        self.assertGreater(result[0]['risk'],result[1]['risk'])
        self.assertGreater(result[0]['conditional'][0][3],.999)  # state0=yield -> column1
        self.assertGreater(result[0]['conditional'][1][0],.99)   # state1=rush -> column0

    def test_belief_transition_uses_elapsed_seconds_and_has_no_candidate_side_effect(self):
        api = self.api()
        filter_ = api.CandidateBelief()
        half = filter_.transition(.5,.5)
        full = filter_.transition(.5,1.)
        np.testing.assert_allclose(half.dot(half),full,atol=1e-12)
        for i in range(6):
            self.assertEqual(sum(full[i,j] for j in range(6) if j//2 != i//2),0.)
        b = filter_.update(7,0,.5,.05)
        before = b.copy()
        filter_.predicted(7,.5,6.)
        np.testing.assert_array_equal(filter_.vector(7),before)
        # Candidate evaluation must never enqueue an action for future inference.
        self.assertFalse(filter_.pending)

    def test_following_brake_is_not_an_independent_yield_observation(self):
        api = self.api()
        f = api.CandidateBelief()
        result = f.update(8,0,.5,.05,following=True)
        np.testing.assert_allclose(result,np.ones(6)/6.)
        self.assertIsNone(f.last_evidence)

    def test_paper_gate_chooses_largest_wcv_without_soft_resampling(self):
        api = self.api()
        learner = api.CandidateLearner(alpha=1000.,range_fallback=1000.)
        context = np.zeros(len(learner.CONTEXT_WIDTHS))
        for episode in range(20):
            learner.begin(context,np.ones(6)/6.,0,[0,1],episode)
            a = episode%2
            learner.select(explore_action=a)
            learner.start_action(a)
            learner.record_reward(float(a)*1000.)
            learner.finish()
        learner.begin(context,np.ones(6)/6.,0,[0,1],21)
        a,_ = learner.select(rng=np.random.RandomState(1))
        self.assertEqual(a,1)
        self.assertEqual(learner.last['selection_rule'],'paper_wcv')

    def test_guard_intervention_is_kept_as_a_guarded_request_outcome(self):
        api = self.api()
        learner = api.CandidateLearner()
        c = np.zeros(len(learner.CONTEXT_WIDTHS))
        learner.begin(c,np.ones(6)/6.,0,[0,1],1)
        learner.select(explore_action=1);learner.start_action(1)
        learner.record_reward(2.)
        learner.record_reward(-10.,forced=True)
        learner.finish()
        self.assertEqual(len(learner.records),1)
        self.assertEqual(learner.records[0]['action'],1)
        self.assertEqual(learner.records[0]['intervention_steps'],1)
        self.assertLess(learner.records[0]['reward'],0.)

    def test_frozen_evaluation_never_updates_or_overwrites_checkpoint(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as directory:
            learner = api.CandidateLearner(out_dir=directory)
            c = np.zeros(len(learner.CONTEXT_WIDTHS))
            learner.begin(c,np.ones(6)/6.,0,[0,1],1)
            learner.select(explore_action=0);learner.start_action(0)
            learner.record_reward(1.);learner.finish()
            checkpoint = Path(directory)/'belief_soft_model.json'
            original = checkpoint.read_bytes()
            frozen = api.CandidateLearner(phase='eval',checkpoint=checkpoint)
            q,records,sweeps = copy.deepcopy(frozen.q),copy.deepcopy(frozen.records),frozen.sweeps
            frozen.begin(c,np.ones(6)/6.,0,[0,1],2)
            frozen.select();frozen.start_action(0);frozen.record_reward(-999.,forced=True);frozen.finish()
            self.assertEqual(frozen.records,records)
            self.assertEqual(frozen.sweeps,sweeps)
            for key in q: np.testing.assert_array_equal(frozen.q[key],q[key])
            self.assertEqual(checkpoint.read_bytes(),original)

    def test_unseen_eval_state_uses_cg_instead_of_untrained_optimism(self):
        api = self.api()
        with tempfile.TemporaryDirectory() as directory:
            trained = api.CandidateLearner(out_dir=directory);trained.save()
            frozen = api.CandidateLearner(phase='eval',checkpoint=Path(directory)/'belief_soft_model.json')
            frozen.begin(np.zeros(len(frozen.CONTEXT_WIDTHS)),np.ones(6)/6.,1,[0,1],1)
            action,_ = frozen.select()
            self.assertEqual(action,1)
            self.assertTrue(frozen.last['unseen_state'])

    def test_gamma_is_defined_in_seconds_and_terminal_reward_is_once(self):
        api = self.api()
        gamma = api.frame_discount(10.,.05)
        self.assertAlmostEqual(gamma**200,.5)
        applied = dict(ego_v_after=3.,a_cmd=0.,delta_rad=0.)
        regular = api.task_reward(applied,.05)
        collision = api.task_reward(applied,.05,'collision')
        self.assertAlmostEqual(collision-regular,-10.)
        self.assertGreater(api.task_reward(applied,.05,'complete'),regular)

    def test_passive_single_candidate_state_never_queries_an_unavailable_action(self):
        api = self.api()
        learner = api.CandidateLearner()
        learner.begin(np.zeros(len(learner.CONTEXT_WIDTHS)),np.ones(6)/6.,1,[1],1)
        action,_ = learner.select()
        self.assertEqual(action,1)
        self.assertEqual(learner.last['behavior_policy'],[0.,1.])

    def test_local_empirical_interval_is_declared_and_can_detect_small_repeatable_gain(self):
        api=self.api()
        learner=api.CandidateLearner(range_fallback=1000.)
        c=np.zeros(len(learner.CONTEXT_WIDTHS))
        for episode in range(20):
            learner.begin(c,np.ones(6)/6.,0,[0,1],episode)
            a=episode%2;learner.select(explore_action=a);learner.start_action(a)
            learner.record_reward(.1*a);learner.finish()
        learner.begin(c,np.ones(6)/6.,0,[0,1],21)
        action,_=learner.select()
        self.assertEqual(action,1)
        self.assertEqual(learner.last['range_mode'],'local_empirical')
        self.assertFalse(learner.last['confidence_guarantee'])

    def test_training_coverage_exploration_is_explicit_in_the_behavior_distribution(self):
        api=self.api()
        learner=api.CandidateLearner()
        learner.begin(np.zeros(len(learner.CONTEXT_WIDTHS)),np.ones(6)/6.,0,[0,1],1)
        learner.select(epsilon=.1,rng=np.random.RandomState(1))
        self.assertEqual(learner.last['epsilon'],.5)
        self.assertEqual(learner.last['behavior_policy'],[.75,.25])


class MatrixIntegrationTests(unittest.TestCase):
    def game_type(self):
        try:
            from Planning_library.matrix_turn_game_v19 import MatrixTurnGameV19
        except ImportError:
            self.fail('The v18 candidate/learning integration has not been implemented')
        return MatrixTurnGameV19

    def fixture(self):
        from test_forecast_v18 import trigger_case,vehicle
        ego,path,plan,times,g,previous = trigger_case()
        rv=vehicle(357,25.,-138.,np.pi,3.)
        cs=[dict(target=2.,a=-.5,delta=plan[1,0],solve_ok=True,prediction=None,plan=None,times=None),
            dict(target=4.,a=plan[0,0],delta=plan[1,0],solve_ok=True,prediction=None,plan=plan,times=times)]
        conf=dict(rv_veh=rv,conflict_x=4.,conflict_y=-138.)
        return ego,path,g,previous,rv,cs,conf

    def test_learning_off_preserves_actual_v18_candidate_scores_and_choice(self):
        from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
        Type=self.game_type()
        ego,path,g,u,rv,cs,conf=self.fixture()
        old,new=MatrixTurnGameV18(g),Type(g,learning_phase='off')
        for game in (old,new):
            game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        a=old.choose(ego,[rv],rv,conf,cs,path,u)
        b=new.choose(ego,[rv],rv,conf,cs,path,u)
        self.assertEqual(a,b)
        np.testing.assert_array_equal(old.last['payoff_matrix'],new.last['payoff_matrix'])
        self.assertIsNone(new.learner)

    def test_learning_choice_reaches_the_same_mpc_candidate_selector(self):
        Type=self.game_type()
        ego,path,g,u,rv,cs,conf=self.fixture()
        game=Type(g,epsilon=1.,decision_period=.05,seed=1)
        changed=[]
        for frame in range(5):
            game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
            selected=game.choose(ego,[rv],rv,conf,cs,path,u)
            self.assertEqual(selected,game.last['selected'])
            changed.append(selected!=game.last['baseline_selected'])
            audit=dict(override=False,unavoidable=False,action='mpc',safe=True,
                       candidates=[dict(action='mpc',target=cs[selected]['target'],
                           a=cs[selected]['a'],delta=cs[selected]['delta'])])
            applied=dict(a_cmd=cs[selected]['a'],delta_rad=cs[selected]['delta'],
                actuator_speed_target=cs[selected]['target'],ego_v_after=ego.v,control_submit_ok=1)
            game.feedback(1,frame,audit,applied)
        self.assertTrue(any(changed),'Learning requests were calculated but never reached candidate selection')

    def test_guarded_failure_has_actual_execution_and_uncensored_terminal_credit(self):
        Type=self.game_type()
        ego,path,g,u,rv,cs,conf=self.fixture()
        game=Type(g,epsilon=0.)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        requested=game.choose(ego,[rv],rv,conf,cs,path,u)
        audit=dict(override=True,unavoidable=False,action='brake',safe=True,
            candidates=[dict(action='brake',target=0.,a=-2.,delta=0.,gap=1.,
                forecast_valid=True,forecasts=[dict(min_standoff=1.,progress_m=1.)])])
        applied=dict(a_cmd=-2.,delta_rad=0.,actuator_speed_target=0.,ego_v_after=.1,control_submit_ok=1)
        game.feedback(1,1,audit,applied,outcome='collision')
        self.assertEqual(game.last['learning']['executed_target'],0.)
        self.assertEqual(game.last['learning']['requested'],requested)
        self.assertFalse(game.belief.pending)
        self.assertEqual(len(game.learner.records),1)
        self.assertGreater(game.learner.records[0]['intervention_steps'],0)
        self.assertLess(game.learner.records[0]['reward'],-9.)

    def journal(self,directory):
        Type=self.game_type()
        ego,path,g,u,rv,cs,conf=self.fixture()
        game=Type(g,directory=directory,epsilon=0.)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        a=game.choose(ego,[rv],rv,conf,cs,path,u)
        audit=dict(override=False,unavoidable=False,action='mpc',safe=True,
                   candidates=[dict(action='mpc')])
        applied=dict(a_cmd=cs[a]['a'],delta_rad=cs[a]['delta'],
            actuator_speed_target=cs[a]['target'],ego_v_after=ego.v,control_submit_ok=1)
        game.feedback(1,1,audit,applied,'complete')
        game.record(1,1,cs[a]['a'],cs[a]['delta'],cs[a]['target'],audit,applied)
        ego_row=dict(episode='1',frame='1',a_mpc=str(cs[a]['a']),delta_mpc_rad=str(cs[a]['delta']),
            a_cmd=str(applied['a_cmd']),delta_rad=str(applied['delta_rad']),
            actuator_speed_target=str(applied['actuator_speed_target']),v_ref=str(cs[a]['target']),
            guard_action='mpc',mpc_audit_override='0',mpc_game_enabled='0',rl_active='0',
            mpc_solve_ms='10',ego_v=str(ego.v))
        return [ego_row]

    def validator(self):
        try:
            from Tools.validate_candidate_learning_v19 import validate_candidate_learning
        except ImportError:self.fail('There is no independent validator of candidate learning evidence')
        return validate_candidate_learning

    def test_actual_journal_and_independent_payoff_audit_pass_and_detect_rewritten_control(self):
        validate=self.validator()
        from Tools.validate_matrix_game import validate_matrix_game
        with tempfile.TemporaryDirectory() as d:
            rows=self.journal(d)
            self.assertTrue(validate(d,rows)['learning_mechanisms_ok'])
            self.assertTrue(validate_matrix_game(d,rows,'matrix_v19')['matrix_contract_ok'])
            rows[0]['a_cmd']='-99'
            self.assertFalse(validate(d,rows)['learning_mechanisms_ok'])

    def test_rewriting_the_efe_breakdown_cannot_pass_an_enabled_flag(self):
        validate=self.validator()
        with tempfile.TemporaryDirectory() as d:
            rows=self.journal(d)
            p=Path(d)/'candidate_learning.jsonl'
            r=json.loads(p.read_text());r['efe'][0]['risk']+=.5
            p.write_text(json.dumps(r),encoding='utf8')
            self.assertFalse(validate(d,rows)['learning_mechanisms_ok'])

    def test_a_heuristic_interval_cannot_be_relabelled_as_a_confidence_guarantee(self):
        validate=self.validator()
        with tempfile.TemporaryDirectory() as d:
            rows=self.journal(d)
            p=Path(d)/'candidate_learning.jsonl'
            r=json.loads(p.read_text());r['confidence_guarantee']=True
            p.write_text(json.dumps(r),encoding='utf8')
            self.assertFalse(validate(d,rows)['learning_mechanisms_ok'])

    def test_efe_ablation_changes_only_one_reward_term_at_the_same_actual_control(self):
        Type=self.game_type()
        ego,path,g,u,rv,cs,conf=self.fixture()
        rewards=[]
        for enabled in (False,True):
            game=Type(g,epsilon=0.,efe_enabled=enabled)
            game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
            a=game.choose(ego,[rv],rv,conf,cs,path,u)
            audit=dict(override=False,unavoidable=False,action='mpc',safe=True,candidates=[])
            applied=dict(a_cmd=cs[a]['a'],delta_rad=cs[a]['delta'],
                actuator_speed_target=cs[a]['target'],ego_v_after=ego.v,control_submit_ok=1)
            game.feedback(1,1,audit,applied)
            rewards.append(game.last['learning'])
        self.assertEqual(rewards[0]['requested'],rewards[1]['requested'])
        self.assertEqual(rewards[0]['task_reward'],rewards[1]['task_reward'])
        self.assertAlmostEqual(rewards[1]['reward']-rewards[0]['reward'],
                               -.1*.05*rewards[1]['realized_efe'])

    def test_invalid_calibration_preferences_are_rejected_instead_of_silently_clipped(self):
        Type=self.game_type()
        _,_,g,_,_,_,_=self.fixture()
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'invalid.json'
            p.write_text(json.dumps(dict(preference=[.94,.02,.05,-.01])),encoding='utf8')
            with self.assertRaises(ValueError):Type(g,belief_model=p)


if __name__=='__main__':
    unittest.main()
