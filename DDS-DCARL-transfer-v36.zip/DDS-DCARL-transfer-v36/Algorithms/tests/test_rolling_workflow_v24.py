"""The remote pilot must stop before long training if no new path executes."""
import contextlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import test_trajectory_workflow_v21 as old_fixtures


class RollingWorkflowTests(unittest.TestCase):
    def workflow(self):
        try: return importlib.import_module('Tools.run_rolling_validation_v24')
        except ImportError: self.fail('Remote rolling learning protocol is missing')

    def boundary(self,cmd,changed=True):
        root=Path(cmd[cmd.index('--output-root')+1])
        result=old_fixtures.TrajectoryWorkflowTests().run_fixture(root,cmd)
        for directory in root.glob('T*_seed*'):
            file=directory/'result.json'; data=json.loads(file.read_text())
            observe=directory.name.startswith('T0')
            data.update(rolling_contract_ok=True,rolling_experience_contract_ok=True,
                rolling_counts=dict(rows=4,decisions=2,changed_requests=int(changed and not observe),
                    transition_records=2,covered_state_action_pairs=0,replanning_events=2),
                rolling_actual_actions={'0':4 if observe or not changed else 3,'1':int(changed and not observe)})
            file.write_text(json.dumps(data),encoding='utf8')
            if directory.name.startswith('T2'):
                model=directory/'rolling_model/rolling_model.json'; model.parent.mkdir()
                model.write_text('{}',encoding='utf8')
        return result

    def test_plan_separates_identity_probe_training_and_unseen_seed_frozen_eval(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            plan=w.build_plan(Path(t)/'new')
            self.assertEqual([s['episodes_total'] for s in plan],[4,8,12,6])
            self.assertEqual(plan[1]['arms'],['T1_fixed_v24','T2_train_v24'])
            self.assertEqual(plan[-1]['arms'],['M6_matrix_v18','T1_fixed_v24','T3_eval_v24'])
            self.assertEqual(plan[-1]['seeds'],[81])
            self.assertIn('--rolling-checkpoint',plan[-1]['arguments'])

    def test_all_rejected_proposals_stop_before_training_but_preserve_failed_archive(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd,False)),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(output)])
            self.assertNotEqual(code,0)
            self.assertFalse((output/'02_train').exists())
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())
            report=json.loads((output/'ROLLING_REPORT.json').read_text())
            self.assertFalse(report['spatial_execution_observed'])
            self.assertFalse(report['benefit_established'])

    def test_complete_protocol_keeps_model_frozen_and_does_not_claim_benefit(self):
        w=self.workflow()
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'result'
            with patch.object(w.subprocess,'run',side_effect=lambda cmd,**kw:self.boundary(cmd)),contextlib.redirect_stdout(io.StringIO()):
                code=w.main(['--output-root',str(output)])
            self.assertEqual(code,0)
            report=json.loads((output/'ROLLING_REPORT.json').read_text())
            self.assertEqual(report['actual_episodes'],30)
            self.assertTrue(report['spatial_execution_observed'])
            self.assertFalse(report['benefit_established'])
            self.assertFalse(report['efe_enabled'])
            self.assertTrue(report['frozen_checkpoint_unchanged'])
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())


if __name__=='__main__': unittest.main()
