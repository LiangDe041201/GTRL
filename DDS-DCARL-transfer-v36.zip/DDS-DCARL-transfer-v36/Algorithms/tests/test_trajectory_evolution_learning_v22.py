"""Real return-driven mutation, recursive credit and conservative evaluation."""
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np

try:
    from Planning_library.trajectory_evolution_learning_v22 import EvolutionLearner
except ImportError:
    EvolutionLearner = None


class EvolutionLearningTests(unittest.TestCase):
    def learner(self, **kwargs):
        self.assertIsNotNone(EvolutionLearner, 'Trajectory parameter learner is missing')
        return EvolutionLearner(**kwargs)

    def context(self, speed=2.):
        return [12., speed, 3., 20., 0., 4., 0., 15., 4., 0., 0., 0., 0., 0., 1., 1.]

    def sample(self, learner, ratio, reward, episode, context=None):
        learner.begin(self.context() if context is None else context, dict(alpha=1., beta=1.), 0, episode)
        selected = learner.select(ratio, True, forced_ratio=ratio)
        learner.start(selected)
        learner.reward(reward, intervention=False)
        learner.finish()

    def test_observed_better_ratio_produces_a_new_parameter_not_only_fixed_point_75(self):
        l = self.learner()
        for episode in range(1, 5):
            self.sample(l, 1. if episode % 2 else .75, 1. if episode % 2 else 5., episode)
        l.begin(self.context(), dict(alpha=1., beta=1.), 0, 5)
        p = l.propose()
        self.assertEqual(p['parent'], .75)
        self.assertEqual(p['ratio'], .85)
        self.assertEqual(p['source'], 'return_driven_mutation')

    def test_unexecuted_proposal_is_not_added_as_real_experience(self):
        l = self.learner()
        l.begin(self.context(), dict(alpha=1., beta=1.), 0, 1)
        self.assertEqual(l.select(.75, False, forced_ratio=None, epsilon=1.), 1.)
        l.start(1.)
        l.reward(2.)
        l.finish()
        self.assertEqual([r['ratio'] for r in l.records], [1.])

    def test_recursive_backup_uses_actual_elapsed_steps(self):
        l = self.learner(gamma=.5)
        first = l.begin(self.context(), dict(alpha=1., beta=1.), 0, 1)
        l.select(.75, True, forced_ratio=.75); l.start(.75)
        l.reward(1.); l.reward(2.)
        second = l.begin(self.context(speed=4.), dict(alpha=1., beta=1.), 0, 1)
        l.select(.75, True, forced_ratio=1.); l.start(1.)
        l.reward(4.); l.finish()
        # r(first)=1+.5*2=2; continuation=.5**2, V(second) includes its fixed prior.
        self.assertEqual(l.records[0]['reward'], 2.)
        self.assertEqual(l.records[0]['discount'], .25)
        self.assertEqual(l.records[0]['next'], second)
        self.assertGreater(l.q[first][l.index(.75)], 2.)
        self.assertLessEqual(l.q[first][l.index(.75)], 3.)

    def test_same_episode_frames_do_not_inflate_confidence_coverage(self):
        l = self.learner()
        for _ in range(12):
            self.sample(l, .75, 3., 7)
        l.begin(self.context(), dict(alpha=1., beta=1.), 0, 8)
        self.assertEqual(l.bounds(.75)['n'], 1)

    def test_guard_intervention_and_failure_stay_with_the_requested_parameter(self):
        l = self.learner()
        l.begin(self.context(), dict(alpha=1., beta=1.), 0, 1)
        l.select(.75, True, forced_ratio=.75); l.start(.75)
        l.reward(-10., intervention=True); l.finish()
        self.assertEqual(l.records[0]['ratio'], .75)
        self.assertEqual(l.records[0]['interventions'], 1)
        self.assertEqual(l.q[l.records[0]['state']][l.index(.75)], -10.)

    def test_optimistic_q_alone_cannot_bypass_wcv_or_executable_qualification(self):
        l = self.learner(phase='observe')
        l.begin(self.context(), dict(alpha=1., beta=1.), 0, 1)
        l.q[l.current][l.index(.75)] = 100.
        self.assertEqual(l.select(.75, True), 1.)
        self.assertEqual(l.select(.75, False), 1.)

    def test_frozen_evaluation_can_select_supported_improvement_without_changing_model(self):
        l = self.learner()
        for n in range(1, 21):
            self.sample(l, .75 if n % 2 else 1., 5. if n % 2 else 1., n)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'model.json'; l.save(path)
            before = path.read_bytes()
            frozen = self.learner(phase='eval', checkpoint=path)
            frozen.begin(self.context(), dict(alpha=1., beta=1.), 0, 21)
            self.assertEqual(frozen.select(.75, True), .75)
            frozen.start(.75); frozen.reward(-10., intervention=True); frozen.finish()
            self.assertEqual(len(frozen.records), 20)
            self.assertEqual(path.read_bytes(), before)
            self.assertNotEqual(frozen.propose()['source'], 'return_driven_mutation')

    def test_checkpoint_signature_rejects_old_action_semantics(self):
        l = self.learner()
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'model.json'; l.save(path)
            data = json.loads(path.read_text(encoding='utf8'))
            data['signature']['schema'] = 'executable_candidate_soft_v20'
            path.write_text(json.dumps(data), encoding='utf8')
            with self.assertRaises(ValueError):
                self.learner(phase='eval', checkpoint=path)

    def test_equal_coverage_exploration_does_not_always_prefer_the_first_default(self):
        l = self.learner()
        rng = np.random.RandomState(4)
        choices = set()
        for episode in range(1, 17):
            l.begin(self.context(), dict(alpha=1., beta=1.), 0, episode)
            choices.add(l.select(.75, True, epsilon=1., rng=rng))
        self.assertEqual(choices, {1., .75})

    def test_equal_beta_means_with_different_uncertainty_are_distinct_belief_states(self):
        l = self.learner()
        try:
            first = l.begin(self.context(), dict(alpha=1., beta=1.), 0, 1)
            second = l.begin(self.context(), dict(alpha=50., beta=50.), 0, 1)
        except TypeError:
            self.fail('Learning still accepts only a posterior mean and discards uncertainty')
        self.assertNotEqual(first, second)
        l.select(.75, True, forced_ratio=1.); l.start(1.); l.reward(2.); l.finish()
        self.assertEqual(l.records[-1]['belief'], dict(alpha=50., beta=50.))

    def test_explicitly_zero_training_exploration_keeps_an_untrusted_default(self):
        l = self.learner()
        choices = set()
        rng = np.random.RandomState(4)
        for episode in range(1, 17):
            l.begin(self.context(), dict(alpha=1., beta=1.), 0, episode)
            choices.add(l.select(.75, True, epsilon=0., rng=rng))
        self.assertEqual(choices, {1.})


if __name__ == '__main__':
    unittest.main()
