"""Consumer-level regression: an inserted ego must become a real leader."""
import os
import unittest
from unittest.mock import patch

from test_cross_traffic_manager import (DummyWorld, DummyMap, DummySpawnedVehicle,
    carla_stub, load_module)


def actor(identifier, x, y=-138., speed=0.):
    result = DummySpawnedVehicle(identifier, carla_stub.Transform(
        carla_stub.Location(x=x, y=y), carla_stub.Rotation(yaw=180.)))
    result.set_target_velocity(carla_stub.Vector3D(x=-speed))
    return result


class TrafficFollowingV17Tests(unittest.TestCase):
    def test_following_audit_detects_missing_or_contradictory_leader(self):
        from Tools.validate_traffic_spacing import validate_following_rows
        _, row = self.step(actor(239, -9.757, speed=.281),
                           actor(245, -5.342, speed=4.3548), actor(244, -41.161, speed=4.41))
        self.assertTrue(validate_following_rows([row])['traffic_following_contract_ok'])
        self.assertFalse(validate_following_rows([dict(row, following_leader_id=245)])['traffic_following_contract_ok'])
        self.assertFalse(validate_following_rows([dict(row, following_gap=None)])['traffic_following_contract_ok'])

    def step(self, ego, follower, leader, revision='v17'):
        world = DummyWorld()
        world.get_actors = lambda ids=None: [v for v in (follower, leader)
                                             if ids is None or v.id in ids]
        with patch.dict(os.environ, {'DSH_TRAFFIC_INTERACTION': revision}):
            manager = load_module().CrossTrafficManager(world, DummyMap(), traffic_v=6.)
        manager.managed_ids = [follower.id, leader.id]
        manager._max_vehicles = 2
        manager._spawned_count = 2
        rows = []
        manager._record_spacing = lambda name, values: rows.append(values)
        manager.run_step(ego)
        return manager, next(row for row in rows if row['actor_id'] == follower.id)

    def test_returned_rear_car_brakes_for_inserted_ego(self):
        # v16 seed5/E4: actor245 saw background leader244 32m away while
        # stopped ego239 was between them. It incorrectly recovered to cruise.
        ego = actor(239, -9.757, y=-138.229, speed=.281)
        follower = actor(245, -5.342, speed=4.3548)
        leader = actor(244, -41.161, speed=4.41)
        _, row = self.step(ego, follower, leader)
        self.assertLess(row['commanded_speed'], row['observed_speed'])
        self.assertEqual(row['following_leader_id'], 239)
        self.assertEqual(row['following_leader_role'], 'ego')
        # Keep birth/density measurements about background traffic unchanged.
        self.assertEqual(row['leader_id'], 244)
        self.assertGreater(row['actual_clear_gap'], 30.)

    def test_nonoverlapping_approach_ego_is_not_a_leader(self):
        _, row = self.step(actor(239, -9., y=-134.),
                           actor(245, -5., speed=2.), actor(244, -41., speed=4.))
        self.assertGreaterEqual(row['commanded_speed'], 2.)
        self.assertEqual(row['following_leader_role'], 'background')

    def test_legacy_control_is_preserved(self):
        _, row = self.step(actor(239, -9.757, speed=.281),
                           actor(245, -5.342, speed=4.3548), actor(244, -41.161, speed=4.41),
                           revision='legacy')
        self.assertGreaterEqual(row['commanded_speed'], row['observed_speed'])

    def test_nominal_five_metre_stream_does_not_slow_without_a_cut_in(self):
        cruise = 4.412022451715821
        _, row = self.step(actor(239, -9., y=-134.), actor(245, -5., speed=cruise),
                           actor(244, -13.6, speed=cruise))
        self.assertAlmostEqual(row['commanded_speed'], cruise, places=6)

    def test_follower_can_stop_behind_stationary_ego(self):
        ego, follower, leader = actor(239, -15.), actor(245, -3., speed=4.), actor(244, -45.)
        manager, row = self.step(ego, follower, leader)
        for _ in range(240):
            follower.transform.location.x += follower.velocity.x*.05
            manager.run_step(ego)
            self.assertGreater(follower.get_location().x-ego.get_location().x-3.6, 0.)
        self.assertLess(abs(follower.velocity.x), .1)


if __name__ == '__main__':
    unittest.main()
