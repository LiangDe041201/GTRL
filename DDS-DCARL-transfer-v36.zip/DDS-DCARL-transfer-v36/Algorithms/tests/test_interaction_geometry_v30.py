"""Common CG/GTRL body observations must remain measured, aligned CSV fields."""
import csv
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from Planning_library.interaction_logger import InteractionLogger


class InteractionGeometryV30Tests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix='ilog_geometry_v30_')
        self.addCleanup(self.directory.cleanup)
        self.logger = InteractionLogger(self.directory.name, enabled=True)
        self.addCleanup(self.logger.close)
        self.logger.begin_episode(1)

    def rows(self):
        with (Path(self.directory.name)/'interaction_ego.csv').open(newline='', encoding='utf8') as stream:
            return list(csv.DictReader(stream))

    def test_body_fields_use_same_observation_and_full_dimensions(self):
        ego = SimpleNamespace(x=4.125, y=-135.875, v=3.25,
                              yaw=-2.123456789, boxx=4.892381668, boxy=1.836713314)
        self.logger.tick()
        self.logger.ego_row(ego=ego, action=0)
        ego.x, ego.y, ego.yaw = 3.75, -136.125, -2.25
        self.logger.tick()
        self.logger.ego_row(ego=ego, action=4)
        rows = self.rows()
        self.assertEqual(len(rows), 2)
        self.assertIsNone(rows[0].get(None), 'Appended geometry must not shift existing values')
        self.assertEqual(float(rows[0]['ego_x']), 4.125)
        self.assertEqual(float(rows[0]['ego_y']), -135.875)
        self.assertEqual(float(rows[0].get('ego_yaw', 'nan')), -2.123457)
        self.assertEqual(float(rows[0].get('ego_length', 'nan')), 4.892382)
        self.assertEqual(float(rows[0].get('ego_width', 'nan')), 1.836713)
        self.assertEqual(float(rows[1]['ego_x']), 3.75)
        self.assertEqual(float(rows[1]['ego_yaw']), -2.25)
        self.assertEqual(rows[0]['action'], '0')
        self.assertEqual(rows[1]['action'], '4')

    def test_absent_body_observation_stays_missing(self):
        self.logger.ego_row(ego=SimpleNamespace(x=1., y=2., v=0.))
        self.logger.ego_row(ego=None)
        for row in self.rows():
            for key in ('ego_yaw', 'ego_length', 'ego_width'):
                self.assertIn(key, row)
                self.assertEqual(row[key], '', 'Missing geometry must not become a fabricated default')

    def test_nonfinite_or_nonpositive_geometry_stays_missing(self):
        for yaw, length, width in ((math.nan, -1., 0.), (math.inf, math.inf, math.nan),
                                   ('invalid', None, 'invalid'), (True, True, False)):
            self.logger.ego_row(ego=SimpleNamespace(x=1., y=2., v=0.,
                                                   yaw=yaw, boxx=length, boxy=width))
        for row in self.rows():
            for key in ('ego_yaw', 'ego_length', 'ego_width'):
                self.assertIn(key, row)
                self.assertEqual(row[key], '')

    def test_valid_zero_yaw_and_valid_dimensions_remain_independent(self):
        self.logger.ego_row(ego=SimpleNamespace(x=0., y=0., v=0.,
                                               yaw=0., boxx=-1., boxy=1.9))
        row = self.rows()[0]
        self.assertEqual(float(row.get('ego_yaw', 'nan')), 0.)
        self.assertEqual(row.get('ego_length', 'MISSING'), '')
        self.assertEqual(float(row.get('ego_width', 'nan')), 1.9)


if __name__ == '__main__':
    unittest.main()
