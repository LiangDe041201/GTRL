#!/usr/bin/env python3
"""阶段 2：Cournot 零和博弈（cournot_game）单元测试（纯 stdlib，无需 CARLA）。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.cournot_game import (
    build_payoff_matrix, solve_equilibrium, cournot_decision,
    EGO_ACTIONS, RV_ACTIONS)


class TestCournotGame(unittest.TestCase):

    def test_matrix_shape_and_zero_sum(self):
        U = build_payoff_matrix(arc_to_cross=16.0, rv_dist_to_conflict=24.6)
        self.assertEqual(len(U), len(EGO_ACTIONS))
        self.assertEqual(len(U[0]), len(RV_ACTIONS))
        # 零和：RV 视角 = -U（逐元素检查符号相反）
        for a in range(len(U)):
            for b in range(len(U[0])):
                self.assertEqual(U[a][b], -(-U[a][b]))

    def test_gap_sufficient_ego_goes(self):
        # 间隙充足（RV 40m，即使抢行也能安全清空）→ 保守鞍点也建议走
        d = cournot_decision(arc_to_cross=16.0, rv_dist_to_conflict=40.0)
        self.assertTrue(d['ego_go'], f"应建议走，实际: {d}")
        self.assertTrue(d['pure_nash'])

    def test_gap_insufficient_ego_waits(self):
        # 间隙不足（RV 10m）→ 应等
        d = cournot_decision(arc_to_cross=16.0, rv_dist_to_conflict=10.0)
        self.assertFalse(d['ego_go'], f"应建议等，实际: {d}")

    def test_pyield_high_ego_goes(self):
        # p_yield 模式：RV 让行概率高（0.9）→ 期望支付支持走（博弈耦合）
        d = cournot_decision(arc_to_cross=16.0, rv_dist_to_conflict=24.6, p_yield=0.9)
        self.assertTrue(d['ego_go'], f"RV 大概率让行应建议走，实际: {d}")

    def test_pyield_low_ego_waits(self):
        # p_yield 模式：RV 大概率抢行（0.1）→ 应等
        d = cournot_decision(arc_to_cross=16.0, rv_dist_to_conflict=24.6, p_yield=0.1)
        self.assertFalse(d['ego_go'], f"RV 大概率抢行应建议等，实际: {d}")

    def test_saddle_pure_nash(self):
        U = build_payoff_matrix(arc_to_cross=16.0, rv_dist_to_conflict=40.0)
        eq = solve_equilibrium(U)
        self.assertIn(eq['ego_action'], (0, 1))
        self.assertIn(eq['rv_action'], (0, 1))
        # 该构型下应存在纯策略鞍点
        self.assertTrue(eq['pure_nash'])

    def test_ego_rv_actions_valid(self):
        d = cournot_decision(arc_to_cross=16.0, rv_dist_to_conflict=20.0)
        self.assertIn(EGO_ACTIONS[d['ego_action']], ('wait', 'go'))
        self.assertIn(RV_ACTIONS[d['rv_action']], ('rush', 'yield'))

    def test_monotonic_with_rv_distance(self):
        # RV 越远，越倾向"走"
        go_far = cournot_decision(16.0, 40.0)['ego_go']
        go_near = cournot_decision(16.0, 8.0)['ego_go']
        self.assertTrue(go_far)
        self.assertFalse(go_near)

    # ===== ① 双侧 THW_boundary 安全项（前后车安全裕度此消彼长）=====
    def test_thw_high_safer_than_low(self):
        # 双侧 THW 都高 → go+yield 的收益明显高于双侧都低（安全项更安全）
        U_hi = build_payoff_matrix(16.0, 24.6, thw_rv=2.0, thw_fv=2.0)
        U_lo = build_payoff_matrix(16.0, 24.6, thw_rv=0.5, thw_fv=0.5)
        self.assertGreater(U_hi[1][1], U_lo[1][1])

    def test_side_min_bound_limits(self):
        # left_turn 模式："此消彼长"——RV 侧很高但 FV 侧极低 → 安全受限于低侧（min），
        # 抬高一侧救不了另一侧；收益与"双侧都低"接近。
        U_imbalanced = build_payoff_matrix(16.0, 24.6, thw_rv=3.0, thw_fv=0.3, u_safe_mode='left_turn')
        U_balanced_lo = build_payoff_matrix(16.0, 24.6, thw_rv=0.3, thw_fv=0.3, u_safe_mode='left_turn')
        self.assertAlmostEqual(U_imbalanced[1][1], U_balanced_lo[1][1], places=3)

    def test_thw_none_falls_back_to_margin(self):
        # 不传 thw → 走原 margin 逻辑（向后兼容，现有行为不变）
        d_far = cournot_decision(16.0, 40.0)
        d_near = cournot_decision(16.0, 8.0)
        self.assertTrue(d_far['ego_go'])
        self.assertFalse(d_near['ego_go'])

    def test_thw_cournot_direction(self):
        # 双侧 THW 越高 → 博弈期望收益越高（更倾向走）——方向性验证。
        # 注意：wait_penalty 下低 THW 也可能为"完成切入"而走（拥堵必须切入的权衡），
        # 所以这里断言"收益随 THW 增大"，而非预设"低 THW 必停"。
        d_hi = cournot_decision(16.0, 24.6, p_yield=0.9,
                                thw_rv=2.5, thw_fv=2.5)
        d_lo = cournot_decision(16.0, 24.6, p_yield=0.9,
                                thw_rv=0.2, thw_fv=0.2)
        self.assertGreater(d_hi['value'], d_lo['value'])

    # ===== 式24 三组件：U_speed=(v-v_ref)²、U_comfort=(J-J_TH)²+(δ-δ_TH)² =====
    def test_eq24_speed_deviation(self):
        # v_ref 提供时：go（v=v_go）贴近 v_ref → 效率偏差小；偏离 v_ref 惩罚大
        U_near = build_payoff_matrix(16.0, 24.6, v_ref=5.0)          # v_go=5=v_ref → 偏差0
        U_far = build_payoff_matrix(16.0, 24.6, v_ref=2.0)           # v_go=5, v_ref=2 → 偏差大
        # 走(go,yield) 的收益，贴近参考（v_ref=5）应更高
        self.assertGreater(U_near[1][1], U_far[1][1])

    def test_eq24_comfort_jerk_steer(self):
        # jerk/steer 提供时：越接近阈值（jerk_th/steer_th）越平顺 → 舒适惩罚小
        U_smooth = build_payoff_matrix(16.0, 24.6, jerk=0.5, steer=0.3,
                                       jerk_th=0.5, steer_th=0.3)      # 等于阈值 → 0 惩罚
        U_rough = build_payoff_matrix(16.0, 24.6, jerk=3.0, steer=1.2,
                                      jerk_th=0.5, steer_th=0.3)       # 偏离阈值 → 惩罚大
        # 走(go,yield)：平顺的舒适项惩罚更小 → 收益更高
        self.assertGreater(U_smooth[1][1], U_rough[1][1])

    def test_usafe_mode_eq24_vs_left_turn(self):
        # U_safe 两种模式：
        #   eq24    = 双侧贴近 TH_th 最优（平方偏差），远离阈值惩罚大
        #   left_turn = min 短板（THW 越大越安全；一侧极高但另一侧安全即可）
        # 双侧 THW 都很高(>th_th)：left_turn 判安全(+)，eq24 判"偏离阈值"为负
        U_lt = build_payoff_matrix(16.0, 24.6, thw_rv=3.0, thw_fv=3.0,
                                   thw_th=1.5, u_safe_mode='left_turn')
        U_24 = build_payoff_matrix(16.0, 24.6, thw_rv=3.0, thw_fv=3.0,
                                   thw_th=1.5, u_safe_mode='eq24')
        self.assertGreater(U_lt[1][1], U_24[1][1])   # 左转对"THW 很安全"给正收益，eq24 给负

    def test_usafe_eq24_mode_produces_finite(self):
        # eq24 模式：THW 非有限（无车=inf）时按 TH_th 处理 → 结果有限
        m = build_payoff_matrix(16.0, 24.6, thw_rv=float('inf'),
                                thw_fv=float('inf'), thw_th=1.5,
                                u_safe_mode='eq24')
        self.assertTrue(all(abs(x) < 1e6 for row in m for x in row))

    def test_expected_response_value_matches_selected_wait_action(self):
        result = cournot_decision(10., 15., v_go=4., p_yield=.6, v_ref=4.,
                                  thw_rv=6., thw_fv=6., jerk=.5, steer=.3)
        self.assertFalse(result['ego_go'])
        self.assertEqual(result['decision_mode'], 'expected_response')
        self.assertIsNone(result['pure_nash'])
        self.assertAlmostEqual(result['u_go'], -81.)
        self.assertAlmostEqual(result['u_wait'], -27.102)
        self.assertAlmostEqual(result['value'], result['u_wait'])

    def test_expected_response_value_matches_selected_go_action(self):
        result = cournot_decision(10., 15., v_go=4., p_yield=.6, v_ref=4.,
                                  thw_rv=.5, thw_fv=1.5, jerk=.5, steer=.3)
        self.assertTrue(result['ego_go'])
        matrix = result['payoff_matrix']
        self.assertAlmostEqual(result['value'], .4*matrix[1][0]+.6*matrix[1][1])

    def test_single_sided_equal_columns_do_not_manufacture_a_probability_effect(self):
        kw = dict(v_go=4., v_ref=4., thw_rv=3., thw_fv=3., jerk=.5, steer=.3)
        low = cournot_decision(10., 15., p_yield=.1, **kw)
        high = cournot_decision(10., 15., p_yield=.9, **kw)
        self.assertEqual(low['value'], high['value'])
        self.assertEqual(low['ego_go'], high['ego_go'])
        self.assertNotEqual(low['rv_action'], high['rv_action'])  # Prediction only.

    def test_no_probability_reports_its_actual_solution_mode(self):
        result = cournot_decision(16., 40.)
        self.assertEqual(result['decision_mode'], 'pure_saddle')


if __name__ == "__main__":
    unittest.main()
