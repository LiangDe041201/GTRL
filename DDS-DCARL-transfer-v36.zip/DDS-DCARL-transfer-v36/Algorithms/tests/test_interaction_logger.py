#!/usr/bin/env python3
"""交互诊断日志（RV 是否提前刹车）单元测试 —— 纯 stdlib，写临时目录。"""
import csv
import os
import shutil
import sys
import tempfile
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.interaction_logger import InteractionLogger


class TestInteractionLogger(unittest.TestCase):
    class _Ego(object):
        """最小 ego 替身（ego_row 只读 x/y/v）。"""
        x, y, v = 4.03, -134.77, 2.78

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix='ilog_')
        self.log = InteractionLogger(out_dir=self.tmp, enabled=True,
                                     report_every=1, flush_every=1)
        self.log.begin_episode(1)

    def tearDown(self):
        self.log.close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _rows(self, name):
        with open(os.path.join(self.tmp, name)) as f:
            return list(csv.reader(f))

    def test_files_created_with_header(self):
        for name in ('interaction_rv.csv', 'interaction_ego.csv',
                     'interaction_summary.csv'):
            rows = self._rows(name)
            self.assertGreaterEqual(len(rows), 1, name)

    def test_observed_and_predicted_acceleration_sources_stay_distinct(self):
        conf = dict(rv_acc=-1.25, rv_acc_source='velocity_difference',
                    rv_acc_follow=.4, rv_acc_follow_source='idm_from_observation')
        self.log.ego_row(conf=conf, ego=self._Ego())
        self.log.close()
        with open(os.path.join(self.tmp, 'interaction_ego.csv'), newline='') as stream:
            row = next(csv.DictReader(stream))
        self.assertIsNone(row.get(None), 'Header and row must remain aligned')
        self.assertEqual(float(row['rv_acc_observed']), -1.25)
        self.assertEqual(row['rv_acc_source'], 'velocity_difference')
        self.assertEqual(float(row['rv_acc_follow_pred']), .4)
        self.assertEqual(row['rv_acc_follow_source'], 'idm_from_observation')

    def test_early_brake_detected_when_ego_far(self):
        """自车距冲突点 > EARLY_DIST 时 RV 减速 → 计入"提前刹车"（RV 自己早刹）。"""
        self.log.tick()
        self.log.rv_row(1, rv_x=10.0, rv_y=-138.0, rv_v=8.0, in_zone=True,
                        ego_dist=30.0, conflict_x=-7.1, committed=False, dt=0.05)
        self.log.tick()
        self.log.rv_row(1, rv_x=9.5, rv_y=-138.0, rv_v=6.0, in_zone=True,
                        ego_dist=29.0, conflict_x=-7.1, committed=False, dt=0.05)
        self.assertEqual(self.log._ep['n_early_brake'], 1)
        self.assertEqual(self.log._ep['n_zoneA_brake'], 0)
        self.assertEqual(self.log._ep['first_brake_cat'], 'early')

    def test_zone_a_brake_counted(self):
        """zone A 生效时刹车 = "我们自己把环境变简单"的直接证据。"""
        self.log.tick()
        self.log.rv_row(2, rv_x=5.0, rv_y=-138.0, rv_v=7.0, in_zone=True, zone_a=True,
                        ego_dist=6.0, conflict_x=-7.1, committed=False, dt=0.05)
        self.log.tick()
        self.log.rv_row(2, rv_x=4.8, rv_y=-138.0, rv_v=4.0, in_zone=True, zone_a=True,
                        ego_dist=5.8, conflict_x=-7.1, committed=False, dt=0.05)
        self.assertEqual(self.log._ep['n_zoneA_brake'], 1)
        self.assertEqual(self.log._ep['n_early_brake'], 0)
        self.assertEqual(self.log._ep['first_brake_cat'], 'zoneA')

    def test_committed_brake_category(self):
        self.log.tick()
        self.log.rv_row(5, rv_x=1.0, rv_y=-138.0, rv_v=9.0, in_zone=True,
                        ego_dist=2.0, conflict_x=-7.1, committed=True, dt=0.05)
        self.log.tick()
        self.log.rv_row(5, rv_x=0.8, rv_y=-138.0, rv_v=6.0, in_zone=True,
                        ego_dist=1.8, conflict_x=-7.1, committed=True, dt=0.05)
        self.assertEqual(self.log._ep['n_committed_brake'], 1)
        self.assertEqual(self.log._ep['first_brake_cat'], 'committed')

    def test_other_brake_in_transition_band(self):
        # 8~12m 之间、zone_a 未生效 → 过渡带
        self.log.tick()
        self.log.rv_row(6, rv_x=3.0, rv_y=-138.0, rv_v=9.0, in_zone=True,
                        ego_dist=10.0, conflict_x=-7.1, committed=False, dt=0.05)
        self.log.tick()
        self.log.rv_row(6, rv_x=2.8, rv_y=-138.0, rv_v=6.5, in_zone=True,
                        ego_dist=9.8, conflict_x=-7.1, committed=False, dt=0.05)
        self.assertEqual(self.log._ep['n_other_brake'], 1)
        self.assertEqual(self.log._ep['first_brake_cat'], 'other')

    def test_only_first_deceleration_counts(self):
        """同一辆车继续减速不重复计数（只看刹车起点）。"""
        self.log.tick()
        self.log.rv_row(4, rv_x=6.0, rv_y=-138.0, rv_v=9.0, in_zone=True,
                        ego_dist=20.0, conflict_x=-7.1, dt=0.05)
        for v in (7.0, 5.0, 3.0):
            self.log.tick()
            self.log.rv_row(4, rv_x=5.0, rv_y=-138.0, rv_v=v, in_zone=True,
                            ego_dist=20.0, conflict_x=-7.1, dt=0.05)
        self.assertEqual(self.log._ep['n_early_brake'], 1)

    def test_decision_reason_counters(self):
        self.log.rv_decision(1, 'yield', 'zoneA')
        self.log.rv_decision(2, 'yield', 'bernoulli')
        self.log.rv_decision(3, 'rush', 'bernoulli')
        self.log.rv_decision(4, 'yield', 'emergency')
        self.log.rv_decision(5, 'yield', 'committed')
        e = self.log._ep
        self.assertEqual(e['n_yield_zoneA'], 1)
        self.assertEqual(e['n_yield_bernoulli'], 1)
        self.assertEqual(e['n_rush_bernoulli'], 1)
        self.assertEqual(e['n_yield_emergency'], 1)
        self.assertEqual(e['n_yield_committed'], 1)

    def test_summary_row_written_on_end(self):
        self.log.tick()
        self.log.rv_decision(1, 'yield', 'zoneA')
        self.log.end_episode(outcome='collision', collision=True, frames=123)
        rows = self._rows('interaction_summary.csv')
        self.assertEqual(len(rows), 2)                     # header + 1 行
        self.assertEqual(rows[1][0], '1')
        self.assertEqual(rows[1][1], 'collision')
        self.assertEqual(rows[1][2], '1')
        self.assertEqual(rows[1][-1], '123')

    def test_collision_row_records_true_partner(self):
        """【诊断埋点】碰撞回合必须写出真实碰撞对方（而不是靠"最近 RV"代理推断）。"""
        self.log.tick()
        # 先有一帧 ego 状态（arc/边界量会被 collision_row 回填）
        self.log.ego_row(conf={'arc_to_cross': 10.22, 'committed': False,
                               'lcttc_rv': 0.01, 'lcttc_fv': float('inf'),
                               'n_vehicles': 3}, ego=self._Ego(), action=0)
        # 再有一帧 RV 行，缓存该对手的博弈决策
        self.log.rv_row(777, rv_x=5.0, rv_y=-138.0, rv_v=1.44, behavior='yield',
                        reason='bernoulli', target_speed=1.32, in_zone=True,
                        ego_dist=9.2, conflict_x=-7.1, dt=0.05)
        ev = {'frame': 216, 'other_id': 777, 'other_type': 'vehicle.audi.a2',
              'other_role': '', 'other_x': 5.0, 'other_y': -138.0, 'other_yaw': 3.14,
              'other_v': 1.44, 'ego_x': 4.03, 'ego_y': -134.77}
        self.log.end_episode(outcome='collision', collision=True, frames=216,
                            collision_event=ev)
        rows = self._rows('interaction_collision.csv')
        self.assertEqual(len(rows), 2, '碰撞回合应写出 1 行碰撞对方记录')
        hdr, row = rows[0], rows[1]
        d = dict(zip(hdr, row))
        self.assertEqual(d['other_id'], '777')
        self.assertEqual(d['other_type'], 'vehicle.audi.a2')
        self.assertEqual(d['other_v'], '1.44')
        # 对手当时的博弈决策（关键：让行还是抢行）必须被回填
        self.assertEqual(d['rv_behavior'], 'yield')
        self.assertEqual(d['rv_reason'], 'bernoulli')
        self.assertEqual(d['rv_target_speed'], '1.32')
        # ego 侧回填
        self.assertEqual(d['arc_to_cross'], '10.22')
        self.assertEqual(d['lcttc_rv'], '0.01')
        self.assertEqual(d['lcttc_min'], '0.01')      # min(0.01, inf)
        self.assertEqual(d['committed'], '0')

    def test_no_collision_row_when_not_collision(self):
        """非碰撞回合不应写碰撞行。"""
        self.log.tick()
        self.log.end_episode(outcome='complete', frames=100)
        rows = self._rows('interaction_collision.csv')
        self.assertEqual(len(rows), 1, '只有表头，没有数据行')

    def test_collision_row_survives_missing_event(self):
        """碰撞但事件缺失（埋点未生效）时不得抛异常，行仍要写出（字段留空）。"""
        self.log.tick()
        self.log.end_episode(outcome='collision', collision=True, frames=50,
                            collision_event=None)
        rows = self._rows('interaction_collision.csv')
        self.assertEqual(len(rows), 2)

    def test_disabled_logger_writes_nothing(self):
        tmp2 = tempfile.mkdtemp(prefix='ilog_off_')
        try:
            log = InteractionLogger(out_dir=tmp2, enabled=False)
            log.begin_episode(1)
            log.tick()
            log.rv_row(1, 1.0, 0.0, 5.0, in_zone=True, ego_dist=30.0)
            log.end_episode(outcome='complete')
            self.assertEqual(os.listdir(tmp2), [])
        finally:
            log.close()
            shutil.rmtree(tmp2, ignore_errors=True)


    def test_since_decision_column(self):
        """新列 since_decision：距上次决策的帧数（用于区分"决策驱动刹车"与"阻抗刹车"）。"""
        self.log.tick()
        self.log.rv_decision(1, 'yield', 'bernoulli', zone_a=False)
        self.log.tick()
        self.log.tick()
        self.log.rv_row(1, rv_x=10.0, rv_y=-138.0, rv_v=5.0, in_zone=True,
                        ego_dist=30.0, conflict_x=-7.1, dt=0.05)
        rows = self._rows('interaction_rv.csv')
        hdr = rows[0]
        self.assertIn('since_decision', hdr)
        self.assertEqual(rows[-1][hdr.index('since_decision')], '2')

    def test_brake_onset_after_decision_is_decision_driven(self):
        """让行决策后立刻减速 → since_decision 很小 → 归因为"决策驱动"。"""
        self.log.tick()
        self.log.rv_row(1, rv_x=18.0, rv_y=-138.0, rv_v=4.4, in_zone=True,
                        ego_dist=25.0, conflict_x=-7.1, dt=0.05)
        self.log.tick()
        self.log.rv_decision(1, 'yield', 'bernoulli')
        self.log.tick()
        self.log.rv_row(1, rv_x=17.6, rv_y=-138.0, rv_v=4.2, in_zone=True,
                        ego_dist=25.0, conflict_x=-7.1, dt=0.05)     # 首帧减速=刹车起点
        rows = self._rows('interaction_rv.csv')
        hdr = rows[0]
        last = rows[-1]
        self.assertEqual(last[hdr.index('brake_onset')], '1')
        self.assertEqual(last[hdr.index('since_decision')], '1')


if __name__ == '__main__':
    unittest.main()
