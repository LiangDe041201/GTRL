"""Candidate identity, unavailable evidence and post-guard shadow attribution."""
import copy
import math
import unittest

try:
    from Planning_library.rolling_efe_v27 import EFEShadowLedger
except ImportError:
    EFEShadowLedger=None


def part(gap=100.,progress=100.,valid=True):
    return dict(min_gap=gap,forecast_valid=valid,admissible=valid,
                forecasts=[dict(progress_m=progress,valid=valid)]*2)


def payload():
    base=dict(action=0,id='proceed_base',path_hash='a'*64,plan_hash='b'*64,prediction_hash='c'*64,
              a=.4,delta=.01,target=4.,solve_ok=True)
    alternative=dict(base,action=2,id='offset_-0.20',path_hash='d'*64,plan_hash='e'*64,
                     prediction_hash='f'*64,components=[part(),part()])
    data=dict(active=True,observation=dict(ego=dict(x=0.,y=0.,yaw=0.,v=2.),others=[]),
        previous=dict(a=0.,df=0.),beta=dict(actor_id='2',alpha=1.,beta=1.,mean=.5),
        candidates=[base,alternative],allowed=[0,2],actual_action=2,requested_action=2,
        request=copy.deepcopy(alternative),retracted=False)
    cg=dict(active=True,selected=1,rv_id='2',standoff=10.,
            components=[[part(),part()],[part(-100.),part(-100.)]])
    return data,cg


def applied(a=.4,delta=.01,target=4.):
    return dict(control_submit_ok=1,a_cmd=a,delta_rad=delta,actuator_speed_target=target,ego_v_after=2.)


class EFELedgerTests(unittest.TestCase):
    def ledger(self):
        self.assertIsNotNone(EFEShadowLedger,'No final-request EFE shadow ledger')
        return EFEShadowLedger()

    def test_each_candidate_uses_its_own_outcome_components_without_mutating_inputs(self):
        p,cg=payload(); before=copy.deepcopy((p,cg))
        row=self.ledger().propose(p,cg); by={v['action']:v for v in row['candidates']}
        self.assertAlmostEqual(by[0]['score']['efe'],-math.log(.01))
        self.assertAlmostEqual(by[2]['score']['efe'],-math.log(.94))
        self.assertNotEqual(by[0]['input_signature'],by[2]['input_signature'])
        self.assertEqual((p,cg),before)
        self.assertFalse(row['calibrated']); self.assertFalse(row['reward_applied'])

    def test_same_action_on_a_different_path_does_not_reuse_its_old_score_identity(self):
        ledger=self.ledger(); p,cg=payload()
        old=ledger.propose(p,cg)['candidates'][1]['input_signature']
        p['candidates'][1]['path_hash']='9'*64
        new=ledger.propose(p,cg)['candidates'][1]['input_signature']
        self.assertNotEqual(old,new)

    def test_another_actors_belief_is_unavailable_instead_of_used_as_a_yield_probability(self):
        ledger=self.ledger(); p,cg=payload(); p['beta']['actor_id']='unrelated'
        row=ledger.propose(p,cg)
        self.assertTrue(all(not c['available'] for c in row['candidates']))
        self.assertTrue(all(c['reason']=='belief_actor_mismatch' for c in row['candidates']))

    def test_invalid_forecasts_have_no_fabricated_zero_efe(self):
        p,cg=payload(); p['candidates'][1]['components'][0]['forecast_valid']=False
        row=self.ledger().propose(p,cg); c=row['candidates'][1]
        self.assertFalse(c['available']); self.assertIsNone(c['score'])
        self.assertEqual(c['reason'],'invalid_forecast')

    def test_unmodified_final_request_gets_time_cost_but_never_changes_actual_reward(self):
        ledger=self.ledger(); p,cg=payload(); ledger.propose(p,cg)
        p['feedback']=dict(reward=.123)
        final=ledger.feedback(p,dict(action='mpc',override=False,unavoidable=False),applied(),1,7)
        self.assertEqual(final['owner_action'],2)
        self.assertEqual(final['source'],'candidate_prediction')
        self.assertAlmostEqual(final['cost_seconds'],.05*(-math.log(.94))/(-math.log(.01)))
        self.assertEqual(p['feedback']['reward'],.123)
        self.assertEqual(final['actual_task_reward'],.123)
        self.assertFalse(final['reward_applied'])

    def test_guard_retraction_scores_the_actual_cg_brake_instead_of_the_rejected_path(self):
        ledger=self.ledger(); p,cg=payload(); ledger.propose(p,cg)
        p.update(actual_action=0,retracted=True,request=copy.deepcopy(p['candidates'][0]))
        p['feedback']=dict(reward=-.01)
        brake=dict(action='brake',a=-2.,delta=.02,target=0.,gap=100.,
                   forecast_valid=True,forecasts=[dict(progress_m=0.,valid=True)]*2)
        audit=dict(action='brake',override=True,unavoidable=False,candidates=[brake])
        final=ledger.feedback(p,audit,applied(-2.,.02,0.),1,8)
        self.assertEqual(final['owner_action'],0)
        self.assertEqual(final['source'],'guard_envelope')
        self.assertEqual(final['evidence'],brake)
        brake['forecasts'][0]['progress_m']=999.
        self.assertEqual(final['evidence']['forecasts'][0]['progress_m'],0.)
        self.assertEqual(final['path_hash'],'a'*64)
        self.assertAlmostEqual(final['score']['efe'],-math.log(.03))
        self.assertAlmostEqual(final['cost_seconds'],.05*(-math.log(.03))/(-math.log(.01)))
        self.assertNotEqual(final['score']['efe'],ledger.last['candidates'][1]['score']['efe'])

    def test_a_changed_control_without_matching_guard_evidence_cannot_borrow_request_efe(self):
        ledger=self.ledger(); p,cg=payload(); ledger.propose(p,cg); p['feedback']=dict(reward=.1)
        final=ledger.feedback(p,dict(action='mpc',override=False,unavoidable=False),applied(a=-1.),1,9)
        self.assertFalse(final['available']); self.assertIsNone(final['score'])
        self.assertIsNone(final['cost_seconds']); self.assertEqual(final['reason'],'unmatched_final_control')

    def test_inactive_or_missing_cg_components_are_explicitly_unavailable(self):
        p,cg=payload(); p['active']=False; cg['components']=None
        row=self.ledger().propose(p,cg)
        self.assertTrue(all(c['reason']=='inactive' and c['score'] is None for c in row['candidates']))

    def test_task_terminal_reward_is_retained_and_cost_is_integrated_only_once_per_feedback(self):
        ledger=self.ledger(); p,cg=payload(); ledger.propose(p,cg); p['feedback']=dict(reward=5.)
        final=ledger.feedback(p,dict(action='mpc',override=False,unavoidable=False),applied(),1,10,dt=.1)
        self.assertEqual(final['actual_task_reward'],5.)
        self.assertAlmostEqual(final['cost_seconds'],.1*(-math.log(.94))/(-math.log(.01)))
        self.assertFalse(final['reward_applied'])


if __name__=='__main__': unittest.main()
