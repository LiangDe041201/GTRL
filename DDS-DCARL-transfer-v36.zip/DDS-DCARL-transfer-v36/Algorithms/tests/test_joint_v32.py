import unittest
from types import SimpleNamespace

import numpy as np

from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
from Tools.run_dense_validation_v30 import build_plan


class JointActionTests(unittest.TestCase):
    def test_action_grid_and_default(self):
        planner = select_rolling_planner('joint_v32')
        actions = planner.LEARNER_CLASS.ACTION_PAIRS
        self.assertEqual(len(actions), 30)
        self.assertEqual(actions[0], (None, None))
        self.assertEqual(set(actions), {(offset, speed)
            for offset in (None, .5, 1., -.5, -1., 0.) for speed in (None, 4., 3., 2., 1.)})
        self.assertEqual(planner.default_action([0, 1], [2., 1.]), 0)

    def test_joint_geometry_accepts_both_requested_one_meter_offsets(self):
        planner = select_rolling_planner('joint_v32')
        family = planner.FAMILY_CLASS([[0., 0.], [10., 0.], [20., 0.], [30., 0.]])
        ego = SimpleNamespace(x=1., y=0., yaw=0., v=2.)
        for offset in (-1., 1.):
            path = family.generate(ego, {'df': 0.}, 2.8, offset, 4.)
            self.assertAlmostEqual(path['d'][-1], offset)
            self.assertTrue(np.isfinite(path['curvature']).all())

    def test_joint_speed_options_respect_cap_and_deduplicate_current_cg_target(self):
        planner = select_rolling_planner('joint_v32')
        instance = object.__new__(planner)
        instance._speed_cap = 3.5
        actions = planner.LEARNER_CLASS.ACTION_PAIRS
        self.assertIsNone(instance._candidate_target(actions.index((.5,4.)),2.))
        self.assertIsNone(instance._candidate_target(actions.index((.5,2.)),2.))
        self.assertEqual(instance._candidate_target(actions.index((.5,3.)),2.),3.)
        self.assertEqual(instance._candidate_target(actions.index((.5,None)),2.),2.)

    def test_runner_keeps_separate_training_and_paired_frozen_evaluation(self):
        train, evaluate = build_plan('unused', 4, 2, [411, 412], learner='joint_v32')
        self.assertEqual(train['arms'], ['U5_joint_train_v32'])
        self.assertEqual(train['episodes_total'] + evaluate['episodes_total'], 12)
        self.assertEqual(evaluate['arms'], ['M6_matrix_v18', 'U6_joint_eval_v32'])
        self.assertIn('--rolling-checkpoint', evaluate['arguments'])


if __name__ == '__main__':
    unittest.main()
