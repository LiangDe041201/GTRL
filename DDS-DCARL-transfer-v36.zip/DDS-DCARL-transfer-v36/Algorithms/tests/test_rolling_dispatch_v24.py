"""Run the real CLI and matrix-driver branch for rolling trajectory ownership."""
import ast
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace as S
import unittest
from Tools.run_relay_validation import main,ARMS
import test_rolling_planner_v24 as fixtures


class RollingDispatchTests(unittest.TestCase):
    def test_remote_arms_select_one_rolling_owner_and_keep_legacy_learning_off(self):
        for arm,phase in [('T0_observe_v24','observe'),('T1_fixed_v24','fixed'),
                          ('T2_train_v24','train'),('T3_eval_v24','eval')]:
            self.assertIn(arm,ARMS,'Rolling learning is not available in the remote runner')
            out=io.StringIO()
            args=['--dry-run','--arms',arm,'--traffic-interaction','v17']
            if phase=='eval': args+=['--rolling-checkpoint','future/rolling_model.json']
            with contextlib.redirect_stdout(out): self.assertEqual(main(args),0)
            c=json.loads(out.getvalue())['effective']
            self.assertEqual(c['DSH_ROLLING_PHASE'],phase)
            self.assertEqual((c['DSH_METHOD'],c['DSH_COURNOT_MODE'],c['DSH_FORECAST_MODEL']),
                             ('CG','matrix_v18','route_v18'))
            self.assertEqual((c['DSH_EFE'],c['DSH_WCV_BCV']),('0','0'))

    def test_missing_frozen_model_is_rejected_before_carla_launch(self):
        self.assertIn('T3_eval_v24',ARMS)
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            main(['--dry-run','--arms','T3_eval_v24','--traffic-interaction','v17'])

    def test_real_driver_records_rolling_owner_and_activates_its_path(self):
        from Planning_library.matrix_turn_game import solve_candidates
        p,f=fixtures.RollingPlannerTests().fixture('train')
        dynamic,cs,game=f[1],f[2],f[4]
        primary,peer=cs[1]['controller'],cs[0]['controller']
        stub=S(dynamic_map=dynamic,trajectory_probe=p,
            env=S(goal_pose=(-21.,-138.5,3.14),INTERSECTION_CENTER=(6.,-138.)),turn_feasibility=S(last={}))
        tree=ast.parse((Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf8'))
        blocks=[n for n in ast.walk(tree) if isinstance(n,ast.If) and any(
            isinstance(c,ast.Call) and isinstance(c.func,ast.Name) and c.func.id=='solve_candidates' for c in ast.walk(n))]
        block=min(blocks,key=lambda n:len(list(ast.walk(n))))
        ns=dict(self=stub,mpc_controller=primary,matrix_peer=peer,matrix_game=game,v_ref=4.,_sd=14.,
            road_right=False,_conf=dict(rv_veh=dynamic.objects[0],conflict_x=6.,conflict_y=-138.),
            _previous_control=dict(primary.last_u),solve_candidates=solve_candidates)
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(ast.Module(body=[block],type_ignores=[]),'<real rolling dispatch>','exec'),ns)
        self.assertIn('rolling_trajectory',game.last)
        self.assertEqual(game.last['rolling_trajectory']['revision'],'rolling_trajectory_v24')
        self.assertEqual(ns['_choice']['target'],game.last['candidate_targets'][game.last['selected']])
        self.assertEqual(ns['mpc_controller'].last_pathway.tolist(),ns['_choice']['path'].tolist())


if __name__=='__main__': unittest.main()
