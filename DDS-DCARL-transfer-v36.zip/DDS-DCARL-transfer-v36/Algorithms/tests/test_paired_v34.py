import unittest
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace as S

from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
from Tools.run_dense_validation_v30 import build_plan


class PairedSamplingTests(unittest.TestCase):
    def make_learner(self):
        cls=select_rolling_planner('paired_v34').LEARNER_CLASS
        learner=cls()
        context=[5.,1.,4.,10.,2.,4.,0.,20.,4.,0.,0.,0.,0.,0.,1.,1.]
        beta=dict(alpha=1.,beta=1.)
        return learner,context,beta,[0.]*len(cls.ACTION_NAMES)

    def test_v34_keeps_the_original_state_key(self):
        from Planning_library.select_first_planner_v33 import SelectFirstLearnerV33
        learner,x,beta,costs=self.make_learner()
        original=SelectFirstLearnerV33()
        for actions in ([0,5],[0,5,20]):
            self.assertEqual(learner.begin(x,beta,0,actions,costs,1),original.begin(x,beta,0,actions,costs,1))
        self.assertNotEqual(learner.signature(),original.signature())

    def test_balanced_pair_exploration_and_wide_exploration(self):
        learner,x,beta,costs=self.make_learner()
        key=learner.begin(x,beta,0,[0,5,20],costs,1)
        node=learner.nodes[key]
        bounds={0:dict(n=2),5:dict(n=1),20:dict(n=0)}
        self.assertEqual(learner._exploration_action(node,bounds,S(random_sample=lambda:.9,choice=min)),5)
        self.assertEqual(learner._exploration_action(node,bounds,S(random_sample=lambda:0.,choice=max)),20)
        bounds[5]['n']=3
        self.assertEqual(learner._exploration_action(node,bounds,S(random_sample=lambda:.9,choice=min)),0)

    def test_rejected_and_weaker_pairs_leave_priority_pool(self):
        learner,x,beta,costs=self.make_learner()
        key=learner.begin(x,beta,0,[0,5,8,25],costs,7)
        for episode in range(1,4): learner.note_rejection(key,5,episode)
        node=learner.nodes[key]
        bounds={0:dict(n=3,wcv=2.),5:dict(n=0),8:dict(n=0),25:dict(n=3,bcv=0.)}
        self.assertEqual(learner._exploration_action(node,bounds,S(random_sample=lambda:.9,choice=min)),8)
        learner.note_rejection(key,8,7)
        self.assertIsNone(learner._exploration_action(node,bounds,S(random_sample=lambda:.9,choice=min)))

    def test_coverage_ignores_repeated_frames_in_the_same_episode(self):
        from Tools.paired_coverage_v34 import paired_coverage
        records=[dict(state='same',action=0,episode=n) for n in range(4)]
        records += [dict(state='same',action=5,episode=1)]*20
        result=paired_coverage(records)
        self.assertEqual(result['paired_support_max'],1)
        self.assertEqual(result['paired_cells_ge_1'],1)
        self.assertEqual(result['paired_cells_ge_3'],0)

    def test_new_decision_retraction_keeps_the_preceding_bellman_link(self):
        from Tools.validate_rolling_v24 import validate_rolling_experience
        learner,x,beta,costs=self.make_learner()
        initial=learner.begin(x,beta,0,[0],costs,1)
        learner.start(0); learner.reward(1.)
        x[0]=15.
        decision=learner.begin(x,beta,0,[0,5],costs,1)
        fallback=learner.begin(x,beta,0,[0],costs,1)
        learner.start(0); learner.reward(1.); learner.finish()

        def row(state,requested,outcome):
            feedback=dict(actual_action=0,credited_state=state,credited_episode=1,option_started=True,
                          observed_body=None,reward=1.,intervention=False,outcome=outcome)
            rolling=dict(feedback=feedback,decision=True,changed_request=False,retracted=requested,
                candidates=[],allowed=[0,5] if requested else [0],learning=dict(source='explore',state=decision),
                beta=dict(evidence_applied=False),actual_action=0,extra_solve_count=int(requested),
                exact_audit_rejected=requested,reused_cg_index=None)
            return dict(rolling_trajectory=rolling)

        with TemporaryDirectory() as tmp:
            path=Path(tmp)
            learner.save(path/'rolling_model/rolling_model.json')
            metadata=dict(signature=learner.signature(),learner_revision=learner.SCHEMA,
                          baseline_action=0,reference_policy='uniform_admissible_v29')
            (path/'rolling_metadata_v24.json').write_text(json.dumps(metadata),encoding='utf8')
            evidence=validate_rolling_experience(path,[row(initial,False,None),row(fallback,True,'complete')],
                                                 'train','paired_v34')
        self.assertTrue(evidence['rolling_experience_contract_ok'],evidence)

    def test_pilot_runner_does_not_reuse_training_seed_for_frozen_evaluation(self):
        train,evaluate=build_plan('unused',learner='paired_v34')
        self.assertEqual(train['arms'],['U9_paired_train_v34'])
        self.assertEqual(evaluate['arms'],['M6_matrix_v18','U10_paired_eval_v34'])
        self.assertTrue(set(train['seeds']).isdisjoint(evaluate['seeds']))


if __name__=='__main__': unittest.main()
