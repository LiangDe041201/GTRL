#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【式67 形状改造】回归测试（纯函数，无 CARLA）。

背景（`PAPER_DRAFT/EVIDENCE_reward_literature.md` L1 + HANDOFF §10/§11）
------------------------------------------------------------------
奖励核账实测：原式 `r_lat = −10·Δy²`（**无界二次**）均值 **−13.28/帧**，
占全部负向奖励的 **41.4%**，且**被罕见尖峰支配**：
    · 中位仅 −0.09，而 p10 = −42.2、min = **−144.5**
    · **最差 5% 帧（38/765）贡献了该项负向总量的 50%**
⇒ 期望被尖峰支配 ⇒ **"不动"成为回避尖峰的最优策略** ⇒ RL 学会"停车"。

文献依据：UniPD thesis 明确指出 **"quadratic penalty that can cause overly
cautious behavior"**，改用**线性化**居中惩罚。

改造后（默认）：
    r_lat = −w·(1 − exp(−|Δy|/scale))        ← 指数饱和，值域 [−w, 0]
可选形状：`DSH_LAT_SHAPE = exp(默认) | linear | quad(论文原式)`

本文件只验证形状/数值/可回退性，不涉及阈值改动。
"""
import math
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.game_reward import (
    lat_reward, LAT_W_DEFAULT, LAT_SCALE_DEFAULT, LAT_CAP_DEFAULT,
)


class TestLatRewardShapes(unittest.TestCase):

    def tearDown(self):
        for k in ('DSH_LAT_CAP', 'DSH_LAT_W', 'DSH_LAT_SHAPE', 'DSH_LAT_SCALE'):
            os.environ.pop(k, None)

    # ---------------- 默认：指数饱和 ----------------
    def test_default_is_exp_and_bounded(self):
        """默认形状必须有界：恒 ≥ −w，且随 |Δy| 单调不增。"""
        prev = 0.0
        for dy in [i * 0.1 for i in range(0, 120)]:
            v = lat_reward(dy, 0.0)
            self.assertLessEqual(v, 1e-12, 'r_lat 必须 ≤ 0')
            self.assertLessEqual(v, prev + 1e-12, '应随 |Δy| 单调不增')
            self.assertGreaterEqual(v, -LAT_W_DEFAULT - 1e-9, '必须 ≥ −w（有界）')
            prev = v

    def test_exp_saturates_at_large_deviation(self):
        """大偏差处斜率必须**饱和**（这是修复的核心）。"""
        d_small = abs(lat_reward(2.0, 0.0) - lat_reward(0.5, 0.0))
        d_large = abs(lat_reward(10.0, 0.0) - lat_reward(2.0, 0.0))
        self.assertLess(d_large, d_small, '指数形状在大偏差处斜率应更小')
        # 实测最差 3.80 m 的惩罚必须显著小于原式的 −144.4
        self.assertGreater(lat_reward(3.80, 0.0), -12.0,
                           'Δy=3.80 的惩罚应远小于论文原式的 −144.4')

    def test_exp_matches_formula(self):
        """与解析式一致：−w·(1−exp(−|Δy|/scale))。"""
        dy, sc, w = 1.234, LAT_SCALE_DEFAULT, LAT_W_DEFAULT
        self.assertAlmostEqual(lat_reward(dy, 0.0),
                               -w * (1.0 - math.exp(-dy / sc)), places=9)

    # ---------------- 线性 ----------------
    def test_linear_shape(self):
        os.environ['DSH_LAT_SHAPE'] = 'linear'
        self.assertAlmostEqual(lat_reward(0.75, 0.0, scale=1.5, w=10.0), -5.0, places=9)
        self.assertAlmostEqual(lat_reward(1.5, 0.0, scale=1.5, w=10.0), -10.0, places=9)
        # 超出 scale 后饱和
        self.assertAlmostEqual(lat_reward(9.9, 0.0, scale=1.5, w=10.0), -10.0, places=9)

    # ---------------- 论文原式（消融） ----------------
    def test_quad_reproduces_paper(self):
        os.environ['DSH_LAT_SHAPE'] = 'quad'
        self.assertAlmostEqual(lat_reward(1.0, 0.0), -10.0, places=6)
        self.assertAlmostEqual(lat_reward(2.0, 0.0), -40.0, places=6)

    def test_quad_cap_still_works(self):
        """quad 模式下的 `cap` 仍应生效（保留上一轮的尖峰上限）。"""
        self.assertAlmostEqual(lat_reward(3.80, 0.0, shape='quad', cap=6.0), -60.0, places=6)
        os.environ['DSH_LAT_CAP'] = '0'          # 0 ⇒ 无界 ⇒ 论文原式
        self.assertAlmostEqual(lat_reward(3.80, 0.0, shape='quad'), -144.4, places=6)

    # ---------------- 参数覆盖 ----------------
    def test_env_overrides(self):
        os.environ['DSH_LAT_W'] = '5.0'
        self.assertAlmostEqual(lat_reward(0.0, 0.0), 0.0, places=9)
        v = lat_reward(3.0, 0.0)
        self.assertGreater(v, -5.0 - 1e-9)
        self.assertLess(v, 0.0)
        # 【显式 scale 是权威】scale 越小 ⇒ 越快饱和 ⇒ 惩罚越接近 −w
        os.environ['DSH_LAT_SCALE'] = '0.5'
        self.assertLess(lat_reward(3.0, 0.0, scale=0.5),
                        lat_reward(3.0, 0.0, scale=5.0),
                        'scale 越小应越快饱和')

    def test_explicit_args_beat_env(self):
        os.environ['DSH_LAT_SHAPE'] = 'quad'
        # 显式 shape 应优先于环境变量
        self.assertAlmostEqual(lat_reward(1.0, 0.0, shape='linear', scale=1.0, w=10.0),
                               -10.0, places=9)

    def test_target_offset(self):
        self.assertAlmostEqual(lat_reward(1.0, 1.0), 0.0, places=9)
        self.assertAlmostEqual(lat_reward(2.0, 1.0), lat_reward(1.0, 0.0), places=9)
        self.assertAlmostEqual(lat_reward(0.0, 1.0), lat_reward(1.0, 0.0), places=9)

    def test_invalid_scale_falls_back(self):
        """scale ≤ 0 或非法 ⇒ 回退默认值，不能抛异常/返回 nan。"""
        for bad in (0.0, -1.0):
            v = lat_reward(1.0, 0.0, scale=bad)
            self.assertTrue(math.isfinite(v), f'scale={bad} 时结果应为有限值')
        self.assertTrue(math.isfinite(lat_reward(1.0, 0.0, scale=float('nan'))))

    def test_bad_input_does_not_raise(self):
        """非法输入不能抛异常（该函数在每帧热路径上）。"""
        for bad in ('x', None):
            try:
                lat_reward(bad, 0.0)
            except (TypeError, ValueError):
                self.fail(f'输入 {bad!r} 不应抛异常')


if __name__ == '__main__':
    unittest.main(verbosity=2)
