"""Road membership must use public nonprojected map queries and the body box."""
from types import SimpleNamespace as S
import unittest
import numpy as np

try:
    from Planning_library.road_corridor_v23 import RoadCorridor
except ImportError:
    RoadCorridor = None


class RoadCorridorTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(RoadCorridor, 'Public drivable-road audit is missing')
        return RoadCorridor

    def lookup(self, x, y):
        return None if abs(y) > 2. else (1, 0, -1)

    def test_inside_center_does_not_hide_body_corners_outside_the_road(self):
        c = self.api()(self.lookup, [(1, 0, -1)])
        self.assertTrue(c.audit([[5., 0., 0.]], 4., 1.8)['accepted'])
        r = c.audit([[5., 1.4, 0.]], 4., 1.8)
        self.assertFalse(r['accepted'])
        self.assertEqual(r['reason'], 'outside_driving_surface')

    def test_full_body_in_an_unrelated_driving_lane_is_not_an_allowed_route(self):
        c = self.api()(lambda x, y: (2, 0, 1), [(1, 0, -1)])
        self.assertFalse(c.audit([[5., 0., 0.]], 4., 1.8)['accepted'])

    def test_between_sample_poses_is_checked_not_just_the_two_endpoints(self):
        c = self.api()(lambda x, y: None if 4.8 < x < 5.2 else (1, 0, -1), [(1, 0, -1)])
        self.assertFalse(c.audit([[0., 0., 0.], [10., 0., 0.]], .2, .2)['accepted'])

    def test_map_errors_or_nonfinite_poses_fail_closed(self):
        def broken(x, y):
            raise RuntimeError('map unavailable')
        c = self.api()(broken, [(1, 0, -1)])
        self.assertFalse(c.audit([[5., 0., 0.]], 4., 1.8)['accepted'])
        self.assertFalse(c.audit([[float('nan'), 0., 0.]], 4., 1.8)['accepted'])

    def test_adapter_never_projects_an_offroad_point_back_to_a_driving_lane(self):
        self.api()
        class Map:
            def get_waypoint(self, location, project_to_road=True, lane_type=None):
                if project_to_road or abs(location.y) <= 2.:
                    return S(road_id=1, section_id=0, lane_id=-1)
                return None
        c = RoadCorridor.from_carla(Map(), lambda **kw: S(**kw), 'Driving',
                                   np.array([[0., 0.], [30., 0.]]), 0.)
        self.assertFalse(c.audit([[5., 5., 0.]], 4., 1.8)['accepted'])


if __name__ == '__main__':
    unittest.main()
