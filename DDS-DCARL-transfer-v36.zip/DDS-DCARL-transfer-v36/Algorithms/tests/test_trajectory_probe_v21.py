"""Real candidate/guard tests for the isolated trajectory experiment."""
import contextlib
import io
import math
from types import SimpleNamespace as S
import unittest

import numpy as np

try:
    from Planning_library.trajectory_probe_v21 import TrajectoryProbeV21
except ImportError:
    TrajectoryProbeV21 = None

from Planning_library.matrix_turn_game import solve_candidates
from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
from test_forecast_v18 import vehicle


class TrajectoryProbeTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(TrajectoryProbeV21, 'The isolated multi-trajectory probe is missing')
        return TrajectoryProbeV21

    def fixture(self, mode='observe'):
        Type = self.api()
        from Agent.game_theory.MPC import MPCController
        path = np.array([[6., y] for y in np.linspace(-110., -160., 101)])
        ego = vehicle(1, 6., -120., -math.pi/2, 2., .1)
        rv = vehicle(2, 40., -138., math.pi, 4., 0.)
        dynamic = S(ego_vehicle=ego, objects=[rv],
                    lanes=[S(front_vehicles=[], rear_vehicles=[])])
        geometry = dict(wheelbase=2.86, max_steer=.6, execution_horizon=6.,
            forecast_model='route_v18', forecast_route=path.tolist(), navigation_end_is_stop=False)
        with contextlib.redirect_stdout(io.StringIO()):
            controllers = [MPCController(N=16, dt=.05, d_safe=2.7, thw_min=.5,
                enable_lead_follow_cost=False, enable_boundary_thw=False, enable_cournot_cost=False,
                cost_profile='paper_v11', step_dts=[.05]*6+[.2]*10,
                vehicle_geometry=dict(l_f=1.43, l_r=1.43, max_steer=.6)) for _ in range(4)]
            controllers[0].reset_global_path(path, dynamic)
            seed = Type.capture(controllers[0])
            cs = solve_candidates(controllers[0], controllers[1], dynamic, 4., 2., False,
                                  (6., -138.), True)
        game = MatrixTurnGameV18(geometry)
        conf = dict(rv_veh=rv, conflict_x=6., conflict_y=-138.)
        game.prepare(ego, [rv], conf, 4., 14., (-21., -138.5, math.pi))
        selected = game.choose(ego, [rv], rv, conf, cs, path, seed['previous'])
        probe = Type(mode, geometry, controllers[2:])
        return probe, dynamic, cs, selected, game, seed, controllers

    def request(self, fixture, selected=None):
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        with contextlib.redirect_stdout(io.StringIO()):
            output = probe.propose(dynamic, cs, baseline if selected is None else selected,
                game.last, seed, False, (6., -138.))
        return output

    def test_observe_does_not_change_original_choice_controls_or_solver_memory(self):
        fixture = self.fixture()
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        original = [(c['a'], c['delta'], c['target'], c['controller'].last_u.copy(),
                     c['controller']._warm_controls.copy()) for c in cs]
        output = self.request(fixture)
        self.assertIs(output[baseline], cs[baseline])
        self.assertEqual(probe.last['request_id'], ('defer_base', 'proceed_base')[baseline])
        self.assertFalse(probe.last['changed_request'])
        self.assertEqual(len(probe.last['candidates']), 4)
        for c, old in zip(cs, original):
            self.assertEqual((c['a'], c['delta'], c['target'], c['controller'].last_u), old[:4])
            np.testing.assert_array_equal(c['controller']._warm_controls, old[4])

    def test_same_proceed_intent_can_request_a_different_real_mpc_trajectory(self):
        fixture = self.fixture('proceed')
        output = self.request(fixture, selected=1)
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        self.assertEqual(probe.last['request_id'], 'proceed_slow')
        self.assertEqual(output[1]['target'], 3.)
        self.assertTrue(probe.last['changed_request'])
        self.assertTrue(output[1]['solve_ok'])
        self.assertEqual(output[1]['prediction'].shape, (7, 17))
        self.assertGreater(np.max(np.abs(output[1]['prediction']-cs[1]['prediction'])), .01)
        self.assertIs(output[0], cs[0])

    def test_defer_variant_preserves_defer_intent_and_cannot_increase_the_speed_cap(self):
        fixture = self.fixture('defer')
        output = self.request(fixture, selected=0)
        self.assertEqual(fixture[0].last['request_id'], 'defer_slow')
        self.assertEqual(output[0]['target'], 1.5)
        self.assertIs(output[1], fixture[2][1])

    def test_a_proceed_probe_never_overrides_a_defer_intent(self):
        fixture = self.fixture('proceed')
        output = self.request(fixture, selected=0)
        self.assertIs(output[0], fixture[2][0])
        self.assertFalse(fixture[0].last['changed_request'])

    def test_guard_rejection_keeps_the_default_and_preserves_rejection_evidence(self):
        fixture = self.fixture('proceed')
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        # Occupying the very same body is an independently obvious collision.
        dynamic.objects = [vehicle(3, 6., -120., -math.pi/2, 0., 0.)]
        output = self.request(fixture, selected=1)
        self.assertIs(output[1], cs[1])
        slow = next(c for c in probe.last['candidates'] if c['id']=='proceed_slow')
        self.assertFalse(slow['execution']['accepted'])
        self.assertFalse(probe.last['changed_request'])

    def test_response_columns_use_the_selected_observed_rv(self):
        fixture = self.fixture()
        self.request(fixture)
        variants = [c for c in fixture[0].last['candidates'] if c['id'].endswith('_slow')]
        self.assertTrue(variants)
        for candidate in variants:
            for part in candidate['components']:
                self.assertTrue(any(a['primary'] and a['actor_id']==2 for a in part['actors']))

    def test_forced_stop_and_inactive_frames_do_not_invent_alternatives(self):
        for reason in ('inactive', 'forced_stop'):
            fixture = self.fixture('proceed')
            if reason=='inactive':
                fixture[4].last['active'] = False
            else:
                fixture[2][1]['controller'].geometry_force_stop = True
            output = self.request(fixture, selected=1)
            self.assertIs(output[1], fixture[2][1])
            self.assertEqual(len(fixture[0].last['candidates']), 2)
            self.assertEqual(fixture[0].last['skip_reason'], reason)

    def test_zero_target_is_not_relabelled_as_a_new_moving_defer(self):
        fixture = self.fixture('defer')
        fixture[2][0]['target'] = 0.
        output = self.request(fixture, selected=0)
        self.assertIs(output[0], fixture[2][0])
        self.assertNotIn('defer_slow', [c['id'] for c in fixture[0].last['candidates']])

    def test_controller_activation_and_feedback_include_the_chosen_variant(self):
        fixture = self.fixture('proceed')
        output = self.request(fixture, selected=1)
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        current = cs[1]['controller']
        chosen = output[1]['controller']
        self.assertIs(probe.activate(current, chosen), chosen)
        self.assertIn(current, probe.controllers)
        self.assertNotIn(chosen, probe.controllers)
        probe.acknowledge(-.2, .01)
        self.assertTrue(all(c.last_u == dict(a=-.2, df=.01) for c in probe.controllers))
        probe.reset()
        self.assertIsNone(probe.last)

    def test_raw_motion_and_prediction_are_retained_for_later_model_checks(self):
        fixture = self.fixture()
        self.request(fixture)
        row = fixture[0].last
        self.assertIn('acc_source', row['observation']['ego'], 'Original observation evidence is not retained')
        self.assertEqual(row['observation']['ego']['acc_source'], 'velocity_difference')
        self.assertGreater(row['observation']['ego']['length'], 0.)
        self.assertEqual(row['path'][0], [6., -110.])
        for c in row['candidates']:
            self.assertEqual(len(c['prediction']), 7)
            self.assertEqual(len(c['prediction'][0]), 17)
            self.assertAlmostEqual(c['prediction'][0][0], 6.)
            self.assertAlmostEqual(c['prediction'][1][0], -120.)
            self.assertEqual(len(c['plan'][0]), 16)
            self.assertAlmostEqual(c['times'][-1], 2.3)


if __name__ == '__main__':
    unittest.main()
