#!/usr/bin/env python3
"""【P4-①】进入判据：最坏情况到达时间 + 占用窗口不重叠（纯 stdlib，无 CARLA）。

修的是两个实测到的漏洞：
  漏洞1（只看第一辆晚到车）：旧判据 `t_rv − t_ego_go ≥ clearance` 只检查**第一个晚于
    自车到达的车**。它漏掉：① 对方早于自车到但**还没清空**；② 落进占用窗的**其它**车辆。
  漏洞2（匀速假设）：`t_veh = |x−x_c|/v` 是匀速估计。对一辆"已让行到 1.3 m/s"的 RV
    给出 ~7 s（看似极安全），但 RV 每 2 s 会重新决策，随时可能加速回巡航 4.41 m/s
    ⇒ 真实到达只有 ~2.6 s。旧判据系统性高估安全裕度。
"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.boundary_safety import (
    entry_gap_is_safe, worst_case_arrival_time, entry_clearance_time,
)
from Planning_library.rv_decision import time_to_cover

INF = float("inf")


class TestEntryGapIsSafe(unittest.TestCase):

    def test_no_vehicle_is_safe(self):
        self.assertTrue(entry_gap_is_safe(2.0, [], 3.0))
        self.assertTrue(entry_gap_is_safe(2.0, [INF], 3.0))

    def test_vehicle_arrives_after_i_clear_is_safe(self):
        # 我占用 [2,5]；车 6.0 到 -> 安全
        self.assertTrue(entry_gap_is_safe(2.0, [6.0], 3.0))

    def test_vehicle_inside_my_window_is_unsafe(self):
        # 我占用 [2,5]；车 4.0 到 -> 撞进我的窗
        self.assertFalse(entry_gap_is_safe(2.0, [4.0], 3.0))
        self.assertFalse(entry_gap_is_safe(2.0, [2.0], 3.0))   # 同时到
        self.assertFalse(entry_gap_is_safe(2.0, [4.999], 3.0))

    def test_earlier_vehicle_not_yet_cleared_is_unsafe(self):
        """漏洞1①：对方早于我到达，但还没清空 -> 旧判据漏判。"""
        # 车 1.0 到，自身占用 1.0 s（到 2.0）；我开始进 2.0 -> 恰好紧贴 -> 不安全（>）
        self.assertFalse(entry_gap_is_safe(2.0, [1.0], 3.0, veh_clear_time=1.5))
        # 车 0.0 到，1.0 清空；我开始进 2.0 -> 安全
        self.assertTrue(entry_gap_is_safe(2.0, [0.0], 3.0, veh_clear_time=1.0))

    def test_other_vehicle_falls_in_window(self):
        """漏洞1②：不是被选中的那辆 RV，但其它的车落进占用窗。"""
        self.assertFalse(entry_gap_is_safe(2.0, [10.0, 3.5], 3.0))
        self.assertTrue(entry_gap_is_safe(2.0, [10.0, 12.0], 3.0))

    def test_degenerate_inputs_are_unsafe(self):
        self.assertFalse(entry_gap_is_safe(INF, [5.0], 3.0))
        self.assertFalse(entry_gap_is_safe('x', [5.0], 3.0))
        self.assertFalse(entry_gap_is_safe(1.0, [5.0], -1.0))


class TestWorstCaseArrival(unittest.TestCase):

    def test_rush_from_yield_is_much_sooner_than_constant_velocity(self):
        """核心：一辆已让行到 1.32 m/s 的 RV，最坏情况到达远早于匀速估计。"""
        d, v_now, v_rush = 9.2, 1.32, 4.41
        t_cv = d / v_now                      # 匀速假设
        t_worst = worst_case_arrival_time(time_to_cover, d, v_now, v_rush, 2.0, 3.0)
        self.assertAlmostEqual(t_cv, 6.97, places=1)
        self.assertLess(t_worst, 3.5, "抢行假设下应显著更早到达")
        self.assertLess(t_worst, t_cv / 2.0, "至少应小于匀速估计的一半")

    def test_never_earlier_than_accel_limited_physics(self):
        """最坏情况不能比"立刻以抢行速度匀速"更早（物理下界）。"""
        d, v_now, v_rush = 20.0, 1.0, 4.41
        t_worst = worst_case_arrival_time(time_to_cover, d, v_now, v_rush, 2.0, 3.0)
        self.assertGreaterEqual(t_worst, d / v_rush - 1e-6)

    def test_already_at_cruise_equals_constant_velocity(self):
        d, v = 20.0, 4.41
        t = worst_case_arrival_time(time_to_cover, d, v, v, 2.0, 3.0)
        self.assertAlmostEqual(t, d / v, places=6)

    def test_bad_input_returns_inf(self):
        self.assertEqual(worst_case_arrival_time(time_to_cover, 'x', 1, 2, 2.0), INF)


class TestInteractionWithClearance(unittest.TestCase):
    """两条判据合起来的语义：必须"对抢行也安全"才算间隙足够。"""

    def test_yielding_vehicle_now_blocks_entry_it_used_to_allow(self):
        t_ego_go = 2.55                     # arc 10.2m / 4 m/s
        clr = entry_clearance_time(4.0, ego_len=4.5, band=4.0, margin=1.0)   # 3.125
        d, v_now, v_rush = 9.2, 1.32, 4.41
        t_cv = d / v_now                                    # 6.97 -> 旧判据放行
        t_worst = worst_case_arrival_time(time_to_cover, d, v_now, v_rush, 2.0, 3.0)
        self.assertTrue(entry_gap_is_safe(t_ego_go, [t_cv], clr),
                        "按匀速估计，旧判据会放行")
        self.assertFalse(entry_gap_is_safe(t_ego_go, [t_worst], clr),
                         "按抢行最坏情况，必须拦住 —— 这正是 expJ 里 32% 的赌输/侧刮")


if __name__ == "__main__":
    unittest.main()
