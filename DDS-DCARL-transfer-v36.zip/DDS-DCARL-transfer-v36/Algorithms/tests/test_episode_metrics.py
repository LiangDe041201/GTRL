#!/usr/bin/env python3
"""阶段 1：回合边界指标记录纯函数（build_episode_metrics_record）的单元测试。

导入 dds_dcarl_turn 需要 casadi/sympy（训练环境自带）；缺失时跳过（skipTest）。
"""
import math
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

try:
    from Agent.drl_library.dds_dcarl.dds_dcarl_turn import build_episode_metrics_record
    _IMPORT_OK = True
except ImportError as _e:
    _IMPORT_OK = False
    _IMPORT_ERR = str(_e)


@unittest.skipUnless(_IMPORT_OK, "dds_dcarl_turn 导入失败（缺 casadi/sympy?）")
class TestEpisodeMetrics(unittest.TestCase):

    def test_means_over_finite_only(self):
        rec = build_episode_metrics_record(1, [
            (2.0, float("inf"), 3.0, 2, 10, 0.5),
            (1.0, 0.5, 2.0, 1, 8, 1.0),
            (float("inf"), 1.5, float("inf"), 0, 5, 30.0),
        ], "complete")
        self.assertEqual(rec["episode"], 1)
        self.assertEqual(rec["n_frames"], 3)
        self.assertEqual(rec["terminal"], "complete")
        self.assertAlmostEqual(rec["lcttc_rv_mean"], 1.5)   # (2.0+1.0)/2
        self.assertAlmostEqual(rec["lcttc_fv_mean"], 1.0)   # (0.5+1.5)/2
        self.assertAlmostEqual(rec["thw_boundary_rv_mean"], 2.5)  # (3.0+2.0)/2
        self.assertAlmostEqual(rec["n_vehicles_mean"], 1.0)       # (2+1+0)/3
        self.assertAlmostEqual(rec["n_objects_mean"], 23.0 / 3.0)  # (10+8+5)/3
        self.assertAlmostEqual(rec["gap_mean"], 10.5)              # (0.5+1.0+30.0)/3

    def test_all_inf_yields_none(self):
        rec = build_episode_metrics_record(2, [(float("inf"), float("inf"), float("inf"), 0, 0, 30.0)], "stuck")
        self.assertIsNone(rec["lcttc_rv_mean"])
        self.assertIsNone(rec["lcttc_fv_mean"])
        self.assertIsNone(rec["thw_boundary_rv_mean"])
        self.assertAlmostEqual(rec["n_vehicles_mean"], 0.0)
        self.assertAlmostEqual(rec["n_objects_mean"], 0.0)
        self.assertAlmostEqual(rec["gap_mean"], 30.0)

    def test_empty_episode(self):
        rec = build_episode_metrics_record(3, [], "collision")
        self.assertEqual(rec["n_frames"], 0)
        self.assertIsNone(rec["lcttc_rv_mean"])
        self.assertIsNone(rec["n_vehicles_mean"])
        self.assertEqual(rec["terminal"], "collision")


if __name__ == "__main__":
    unittest.main()
