"""Real driver/MPC regression: shadow diagnostics cannot change learning."""
import contextlib
import copy
import io
import json
from pathlib import Path
import random
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import test_rolling_reference_v25 as fixtures
from Planning_library.execution_guard import select_execution
from Planning_library.trajectory_guard import execution_acceleration

try:
    from Planning_library.rolling_shadow_v27 import RollingShadowPlannerV27
except ImportError:
    RollingShadowPlannerV27=None


class RollingShadowTests(unittest.TestCase):
    def fixture(self,shadow=False,directory=None):
        fixture=fixtures.RollingReferenceTests().fixture('train')
        p,f,ns,path,codes=fixture
        if shadow:
            self.assertIsNotNone(RollingShadowPlannerV27,'No optional EFE observer on the actual rolling driver')
            p=RollingShadowPlannerV27('train',p.geometry,p.controllers,p.corridor,
                epsilon=1.,seed=7,directory=directory)
            ns['self'].trajectory_probe=p
        return p,f,ns,path,codes

    def frame(self,fixture,index,terminal=False):
        p,f,ns,path,(start,reset,dispatch)=fixture
        with contextlib.redirect_stdout(io.StringIO()):
            exec(start,ns)
            if index==1: exec(reset,ns)
            ns['_previous_control']=dict(ns['mpc_controller'].last_u)
            exec(dispatch,ns)
        c=ns['_choice']; controller=ns['mpc_controller']; previous=p.last['previous']
        selected,audit=select_execution(f[1].ego_vehicle,f[1].objects,c['path'],c['target'],
            execution_acceleration(c['a'],2.,c['target']),c['delta'],previous,p.geometry,
            prediction=c['prediction'],prediction_times=c['times'],plan=c['plan'])
        result=p.review_execution(controller,f[1].ego_vehicle,f[1].objects,previous,audit)
        if result is not None:
            controller,selected,audit=result['controller'],result['selected'],result['audit']
            ns['mpc_controller']=controller
        applied=dict(control_submit_ok=1,a_cmd=selected['a'],delta_rad=selected['delta'],
                     actuator_speed_target=selected['target'],ego_v_after=2.)
        controller.acknowledge_applied_control(selected['a'],selected['delta'])
        ns['matrix_peer'].acknowledge_applied_control(selected['a'],selected['delta'])
        p.acknowledge(selected['a'],selected['delta'])
        p.feedback(1,index,audit,applied,'complete' if terminal else None)
        request=copy.deepcopy(p.last['request'])
        request.pop('audit_profile',None)  # Wall-clock timers are expected to differ.
        return dict(action=p.last['actual_action'],request=request,
                    previous=copy.deepcopy(p.last['previous']),applied=applied,
                    guard_action=audit['action'],guard_override=audit['override'],
                    learning=copy.deepcopy(p.last['learning']),reward=p.last['feedback']['reward'])

    def test_shadow_preserves_real_driver_controls_rng_records_and_q_across_frames(self):
        base=self.fixture(); shadow=self.fixture(True)
        np_before=np.random.get_state(); py_before=random.getstate()
        for i in range(1,4):
            a=self.frame(base,i,terminal=i==3); b=self.frame(shadow,i,terminal=i==3)
            self.assertEqual(a,b)
            self.assertEqual(base[0].learner.records,shadow[0].learner.records)
            self.assertEqual(base[0].learner.q.keys(),shadow[0].learner.q.keys())
            for key in base[0].learner.q:
                np.testing.assert_array_equal(base[0].learner.q[key],shadow[0].learner.q[key])
            self.assertFalse(shadow[0].last['efe_shadow']['feedback']['reward_applied'])
            from Tools.validate_efe_shadow_v27 import validate_shadow_record
            ledger=shadow[0].efe_shadow
            meta=dict(ledger.metadata,model_sha256=ledger.model_hash)
            actual=b['applied']
            row=dict(shadow[1][4].last,rolling_trajectory=shadow[0].last,episode=1,frame=i,
                guard_action=b['guard_action'],guard_override=b['guard_override'],
                applied_a=actual['a_cmd'],applied_delta=actual['delta_rad'],
                applied_target=actual['actuator_speed_target'],control_submit_ok=1)
            self.assertEqual(validate_shadow_record(row,meta),{})
        np.testing.assert_array_equal(np.random.get_state()[1],np_before[1])
        self.assertEqual(np.random.get_state()[2:],np_before[2:])
        self.assertEqual(random.getstate(),py_before)

    def test_observer_failure_is_recorded_without_changing_requested_control_or_experience(self):
        base=self.fixture(); shadow=self.fixture(True)
        with patch.object(shadow[0].efe_shadow,'propose',side_effect=RuntimeError('model failure')):
            a=self.frame(base,1,True); b=self.frame(shadow,1,True)
        self.assertEqual(a,b)
        self.assertEqual(base[0].learner.records,shadow[0].learner.records)
        self.assertEqual(shadow[0].last['efe_shadow']['status'],'error')
        self.assertEqual(shadow[0].last['efe_shadow']['error_type'],'RuntimeError')

    def test_metadata_declares_shadow_uncalibrated_and_no_reward_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=self.fixture(True,Path(tmp))
            metadata=json.loads((Path(tmp)/'efe_shadow_metadata_v27.json').read_text(encoding='utf8'))
            self.assertEqual(metadata['mode'],'shadow')
            self.assertFalse(metadata['calibrated']); self.assertFalse(metadata['reward_applied'])
            self.frame(f,1,True)
            model=json.loads((Path(tmp)/'rolling_model/rolling_model.json').read_text(encoding='utf8'))
            self.assertEqual(model['signature']['reward'],'measured_task_v19_without_EFE')
            self.assertEqual(model['records'],f[0].learner.records)


if __name__=='__main__': unittest.main()
