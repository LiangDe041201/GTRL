#!/usr/bin/env python3
"""【0' 诊断】path_diagnostics 纯函数单元测试（纯 numpy，无 CARLA）。"""
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.path_diagnostics import (
    cumulative_arclength, discrete_curvature, spline_applicability,
    lateral_deviation, deviation_summary, param_vs_arclength_error,
    curvature_exceeds_limit,
)


def _circle(R=10.0, n=200, a0=0.0, a1=np.pi / 2):
    a = np.linspace(a0, a1, n)
    return np.stack([R * np.cos(a), R * np.sin(a)], axis=1)


class TestCumulativeArclength(unittest.TestCase):

    def test_line(self):
        p = np.array([[0.0, 0.0], [3.0, 0.0], [3.0, 4.0]])
        np.testing.assert_allclose(cumulative_arclength(p), [0.0, 3.0, 7.0])

    def test_degenerate(self):
        self.assertEqual(len(cumulative_arclength([])), 0)
        self.assertEqual(list(cumulative_arclength([[1.0, 1.0]])), [0.0])


class TestDiscreteCurvature(unittest.TestCase):

    def test_straight_line_is_zero(self):
        p = np.array([[float(i), 0.0] for i in range(10)])
        k, r = discrete_curvature(p)
        np.testing.assert_allclose(k, 0.0, atol=1e-12)
        self.assertTrue(np.all(np.isinf(r)))

    def test_circle_curvature_is_inverse_radius(self):
        for R in (5.0, 10.0, 25.0):
            k, r = discrete_curvature(_circle(R))
            # 圆周 |κ| = 1/R（端点用邻值，中间点应精确）
            np.testing.assert_allclose(np.abs(k[1:-1]), 1.0 / R, rtol=1e-3)
            np.testing.assert_allclose(r[1:-1], R, rtol=1e-3)

    def test_sign_follows_turn_direction(self):
        k_ccw, _ = discrete_curvature(_circle())
        k_cw, _ = discrete_curvature(_circle()[::-1])
        self.assertGreater(np.median(k_ccw[1:-1]), 0.0)
        self.assertLess(np.median(k_cw[1:-1]), 0.0)

    def test_too_few_points(self):
        k, r = discrete_curvature(np.array([[0.0, 0.0], [1.0, 1.0]]))
        np.testing.assert_allclose(k, 0.0)


class TestSplineApplicability(unittest.TestCase):

    def test_fine_sampling_on_circle_is_ok(self):
        """R=10，路点间距 2 -> Δs/R=0.2 < 0.5，判为适用。"""
        a = np.linspace(0.0, np.pi / 2, 8)      # 弧长 ~15.7m / 7 段 ≈ 2.2m
        p = np.stack([10 * np.cos(a), 10 * np.sin(a)], axis=1)
        s = spline_applicability(p)
        self.assertLess(s['max_ratio'], 0.5)
        self.assertEqual(s['n_over_1p0'], 0)

    def test_coarse_sampling_on_tight_curve_flags_overshoot(self):
        """Δs/R = 2·sin(Δa/2)，只取决于角度步长。

        3 点跨 150° -> Δa = 75° -> ratio = 1.22 > 1，应判为严重欠采样。
        """
        a = np.linspace(0.0, 5.0 * np.pi / 6.0, 3)      # Δa = 75°
        p = np.stack([3.0 * np.cos(a), 3.0 * np.sin(a)], axis=1)
        s = spline_applicability(p)
        self.assertAlmostEqual(s['max_ratio'], 2.0 * np.sin(np.radians(75) / 2), places=3)
        self.assertGreater(s['max_ratio'], 1.0)
        self.assertGreaterEqual(s['n_over_1p0'], 1)

    def test_ratio_is_independent_of_radius(self):
        """关键性质：同样的角度步长，R 变 10 倍，Δs/R 不变。"""
        for R in (2.0, 20.0):
            a = np.linspace(0.0, np.pi / 2.0, 4)        # Δa = 30°
            p = np.stack([R * np.cos(a), R * np.sin(a)], axis=1)
            self.assertAlmostEqual(spline_applicability(p)['max_ratio'],
                                   2.0 * np.sin(np.radians(30) / 2), places=3)

    def test_worst_idx_points_at_the_tight_part(self):
        # 前半直线（间距 2），后半 R=3 的紧弯（间距 2） -> 最差点应在后半
        line = np.array([[float(i) * 2.0, 0.0] for i in range(6)])
        a = np.linspace(-np.pi / 2, 0.0, 5)
        arc = np.stack([line[-1, 0] + 3 * np.cos(a), 3 + 3 * np.sin(a)], axis=1)
        p = np.vstack([line, arc[1:]])
        s = spline_applicability(p)
        self.assertGreater(s['worst_idx'], 4)


class TestLateralDeviation(unittest.TestCase):

    def test_offset_line(self):
        ref = np.array([[float(i), 0.0] for i in range(11)])
        q = np.array([[5.0, 2.0], [7.5, -1.5]])
        lat, ss = lateral_deviation(ref, q)
        np.testing.assert_allclose(lat, [2.0, 1.5], atol=1e-9)
        np.testing.assert_allclose(ss, [5.0, 7.5], atol=1e-9)

    def test_deviation_summary_reports_worst_s(self):
        ref = np.array([[float(i), 0.0] for i in range(11)])
        q = np.array([[1.0, 0.1], [9.0, 3.0]])
        d = deviation_summary(ref, q, label='t')
        self.assertAlmostEqual(d['lat_max'], 3.0, places=6)
        self.assertAlmostEqual(d['worst_s'], 9.0, places=6)
        self.assertEqual(d['label'], 't')

    def test_bad_input(self):
        lat, ss = lateral_deviation(np.array([[0.0, 0.0]]), np.array([[1.0, 1.0]]))
        self.assertEqual(len(lat), 1)


class TestParamVsArclength(unittest.TestCase):

    def test_consistent_when_param_is_true_arclength(self):
        ref = np.array([[float(i), 0.0] for i in range(11)])
        s = cumulative_arclength(ref)
        err, mx, rel = param_vs_arclength_error(ref, s)
        self.assertLess(mx, 1e-9)
        self.assertLess(rel, 1e-9)

    def test_detects_shortfall(self):
        # 参数比真实弧长少 30% -> 应报出系统性偏差
        ref = np.array([[float(i), 0.0] for i in range(11)])
        s = cumulative_arclength(ref) * 0.7
        err, mx, rel = param_vs_arclength_error(ref, s)
        self.assertGreater(mx, 2.0)
        self.assertAlmostEqual(rel, 0.3, places=6)


class TestCurvatureLimit(unittest.TestCase):

    def test_tight_circle_exceeds(self):
        over, mk, mr = curvature_exceeds_limit(_circle(3.0))
        self.assertTrue(over)
        self.assertAlmostEqual(mr, 3.0, places=2)

    def test_gentle_circle_ok(self):
        over, mk, mr = curvature_exceeds_limit(_circle(20.0))
        self.assertFalse(over)
        self.assertAlmostEqual(mr, 20.0, places=1)


if __name__ == "__main__":
    unittest.main()
