"""Exercise production CLI configuration and actual matrix dispatch AST."""
import ast
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace as S
import unittest

from Tools.run_relay_validation import main, ARMS
import test_trajectory_evolution_v22 as runtime_fixtures


class EvolutionDispatchTests(unittest.TestCase):
    def test_pilot_cannot_silently_reduce_the_frozen_trust_coverage_threshold(self):
        with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit):
                main(['--dry-run', '--arms', 'E1_train_v22', '--traffic-interaction', 'v17',
                      '--belief-min-episodes', '2'])

    def test_new_arms_use_one_isolated_learner_and_keep_the_frozen_physics(self):
        for arm, phase in [('E0_observe_v22', 'observe'), ('E1_train_v22', 'train'), ('E2_eval_v22', 'eval')]:
            self.assertIn(arm, ARMS, 'New trajectory evolution is not exposed to the remote launcher')
            output = io.StringIO()
            args = ['--dry-run', '--arms', arm, '--traffic-interaction', 'v17']
            if phase == 'eval':
                args += ['--evolution-checkpoint', 'future-model.json']
            with contextlib.redirect_stdout(output):
                self.assertEqual(main(args), 0)
            config = json.loads(output.getvalue())['effective']
            self.assertEqual(config['DSH_TRAJECTORY_EVOLUTION'], phase)
            self.assertEqual(config['DSH_COURNOT_MODE'], 'matrix_v18')
            self.assertEqual(config['DSH_FORECAST_MODEL'], 'route_v18')
            self.assertEqual(config['DSH_EFE'], '0')
            self.assertNotIn('DSH_TRAJECTORY_PROBE', config)

    def test_actual_driver_dispatch_records_new_owner_and_activates_the_chosen_solver(self):
        from Planning_library.matrix_turn_game import solve_candidates
        runtime, old = runtime_fixtures.EvolutionRuntimeTests().fixture(epsilon=1.)
        dynamic, cs, game = old[1], old[2], old[4]
        primary, peer = cs[1]['controller'], cs[0]['controller']
        for c in (primary, peer):
            c.acknowledge_applied_control(.1, 0.)
        # Same public context and real completed return records; no mock policy.
        context = runtime.context(dynamic, game.last, dict(a=.1, df=0.), 4.)
        l = runtime.learner
        l.begin(context, dict(alpha=1., beta=1.), 1, 1); l.select(.75, True, forced_ratio=1.); l.start(1.)
        l.reward(1.); l.finish()
        self_stub = S(dynamic_map=dynamic, trajectory_probe=runtime,
            env=S(goal_pose=(-21., -138.5, 3.14), INTERSECTION_CENTER=(6., -138.)),
            turn_feasibility=S(last={}))
        tree = ast.parse((Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf8'))
        blocks = [n for n in ast.walk(tree) if isinstance(n, ast.If)
            and any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == 'solve_candidates'
                    for c in ast.walk(n))]
        block = min(blocks, key=lambda n: len(list(ast.walk(n))))
        ns = dict(self=self_stub, mpc_controller=primary, matrix_peer=peer, matrix_game=game,
            v_ref=4., _sd=14., road_right=False, _conf=dict(rv_veh=dynamic.objects[0], conflict_x=6., conflict_y=-138.),
            _previous_control=dict(a=.1, df=0.), solve_candidates=solve_candidates)
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(ast.Module(body=[block], type_ignores=[]), '<production dispatch>', 'exec'), ns)
        self.assertIn('trajectory_evolution', game.last)
        self.assertNotIn('trajectory_probe', game.last)
        self.assertIs(ns['mpc_controller'], ns['_choice']['controller'])


if __name__ == '__main__':
    unittest.main()
