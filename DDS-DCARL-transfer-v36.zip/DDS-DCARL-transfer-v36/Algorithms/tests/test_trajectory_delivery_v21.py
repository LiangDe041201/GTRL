"""Exercise the production dispatch without importing the external CARLA runtime."""
import ast
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace as S
import unittest

from Tools.run_relay_validation import main as relay_main, ARMS


class TrajectoryDispatchTests(unittest.TestCase):
    def test_dry_run_arms_keep_the_same_cg_physics_and_disable_learning(self):
        for arm, mode in (('P0_observe_v21','observe'),('P1_defer_v21','defer'),('P2_proceed_v21','proceed')):
            self.assertIn(arm, ARMS, 'Trajectory probe arms are not wired into the remote runner')
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                code = relay_main(['--dry-run','--episodes','3','--seeds','31','--arms',arm,
                                   '--traffic-interaction','v17','--control-profile','paper_v11'])
            self.assertEqual(code,0)
            config = json.loads(stream.getvalue())['effective']
            self.assertEqual(config['DSH_TRAJECTORY_PROBE'],mode)
            self.assertEqual(config['DSH_METHOD'],'CG')
            self.assertEqual(config['DSH_COURNOT_MODE'],'matrix_v18')
            self.assertEqual(config['DSH_FORECAST_MODEL'],'route_v18')
            self.assertEqual((config['DSH_EFE'],config['DSH_WCV_BCV']),('0','0'))

    def test_the_real_matrix_dispatch_executes_the_selected_same_intent_variant(self):
        from test_trajectory_probe_v21 import TrajectoryProbeTests
        from Planning_library.matrix_turn_game import solve_candidates
        fixture = TrajectoryProbeTests().fixture('proceed')
        probe, dynamic, candidates, baseline, game, seed, controllers = fixture
        primary, peer = candidates[1]['controller'], candidates[0]['controller']
        for c in (primary,peer):c.acknowledge_applied_control(.1,0.)
        self_stub = S(dynamic_map=dynamic, trajectory_probe=probe,
                      env=S(goal_pose=(-21.,-138.5,3.14),INTERSECTION_CENTER=(6.,-138.)),
                      turn_feasibility=S(last={}))
        path = Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree = ast.parse(path.read_text(encoding='utf8'))
        blocks = [n for n in ast.walk(tree) if isinstance(n,ast.If)
                  and any(isinstance(c,ast.Call) and isinstance(c.func,ast.Name)
                          and c.func.id=='solve_candidates' for c in ast.walk(n))]
        block = min(blocks,key=lambda n:len(list(ast.walk(n))))
        ns = dict(self=self_stub,mpc_controller=primary,matrix_peer=peer,matrix_game=game,
                  v_ref=4.,_sd=14.,road_right=False,_conf=dict(rv_veh=dynamic.objects[0],conflict_x=6.,conflict_y=-138.),
                  _previous_control=dict(a=.1,df=0.),solve_candidates=solve_candidates)
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(ast.Module(body=[block],type_ignores=[]),'<actual matrix dispatch>','exec'),ns)
        self.assertIsNotNone(probe.last,'The candidate probe was calculated but never called by the driver')
        self.assertEqual(probe.last['request_id'],'proceed_slow')
        self.assertEqual(ns['v_ref'],3.)
        self.assertIs(ns['mpc_controller'],ns['_choice']['controller'])
        self.assertEqual(game.last['trajectory_probe']['request_id'],'proceed_slow')


if __name__=='__main__':unittest.main()
