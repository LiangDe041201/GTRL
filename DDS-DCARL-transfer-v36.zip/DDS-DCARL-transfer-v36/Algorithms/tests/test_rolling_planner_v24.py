"""Real MPC, receding decisions and post-guard action credit."""
import contextlib
import io
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
import numpy as np
import test_trajectory_probe_v21 as fixtures
from Planning_library.road_corridor_v24 import RoadCorridorV24

try:
    from Planning_library.rolling_planner_v24 import RollingPlannerV24
except ImportError:
    RollingPlannerV24=None


class RollingPlannerTests(unittest.TestCase):
    def fixture(self,phase='fixed',lookup=None):
        self.assertIsNotNone(RollingPlannerV24,'Rolling actions do not reach the real candidate/MPC chain')
        f=fixtures.TrajectoryProbeTests().fixture('observe')
        from Agent.game_theory.MPC import MPCController
        with contextlib.redirect_stdout(io.StringIO()):
            pool=[MPCController(N=16,dt=.05,d_safe=2.7,thw_min=.5,
                enable_lead_follow_cost=False,enable_boundary_thw=False,enable_cournot_cost=False,
                cost_profile='paper_v11',step_dts=[.05]*6+[.2]*10,
                vehicle_geometry=dict(l_f=1.43,l_r=1.43,max_steer=.6)) for _ in range(5)]
        corridor=RoadCorridorV24(lookup or (lambda x,y:dict(lane=[1,0,-1],junction=None,is_junction=False,width=3.5)),[(1,0,-1)],[])
        p=RollingPlannerV24(phase,f[0].geometry,pool,corridor,epsilon=1.,seed=7)
        return p,f

    def request(self,p,f,selected=1):
        with contextlib.redirect_stdout(io.StringIO()):
            return p.propose(f[1],f[2],selected,f[4].last,f[5],False,(6.,-138.))

    def feedback(self,p,episode=1,frame=1,outcome=None):
        request=p.last['request']
        return p.feedback(episode,frame,dict(action='mpc',override=False,unavoidable=False),
            dict(control_submit_ok=1,a_cmd=request['a'],delta_rad=request['delta'],
                 actuator_speed_target=request['target'],ego_v_after=2.),outcome)

    def test_observe_preserves_cg_controls_while_building_a_real_six_action_pool(self):
        p,f=self.fixture('observe'); original=f[2][1]['controller'].last_pathway.copy()
        out=self.request(p,f)
        self.assertIs(out[1],f[2][1])
        self.assertEqual({c['action'] for c in p.last['candidates']},set(range(6)))
        self.assertTrue(all(c['solve_ok'] for c in p.last['candidates']))
        np.testing.assert_array_equal(f[2][1]['controller'].last_pathway,original)
        self.assertEqual(p.last['actual_action'],0)

    def test_next_upper_decision_rebuilds_paths_at_the_new_observed_position(self):
        p,f=self.fixture('train'); self.request(p,f); self.feedback(p)
        first=p.last['generation']['anchor']['x']
        f[1].ego_vehicle.x+=.1; p.age=.5
        self.request(p,f)
        self.assertTrue(p.last['decision'])
        self.assertGreater(p.last['generation']['anchor']['x'],first)
        self.assertGreater(p.last['generation_id'],1)
        self.assertTrue(p.learner.records)
        self.assertIsNotNone(p.learner.records[0]['next'])

    def test_map_rejected_proposals_never_gain_control_or_realized_experience(self):
        p,f=self.fixture('train',lookup=lambda x,y:None)
        out=self.request(p,f); self.feedback(p,outcome='complete')
        self.assertIs(out[1],f[2][1])
        self.assertEqual(p.last['allowed'],[0])
        self.assertEqual(p.learner.records[-1]['action'],0)
        self.assertEqual(p.last['changed_request'],False)

    def test_final_guard_retraction_restores_cg_and_credits_cg_instead_of_unexecuted_path(self):
        p,f=self.fixture('train')
        out=self.request(p,f)
        self.assertTrue(p.last['changed_request'],'Coverage exploration should select an eligible nondefault')
        original=f[2][1]['controller']; chosen=out[1]['controller']
        current=p.activate(original,chosen)
        result=p.review_execution(current,f[1].ego_vehicle,f[1].objects,f[5]['previous'],
                                  dict(action='brake',override=True,safe=True))
        self.assertIs(result['controller'],original)
        self.assertEqual(p.last['actual_action'],0)
        self.feedback(p,outcome='complete')
        self.assertEqual(p.learner.records[-1]['action'],0)
        self.assertTrue(p.last['retracted'])

    def test_defer_geometry_does_not_supply_a_foreign_path_to_clear_backup(self):
        p,f=self.fixture('train'); out=self.request(p,f,selected=0)
        self.assertEqual(out[0]['target'],f[2][0]['target'])
        self.assertTrue(p.last['changed_request'])
        self.assertTrue(p.last['disable_foreign_clear_backup'])
        self.assertIs(out[1],f[2][1])

    def test_terminal_checkpoint_contains_only_completed_realized_options(self):
        p,f=self.fixture('train')
        with tempfile.TemporaryDirectory() as t:
            p.directory=Path(t)
            self.request(p,f); self.feedback(p,outcome='complete')
            self.assertTrue((Path(t)/'rolling_model/rolling_model.json').is_file())
            self.assertIsNone(p.learner.records[-1]['next'])
            self.assertIsNone(p.learner.pending)

    def test_invalidated_held_action_replans_next_frame_instead_of_waiting_another_full_period(self):
        p,f=self.fixture('train'); self.request(p,f); self.feedback(p)
        self.assertTrue(p.last['changed_request'])
        generation=p.generation_id
        f[4].last['active']=False
        self.request(p,f); self.feedback(p,frame=2)
        self.assertTrue(p.last['invalidated'])
        f[4].last['active']=True; f[1].ego_vehicle.x+=.05
        self.request(p,f)
        self.assertTrue(p.last['decision'])
        self.assertGreater(p.generation_id,generation)


if __name__=='__main__': unittest.main()
