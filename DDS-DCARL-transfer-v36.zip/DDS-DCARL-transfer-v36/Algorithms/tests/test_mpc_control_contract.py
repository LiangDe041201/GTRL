"""The planner-to-environment contract is signed acceleration in m/s^2."""
import ast
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    from Agent.game_theory.MPC import MPCController
except ImportError:
    MPCController = None


@unittest.skipIf(MPCController is None, 'Controller checks require CasADi')
class TestControlContract(unittest.TestCase):
    def controller(self, speed, previous_acceleration):
        ego = SimpleNamespace(x=0., y=0., yaw=0., v=speed)
        lane = SimpleNamespace(front_vehicles=[], rear_vehicles=[])
        dynamic_map = SimpleNamespace(ego_vehicle=ego, lanes=[lane])
        controller = MPCController(3, .05, 2.7, .5, enable_lead_follow_cost=False)
        controller.reset_global_path(np.column_stack((np.arange(40.), np.zeros(40))), dynamic_map)
        controller.last_u = dict(a=previous_acceleration, df=0.)
        return controller, dynamic_map

    def environment_control(self, acceleration, steering):
        # Execute the original environment's control conversion through apply_control.
        path = ROOT / 'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CarEnv_Town03_Turn')
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'step')
        # Legacy pedal conversion is now the explicit alternative to native
        # Ackermann execution. Test that production branch without a CARLA world.
        dispatch = next(node for node in method.body if isinstance(node, ast.If) and
                        any(isinstance(n, ast.Attribute) and n.attr == 'apply_ackermann_control'
                            for n in ast.walk(node)))
        assignment = next(node for node in method.body if isinstance(node, ast.Assign) and
                          any(isinstance(t, ast.Name) and t.id == 'a_cmd' for t in node.targets))
        body = [assignment] + dispatch.orelse
        fn = ast.FunctionDef(name='convert', args=method.args, body=body,
                             decorator_list=[], returns=None)
        namespace = dict(np=np, carla=SimpleNamespace(VehicleControl=lambda **kw: kw))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])),
                     str(path), 'exec'), namespace)
        captured = []
        env = SimpleNamespace(ego_vehicle=SimpleNamespace(apply_control=captured.append))
        namespace['convert'](env, [acceleration, steering])
        return captured[0]

    def test_optimized_deceleration_reaches_environment_as_braking(self):
        controller, dynamic_map = self.controller(5., -1.)
        acceleration, steering = controller.solve(dynamic_map, 0., False)
        self.assertTrue(controller._solve_ok)
        self.assertLess(controller.last_a_cmd, 0.)
        self.assertAlmostEqual(acceleration, controller.last_a_cmd)
        control = self.environment_control(acceleration, steering)
        self.assertEqual(control['throttle'], 0.)
        self.assertGreater(control['brake'], 0.)

    def test_optimized_acceleration_is_not_converted_twice(self):
        controller, dynamic_map = self.controller(1., .1)
        acceleration, _ = controller.solve(dynamic_map, 5., False)
        self.assertTrue(controller._solve_ok)
        self.assertGreater(controller.last_a_cmd, 0.)
        self.assertAlmostEqual(acceleration, controller.last_a_cmd)

    def test_solver_fallback_preserves_negative_acceleration(self):
        controller, dynamic_map = self.controller(5., 0.)
        with patch.object(controller.opti, 'solve', side_effect=RuntimeError('offline fallback probe')):
            acceleration, steering = controller.solve(dynamic_map, 0., False)
        self.assertFalse(controller._solve_ok)
        self.assertLess(acceleration, 0.)
        self.assertAlmostEqual(acceleration, controller.last_a_cmd)
        self.assertGreater(self.environment_control(acceleration, steering)['brake'], 0.)


if __name__ == '__main__':
    unittest.main()
