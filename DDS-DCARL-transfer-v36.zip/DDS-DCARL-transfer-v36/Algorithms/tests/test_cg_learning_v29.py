"""CG remains the behavioral baseline; geometry is context, never authority."""
import json
import math
from pathlib import Path
import tempfile
import unittest

import numpy as np

try:
    from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
except ImportError:CGTrajectoryLearnerV29=None


class CGTrajectoryLearningTests(unittest.TestCase):
    def learner(self,**kwargs):
        self.assertIsNotNone(CGTrajectoryLearnerV29,'No CG-baseline trajectory learner')
        return CGTrajectoryLearnerV29(**kwargs)

    def begin(self,l,costs=None,episode=1,allowed=(0,1)):
        return l.begin([0.]*16,dict(alpha=1.,beta=1.),0,list(allowed),
            [10.,0.,2.,3.,4.,5.] if costs is None else costs,episode)

    def test_no_experience_uses_cg_even_when_another_path_is_geometrically_cheaper(self):
        l=self.learner();self.begin(l)
        self.assertEqual(l.choose(),0)
        self.assertEqual(l.last['source'],'cg_default')
        self.assertEqual(l.nodes[l.current]['default'],0)
        self.assertEqual(l.nodes[l.current]['proposal_geometry_stratum'],1)

    def test_reference_is_positive_and_neutral_without_removing_information_cost(self):
        l=self.learner();self.begin(l,allowed=(0,1,5))
        np.testing.assert_array_equal(l.nodes[l.current]['prior'],[1/3.,1/3.,0.,0.,0.,1/3.])
        self.assertAlmostEqual(l.bounds(0)['information_cost'],.1*math.log(3.))
        self.assertAlmostEqual(l.bounds(1)['information_cost'],.1*math.log(3.))
        self.assertEqual(l.signature()['alpha'],.1)
        self.assertEqual(l.signature()['min_episodes'],10)

    def test_geometry_stratum_remains_in_key_to_avoid_silent_state_pooling(self):
        l=self.learner();a=self.begin(l)
        b=self.begin(l,costs=[0.,10.,2.,3.,4.,5.])
        self.assertNotEqual(a,b)
        self.assertEqual(json.loads(a)[2],1)
        self.assertEqual(json.loads(b)[2],0)
        self.assertEqual(l.choose(),0)

    def test_only_independent_episode_evidence_can_enable_a_better_trajectory(self):
        l=self.learner()
        for ep in range(1,25):
            self.begin(l,episode=ep);action=0 if ep<=12 else 1
            l.start(action);l.reward(.01 if action==0 else .1);l.finish()
        self.assertEqual(l.choose(),1)
        self.assertEqual(l.last['source'],'takeover')
        self.assertEqual(l.last['baseline_action'],0)
        self.assertEqual(l.bounds(0)['n'],12);self.assertEqual(l.bounds(1)['n'],12)

    def test_repetitions_in_one_episode_do_not_create_a_trusted_takeover(self):
        l=self.learner()
        for i in range(30):
            self.begin(l,episode=1);l.start(i%2);l.reward(.1 if i%2 else .01);l.finish()
        self.assertEqual(l.bounds(0)['n'],1);self.assertEqual(l.bounds(1)['n'],1)
        self.assertEqual(l.choose(),0)

    def test_geometric_default_cannot_be_passed_as_the_new_baseline(self):
        l=self.learner()
        with self.assertRaises(ValueError):l.begin([0.]*16,dict(alpha=1.,beta=1.),1,[0,1],[0.]*6,1)
        with self.assertRaises(ValueError):l.begin([0.]*16,dict(alpha=1.,beta=1.),0,[1],[0.]*6,1)

    def test_old_signature_is_rejected_and_frozen_new_model_never_updates_q(self):
        from Planning_library.rolling_learning_v24 import RollingLearner
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'model.json';old=RollingLearner();old.save(path)
            with self.assertRaises(ValueError):self.learner(phase='eval',checkpoint=path)
            l=self.learner();self.begin(l);l.start(0);l.reward(.03);l.finish();l.save(path)
            frozen=self.learner(phase='eval',checkpoint=path);before=path.read_bytes()
            key=self.begin(frozen);q=frozen.q[key].copy();frozen.start(0);frozen.reward(100.);frozen.finish()
            np.testing.assert_array_equal(frozen.q[key],q)
            self.assertEqual(path.read_bytes(),before)


if __name__=='__main__':unittest.main()
