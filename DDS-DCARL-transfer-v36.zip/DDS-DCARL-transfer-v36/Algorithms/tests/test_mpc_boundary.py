"""Numerical equivalence and optimizer sensitivity of the MPC boundary cost."""
import math
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import casadi as ca
except ImportError:
    ca = None

from Planning_library.boundary_safety import boundary_metrics


@unittest.skipIf(ca is None, 'MPC boundary checks require CasADi')
class TestSymbolicBoundary(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from Planning_library.mpc_boundary import boundary_thw
        z = ca.MX.sym('boundary_state', 11)
        value = boundary_thw(*[z[i] for i in range(11)])
        cls.evaluate = ca.Function('boundary_thw_check', [z], [value, ca.jacobian(value, z)])

    def test_matches_existing_numeric_rectangle_model(self):
        rng = np.random.default_rng(76)
        for _ in range(80):
            z = np.array([*rng.uniform(-4., 4., 2), rng.uniform(-math.pi, math.pi),
                          rng.uniform(.2, 8.), *rng.uniform(-10., 10., 2),
                          rng.uniform(-math.pi, math.pi),
                          rng.uniform(3., 5.), rng.uniform(1.5, 2.3),
                          rng.uniform(3., 5.), rng.uniform(1.5, 2.3)])
            expected = boundary_metrics(*z[:7], 0., ego_len=z[7], ego_wid=z[8],
                                        veh_len=z[9], veh_wid=z[10])['thw_boundary']
            value, _ = self.evaluate(z)
            self.assertAlmostEqual(float(value), expected, delta=1e-6 * max(1., expected))

    def test_contact_and_standstill_have_finite_values_and_derivatives(self):
        for x, y, speed in ((0., 0., 0.), (4.25, 0., 0.), (6., 0., 0.), (6., .7, 5.)):
            value, gradient = self.evaluate([0., 0., 0., speed, x, y, .1, 4.5, 2., 4., 2.])
            self.assertTrue(np.isfinite(float(value)))
            self.assertTrue(np.isfinite(np.asarray(gradient)).all())

    def test_approach_cost_depends_on_ego_pose_and_speed(self):
        from Planning_library.mpc_boundary import boundary_thw
        ego = ca.MX.sym('ego', 4)
        thw = boundary_thw(*[ego[i] for i in range(4)], 6., .7, .1)
        cost = 10. * ca.fmax(.5 - thw, 0.) ** 2
        gradient = ca.Function('boundary_cost_gradient', [ego], [ca.jacobian(cost, ego)])
        g = np.asarray(gradient([0., 0., 0., 5.])).ravel()
        self.assertGreater(g[0], 0.)  # Moving toward the other vehicle increases cost.
        self.assertGreater(g[3], 0.)  # Increasing speed reduces the available headway.

    def test_live_geometry_changes_optimized_acceleration(self):
        from Planning_library.mpc_boundary import boundary_thw
        solutions = {}
        for mode in ('legacy', 'symbolic'):
            problem = ca.Opti()
            acceleration = problem.variable()
            loss = .1 * acceleration ** 2
            for k in range(1, 11):
                t = .1 * k
                a = acceleration if mode == 'symbolic' else 0.
                thw = boundary_thw(5. * t + .5 * a * t * t, 0., 0.,
                                   5. + a * t, 8., 0., 0.)
                loss += 10. * ca.fmax(.5 - thw, 0.) ** 2
            problem.minimize(loss)
            problem.subject_to(problem.bounded(-3., acceleration, 2.))
            problem.solver('ipopt', {'print_time': False}, {'print_level': 0, 'sb': 'yes'})
            solutions[mode] = float(problem.solve().value(acceleration))
        self.assertAlmostEqual(solutions['legacy'], 0., places=5)
        self.assertLess(solutions['symbolic'], -.1)


@unittest.skipIf(ca is None, 'MPC integration checks require CasADi')
class TestMpcBoundaryIntegration(unittest.TestCase):
    def test_active_cost_depends_on_decision_states_and_legacy_does_not(self):
        from Agent.game_theory.MPC import MPCController
        for mode, expected in (('symbolic', True), ('legacy', False)):
            with patch.dict(os.environ, {'DSH_MPC_BOUNDARY_MODE': mode}):
                controller = MPCController(2, .05, 2.7, .5, enable_lead_follow_cost=False)
            term = sum(controller.boundary_cost(k) for k in range(controller.N + 1))
            self.assertEqual(ca.depends_on(term, controller.x), expected)

    def test_real_controller_reacts_to_boundary_cost(self):
        from Agent.game_theory.MPC import MPCController
        commands = {}
        for mode in ('legacy', 'symbolic'):
            with patch.dict(os.environ, {'DSH_MPC_BOUNDARY_MODE': mode}):
                controller = MPCController(10, .05, 2.7, .5, enable_lead_follow_cost=False)
            ego = SimpleNamespace(x=0., y=0., yaw=0., v=3.)
            rv = SimpleNamespace(x=6., y=.7, yaw=.1, v=0.)
            lane = SimpleNamespace(front_vehicles=[], rear_vehicles=[rv])
            dynamic_map = SimpleNamespace(ego_vehicle=ego, lanes=[lane])
            controller.reset_global_path(
                np.column_stack((np.arange(40.), np.zeros(40))), dynamic_map)
            controller.last_u = dict(a=0., df=0.)
            commands[mode] = controller.solve(dynamic_map, 3., False, intersection_center=(0., 10.))
            self.assertTrue(controller._solve_ok)
        self.assertLess(abs(commands['legacy'][0]), .01)
        self.assertLess(commands['symbolic'][0], -.05)


if __name__ == '__main__':
    unittest.main()
