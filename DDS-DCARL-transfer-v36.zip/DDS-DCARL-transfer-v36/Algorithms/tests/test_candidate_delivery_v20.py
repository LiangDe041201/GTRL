"""Actual CLI, journal audit and training/holdout protocol for v20."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest

from Tools.run_relay_validation import main
from Tools.validate_candidate_learning_v19 import validate_candidate_learning
from test_candidate_learning_v20 import Game


class DeliveryV20Tests(unittest.TestCase):
    def test_cli_dispatches_new_authority_with_the_same_cg_and_traffic(self):
        from Planning_library.cournot_mpc import game_configuration
        try:config=game_configuration('GTRL',True,'matrix_v20')
        except ValueError as exc:self.fail(str(exc))
        self.assertTrue(config['candidate_learning'])
        self.assertFalse(config['learning'])
        output=io.StringIO()
        with contextlib.redirect_stdout(output),contextlib.redirect_stderr(io.StringIO()):
            try:code=main(['--dry-run','--traffic-interaction','v17',
                '--arms','M6_matrix_v18,L0_learning_v20,L1_efe_v20'])
            except SystemExit:self.fail('v20 arms cannot run through the real CLI')
        self.assertEqual(code,0)
        plans=[json.loads(s)['effective'] for s in output.getvalue().splitlines()]
        self.assertEqual([r['DSH_COURNOT_MODE'] for r in plans],['matrix_v18','matrix_v20','matrix_v20'])
        self.assertEqual([r['DSH_EFE'] for r in plans],['0','0','1'])
        self.assertTrue(all(r['DSH_FORECAST_MODEL']=='route_v18' for r in plans))

    def test_new_holdout_does_not_reuse_the_v19_analysis_seeds(self):
        try:from Tools.run_learning_validation_v20 import build_plan
        except ImportError:self.fail('No v20 workflow')
        stages=build_plan(Path('out'))
        self.assertEqual(sum(s['episodes_total'] for s in stages),435)
        args=stages[-1]['arguments']
        seeds=[int(s) for s in args[args.index('--seeds')+1].split(',')]
        offset=int(args[args.index('--environment-seed-offset')+1])
        self.assertFalse(set(s+offset for s in seeds)&{1001,1004,1005})
        self.assertEqual(args[args.index('--candidate-phase')+1],'eval')
        self.assertIn('L1_efe_v20',args[args.index('--arms')+1])

    def journal(self,directory):
        from test_candidate_learning_v19 import MatrixIntegrationTests
        from Planning_library.execution_guard import select_execution
        from Planning_library.trajectory_guard import execution_acceleration
        ego,path,g,u,rv,cs,conf=MatrixIntegrationTests().fixture()
        game=Game(g,directory=directory,epsilon=0.)
        game.prepare(ego,[rv],conf,4.,.846,(-21.,-138.5,-3.12))
        a=game.choose(ego,[rv],rv,conf,cs,path,u);c=cs[a]
        chosen,audit=select_execution(ego,[rv],path,c['target'],
            execution_acceleration(c['a'],ego.v,c['target']),c['delta'],u,g,
            prediction=c['prediction'],prediction_times=c['times'],plan=c['plan'],solve_ok=c['solve_ok'],
            alternative=cs[1] if a==0 else None)
        applied=dict(a_cmd=chosen['a'],delta_rad=chosen['delta'],
            actuator_speed_target=chosen['target'],ego_v_after=ego.v,control_submit_ok=1)
        game.feedback(1,1,audit,applied,'complete')
        game.record(1,1,c['a'],c['delta'],c['target'],audit,applied)
        row=dict(episode='1',frame='1',a_mpc=str(c['a']),delta_mpc_rad=str(c['delta']),
            a_cmd=str(chosen['a']),delta_rad=str(chosen['delta']),v_ref=str(chosen['target']),
            actuator_speed_target=str(chosen['target']),ego_v_after=str(ego.v),
            guard_action=audit['action'],mpc_audit_override=str(int(audit['override'])),
            mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10',ego_v=str(ego.v))
        return [row]

    def test_independent_audit_checks_net_bounds_and_executable_authority(self):
        from Tools.validate_matrix_game import validate_matrix_game
        with tempfile.TemporaryDirectory() as d:
            rows=self.journal(d)
            result=validate_candidate_learning(d,rows)
            self.assertTrue(result['learning_mechanisms_ok'],result)
            result=validate_matrix_game(d,rows,'matrix_v20')
            self.assertTrue(result['matrix_contract_ok'],result)
            p=Path(d)/'candidate_learning.jsonl';row=json.loads(p.read_text())
            action=str(row['cg'])
            row['regularized_bounds'][action]['information_cost']+=1.
            p.write_text(json.dumps(row),encoding='utf8')
            self.assertFalse(validate_candidate_learning(d,rows)['learning_mechanisms_ok'])

    def test_comparison_reports_actual_v20_ablation_groups(self):
        from Tools.summarize_matrix_comparison import learning_comparisons
        group=dict(success_rate=1.,collisions=0,mean_all_episode_s=25.,mean_entry_wait_s=1.,
                   mean_non_goal_stop_events=1.)
        groups={a:dict(group) for a in ['M6_matrix_v18','L0_learning_v20','L1_efe_v20']}
        comparisons=learning_comparisons(groups)
        self.assertIn('EFE_vs_learning',comparisons)
        self.assertEqual(comparisons['full_GTRL_vs_CG']['treatment'],'L1_efe_v20')


if __name__=='__main__':unittest.main()
