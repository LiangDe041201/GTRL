"""Corrupted prediction payloads must not pass through a valid action label."""
import copy
import hashlib
import json
import struct
import unittest

from Tools.validate_trajectory_probe_v21 import validate_probe_record


def digest(matrix):
    values = [float(x) for row in matrix for x in row]
    return hashlib.sha256(struct.pack('<%dd' % len(values), *values)).hexdigest()


class TrajectoryPayloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Import inside the method so discovery does not collect another class.
        from test_trajectory_validation_v21 import TrajectoryValidationTests
        cls.saved_row, cls.saved_ego = TrajectoryValidationTests().evidence()

    def setUp(self):
        self.row, self.ego = copy.deepcopy((self.saved_row, self.saved_ego))

    def candidate(self):
        return self.row['trajectory_probe']['candidates'][0]

    def check(self):
        return validate_probe_record(self.row, self.ego, 'proceed')

    def test_real_json_round_trip_keeps_valid_payloads_accepted(self):
        self.row = json.loads(json.dumps(self.row, allow_nan=False))
        self.assertEqual(self.check(), {})

    def test_changed_path_points_cannot_keep_the_old_geometry_hash(self):
        self.row['trajectory_probe']['path'][1][0] += .1
        self.assertTrue(self.check())

    def test_wrong_path_coordinate_count_is_rejected_even_with_a_matching_hash(self):
        p = self.row['trajectory_probe']
        p['path'] = [point + [0.] for point in p['path']]
        p['path_hash'] = digest(p['path'])
        self.assertTrue(self.check())

    def test_changed_control_plan_cannot_keep_its_old_hash(self):
        self.candidate()['plan'][0][0] += .1
        self.assertTrue(self.check())

    def test_changed_prediction_cannot_keep_its_old_hash(self):
        self.candidate()['prediction'][0][1] += .1
        self.assertTrue(self.check())

    def test_missing_prediction_is_not_valid_for_a_successful_solver(self):
        c = self.candidate()
        c['prediction'] = c['prediction_hash'] = None
        self.assertTrue(self.check())

    def test_missing_control_plan_is_not_valid_for_a_successful_solver(self):
        c = self.candidate()
        c['plan'] = c['plan_hash'] = None
        self.assertTrue(self.check())

    def test_wrong_prediction_state_count_is_rejected_with_a_matching_hash(self):
        c = self.candidate()
        c['prediction'] = c['prediction'][:-1]
        c['prediction_hash'] = digest(c['prediction'])
        self.assertTrue(self.check())

    def test_ragged_plan_is_rejected_with_a_matching_flat_hash(self):
        c = self.candidate()
        c['plan'][0] = c['plan'][0][:-1]
        c['plan_hash'] = digest(c['plan'])
        self.assertTrue(self.check())

    def test_nonfinite_prediction_is_rejected_even_when_its_hash_matches(self):
        c = self.candidate()
        c['prediction'][0][0] = float('inf')
        c['prediction_hash'] = digest(c['prediction'])
        self.assertTrue(self.check())

    def test_reversed_time_step_is_rejected(self):
        c = self.candidate()
        c['times'][2] = c['times'][1] - .01
        self.assertTrue(self.check())

    def test_time_axis_cannot_drop_a_prediction_sample(self):
        self.candidate()['times'].pop()
        self.assertTrue(self.check())

    def test_time_axis_must_start_at_the_current_frame(self):
        c = self.candidate()
        c['times'] = [t + .1 for t in c['times']]
        self.assertTrue(self.check())

    def test_failed_unselected_solver_may_have_no_plan_or_prediction(self):
        c = self.candidate()
        c.update(solve_ok=False, plan=None, prediction=None,
                 plan_hash=None, prediction_hash=None)
        self.row['candidate_solve_ok'][0] = False
        self.assertEqual(self.check(), {})

    def test_failed_solver_cannot_claim_an_eligible_trajectory(self):
        c = self.candidate()
        c.update(solve_ok=False, plan=None, prediction=None,
                 plan_hash=None, prediction_hash=None, eligible=True)
        self.row['candidate_solve_ok'][0] = False
        self.assertTrue(self.check())


if __name__ == '__main__':
    unittest.main()
