"""Catches invented observations and noncausal/repeated response evidence."""
import math
from types import SimpleNamespace as S
import unittest

try:
    from Planning_library.physical_belief_v22 import physical_state, ResponseBelief
except ImportError:
    physical_state = ResponseBelief = None


class PhysicalBeliefTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(ResponseBelief, 'Physical state and explicit beta posterior are missing')
        return ResponseBelief

    def test_observed_motion_and_hidden_parameter_are_separate(self):
        self.api()
        v = S(x=2., y=3., v=4., yaw=.2, acc=.5, acc_source='velocity_difference',
              private_style='aggressive', private_yield=True)
        result = physical_state(v)
        self.assertEqual(result['motion'], [2., 3., 4., .5, .2])
        self.assertIsNone(result['beta_true'])
        self.assertNotIn('private_style', result)

    def test_missing_acceleration_is_not_fabricated_as_zero(self):
        self.api()
        v = S(x=2., y=3., v=4., yaw=.2, acc=0., acc_source='unavailable')
        self.assertIsNone(physical_state(v)['motion'][3])

    def test_half_second_real_deceleration_updates_beta_once(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=True)
        for k in range(1, 11):
            r = b.update(7, 4.-.05*k, .05, opportunity=True)
        self.assertEqual((r['alpha'], r['beta']), (2., 1.))
        self.assertAlmostEqual(r['mean'], 2./3.)
        self.assertEqual(r['observations'], 1)
        self.assertFalse(r['calibrated'])

    def test_current_opportunity_cannot_relabel_a_previous_unexposed_window(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=False)
        r = b.update(7, 3.5, .5, opportunity=True)
        self.assertEqual(r['observations'], 0)

    def test_leader_confounded_slowdown_does_not_count_as_interaction_evidence(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=True, confounded=True)
        r = b.update(7, 3., .5, opportunity=True)
        self.assertEqual((r['alpha'], r['beta']), (1., 1.))

    def test_cruising_in_an_exposed_window_is_non_deceleration_evidence(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=True)
        r = b.update(7, 4., .5, opportunity=True)
        self.assertEqual((r['alpha'], r['beta']), (1., 2.))

    def test_actor_switch_and_reappearance_do_not_inherit_another_posterior(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=True)
        b.update(7, 3., .5, opportunity=True)
        r = b.update(8, 3., .05, opportunity=True)
        self.assertEqual(r['mean'], .5)
        r = b.update(7, 3., .05, opportunity=True)
        self.assertEqual(r['observations'], 0)

    def test_missing_observation_breaks_the_window_and_invalid_time_is_rejected(self):
        b = self.api()()
        b.update(7, 4., .05, opportunity=True)
        b.update(7, None, .5, opportunity=True)
        r = b.update(7, 1., .5, opportunity=True)
        self.assertEqual(r['observations'], 0)
        for dt in (0., -1., float('nan')):
            with self.assertRaises(ValueError):
                b.update(7, 1., dt)


if __name__ == '__main__':
    unittest.main()
