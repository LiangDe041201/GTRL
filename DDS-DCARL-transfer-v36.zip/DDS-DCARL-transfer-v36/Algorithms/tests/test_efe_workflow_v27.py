"""An explicit six-episode shadow comparison, independent of tonight's v26."""
import contextlib
import copy
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from test_efe_validation_v27 import sample
from Tools.run_trajectory_validation_v21 import PHYSICAL_FIELDS

try:
    from Tools.run_efe_shadow_validation_v27 import build_plan,compare_runs,main
except ImportError:
    build_plan=compare_runs=main=None


class EFEWorkflowTests(unittest.TestCase):
    def test_plan_is_paired_fresh_training_not_a_benefit_experiment(self):
        self.assertIsNotNone(build_plan,'No independent shadow workflow')
        stages=build_plan(Path('result'))
        self.assertEqual(sum(s['episodes_total'] for s in stages),6)
        args=stages[0]['arguments']
        self.assertIn('T2_train_v24,T4_efe_shadow_v27',args)
        self.assertEqual(args[args.index('--road-audit')+1],'local_v26')
        self.assertEqual(args[args.index('--rolling-epsilon')+1],'.3')
        self.assertNotIn('--rolling-checkpoint',args)

    def files(self,root,shadow=False):
        root.mkdir(); row,meta=sample()
        if not shadow: row['rolling_trajectory'].pop('efe_shadow')
        row.update(decision_ms=1. if shadow else 3.)
        (root/'matrix_decisions.jsonl').write_text(json.dumps(row)+'\n',encoding='utf8')
        with (root/'interaction_ego.csv').open('w',encoding='utf8',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(PHYSICAL_FIELDS)+['mpc_solve_ms'])
            values={k:'0' for k in PHYSICAL_FIELDS}; values.update(episode=1,frame=7,ego_v=2.,mpc_solve_ms=1. if shadow else 3.)
            writer.writeheader(); writer.writerow(values)
        (root/'rolling_model').mkdir()
        (root/'rolling_model/rolling_model.json').write_text('{"q":{"s":[1,2]},"records":[1]}',encoding='utf8')
        return root

    def test_pair_ignores_only_timing_and_shadow_but_checks_controls_q_and_evidence(self):
        self.assertIsNotNone(compare_runs,'No off/shadow invariance comparison')
        with tempfile.TemporaryDirectory() as tmp:
            a=self.files(Path(tmp)/'off'); b=self.files(Path(tmp)/'shadow',True)
            self.assertTrue(compare_runs(a,b)['ok'])
            path=b/'matrix_decisions.jsonl'; row=json.loads(path.read_text(encoding='utf8'))
            row['rolling_trajectory']['request']['target']=3.
            path.write_text(json.dumps(row)+'\n',encoding='utf8')
            self.assertFalse(compare_runs(a,b)['ok'])
            path.write_text((a/'matrix_decisions.jsonl').read_text(encoding='utf8'),encoding='utf8')
            (b/'rolling_model/rolling_model.json').write_text('{"q":{}}',encoding='utf8')
            self.assertFalse(compare_runs(a,b)['ok'])

    def test_dry_run_does_not_make_a_result_directory(self):
        self.assertIsNotNone(main,'No standalone shadow command')
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)/'not_created'; text=io.StringIO()
            with contextlib.redirect_stdout(text):
                self.assertEqual(main(['--dry-run','--output-root',str(output)]),0)
            self.assertFalse(output.exists())
            self.assertEqual(json.loads(text.getvalue())['episodes_total'],6)


if __name__=='__main__': unittest.main()
