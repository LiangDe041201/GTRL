"""Longitudinal choices use the CG path and real applied action ownership."""
import importlib
import math
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace as S
import unittest

import numpy as np


class LongitudinalV31Tests(unittest.TestCase):
    def module(self):
        try:
            return importlib.import_module('Planning_library.longitudinal_planner_v31')
        except ModuleNotFoundError:
            self.fail('The longitudinal planner has no implementation')

    def test_two_action_model_round_trips_and_explores_the_candidate(self):
        cls = self.module().LongitudinalLearnerV31
        learner = cls()
        key = learner.begin([0.]*16, dict(alpha=1., beta=1.), 0, [0,1], [0.,0.], 1)
        learner.start(0); learner.reward(0.); learner.finish()
        learner.begin([0.]*16, dict(alpha=1., beta=1.), 0, [0,1], [0.,0.], 2)
        self.assertEqual(learner.choose(1., np.random.RandomState(1)), 1)
        learner.start(1); learner.reward(1.); learner.finish()
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'model.json'; learner.save(path)
            loaded = cls('eval', path)
            self.assertEqual(len(loaded.q[key]), 2)
            loaded.begin([0.]*16, dict(alpha=1., beta=1.), 0, [0,1], [0.,0.], 2)
            self.assertEqual(loaded.choose(), 0)
            self.assertEqual(loaded.records[-1]['action'], 1)

    def test_entry_requires_actual_body_clear_and_alignment(self):
        times = np.arange(4.)
        states = np.zeros((7,4)); states[0] = [5.,4.,2.,0.]
        states[1] = [-132.,-136.,-138.,-138.]
        states[6] = [-math.pi/2,-math.pi/2,-math.pi/2,math.pi]
        check = self.module().entry_times
        self.assertEqual(check(states,times,4.8,1.8,1.), (1.,3.))
        self.assertEqual(check(states[:,:3],times[:3],4.8,1.8,1.), (1.,None))

    def test_reuse_is_only_exposed_while_waiting_with_a_safe_proceed_prediction(self):
        permitted = self.module().entry_candidate_permitted
        controller = S(geometry_force_stop=False,geometry_source='planned')
        candidate = dict(controller=controller,solve_ok=True,target=4.)
        parts = [dict(admissible=True,min_gap=.2),dict(admissible=True,min_gap=.35)]
        record = dict(active=True,phase='approach',standoff=3.,components=[[],parts])
        self.assertTrue(permitted(0,record,candidate))
        self.assertFalse(permitted(1,record,candidate))
        controller.geometry_force_stop=True
        self.assertFalse(permitted(0,record,candidate))
        controller.geometry_force_stop=False
        parts[1]['min_gap']=.19
        self.assertFalse(permitted(0,record,candidate))


if __name__ == '__main__': unittest.main()
