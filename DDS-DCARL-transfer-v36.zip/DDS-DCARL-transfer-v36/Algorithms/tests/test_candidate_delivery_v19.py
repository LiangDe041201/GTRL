"""Configuration and CLI contracts for the new learning branch."""
import contextlib
import io
import json
import unittest
from pathlib import Path

from Planning_library.cournot_mpc import game_configuration
from Planning_library.control_path_v15 import ControlExperimentV15
from Tools.run_relay_validation import main


class CandidateConfigurationTests(unittest.TestCase):
    def test_new_branch_has_one_learning_owner_and_retains_two_mpc_candidates(self):
        try:
            result=game_configuration('GTRL',True,'matrix_v19')
        except ValueError as e:
            self.fail('New GTRL candidate branch is still rejected: '+str(e))
        self.assertTrue(result['matrix'])
        self.assertTrue(result['candidate_learning'])
        self.assertFalse(result['learning']) # old speed/lateral learner cannot run too
        self.assertFalse(result['mpc'])      # no extra game cost inside tracking MPC

    def test_spatial_path_requires_explicit_candidate_learning_authority(self):
        with self.assertRaises(ValueError):
            ControlExperimentV15('GTRL',True,'paper_v11','spatial_v15')
        try:
            c=ControlExperimentV15('GTRL',True,'paper_v11','spatial_v15',candidate_learning=True)
        except TypeError as e:
            self.fail('Common path cannot accept the explicit candidate owner: '+str(e))
        self.assertTrue(c.enabled)
        self.assertFalse(c.advance_enabled)

    def test_learning_ablation_dry_run_keeps_traffic_controller_and_rewards_common(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(io.StringIO()):
            try:
                code=main(['--dry-run','--traffic-interaction','v17','--soft-alpha','.1',
                    '--arms','M6_matrix_v18,L0_learning_v19,L1_efe_v19'])
            except SystemExit:
                self.fail('The actual validation CLI cannot plan the learning ablation')
        self.assertEqual(code,0)
        configs=[json.loads(line)['effective'] for line in out.getvalue().splitlines()]
        self.assertEqual([c['DSH_EFE'] for c in configs],['0','0','1'])
        self.assertEqual([c['DSH_COURNOT_MODE'] for c in configs],['matrix_v18','matrix_v19','matrix_v19'])
        self.assertTrue(all(c['DSH_FORECAST_MODEL']=='route_v18' and
                            c['DSH_TRAFFIC_INTERACTION']=='v17' and
                            c['DSH_CONTROL_PROFILE']=='paper_v11' for c in configs))
        for key in ('DSH_CANDIDATE_REWARD','DSH_DISCOUNT_HALF_LIFE','DSH_SOFT_ALPHA',
                    'DSH_CANDIDATE_EFE_WEIGHT','DSH_BASELINE_SUPPORT'):
            self.assertEqual(configs[1][key],configs[2][key])

    def test_eval_cannot_silently_start_with_a_fresh_model(self):
        with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as cm:
                main(['--arms','L1_efe_v19','--traffic-interaction','v17','--candidate-phase','eval'])
        self.assertEqual(cm.exception.code,2)

    def test_eval_environment_seed_changes_but_model_replica_identity_does_not(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out),contextlib.redirect_stderr(io.StringIO()):
            try:
                main(['--dry-run','--arms','L1_efe_v19','--traffic-interaction','v17',
                    '--candidate-phase','eval','--checkpoint-root','trained',
                    '--environment-seed-offset','1000','--seeds','4'])
            except SystemExit:self.fail('Evaluation cannot separate environment seed from trained model identity')
        plan=json.loads(out.getvalue())
        self.assertEqual(plan['seed'],4)
        self.assertEqual(plan['environment_seed'],1004)
        self.assertIn('L1_efe_v19_seed4',plan['effective']['DSH_CANDIDATE_CHECKPOINT'])

    def test_workflow_has_matched_training_and_unseen_frozen_evaluation(self):
        try:
            from Tools.run_learning_validation_v19 import build_plan
        except ImportError:self.fail('There is no reproducible training/evaluation workflow')
        stages=build_plan(Path('result'),train_episodes=50,eval_episodes=10,seeds=[1,4,5])
        self.assertEqual([s['name'] for s in stages],['00_smoke','01_train','02_eval'])
        self.assertEqual(sum(s['episodes_total'] for s in stages),435)
        evaluation=stages[-1]['arguments']
        self.assertEqual(evaluation[evaluation.index('--environment-seed-offset')+1],'1000')
        self.assertEqual(evaluation[evaluation.index('--candidate-phase')+1],'eval')
        self.assertEqual(evaluation[evaluation.index('--checkpoint-root')+1],str(Path('result')/'01_train'))

    def test_report_separates_learning_gain_from_the_added_efe_gain(self):
        from Tools import summarize_matrix_comparison as report
        self.assertTrue(hasattr(report,'learning_comparisons'),'The report cannot isolate learning and EFE')
        def group(success,collisions,seconds):
            return dict(success_rate=success,collisions=collisions,mean_all_episode_s=seconds,
                        mean_entry_wait_s=1.,mean_non_goal_stop_events=2.)
        groups={'M6_matrix_v18':group(.8,2,30.),'L0_learning_v19':group(.9,1,31.),
                'L1_efe_v19':group(1.,0,32.)}
        comparisons=report.learning_comparisons(groups)
        self.assertAlmostEqual(comparisons['learning_vs_CG']['success_rate_delta'],.1)
        self.assertAlmostEqual(comparisons['EFE_vs_learning']['success_rate_delta'],.1)
        self.assertEqual(comparisons['EFE_vs_learning']['mean_all_episode_s_delta'],1.)


if __name__=='__main__':unittest.main()
