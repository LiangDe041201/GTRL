#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【标定·2026-10-15】env_sign 容差可标定化的回归测试（纯函数，无 CARLA）。

背景
------------------------------------------------------------------
`Trustset.compare_signs` 的 8 维 env_sign 容差原为**硬编码**
    tol = [3.0, 3.0, 3.0, 3.0, 0.8, 3.0, 0.02, 1.5]
而该容差**直接决定**状态条件化后的样本量 n，进而决定式(43) 的
    δ = (R_max−R_min)·√(ln(1/α)/(2n))
接管条件是 `WCV(替代) > BCV(规则)`，即 `ΔQ̂ > δ(替代) + δ(规则)`。

实测（A6fix100，44047 样本，R=3331）：
  · 原容差下每动作**局部**样本中位仅 140 ⇒ δ≈400 ⇒ 需 ΔQ̂>800
    而实测动作间差仅 ~150 ⇒ **机制结构上无法行动**（可接管邻域仅 0.8%）
  · 放宽到 k=5 ⇒ n 中位 480、可接管占比 19.1%；k=8 ⇒ n 600、40.0%
  · **所有倍数的"接管方向检验"均为 100%**（替代动作状态匹配均值确实更高）
    ⇒ 放宽是**偏差-方差权衡**，不是引入噪声

⚠️ 本文件只验证**容差语义与开关行为**，不断言"放宽后性能一定变好"（那是闭环问题）。
   最重要的一条：**默认必须保持原行为**（不静默改变任何历史基线）。
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.trustset_dds import (  # noqa: E402
    Trustset, env_tol_scale, _ENV_TOL_BASE, _ENV_TOL_SCALE_CACHE)

#: 修复前的硬编码容差（默认行为必须与它**逐元素相等**）
ORIG_TOL = np.array([3.0, 3.0, 3.0, 3.0, 0.8, 3.0, 0.02, 1.5])


class _TolCase(unittest.TestCase):
    """公共夹具：隔离保存目录 + 清洁的环境变量 + 独立的 scale 缓存。"""

    def setUp(self):
        self._old_save = os.environ.get('DSH_SAVE_DIR')
        self._old_scale = os.environ.get('DSH_ENV_TOL_SCALE')
        self._tmp = tempfile.mkdtemp(prefix='dsh_tol_ut_')
        os.environ['DSH_SAVE_DIR'] = self._tmp
        os.environ.pop('DSH_ENV_TOL_SCALE', None)
        _ENV_TOL_SCALE_CACHE[0] = None

    def tearDown(self):
        for k, v in (('DSH_SAVE_DIR', self._old_save),
                     ('DSH_ENV_TOL_SCALE', self._old_scale)):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        _ENV_TOL_SCALE_CACHE[0] = None
        shutil.rmtree(self._tmp, ignore_errors=True)

    def _ts(self, scale=None):
        """构造 Trustset；scale=None ⇒ 不设环境变量；随后清缓存使其生效。"""
        if scale is None:
            os.environ.pop('DSH_ENV_TOL_SCALE', None)
        else:
            os.environ['DSH_ENV_TOL_SCALE'] = str(scale)
        _ENV_TOL_SCALE_CACHE[0] = None
        return Trustset()


# ---------------------------------------------------------------------------
# 1. 默认行为保持（**最重要**：不得静默改变历史基线）
# ---------------------------------------------------------------------------
class TestDefaultPreserved(_TolCase):

    def test_default_scale_is_one(self):
        self.assertEqual(env_tol_scale(), 1.0)

    def test_default_tolerance_equals_original(self):
        ts = self._ts(None)
        s = np.zeros(8)
        self.assertTrue(ts.compare_signs(s, ORIG_TOL))
        self.assertTrue(ts.compare_signs(s, -ORIG_TOL))
        self.assertFalse(ts.compare_signs(s, ORIG_TOL * 1.0001))

    def test_base_constant_matches_original(self):
        self.assertTrue(np.allclose(_ENV_TOL_BASE, ORIG_TOL))


# ---------------------------------------------------------------------------
# 2. 缩放行为
# ---------------------------------------------------------------------------
class TestScaling(_TolCase):

    def test_scale_multiplies_tolerance(self):
        s = np.zeros(8)
        far = ORIG_TOL * 3.0
        self.assertFalse(self._ts(None).compare_signs(s, far))
        self.assertTrue(self._ts(5.0).compare_signs(s, far))

    def test_scale_boundary_exact(self):
        s = np.zeros(8)
        ts = self._ts(2.0)
        self.assertTrue(ts.compare_signs(s, ORIG_TOL * 2.0))
        self.assertFalse(ts.compare_signs(s, ORIG_TOL * 2.0001))

    def test_scale_is_monotone(self):
        s = np.zeros(8)
        probe = ORIG_TOL * 4.0
        prev = False
        for k in (1.0, 2.0, 3.0, 5.0):
            cur = self._ts(k).compare_signs(s, probe)
            self.assertGreaterEqual(cur, prev)
            prev = cur


# ---------------------------------------------------------------------------
# 3. 非法输入回退
# ---------------------------------------------------------------------------
class TestInvalidFallback(_TolCase):

    def test_invalid_values_fall_back_to_one(self):
        for bad in ('abc', '', '0', '-1', 'nan', 'inf', '-inf', 'None'):
            self._ts(bad)
            self.assertEqual(env_tol_scale(), 1.0, f'非法值 {bad!r}')

    def test_nonpositive_scale_rejected(self):
        """0/负数若被接受 ⇒ 容差为 0 ⇒ 精确匹配 ⇒ 检索几乎全空。必须拒绝。"""
        for bad in (0.0, -3.0, -0.001):
            self._ts(bad)
            self.assertEqual(env_tol_scale(), 1.0)


# ---------------------------------------------------------------------------
# 4. lane 分支不受影响（4×2 矩阵走 ndim==2 分支）
# ---------------------------------------------------------------------------
class TestLaneBranch(_TolCase):

    def test_lane_branch_unaffected_by_scale(self):
        lane = np.zeros((4, 2))
        near = np.full((4, 2), 0.9)
        far = np.full((4, 2), 1.1)
        for k in (None, 1.0, 5.0, 20.0):
            ts = self._ts(k)
            self.assertTrue(ts.compare_signs(lane, near), f'scale={k}')
            self.assertFalse(ts.compare_signs(lane, far), f'scale={k}')


# ---------------------------------------------------------------------------
# 5. 健壮性（沿用原函数既有语义）
# ---------------------------------------------------------------------------
class TestRobustness(_TolCase):

    def test_none_inputs_return_false(self):
        ts = self._ts(None)
        self.assertFalse(ts.compare_signs(None, np.zeros(8)))
        self.assertFalse(ts.compare_signs(np.zeros(8), None))
        self.assertFalse(ts.compare_signs(None, None))

    def test_shape_mismatch_returns_false(self):
        ts = self._ts(None)
        self.assertFalse(ts.compare_signs(np.zeros(8), np.zeros(7)))
        self.assertFalse(ts.compare_signs(np.zeros(8), np.zeros((4, 2))))

    def test_short_vector_uses_flat_tolerance(self):
        """非 8 维、非 2 维 ⇒ 平坦容差 2.0（且不随 scale 变）。"""
        s = np.zeros(4)
        for k in (None, 5.0):
            ts = self._ts(k)
            self.assertTrue(ts.compare_signs(s, np.full(4, 1.9)))
            self.assertFalse(ts.compare_signs(s, np.full(4, 2.1)))

    def test_nan_input_does_not_match(self):
        ts = self._ts(None)
        a = np.zeros(8)
        a[0] = float('nan')
        self.assertFalse(ts.compare_signs(a, np.zeros(8)))

    def test_compare_signs_has_no_side_effect(self):
        """`compare_signs` 必须是**纯查询**：不得修改 diag 或任何 Trustset 状态。

        （式43/46 的哨兵统计由 `TS_*_ConfidenceValue` 维护；容差改动不得触碰。）
        """
        ts = self._ts(5.0)
        before = {k: (dict(v) if isinstance(v, dict) else v)
                  for k, v in ts.diag.items()}
        ts.compare_signs(np.zeros(8), np.zeros(8))
        after = {k: (dict(v) if isinstance(v, dict) else v)
                 for k, v in ts.diag.items()}
        self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main(verbosity=2)
