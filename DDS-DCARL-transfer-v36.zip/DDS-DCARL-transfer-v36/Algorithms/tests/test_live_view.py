#!/usr/bin/env python3
"""训练可视化窗口的纯函数部分（BGRA→RGB）单元测试；无 CARLA / 无 GUI 也能跑。"""
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.live_view import LiveView, bgra_to_rgb


class TestBgraToRgb(unittest.TestCase):
    def test_channel_order(self):
        # 两个像素：BGRA(10,20,30,255) → RGB(30,20,10)
        raw = bytes([10, 20, 30, 255, 1, 2, 3, 255])
        arr = bgra_to_rgb(raw, 2, 1)
        self.assertEqual(arr.shape, (1, 2, 3))
        self.assertEqual(list(arr[0, 0]), [30, 20, 10])
        self.assertEqual(list(arr[0, 1]), [3, 2, 1])

    def test_contiguous_for_pygame(self):
        raw = bytes([0, 0, 0, 255] * 6)
        arr = bgra_to_rgb(raw, 3, 2)
        self.assertTrue(arr.flags['C_CONTIGUOUS'])
        self.assertEqual(arr.shape, (2, 3, 3))


class TestDisabledView(unittest.TestCase):
    def test_disabled_is_noop(self):
        v = LiveView(enabled=False)
        self.assertFalse(v.enabled)
        v.attach(None, None)          # 不应抛异常
        v.update({'frame': 1}, world=None, ego=None)
        v.close()

    def test_attaches_only_once_per_ego(self):
        v = LiveView(enabled=False)
        self.assertIsNone(v.ego_id)
        v.attach(None, type('E', (), {'id': 7})())
        v.update({}, world=None, ego=type('E', (), {'id': 7})())
        v.close()


if __name__ == '__main__':
    unittest.main()
