"""Returned v8 actuator regressions and measured-state v9 probe evidence."""
import ast
import contextlib
import csv
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest

import numpy as np

from Planning_library.pedal_control import PedalController, brake_deceleration, signed_speed
from Planning_library.control_probe import StopRestartProbe
from Tools.validate_control_health import validate_control_health

ROOT = Path(__file__).resolve().parents[1]


def evidence(phase, v0, v1, frame, target=4., failure=''):
    return dict(control_profile='paper_v9', actuator_mode='feedback_pedal_v9',
        sim_dt='.05', sim_frame_before=str(frame), sim_frame_after=str(frame+1),
        ego_v_before=str(v0), ego_v_after=str(v1), ego_acc_measured=str((v1-v0)/.05),
        ego_v_signed_before=str(v0), ego_v_signed_after=str(v1), ego_acc_signed=str((v1-v0)/.05),
        ego_acc_sensor=str((v1-v0)/.05), a_cmd='0.', actuator_speed_target=str(target),
        actuator_accel_limit='3.', throttle='0.', brake='0.', steer='0.',
        requested_throttle='0.', requested_brake='0.', requested_steer='0.',
        gear='1', reverse='0', hand_brake='0', manual_gear_shift='0',
        guard_safe='1', guard_unavoidable='0', guard_action='mpc', mpc_solve_ok='1',
        episode='1', goal_remaining='15.', control_probe_phase=phase, control_probe_failure=failure)


def healthy_probe():
    rows, v = [], 0.
    for phase, frames in [('startup', 20), ('cruise', 60), ('decelerate', 35),
                          ('hold', 10), ('recovery', 20), ('done', 10)]:
        for _ in range(frames):
            v1 = min(2., v+.1) if phase in ('startup', 'cruise', 'recovery', 'done') else max(0., v-.1)
            rows.append(evidence(phase, v, v1, len(rows), 0. if phase in ('decelerate', 'hold') else 4.))
            v = v1
    return rows


class TestPedalFeedback(unittest.TestCase):
    def test_physics_uses_centimetres_for_wheel_radius(self):
        physics = S(mass=1600., wheels=[S(radius=32., max_brake_torque=1600.)]*4)
        self.assertAlmostEqual(brake_deceleration(physics), 12.5)
        physics.wheels[0] = S(radius=0., max_brake_torque=100.)
        with self.assertRaises(ValueError):
            brake_deceleration(physics)

    def test_forward_projection_distinguishes_reverse_and_sideways(self):
        self.assertAlmostEqual(signed_speed(S(x=0., y=-2.), -90.), 2.)
        self.assertAlmostEqual(signed_speed(S(x=0., y=2.), -90.), -2.)
        self.assertAlmostEqual(signed_speed(S(x=2., y=0.), -90.), 0.)

    def test_stop_request_cuts_existing_throttle_on_first_tick(self):
        controller = PedalController(25., 1.2)
        for _ in range(20):
            controller.command(2., 3., 4., 0.)
        self.assertGreater(controller.throttle, .1)
        request = controller.command(-3., 3., 0., 0.)
        self.assertEqual(request['throttle'], 0.)
        self.assertGreater(request['brake'], 0.)

    def test_negative_game_acceleration_brakes_even_below_nominal_speed(self):
        controller = PedalController(25., 1.2)
        request = controller.command(-1., 2., 4., 0.)
        self.assertEqual(request['throttle'], 0.)
        self.assertGreater(request['brake'], 0.)

    def test_restart_releases_hold_brake_without_integral_history(self):
        controller = PedalController(25., 1.2)
        for _ in range(20):
            controller.command(-3., 0., 0., 0.)
        self.assertLess(controller.brake, .11)
        request = controller.command(.5, 0., 4., 0.)
        self.assertEqual(request['brake'], 0.)
        self.assertGreater(request['throttle'], 0.)
        self.assertLessEqual(request['throttle'], .05)
        self.assertFalse(request['reverse'])
        self.assertFalse(request['hand_brake'])

    def test_overspeed_cannot_emit_throttle_even_if_mpc_requests_acceleration(self):
        request = PedalController(25., 1.2).command(2., 5., 4., 0.)
        self.assertEqual(request['throttle'], 0.)

    def test_abrupt_deceleration_releases_brake_and_retains_raw_evidence(self):
        controller = PedalController(25., 1.2)
        controller.command(-3., 3., 0., 0.)
        controller.observe(3., 2., .05)
        request = controller.command(-3., 2., 0., 0.)
        self.assertEqual(request['brake'], 0.)
        self.assertEqual(request['throttle'], 0.)
        self.assertEqual(controller.raw_acceleration, -20.)

    def test_steering_uses_physical_radians_and_rate_limit(self):
        controller = PedalController(25., 1.2)
        request = controller.command(1., 0., 4., .5)
        self.assertAlmostEqual(request['steer']*1.2, .045)
        for _ in range(40):
            request = controller.command(1., 0., 4., 9.)
        self.assertLessEqual(abs(request['steer']), 1.)

    def test_synthetic_plants_stop_and_restart_with_gain_error_and_lag(self):
        # This tests a family of declared toy plants, never claims CARLA fidelity.
        for throttle_gain, brake_ratio, lag in [(2., .7, .15), (3., 1., .2), (5., 1.4, .3)]:
            controller, probe = PedalController(25., 1.2), StopRestartProbe()
            speed, actual_acceleration = 0., 0.
            for _ in range(600):
                target = probe.target(4.)
                requested = max(-3., min(2., 1.5*(target-speed)))
                control = controller.command(requested, speed, target, 0.)
                equilibrium = throttle_gain*control['throttle']-25.*brake_ratio*control['brake']-.35
                actual_acceleration += .05/(lag+.05)*(equilibrium-actual_acceleration)
                next_speed = max(0., speed+.05*actual_acceleration)
                controller.observe(speed, next_speed, .05)
                probe.observe(next_speed)
                speed = next_speed
                self.assertFalse(control['throttle'] > 0. and control['brake'] > 0.)
                if probe.phase in ('done', 'failed'):
                    break
            self.assertEqual(probe.phase, 'done', (throttle_gain, brake_ratio, lag, probe.failure))

    def test_production_environment_applies_and_records_explicit_pedals(self):
        source = ROOT/'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(source.read_text(encoding='utf8'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CarEnv_Town03_Turn')
        step = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'step')
        body = []
        for node in step.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Tuple) for t in node.targets):
                if any(isinstance(n, ast.Attribute) and n.attr == 'wrap_state' for n in ast.walk(node)):
                    break
            body.append(node)
        step.body = body+[ast.Return(value=ast.Attribute(value=ast.Name(id='self', ctx=ast.Load()),
            attr='last_control', ctx=ast.Load()))]
        ns = dict(np=np, math=math, signed_speed=signed_speed, carla=S(VehicleControl=lambda **kw: kw))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[step], type_ignores=[])), str(source), 'exec'), ns)
        class World:
            frame = 0
            def get_snapshot(self):
                return S(frame=self.frame, timestamp=S(elapsed_seconds=self.frame*.05))
            def tick(self):
                self.frame += 1
        world, applied = World(), {}
        def apply(control):
            applied.update(control, gear=1)
        actor = S(get_velocity=lambda: S(x=2.-.025*world.frame, y=0.),
            get_transform=lambda: S(rotation=S(yaw=0.), get_forward_vector=lambda: S(x=1., y=0.)),
            get_acceleration=lambda: S(x=-.5, y=0.), apply_control=apply,
            get_control=lambda: S(**applied))
        env = S(world=world, ego_vehicle=actor, native_control=False, pedal_control=True,
            pedal_controller=PedalController(25., 1.2), traffic_enabled=True,
            control_geometry=dict(max_steer=1.2, wheelbase=2.85), dt=.05, sim_frame=0,
            cross_traffic=S(run_step=lambda ego: (None, -1, float('inf'))), update_vehicle_bboxes=lambda: None)
        result = ns['step'](env, [-1., .2], target_speed=0.)
        self.assertEqual(result['throttle'], 0.)
        self.assertGreater(result['brake'], 0.)
        self.assertEqual(result['actuator_mode'], 'feedback_pedal_v9')
        self.assertAlmostEqual(result['ego_acc_signed'], -.5)
        self.assertEqual(result['ego_acc_sensor'], -.5)
        self.assertEqual(result['requested_brake'], result['brake'])
        self.assertAlmostEqual(result['delta_rad'], .045)


class TestMeasuredProbe(unittest.TestCase):
    def ready_probe(self):
        probe = StopRestartProbe()
        for _ in range(100):
            probe.observe(3.)
            if probe.phase == 'decelerate':
                break
        self.assertEqual(probe.phase, 'decelerate')
        return probe

    def test_probe_does_not_release_at_old_fixed_two_second_deadline(self):
        probe = self.ready_probe()
        for _ in range(45):
            probe.observe(.3)
        self.assertEqual(probe.phase, 'decelerate')
        self.assertEqual(probe.target(4.), 0.)
        for _ in range(5):
            probe.observe(0.)
        self.assertEqual(probe.phase, 'hold')
        for _ in range(10):
            probe.observe(0.)
        self.assertEqual(probe.phase, 'recovery')
        self.assertEqual(probe.target(4.), 4.)

    def test_each_failed_stage_has_a_deadline(self):
        startup = StopRestartProbe()
        for _ in range(100):
            startup.observe(0.)
        self.assertEqual(startup.failure, 'startup_timeout')
        stop = self.ready_probe()
        for _ in range(80):
            stop.observe(.3)
        self.assertEqual(stop.failure, 'stop_timeout')
        self.assertEqual(stop.target(4.), 0.)
        recovery = self.ready_probe()
        for _ in range(15):
            recovery.observe(0.)
        for _ in range(60):
            recovery.observe(.5)
        self.assertEqual(recovery.failure, 'recovery_timeout')

    def test_holding_must_remain_stationary(self):
        probe = self.ready_probe()
        for _ in range(5):
            probe.observe(0.)
        probe.observe(.2)
        self.assertEqual(probe.failure, 'hold_drift')

    def test_validator_requires_measured_stop_and_all_phases(self):
        rows = healthy_probe()
        result = validate_control_health(rows, {'complete': 1}, 'off', True, 'paper_v9')
        self.assertTrue(result['empty_road_health_ok'], result)
        truncated = [row for row in rows if row['control_probe_phase'] != 'hold']
        self.assertFalse(validate_control_health(truncated, {'complete': 1}, 'off', True,
            'paper_v9')['empty_road_health_ok'])
        rows[-1]['control_probe_failure'] = 'hold_drift'
        self.assertFalse(validate_control_health(rows, {'complete': 1}, 'off', True,
            'paper_v9')['empty_road_health_ok'])

    def test_initial_startup_is_not_an_unexpected_mid_drive_stop(self):
        rows = [evidence('startup', 0., 0., k) for k in range(35)]
        result = validate_control_health(rows, {'complete': 1}, 'off', False, 'paper_v9')
        self.assertEqual(result['longest_non_goal_stop_s'], 0.)
        # Calling it startup cannot bypass the mandatory probe for real launches.
        self.assertFalse(validate_control_health(rows, {'complete': 1}, 'off', True,
            'paper_v9')['empty_road_health_ok'])

    def test_high_deceleration_and_throttle_during_stop_are_still_rejected(self):
        rows = healthy_probe()
        row = next(r for r in rows if r['control_probe_phase'] == 'decelerate')
        row.update(ego_v_before='3.', ego_v_after='2.', ego_acc_measured='-20.',
            ego_v_signed_before='3.', ego_v_signed_after='2.', ego_acc_signed='-20.',
            a_cmd='-3.', throttle='.403', requested_throttle='.403')
        result = validate_control_health(rows, {'complete': 1}, 'off', True, 'paper_v9')
        self.assertFalse(result['empty_road_health_ok'])
        self.assertEqual(result['severe_deceleration_rows'], 1)
        self.assertEqual(result['actuator_contract_errors']['throttle_during_braking'], 1)

    def test_feedback_mismatch_and_reverse_cannot_pass(self):
        row = evidence('', 1., 1., 1)
        row.update(requested_brake='.001234', reverse='1')
        result = validate_control_health([row], {'complete': 1}, 'on', False, 'paper_v9')
        self.assertFalse(result['actuator_contract_ok'])
        self.assertEqual(result['actuator_contract_errors']['pedal_feedback_brake'], 1)
        self.assertEqual(result['actuator_contract_errors']['drivetrain_flags'], 1)

    def test_logger_retains_small_brake_and_extra_columns(self):
        from Planning_library.interaction_logger import InteractionLogger
        ego = S(x=0., y=0., yaw=0., v=1., vx=1., vy=0.)
        with tempfile.TemporaryDirectory() as directory:
            logger = InteractionLogger(out_dir=directory, enabled=True)
            logger.begin_episode(1)
            logger.ego_row(ego=ego, control=dict(brake=.001234, requested_brake=.001234,
                ego_acc_signed=-.5, gear=1, reverse=0, control_probe_phase='hold',
                control_probe_failure='', control_probe_phase_seconds=.25))
            logger.close()
            with (Path(directory)/'interaction_ego.csv').open(encoding='utf8') as stream:
                row = next(csv.DictReader(stream))
        self.assertEqual(float(row['brake']), .001234)
        self.assertEqual(row['requested_brake'], row['brake'])
        self.assertEqual(float(row['ego_acc_signed']), -.5)
        self.assertEqual(row['gear'], '1')
        self.assertEqual(row['control_probe_phase'], 'hold')

    def test_default_comparison_uses_same_v9_controller(self):
        from Tools.run_relay_validation import main
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            self.assertEqual(main(['--dry-run', '--control-profile', 'paper_v9']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertTrue(all(c['DSH_CONTROL_PROFILE'] == 'paper_v9' for c in configs))
        self.assertTrue(all(c['DSH_EFE'] == c['DSH_WCV_BCV'] == '0' for c in configs))
        self.assertEqual({k for k in configs[0] if configs[0][k] != configs[1][k]},
            {'DSH_METHOD', 'DSH_TAKE_COURNOT'})

    def test_optimizer_objective_is_unchanged_between_v8_and_v9(self):
        from Agent.game_theory.MPC import MPCController
        results = []
        for profile in ('paper_v8', 'paper_v9'):
            ego = S(x=0., y=0., yaw=0., v=2., vx=2., vy=0., length=4., width=2.)
            dynamic = S(ego_vehicle=ego, objects=[], lanes=[S(front_vehicles=[], rear_vehicles=[])])
            controller = MPCController(16, .05, 2.7, .5, enable_lead_follow_cost=False,
                enable_boundary_thw=False, enable_cournot_cost=True, cost_profile=profile,
                step_dts=[.05]*6+[.2]*10,
                vehicle_geometry=dict(l_f=1.425, l_r=1.425, wheelbase=2.85, max_steer=1.2))
            controller.reset_global_path(np.c_[np.arange(60.), np.zeros(60)], dynamic)
            controller.set_game_context(dict(observed_vehicles=[]), ego)
            results.append(controller.solve(dynamic, 4., False))
            self.assertTrue(controller._solve_ok)
        np.testing.assert_allclose(*results, atol=1e-6)


if __name__ == '__main__':
    unittest.main()
