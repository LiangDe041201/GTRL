import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from Planning_library.candidate_learning_v19 import task_reward
from Planning_library.entry_planner_v35 import EntryLearnerV35


def discounted_score(reward, gamma, speeds, outcome):
    return sum(gamma**index * reward(dict(ego_v_after=speed, a_cmd=0.), .05,
                                    outcome if index == len(speeds)-1 else None)
               for index, speed in enumerate(speeds))


class RewardV36Tests(unittest.TestCase):
    def test_slow_completion_outranks_faster_initial_motion_then_stuck(self):
        from Planning_library.reward_planner_v36 import RewardLearnerV36, task_reward_v36
        completion = [3.]*150 + [0.]*2000 + [3.]*350
        stalled = [3.]*200 + [0.]*1900
        old_gamma = EntryLearnerV35().gamma
        self.assertLess(discounted_score(task_reward,old_gamma,completion,'complete'),
                        discounted_score(task_reward,old_gamma,stalled,'stuck'))
        gamma = RewardLearnerV36().gamma
        self.assertGreater(discounted_score(task_reward_v36,gamma,completion,'complete'),
                           discounted_score(task_reward_v36,gamma,stalled,'stuck'))

    def test_delaying_an_identical_stuck_outcome_does_not_increase_its_score(self):
        from Planning_library.reward_planner_v36 import RewardLearnerV36, task_reward_v36
        gamma = RewardLearnerV36().gamma
        self.assertLess(discounted_score(task_reward_v36,gamma,[0.]*2400,'stuck'),
                        discounted_score(task_reward_v36,gamma,[0.]*1800,'stuck'))

    def test_reward_charges_time_and_intervention_without_speed_bonus(self):
        from Planning_library.reward_planner_v36 import task_reward_v36
        stopped, moving = dict(ego_v_after=0.,a_cmd=1.5), dict(ego_v_after=4.,a_cmd=1.5)
        self.assertAlmostEqual(task_reward_v36(stopped),-.05*(.06+.01*.25))
        self.assertEqual(task_reward_v36(stopped),task_reward_v36(moving))
        self.assertAlmostEqual(task_reward_v36(moving,outcome='collision',intervention=True),
                               -10.-.05*(.06+.01*.25+.02))

    def test_frozen_model_must_use_the_new_reward_signature(self):
        from Planning_library.reward_planner_v36 import RewardLearnerV36
        with TemporaryDirectory() as directory:
            checkpoint = Path(directory)/'checkpoint.json'
            EntryLearnerV35().save(checkpoint)
            with self.assertRaisesRegex(ValueError,'schema differs'):
                RewardLearnerV36('eval',checkpoint)
            learner=RewardLearnerV36()
            learner.save(checkpoint)
            frozen=RewardLearnerV36('eval',checkpoint)
            self.assertEqual(frozen.signature(),learner.signature())
            self.assertAlmostEqual(frozen.gamma**1200,.5)

    def test_runner_selects_reward_v36_with_original_cg_baseline(self):
        from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
        from Planning_library.reward_planner_v36 import RewardLearnerV36
        from Tools.run_dense_validation_v30 import build_plan
        train,evaluate=build_plan('unused',150,6,learner='reward_v36')
        self.assertEqual(train['arms'],['U13_reward_train_v36'])
        self.assertEqual(evaluate['arms'],['M6_matrix_v18','U14_reward_eval_v36'])
        self.assertEqual((train['episodes_total'],evaluate['episodes_total']),(150,60))
        self.assertIs(select_rolling_planner('reward_v36').LEARNER_CLASS,RewardLearnerV36)
