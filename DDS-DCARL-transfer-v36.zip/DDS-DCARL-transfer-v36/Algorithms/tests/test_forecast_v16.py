"""Behavior regressions for coverage, stop semantics, score and audit linkage."""
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest

import numpy as np

from Planning_library.execution_guard import select_execution, execution_forecast, rollout
from Planning_library.forecast_v16 import predict, prediction_geometry, ForecastRecorder
from Planning_library.matrix_turn_game_v16 import MatrixTurnGameV16, score_candidates
from Planning_library.cournot_game import expected_payoff_response
from Tools.run_relay_validation import main as relay_main
from Tools.validate_matrix_game import validate_matrix_game
from Tools.validate_forecast_v16 import validate_forecast

PATH = np.c_[np.arange(0., 8.01, .5), np.zeros(17)]
PUBLIC = np.c_[np.arange(0., 100.01, .5), np.zeros(201)]
OLD = dict(wheelbase=2.86, max_steer=1., execution_horizon=6.,
           brake_response_jerk=.5, low_speed_brake_taper=.5)
GEOMETRY = prediction_geometry(OLD, PUBLIC, 'route_v16')
PREVIOUS = dict(a=1.6, df=0.)


def vehicle(ident=1, x=0., y=0., yaw=0., v=.1, acc=1.8):
    return S(veh_id=ident, x=x, y=y, yaw=yaw, v=v, acc=acc, acc_source='velocity_difference',
             vx=v*math.cos(yaw), vy=v*math.sin(yaw), length=4.5, width=1.8)


def candidate(target, a=1.6, ok=True):
    return dict(target=target, a=a, delta=0., solve_ok=ok, prediction=None, plan=None, times=None)


class ForecastV16Tests(unittest.TestCase):
    def test_stop_does_not_accumulate_positive_acceleration_for_seconds(self):
        for lag in (0., .4):
            states, _, d = predict(vehicle(), PATH, 0., 1.6, 0., PREVIOUS, GEOMETRY, lag=lag)
            self.assertTrue(d['valid'], d)
            self.assertLess(states[5].max(), .8)
            self.assertLess(states[5, -1], .1)
            self.assertLess(d['progress_m'], 2.)
            self.assertLessEqual(d['command_max'], 0.)

    def test_proceed_uses_public_route_after_the_local_path_end(self):
        states, _, d = predict(vehicle(), PATH, 4., 1.6, 0., PREVIOUS, GEOMETRY)
        self.assertTrue(d['valid'], d)
        self.assertEqual(d['source'], 'public_route')
        self.assertGreater(d['progress_m'], 8.)
        self.assertLess(states[5].max(), 5.)
        self.assertGreater(states[0, -1], states[0, 0])

    def test_missing_route_is_explicitly_invalid_without_turning_back(self):
        states, _, d = predict(vehicle(), PATH, 4., 1.6, 0., PREVIOUS, OLD)
        self.assertFalse(d['valid'])
        self.assertTrue(d['coverage_exhausted'])
        self.assertTrue(np.all(np.diff(states[0]) >= 0.))
        self.assertGreater(d['progress_m'], 7.)

    def test_distant_or_reversed_public_continuations_are_rejected(self):
        for route in (PUBLIC+[0., 20.], PUBLIC[::-1]):
            _, _, d = predict(vehicle(), PATH, 4., 1.6, 0., PREVIOUS,
                              prediction_geometry(OLD, route, 'route_v16'))
            self.assertEqual(d['source'], 'join_rejected')
            self.assertFalse(d['valid'])

    def test_known_route_end_is_approached_as_a_stop_destination(self):
        geometry = prediction_geometry(OLD, PUBLIC[:21], 'route_v16')
        states, _, d = predict(vehicle(v=2., acc=0.), PATH, 4., 0., 0., PREVIOUS, geometry)
        self.assertTrue(d['valid'], d)
        self.assertLess(states[0, -1], 10.5)
        self.assertLess(states[5, -1], 1.)

    def test_curved_route_has_positive_progress_without_a_terminal_uturn(self):
        theta = np.linspace(0., math.pi/2., 50)
        curved = np.c_[10.*np.sin(theta), 10.*(1.-np.cos(theta))]
        route = np.vstack((curved, np.c_[np.full(40, 10.), np.arange(10.5, 30.1, .5)]))
        states, _, d = predict(vehicle(v=1., acc=0.), curved[:25], 4., .5, .15,
            dict(a=.5, df=.15), prediction_geometry(OLD, route, 'route_v16'))
        self.assertTrue(d['valid'], d)
        self.assertGreater(d['progress_m'], 10.)
        self.assertLess(d['max_cross_track'], 2.)

    def test_longitudinal_progress_does_not_reward_driving_away_from_route(self):
        _, _, d = predict(vehicle(yaw=math.pi, v=4., acc=0.), PATH, 4., 0., 0.,
                           PREVIOUS, GEOMETRY)
        self.assertFalse(d['valid'])
        self.assertEqual(d['progress_m'], 0.)

    def test_both_candidates_have_independent_state_and_safe_go_beats_stop(self):
        ego = vehicle(); before = vars(ego).copy(); previous = dict(PREVIOUS)
        candidates = [candidate(0.), candidate(4.)]
        original = [dict(c) for c in candidates]
        matrix, parts = score_candidates(ego, [], None, candidates, GEOMETRY, PATH, previous, 4.4)
        self.assertEqual(expected_payoff_response(matrix, .5)['ego_action'], 1)
        self.assertGreater(parts[1][0]['progress'], parts[0][0]['progress'])
        self.assertTrue(all(c['forecast_valid'] for row in parts for c in row))
        self.assertEqual(vars(ego), before); self.assertEqual(previous, PREVIOUS)
        self.assertEqual(candidates, original)

    def test_invalid_forecast_cannot_be_a_safe_guard_proposal(self):
        selected, audit = select_execution(vehicle(), [], PATH, 4., 1.6, 0., PREVIOUS,
            dict(OLD, forecast_model='route_v16'), prediction=np.zeros((7, 2)),
            prediction_times=np.array([0., .1]))
        self.assertTrue(audit['override'])
        self.assertEqual(selected['action'], 'brake')
        self.assertTrue(any(not c['forecast_valid'] for c in audit['candidates']))

    def test_legacy_dispatch_keeps_the_same_numerical_forecast(self):
        expected, t = rollout(vehicle(), PATH, 4., 1.6, 0., PREVIOUS, OLD, horizon=6.)
        actual, u, diag = execution_forecast(vehicle(), PATH, 4., 1.6, 0., PREVIOUS, OLD, horizon=6.)
        np.testing.assert_array_equal(expected, actual)
        np.testing.assert_array_equal(t, u); self.assertIsNone(diag)

    def test_all_invalid_guard_forecasts_choose_brake_and_report_unknown_safety(self):
        selected, audit = select_execution(vehicle(y=20.), [], PATH, 4., 1.6, 0.,
                                           PREVIOUS, GEOMETRY)
        self.assertEqual(selected['action'], 'brake')
        self.assertFalse(audit['safe'])
        self.assertTrue(audit['unavoidable'])
        self.assertTrue(all(not c['forecast_valid'] for c in audit['candidates']))

    def test_empty_actor_forecast_journal_remains_valid_json(self):
        selected, audit = select_execution(vehicle(), [], PATH, 0., -.3, 0., PREVIOUS, GEOMETRY)
        with tempfile.TemporaryDirectory() as directory:
            ForecastRecorder(directory, GEOMETRY).record(1, 1, audit,
                dict(a_cmd=selected['a'], actuator_speed_target=selected['target']))
            row=json.loads((Path(directory)/'forecast_audit.jsonl').read_text())
            self.assertIsNone(row['candidates'][0]['gap'])

    def test_four_arm_dry_run_has_fair_common_predictions_and_no_learning(self):
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(relay_main(['--dry-run', '--method', 'CG', '--arms',
                'B2_rule_spatial,M3_matrix_spatial,B3_rule_forecast,M4_matrix_forecast']), 0)
        configs = [json.loads(s)['effective'] for s in stream.getvalue().splitlines()]
        self.assertEqual([c['DSH_FORECAST_MODEL'] for c in configs], ['legacy', 'legacy', 'route_v16', 'route_v16'])
        self.assertTrue(all(c['DSH_EFE'] == c['DSH_WCV_BCV'] == '0' for c in configs))
        self.assertEqual(configs[-1]['DSH_COURNOT_MODE'], 'matrix_v16')
        self.assertEqual(configs[-1]['DSH_COURNOT_AUTHORITY'], 'matrix_entry')

    def test_records_link_payoff_forecast_and_applied_control_and_reject_corruption(self):
        ego, rv = vehicle(v=0., acc=0.), vehicle(2, 25., 20., math.pi, 4., 0.)
        with tempfile.TemporaryDirectory() as directory:
            game = MatrixTurnGameV16(GEOMETRY, directory=directory)
            game.prepare(ego, [rv], dict(rv_veh=rv, conflict_x=0., conflict_y=20.),
                         4., 1., (100., 0., 0.))
            cs = [candidate(0., -.3), candidate(4., .1)]
            chosen = game.choose(ego, [rv], rv, {}, cs, PATH, dict(a=0., df=0.))
            c = cs[chosen]
            selected, audit = select_execution(ego, [rv], PATH, c['target'], c['a'], 0.,
                dict(a=0., df=0.), GEOMETRY, prediction=np.zeros((7, 2)), prediction_times=np.array([0., .1]))
            applied = dict(a_cmd=selected['a'], delta_rad=0., actuator_speed_target=selected['target'], control_submit_ok=1)
            game.record(1, 1, c['a'], 0., c['target'], audit, applied)
            recorder = ForecastRecorder(directory, GEOMETRY); recorder.record(1, 1, audit, applied)
            row = dict(episode='1', frame='1', a_mpc=str(c['a']), delta_mpc_rad='0',
                a_cmd=str(selected['a']), delta_rad='0', v_ref=str(selected['target']),
                actuator_speed_target=str(selected['target']), guard_action=audit['action'],
                mpc_audit_override=str(int(audit['override'])), guard_safe=str(int(audit['safe'])),
                mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10', ego_v='0')
            self.assertTrue(validate_matrix_game(directory, [row], 'matrix_v16')['matrix_contract_ok'])
            self.assertTrue(validate_forecast(directory, [row])['forecast_contract_ok'])
            path = Path(directory)/'matrix_decisions.jsonl'
            saved = json.loads(path.read_text()); saved['components'][1][0]['forecast_penalty'] = 4.
            path.write_text(json.dumps(saved)+'\n')
            self.assertFalse(validate_matrix_game(directory, [row], 'matrix_v16')['matrix_contract_ok'])
            path = Path(directory)/'forecast_audit.jsonl'
            saved = json.loads(path.read_text()); saved['candidates'][0]['forecasts'][0]['valid'] = False
            path.write_text(json.dumps(saved)+'\n')
            self.assertFalse(validate_forecast(directory, [row])['forecast_contract_ok'])


if __name__ == '__main__':
    unittest.main()
