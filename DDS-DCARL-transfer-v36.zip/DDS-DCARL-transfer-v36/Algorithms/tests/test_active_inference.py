#!/usr/bin/env python3
"""阶段 5 ②/③：主动推理 EFE 奖励 + WCV/BCV 方差修正 + 接管规则的单元测试（纯 stdlib）。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.active_inference import (
    rv_intent_entropy,
    risk_term,
    ambiguity_term,
    expected_free_energy,
    efe_reward,
    monte_carlo_q,
    reward_to_go,
    variance_corrected_wcv,
    wcv_bcv,
    takeover_rule,
    # ===== 式52/55/56/57 论文原式：逐动作 EFE(s,a) =====
    OBS_CLASSES,
    PREF_WEIGHTS,
    observation_entropy,
    kl_divergence,
    preferred_observation,
    predicted_observation,
    behavior_ambiguity,
    cognitive_risk,
    action_efe,
    action_efe_reward,
    efe_by_action,
)


class TestRVIntentEntropy(unittest.TestCase):
    """式18：对手让行意图熵。"""

    def test_fully_determined_zero(self):
        self.assertAlmostEqual(rv_intent_entropy(0.0), 0.0, places=9)
        self.assertAlmostEqual(rv_intent_entropy(1.0), 0.0, places=9)

    def test_max_at_half(self):
        h05 = rv_intent_entropy(0.5)
        self.assertAlmostEqual(h05, 1.0, places=9)   # 式18 用 log2：二元均匀分布 = 1 bit
        self.assertGreater(h05, rv_intent_entropy(0.7))
        self.assertGreater(h05, rv_intent_entropy(0.2))

    def test_clamped(self):
        self.assertEqual(rv_intent_entropy(9.0), rv_intent_entropy(1.0))
        self.assertEqual(rv_intent_entropy(-1.0), rv_intent_entropy(0.0))


class TestEfeTerms(unittest.TestCase):
    """式56/57：EFE = risk + ambiguity；reward = -EFE。"""

    def test_risk_monotonic(self):
        # 偏离越大 risk 越大；零偏离 zero risk
        self.assertEqual(risk_term(0.0), 0.0)
        self.assertGreater(risk_term(2.0), risk_term(1.0))

    def test_ambiguity_adds_entropy_and_variance(self):
        self.assertEqual(ambiguity_term(0.0, 0.0), 0.0)
        self.assertGreater(ambiguity_term(0.5, 0.5), ambiguity_term(0.3, 0.3))
        self.assertGreater(ambiguity_term(0.5, 0.0), ambiguity_term(0.0, 0.0))

    def test_efe_is_risk_plus_ambiguity(self):
        self.assertAlmostEqual(
            expected_free_energy(1.5, 0.4, 0.2, w_risk=2.0, w_amb=1.0),
            risk_term(1.5, 2.0) + ambiguity_term(0.4, 0.2, 1.0))

    def test_reward_is_negative_efe(self):
        for dev, ent, var in [(0.0, 0.0, 0.0), (1.0, 0.5, 0.3), (3.0, 0.4, 0.1)]:
            self.assertAlmostEqual(efe_reward(dev, ent, var),
                                   -expected_free_energy(dev, ent, var))
            self.assertLessEqual(efe_reward(dev, ent, var), 0.0)

    def test_reward_more_negative_with_more_uncertainty(self):
        self.assertLess(efe_reward(1.0, 0.5, 0.5), efe_reward(1.0, 0.5, 0.1))


class TestMonteCarloQ(unittest.TestCase):
    """式58/59：蒙特卡洛 Q̂ = mean(returns)。"""

    def test_mean_of_returns(self):
        self.assertAlmostEqual(monte_carlo_q([1.0, 3.0, 2.0]), 2.0)

    def test_empty(self):
        self.assertEqual(monte_carlo_q([]), 0.0)


class TestRewardToGo(unittest.TestCase):
    """式58/59：回合级折扣回报 G_t = Σ_{k>=t} γ^{k-t} r_k（信用分配）。"""

    def test_last_equals_last_reward(self):
        G = reward_to_go([1.0, 2.0, 3.0], gamma=0.5)
        self.assertAlmostEqual(G[-1], 3.0)

    def test_discounted_backward(self):
        # G_2=3; G_1=2+0.5*3=3.5; G_0=1+0.5*3.5=2.75
        G = reward_to_go([1.0, 2.0, 3.0], gamma=0.5)
        self.assertAlmostEqual(G[2], 3.0)
        self.assertAlmostEqual(G[1], 3.5)
        self.assertAlmostEqual(G[0], 2.75)

    def test_terminal_penalty_propagates_backward(self):
        # 【关键】终局碰撞 −300 位于末帧，必须回传到前面每一帧（信用分配）
        G = reward_to_go([10.0, 10.0, 10.0, -300.0], gamma=0.9)
        self.assertLess(G[0], 0.0)     # 早期"加速"帧也被终局惩罚拖成负
        self.assertGreater(G[0], G[3]) # 越早折扣越多 → 负得越少（G[3]=−300 最负）
        self.assertLess(G[0], 10.0)    # 不再是"只看当帧正奖励"

    def test_empty(self):
        self.assertEqual(reward_to_go([]), [])


class TestVarianceCorrectedWcv(unittest.TestCase):
    """式43/44/45 + 式60：Hoeffding WCV/BCV，方差修正压低保守下界。"""

    def test_wcv_below_mean_bcv_above(self):
        wcv, bcv, mean, var = variance_corrected_wcv([10.0, 12.0, 11.0], alpha=0.05,
                                                     reward_range=10.0, var_weight=1.0)
        self.assertLess(wcv, mean)
        self.assertGreater(bcv, mean)
        self.assertAlmostEqual(mean, 11.0)

    def test_variance_correction_lowers_wcv(self):
        # 同一均值/范围下，高方差样本 -> WCV 更低（式60 保守下界）
        lo, _, _, _ = variance_corrected_wcv([5.0, 5.0, 5.0], reward_range=10.0, var_weight=1.0)
        hi, _, _, _ = variance_corrected_wcv([0.0, 5.0, 10.0], reward_range=10.0, var_weight=1.0)
        self.assertLess(hi, lo)  # 方差大 -> WCV 更保守

    def test_var_weight_zero_gives_pure_hoeffding(self):
        # var_weight=0 退化为纯 Hoeffding：WCV = mean - ε（式44，不含式60修正）
        samples = [10.0, 12.0, 11.0]
        wcv, bcv, mean, var = variance_corrected_wcv(samples, alpha=0.05,
                                                     reward_range=10.0, var_weight=0.0)
        eps = 10.0 * (0.05 ** 0.5) * 0.0  # placeholder
        import math
        eps = 10.0 * math.sqrt(math.log(1.0 / 0.05) / (2.0 * len(samples)))
        self.assertAlmostEqual(wcv, mean - eps)
        self.assertAlmostEqual(bcv, mean + eps)

    def test_empty_samples(self):
        self.assertEqual(wcv_bcv([]), (0.0, 0.0, 0.0, 0.0))

    def test_variance_correction_scale_not_swamping(self):
        """回归：方差修正必须用 σ（不是 σ²），否则会淹没均值 → WCV 恒远低于 BCV →
        真实数据永远无法接管、只剩哨兵值能'赢'（实测 300 回合性能崩溃的根因）。"""
        import numpy as _np
        rs = _np.random.RandomState(0)
        samples = rs.normal(100.0, 150.0, 200)      # mean≈100, std≈150（奖励量级 ~10²）
        wcv, bcv, mean, var = variance_corrected_wcv(samples, alpha=0.05,
                                                     reward_range=80.0, var_weight=0.5)
        self.assertLess(wcv, mean)                   # 仍保守
        self.assertGreater(wcv, mean - 5.0 * 150.0)  # 修正量同量级，不是 -10⁴
        self.assertGreater(bcv, mean)


class TestTakeoverRule(unittest.TestCase):
    """式46 接管规则。"""

    def test_takeover_when_alt_wcv_exceeds_default_bcv(self):
        # 默认动作 BCV=0；某动作 WCV=2 > 0 -> 发生接管，选 WCV 最大者
        act, took = takeover_rule({0: 0.5, 1: 2.0, 2: 1.5}, bcv_default=0.0, default_act=0)
        self.assertTrue(took)
        self.assertEqual(act, 1)

    def test_no_takeover_when_none_exceeds(self):
        act, took = takeover_rule({1: -1.0, 2: -2.0}, bcv_default=0.0, default_act=0)
        self.assertFalse(took)
        self.assertEqual(act, 0)

    def test_default_action_ignored(self):
        # 默认动作自身即便 WCV 大也不应被当作接管控对象
        act, took = takeover_rule({1: 3.0}, bcv_default=0.0, default_act=0)
        self.assertTrue(took)
        self.assertEqual(act, 1)


class TestObservationModel(unittest.TestCase):
    """式54/55：博弈观测模型（clear/tight/stalled/blocked 四类）。"""

    def test_classes_and_preference_are_consistent(self):
        self.assertEqual(len(OBS_CLASSES), 4)
        self.assertEqual(len(PREF_WEIGHTS), 4)
        p = preferred_observation()
        self.assertAlmostEqual(float(p.sum()), 1.0, places=9)
        # 偏好次序：clear > stalled > tight > blocked
        clear, tight, stalled, blocked = p
        self.assertGreater(clear, stalled)
        self.assertGreater(stalled, blocked)
        self.assertGreater(tight, blocked)

    def test_entropy_uses_natural_log(self):
        # 式55 用 ln：三类均匀 = ln3 ≈ 1.0986（若误用 log2 会得到 1.585）
        self.assertAlmostEqual(observation_entropy([1 / 3, 1 / 3, 1 / 3]),
                               1.0986122886681098, places=9)
        self.assertEqual(observation_entropy([1.0, 0.0, 0.0]), 0.0)
        self.assertEqual(observation_entropy([]), 0.0)

    def test_kl_nonneg_and_zero_for_identical(self):
        p = [0.5, 0.25, 0.25]
        self.assertAlmostEqual(kl_divergence(p, p), 0.0, places=6)
        self.assertGreater(kl_divergence([1.0, 0.0, 0.0], [0.1, 0.45, 0.45]), 0.0)

    def test_predicted_observation_is_distribution(self):
        for m, te in [(0.1, 1.0), (3.0, 1.0), (1.2, 1.0), (3.0, 100.0)]:
            q = predicted_observation(m, clearance=1.0, sigma=0.35, t_ego=te, horizon=6.0)
            self.assertAlmostEqual(float(q.sum()), 1.0, places=9)
            self.assertTrue((q >= -1e-12).all())

    def test_large_margin_is_clear(self):
        q = predicted_observation(5.0, clearance=1.0, sigma=0.35, t_ego=1.0, horizon=6.0)
        self.assertGreater(q[0], 0.99)                    # clear

    def test_small_margin_is_blocked(self):
        q = predicted_observation(0.0, clearance=1.0, sigma=0.35, t_ego=1.0, horizon=6.0)
        self.assertGreater(q[3], 0.99)                    # blocked

    def test_unreachable_is_stalled(self):
        q = predicted_observation(5.0, clearance=1.0, sigma=0.35,
                                  t_ego=float('inf'), horizon=6.0)
        self.assertAlmostEqual(q[2], 1.0, places=9)       # stalled

    def test_infinite_margin_is_clear_not_nan(self):
        # t_RV = inf（RV 让行停住）时裕度为 inf：必须落在 clear，不能出现 nan
        q = predicted_observation(float('inf'), clearance=1.0, sigma=0.35,
                                  t_ego=1.0, horizon=6.0)
        self.assertFalse(any(x != x for x in q))          # 无 nan
        self.assertGreater(q[0], 0.99)


class TestActionEfe(unittest.TestCase):
    """式56/57：EFE(s,a) = r_cognition + r_behavior；R(s,a) = -EFE(s,a)。"""

    BELIEF = {'aggressive': 1 / 3, 'normal': 1 / 3, 'conservative': 1 / 3}
    YP = {'aggressive': 0.2, 'normal': 0.5, 'conservative': 0.8}

    def test_ambiguity_is_conditional_observation_entropy(self):
        det = {'t1': [1.0, 0.0, 0.0], 't2': [1.0, 0.0, 0.0]}
        self.assertAlmostEqual(behavior_ambiguity(det, [0.5, 0.5]), 0.0, places=9)
        mixed = {'t1': [0.5, 0.5, 0.0], 't2': [0.5, 0.5, 0.0]}
        self.assertAlmostEqual(behavior_ambiguity(mixed, [0.5, 0.5]),
                               observation_entropy([0.5, 0.5, 0.0]), places=9)

    def test_cognitive_risk_equals_kl_of_marginal(self):
        cond = {'t1': [1.0, 0.0, 0.0], 't2': [0.0, 1.0, 0.0]}
        q_marg = [0.5, 0.5, 0.0]
        self.assertAlmostEqual(cognitive_risk(cond, [0.5, 0.5]),
                               kl_divergence(q_marg, preferred_observation()), places=9)

    def test_reward_is_negative_efe(self):
        cond = {'t1': [0.4, 0.3, 0.3]}
        r = action_efe_reward(cond, [1.0])
        self.assertAlmostEqual(r, -action_efe(cond, [1.0]), places=9)
        self.assertLessEqual(r, 0.0)

    def test_efe_by_action_prefers_safe_passage_over_braking_and_collision(self):
        """核心口径：EFE 最偏好"安全高效通过"，其次"停滞等待"，最差"冲突"。"""
        margins = {
            0: {'yield': 5.0, 'rush': 5.0},      # 刹停（stalled）
            5: {'yield': 1.0, 'rush': 0.05},     # 会与抢行的 RV 冲突（blocked）
            7: {'yield': 3.0, 'rush': 2.6},      # 安全通过（clear）
        }
        t_ego = {0: float('inf'), 5: 2.0, 7: 1.0}
        clr = {0: 1.0, 5: 1.0, 7: 0.5}
        yp = {a: dict(self.YP) for a in margins}
        res = efe_by_action(margins, yp, self.BELIEF, clr, t_ego,
                            horizon=6.0, sigma=0.35)
        self.assertLess(res[7]['efe'], res[0]['efe'])       # 通过 优于 停滞
        self.assertLess(res[0]['efe'], res[5]['efe'])       # 停滞 优于 冲突
        self.assertLess(res[7]['reward'], 0.0)

    def test_efe_is_per_action_not_state_constant(self):
        """回归：EFE 必须随候选动作变化（否则它只是状态价值平移，接不到动作选择上）。"""
        margins = {a: {'yield': m, 'rush': m * 0.1}
                   for a, m in {0: 5.0, 1: 4.0, 2: 3.0, 3: 2.0, 4: 1.0}.items()}
        t_ego = {a: 8.0 / max(v, 0.5) for a, v in {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 5.0}.items()}
        yp = {a: dict(self.YP) for a in margins}
        res = efe_by_action(margins, yp, self.BELIEF, None, t_ego, horizon=6.0)
        efes = [res[a]['efe'] for a in sorted(res)]
        self.assertGreater(max(efes) - min(efes), 1e-3)

    def test_ambiguity_is_belief_average_of_conditional_entropies(self):
        """r_behavior = Σ_τ b(τ)·H(q_τ)：后验单点 → 该类型条件熵；均匀后验 → 三者均值。"""
        margins = {3: {'yield': 2.0, 'rush': 0.2}}
        t_ego = {3: 1.5}
        yp = {3: {'aggressive': 0.1, 'normal': 0.5, 'conservative': 0.9}}
        base = efe_by_action(margins, yp, {'aggressive': 1 / 3, 'normal': 1 / 3,
                                           'conservative': 1 / 3}, None, t_ego)
        hs = {k: observation_entropy(v) for k, v in base[3]['cond_dists'].items()}
        for k in hs:
            point = {t: (1.0 if t == k else 0.0) for t in hs}
            res = efe_by_action(margins, yp, point, None, t_ego)
            self.assertAlmostEqual(res[3]['r_behavior'], hs[k], places=9)
        self.assertAlmostEqual(base[3]['r_behavior'],
                               sum(hs.values()) / len(hs), places=9)


if __name__ == "__main__":
    unittest.main()
