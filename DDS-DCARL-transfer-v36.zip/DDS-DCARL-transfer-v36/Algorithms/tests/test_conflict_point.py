#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【BUG-1 回归测试】冲突点定位：必须取"沿行进方向首次穿越带北边缘"的点。

为什么需要这个测试（HANDOFF_2026-10-10.md §2 BUG-1）
------------------------------------------------------------------
旧实现 `cross_idx = argmin |path[:,1] - cross_y|` 在"参考路径尾段与交叉路平行"的
几何下**退化为任意点**：参考路径由 `global_routing()` 从
`goal_point = (-21, -138.51)` 生成，而该点**正落在交叉路中心线 y=-138 上**
⇒ 路径转弯完成后有约 27 m 沿着 y≈-138 一路向西，argmin 于是在约 10 个几乎
等距的点里随便挑，实测挑中最西端的 **x = -7.109**。

真实冲突点（车头跨过交叉带北边缘）实测是 **x ≈ 4.187**（60 回合中位）
⇒ **误差 11.3 m** ⇒ 直行车到达时间被系统性高估 **9 倍**（碰撞帧中位）。

本测试用**合成路径**复现该几何并钉住修复后的行为，另加一条用**真实录制的
参考路径**（`expS82_gap_seed1/path_diag.pkl`）的端到端断言。

注意：本文件**不导入 carla**，纯 numpy + 本仓库纯函数。
"""
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # Algorithms
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.define_state_space_turn import _find_conflict_point
from Planning_library.boundary_safety import BAND_HALF_DEFAULT

CROSS_Y = -138.0
#: 参考路径实测：车头跨过带北边缘时 ego_x 中位（60 回合）
BAND_ENTRY_X_MEASURED = 4.187
#: 旧口径在真实路径上挑中的点
LEGACY_X_MEASURED = -7.109


def _turn_then_parallel_path():
    """复现 BUG-1 的几何：先由北向南转弯，然后**沿 y≈-138 长距离向西平行**。

    这条路径与真实参考路径（`path_diag.pkl`）形状同构：
      · 接近段：x 从 6.0 缓变到 1.0，y 从 -120 降到 -138.4（自北向南）
      · 尾段：y **收敛到 -138.5 附近**，x 一路向西到约 -24

    ⚠️ 尾段的 y 必须**收敛**（而不是单调远离 -138），否则 argmin|cross_y|
    会挑到离 -138 最近的那个尾点（也就是最东的那个），复现不出 BUG-1。
    真实路径正是这样：尾段 y 从 -137.726 单调降到 -138.687，
    最小值 -138.138 出现在**中段**（index 21），而不是尾段末端。
    """
    pts = []
    # 接近段：y 从 -120 降到 -138.4，x 从 6.0 缓变到 1.0
    for i in range(0, 20):
        t = i / 19.0
        pts.append([6.0 - 5.0 * t, -120.0 - 18.4 * t])
    # 尾段：y 从 -138.4 **穿过 -138.0** 并收敛到 -137.7 附近。
    #   真实路径正是这个形状：尾段 y 从 -137.726 单调降到 -138.687，最小值 -138.138
    #   出现在**中段**（index 21）而不是尾段末端 ⇒ argmin 落到尾段中段（很西）。
    #   若尾段 y 单调远离 -138，argmin 会挑到最东的尾点，就复现不出 BUG-1。
    import math as _m
    for i in range(1, 17):
        y = -138.4 + 0.675 * (1.0 - _m.exp(-i / 3.0))
        pts.append([1.0 - 1.6 * i, y])
    return np.array(pts, dtype=float)


class TestConflictPointCrossing(unittest.TestCase):

    def test_crossing_picks_first_band_entry_not_the_parallel_tail(self):
        """新口径必须落在**穿越点**，而不是尾段。"""
        p = _turn_then_parallel_path()
        ci, cx, s, mode = _find_conflict_point(p, CROSS_Y)
        self.assertEqual(mode, 'crossing', '应走穿越口径')
        # 目标 y = -138 + 1 + 2.25 = -134.75；接近段在这里的 x 应仍为正值
        self.assertGreater(cx, 0.0,
                           f'冲突点应在路口内（x>0），实际 {cx:.3f} —— 疑似挑到了尾段')
        # 尾段最西端是 x = 1.0 - 1.5*14 = -20.0；新口径绝不能接近它
        self.assertGreater(cx, -5.0, f'冲突点不应落到尾段（x={cx:.3f}）')

    def test_legacy_mode_reproduces_the_bug(self):
        """旧口径必须**仍然**复现 BUG-1（证明 bug 是真的，不是我们记错）。

        判据：旧口径应落到**尾段**（x < 尾段起点的 x=1.0），而不是接近段。
        """
        p = _turn_then_parallel_path()
        _, cx_new, _, _ = _find_conflict_point(p, CROSS_Y)
        ci, cx, s, mode = _find_conflict_point(p, CROSS_Y, mode='legacy')
        self.assertTrue(mode.startswith('legacy'))
        # 尾段起点是 index 19（x=1.0）。旧口径必须落到尾段里（更西）
        self.assertLess(cx, 1.0,
                        f'旧口径本应挑到尾段（x<1.0），实际 {cx:.3f} —— '
                        f'合成路径可能没复现出"尾段平行"这个几何')
        self.assertGreater(abs(cx_new - cx), 3.0,
                           f'两口径只差 {abs(cx_new-cx):.2f} m，未体现 BUG-1')

    def test_crossing_vs_legacy_differ_by_more_than_5m(self):
        """两种口径的差距必须显著（BUG-1 的量级）。"""
        p = _turn_then_parallel_path()
        _, cx_new, _, _ = _find_conflict_point(p, CROSS_Y)
        _, cx_old, _, _ = _find_conflict_point(p, CROSS_Y, mode='legacy')
        self.assertGreater(abs(cx_new - cx_old), 5.0,
                           f'两口径只差 {abs(cx_new-cx_old):.2f} m，不足以体现 BUG-1')

    def test_arc_length_is_interpolated_at_crossing(self):
        """穿越点的弧长必须是线段内插值，不能落在路点网格上。"""
        p = _turn_then_parallel_path()
        ci, cx, s, mode = _find_conflict_point(p, CROSS_Y)
        seg_cum = 0.0
        for i in range(1, ci + 1):
            seg_cum += float(np.linalg.norm(p[i] - p[i - 1]))
        # s 必须 >= 到该段起点的累计弧长，且 <= 到该段终点的累计弧长
        seg_len = float(np.linalg.norm(p[ci + 1] - p[ci]))
        self.assertGreaterEqual(s, seg_cum - 1e-9)
        self.assertLessEqual(s, seg_cum + seg_len + 1e-9)
        # 并且严格落在段内（不是端点）⇒ 说明做了插值
        self.assertGreater(s, seg_cum + 1e-6, '弧长落在段起点 ⇒ 没插值')
        self.assertLess(s, seg_cum + seg_len - 1e-6, '弧长落在段终点 ⇒ 没插值')

    def test_monotone_south_path_crosses_exactly_once(self):
        """单调向南的路径：穿越点应唯一且与解析解一致。"""
        # y 从 0 线性降到 -10，x 恒为 3；目标 y = -138+1+2.25 不在此范围 ⇒ 走兜底
        p = np.array([[3.0, 0.0 - 1.0 * i] for i in range(11)], dtype=float)
        _, _, _, mode = _find_conflict_point(p, -4.0)
        self.assertEqual(mode, 'crossing')
        # 目标 y = -4 + 1 + 2.25 = -0.75 ⇒ 在 y=0 与 y=-1 之间，x 恒 3
        _, cx, _, _ = _find_conflict_point(p, -4.0)
        self.assertAlmostEqual(cx, 3.0, places=6)

    def test_fallback_when_path_never_crosses(self):
        """路径从不穿越 ⇒ 必须回退到 legacy，而不是抛异常或给垃圾值。"""
        p = np.array([[1.0, 0.0], [2.0, 1.0], [3.0, 2.0]], dtype=float)  # y 递增
        ci, cx, s, mode = _find_conflict_point(p, -138.0)
        self.assertTrue(mode.startswith('legacy'), f'应回退，实际 {mode}')

    def test_empty_or_degenerate_path_does_not_raise(self):
        """退化输入不能抛异常（这个函数在每帧的热路径上）。"""
        for bad in (np.zeros((0, 2)), np.zeros((1, 2))):
            ci, cx, s, mode = _find_conflict_point(bad, CROSS_Y)
            self.assertTrue(mode.startswith('legacy(empty)'))

    def test_nose_offset_shifts_crossing_point(self):
        """车头偏移越大 ⇒ 越早穿越 ⇒ x 应更大（更靠近路口北侧）。"""
        p = _turn_then_parallel_path()
        _, cx_small, _, _ = _find_conflict_point(p, CROSS_Y, nose_offset=0.0)
        _, cx_big, _, _ = _find_conflict_point(p, CROSS_Y, nose_offset=4.5)
        self.assertGreater(cx_big, cx_small,
                           '鼻子更长应更早触到带边缘 ⇒ x 更大')


class TestConflictPointOnRealPath(unittest.TestCase):
    """用**真实录制的参考路径**做端到端断言（这是 BUG-1 的原始证据）。"""

    PKL = os.path.join(_HERE, 'expS82_gap_seed1', 'path_diag.pkl')

    def _load(self):
        import pickle
        if not os.path.exists(self.PKL):
            self.skipTest(f'缺少真实路径数据 {self.PKL}（历史实验目录被清理？）')
        d = pickle.load(open(self.PKL, 'rb'))
        return np.asarray(d['static']['ref_path_array'], dtype=float)

    def test_new_mode_error_versus_measured_is_small(self):
        """新口径与实测 band_entry_x 的偏差应 < 3 m（旧口径偏 11.3 m）。"""
        p = self._load()
        _, cx, _, mode = _find_conflict_point(p, CROSS_Y)
        self.assertEqual(mode, 'crossing')
        err = abs(cx - BAND_ENTRY_X_MEASURED)
        self.assertLess(err, 3.0,
                        f'新口径 x={cx:.3f} 与实测 {BAND_ENTRY_X_MEASURED} 差 {err:.2f} m')

    def test_old_mode_reproduces_measured_bug(self):
        """旧口径在真实路径上必须复现 -7.109（BUG-1 的原始数字）。"""
        p = self._load()
        _, cx, _, _ = _find_conflict_point(p, CROSS_Y, mode='legacy')
        self.assertAlmostEqual(cx, LEGACY_X_MEASURED, places=2,
                               msg='旧口径复现不出 -7.109 ⇒ 路径数据或代码已变，'
                                   '需重新核对 HANDOFF §2 BUG-1')

    def test_improvement_is_at_least_7m(self):
        """修复必须把误差显著缩小（不是原地打转）。"""
        p = self._load()
        _, cx_new, _, _ = _find_conflict_point(p, CROSS_Y)
        _, cx_old, _, _ = _find_conflict_point(p, CROSS_Y, mode='legacy')
        err_new = abs(cx_new - BAND_ENTRY_X_MEASURED)
        err_old = abs(cx_old - BAND_ENTRY_X_MEASURED)
        self.assertGreater(err_old - err_new, 7.0,
                           f'误差只从 {err_old:.2f} 降到 {err_new:.2f} m，改善不足')


if __name__ == '__main__':
    unittest.main(verbosity=2)
