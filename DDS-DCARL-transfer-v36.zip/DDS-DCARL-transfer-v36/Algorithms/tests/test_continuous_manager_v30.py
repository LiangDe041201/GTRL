"""Continuous supply stays live, preserves spacing, and isolates RV randomness."""
import contextlib
import csv
import io
import json
import os
from pathlib import Path
import random
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

from test_cross_traffic_manager import load_module, DummyMap, DummySpawnedVehicle, DummyBoundingBox, DummyVehicle
from test_traffic_spacing_v12 import MovingWorld, Logger

try:
    from Planning_library.traffic_flow_v30 import TrafficSupplyV30
except ImportError:
    TrafficSupplyV30=None


class EightMeterWorld(MovingWorld):
    def try_spawn_actor(self,bp,transform):
        actor=DummySpawnedVehicle(len(self._spawned)+1,transform)
        actor.bounding_box=DummyBoundingBox(length=3.8058)
        actor.bounding_box.extent=S(x=3.8058/2.,y=.8,z=.5)
        self._spawned.append(actor)
        return actor


def make_manager(mode='continuous_v30',output=None,limit=2,gap_after=0):
    env=dict(DSH_TRAFFIC_FLOW_MODE=mode,DSH_GAP_AFTER=str(gap_after),DSH_GAP_SEC='11',
             DSH_RV_MAX=str(limit),DSH_TRAFFIC_CLEAR_GAP='8',DSH_SEED='121')
    module=load_module();world=EightMeterWorld()
    with patch.dict(os.environ,env,clear=True),patch.object(module,'get_logger',return_value=Logger()):
        manager=module.CrossTrafficManager(world,DummyMap(),traffic_v=6.)
    manager._spacing_directory=None if output is None else str(output)
    manager.interactions_enabled=False
    manager.reset();manager.ilog.begin_episode(1);manager.start_flow()
    return world,manager


def read_csv(path):
    with Path(path).open(encoding='utf8',newline='') as stream:return list(csv.DictReader(stream))


class ContinuousTrafficTests(unittest.TestCase):
    def policy(self,*args,**kwargs):
        self.assertIsNotNone(TrafficSupplyV30,'Continuous traffic supply policy is absent')
        return TrafficSupplyV30(*args,**kwargs)

    def test_continuous_does_not_stop_at_finite_count_or_insert_long_gaps(self):
        flow=self.policy('continuous_v30',seed=121)
        for total in (0,3,14,1000):
            self.assertTrue(flow.can_spawn(total,14))
            self.assertEqual(flow.interval_frames(total,54,0,220),54)
        self.assertIsNone(flow.metadata(14,0)['finite_spawn_limit'])
        with self.assertRaises(ValueError):flow.interval_frames(3,54,3,220)

    def test_legacy_preserves_total_cap_and_every_third_long_interval(self):
        flow=self.policy('legacy')
        self.assertTrue(flow.can_spawn(13,14));self.assertFalse(flow.can_spawn(14,14))
        self.assertEqual([flow.interval_frames(n,40,3,220) for n in (0,1,2,3,4,6)],
                         [40,40,40,220,40,220])
        self.assertEqual(flow.metadata(14,3),{})
        with self.assertRaises(ValueError):self.policy('unknown')

    def test_keyed_rv_draws_do_not_consume_or_follow_global_random(self):
        flow=self.policy('continuous_v30',seed=121)
        before=random.getstate();first=flow.decision_random(1,2,3).random()
        self.assertEqual(random.getstate(),before)
        with patch.object(random,'random',side_effect=AssertionError('global RNG consumed')):
            self.assertEqual(first,flow.decision_random(1,2,3).random())
        other=[flow.decision_random(*key).random() for key in ((2,2,3),(1,3,3),(1,2,4))]
        self.assertTrue(all(0.<=v<1. and v!=first for v in other))
        self.assertIsNone(self.policy('legacy').decision_random(1,2,3))

    def test_real_manager_continues_after_cap_and_departure_cleanup(self):
        with contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager(limit=2)
            for _ in range(1000):
                manager.run_step(DummyVehicle(6.,-103.));world.advance()
        self.assertGreater(manager._spawned_count,14)
        self.assertTrue(any(not actor.is_alive for actor in world._spawned))
        self.assertEqual(set(manager._spawn_ordinals),set(manager.managed_ids))
        self.assertTrue(set(manager._rv_state)<=set(manager.managed_ids))
        self.assertTrue(manager._ego_near_intersection)
        self.assertAlmostEqual(manager.rv_cruise_speed,4.412022451715821)
        self.assertAlmostEqual(manager._spawn_interval,2.7)

    def test_real_manager_legacy_still_stops_at_same_finite_cap(self):
        with contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager(mode='legacy',limit=2)
            for _ in range(300):
                manager.run_step(DummyVehicle(6.,-103.));world.advance()
        self.assertEqual(manager._spawned_count,2)
        self.assertNotIn('flow_mode',manager.spacing_metadata())

    def test_safety_defer_remains_active_in_continuous_mode(self):
        with contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager()
            manager.run_step(DummyVehicle(6.,-103.))
            for _ in range(70):manager.run_step(DummyVehicle(6.,-103.))
        self.assertEqual(manager._spawned_count,1,'Elapsed time must not spawn into the unmoved leader')

    def test_events_cover_empty_frames_and_sample_geometry_matches_live_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager(output=tmp)
            for _ in range(80):
                manager.run_step(DummyVehicle(6.,-103.));world.advance()
            self.assertTrue((Path(tmp)/'traffic_flow_events_v30.csv').exists(),'No full-frame continuous supply evidence')
            events=read_csv(Path(tmp)/'traffic_flow_events_v30.csv')
            samples=read_csv(Path(tmp)/'traffic_spacing_samples.csv')
            meta=json.loads((Path(tmp)/'traffic_spacing_metadata.json').read_text(encoding='utf8'))
        self.assertEqual(len(events),80)
        self.assertEqual(events[0]['observed_actor_count'],'0')
        counts={frame:sum(row['frame']==frame for row in samples) for frame in (row['frame'] for row in events)}
        self.assertTrue(all(int(event['observed_actor_count'])==counts[event['frame']] for event in events))
        self.assertTrue(all(event['supply_active']=='True' and event['flow_mode']=='continuous_v30' for event in events))
        self.assertEqual(meta['flow_revision'],'traffic_flow_v30')
        self.assertTrue(meta['continuous_supply']);self.assertIsNone(meta['finite_spawn_limit'])
        self.assertFalse(meta['artificial_long_gaps_enabled'])
        for sample in samples:
            self.assertAlmostEqual(float(sample['observed_yaw_rad']),3.141592653589793)
            self.assertAlmostEqual(float(sample['observed_length']),3.8058)
            self.assertAlmostEqual(float(sample['observed_width']),1.6)
            self.assertGreaterEqual(int(sample['spawn_ordinal']),1)

    def test_reset_advances_rng_episode_without_reading_stale_logger_episode(self):
        with contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager()
            self.assertTrue(hasattr(manager,'_flow_episode'),'No reset-owned traffic episode identity')
            self.assertEqual(manager._flow_episode,1)
            manager.ilog.episode=777;manager.reset()
        self.assertEqual(manager._flow_episode,2)
        self.assertEqual(manager._spawned_count,0)

    def test_actual_rv_decision_uses_keyed_draw_not_global_random(self):
        with contextlib.redirect_stdout(io.StringIO()):
            world,manager=make_manager();manager.interactions_enabled=True
            manager.run_step(DummyVehicle(6.,-103.));world.advance()
            before=random.getstate()
            try:
                with patch.object(random,'random',side_effect=AssertionError('global random RV decision')):
                    manager.run_step(DummyVehicle(6.,-103.))
            except AssertionError as error:self.fail(str(error))
        self.assertEqual(random.getstate(),before)
        state=manager._rv_state[world._spawned[0].id]
        self.assertEqual(state['decision_ordinal'],1)


if __name__=='__main__':unittest.main()
