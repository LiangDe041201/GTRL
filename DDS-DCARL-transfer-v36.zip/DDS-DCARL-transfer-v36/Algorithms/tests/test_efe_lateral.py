#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【修复 D2b】横向盲区：横向 offset 的一阶弧长修正回归测试（纯函数，无 CARLA）。

缺陷
------------------------------------------------------------------
`_efe_by_action` 原本只用 `action_speed(a)`，**从不看 `action_lateral(a)`**
⇒ 同一速度档的 3 个横向动作得到**完全相同**的 margins/clearances
⇒ EFE 对横向维度零区分度。
实测：`efe_best_action ∈ {0,3,6,9}` 恒成立（全 ≡0 mod 3）
⇒ EFE 的"建议"退化为「横向恒 −1.5 m + 选速度」。

修法的严格依据（**不是拟合**）
------------------------------------------------------------------
Frenet 基本关系 `κ = dψ/ds`。把路径横向平移 `d`，对弧长的一阶影响为
    Δarc = −d · ∫κ(s)ds = **−d · Δψ**
其中 `Δψ` 是"自车 → 冲突点"沿参考路径的**航向变化量**（`∫κ ds ≡ Δψ`）。
⇒ 只需两端航向差，无需逐点曲率。

符号（依据 `calc_global_paths`: `fx = ix + di·cos(iyaw+π/2)`）
------------------------------------------------------------------
`lateral_offset` 正 = **左**。左转时曲率中心在左侧
⇒ 正 d 使半径变小 ⇒ **弧长变短** ⇒ `arc − d·Δψ`（Δψ>0）。

本文件只验证该模型的**符号/量级/边界/健壮性**，
不断言"加了它成功率会提高"（那是闭环问题）。
"""
import math
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.active_inference import lateral_arc_correction, efe_by_action

#: 实测参考路径的几何（见 HANDOFF §24 / path_diag.pkl）
PSI_TURN = 1.11            # rad，自车→冲突点的航向变化量（左转，实测量级）
KAPPA_CONFLICT = 0.0783    # 1/m，冲突点附近曲率（R≈12.8m，实测）
LATERALS = (-1.5, 0.0, 1.5)   # TURN_2D_LATERALS


class TestLateralArcCorrection(unittest.TestCase):

    # ---------- 基本语义 ----------
    def test_zero_lateral_is_identity(self):
        """横向 offset = 0 ⇒ 弧长不变（沿参考路径）。"""
        for arc in (1.0, 5.0, 12.0, 40.0):
            self.assertAlmostEqual(lateral_arc_correction(arc, 0.0, PSI_TURN), arc, places=9)

    def test_zero_dpsi_is_identity(self):
        """Δψ = 0（直线路径）⇒ 横向平移不影响弧长 ⇒ 退化为修复前行为。"""
        for d in LATERALS:
            self.assertAlmostEqual(lateral_arc_correction(12.0, d, 0.0), 12.0, places=9)

    def test_sign_left_turn(self):
        """左转（Δψ>0）：正 d（左）⇒ 弧长**变短**；负 d（右）⇒ 弧长**变长**。"""
        arc = 12.0
        self.assertLess(lateral_arc_correction(arc, 1.5, PSI_TURN), arc)
        self.assertGreater(lateral_arc_correction(arc, -1.5, PSI_TURN), arc)

    def test_exact_formula(self):
        """必须精确等于 arc − d·Δψ（解析式）。"""
        arc, d, p = 12.0, 1.5, PSI_TURN
        self.assertAlmostEqual(lateral_arc_correction(arc, d, p), arc - d * p, places=9)

    def test_symmetry(self):
        """±d 必须关于 arc **对称**（同量级、反方向）。"""
        arc = 12.0
        lo = lateral_arc_correction(arc, -1.5, PSI_TURN)
        hi = lateral_arc_correction(arc, 1.5, PSI_TURN)
        self.assertAlmostEqual((arc - lo), (hi - arc), places=9)

    # ---------- 量级：必须可观（否则"修了等于没修"）----------
    def test_magnitude_is_material(self):
        """d=±1.5m、Δψ≈1.11rad ⇒ 弧长变化 ≈ 1.67m（>10%）—— 必须可观。"""
        arc = 12.0
        got = abs(lateral_arc_correction(arc, 1.5, PSI_TURN) - arc)
        self.assertAlmostEqual(got, 1.665, places=3)
        self.assertGreater(got / arc, 0.10, '横向耦合必须产生 >10% 的弧长变化')

    def test_three_laterals_are_distinct(self):
        """同一速度档的 3 个横向动作必须得到**互不相同**的弧长（打破盲区）。"""
        arc = 12.0
        vals = [lateral_arc_correction(arc, d, PSI_TURN) for d in LATERALS]
        self.assertEqual(len(set(round(v, 9) for v in vals)), 3,
                         '三个横向动作的弧长必须互不相同')

    def test_monotone_in_lateral(self):
        """弧长必须随 d 单调递减（越靠左弧长越短）——保证排序一致。"""
        arc = 12.0
        prev = None
        for d in (-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5):
            v = lateral_arc_correction(arc, d, PSI_TURN)
            if prev is not None:
                self.assertLess(v, prev, f'd={d} 时未单调递减')
            prev = v

    # ---------- 边界与健壮性 ----------
    def test_clamped_at_min_arc(self):
        """极端情况下不得出现非正弧长（会被下游当作"到不了"）。"""
        v = lateral_arc_correction(1.0, 50.0, PSI_TURN)
        self.assertGreaterEqual(v, 0.5)
        self.assertAlmostEqual(v, 0.5, places=9)

    def test_bad_inputs_return_arc(self):
        """非法输入 ⇒ 原样返回 arc（退化为修复前行为），绝不抛异常。"""
        for bad in ('x', None, float('nan'), float('inf')):
            for args in ((12.0, bad, PSI_TURN), (12.0, 1.5, bad), (bad, 1.5, PSI_TURN)):
                try:
                    v = lateral_arc_correction(*args)
                except (TypeError, ValueError):
                    self.fail(f'输入 {args} 不应抛异常')
                self.assertTrue(isinstance(v, float))

    def test_negative_arc_not_crashes(self):
        """弧长为负（异常上游）不得抛异常。"""
        try:
            lateral_arc_correction(-3.0, 1.5, PSI_TURN)
        except (TypeError, ValueError):
            self.fail('负弧长不应抛异常')

    # ---------- 与下游 EFE 的连通性 ----------
    def test_lateral_changes_efe_inputs(self):
        """三个横向动作经修正后，交给 `efe_by_action` 的 margins 必须可区分。

        这是"横向盲区被打破"的**端到端判据**：
        修正前后，同速度的 3 个横向动作必须产生不同的 `r_behavior` / `efe`。
        """
        def run(use_correction):
            t_rv = 3.0
            margins, clr, t_ego_d = {}, {}, {}
            for i, d in enumerate(LATERALS):
                a = i                      # 同一速度档（v=0 档）的三个横向动作
                arc = 12.0
                if use_correction:
                    arc = lateral_arc_correction(arc, d, PSI_TURN)
                te = arc / 2.0             # 简化运动学：v=2 m/s
                margins[a] = {'yield': abs(t_rv - te), 'rush': abs(t_rv - te * 0.8)}
                clr[a] = 2.0
                t_ego_d[a] = te
            return efe_by_action(margins, {a: {'tau0': 0.5} for a in margins},
                                 {'tau0': 1.0}, clearance_by_action=clr,
                                 t_ego_by_action=t_ego_d, horizon=4.0)

        off = run(False)
        on = run(True)
        r_off = {a: d['r_behavior'] for a, d in off.items()}
        r_on = {a: d['r_behavior'] for a, d in on.items()}
        self.assertEqual(len(set(round(v, 9) for v in r_off.values())), 1,
                         '修复前：三个横向动作的 r_behavior 应完全相同（盲区）')
        self.assertEqual(len(set(round(v, 9) for v in r_on.values())), 3,
                         '修复后：三个横向动作的 r_behavior 必须互不相同')

    def test_ablation_flag_documented(self):
        """消融口径 `DSH_EFE_LATERAL=0` 必须存在（配置层已实现）。

        本用例只做"文档存在性"检查：确保代码里确实引用了该环境变量。
        """
        import inspect
        import Agent.drl_library.dds_dcarl.dds_dcarl_turn as M
        src = inspect.getsource(M)
        self.assertIn('DSH_EFE_LATERAL', src, '消融开关必须存在，否则无法复现修复前行为')


if __name__ == '__main__':
    unittest.main(verbosity=2)
