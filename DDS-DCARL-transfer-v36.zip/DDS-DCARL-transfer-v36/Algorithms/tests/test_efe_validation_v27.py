"""Independent audit must reject swapped candidates, corrupt math and reward writes."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from Planning_library.rolling_efe_v27 import EFEShadowLedger
from test_rolling_efe_v27 import payload,applied

try:
    from Tools.validate_efe_shadow_v27 import validate_shadow_record,validate_efe_shadow
except ImportError:
    validate_shadow_record=validate_efe_shadow=None


def sample():
    p,cg=payload(); ledger=EFEShadowLedger()
    shadow=ledger.propose(p,cg); shadow.update(status='ok',proposal_ms=1.,feedback_ms=1.)
    p['feedback']=dict(reward=.123)
    ledger.feedback(p,dict(action='mpc',override=False),applied(),1,7)
    p['efe_shadow']=shadow
    row=dict(cg,rolling_trajectory=p,episode=1,frame=7,guard_action='mpc',guard_override=False,
        applied_a=.4,applied_delta=.01,applied_target=4.,control_submit_ok=1)
    meta=dict(ledger.metadata,model_sha256=ledger.model_hash,
        learning_signature=dict(reward='measured_task_v19_without_EFE'))
    return row,meta


class EFEValidationTests(unittest.TestCase):
    def audit(self,row,meta):
        self.assertIsNotNone(validate_shadow_record,'No independent shadow audit')
        return validate_shadow_record(row,meta)

    def test_own_candidate_scores_and_final_execution_are_accepted(self):
        row,meta=sample(); before=copy.deepcopy(row)
        self.assertEqual(self.audit(row,meta),{})
        self.assertEqual(row,before)

    def test_score_formula_and_candidate_identity_cannot_be_swapped(self):
        for change in ('risk','candidate','path','input'):
            row,meta=sample(); cs=row['rolling_trajectory']['efe_shadow']['candidates']
            if change=='risk': cs[1]['score']['risk']+=.1
            elif change=='candidate': cs[0]['score']=copy.deepcopy(cs[1]['score'])
            elif change=='path': cs[1]['path_hash']='9'*64
            else: cs[1]['input_signature']='0'*64
            self.assertTrue(self.audit(row,meta),change)

    def test_final_owner_reward_time_cost_and_silent_zero_fallback_are_rejected(self):
        for key,value in (('owner_action',0),('reward_applied',True),('cost_seconds',0.),
                          ('actual_task_reward',-99.),('dt',.1),('available',False)):
            row,meta=sample(); row['rolling_trajectory']['efe_shadow']['feedback'][key]=value
            self.assertTrue(self.audit(row,meta),key)

    def test_invalid_evidence_is_unavailable_but_observer_crashes_fail_validation(self):
        row,meta=sample(); p=row['rolling_trajectory']; p['active']=False
        ledger=EFEShadowLedger(); p['efe_shadow']=ledger.propose(p,row)
        ledger.feedback(p,dict(action='mpc',override=False),applied(),1,7)
        p['efe_shadow'].update(status='ok',proposal_ms=0.,feedback_ms=0.)
        self.assertEqual(self.audit(row,meta),{})
        p['efe_shadow']['status']='error'
        self.assertTrue(self.audit(row,meta))

    def test_full_frame_metadata_and_duplicate_coverage_are_checked(self):
        self.assertIsNotNone(validate_efe_shadow,'No streaming file/metadata audit')
        row,meta=sample()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'efe_shadow_metadata_v27.json').write_text(json.dumps(meta),encoding='utf8')
            path=root/'matrix_decisions.jsonl'; path.write_text(json.dumps(row)+'\n',encoding='utf8')
            result=validate_efe_shadow(root,[dict(episode='1',frame='7')])
            self.assertTrue(result['efe_shadow_contract_ok'],result)
            path.write_text((json.dumps(row)+'\n')*2,encoding='utf8')
            self.assertFalse(validate_efe_shadow(root,[dict(episode='1',frame='7')])['efe_shadow_contract_ok'])
            meta['calibrated']=True
            (root/'efe_shadow_metadata_v27.json').write_text(json.dumps(meta),encoding='utf8')
            self.assertFalse(validate_efe_shadow(root,[dict(episode='1',frame='7')])['efe_shadow_contract_ok'])

    def test_matching_but_invalid_guard_evidence_remains_auditable_and_unavailable(self):
        row,meta=sample(); p=row['rolling_trajectory']; ledger=EFEShadowLedger()
        p['efe_shadow']=ledger.propose(p,row)
        brake=dict(action='brake',a=-2.,delta=.02,target=0.,gap=100.,forecast_valid=False,
                   forecasts=[dict(progress_m=0.,valid=False)])
        ledger.feedback(p,dict(action='brake',override=True,candidates=[brake]),applied(-2.,.02,0.),1,7)
        p['efe_shadow'].update(status='ok',proposal_ms=0.,feedback_ms=0.)
        row.update(guard_action='brake',guard_override=True,applied_a=-2.,applied_delta=.02,applied_target=0.)
        self.assertEqual(p['efe_shadow']['feedback']['reason'],'invalid_forecast')
        self.assertEqual(self.audit(row,meta),{})

    def test_only_final_control_provenance_uses_declared_float_transport_tolerance(self):
        for difference in (5.e-9,5.e-7):
            row,meta=sample(); p=row['rolling_trajectory']; ledger=EFEShadowLedger()
            p['efe_shadow']=ledger.propose(p,row)
            delta=.01+difference
            ledger.feedback(p,dict(action='mpc',override=False,candidates=[]),applied(delta=delta),1,7)
            p['efe_shadow'].update(status='ok',proposal_ms=0.,feedback_ms=0.)
            row['applied_delta']=delta
            self.assertEqual(p['efe_shadow']['feedback']['available'],difference<1.e-8)
            self.assertEqual(self.audit(row,meta),{})


if __name__=='__main__': unittest.main()
