"""A precision recheck must not reuse a changed driving model or failed run."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from Tools.recheck_matrix_smoke import REQUIRED_SOURCES, REQUIRED_FLAGS, recheck_smoke
from tests.test_matrix_validation_v13 import csv_file


def fixture(folder):
    base=Path(folder);root=base/'previous'/'00_matrix_smoke';source=base/'Algorithms'
    run=root/'M1_matrix_seed1';run.mkdir(parents=True)
    hashes={}
    for name in REQUIRED_SOURCES:
        path=source/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text('original fixture',encoding='utf8')
        hashes[name]=hashlib.sha256(path.read_bytes()).hexdigest()
    (source/'Tools/validate_matrix_game.py').write_text('corrected fixture',encoding='utf8')
    config=dict(DSH_METHOD='CG',DSH_COURNOT_MODE='matrix',DSH_TAKE_COURNOT='1',
        DSH_CONTROL_PROFILE='paper_v11',DSH_TRAFFIC='on',DSH_TRAFFIC_CLEAR_GAP='5.0',
        DSH_EFE='0',DSH_WCV_BCV='0')
    manifest=dict(episodes=5,source_sha256=hashes,runs=[dict(arm='M1_matrix',seed=1,config=config)])
    (root/'manifest.json').write_text(json.dumps(manifest),encoding='utf8')
    original=dict.fromkeys(REQUIRED_FLAGS,True)
    original.update(returncode=0,finished_episodes=5,expected_episodes=5,
                    matrix_contract_ok=False,matrix_contract_errors={'control_link_applied_target':5})
    (run/'result.json').write_text(json.dumps(original),encoding='utf8')
    rows=[];records=[];episodes=[]
    target=2.8307578640832483
    for i in range(1,6):
        rows.append(dict(episode=str(i),frame='1',a_mpc='.1',delta_mpc_rad='0',a_cmd='.1',
            delta_rad='0',v_ref='2.831',actuator_speed_target='2.830758',guard_action='mpc',
            mpc_audit_override='0',mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10',ego_v='2'))
        records.append(dict(revision='matrix_entry_v13',controller='matrix_v13',authority='matrix_entry',
            episode=i,frame=1,pure_nash=None,selected=1,control_submit_ok=1,active=True,
            pre_audit_a=.1,pre_audit_delta=0.,pre_audit_target=target,
            applied_a=.1,applied_delta=0.,applied_target=target,
            guard_action='mpc',guard_override=False,payoff_matrix=[[0.,0.],[1.,1.]],
            rv_payoff_matrix=[[0.,0.],[-1.,-1.]],p_yield=.5,u_wait=0.,u_go=1.,
            decision_mode='expected_response',candidate_targets=[0.,target],candidate_a=[-.1,.1],
            switch=False,decision_ms=1.))
        episodes.append(dict(episode=str(i),outcome='complete'))
    csv_file(run/'interaction_ego.csv',rows);csv_file(run/'interaction_summary.csv',episodes)
    (run/'matrix_decisions.jsonl').write_text('\n'.join(json.dumps(r) for r in records)+'\n',encoding='utf8')
    return root,source,run,episodes


class TestMatrixRecheck(unittest.TestCase):
    def test_corrected_precision_reuses_original_files_without_rewriting_them(self):
        with tempfile.TemporaryDirectory() as folder:
            root,source,run,_=fixture(folder)
            before={p:p.read_bytes() for p in root.rglob('*') if p.is_file()}
            result=recheck_smoke(root,source)
            self.assertTrue(result['recheck_ok'],result)
            self.assertEqual(result['changed_source_files'],['Tools/validate_matrix_game.py'])
            self.assertTrue(all(p.read_bytes()==content for p,content in before.items()))

    def test_changed_driving_source_prevents_reusing_the_smoke(self):
        with tempfile.TemporaryDirectory() as folder:
            root,source,_,_=fixture(folder)
            (source/'Agent/game_theory/MPC.py').write_text('changed model',encoding='utf8')
            result=recheck_smoke(root,source)
            self.assertFalse(result['recheck_ok'])
            self.assertIn('driving_source_changed',result['errors'])

    def test_collision_in_csv_is_rejected_even_if_old_cached_flags_say_complete(self):
        with tempfile.TemporaryDirectory() as folder:
            root,source,run,episodes=fixture(folder)
            episodes[-1]['outcome']='collision';csv_file(run/'interaction_summary.csv',episodes)
            result=recheck_smoke(root,source)
            self.assertFalse(result['recheck_ok'])
            self.assertIn('smoke_driving_not_five_successes',result['errors'])

    def test_other_execution_failure_and_wrong_configuration_remain_failures(self):
        with tempfile.TemporaryDirectory() as folder:
            root,source,run,_=fixture(folder)
            path=run/'result.json';result=json.loads(path.read_text(encoding='utf8'))
            result['actuator_contract_ok']=False;path.write_text(json.dumps(result),encoding='utf8')
            self.assertFalse(recheck_smoke(root,source)['recheck_ok'])
            path=root/'manifest.json';manifest=json.loads(path.read_text(encoding='utf8'))
            manifest['runs'][0]['config']['DSH_TRAFFIC']='off'
            path.write_text(json.dumps(manifest),encoding='utf8')
            self.assertIn('smoke_configuration_changed',recheck_smoke(root,source)['errors'])


if __name__=='__main__':
    unittest.main()
