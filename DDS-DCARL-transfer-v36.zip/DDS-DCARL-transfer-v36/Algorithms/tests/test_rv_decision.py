#!/usr/bin/env python3
"""阶段 2 前置：交叉车流让行/抢行决策纯函数（decide_rv_behavior）单元测试。"""
import math
import os
import random
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.rv_decision import (decide_rv_behavior, rv_yield_probability,
                                          RV_THETA_DEFAULT, time_to_cover,
                                          select_conflict_rv)

EGO = {'x': 6.0, 'y': -130.0, 'v': 5.0}
RV = {'x': 15.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0}


class TestRvYieldProbability(unittest.TestCase):
    """rv_yield_probability（① Cournot 接线用：ego 侧估计 RV 让行概率）"""

    def test_range(self):
        for ttc in (None, 0.5, 2.0, 5.0):
            p = rv_yield_probability(EGO, RV, 6.0, ttc)
            self.assertGreaterEqual(p, 0.1)
            self.assertLessEqual(p, 0.9)

    def test_urgent_higher_than_relaxed(self):
        # 紧迫（ttc 小）→ 让行概率更高
        p_urgent = rv_yield_probability(EGO, RV, 6.0, 0.5)
        p_relaxed = rv_yield_probability(EGO, RV, 6.0, 5.0)
        self.assertGreater(p_urgent, p_relaxed)

    def test_eq61_difficulty_monotonic(self):
        # 【论文式61】η = (acc_need − acc_cur)/(acc_rest − acc_cur)，acc_rest = min(acc_follow, acc_max)
        # 抢行需要的加速度越大 → 难度 η 越大 → 让行概率越高
        p_hard = rv_yield_probability(EGO, {'x': 40.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0},
                                      6.0, ttc_boundary=1.0)
        p_easy = rv_yield_probability(EGO, {'x': 8.0, 'y': -138.0, 'v': 10.0, 'vx': -10.0},
                                      6.0, ttc_boundary=3.0)
        self.assertGreaterEqual(p_hard, p_easy)

    def test_matches_decide_rv_behavior_prob(self):
        # 无 override 时 decide_rv_behavior 的 yield_prob 应等于纯概率函数
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=4.0,
                               rng=random.Random(42))
        p = rv_yield_probability(EGO, RV, 6.0, 4.0)
        self.assertAlmostEqual(d['yield_prob'], p, places=9)

    def test_deterministic(self):
        a = rv_yield_probability(EGO, RV, 6.0, 2.0)
        b = rv_yield_probability(EGO, RV, 6.0, 2.0)
        self.assertEqual(a, b)

    def test_theta_affects_yield_prob(self):
        # θ=对手类型 aggressiveness：保守(θ小)→让行概率高；激进(θ大)→让行概率低
        p_cons = rv_yield_probability(EGO, RV, 6.0, 4.0, theta=0.0)
        p_aggr = rv_yield_probability(EGO, RV, 6.0, 4.0, theta=1.0)
        self.assertGreater(p_cons, p_aggr)

    def test_theta_default_unchanged(self):
        # 默认 theta=None → 与旧公式一致（向后兼容）
        p_old = rv_yield_probability(EGO, RV, 6.0, 4.0)
        p_new = rv_yield_probability(EGO, RV, 6.0, 4.0, theta=RV_THETA_DEFAULT)
        self.assertAlmostEqual(p_old, p_new)


class TestRvDecision(unittest.TestCase):

    def test_committed_forced_yield(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=True, ttc_boundary=5.0)
        self.assertEqual(d['behavior'], 'yield')
        self.assertEqual(d['reason'], 'committed')
        self.assertEqual(d['target_speed'], 0.0)

    def test_emergency_forced_yield(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=0.5)
        self.assertEqual(d['behavior'], 'yield')
        self.assertEqual(d['reason'], 'emergency')
        self.assertEqual(d['target_speed'], 0.0)

    def test_ttc_none_goes_zone_b(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=None)
        self.assertIn(d['behavior'], ('yield', 'rush'))
        self.assertEqual(d['reason'], 'bernoulli')

    def test_override_always_yield(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               yield_prob_override=1.0, rng=random.Random(1))
        self.assertEqual(d['behavior'], 'yield')

    def test_override_never_yield(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               yield_prob_override=0.0, rng=random.Random(1))
        self.assertEqual(d['behavior'], 'rush')
        self.assertEqual(d['target_speed'], 10.0)  # 抢行维持原速

    def test_default_prob_range(self):
        # 默认让行概率应在 [0.1, 0.9]
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               rng=random.Random(42))
        self.assertGreaterEqual(d['yield_prob'], 0.1)
        self.assertLessEqual(d['yield_prob'], 0.9)

    def test_deterministic_with_seed(self):
        a = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               rng=random.Random(7))
        b = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               rng=random.Random(7))
        self.assertEqual(a['behavior'], b['behavior'])
        self.assertEqual(a['yield_prob'], b['yield_prob'])


class TestTimeToCover(unittest.TestCase):
    """式56/57 的 EFE(s,a) 观测预测所需：分段匀变速到达时间。"""

    def test_zero_distance(self):
        self.assertEqual(time_to_cover(0.0, 5.0, 5.0), 0.0)
        self.assertEqual(time_to_cover(-1.0, 5.0, 5.0), 0.0)

    def test_uniform_speed(self):
        self.assertAlmostEqual(time_to_cover(8.0, 4.0, 4.0), 2.0, places=9)

    def test_accel_then_cruise(self):
        # v0=2 → v_t=6, a_acc=2：加速段 8m 用时 2s，恰好走完 8m
        self.assertAlmostEqual(time_to_cover(8.0, 2.0, 6.0, a_acc=2.0), 2.0, places=9)
        # 距离更长 → 剩余按 6 m/s 匀速
        t = time_to_cover(14.0, 2.0, 6.0, a_acc=2.0)
        self.assertAlmostEqual(t, 2.0 + 1.0, places=9)

    def test_decel_to_target(self):
        # v0=6 → v_t=3, a_dec=3：减速段 4.5m 用时 1s
        self.assertAlmostEqual(time_to_cover(4.5, 6.0, 3.0, a_dec=3.0), 1.0, places=9)

    def test_decel_to_stop_unreachable_returns_inf(self):
        # 4 m/s、a_dec=3 → 停车距离 8/3≈2.67m < 20m：时域内到不了 → inf
        self.assertEqual(time_to_cover(20.0, 4.0, 0.0, a_dec=3.0), float('inf'))

    def test_decel_to_stop_reachable(self):
        # 4 m/s 减速到 0 前经过 2m 处：v_end²=16−12=4 → v_end=2, t=(4−2)/3
        self.assertAlmostEqual(time_to_cover(2.0, 4.0, 0.0, a_dec=3.0), 2.0 / 3.0, places=9)

    def test_monotonic_in_distance(self):
        ts = [time_to_cover(d, 3.0, 6.0) for d in (2.0, 5.0, 10.0, 20.0)]
        self.assertEqual(ts, sorted(ts))


class TestSelectConflictRv(unittest.TestCase):
    """【论文 zone A 作用对象】只选"与 ego 时空冲突的那一辆 RV"。"""

    CX = -7.1

    def test_picks_only_the_conflicting_one(self):
        # ego 到冲突点 2.0s，清空 1.0s → |t_rv - 2.0| < 1.5 才算冲突
        vehs = [
            {'id': 1, 'x': 3.0, 'v': 3.0},     # t_rv=(3+7.1)/3=3.37 → |1.37| 冲突
            {'id': 2, 'x': 17.0, 'v': 10.0},   # t_rv=24.1/10=2.41 → |0.41| 更近 → 选它
            {'id': 3, 'x': 40.0, 'v': 10.0},   # t_rv=4.71 → |2.71| 不冲突 → 不选
        ]
        vid, dt = select_conflict_rv(vehs, self.CX, t_ego=2.0, clear_time=1.0, margin=0.5)
        self.assertEqual(vid, 2)
        self.assertLess(dt, 0.5)

    def test_none_when_all_far(self):
        vehs = [{'id': 1, 'x': 60.0, 'v': 10.0}]
        vid, dt = select_conflict_rv(vehs, self.CX, t_ego=1.0, clear_time=1.0, margin=0.5)
        self.assertIsNone(vid)
        self.assertEqual(dt, float('inf'))

    def test_ignores_vehicles_past_the_conflict_point(self):
        # x <= conflict_x 的车已通过，不应再被强制让行
        vehs = [{'id': 9, 'x': self.CX - 5.0, 'v': 2.0}]
        vid, _ = select_conflict_rv(vehs, self.CX, t_ego=1.0, clear_time=1.0)
        self.assertIsNone(vid)

    def test_accepts_objects_with_attributes(self):
        class _V:
            def __init__(self, vid, x, v):
                self.id, self.x, self.v = vid, x, v
        vehs = [_V(7, 10.0, 10.0)]
        vid, _ = select_conflict_rv(vehs, self.CX, t_ego=1.9, clear_time=1.0, margin=0.5)
        self.assertEqual(vid, 7)

    def test_invalid_t_ego(self):
        vehs = [{'id': 1, 'x': 10.0, 'v': 5.0}]
        self.assertEqual(select_conflict_rv(vehs, self.CX, t_ego=float('inf'),
                                            clear_time=1.0)[0], None)
        self.assertEqual(select_conflict_rv(vehs, self.CX, t_ego=None,
                                            clear_time=1.0)[0], None)


class TestTEgoPrecedence(unittest.TestCase):
    """式61 的 t_avail 口径：论文用"LCV 进入 A 区的时间"(t_ego)，优先于 ttc_boundary。"""

    def test_t_ego_changes_probability(self):
        p_ttc = rv_yield_probability(EGO, RV, 6.0, ttc_boundary=4.0)
        p_ego_near = rv_yield_probability(EGO, RV, 6.0, ttc_boundary=4.0, t_ego=1.0)
        p_ego_far = rv_yield_probability(EGO, RV, 6.0, ttc_boundary=4.0, t_ego=8.0)
        # t_avail 越小 → RV 越难在 ego 到达前抢行 → 让行概率越高
        self.assertGreater(p_ego_near, p_ego_far)
        self.assertNotAlmostEqual(p_ttc, p_ego_near, places=6)

    def test_falls_back_to_ttc_when_t_ego_missing(self):
        self.assertAlmostEqual(
            rv_yield_probability(EGO, RV, 6.0, ttc_boundary=4.0),
            rv_yield_probability(EGO, RV, 6.0, ttc_boundary=4.0, t_ego=None), places=12)

    def test_decide_rv_behavior_uses_t_ego_and_yield_target(self):
        d = decide_rv_behavior(EGO, RV, 6.0, committed=False, ttc_boundary=5.0,
                               rng=random.Random(3), t_ego=1.0, yield_target_speed=2.0)
        if d['behavior'] == 'yield':
            self.assertAlmostEqual(d['target_speed'], 2.0)
        else:
            self.assertEqual(d['reason'], 'bernoulli')


class TestIdmLeaderIndex(unittest.TestCase):
    """【旧 bug 回归】IDM 前车识别：升序列表里 i+1 之后永远找不到更小的 x。"""

    def test_sorted_ascending_leader_is_previous(self):
        from Planning_library.rv_decision import idm_leader_index
        xs = [0.0, 8.6, 17.2, 25.8]          # 升序（0 最靠西=队首）
        self.assertIsNone(idm_leader_index(xs, 0))
        for i in (1, 2, 3):
            self.assertEqual(idm_leader_index(xs, i), i - 1)

    def test_unsorted_input_robust(self):
        from Planning_library.rv_decision import idm_leader_index
        xs = [17.2, 0.0, 8.6]                # 第 1 辆车（index 1）的前车应是 index 0(17.2)? 否
        # index1: x=0.0，比它小的没有 → None；index2: x=8.6，比它小的有 0.0(index1) → 1
        self.assertIsNone(idm_leader_index(xs, 1))
        self.assertEqual(idm_leader_index(xs, 2), 1)

    def test_empty_and_out_of_range(self):
        from Planning_library.rv_decision import idm_leader_index
        self.assertIsNone(idm_leader_index([], 0))
        self.assertIsNone(idm_leader_index([1.0], 5))
        self.assertIsNone(idm_leader_index([1.0], -1))


class TestIdm(unittest.TestCase):
    """IDM 纯函数（P0-3：车流物理一致性）。"""

    def test_gap_le_zero_hard_brake(self):
        from Planning_library.rv_decision import idm_acceleration
        self.assertEqual(idm_acceleration(5.0, 5.0, 0.0), -5.0)   # -2b, b=2.5
        self.assertEqual(idm_acceleration(5.0, 5.0, -1.0), -5.0)

    def test_free_road_accelerates_to_v0(self):
        from Planning_library.rv_decision import idm_acceleration
        self.assertGreater(idm_acceleration(1.0, 1.0, 100.0, v0=10.0), 0.0)
        # v = v0 且前方极远 → 自由流项为 0 → acc ≈ 0
        self.assertAlmostEqual(idm_acceleration(10.0, 10.0, 1e6, v0=10.0), 0.0, places=3)

    def test_clipped_to_limits(self):
        from Planning_library.rv_decision import idm_acceleration
        acc = idm_acceleration(0.0, 20.0, 1.0, a=2.0, b=2.5)
        self.assertLessEqual(acc, 2.0)
        self.assertGreaterEqual(acc, -5.0)

    def test_equilibrium_speed_solves_acc_zero(self):
        from Planning_library.rv_decision import (idm_acceleration,
                                                  idm_equilibrium_speed)
        for gap in (3.0, 5.0, 8.0, 12.0):
            v = idm_equilibrium_speed(gap, v0=6.0)
            self.assertAlmostEqual(idm_acceleration(v, v, gap, v0=6.0), 0.0, places=6)

    def test_equilibrium_speed_monotonic_in_gap(self):
        from Planning_library.rv_decision import idm_equilibrium_speed
        vs = [idm_equilibrium_speed(g, v0=6.0) for g in (3.0, 4.0, 5.0, 6.0, 10.0)]
        self.assertEqual(vs, sorted(vs))

    def test_equilibrium_speed_below_v0_when_following(self):
        """IDM 跟车不存在 v=v0 的稳态：只要 gap 有限，稳态速度必然 < v0。"""
        from Planning_library.rv_decision import idm_equilibrium_speed
        self.assertLess(idm_equilibrium_speed(5.0, v0=6.0), 6.0)
        self.assertLess(idm_equilibrium_speed(20.0, v0=6.0), 6.0)

    def test_equilibrium_speed_zero_gap(self):
        from Planning_library.rv_decision import idm_equilibrium_speed
        self.assertEqual(idm_equilibrium_speed(0.0), 0.0)
        self.assertEqual(idm_equilibrium_speed(-1.0), 0.0)

    def test_equilibrium_center_matches_design(self):
        from Planning_library.rv_decision import idm_equilibrium_center
        # 6 m/s：2.0 + 6*0.5 + 3.6 = 8.6 m（净间隙 5.0 m，落在论文式62 的 3.5~5.0 m 区间）
        self.assertAlmostEqual(idm_equilibrium_center(6.0), 8.6, places=9)
        self.assertAlmostEqual(idm_equilibrium_center(10.0), 10.6, places=9)


class TestPlatoonIdsBehind(unittest.TestCase):
    """【P1-d】让行编队：rv 及其后方 k 辆（车流按 x 升序，队首在前）。"""

    IDS = [101, 102, 103, 104, 105]

    def test_partner_plus_followers(self):
        from Planning_library.rv_decision import platoon_ids_behind
        self.assertEqual(platoon_ids_behind(self.IDS, 103, 0), {103})
        self.assertEqual(platoon_ids_behind(self.IDS, 103, 1), {103, 104})
        self.assertEqual(platoon_ids_behind(self.IDS, 103, 2), {103, 104, 105})

    def test_truncates_at_tail(self):
        from Planning_library.rv_decision import platoon_ids_behind
        self.assertEqual(platoon_ids_behind(self.IDS, 105, 3), {105})
        self.assertEqual(platoon_ids_behind(self.IDS, 104, 9), {104, 105})

    def test_none_and_unknown(self):
        from Planning_library.rv_decision import platoon_ids_behind
        self.assertEqual(platoon_ids_behind(self.IDS, None, 2), set())
        self.assertEqual(platoon_ids_behind(self.IDS, 999, 2), {999})

    def test_leader_has_followers(self):
        from Planning_library.rv_decision import platoon_ids_behind
        self.assertEqual(platoon_ids_behind(self.IDS, 101, 1), {101, 102})


if __name__ == "__main__":
    unittest.main()
