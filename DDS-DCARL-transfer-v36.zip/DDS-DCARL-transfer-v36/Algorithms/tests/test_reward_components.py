#!/usr/bin/env python3
"""阶段 1：奖励安全项（边界度量版）的单元测试（纯 stdlib，无需 CARLA）。"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.reward_components import boundary_safety_reward

INF = float("inf")


class TestBoundarySafetyReward(unittest.TestCase):

    def test_committed_zero(self):
        self.assertEqual(boundary_safety_reward(0.5, 0.5, 0.5, committed=True, n_vehicles=1), 0.0)

    def test_no_vehicle_bonus(self):
        # 【P1-f】空路口默认中性 0（旧值 +2/帧 = "什么都不做也白拿"）；旧口径仍可显式传参复现
        self.assertEqual(boundary_safety_reward(INF, INF, INF, committed=False, n_vehicles=0), 0.0)
        self.assertEqual(boundary_safety_reward(INF, INF, INF, committed=False, n_vehicles=0,
                                                no_vehicle_bonus=2.0), 2.0)

    def test_yield_wait_bonus(self):
        # 【P1-f(b)】等待补偿现在是**追加项**，不再短路掉危险惩罚。
        #   yield_wait=True, bonus=5.0, THW=0.3 -> 3.0 + 5.0 - 42 = -34
        self.assertAlmostEqual(
            boundary_safety_reward(0.3, INF, 0.3, committed=False, n_vehicles=1,
                                   yield_wait=True, yield_wait_bonus=5.0), -34.0, places=6)
        #   默认 bonus=0 -> 与不带等待完全一致（等待不再白拿）
        self.assertAlmostEqual(
            boundary_safety_reward(0.3, INF, 0.3, committed=False, n_vehicles=1,
                                   yield_wait=True), -39.0, places=6)

    def test_danger_negative(self):
        # THW=0.3 -> 主体 10·0.3=3；LCTTC=0.3 < 1.0 -> 负惩罚 -42 -> 总 -39
        r = boundary_safety_reward(0.3, INF, 0.3, committed=False, n_vehicles=1)
        self.assertLess(r, -30.0)
        self.assertAlmostEqual(r, -39.0, places=6)

    def test_safe_positive(self):
        # THW=3.0 -> 10·min(2.0, 3.0) = 20（论文式 65）
        r = boundary_safety_reward(2.5, 2.5, 3.0, committed=False, n_vehicles=1)
        self.assertEqual(r, 20.0)

    def test_thw_aligned_to_eq65(self):
        # 式 65 对齐验证：THW 封顶 2.0 -> 10·2=20；THW=1.2 -> 12
        self.assertEqual(boundary_safety_reward(INF, INF, 5.0, committed=False, n_vehicles=1), 20.0)
        self.assertEqual(boundary_safety_reward(INF, INF, 1.2, committed=False, n_vehicles=1), 12.0)

    def test_monotonic_in_thw_and_lcttc(self):
        # 随 THW/LCTTC 增大奖励不降（安全区间内单调）
        vals = [boundary_safety_reward(x, INF, x, committed=False, n_vehicles=1)
                for x in (0.5, 1.0, 1.2, 1.5, 2.0)]
        self.assertEqual(vals, sorted(vals))

    # ============================================================
    # 【P1-f 回归】奖励劫持：不能靠"减速制造没有 RV"来白拿安全分
    #   证据 expE_p0_100 第 4 回合：arc≈12.26m、v≈0.3~1.1 m/s、n_vehicles=3~4
    #   但 rv 角色为空 ⇒ lcttc_rv=inf、thw_boundary_rv=inf ⇒ 旧代码给满额 +20/帧，
    #   实测逐帧 reward = +20.41 = 20 + 0.5·0.85，连续 150 帧。
    # ============================================================
    def test_no_rv_farming_regression(self):
        INF_ = float("inf")
        # 场景 A：无 RV、无 FV（纯粹"没有对手"）—— 必须 ≤ 0，绝不能是 +20
        r_no_rv = boundary_safety_reward(INF_, INF_, INF_, committed=False, n_vehicles=4)
        self.assertLessEqual(r_no_rv, 0.0, "无 RV 时不得拿到正的安全奖励（旧口径 +20 即劫持源）")
        self.assertAlmostEqual(r_no_rv, 0.0, places=9)
        # 场景 B：有 RV 且 THW 很小（真正的危险）—— 必须显著为负
        r_danger = boundary_safety_reward(0.3, INF_, 0.3, committed=False, n_vehicles=4)
        self.assertLess(r_danger, r_no_rv, "真危险必须比'没对手'更差，否则策略会往没对手跑")
        # 场景 C：有 RV 且 THW 充足（真安全）—— 拿满 +20
        self.assertEqual(boundary_safety_reward(INF_, INF_, 3.0, committed=False, n_vehicles=4), 20.0)
        # 场景 D：旧口径必须能被显式打开（消融对照），且确实是 +20
        self.assertEqual(boundary_safety_reward(INF_, INF_, INF_, committed=False, n_vehicles=4,
                                                missing_thw_neutral=False), 20.0)

    def test_yield_wait_does_not_bypass_danger(self):
        # 慢速等待不能绕过 LCTTC 危险惩罚：LCTTC 极小时结果必须仍为负
        r = boundary_safety_reward(0.05, INF, INF, committed=False, n_vehicles=4, yield_wait=True)
        self.assertLess(r, 0.0, "等待不得豁免危险惩罚（旧实现提前 return 会豁免）")


if __name__ == "__main__":
    unittest.main()
