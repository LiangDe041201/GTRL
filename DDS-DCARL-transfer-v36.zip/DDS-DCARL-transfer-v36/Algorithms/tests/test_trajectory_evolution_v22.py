"""Connect the parameter learner to real MPC candidates and measured feedback."""
import contextlib
import io
import unittest

import test_trajectory_probe_v21 as probe_fixtures

try:
    from Planning_library.trajectory_evolution_v22 import TrajectoryEvolutionV22
except ImportError:
    TrajectoryEvolutionV22 = None


class EvolutionRuntimeTests(unittest.TestCase):
    def fixture(self, phase='train', epsilon=1.):
        self.assertIsNotNone(TrajectoryEvolutionV22, 'Executable trajectory evolution is missing')
        old = probe_fixtures.TrajectoryProbeTests().fixture('observe')
        runtime = TrajectoryEvolutionV22(phase, old[0].geometry, old[6][2:], epsilon=epsilon)
        return runtime, old

    def run_request(self, runtime, old, selected=1):
        with contextlib.redirect_stdout(io.StringIO()):
            return runtime.propose(old[1], old[2], selected, old[4].last, old[5], False, (6., -138.))

    def test_observe_keeps_cg_controls_and_separates_physical_state_from_beta(self):
        runtime, old = self.fixture('observe')
        output = self.run_request(runtime, old)
        self.assertIs(output[1], old[2][1])
        self.assertFalse(runtime.last['changed_request'])
        self.assertIsNone(runtime.last['physical']['ego']['beta_true'])
        self.assertEqual(runtime.last['beta']['mean'], .5)
        self.assertFalse(runtime.last['efe_reward_enabled'])

    def test_real_returns_can_evolve_and_execute_point_85_in_the_same_intent(self):
        runtime, old = self.fixture()
        context = runtime.context(old[1], old[4].last, old[5]['previous'], old[2][1]['target'])
        l = runtime.learner
        for episode in range(1, 5):
            ratio = 1. if episode % 2 else .75
            l.begin(context, dict(alpha=1., beta=1.), 1, episode)
            l.select(ratio, True, forced_ratio=ratio); l.start(ratio)
            l.reward(1. if ratio == 1. else 5.); l.finish()
        output = self.run_request(runtime, old)
        self.assertEqual(runtime.last['proposal']['ratio'], .85)
        self.assertEqual(runtime.last['request']['target'], 3.4)
        self.assertEqual(output[1]['target'], 3.4)
        self.assertTrue(output[1]['solve_ok'])
        self.assertIs(output[0], old[2][0])

    def test_measurements_after_guard_override_update_the_requested_trajectory(self):
        runtime, old = self.fixture()
        # Prefill default coverage so train exploration selects the new ratio.
        context = runtime.context(old[1], old[4].last, old[5]['previous'], old[2][1]['target'])
        l = runtime.learner
        l.begin(context, dict(alpha=1., beta=1.), 1, 1); l.select(.75, True, forced_ratio=1.); l.start(1.)
        l.reward(1.); l.finish()
        self.run_request(runtime, old)
        applied = dict(control_submit_ok=1, ego_v_after=0., a_cmd=-2., delta_rad=0., actuator_speed_target=0.)
        runtime.feedback(2, 1, dict(override=True, unavoidable=False, action='brake'), applied, 'collision')
        self.assertEqual(l.records[-1]['ratio'], .75)
        self.assertEqual(l.records[-1]['interventions'], 1)
        self.assertLess(l.records[-1]['reward'], -10.)

    def test_forced_stop_never_turns_into_a_learned_rolling_request(self):
        runtime, old = self.fixture()
        old[2][1]['controller'].geometry_force_stop = True
        output = self.run_request(runtime, old)
        self.assertIs(output[1], old[2][1])
        self.assertFalse(runtime.last['changed_request'])


if __name__ == '__main__':
    unittest.main()
