"""Topology-aware junction checks must still reject curbs and wrong entry lanes."""
from types import SimpleNamespace as S
import unittest
import numpy as np

try:
    from Planning_library.road_corridor_v24 import RoadCorridorV24
except ImportError:
    RoadCorridorV24=None


def lane(road=1, number=-1, junction=None):
    return dict(lane=[road,0,number],junction=junction,is_junction=junction is not None,width=3.5)


class CorridorV24Tests(unittest.TestCase):
    def corridor(self,lookup):
        self.assertIsNotNone(RoadCorridorV24,'Body checks still use only sampled centerline lane IDs')
        return RoadCorridorV24(lookup,[(1,0,-1)],[7])

    def test_overlapping_driving_lane_in_the_same_route_junction_is_accepted(self):
        c=self.corridor(lambda x,y:lane(1229,1,7))
        self.assertTrue(c.audit([[0.,0.,0.]],4.,1.8)['accepted'])

    def test_other_junction_and_adjacent_nonjunction_lane_remain_rejected(self):
        for value in (lane(1229,1,8),lane(1,-2)):
            c=self.corridor(lambda x,y:value)
            a=c.audit([[0.,0.,0.]],4.,1.8)
            self.assertFalse(a['accepted'])
            self.assertEqual(a['reason'],'outside_task_corridor')
            self.assertEqual(a['first_rejection']['junction'],value['junction'])

    def test_missing_driving_surface_and_body_corner_are_not_projected_away(self):
        c=self.corridor(lambda x,y:lane() if abs(y)<.95 else None)
        a=c.audit([[0.,0.,0.]],4.,1.8)
        self.assertFalse(a['accepted'])
        self.assertEqual(a['reason'],'outside_driving_surface')

    def test_adapter_derives_junctions_from_public_route_and_records_real_map_evidence(self):
        self.assertIsNotNone(RoadCorridorV24)
        calls=[]
        class Map:
            name='TownTest'
            def get_waypoint(self,location,project_to_road,lane_type):
                calls.append((location.x,project_to_road,lane_type))
                return S(road_id=1,section_id=0,lane_id=-1,lane_width=3.5,
                         is_junction=True,get_junction=lambda:S(id=7))
        c=RoadCorridorV24.from_carla(Map(),S,'Driving',[[0.,0.],[4.,0.]],0.)
        self.assertIn(7,c.junctions)
        self.assertTrue(c.audit([[2.,0.,0.]],4.,1.8)['accepted'])
        self.assertTrue(calls)
        self.assertTrue(all(not projected and kind=='Driving' for _,projected,kind in calls))
        self.assertEqual(c.metadata['route_junctions'],[7])

    def test_unknown_map_queries_fail_closed(self):
        def bad(x,y): raise RuntimeError('Map unavailable')
        a=self.corridor(bad).audit([[0.,0.,0.]],4.,1.8)
        self.assertFalse(a['accepted'])
        self.assertEqual(a['reason'],'map_query_error')


if __name__=='__main__': unittest.main()
