import unittest
from types import SimpleNamespace

import numpy as np


def forecast(crossing=False, cleared=False, standoff=.4, end_speed=.02):
    times = np.array([0., 4., 7., 8.])
    states = np.zeros((7, len(times)))
    states[0] = [8., 7., 6., 1.] if cleared else [8., 7., 6., 5.]
    states[1] = [-133., -134., -138., -138.] if crossing else [-133., -134., -134., -134.]
    states[6, -1] = np.pi
    return states, times, dict(valid=True, min_standoff=standoff, end_speed=end_speed)


class EntryV35Tests(unittest.TestCase):
    def test_creep_needs_both_forecasts_outside_and_stopped(self):
        from Planning_library.entry_planner_v35 import creep_witness
        valid = forecast()
        for invalid in (forecast(crossing=True), forecast(standoff=.1), forecast(end_speed=.25)):
            self.assertFalse(creep_witness([valid, invalid], 4.5, 2., 1.)['accepted'])
        self.assertTrue(creep_witness([valid, valid], 4.5, 2., 1.)['accepted'])

    def test_extended_merge_checks_clearance_after_six_seconds(self):
        from Planning_library.entry_planner_v35 import merge_qualified
        plans = [forecast(crossing=True, cleared=True)] * 2
        good = [dict(admissible=True, min_gap=.3)] * 2
        self.assertTrue(merge_qualified(plans, good, 4.5, 2., 1.)[0])
        self.assertFalse(merge_qualified(plans, [good[0], dict(admissible=True, min_gap=.19)],
                                        4.5, 2., 1.)[0])
        self.assertFalse(merge_qualified([plans[0], forecast(crossing=True)], good, 4.5, 2., 1.)[0])

    def test_creep_is_distinct_and_only_available_from_cg_stop(self):
        from Planning_library.entry_planner_v35 import EntryPlannerV35
        planner = object.__new__(EntryPlannerV35)
        planner.intent, planner._speed_cap = 0, 4.
        creep = planner.CREEP_ACTION
        self.assertEqual(planner._candidate_target(creep, 0.), .5)
        self.assertEqual(planner._candidate_target(4, 0.), 1.)
        self.assertNotEqual(planner.LEARNER_CLASS.ACTION_NAMES[creep], planner.LEARNER_CLASS.ACTION_NAMES[4])
        self.assertIsNone(planner._candidate_target(creep, .3))
        planner.intent = 1
        self.assertIsNone(planner._candidate_target(creep, 0.))

    def test_prefix_then_brake_uses_measured_response_and_stops(self):
        from Planning_library.forecast_v18 import predict
        ego = SimpleNamespace(x=0., y=-132., yaw=-np.pi/2, v=.5, acc=0., length=4.5, width=2.)
        path = np.column_stack((np.zeros(28), np.linspace(-132., -159., 28)))
        geometry = dict(wheelbase=2.7, max_steer=.5, brake_response_jerk=.5)
        initial = dict(a=0., df=0.)
        _, _, stopping = predict(ego, path, 1., .5, 0., initial, geometry,
                                 horizon=6., lag=.4, stop_after=.5)
        _, _, continuing = predict(ego, path, 1., .5, 0., initial, geometry,
                                   horizon=6., lag=.4)
        self.assertGreater(continuing['end_speed'], .8)
        self.assertLessEqual(stopping['end_speed'], .05)
        self.assertGreater(stopping['progress_m'], .15)
        self.assertLess(stopping['progress_m'], continuing['progress_m'])

    def test_final_guard_audits_only_the_committed_mpc_prefix(self):
        from Planning_library.execution_guard import select_execution
        ego = SimpleNamespace(x=0., y=-132., yaw=-np.pi/2, v=0., acc=0., length=4.5, width=2.)
        path = np.column_stack((np.zeros(28), np.linspace(-132., -159., 28)))
        geometry = dict(wheelbase=2.7, max_steer=.5, brake_response_jerk=.5,
                        forecast_model='route_v18', execution_horizon=6.)
        selected, audit = select_execution(ego, [], path, .5, .25, 0.,
            dict(a=0., df=0.), geometry, stop_after=.5)
        self.assertEqual(selected['action'], 'mpc')
        self.assertTrue(audit['safe'])
        self.assertTrue(all(f['stop_check_required'] and f['stop_before_band']
                            for f in selected['forecasts']))

    def test_creep_audit_keeps_full_stopping_timeline_alongside_mpc_prefix(self):
        from Planning_library.forecast_v18 import predict
        from Planning_library.rolling_audit_v25 import CandidateAudit
        ego = SimpleNamespace(x=0., y=-132., yaw=-np.pi/2, v=0., acc=0., length=4.5, width=2.)
        path = np.column_stack((np.zeros(28), np.linspace(-132., -159., 28)))
        geometry = dict(wheelbase=2.7, max_steer=.5, forecast_model='route_v18')
        previous = dict(a=0., df=0.)
        prediction,times,_ = predict(ego,path,.5,.25,0.,previous,geometry,horizon=2.3)
        candidate = dict(target=.5,a=.25,delta=0.,prediction=prediction,times=times,solve_ok=True)
        audit = CandidateAudit(ego,[],None,path,previous,geometry,4.4,stop_after=.5)
        execution, parts, forecasts = audit.evaluate(candidate)
        self.assertTrue(execution['accepted'])
        self.assertEqual(len(parts), 2)
        self.assertTrue(all(t[-1] == 6. for _,t,_ in forecasts))

    def test_runner_uses_same_traffic_and_fresh_learner(self):
        from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
        from Tools.run_dense_validation_v30 import build_plan
        train, evaluation = build_plan('unused', learner='entry_v35')
        self.assertEqual(train['arms'], ['U11_entry_train_v35'])
        self.assertEqual(evaluation['arms'], ['M6_matrix_v18', 'U12_entry_eval_v35'])
        self.assertEqual(train['seeds'], [501])
        self.assertNotEqual(select_rolling_planner('entry_v35').LEARNER_CLASS.SCHEMA,
                            select_rolling_planner('paired_v34').LEARNER_CLASS.SCHEMA)
