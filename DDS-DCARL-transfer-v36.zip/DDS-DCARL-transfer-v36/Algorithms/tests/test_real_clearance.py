#!/usr/bin/env python3
"""【§54】基于真实运动的清空时间模型 —— 独立对拍测试。

存在理由：旧判据 `_clr_go = (车长+带宽)/_go_speed + margin` **与位置、速度无关**
（恒 3.125 s），而真实自车从等待线静止起步、转弯中只有 ~1.46 m/s ⇒ 低估 2~3 倍，
导致 `entry_gap_is_safe` 把"插不进去"判成"能过"（实测碰撞帧 committing=1 且 gap_ok=0）。
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Planning_library.boundary_safety import (required_clearance, entry_clearance_time,
                                              _time_to_cover)

FAILED = []


def chk(name, cond, detail=''):
    print('%-52s %s %s' % (name, 'ok' if cond else 'FAIL', detail))
    if not cond:
        FAILED.append(name)


# ---- 1. 纯运动学：匀加速距离公式对拍 ----
a = 1.2
for s in (0.5, 3.0, 8.5, 20.0):
    t = _time_to_cover(s, 0.0, 999.0, a)          # 不设速度上限
    chk('运动学 s=%.1f: ½at² 复原' % s, abs(0.5 * a * t * t - s) < 1e-9)

# 有速度上限时：加速段 + 匀速段
t2 = _time_to_cover(100.0, 0.0, 3.0, 1.2)
chk('含速度上限 100 m: 2.5s加速+剩余匀速',
    abs(t2 - (3.0 / 1.2 + (100.0 - 3.0 ** 2 / (2 * 1.2)) / 3.0)) < 1e-9)

# ---- 2. 与旧式对比：旧式与位置/速度无关，新式不是 ----
old = entry_clearance_time(4.0)
chk('旧式清空时长恒为常数（问题本身）',
    abs(old - entry_clearance_time(4.0, ego_len=4.5)) < 1e-9 and abs(old - 3.125) < 1e-9)

far = required_clearance(25.0, 0.0, dt_lag=0.0)[1]
near = required_clearance(6.0, 0.0, dt_lag=0.0)[1]
chk('新式占用窗随初速度变化（near 更快到达 ⇒ v_arr 一致时应相近）',
    abs(far - near) < 1e-6, 'far=%.3f near=%.3f' % (far, near))

t_rest = required_clearance(12.26, 0.0, dt_lag=0.0)
t_mov = required_clearance(12.26, 3.0, dt_lag=0.0)
chk('新式：已在动的车到达更快（占用窗也因 v_arr 更高而更短）',
    t_mov[0] < t_rest[0] and t_mov[1] <= t_rest[1] + 1e-9,
    '静止 t_arr=%.2f  已动 t_arr=%.2f' % (t_rest[0], t_mov[0]))

# ---- 3. 单调性 ----
prev = None
for d in (5.0, 10.0, 15.0, 20.0, 30.0):
    ta = required_clearance(d, 0.0, dt_lag=0.0)[0]
    if prev is not None:
        chk('到达时间随距离单调不减 d=%.0f' % d, ta >= prev - 1e-9)
    prev = ta

# ---- 4. 滞后必须计入 ----
a0 = required_clearance(12.26, 0.0, dt_lag=0.0)[0]
a4 = required_clearance(12.26, 0.0, dt_lag=0.4)[0]
chk('执行滞后 dt_lag 线性计入到达时间', abs((a4 - a0) - 0.4) < 1e-9)

# ---- 5. 相对旧式的保守性：在等待线处，新式占用窗必须**不短于**旧式的一半 ----
_, clr_new = required_clearance(12.26, 0.0, dt_lag=0.4)
chk('等待线处新式占用窗 >= 旧式(3.125s)', clr_new >= 3.125,
    'new=%.3f old=%.3f' % (clr_new, 3.125))

# ---- 6. 需要多大的车流间隙才可行（本场景的可行性数） ----
need = clr_new
print('\n[可行性数] 等待线处需要车流让出 %.2f s 的窗口（含 %.1f s 余量）'
      % (need, need - _time_to_cover(8.5, 3.0, 3.0, 1.2)))
chk('A 方案的 7.0 s 车流间隙足够覆盖该窗口', 7.0 > need,
    'gap=7.0 need=%.2f' % need)

# ---- 7.【§54b 关键】"越慢越宽松"的反向激励必须被消除 ----
from Planning_library.boundary_safety import (required_clearance_from_standoff,
                                              entry_gap_is_safe)

# (a) 车头已在带内 ⇒ 占用必须从"现在"(t=0)开始
t0_in, c_in = required_clearance_from_standoff(-0.5, 0.3, dt_lag=0.4)
chk('车头在带内 ⇒ t_enter == 0（占用从现在开始）', abs(t0_in) < 1e-12,
    't_enter=%.4f' % t0_in)

# (b) t_enter 随净空单调不减
prev = -1.0
mono = True
for sd in (-1.0, -0.1, 0.0, 0.5, 1.0, 2.0, 5.0, 12.0):
    te = required_clearance_from_standoff(sd, 0.3, dt_lag=0.4)[0]
    if te < prev - 1e-9:
        mono = False
    prev = te
chk('t_enter 随净空单调不减（蹭进去不会让窗口更靠后）', mono)

# (c) 反向激励已被消除：带内有一辆车【现在就占用】(t_veh=0) 时，
#     蹭进带内必须让判据**变严**（False），而停在带外可以判过（True）
VEH_CLEAR = 1.5
in_band = entry_gap_is_safe(t0_in, [0.0], c_in, veh_clear_time=VEH_CLEAR)
t_out, c_out = required_clearance_from_standoff(6.0, 0.3, dt_lag=0.4)
out_band = entry_gap_is_safe(t_out, [0.0], c_out, veh_clear_time=VEH_CLEAR)
chk('带内有一辆车现在占用 ⇒ 车头在带内判拒（修掉反向激励）', in_band is False,
    'standoff<=0 -> %s' % in_band)
chk('同一辆车：停在带外 6 m 时可判过', out_band is True,
    'standoff=6 -> %s' % out_band)

# (d) 为什么旧 arc 锚定会失效：t_ego_go 越大 ⇒ 窗口越靠后 ⇒ 越容易"看起来安全"
#     用同一辆"现在占用"的车做对照
ta_far = required_clearance(30.0, 0.3, dt_lag=0.4)[0]     # arc 锚定：很远 ⇒ t 很大
chk('arc 锚定的失效机制可复现：t 很大时同一辆车不再构成冲突',
    entry_gap_is_safe(ta_far, [0.0], c_in, veh_clear_time=VEH_CLEAR) is True,
    't_ego_go=%.2f（旧锚定会说"安全"，但车头其实已在带内）' % ta_far)

print()
if FAILED:
    print('FAILED: %s' % FAILED)
    sys.exit(1)
print('ALL %d CHECKS PASSED' % 6)
