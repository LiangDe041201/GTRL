"""Shared geometry, real entry dispatch and full-frame experiment evidence."""
import ast
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import Mock

import numpy as np

from Planning_library.control_path_v15 import ControlExperimentV15, spatial_path, path_hash
from Tools.run_relay_validation import main as relay_main
from Tools.validate_entry_path_v15 import validate_entry_path


class TestSpatialGeometry(unittest.TestCase):
    def test_time_clustered_curve_preserves_route_and_endpoints(self):
        x=np.array([0.,.025,.05,.08,.15,.4,.9,1.5,2.5,4.,6.,8.])
        raw=np.c_[x,.015*np.sin(12.*x)+.012*x*x]
        result,diag=spatial_path(raw)
        np.testing.assert_array_equal(result[[0,-1]],raw[[0,-1]])
        self.assertEqual(diag['status'],'resampled')
        self.assertLessEqual(diag['deviation_bound'],.05)
        self.assertEqual(path_hash(result),diag['output_hash'])
        lengths=np.linalg.norm(np.diff(result,axis=0),axis=1)
        self.assertGreater(np.min(lengths),.02)
        self.assertLess(np.max(lengths)-np.min(lengths),.02)

    def test_sharp_corner_refines_instead_of_cutting_the_route(self):
        raw=np.array([[0.,0.],[.7,0.],[.7,2.3],[4.,2.3]])
        result,diag=spatial_path(raw)
        self.assertLess(diag['spacing'],.5)
        self.assertLessEqual(diag['deviation_bound'],.05)
        np.testing.assert_array_equal(result[[0,-1]],raw[[0,-1]])

    def test_invalid_geometry_is_left_to_existing_recovery(self):
        for raw in (None,[],[[0.,0.],[0.,0.],[0.,0.]],[[0.,0.],[math.nan,1.],[2.,2.]]):
            result,diag=spatial_path(raw)
            self.assertIs(result,raw)
            self.assertEqual(diag['status'],'unchanged_invalid')
        for tol in (-1.,0.,.005,math.nan):
            with self.assertRaises(ValueError):spatial_path([[0,0],[1,0],[2,0]],tolerance=tol)

    def test_minimal_policy_is_not_available_to_learning_or_legacy_control(self):
        for args in (('GTRL',False,'paper_v11','spatial_v15','minimal'),
                     ('CG',True,'paper_v11','spatial_v15','minimal'),
                     ('RULE',False,'paper_v11','legacy','minimal'),
                     ('RULE',False,'legacy','spatial_v15','full')):
            with self.assertRaises(ValueError):ControlExperimentV15(*args)

    def test_legacy_arm_does_not_mutate_trajectory(self):
        path=np.array([[0.,0.],[1.,0.],[2.,0.]])
        trajectory=S(trajectory=path)
        ControlExperimentV15('CG',True,'paper_v11').condition(trajectory)
        self.assertIs(trajectory.trajectory,path)


class TestProductionEntryDispatch(unittest.TestCase):
    def test_actual_entry_branch_only_calls_advance_gate_for_full_rule(self):
        source=Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
        tree=ast.parse(source.read_text(encoding='utf-8-sig'))
        block=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
            and any(isinstance(c,ast.Assign) and any(isinstance(t,ast.Name)
                and t.id=='_advance_entry_called' for t in c.targets) for c in n.body))
        for policy,matrix in (('full',False),('minimal',False),('full',True)):
            gate=S(last=dict(safe=True,phase='approach'),launched=False)
            gate.target=Mock(return_value=1.5)
            experiment=ControlExperimentV15('CG' if matrix else 'RULE',matrix,'paper_v11','spatial_v15',policy)
            ego=S(x=0.,y=0.,yaw=0.)
            stub=S(paper_control=True,revised_control=True,control_experiment=experiment,
                   turn_feasibility=gate,dynamic_map=S(ego_vehicle=ego,objects=[]),game_config=dict(mpc=False,matrix=matrix))
            ns=dict(self=stub,matrix_game=S(revision='matrix_entry_v14') if matrix else None,
                wait_standoff=lambda *a:4.,vehicle_size=lambda *a:4.5,BAND_HALF_DEFAULT=1.,
                _conf={},used_trajectory=S(trajectory=np.array([[0.,0.],[2.,0.],[4.,0.]])),
                v_ref=4.,mpc_controller=S(last_u={'a':0.}))
            module=ast.Module(body=[block])
            if 'type_ignores' in ast.Module._fields:module.type_ignores=[]
            exec(compile(module,'<actual entry dispatch>','exec'),ns)
            expected=policy=='full' and not matrix
            self.assertEqual(gate.target.call_count,int(expected))
            self.assertEqual(ns['_advance_entry_called'],expected)
            self.assertEqual(ns['v_ref'],1.5 if expected else 4.)

    def test_new_comparison_has_one_shared_geometry_and_one_changed_rule_gate(self):
        stream=io.StringIO()
        with contextlib.redirect_stdout(stream):
            self.assertEqual(relay_main(['--dry-run','--method','CG','--arms',
                'B1_rule_minimal,B2_rule_spatial,M3_matrix_spatial,M2_matrix_v14']),0)
        configs=[json.loads(s)['effective'] for s in stream.getvalue().splitlines()]
        self.assertEqual({k for k in configs[0] if configs[0][k]!=configs[1][k]},{'DSH_ENTRY_POLICY'})
        self.assertEqual({c['DSH_CONTROL_PATH'] for c in configs[:3]},{'spatial_v15'})
        self.assertEqual(configs[3]['DSH_CONTROL_PATH'],'legacy')
        self.assertTrue(all(c['DSH_EFE']=='0' and c['DSH_WCV_BCV']=='0' for c in configs))


class TestAuditEvidence(unittest.TestCase):
    def test_actual_journal_matches_motion_and_rejects_removed_guard_and_wrong_path(self):
        with tempfile.TemporaryDirectory() as directory:
            experiment=ControlExperimentV15('CG',True,'paper_v11','spatial_v15','full',directory)
            trajectory=S(trajectory=np.array([[0.,0.],[.02,.002],[1.,.02],[4.,.2]]))
            experiment.condition(trajectory)
            controller=S(last_pathway=trajectory.trajectory,geometry_source='planned',
                reference_path=S(frenet_convertor=S(get_kappa=lambda *a:.1)))
            applied=dict(actuator_speed_target=4.,ego_v_before=.02,ego_v_after=.04,a_cmd=.1)
            audit=dict(action='mpc',override=False)
            for frame in (1,2):
                experiment.record(1,frame,controller,audit,applied,S(x=0.,y=0.),False,1,True)
            rows=[dict(episode='1',frame=str(f),actuator_speed_target='4.000000',
                ego_v_before='.020000',ego_v_after='.040000',a_cmd='.100000',
                guard_action='mpc',mpc_audit_override='0') for f in (1,2)]
            result=validate_entry_path(directory,rows,'matrix')
            self.assertTrue(result['entry_path_contract_ok'],result)
            self.assertEqual(result['matrix_accepted_go_low_speed_rows'],2)
            self.assertEqual(result['matrix_longest_accepted_go_low_speed_s'],.1)
            with self.assertRaises(ValueError):
                experiment.record(1,3,controller,None,applied,S(x=0.,y=0.),False)
            path=Path(directory)/'entry_path_audit.jsonl'
            saved=[json.loads(s) for s in path.read_text().splitlines()]
            saved[0]['actual_path_hash']='wrong'
            saved[1]['advance_called']=True
            path.write_text('\n'.join(json.dumps(s) for s in saved)+'\n',encoding='utf8')
            result=validate_entry_path(directory,rows,'matrix')
            self.assertFalse(result['entry_path_contract_ok'])
            self.assertIn('mpc_path_mismatch',result['entry_path_errors'])
            self.assertIn('entry_policy',result['entry_path_errors'])

    def test_missing_journal_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            result=validate_entry_path(directory,[dict(episode=1,frame=1)],'full')
            self.assertFalse(result['entry_path_contract_ok'])


if __name__=='__main__':
    unittest.main()
