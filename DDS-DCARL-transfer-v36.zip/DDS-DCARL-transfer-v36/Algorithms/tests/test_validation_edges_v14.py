"""Precision intervals and proven terminal births must not hide real failures."""
import csv
import json
from pathlib import Path
import tempfile
import unittest

from Tools.run_relay_validation import execution_target_interval
from Tools.validate_traffic_spacing import validate_traffic_spacing
from tests import test_full_episode_logging as logging_tests


def write_csv(path,rows):
    with path.open('w',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def spacing_fixture(folder):
    root=Path(folder)
    metadata=dict(revision='spacing_v12',length_source='actor_bbox_world_vertices',
        target_clear_gap=5.,cruise_speed=4.4,measured_length=4.,interval_seconds=2.1,
        interactions_enabled=True,gap_after=3)
    (root/'traffic_spacing_metadata.json').write_text(json.dumps(metadata),encoding='utf8')
    spawned=[dict(episode='1',trial='0',frame=str(frame),event='spawned',actor_id=str(actor),
        leader_id='' if actor==1 else str(actor-1),
        projected_clear_gap='' if actor==1 else '5.2',target_clear_gap='5',
        pose_source='requested_spawn_transform') for actor,frame in ((1,1),(2,3),(3,5))]
    samples=[dict(episode='1',trial='0',frame=str(frame),actor_id=str(actor),
        leader_id='' if actor==1 else '1',actual_clear_gap='' if actor==1 else '5.2',
        observed_speed='4.4',pose_source='actor_snapshot',age_s='1',following_acceleration='0',
        policy='cruise_only_probe',at_conflict='1') for actor,frame in ((1,2),(2,4))]
    write_csv(root/'traffic_spawns.csv',spawned);write_csv(root/'traffic_spacing_samples.csv',samples)
    write_csv(root/'interaction_ego.csv',[dict(episode='1',frame=str(f)) for f in range(1,6)])
    write_csv(root/'interaction_summary.csv',[dict(episode='1',frames='5',outcome='complete')])
    return root,spawned


class TestTargetPrecision(unittest.TestCase):
    def test_real_fractional_target_above_stop_threshold_is_not_a_stop_contradiction(self):
        result=logging_tests.TestRunSummary().summary([1,2],overrides={
            2:dict(v_ref=.01,actuator_speed_target=.010057,a_cmd=.1)})
        self.assertTrue(result['execution_contract_ok'],result)
        self.assertEqual(result['stop_target_positive_acceleration_rows'],0)

    def test_real_stop_acceleration_and_mismatched_execution_target_still_fail(self):
        stopped=logging_tests.TestRunSummary().summary([1,2],overrides={
            2:dict(v_ref=0.,actuator_speed_target=0.,a_cmd=.1)})
        self.assertFalse(stopped['execution_contract_ok'])
        self.assertEqual(stopped['stop_target_positive_acceleration_rows'],1)
        mismatch=logging_tests.TestRunSummary().summary([1,2],overrides={
            2:dict(v_ref=0.,actuator_speed_target=4.,a_cmd=.1)})
        self.assertFalse(mismatch['execution_contract_ok'])
        self.assertEqual(mismatch['execution_target_display_mismatch_rows'],1)

    def test_exact_recorded_boundary_is_reported_as_ambiguous_and_nan_cannot_fall_back(self):
        result=logging_tests.TestRunSummary().summary([1,2],overrides={
            2:dict(v_ref=.01,actuator_speed_target=.01,a_cmd=.1)})
        self.assertEqual(result['stop_threshold_ambiguous_rows'],1)
        value,half_unit=execution_target_interval(dict(v_ref='4',actuator_speed_target='nan'))
        self.assertIsNone(value);self.assertLess(half_unit,1e-6)


class TestTerminalSpawn(unittest.TestCase):
    def test_only_proven_terminal_birth_is_censored_and_gap_is_still_checked(self):
        with tempfile.TemporaryDirectory() as folder:
            root,events=spacing_fixture(folder)
            result=validate_traffic_spacing(root)
            self.assertTrue(result['traffic_spacing_contract_ok'],result)
            self.assertEqual(result['traffic_terminal_unobserved_spawns'][0]['actor_id'],'3')
            self.assertEqual(result['traffic_unexpected_unsampled_actors'],[])
            events[-1]['projected_clear_gap']='2.8';write_csv(root/'traffic_spawns.csv',events)
            self.assertFalse(validate_traffic_spacing(root)['traffic_spacing_contract_ok'])

    def test_mid_episode_omission_or_incomplete_ego_coverage_is_not_excused(self):
        with tempfile.TemporaryDirectory() as folder:
            root,events=spacing_fixture(folder)
            events[-1]['frame']='4';write_csv(root/'traffic_spawns.csv',events)
            self.assertFalse(validate_traffic_spacing(root)['traffic_spacing_contract_ok'])
            events[-1]['frame']='5';write_csv(root/'traffic_spawns.csv',events)
            write_csv(root/'interaction_ego.csv',[dict(episode='1',frame=str(f)) for f in (1,2,3,5)])
            self.assertFalse(validate_traffic_spacing(root)['traffic_spacing_contract_ok'])

    def test_missing_summary_or_probe_does_not_create_an_exemption(self):
        with tempfile.TemporaryDirectory() as folder:
            root,_=spacing_fixture(folder)
            result=validate_traffic_spacing(root,probe=True)
            self.assertIn('missing_actual_gap_or_actor_samples',result['traffic_spacing_errors'])
            (root/'interaction_summary.csv').unlink()
            self.assertFalse(validate_traffic_spacing(root)['traffic_spacing_contract_ok'])


if __name__=='__main__':
    unittest.main()
