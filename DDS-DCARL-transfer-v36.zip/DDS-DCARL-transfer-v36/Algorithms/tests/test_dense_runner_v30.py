"""Exercise the public CLI without CARLA, including inherited-env isolation."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest

from Tools import run_relay_validation as relay


class DenseRunnerTests(unittest.TestCase):
    def run_cli(self, extra):
        output, errors = io.StringIO(), io.StringIO()
        arguments = ['--dry-run', '--method', 'CG', '--game-mode', 'matrix_v18',
            '--traffic-interaction', 'v17', '--arms', 'M6_matrix_v18', '--seeds', '211']+extra
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
            try:
                code = relay.main(arguments)
            except SystemExit as exc:
                code = exc.code
        return code, output.getvalue(), errors.getvalue()

    def test_continuous_cli_survives_environment_sanitization_and_disables_long_gap(self):
        code, output, error = self.run_cli(['--traffic-flow-mode', 'continuous_v30',
                                          '--traffic-clear-gap', '8'])
        self.assertEqual(code, 0, error)
        rows = [json.loads(line) for line in output.splitlines()]
        self.assertEqual(len(rows), 1)
        config = rows[0]['effective']
        self.assertEqual(config['DSH_TRAFFIC_FLOW_MODE'], 'continuous_v30')
        self.assertEqual(config['DSH_GAP_AFTER'], '0')
        self.assertEqual(config['DSH_TRAFFIC_CLEAR_GAP'], '8.0')
        self.assertEqual(config['DSH_TRAFFIC_INTERACTION'], 'v17')

    def test_legacy_default_keeps_existing_platoon_spacing(self):
        code, output, error = self.run_cli([])
        self.assertEqual(code, 0, error)
        config = json.loads(output.splitlines()[0])['effective']
        self.assertEqual(config.get('DSH_TRAFFIC_FLOW_MODE'), 'legacy')
        self.assertEqual(config['DSH_GAP_AFTER'], '3')
        self.assertEqual(config['DSH_GAP_SEC'], '11')

    def test_continuous_flow_requires_traffic_on_before_creating_output(self):
        with tempfile.TemporaryDirectory() as name:
            target = Path(name)/'must-not-create'
            code, output, error = self.run_cli(['--traffic-flow-mode', 'continuous_v30',
                '--traffic', 'off', '--arms', 'B0_rule', '--output-root', str(target)])
            self.assertEqual(code, 2)
            self.assertIn('continuous', error.lower())
            self.assertFalse(target.exists())


if __name__ == '__main__':
    unittest.main()
