"""Intentional new geometry needs its own trace; old-path evidence cannot stand in."""
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
import test_spatial_probe_v23 as fixtures
from Planning_library.execution_guard import select_execution
from Planning_library.trajectory_guard import execution_acceleration
from Planning_library.control_path_v15 import ControlExperimentV15


class SpatialValidationTests(unittest.TestCase):
    def validator(self):
        try:
            from Tools.validate_spatial_probe_v23 import validate_spatial_record
        except ImportError:
            self.fail('Independent spatial trajectory audit is missing')
        return validate_spatial_record

    def evidence(self):
        p, f = fixtures.SpatialProbeTests().fixture()
        with contextlib.redirect_stdout(io.StringIO()):
            output = p.propose(f[1], f[2], 1, f[4].last, f[5], False, (6., -138.))
        c = output[1]
        controller = p.activate(f[2][1]['controller'], c['controller'])
        applied, audit = select_execution(f[1].ego_vehicle, f[1].objects, c['path'], c['target'],
            execution_acceleration(c['a'], f[1].ego_vehicle.v, c['target']), c['delta'], f[5]['previous'],
            p.geometry, prediction=c['prediction'], prediction_times=c['times'], plan=c['plan'])
        self.assertIsNone(p.review_execution(controller, f[1].ego_vehicle, f[1].objects, f[5]['previous'], audit))
        delivered = dict(control_submit_ok=1, a_cmd=applied['a'], delta_rad=applied['delta'],
                         actuator_speed_target=applied['target'], ego_v_before=2., ego_v_after=2.)
        p.feedback(1, 1, audit, delivered)
        row = copy.deepcopy(f[4].last)
        row.update(spatial_probe=copy.deepcopy(p.last), episode=1, frame=1,
            pre_audit_a=c['a'], pre_audit_delta=c['delta'], pre_audit_target=c['target'],
            applied_a=applied['a'], applied_delta=applied['delta'], applied_target=applied['target'],
            guard_action=audit['action'], guard_override=audit['override'], guard_safe=audit['safe'], control_submit_ok=1)
        ego = dict(episode='1', frame='1', a_mpc=str(c['a']), delta_mpc_rad=str(c['delta']),
            a_cmd=str(applied['a']), delta_rad=str(applied['delta']), ego_v='2', ego_v_before='2', ego_v_after='2',
            actuator_speed_target=str(round(applied['target'], 6)), v_ref=str(round(applied['target'], 3)),
            guard_action=audit['action'], mpc_audit_override=str(int(audit['override'])),
            mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10',
            a_prev=str(round(f[5]['previous']['a'], 3)), steer_prev=str(round(f[5]['previous']['df'], 3)))
        return row, ego, p, f, controller, audit, delivered

    def test_real_spatial_plan_and_guarded_control_have_one_matching_path(self):
        validate = self.validator(); row, ego, *_ = self.evidence()
        self.assertEqual(validate(row, ego, 'plus'), {})

    def test_forged_path_or_failed_road_membership_cannot_keep_execution_authority(self):
        validate = self.validator(); row, ego, *_ = self.evidence()
        row['spatial_probe']['request']['path_hash'] = '0'*64
        self.assertTrue(validate(row, ego, 'plus'))
        row, ego, *_ = self.evidence()
        row['spatial_probe']['proposal']['path_road']['accepted'] = False
        self.assertTrue(validate(row, ego, 'plus'))

    def test_matrix_payoff_stays_checked_when_new_geometry_owns_control(self):
        self.validator(); row, ego, *_ = self.evidence()
        from Tools.validate_matrix_game import validate_matrix_game
        with tempfile.TemporaryDirectory() as d:
            file = Path(d)/'matrix_decisions.jsonl'
            file.write_text(json.dumps(row)+'\n', encoding='utf8')
            r = validate_matrix_game(d, [ego], 'matrix_v18', expected_spatial='plus')
            self.assertTrue(r['matrix_contract_ok'], r)
            row['payoff_matrix'][0][0] += 1.
            file.write_text(json.dumps(row)+'\n', encoding='utf8')
            self.assertFalse(validate_matrix_game(d, [ego], 'matrix_v18', expected_spatial='plus')['matrix_contract_ok'])

    def test_entry_audit_accepts_a_traceable_new_path_and_rejects_an_unlisted_path(self):
        self.validator(); row, ego, p, f, controller, audit, delivered = self.evidence()
        from Tools.validate_entry_path_v15 import validate_entry_path
        with tempfile.TemporaryDirectory() as d:
            e = ControlExperimentV15('CG', True, 'paper_v11', 'spatial_v15', directory=d)
            e.condition(S(trajectory=f[2][1]['controller'].last_pathway.copy()))
            e.record(1, 1, controller, audit, delivered, f[1].ego_vehicle, False, selected=1, active=True)
            file = Path(d)/'matrix_decisions.jsonl'
            file.write_text(json.dumps(row)+'\n', encoding='utf8')
            good = validate_entry_path(d, [ego], 'matrix', spatial_mode='plus')
            self.assertTrue(good['entry_path_contract_ok'], good)
            row['spatial_probe']['request']['path_hash'] = '0'*64
            file.write_text(json.dumps(row)+'\n', encoding='utf8')
            self.assertFalse(validate_entry_path(d, [ego], 'matrix', spatial_mode='plus')['entry_path_contract_ok'])


if __name__ == '__main__':
    unittest.main()
