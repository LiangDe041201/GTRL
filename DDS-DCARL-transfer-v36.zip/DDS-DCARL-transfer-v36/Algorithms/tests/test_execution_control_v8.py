"""Regressions for returned v7 failures; production optimizer and control glue."""
import ast
import contextlib
import csv
import io
import json
import math
from pathlib import Path
from types import SimpleNamespace as S
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

from Planning_library.actuator_interface import ackermann_target, physical_geometry, body_clear_of_band
from Planning_library.execution_guard import rollout, select_execution, TurnFeasibilityV8
from Planning_library.paper_turn_control import smooth_interaction_cost
from Tools.validate_control_health import validate_control_health

ROOT = Path(__file__).resolve().parents[1]
GEOMETRY = dict(wheelbase=2.85, l_f=1.425, l_r=1.425, max_steer=1.)


def vehicle(actor=0, x=0., y=-138., yaw=math.pi, v=3.):
    return S(veh_id=actor, x=x, y=y, yaw=yaw, v=v, vx=v*math.cos(yaw),
             vy=v*math.sin(yaw), length=4., width=2.)


class TestPhysicalExecution(unittest.TestCase):
    def test_geometry_from_rotated_world_wheels(self):
        physics = S(wheels=[S(position=S(x=x, y=y, z=0.), max_steer_angle=angle)
            for x, y, angle in [(80., 142.5, 60.), (-80., 142.5, 60.),
                                 (80., -142.5, 0.), (-80., -142.5, 0.)]])
        geometry = physical_geometry(physics)
        self.assertAlmostEqual(geometry['wheelbase'], 2.85)
        self.assertAlmostEqual(geometry['max_steer'], math.pi/3.)
        physics.wheels[0].position.y = float('nan')
        with self.assertRaises(ValueError):
            physical_geometry(physics)

    def test_native_acceleration_is_limit_and_braking_has_lower_speed_target(self):
        request = ackermann_target(-.5, 2., 4., .2, 1.)
        self.assertEqual(request['acceleration'], .5)
        self.assertLess(request['speed'], 2.)
        self.assertEqual(request['steer'], .2)
        self.assertGreater(ackermann_target(0., 2., 4., 0., 1.)['acceleration'], 0.)
        self.assertEqual(ackermann_target(-1., 0., 0., 0., 1.)['speed'], 0.)

    def test_scalar_committed_is_not_whole_body_clear(self):
        self.assertFalse(body_clear_of_band(vehicle(y=-135.2)))
        self.assertFalse(body_clear_of_band(vehicle(y=-138.)))
        self.assertTrue(body_clear_of_band(vehicle(y=-140.2)))

    def test_inside_braking_can_be_worse_than_clearing(self):
        ego = vehicle()
        other = vehicle(actor=7, x=10., v=6.)
        path = np.c_[np.linspace(0., -50., 101), np.full(101, -138.)]
        predicted, times = rollout(ego, path, 0., -1., 0., dict(a=-1., df=0.), GEOMETRY, lag=0.)
        selected, audit = select_execution(ego, [other], path, 4., -1., 0., dict(a=-1., df=0.),
            GEOMETRY, prediction=predicted, prediction_times=times)
        self.assertEqual(selected['action'], 'clear')
        self.assertTrue(audit['override'])
        self.assertTrue(audit['safe'])
        self.assertFalse(audit['unavoidable'])
        self.assertFalse(next(c for c in audit['candidates'] if c['action'] == 'brake')['safe'])

    def test_failed_solver_positive_fallback_is_checked_outside(self):
        ego = vehicle(y=-130., yaw=-math.pi/2, v=1.)
        path = np.c_[np.zeros(100), np.linspace(-130., -180., 100)]
        selected, audit = select_execution(ego, [], path, 4., 1., 0., dict(a=0., df=0.),
                                           GEOMETRY, solve_ok=False)
        self.assertEqual(selected['action'], 'brake')
        self.assertLess(selected['a'], 0.)
        self.assertTrue(audit['override'])

    def test_backup_respects_optimizer_steering_range_even_with_larger_physical_limit(self):
        ego = vehicle(y=-130., yaw=0., v=0.)
        path = np.c_[np.zeros(100), np.linspace(-130., -80., 100)]
        selected, _ = select_execution(ego, [], path, 4., 1., .99, dict(a=0., df=.99),
            dict(GEOMETRY, max_steer=1.3), solve_ok=False)
        self.assertLessEqual(abs(selected['delta']), 1.)

    def test_overlap_is_reported_instead_of_claimed_safe(self):
        ego = vehicle()
        obstacle = vehicle(actor=9, v=0.)
        path = np.c_[np.linspace(0., -50., 101), np.full(101, -138.)]
        selected, audit = select_execution(ego, [obstacle], path, 4., 1., 0.,
            dict(a=0., df=0.), GEOMETRY, solve_ok=False)
        self.assertTrue(audit['unavoidable'])
        self.assertFalse(audit['safe'])
        self.assertLess(selected['gap'], 0.)

    def test_smooth_game_cost_has_finite_derivatives_at_contact_and_zero_speed(self):
        import casadi as ca
        state = ca.MX.sym('state', 4)
        cost = smooth_interaction_cost(*ca.vertsplit(state),
                                      [4., 0., 0., 4., 2., -4., 0.], [4., 2.])
        evaluate = ca.Function('cost_and_gradient', [state], [cost, ca.gradient(cost, state)])
        value, gradient = evaluate([0., 0., 0., 0.])
        self.assertGreater(float(value), 0.)
        self.assertTrue(np.isfinite(np.asarray(gradient)).all())

    def test_native_environment_records_actual_response_and_physical_steering(self):
        source = ROOT/'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(source.read_text(encoding='utf8'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CarEnv_Town03_Turn')
        step = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'step')
        body = []
        for node in step.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Tuple) for t in node.targets):
                if any(isinstance(n, ast.Attribute) and n.attr == 'wrap_state' for n in ast.walk(node)):
                    break
            body.append(node)
        body.append(ast.Return(value=ast.Attribute(value=ast.Name(id='self', ctx=ast.Load()),
                                                   attr='last_control', ctx=ast.Load())))
        step.body = body
        namespace = dict(np=np, math=math, ackermann_target=ackermann_target,
                         carla=S(VehicleAckermannControl=lambda **kw: kw))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[step], type_ignores=[])), str(source), 'exec'), namespace)
        captured = []
        class World:
            frame = 0
            def get_snapshot(self):
                return S(frame=self.frame, timestamp=S(elapsed_seconds=self.frame*.05))
            def tick(self):
                self.frame += 1
        world = World()
        native = S(get_velocity=lambda: S(x=2.-.025*world.frame, y=0.),
                   apply_ackermann_control=captured.append,
                   get_control=lambda: S(throttle=0., brake=.01, steer=.2))
        env = S(world=world, ego_vehicle=native, native_control=True, traffic_enabled=True,
                control_geometry=dict(GEOMETRY, max_steer=1.2), dt=.05, sim_frame=0,
                cross_traffic=S(run_step=lambda ego: (None, -1, float('inf'))),
                update_vehicle_bboxes=lambda: None)
        control = namespace['step'](env, [-.5, .2], target_speed=4.)
        self.assertEqual(captured[0]['speed'], 1.5)
        self.assertAlmostEqual(control['ego_acc_measured'], -.5)
        self.assertEqual(control['brake'], .01)
        self.assertEqual(captured[0]['steer'], .2)
        self.assertAlmostEqual(control['delta_rad'], .24)
        self.assertEqual(control['sim_frame_after']-control['sim_frame_before'], 1)

    def test_default_comparison_disables_learning_and_differs_only_in_game(self):
        from Tools.run_relay_validation import main
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            self.assertEqual(main(['--dry-run', '--control-profile', 'paper_v8']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        for config in configs:
            self.assertEqual(config['DSH_CONTROL_PROFILE'], 'paper_v8')
            self.assertEqual(config['DSH_EFE'], '0')
            self.assertEqual(config['DSH_WCV_BCV'], '0')
        self.assertEqual({k for k in configs[0] if configs[0][k] != configs[1][k]},
                         {'DSH_METHOD', 'DSH_TAKE_COURNOT'})

    def test_incomplete_or_colliding_empty_road_cannot_pass_health(self):
        for rows, outcomes in [([], {}), ([{}], {'collision': 1})]:
            result = validate_control_health(rows, outcomes, traffic='off')
            self.assertFalse(result['empty_road_health_ok'])

    def test_healthy_evidence_passes_but_unclassified_risk_does_not(self):
        row = dict(control_profile='paper_v8', actuator_mode='ackermann',
            sim_dt='.05', sim_frame_before='1', sim_frame_after='2',
            ego_v_before='2.', ego_v_after='2.05', ego_acc_measured='1.', a_cmd='1.',
            actuator_speed_target='3.', actuator_accel_limit='1.',
            guard_safe='1', guard_unavoidable='0', guard_action='mpc',
            mpc_solve_ok='1', episode='1', goal_remaining='10.')
        self.assertTrue(validate_control_health([row], {'complete': 1}, 'off')['empty_road_health_ok'])
        row['guard_safe'] = '0'
        self.assertFalse(validate_control_health([row], {'complete': 1}, 'off')['actuator_contract_ok'])

    def test_stop_restart_probe_requires_actual_stop_and_recovery(self):
        common = dict(control_profile='paper_v8', actuator_mode='ackermann', sim_dt='.05',
            actuator_speed_target='0.', actuator_accel_limit='.4', guard_safe='1',
            guard_unavoidable='0', guard_action='mpc', mpc_solve_ok='1', episode='1', goal_remaining='10.')
        rows = []
        for k in range(90):
            speed = 0. if k < 40 else (k-40)*.02
            next_speed = 0. if k < 40 else speed+.02
            rows.append(dict(common, sim_frame_before=str(k), sim_frame_after=str(k+1),
                ego_v_before=str(speed), ego_v_after=str(next_speed),
                ego_acc_measured='0.' if k < 40 else '.4', a_cmd='-.3' if k < 40 else '.4',
                control_probe_phase='stop' if k < 40 else 'recovery'))
        self.assertTrue(validate_control_health(rows, {'complete': 1}, 'off', True)['empty_road_health_ok'])
        rows[-1]['ego_v_after'] = '.98'
        rows[-1]['ego_acc_measured'] = '0.'
        self.assertFalse(validate_control_health(rows, {'complete': 1}, 'off', True)['empty_road_health_ok'])

    def test_new_telemetry_roundtrips_without_column_shift(self):
        from Planning_library.interaction_logger import InteractionLogger
        with tempfile.TemporaryDirectory() as directory:
            logger = InteractionLogger(out_dir=directory, enabled=True)
            logger.begin_episode(1)
            logger.ego_row(ego=vehicle(), control=dict(control_profile='paper_v8',
                actuator_mode='ackermann', sim_dt=.05, ego_acc_measured=-.5,
                feasibility=dict(body_clear=False),
                execution_audit=dict(action='clear', safe=True, unavoidable=False,
                    candidates=[dict(action='clear', gap=.4)])))
            logger.close()
            with (Path(directory)/'interaction_ego.csv').open(encoding='utf8') as stream:
                row = next(csv.DictReader(stream))
        self.assertEqual(row['guard_action'], 'clear')
        self.assertEqual(row['guard_safe'], '1')
        self.assertEqual(float(row['ego_acc_measured']), -.5)
        self.assertEqual(row['body_clear'], '0')


class TestV8Optimizer(unittest.TestCase):
    def controller(self, enabled=False, speed=2.867, objects=None):
        from Agent.game_theory.MPC import MPCController
        c = MPCController(16, .05, 2.7, .5, enable_lead_follow_cost=False,
            enable_boundary_thw=False, enable_cournot_cost=enabled, cost_profile='paper_v8',
            step_dts=[.05]*6+[.2]*10, vehicle_geometry=GEOMETRY)
        ego = vehicle(x=0., y=0., yaw=0., v=speed)
        dynamic = S(ego_vehicle=ego, objects=objects or [], lanes=[S(front_vehicles=[], rear_vehicles=[])])
        c.reset_global_path(np.c_[np.arange(60.), np.zeros(60)], dynamic)
        c.set_game_context(dict(observed_vehicles=objects or [], committed=True), ego)
        return c, dynamic

    def test_measured_deceleration_does_not_make_braking_deeper(self):
        results = []
        for before in (4.195, 2.867):
            c, dynamic = self.controller()
            c.last_u = dict(a=-.2, df=0.)
            c._previous_observed_speed = before
            acceleration, _ = c.solve(dynamic, 4., False)
            self.assertTrue(c._solve_ok)
            self.assertGreater(acceleration, -.2)
            results.append(acceleration)
        self.assertAlmostEqual(*results, places=5)

    def test_held_brakes_release_at_zero_speed_without_fictitious_jerk(self):
        c, dynamic = self.controller(speed=0.)
        c.last_u = dict(a=-3., df=0.)
        acceleration, _ = c.solve(dynamic, 4., False)
        self.assertTrue(c._solve_ok)
        self.assertGreaterEqual(acceleration, 0.)

    def test_no_opponent_does_not_change_control_when_game_is_enabled(self):
        results = []
        for enabled in (False, True):
            c, dynamic = self.controller(enabled)
            results.append(c.solve(dynamic, 4., False))
            self.assertTrue(c._solve_ok)
        np.testing.assert_allclose(results[0], results[1], atol=1e-4)

    def test_game_still_changes_real_optimizer_and_keeps_committed_opponent(self):
        results = []
        for enabled in (False, True):
            c, dynamic = self.controller(enabled, speed=3.,
                objects=[vehicle(actor=5, x=7., y=0., yaw=0., v=0.)])
            results.append(c.solve(dynamic, 4., False))
            self.assertTrue(c._solve_ok)
            if enabled:
                self.assertIn(5, c.last_game_diag['participant_ids'])
                self.assertGreater(c.last_game_diag['safety'], 0.)
        self.assertGreater(np.linalg.norm(np.subtract(*results)), .01)

    def test_failure_snapshot_preserves_observations_and_warm_start(self):
        c, dynamic = self.controller(True, objects=[vehicle(actor=5, x=20., y=0., yaw=0., v=4.)])
        with tempfile.TemporaryDirectory() as directory, patch.dict('os.environ', DSH_SAVE_DIR=directory):
            with patch.object(c.opti, 'solve', side_effect=RuntimeError('replayable offline failure')):
                c.solve(dynamic, 4., False)
            self.assertFalse(c._solve_ok)
            data = json.loads((Path(directory)/c.last_failure_snapshot).read_text(encoding='utf8'))
        self.assertEqual(data['format'], 'mpc_v8_failure_v1')
        self.assertEqual(data['observed_vehicles'][0]['veh_id'], 5)
        self.assertAlmostEqual(data['geometry']['wheelbase'], 2.85)
        self.assertIsNone(c.last_prediction)
        from Tools.replay_mpc_failure import replay
        result = replay(data)
        self.assertTrue(result['solve_ok'])
        self.assertIn(5, result['game_cost']['participant_ids'])


if __name__ == '__main__':
    unittest.main()
