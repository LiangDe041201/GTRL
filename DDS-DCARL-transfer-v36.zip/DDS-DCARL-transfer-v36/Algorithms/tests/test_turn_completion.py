"""Completion must reject off-path arrivals even when the legacy check passes."""
import ast
import math
from pathlib import Path
import sys
from types import SimpleNamespace as S
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Planning_library.turn_completion import completion_metrics


class TestCompletionGeometry(unittest.TestCase):
    def metrics(self, x=98., y=0., yaw=0., reference=None, goal_yaw=0.):
        if reference is None:
            reference = [[0., 0.], [50., 0.], [100., 0.]]
        return completion_metrics(x, y, yaw, 100., 0., goal_yaw, reference)

    def test_aligned_arrival_completes(self):
        self.assertTrue(self.metrics()['strict_complete'])

    def test_close_to_goal_but_off_path_does_not_complete(self):
        self.assertFalse(self.metrics(y=3.)['strict_complete'])

    def test_wrong_heading_does_not_complete(self):
        self.assertFalse(self.metrics(yaw=math.radians(60))['strict_complete'])

    def test_heading_wraparound_does_not_reject_aligned_arrival(self):
        self.assertTrue(self.metrics(yaw=math.radians(179), goal_yaw=math.radians(-179))
                        ['strict_complete'])

    def test_too_far_from_goal_does_not_complete(self):
        self.assertFalse(self.metrics(x=90.)['strict_complete'])

    def test_invalid_reference_cannot_report_success(self):
        for path in ([], [[100., 0.]], [[100., 0.], [100., 0.]], [[float('nan'), 0.], [100., 0.]]):
            self.assertFalse(self.metrics(reference=path)['strict_complete'])

    def test_duplicate_points_do_not_change_progress(self):
        result = self.metrics(reference=[[0., 0.], [50., 0.], [50., 0.], [100., 0.]])
        self.assertTrue(result['strict_complete'])
        self.assertAlmostEqual(result['path_progress'], .98)

    def test_environment_rejects_a_legacy_false_positive(self):
        path = ROOT / 'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and
                   n.name == 'CarEnv_Town03_Turn')
        methods = [n for n in cls.body if isinstance(n, ast.FunctionDef) and
                   n.name in ('_turn_complete', '_turn_complete_legacy', '_distance_to_goal')]
        goal = S(location=S(x=-21., y=-138.51), rotation=S(yaw=-179.))
        namespace = dict(math=math, np=np, goal_point=goal,
                         completion_metrics=completion_metrics,
                         _normalize_angle=lambda a: math.atan2(math.sin(a), math.cos(a)))
        exec(compile(ast.Module(body=methods, type_ignores=[]), str(path), 'exec'), namespace)
        env_type = type('OfflineEnvironment', (), {n.name: namespace[n.name] for n in methods})
        env = env_type()
        transform = S(location=S(x=-19., y=-131.), rotation=S(yaw=-179.))
        env.ego_vehicle = S(get_transform=lambda: transform, get_location=lambda: transform.location)
        env.initial_yaw = math.radians(-89.)
        env.ref_path_array = np.asarray([[6., -103.], [6., -126.], [3., -134.],
                                        [-3., -138.], [-10., -138.5], [-21., -138.51]])
        env.completion_mode = 'strict'
        self.assertTrue(env._turn_complete_legacy())
        self.assertFalse(env._turn_complete())
        self.assertTrue(env.completion_diag['legacy_complete'])
        self.assertGreater(env.completion_diag['path_distance'], 7.)
        env.completion_mode = 'legacy'
        self.assertTrue(env._turn_complete())


if __name__ == '__main__':
    unittest.main()
