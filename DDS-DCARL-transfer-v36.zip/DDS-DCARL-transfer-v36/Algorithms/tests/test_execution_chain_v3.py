"""Regression cases from the v2 CARLA return, executable without CARLA."""
import ast
import math
from pathlib import Path
import sys
from types import SimpleNamespace as S
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Agent.tools_dds.actions import TrajectoryAction
from Agent.tools_dds.tools import Frenet_path
from Planning_library.trajectory_guard import (
    clean_path, road_geometry, execution_speed, execution_acceleration)

try:
    from Agent.game_theory.MPC import MPCController, GlobalPath, VehicleModel
except ImportError:
    MPCController = None


def offline_planner():
    """Load actual planner methods while excluding simulator imports."""
    path = ROOT / 'Agent/tools_dds/LaneTrajectoryPlanner.py'
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Werling')
    names = {'_generate_speed_trajectory', '_create_reference_fallback',
             '_create_brake_trajectory', '_as_action', 'trajectory_update_UBP', 'trajectory_update'}
    methods = [n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name in names]
    ns = dict(np=np, math=math, clean_path=clean_path, road_geometry=road_geometry,
              Frenet_path=Frenet_path, TrajectoryAction=TrajectoryAction, ACTION_MODE='2d',
              TURN_2D_SPEEDS=[0., 2., 4., 6.], TURN_2D_LATERALS=[-1.5, 0., 1.5], _N_LAT=3,
              _clip_action=lambda a: max(0, min(11, int(a))),
              action_speed=lambda a: [0., 2., 4., 6.][int(a) // 3],
              action_lateral=lambda a: [-1.5, 0., 1.5][int(a) % 3],
              dist_from_point_to_polyline2d=lambda *args, **kw: (0.,))
    exec(compile(ast.Module(body=methods, type_ignores=[]), str(path), 'exec'), ns)
    planner = type('OfflineWerling', (), {n.name: ns[n.name] for n in methods})()
    planner._lane_idx = 0
    return planner


def straight_map(x=0., y=.1, speed=0., yaw=0., road=True):
    lane = S(front_vehicles=[], rear_vehicles=[])
    if road:
        lane.central_path_array = np.asarray([[0., 0.], [10., 0.], [20., 0.]])
    return S(ego_vehicle=S(x=x, y=y, yaw=yaw, v=speed, lane_idx=0), lanes=[lane])


class TestPlanningExecution(unittest.TestCase):
    def test_stationary_action_keeps_road_heading_instead_of_sideways_path(self):
        planner, dynamic_map = offline_planner(), straight_map()
        path = planner._generate_speed_trajectory(dynamic_map, 0., di=0.)
        self.assertIsNotNone(path)
        heading = math.atan2(path.y[1] - path.y[0], path.x[1] - path.x[0])
        self.assertAlmostEqual(heading, 0.)
        self.assertEqual(path.planning_status, 'stationary_geometry')

    def test_reference_endpoint_extension_has_no_repeated_points(self):
        planner, dynamic_map = offline_planner(), straight_map(x=20.)
        path = planner._create_reference_fallback(dynamic_map, 6.)
        self.assertIsNotNone(path)
        points = np.c_[path.x, path.y]
        self.assertGreater(np.min(np.linalg.norm(np.diff(points, axis=0), axis=1)), .01)
        self.assertLessEqual(max(path.s_d), 2.)

    def test_emergency_brake_semantics_survive_action_conversion(self):
        planner, dynamic_map = offline_planner(), straight_map(speed=4.)
        path = planner._create_brake_trajectory(dynamic_map)
        action = planner._as_action(path, 8.)
        self.assertTrue(action.force_stop)
        self.assertEqual(action.desired_speed, 0.)
        target, reason, _ = execution_speed(8., action, 0., .1)
        self.assertEqual(target, 0.)
        self.assertIn('planner_stop', reason)
        self.assertLess(execution_acceleration(2., 4., target), 0.)

    def test_emergency_hold_geometry_remains_valid_without_road_or_speed(self):
        planner = offline_planner()
        path = planner._create_brake_trajectory(straight_map(road=False))
        self.assertTrue(path.force_stop)
        self.assertIsNotNone(clean_path(np.c_[path.x, path.y]))
        self.assertEqual(max(path.s_d), 0.)

    def test_rule_fallback_cannot_restore_positive_speed_after_braking(self):
        planner, dynamic_map = offline_planner(), straight_map(speed=4., road=False)
        dynamic_map.lanes[0].central_path_array = None
        planner.initialize_obj_predict = lambda *_: None
        planner.calculate_start_state = lambda *_: None
        planner.frenet_optimal_planning = lambda *args: (None, 8., 0)
        planner.csp, planner.c_speed = None, 4.
        action, _ = planner.trajectory_update(dynamic_map, 8., 0., 0)
        self.assertTrue(action.force_stop)
        self.assertEqual(action.desired_speed, 0.)
        self.assertEqual(execution_speed(8., action, 0., 0.)[0], 0.)

    def test_policy_fallback_recovers_on_road_with_explicit_speed_cap(self):
        planner, dynamic_map = offline_planner(), straight_map(x=19., speed=4.)
        planner._generate_speed_trajectory = lambda *args, **kw: None
        action = planner.trajectory_update_UBP(dynamic_map, 10)
        self.assertEqual(action.planning_status, 'road_recovery')
        self.assertEqual(execution_speed(8., action, 19., .1)[0], 2.)

    def test_collapsed_geometry_is_rejected(self):
        for points in ([[0., 0.]] * 14, [[0., .1], [0., .05], [0., 0.]]):
            self.assertIsNone(clean_path(points))

    def test_goal_guard_stops_the_recorded_far_endpoint_overrun(self):
        action = TrajectoryAction()
        goal = (-21., -138.51, math.radians(-179.))
        for x, y in [(-94.122, -148.724), (-92.292, -102.097)]:
            speed, reason, remaining = execution_speed(8., action, x, y, goal)
            self.assertEqual(speed, 0.)
            self.assertIn('goal_hold', reason)
            self.assertLess(remaining, 0.)

    def test_goal_approach_does_not_accelerate_or_limit_the_distant_start(self):
        action = TrajectoryAction()
        goal = (-21., -138.51, math.radians(-179.))
        self.assertEqual(execution_speed(8., action, 5.78, -103.23, goal)[0], 8.)
        self.assertLess(execution_speed(8., action, -16., -138.51, goal)[0], 8.)
        self.assertEqual(execution_speed(.5, action, -16., -138.51, goal)[0], .5)

    def test_zero_target_reaches_real_environment_as_brake_not_throttle(self):
        path = ROOT / 'Test_Scenarios/TestScenario_Town03_turn.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig'))
        cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'CarEnv_Town03_Turn')
        method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'step')
        dispatch = next(node for node in method.body if isinstance(node, ast.If) and
                        any(isinstance(n, ast.Attribute) and n.attr == 'apply_ackermann_control'
                            for n in ast.walk(node)))
        assignment = next(node for node in method.body if isinstance(node, ast.Assign) and
                          any(isinstance(t, ast.Name) and t.id == 'a_cmd' for t in node.targets))
        method.body = [assignment] + dispatch.orelse
        ns = dict(np=np, carla=S(VehicleControl=lambda **kw: kw))
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(path), 'exec'), ns)
        commands = []
        env = S(ego_vehicle=S(apply_control=commands.append))
        ns['step'](env, [execution_acceleration(2., 0., 0.), 0.])
        self.assertEqual(commands[0]['throttle'], 0.)
        self.assertGreater(commands[0]['brake'], 0.)


@unittest.skipIf(MPCController is None, 'Requires CasADi')
class TestMpcExecution(unittest.TestCase):
    def controller(self, dynamic_map):
        c = MPCController(10, .05, 2.7, .5,
                          enable_lead_follow_cost=False, enable_boundary_thw=False)
        c.reset_global_path(np.c_[np.arange(40.), np.zeros(40)], dynamic_map)
        return c

    def test_amplitude_bounds_apply_to_entire_optimized_sequence(self):
        dynamic_map = straight_map(y=0., speed=1.)
        c = self.controller(dynamic_map)
        c.last_u = dict(a=2.2, df=0.)
        c.solve(dynamic_map, 8., False)
        self.assertTrue(c._solve_ok)
        sequence = np.asarray(c.opti.debug.value(c.u))
        self.assertLessEqual(sequence[0].max(), 2.001)
        self.assertGreaterEqual(sequence[0].min(), -3.001)
        self.assertLessEqual(np.abs(sequence[1]).max(), 1.001)

    def test_standstill_with_previous_braking_is_feasible_and_cannot_reverse(self):
        dynamic_map = straight_map(y=0.)
        c = self.controller(dynamic_map)
        c.last_u = dict(a=-3., df=0.)
        c.solve(dynamic_map, 0., False)
        self.assertTrue(c._solve_ok)
        self.assertGreaterEqual(np.asarray(c.opti.debug.value(c.x))[5].min(), -.001)
        model = VehicleModel()
        state = dict(x=0., y=0., s=0., l=0., epsi=0., heading=0., K=0., v=.01)
        self.assertEqual(float(model.dynamics_step(state, dict(a=-3., df=0.))['v']), 0.)

    def test_actual_limiter_command_is_the_next_slew_reference(self):
        dynamic_map = straight_map(y=0., speed=3.)
        c = self.controller(dynamic_map)
        c.last_u = dict(a=1., df=0.)
        c.solve(dynamic_map, 5., False)
        c.acknowledge_applied_control(0., 0.)
        acceleration, _ = c.solve(dynamic_map, 5., False)
        self.assertTrue(c._solve_ok)
        self.assertLessEqual(acceleration, .101)

    def test_collapsed_mpc_path_uses_road_and_preserves_real_heading_error(self):
        dynamic_map = straight_map(y=.1, yaw=.2)
        c = self.controller(dynamic_map)
        c.reset_global_path([[0., .1]] * 12, dynamic_map)
        self.assertEqual(c.geometry_source, 'road_recovery')
        self.assertAlmostEqual(c.ego_info_convert(dynamic_map)['epsi'], .2)

    def test_no_usable_path_requests_stop_instead_of_authorizing_a_straight_drive(self):
        dynamic_map = straight_map(road=False)
        c = MPCController(3, .05, 2.7, .5, enable_lead_follow_cost=False)
        c.reset_global_path([[0., .1]] * 5, dynamic_map)
        self.assertTrue(c.geometry_force_stop)
        self.assertEqual(c.geometry_source, 'heading_hold')

    def test_curve_heading_wraparound_does_not_create_a_curvature_spike(self):
        angles = np.linspace(math.pi / 2 - .4, math.pi / 2 + .4, 21)
        path = GlobalPath(np.c_[10 * np.cos(angles), 10 * np.sin(angles)])
        path.set_frenet_path(*[float(x) for x in (10 * math.cos(angles[0]), 10 * math.sin(angles[0]))])
        self.assertGreater(min(path.kappa[1:-1]), .05)
        self.assertLess(max(path.kappa), .2)


if __name__ == '__main__':
    unittest.main()
