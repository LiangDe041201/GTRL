"""Explicit learner selection must reject mixed CG/default evidence."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
from Planning_library.rolling_learning_v24 import RollingLearner
from Tools.validate_rolling_v24 import validate_rolling_record,validate_rolling_experience
from Tools.validate_matrix_game import validate_matrix_game
import test_rolling_validation_v24 as fixtures


class CGValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.evidence=fixtures.RollingValidationTests().evidence(full=True,terminal=True)

    def row(self):
        row,ego=copy.deepcopy(self.evidence[:2]);p=row['rolling_trajectory'];learning=p['learning']
        parts=json.loads(learning['state']);allowed=parts[3]
        p.update(learner_revision='cg_trajectory_learning_v29',baseline_action=0,
                 reference_policy='uniform_admissible_v29')
        learning.update(default=0,baseline_action=0,reference_policy='uniform_admissible_v29',
            proposal_geometry_stratum=parts[2],source='explore',certified=False,
            prior=[1./len(allowed) if a in allowed else 0. for a in range(6)])
        return row,ego

    def validate(self,row,ego):
        return validate_rolling_record(row,ego,'train',expected_learner='cg_v29')

    def test_explicit_v29_real_control_evidence_accepts_new_uniform_reference(self):
        self.assertEqual(self.validate(*self.row()),{})

    def test_v29_and_legacy_records_cannot_silently_exchange_modes(self):
        row,ego=self.row()
        self.assertTrue(validate_rolling_record(row,ego,'train'))
        del row['rolling_trajectory']['learner_revision']
        self.assertTrue(validate_rolling_record(row,ego,'train'))
        old,old_ego=copy.deepcopy(self.evidence[:2])
        self.assertTrue(self.validate(old,old_ego))

    def test_geometry_default_nonuniform_prior_and_false_cg_fallback_are_rejected(self):
        for field,value in [('default',1),('prior',[1.,0.,0.,0.,0.,0.]),
                            ('proposal_geometry_stratum',-1),('source','cg_default')]:
            row,ego=self.row();row['rolling_trajectory']['learning'][field]=value
            self.assertTrue(self.validate(row,ego),(field,value))

    def test_takeover_requires_both_independent_coverage_and_cg_bound_advantage(self):
        for coverage,wcv,bcv in [(9,1.,0.),(10,0.,1.)]:
            row,ego=self.row();learning=row['rolling_trajectory']['learning']
            learning.update(source='takeover',certified=True)
            chosen=learning['bounds'][str(learning['requested'])];base=learning['bounds']['0']
            chosen.update(n=coverage,wcv=wcv);base.update(n=10,bcv=bcv)
            self.assertTrue(self.validate(row,ego))

    def checkpoint(self,root,learner):
        learner.begin([0.]*16,dict(alpha=1.,beta=1.),0,[0,1],[1.,0.,9.,9.,9.,9.],1)
        file=root/'rolling_model/frozen_input.json';file.parent.mkdir(parents=True)
        learner.save(file)
        meta=dict(signature=learner.signature(),learner_revision='cg_trajectory_learning_v29',
            baseline_action=0,reference_policy='uniform_admissible_v29',
            checkpoint_sha256=hashlib.sha256(file.read_bytes()).hexdigest())
        (root/'rolling_metadata_v24.json').write_text(json.dumps(meta),encoding='utf8')
        return file,meta

    def test_frozen_v29_checkpoint_and_metadata_are_both_explicitly_checked(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);file,meta=self.checkpoint(root,CGTrajectoryLearnerV29())
            before=file.read_bytes()
            good=validate_rolling_experience(root,[],'eval',expected_learner='cg_v29')
            self.assertTrue(good['rolling_experience_contract_ok'],good)
            self.assertEqual(file.read_bytes(),before)
            meta['signature']=RollingLearner().signature()
            (root/'rolling_metadata_v24.json').write_text(json.dumps(meta),encoding='utf8')
            bad=validate_rolling_experience(root,[],'eval',expected_learner='cg_v29')
            self.assertFalse(bad['rolling_experience_contract_ok'])

    def test_old_checkpoint_cannot_be_relabelled_as_v29_and_eval_cannot_write(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);self.checkpoint(root,RollingLearner())
            bad=validate_rolling_experience(root,[],'eval',expected_learner='cg_v29')
            self.assertFalse(bad['rolling_experience_contract_ok'])
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);self.checkpoint(root,CGTrajectoryLearnerV29())
            (root/'rolling_model/rolling_model.json').write_text('{}',encoding='utf8')
            bad=validate_rolling_experience(root,[],'eval',expected_learner='cg_v29')
            self.assertIn('eval_model_write',bad['rolling_experience_errors'])

    def test_outer_matrix_audit_passes_explicit_learner_selection(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);self.checkpoint(root,CGTrajectoryLearnerV29())
            result=validate_matrix_game(root,[],'matrix_v18',expected_rolling='eval',
                                        expected_rolling_learner='cg_v29')
            self.assertTrue(result['rolling_experience_contract_ok'],result)


if __name__=='__main__':unittest.main()
