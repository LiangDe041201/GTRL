# -*- coding: utf-8 -*-
"""论文一致性回归测试 —— 锁死"逐式口径"与"论文 Table I 数值"。

背景（PLAN §42）：第 1/2 步的独立验证发现 8 条残留限制（LIMIT）。
本文件把**已修好的**那些锁成测试，防止再次退化：
  · 式(49) 的权重必须等于论文 Table I（ω_κ=1, ω_Δκ=2, ω_{dκ/ds}=5, ω_j=1, ω_TH=10, κ_TH=0.1）
  · 式(18) 必须是对**对手动作频率**求熵，且底数为 **2**
  · 式(16) 的信息集基数必须**逐动作**（否则对 argmin 无影响 = 假落地）
  · 式(20) / 式(24) 的权重与阈值必须**可配**（不是埋在签名里的字面量）
  · 式(48) 的 6 档候选集必须**可达**（不是只留一个常量）
  · 式(10) 的默认动作空间必须是**二维联合**（不是 lateral）
"""
import importlib
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DSH_ACTION_MODE', '2d')


# ============================================================
# 式(49)：论文 Table I 的权重（原始 docx 表 I 逐行核对）
# ============================================================
def test_formula49_weights_match_paper_table_I():
    import Agent.tools_dds.LaneTrajectoryPlanner as L
    assert abs(L.W_K - 1.0) < 1e-9, 'ω_κ 应为 1，实测 %s' % L.W_K
    assert abs(L.W_DK - 2.0) < 1e-9, 'ω_Δκ 应为 2，实测 %s' % L.W_DK
    assert abs(L.W_DKDS - 5.0) < 1e-9, 'ω_{dκ/ds} 应为 5，实测 %s' % L.W_DKDS
    assert abs(L.KJ - 1.0) < 1e-9, 'ω_j 应为 1（原为 0.1，与论文不符），实测 %s' % L.KJ
    assert abs(L.HINGE_W - 10.0) < 1e-9, 'ω_TH 应为 10（原为硬编码 1e6），实测 %s' % L.HINGE_W
    assert abs(L.MAX_ABS_K - 0.1) < 1e-9, 'κ_TH 应为 0.1，实测 %s' % L.MAX_ABS_K


def test_formula49_weights_are_configurable(monkeypatch=None):
    """权重必须可经环境变量覆盖（论文未给的那几个阈值尤其是）。"""
    import Agent.tools_dds.LaneTrajectoryPlanner as L
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            'Agent/tools_dds/LaneTrajectoryPlanner.py'),
               encoding='utf-8').read()
    for k in ('DSH_KJ', 'DSH_HINGE_W', 'DSH_W_K', 'DSH_W_DK', 'DSH_W_DKDS',
              'DSH_MAX_ABS_K', 'DSH_MAX_ABS_DK', 'DSH_MAX_ABS_DKDS'):
        assert k in src, '式(49) 的参数 %s 未参数化' % k


# ============================================================
# 式(18)：对手**动作频率**熵，底数 2
# ============================================================
def test_formula18_action_frequency_entropy():
    from Planning_library.information_set import rv_action_entropy
    assert abs(rv_action_entropy(['yield'] * 5)) < 1e-12, '单一动作 ⇒ H=0'
    assert abs(rv_action_entropy(['yield', 'rush', 'yield', 'rush']) - 1.0) < 1e-12, \
        '两动作均分 ⇒ H=1 bit（log2）'
    assert abs(rv_action_entropy(['a', 'b', 'c']) - math.log(3, 2)) < 1e-12, \
        '三动作均分 ⇒ H=log2(3)'
    assert rv_action_entropy([]) == 0.0, '空历史 ⇒ 0'
    assert rv_action_entropy([None, None]) == 0.0, 'None 动作不计入'


# ============================================================
# 式(16)：信息集基数必须**逐动作**（否则不改变 argmin = 假落地）
# ============================================================
def test_formula16_cardinality_is_per_action():
    import numpy as np
    from Planning_library.active_inference import info_cardinality_by_action
    # 类型 A 观测锐利、类型 B 弥散 ⇒ 混合情形应落在 (1,2) 之间
    cond = {'A': np.array([0.94, 0.02, 0.03, 0.01]),
            'B': np.array([0.30, 0.25, 0.25, 0.20])}
    c = info_cardinality_by_action(cond, {'A': 0.5, 'B': 0.5})
    assert 1.0 <= c <= 2.0, '应落在 [1,2]，实测 %s' % c
    # 两侧都锐利且互不重叠 ⇒ 观测后能区分 ⇒ 基数应≈1
    sharp = {'A': np.array([1.0, 0.0, 0.0, 0.0]), 'B': np.array([0.0, 1.0, 0.0, 0.0])}
    assert info_cardinality_by_action(sharp, {'A': 0.5, 'B': 0.5}) < 1.01
    # 两侧完全相同 ⇒ 观测无信息 ⇒ 基数应≈2
    same = {'A': np.array([0.25] * 4), 'B': np.array([0.25] * 4)}
    assert info_cardinality_by_action(same, {'A': 0.5, 'B': 0.5}) > 1.99


def test_formula16_changes_argmin_via_efe():
    """逐动作基数必须真的进入 EFE（不同动作 → 不同 r_info）。"""
    from Planning_library.active_inference import efe_by_action
    bel = {'conservative': 0.2, 'normal': 0.5, 'aggressive': 0.3}
    margins = {0: {'yield': -2.0, 'rush': -2.0},
               4: {'yield': 0.8, 'rush': -0.5},
               10: {'yield': 3.0, 'rush': 2.0}}
    yprobs = {a: {'conservative': 0.7, 'normal': 0.5, 'aggressive': 0.25} for a in margins}
    res = efe_by_action(margins, yprobs, bel, w_info=1.0)
    cards = [res[a]['info_card_action'] for a in sorted(res)]
    assert len({round(c, 6) for c in cards}) > 1, \
        '逐动作基数在所有动作上相同 ⇒ 不改变 argmin ⇒ 式(16) 假落地: %s' % cards
    # w_info=0 必须可回退
    res0 = efe_by_action(margins, yprobs, bel, w_info=0.0)
    assert all(abs(res0[a]['r_info']) < 1e-12 for a in res0)


def test_formula18_entropy_enters_efe():
    from Planning_library.active_inference import efe_by_action
    bel = {'normal': 1.0}
    margins = {0: {'yield': 1.0, 'rush': 0.0}}
    yprobs = {0: {'normal': 0.5}}
    a0 = efe_by_action(margins, yprobs, bel, w_action_entropy=0.0)[0]['r_action_entropy']
    a1 = efe_by_action(margins, yprobs, bel, action_entropy=1.0, w_action_entropy=1.0)[0]['r_action_entropy']
    assert abs(a0) < 1e-12 and abs(a1 - 1.0) < 1e-12, (a0, a1)


# ============================================================
# 式(20)：权重可配（不是埋死的字面量）
# ============================================================
def test_formula20_weights_are_configurable():
    from Planning_library.cournot_game import build_payoff_matrix
    a = build_payoff_matrix(12.0, 20.0, v_go=4.0, thw_rv=3.0, thw_fv=3.0)
    b = build_payoff_matrix(12.0, 20.0, v_go=4.0, thw_rv=3.0, thw_fv=3.0,
                            w_eff=2.0, w_safe=0.0, w_comf=0.0, wait_penalty=5.0)
    assert a != b, '权重改了但支付矩阵不变 ⇒ 权重没生效'
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'),
               encoding='utf-8').read()
    for k in ('DSH_W_EFF', 'DSH_W_SAFE', 'DSH_W_COMF', 'DSH_WAIT_PENALTY', 'DSH_THW_TH'):
        assert k in src, '式(20) 的权重 %s 未参数化' % k


# ============================================================
# 式(24)：J_TH / ψ_TH 可配（论文 Table I 未给 ⇒ 自由参数）
# ============================================================
def test_formula24_thresholds_are_configurable():
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'),
               encoding='utf-8').read()
    assert 'DSH_J_TH' in src and 'DSH_PSI_TH' in src, '式(24) 的 J_TH/ψ_TH 未参数化'
    # 且不再有硬编码的 jerk=/steer= 常数
    import re
    assert not re.search(r'jerk\s*=\s*[0-9.]+\s*,\s*steer\s*=\s*[0-9.]+', src), \
        '仍存在硬编码的 jerk=/steer= 常数'


# ============================================================
# 式(48) / 式(10)：横向候选集可达 + 默认二维
# ============================================================
def test_formula48_six_levels_reachable_by_config():
    """式(48) 的 6 档必须能通过配置真正跑起来（不是只留常量）。"""
    assert 'DSH_LAT_LEVELS' in open(
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     'Agent/tools_dds/LaneTrajectoryPlanner.py'), encoding='utf-8').read()
    code = (
        "import os; os.environ['DSH_ACTION_MODE']='2d'; os.environ['DSH_LAT_LEVELS']='6';"
        "import importlib, Agent.tools_dds.LaneTrajectoryPlanner as L;"
        "importlib.reload(L);"
        "print(L.TURN_2D_LATERALS); print(L.N_ACTIONS); print(L.BRAKE_ACTION)"
    )
    import subprocess
    out = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True,
                         cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         env=dict(os.environ, PYTHONPATH=os.path.dirname(os.path.dirname(
                             os.path.abspath(__file__))) + ':' + os.environ.get('PYTHONPATH', '')))
    assert out.returncode == 0, out.stderr[-500:]
    lines = out.stdout.strip().split('\n')
    lat = eval(lines[0])
    assert lat == [0.0, 0.5, 1.0, 1.5, 2.0, 2.5], '6 档应等于论文式(48) 原样，实测 %s' % lat
    assert int(lines[1]) == 24, '6 档 × 4 纵向 = 24 动作，实测 %s' % lines[1]
    assert int(lines[2]) == 0, '含 0.0 ⇒ BRAKE_ACTION=0' 


def test_formula10_default_is_2d_not_lateral():
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            'Agent/tools_dds/LaneTrajectoryPlanner.py'), encoding='utf-8').read()
    import re
    m = re.search(r"ACTION_MODE\s*=\s*_os\.environ\.get\('DSH_ACTION_MODE',\s*'([a-z0-9]+)'\)", src)
    assert m and m.group(1) == '2d', "式(10) 默认必须是二维联合 '2d'，实测 %r" % (m.group(1) if m else None)


if __name__ == '__main__':
    fns = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in fns:
        fn()
        print('ok  %s' % fn.__name__)
    print('\nALL %d PASSED' % len(fns))
