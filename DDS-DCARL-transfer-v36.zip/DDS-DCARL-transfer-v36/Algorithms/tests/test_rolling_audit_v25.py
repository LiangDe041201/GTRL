"""Equivalent spatial eligibility/payoffs with fewer identical forecasts."""
import unittest

import numpy as np
from Planning_library.forecast_v18 import predict
from Planning_library.matrix_turn_game_v18 import score_candidates
from Planning_library.matrix_turn_game_v20 import candidate_execution
from Planning_library.trajectory_guard import execution_acceleration
import test_rolling_planner_v24 as fixtures

try:
    from Planning_library.rolling_audit_v25 import CandidateAudit
except ImportError:
    CandidateAudit = None


class RollingAuditTests(unittest.TestCase):
    def fixture(self):
        p, f = fixtures.RollingPlannerTests().fixture('observe')
        return p, f

    def auditor(self, p, f, calls=None):
        self.assertIsNotNone(CandidateAudit, 'Spatial forecasts are still recomputed by each consumer')
        def counted(*args, **kwargs):
            if calls is not None: calls.append((args[2:5], kwargs['lag']))
            return predict(*args, **kwargs)
        return CandidateAudit(f[1].ego_vehicle, f[1].objects, f[1].objects[0],
            f[2][1]['controller'].last_pathway, f[5]['previous'], p.geometry,
            p.cruise, f[4].last.get('motion_evidence', {}).get('acceleration'), predictor=counted)

    def compare(self, p, f, candidate):
        ego, objects = f[1].ego_vehicle, f[1].objects
        path = f[2][1]['controller'].last_pathway
        execution = candidate_execution(ego, objects, [candidate], path, f[5]['previous'], p.geometry)[0]
        _, parts = score_candidates(ego, objects, objects[0], [candidate], p.geometry, path,
            f[5]['previous'], p.cruise, f[4].last.get('motion_evidence', {}).get('acceleration'))
        audit = self.auditor(p, f)
        actual, components, forecasts = audit.evaluate(candidate)
        self.assertEqual(actual, execution)
        self.assertEqual(components, parts[0])
        acceleration = execution_acceleration(candidate['a'], max(0., ego.v), candidate['target'])
        for value, lag in zip(forecasts, (0., .4)):
            expected = predict(ego, path, candidate['target'], acceleration, candidate['delta'],
                f[5]['previous'], p.geometry, horizon=6., lag=lag,
                plan=candidate.get('plan'), plan_times=candidate.get('times'))
            np.testing.assert_array_equal(value[0], expected[0])
            np.testing.assert_array_equal(value[1], expected[1])
            self.assertEqual(value[2], expected[2])

    def test_safe_candidate_keeps_exact_execution_and_payoff_results(self):
        p, f = self.fixture()
        self.compare(p, f, f[2][1])

    def test_guard_horizon_is_not_confused_with_six_second_payoff_and_road_horizon(self):
        p, f = self.fixture()
        p.geometry=dict(p.geometry,execution_horizon=.1)
        self.compare(p, f, f[2][1])

    def test_overlapping_vehicle_stop_and_failed_solver_keep_rejections(self):
        from test_forecast_v18 import vehicle
        p, f = self.fixture()
        f[1].objects = [vehicle(3, 6., -120., -np.pi/2, 0., 0.)]
        self.compare(p, f, f[2][1])
        stopped = dict(f[2][1], target=0.)
        self.compare(p, f, stopped)
        failed = dict(stopped, solve_ok=False, prediction=None, plan=None)
        self.compare(p, f, failed)

    def test_same_two_forecasts_are_shared_by_guard_score_and_road_consumers(self):
        p, f = self.fixture(); calls = []
        audit = self.auditor(p, f, calls)
        audit.evaluate(f[2][1])
        self.assertEqual(len(calls), 2)
        self.assertEqual({lag for _, lag in calls}, {0., .4})

    def test_clamped_controls_and_changed_plan_do_not_reuse_a_different_prediction(self):
        p, f = self.fixture(); calls = []
        audit = self.auditor(p, f, calls)
        candidate = dict(f[2][1], target=.2, a=1.5)
        self.compare(p, f, candidate)
        first = audit.evaluate(candidate)[2]
        changed = dict(candidate, plan=candidate['plan'].copy())
        changed['plan'][1, 1] += .02
        second = audit.evaluate(changed)[2]
        self.assertGreater(len(calls), 2)
        self.assertGreater(np.max(np.abs(first[0][0]-second[0][0])), 1e-8)

    def test_real_planner_uses_shared_forecasts_and_reports_stage_timings(self):
        p, f = self.fixture()
        fixtures.RollingPlannerTests().request(p, f)
        timing = p.last.get('timing', {})
        self.assertEqual(timing.get('prediction_calls'), 10,
                         'The five spatial candidates still recompute their predictions')
        for key in ('generation_ms', 'mpc_reset_ms', 'mpc_solve_ms', 'execution_ms',
                    'score_ms', 'prediction_ms', 'road_audit_ms', 'selection_ms'):
            self.assertTrue(np.isfinite(timing[key]) and timing[key] >= 0., key)


if __name__ == '__main__':
    unittest.main()
