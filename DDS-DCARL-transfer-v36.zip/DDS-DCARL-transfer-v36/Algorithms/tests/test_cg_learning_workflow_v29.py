"""CG-baseline experiments never silently replace replay with long training."""
import contextlib
import csv
import io
import json
import math
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

try:
    from Tools import run_cg_learning_validation_v29 as workflow
except ImportError:
    workflow=None


class CGLearningWorkflowTests(unittest.TestCase):
    def require_workflow(self):
        self.assertIsNotNone(workflow,'No CG vs frozen GTRL workflow')

    def test_replay_plan_has_four_smoke_and_sixty_main_comparison_episodes(self):
        self.require_workflow()
        stages=workflow.build_plan(Path('output'),replay_source=Path('source.json'))
        self.assertEqual([s['name'] for s in stages],['00_smoke','01_rebuild','02_eval'])
        self.assertEqual([s['episodes_total'] for s in stages],[4,0,60])
        self.assertEqual(stages[0]['arms'],['M6_matrix_v18','U0_cg_observe_v29'])
        self.assertEqual(stages[-1]['arms'],['M6_matrix_v18','U2_cg_eval_v29'])
        self.assertEqual(stages[-1]['seeds'],[121,122,123])
        self.assertEqual(stages[1]['tool'],'rebuild_cg_learning_v29.py')
        self.assertEqual(stages[1]['arguments'][0],'source.json')
        self.assertNotIn('T1_fixed_v24',','.join(str(s) for s in stages))

    def test_fresh_training_requires_an_explicit_mode_and_has_164_episodes(self):
        self.require_workflow()
        stages=workflow.build_plan(Path('output'),fresh_train=True)
        self.assertEqual([s['episodes_total'] for s in stages],[4,100,60])
        self.assertEqual(stages[1]['arms'],['U1_cg_train_v29'])
        self.assertEqual(stages[1]['seeds'],[111])
        args=stages[-1]['arguments']
        checkpoint=args[args.index('--rolling-checkpoint')+1]
        self.assertTrue(checkpoint.replace('\\','/').endswith('01_train/U1_cg_train_v29_seed111/rolling_model/rolling_model.json'))

    def test_dry_run_does_not_require_replay_data_or_create_output(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)/'not_created';capture=io.StringIO()
            with contextlib.redirect_stdout(capture):
                self.assertEqual(workflow.main(['--dry-run','--output-root',str(output)]),0)
            rows=[json.loads(line) for line in capture.getvalue().splitlines()]
            self.assertEqual(sum(r['episodes_total'] for r in rows),64)
            self.assertFalse(output.exists())

    def test_missing_replay_source_fails_before_a_simulator_child_is_launched(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)/'not_created';missing=Path(tmp)/'missing.json'
            with patch.object(workflow,'DEFAULT_REPLAY_SOURCE',missing):
                with patch.object(workflow.subprocess,'run',side_effect=AssertionError('Unexpected CARLA child')):
                    with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
                        workflow.main(['--output-root',str(output)])
            self.assertFalse(output.exists())

    def test_failed_child_archives_partial_work_and_preserves_source_model(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'old.json';source.write_text('{"source_model":true}',encoding='utf8')
            before=source.read_bytes();output=Path(tmp)/'partial'
            with patch.object(workflow.subprocess,'run',return_value=S(returncode=3)):
                with contextlib.redirect_stdout(io.StringIO()):
                    code=workflow.main(['--replay-source',str(source),'--output-root',str(output)])
            self.assertEqual(code,3)
            self.assertEqual(source.read_bytes(),before)
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())
            state=json.loads((output/'WORKFLOW.json').read_text(encoding='utf8'))
            self.assertFalse(state['overall_success'])
            self.assertEqual(state['planned_episodes'],64)
            self.assertEqual(state['mode'],'offline_rebuild_then_frozen_eval')

    def test_observe_identity_uses_new_arm_and_seed_and_detects_changed_controls(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);stage=workflow.build_plan(root)[0]
            values=dict.fromkeys(workflow.PHYSICAL_FIELDS,'0');values.update(episode='1',frame='1')
            for arm in ('M6_matrix_v18','U0_cg_observe_v29'):
                directory=root/'00_smoke'/(arm+'_seed110');directory.mkdir(parents=True)
                self.write_csv(directory/'interaction_ego.csv',[values])
            self.assertTrue(workflow.identity(root,stage)['ok'])
            values['a_cmd']='1'
            self.write_csv(root/'00_smoke/U0_cg_observe_v29_seed110/interaction_ego.csv',[values])
            self.assertFalse(workflow.identity(root,stage)['ok'])

    @staticmethod
    def write_csv(path,rows):
        with path.open('w',newline='',encoding='utf8') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader();writer.writerows(rows)

    def test_zero_takeover_and_a_driving_collision_do_not_mean_failed_data_collection(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            all_stages=workflow.build_plan(root,eval_episodes=1,eval_seeds=[121],smoke_episodes=1)
            stages=[all_stages[0],all_stages[-1]]
            for stage in stages:
                parent=root/stage['name'];parent.mkdir()
                runs=[]
                for arm in stage['arms']:
                    seed=stage['seeds'][0];directory=parent/('%s_seed%d'%(arm,seed));directory.mkdir()
                    result=dict(complete=True,ego_log_complete=True)
                    if arm.startswith('U'):
                        result.update(rolling_counts=dict(rows=1,takeovers=0),rolling_actual_actions={'0':1})
                    (directory/'result.json').write_text(json.dumps(result),encoding='utf8')
                    values=dict.fromkeys(workflow.PHYSICAL_FIELDS,'0')
                    values.update(episode='1',frame='1',ego_v='1',ego_v_after='1',guard_selected_gap='2',
                                  goal_remaining='20',ego_acc_measured='0',wait_standoff='2',mpc_l='0')
                    self.write_csv(directory/'interaction_ego.csv',[values])
                    outcome='collision' if arm=='U2_cg_eval_v29' else 'complete'
                    self.write_csv(directory/'interaction_summary.csv',[dict(episode='1',frames='1',outcome=outcome)])
                    self.write_csv(directory/'traffic_spacing_samples.csv',[dict(episode='1',commanded_acceleration='-.5')])
                    runs.append(dict(arm=arm,seed=seed,status='complete'))
                (parent/'manifest.json').write_text(json.dumps(dict(runs=runs,overall_success=True,
                    collection_finished=True)),encoding='utf8')
            # Runtime geometry itself is checked by its separate audit tests.
            with patch.object(workflow,'inspect_runtime',return_value=dict(ok=True,errors={})): 
                report=workflow.collect_report(root,stages)
            self.assertTrue(report['collection_ok'])
            self.assertIn('learned_takeover_requested',report,'Takeover requests and executed actions are not separated')
            self.assertFalse(report['learned_takeover_requested'])
            self.assertFalse(report['frozen_nonzero_action_executed'])
            self.assertFalse(report['benefit_established'])
            treatment=report['stages'][-1]['arms']['U2_cg_eval_v29']
            self.assertEqual(treatment['collisions'],1)
            self.assertEqual(treatment['success'],0)
            self.assertEqual(treatment['background_braking']['commanded_braking_actor_s'],.05)
            self.assertEqual(report['comparison']['pairs'][0]['measured_acceleration_rms_delta'],0.)
            self.assertIsNone(report['comparison']['pairs'][0]['measured_jerk_rms_delta'])
            self.assertEqual(report['comparison']['pairs'][0]['background_harsh_braking_actor_time_ratio_delta'],0.)
            result_path=root/'02_eval/U2_cg_eval_v29_seed121/result.json'
            requested=json.loads(result_path.read_text(encoding='utf8'))
            requested['rolling_counts']['takeovers']=1
            result_path.write_text(json.dumps(requested),encoding='utf8')
            with patch.object(workflow,'inspect_runtime',return_value=dict(ok=True,errors={})):
                retracted=workflow.collect_report(root,stages)
            self.assertTrue(retracted['learned_takeover_requested'])
            self.assertFalse(retracted['frozen_nonzero_action_executed'])
            requested['rolling_actual_actions']={'1':1}
            result_path.write_text(json.dumps(requested),encoding='utf8')
            with patch.object(workflow,'inspect_runtime',return_value=dict(ok=True,errors={})):
                executed=workflow.collect_report(root,stages)
            self.assertTrue(executed['frozen_nonzero_action_executed'])
            self.assertEqual(executed['frozen_nonzero_action_frames'],1)

    def test_offline_audit_must_prove_convergence_and_unchanged_real_evidence(self):
        self.require_workflow()
        from Planning_library.rolling_learning_v24 import RollingLearner
        from Tools.rebuild_cg_learning_v29 import rebuild
        learner=RollingLearner();context=[0.]*16;beta=dict(alpha=1.,beta=1.)
        key=learner.begin(context,beta,0,[0,1],[0.]*6,1)
        record=dict(state=key,action=0,episode=1,context=context,beta=beta,reward=0.,
                    discount=learner.gamma,steps=1,interventions=0,next=None)
        data=dict(signature=learner.signature(),nodes=learner.nodes,records=[record],q={key:[0.]*6})
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'old.json';source.write_text(json.dumps(data),encoding='utf8')
            stage=workflow.build_plan(root,replay_source=source)[1]
            audit=rebuild(source,stage['checkpoint'],stage['audit'])
            stage['returncode']=0
            self.assertTrue(workflow._offline_report(stage)['collection_ok'])
            for field,value in [('bellman_converged',False),('bellman_residual',.1),
                                ('real_episode_count',100),('synthetic_transition_records',1),
                                ('source_unchanged',False),('source_sha256','wrong')]:
                changed=dict(audit);changed[field]=value
                Path(stage['audit']).write_text(json.dumps(changed),encoding='utf8')
                with self.subTest(field=field):
                    self.assertFalse(workflow._offline_report(stage)['collection_ok'])

    def test_motion_metrics_do_not_cross_episode_boundaries_or_fill_missing_acceleration_with_zero(self):
        self.require_workflow()
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp)/'U2_cg_eval_v29_seed121';directory.mkdir()
            self.write_csv(directory/'interaction_ego.csv',[
                dict(episode='1',ego_acc_measured='0'),dict(episode='1',ego_acc_measured='1'),
                dict(episode='2',ego_acc_measured='10'),dict(episode='2',ego_acc_measured='10'),
                dict(episode='3',ego_acc_measured=''),dict(episode='3',ego_acc_measured='1')])
            self.write_csv(directory/'traffic_spacing_samples.csv',[
                dict(commanded_acceleration='-4'),dict(commanded_acceleration='0')])
            group=dict(episodes=[dict(seed=121,episode=1),dict(seed=121,episode=2),dict(seed=121,episode=3)])
            workflow._supplement(group,[directory])
            first,second,missing=group['episodes']
            self.assertIn('measured_acceleration_rms',first,'Measured comfort metrics were not computed')
            self.assertAlmostEqual(first['measured_acceleration_rms'],math.sqrt(.5))
            self.assertEqual(first['measured_jerk_rms'],20.)
            self.assertEqual(second['measured_acceleration_rms'],10.)
            self.assertEqual(second['measured_jerk_rms'],0.)
            self.assertIsNone(missing['measured_acceleration_rms'])
            self.assertIsNone(missing['measured_jerk_rms'])
            self.assertEqual(missing['measured_acceleration_missing_rows'],1)
            self.assertEqual(group['measured_motion_missing_episodes'],1)
            self.assertEqual(group['background_braking']['sample_actor_s'],.1)
            self.assertEqual(group['background_braking']['harsh_braking_actor_time_ratio'],.5)
            self.assertEqual(group['background_braking']['harsh_braking_actor_s_per_100_actor_s'],50.)


if __name__=='__main__':unittest.main()
