#!/usr/bin/env python3
"""【P0-step0 验证】折线连续投影的单元测试（纯 numpy，无 CARLA）。

被验证的假设：
  `arc_to_cross` 现在是"最近**路点**下标 × 路点间距（=2.045 m）"，因为参考路径是
  `dense_polyline2d(ref_path_ori, 2)` 按 2 m 加密的。于是弧长被**量化**，亚米级的
  安全判断（停止线/回退位/清空时间）建立在一个 2 m 量化的坐标上。
  `project_point_on_polyline` 把点投到**线段**上并插值，弧长连续。

本文件只验证几何正确性，不涉及任何阈值改动。
"""
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.gap_analysis import (
    polyline_cumlen, project_point_on_polyline, PATH_RESOLUTION_M,
)


def _line(n=11, step=2.0):
    """沿 +x 的直线折线：x = 0, 2, 4, ..., 20（模拟 2 m 加密的参考路径）。"""
    return np.array([[i * step, 0.0] for i in range(n)], dtype=float)


class TestPolylineCumlen(unittest.TestCase):

    def test_straight_line(self):
        s = polyline_cumlen(_line(11, 2.0))
        np.testing.assert_allclose(s, np.arange(11) * 2.0)

    def test_degenerate_inputs(self):
        self.assertEqual(len(polyline_cumlen([])), 0)
        self.assertEqual(list(polyline_cumlen([[1.0, 2.0]])), [0.0])

    def test_default_resolution_matches_project_densification(self):
        # 参考路径按 2 m 加密 -> 本常量必须与之一致，否则"量化步长"的说法就错了
        self.assertAlmostEqual(PATH_RESOLUTION_M, 2.0)


class TestProjectPoint(unittest.TestCase):

    def test_point_on_vertex(self):
        p = _line()
        r = project_point_on_polyline(p, 4.0, 0.0)
        self.assertAlmostEqual(r['s'], 4.0, places=9)
        self.assertAlmostEqual(r['lat'], 0.0, places=9)
        self.assertTrue(r['ok'])

    def test_point_mid_segment_is_continuous(self):
        """关键：点落在两个路点**之间**时，弧长必须连续（旧法只能给到路点）。"""
        p = _line()
        # x=3.0 在路点 2.0 与 4.0 之间 —— 旧法会给 2.0 或 4.0（步长 2.0）
        r = project_point_on_polyline(p, 3.0, 0.0)
        self.assertAlmostEqual(r['s'], 3.0, places=9, msg='连续投影应给出 3.0，而不是量化的 2.0/4.0')
        self.assertAlmostEqual(r['t'], 0.5, places=9)
        # 逐点扫描：s 必须关于 x 严格单调且斜率 1（旧法会是阶梯）
        xs = np.arange(0.0, 20.01, 0.1)
        ss = [project_point_on_polyline(p, float(x), 0.0)['s'] for x in xs]
        self.assertGreater(np.min(np.diff(ss)), 0.0, '连续投影的 s 必须严格单调')
        np.testing.assert_allclose(np.array(ss), xs, atol=1e-9,
                                   err_msg='直线上的弧长应精确等于 x')

    def test_lateral_offset(self):
        p = _line()
        r = project_point_on_polyline(p, 5.0, 3.5)
        self.assertAlmostEqual(r['lat'], 3.5, places=9, msg='垂距 = 横向偏差')
        self.assertAlmostEqual(r['s'], 5.0, places=9, msg='横向偏移不改变纵向弧长')

    def test_clamps_beyond_ends(self):
        p = _line(11, 2.0)          # x ∈ [0, 20]
        r0 = project_point_on_polyline(p, -5.0, 0.0)
        self.assertAlmostEqual(r0['s'], 0.0, places=9)
        self.assertAlmostEqual(r0['lat'], 5.0, places=9)
        r1 = project_point_on_polyline(p, 25.0, 0.0)
        self.assertAlmostEqual(r1['s'], 20.0, places=9)
        self.assertAlmostEqual(r1['lat'], 5.0, places=9)

    def test_quantization_gap_demonstrated(self):
        """把"旧法的量化误差"与"新法的连续性"直接并排证明一次。

        旧法：argmin |path - ego| 取最近路点 -> s 只能是 2.0 的整数倍。
        """
        p = _line(11, 2.0)
        max_err_old = 0.0
        max_err_new = 0.0
        for x in np.arange(0.0, 20.01, 0.05):
            exact = float(x)
            # 旧法
            idx = int(np.argmin(np.linalg.norm(p - np.array([x, 0.0]), axis=1)))
            s_old = float(polyline_cumlen(p)[idx])
            # 新法
            s_new = project_point_on_polyline(p, float(x), 0.0)['s']
            max_err_old = max(max_err_old, abs(s_old - exact))
            max_err_new = max(max_err_new, abs(s_new - exact))
        self.assertAlmostEqual(max_err_old, PATH_RESOLUTION_M / 2.0, places=6,
                               msg='旧法最大误差 = 半个路点间距（应为 1.0 m）')
        self.assertLess(max_err_new, 1e-9, msg='新法误差应为 0')

    def test_curved_path_arc_matches_analytic(self):
        """四分之一圆弧：连续投影的弧长应与解析弧长一致（验证不是只对直线成立）。"""
        R = 10.0
        ang = np.linspace(0.0, np.pi / 2, 200)
        p = np.stack([R * np.sin(ang), R * (1 - np.cos(ang))], axis=1)
        s = polyline_cumlen(p)
        # 取弧上一点 P(ang=π/4) 的坐标，投影回去应得到 R*π/4
        k = len(ang) // 2
        r = project_point_on_polyline(p, float(p[k, 0]), float(p[k, 1]), cumlen=s)
        self.assertAlmostEqual(r['s'], R * float(ang[k]), places=3)
        self.assertAlmostEqual(r['lat'], 0.0, places=6)

    def test_bad_input_is_safe(self):
        r = project_point_on_polyline([], 0.0, 0.0)
        self.assertFalse(r['ok'])
        r1 = project_point_on_polyline(np.array([[3.0, 4.0]]), 3.0, 4.0)
        self.assertTrue(r1['ok'])
        self.assertAlmostEqual(r1['s'], 0.0)
        self.assertAlmostEqual(r1['lat'], 0.0)


if __name__ == "__main__":
    unittest.main()
