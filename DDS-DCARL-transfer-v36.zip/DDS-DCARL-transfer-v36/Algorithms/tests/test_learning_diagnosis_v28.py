"""Offline grouping reports real episode coverage, never synthetic trust."""
import copy
import json
import unittest

try:
    from Tools.diagnose_rolling_learning_v28 import compare_abstractions
except ImportError:compare_abstractions=None
try:
    from Tools.diagnose_rolling_learning_v28 import realized_options
except ImportError:realized_options=None


def sample():
    keys=[json.dumps([[0]*16,[2,4],0,mask],separators=(',',':')) for mask in ([0,1],[0,1,2])]
    data=dict(nodes={k:dict(default=0,allowed=json.loads(k)[3]) for k in keys},records=[])
    # Two real action histories, in two eligibility contexts. Each action
    # has ten independent episodes; repetitions do not create more episodes.
    for ep in range(1,11):
        for key,action,reward in ((keys[0],0,1.),(keys[1],1,2.)):
            data['records'].append(dict(state=key,action=action,episode=ep,reward=reward,steps=10,next='next'))
    return data


class LearningDiagnosisTests(unittest.TestCase):
    def diagnose(self,data,cut=5):
        self.assertIsNotNone(compare_abstractions,'No explicit offline state-grouping comparison')
        return compare_abstractions(data,train_through_episode=cut)

    def test_mask_pooling_counts_observed_episode_overlap_without_claiming_benefit(self):
        data=sample(); before=copy.deepcopy(data); report=self.diagnose(data)
        self.assertEqual(report['full']['covered_comparisons'],0)
        self.assertEqual(report['without_available_set']['covered_comparisons'],1)
        self.assertFalse(report['production_changed']);self.assertFalse(report['exchangeability_established'])
        self.assertEqual(data,before)

    def test_repeated_frames_from_one_episode_never_become_ten_episode_support(self):
        data=sample()
        for r in data['records']:r['episode']=1
        self.assertEqual(self.diagnose(data)['without_available_set']['covered_comparisons'],0)

    def test_holdout_errors_use_only_earlier_episode_rewards(self):
        data=sample();k=next(iter(data['nodes']))
        for r in data['records']:
            if r['state']==k:r['reward']=1. if r['episode']<=5 else 4.
        report=self.diagnose(data)
        # Ten held-out records: five errors of 3 and five errors of 0.
        self.assertAlmostEqual(report['full']['holdout']['mean_squared_error'],4.5)
        self.assertEqual(report['full']['holdout']['predicted_records'],10)

    def actual_fixture(self):
        data=dict(signature=dict(gamma=.5),records=[
            dict(state='s0',next='s1',action=0,episode=1,steps=1,reward=.0015),
            dict(state='s1',next=None,action=1,episode=1,steps=1,reward=5.0015)])
        rows=[dict(episode='1',frame=str(i+1),sim_dt='.05',ego_v_after='2',a_cmd='0',
            ego_acc_signed=str(i%2),mpc_audit_override='0',guard_unavoidable='0') for i in range(4)]
        return data,rows,[dict(episode='1',frames='4',outcome='complete')]

    def test_realized_components_align_with_recorded_suffix_not_initial_inactive_frames(self):
        self.assertIsNotNone(realized_options,'No actual option/reward decomposition')
        report=realized_options(*self.actual_fixture())
        self.assertTrue(report['realized_reward_contract_ok'])
        self.assertEqual([(r['first_frame'],r['last_frame']) for r in report['options']],[(3,3),(4,4)])
        self.assertAlmostEqual(report['options'][1]['components']['terminal'],5.)
        self.assertAlmostEqual(report['options'][0]['metrics']['measured_jerk_integral'],.05)
        self.assertFalse(report['new_reward_applied'])

    def test_reward_mismatch_and_missing_frames_are_not_silently_accepted(self):
        self.assertIsNotNone(realized_options,'No reward mismatch diagnostic')
        data,rows,summaries=self.actual_fixture();data['records'][0]['reward']=99.
        self.assertFalse(realized_options(data,rows,summaries)['realized_reward_contract_ok'])
        with self.assertRaises(ValueError):realized_options(data,rows[:-1],summaries)


if __name__=='__main__':unittest.main()
