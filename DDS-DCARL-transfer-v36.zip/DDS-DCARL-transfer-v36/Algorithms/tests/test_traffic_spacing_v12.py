"""Measured spawn geometry and actual manager regressions; no CARLA required."""
import contextlib
import csv
import io
import json
import math
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

from Planning_library.traffic_spacing import FlowSpacing, box_bounds, spawn_clearance
from Tools.validate_traffic_spacing import validate_traffic_spacing
from Tools.run_traffic_spacing_probe import main as probe_main
from Tools.run_relay_validation import main as relay_main
from Tools import run_relay_validation as relay_module
from test_cross_traffic_manager import (load_module, DummyWorld, DummyMap, DummySpawnedVehicle,
                                       DummyBoundingBox, DummyVehicle)


class Logger:
    episode = 0
    def tick(self):
        pass
    def begin_episode(self, episode):
        self.episode = episode
    def last_ego(self):
        return None
    def rv_row(self, *args, **kwargs):
        pass
    def rv_decision(self, *args, **kwargs):
        pass


class MovingWorld(DummyWorld):
    def try_spawn_actor(self, bp, transform):
        actor = DummySpawnedVehicle(len(self._spawned)+1, transform)
        actor.bounding_box = DummyBoundingBox(length=4.2, offset=.25)
        self._spawned.append(actor)
        return actor
    def get_actors(self, ids=None):
        return [v for v in self._spawned if v.is_alive and (ids is None or v.id in ids)]
    def advance(self, dt=.05):
        for actor in self.get_actors():
            actor.transform.location.x += actor.velocity.x*dt
            actor.transform.location.y += actor.velocity.y*dt


def make_manager(output=None):
    module = load_module()
    world = MovingWorld()
    with patch.object(module, 'get_logger', return_value=Logger()):
        manager = module.CrossTrafficManager(world, DummyMap(), traffic_v=6.)
    manager._spacing_directory = None if output is None else str(output)
    manager._gap_after_count = 0
    manager.interactions_enabled = False
    return world, manager


class TestSpacingContract(unittest.TestCase):
    def test_old_birth_gap_defect_is_reproduced_and_corrected(self):
        spacing = FlowSpacing()
        old_gap=spacing.cruise_speed*1.45-3.6
        self.assertAlmostEqual(old_gap, 2.79743255498794)
        self.assertAlmostEqual(spacing.interval_seconds, 1.95)
        self.assertGreaterEqual(spacing.predicted_clear_gap, 5.)
        self.assertLess(spacing.predicted_clear_gap, 5.01)

    def test_density_length_and_interval_do_not_silently_change_cruise(self):
        configs = [FlowSpacing(clear_gap=g) for g in (4.5, 5., 6.)]
        configs.append(FlowSpacing(interval=2.2))
        self.assertEqual(len({c.cruise_speed for c in configs}), 1)
        speed = configs[0].cruise_speed
        configs[0].set_length(4.2, source='actor_bbox_world_vertices')
        self.assertEqual(configs[0].cruise_speed, speed)
        self.assertGreaterEqual(configs[0].predicted_clear_gap, 4.5)

    def test_bad_or_inconsistent_configuration_is_rejected(self):
        for kwargs in (dict(interval=1.45), dict(clear_gap=3.), dict(cruise_speed=math.nan),
                       dict(length=0.), dict(dt=math.inf), dict(clear_gap=-1.)):
            with self.assertRaises(ValueError):
                FlowSpacing(**kwargs)

    def test_world_vertices_preserve_offset_and_geometry(self):
        box = DummyBoundingBox(length=4.2, offset=.25)
        transform = S(location=S(x=20., y=-138.), rotation=S(yaw=180.))
        bounds = box_bounds(box.get_world_vertices(transform))
        self.assertAlmostEqual(bounds[0], 17.65)
        self.assertAlmostEqual(bounds[1], 21.85)
        gap, identity = spawn_clearance(bounds, [(7, (8.65, 12.85, -139., -137.))])
        self.assertAlmostEqual(gap, 4.8)
        self.assertEqual(identity, 7)
        self.assertLess(spawn_clearance(bounds, [(8, (18., 22., -139., -137.))])[0], 0.)
        self.assertEqual(spawn_clearance(bounds, [(9, (18., 22., -130., -128.))]), (None, None))


class TestProductionManager(unittest.TestCase):
    def test_spawn_does_not_read_pose_before_first_snapshot(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {}, clear=True), \
                contextlib.redirect_stdout(io.StringIO()):
            world, manager = make_manager(folder)
            spawn = world.try_spawn_actor
            def pending_spawn(bp, transform):
                actor = spawn(bp, transform)
                actor.get_transform = lambda: (_ for _ in ()).throw(
                    AssertionError('pose unavailable before the first normal tick'))
                return actor
            with patch.object(world, 'try_spawn_actor', side_effect=pending_spawn):
                actor = manager.spawn_one_vehicle()
            self.assertIsNotNone(actor)
            self.assertAlmostEqual(manager.veh_len, 4.2)
            del actor.get_transform
            world.advance()
            manager.run_step(DummyVehicle(6., -103.))
            with (Path(folder)/'traffic_spawns.csv').open(newline='', encoding='utf8') as stream:
                spawn_row = next(csv.DictReader(stream))
            with (Path(folder)/'traffic_spacing_samples.csv').open(newline='', encoding='utf8') as stream:
                observed_row = next(csv.DictReader(stream))
            self.assertEqual(spawn_row['pose_source'], 'requested_spawn_transform')
            self.assertNotIn('actual_clear_gap', spawn_row)
            self.assertEqual(observed_row['pose_source'], 'actor_snapshot')
            self.assertAlmostEqual(float(observed_row['x']), 20.-manager.rv_cruise_speed*.05)

    def test_first_actor_recalibrates_length_and_interval(self):
        with patch.dict(os.environ, {}, clear=True), contextlib.redirect_stdout(io.StringIO()):
            world, manager = make_manager()
            actor = manager.spawn_one_vehicle()
        self.assertIsNotNone(actor)
        self.assertAlmostEqual(manager.veh_len, 4.2)
        self.assertAlmostEqual(manager._spawn_interval, 2.1)
        self.assertEqual(manager.spacing.length_source, 'actor_bbox_world_vertices')

    def test_elapsed_time_cannot_spawn_inside_actual_front_gap(self):
        with patch.dict(os.environ, {}, clear=True), contextlib.redirect_stdout(io.StringIO()):
            world, manager = make_manager()
            actor = manager.spawn_one_vehicle()
            actor.transform.location.x = 11.  # 9 m centers, only 4.8 m actual bumper gap
            self.assertIsNone(manager.spawn_one_vehicle())
            self.assertEqual(manager._spawned_count, 1)
            actor.transform.location.x = 10.7
            self.assertIsNotNone(manager.spawn_one_vehicle())
            self.assertEqual(manager._spawned_count, 2)

    def test_delayed_or_stopped_front_vehicle_does_not_force_insertion(self):
        with patch.dict(os.environ, {}, clear=True), contextlib.redirect_stdout(io.StringIO()):
            world, manager = make_manager()
            manager._max_vehicles = 2
            manager.start_flow()
            ego = DummyVehicle(6., -103.)
            manager.run_step(ego)
            for _ in range(manager._spawn_interval_frames+20):
                manager.run_step(ego)  # deliberately do not advance the front actor
            self.assertEqual(manager._spawned_count, 1)

    def test_real_run_step_produces_stable_following_and_auditable_gaps(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {}, clear=True), \
                contextlib.redirect_stdout(io.StringIO()):
            world, manager = make_manager(folder)
            manager._max_vehicles = 6
            manager.ilog.begin_episode(1)
            manager.start_flow(trial=1)
            for _ in range(230):
                manager.run_step(DummyVehicle(6., -103.))
                world.advance()
            result = validate_traffic_spacing(folder, expected_spawns=6, expected_trials=[1], probe=True)
            self.assertTrue(result['traffic_spacing_contract_ok'], result)
            self.assertGreaterEqual(result['traffic_spawn_projected_clear_gaps']['min'], 5.)
            self.assertGreaterEqual(result['traffic_first_observed_clear_gaps']['min'], 5.)
            self.assertEqual(result['traffic_birth_follow_braking_rows'], 0)
            self.assertEqual(result['traffic_overlap_rows'], 0)
            self.assertGreater(result['traffic_sample_rows'], 300)
            self.assertGreater(result['traffic_conflict_clear_gaps']['min'], 5.)
            path = Path(folder)/'traffic_spawns.csv'
            with path.open(encoding='utf8', newline='') as stream:
                rows = list(csv.DictReader(stream))
            next(r for r in rows if r.get('leader_id'))['projected_clear_gap'] = '2.8'
            with path.open('w', encoding='utf8', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
            self.assertFalse(validate_traffic_spacing(folder)['traffic_spacing_contract_ok'])


class FakeProbeEnvironment:
    dt = .05
    def __init__(self):
        self.world, self.cross_traffic = make_manager(os.environ['DSH_SAVE_DIR'])
        self.cleaned = False
    def reset(self, train):
        self.cross_traffic.reset()
    def step(self, action, target_speed):
        self.cross_traffic.run_step(DummyVehicle(6., -103.))
        self.world.advance()
        frame = self.cross_traffic._spawn_frame
        self.last_control = dict(ego_v_after=0., control_submit_ok=1,
                                 control_tick_frame=frame, sim_frame_after=frame)
        return None, None, False, None
    def cleanup(self):
        self.cross_traffic.reset()
        self.cleaned = True


class TestProbeAndRunner(unittest.TestCase):
    def test_quality_warnings_do_not_masquerade_as_interface_failure_or_get_erased(self):
        row = dict(control_profile='paper_v11', feasibility_phase='approach', feasibility_safe='1',
            mpc_audit_override='0', mpc_prediction_horizon='2.3', rl_active='0', mpc_l='.1')
        summary = dict(complete=True, outcomes={'complete': 1}, execution_contract_ok=True, game_contract_ok=True)
        health = dict(actuator_contract_ok=True, severe_deceleration_rows=1, severe_acceleration_rows=1)
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()), \
                patch.object(relay_module.subprocess, 'run', return_value=S(returncode=0)), \
                patch.object(relay_module, 'summarize', side_effect=lambda *a, **kw: dict(summary)), \
                patch.object(relay_module, '_read_rows', return_value=[row]), \
                patch.object(relay_module, 'validate_control_health', return_value=health), \
                patch.object(relay_module, 'validate_traffic_spacing', return_value={'traffic_spacing_contract_ok': True}):
            output=Path(folder)/'runs'
            code=relay_main(['--output-root',str(output),'--episodes','1'])
            result=json.loads((output/'B0_rule_seed1/result.json').read_text())
        self.assertEqual(code,0)
        self.assertEqual(set(result['control_quality_warnings']),{'severe_acceleration','severe_deceleration'})
        self.assertEqual(result['evaluation_scope'],'exploratory_traffic')
        self.assertEqual(result['severe_acceleration_rows'],1)

    def test_standalone_probe_collects_all_trials_and_cleans_up(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {}, clear=True), \
                contextlib.redirect_stdout(io.StringIO()):
            output = Path(folder)/'probe'
            code = probe_main(['--output-root', str(output), '--trials', '2', '--seconds', '5',
                               '--vehicles', '2'], env_factory=FakeProbeEnvironment)
            result = json.loads((output/'result.json').read_text())
        self.assertEqual(code, 0, result)
        self.assertEqual(result['traffic_spawn_count'], 4)
        self.assertFalse(result['mpc_used'])
        self.assertFalse(result['traffic_interactions_enabled'])

    def test_probe_exception_is_preserved_as_failed_result(self):
        class Broken(FakeProbeEnvironment):
            def step(self, *args, **kwargs):
                super().step(*args, **kwargs)
                raise RuntimeError('recorded simulator disconnect')
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {}, clear=True), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            output = Path(folder)/'probe'
            code = probe_main(['--output-root', str(output), '--trials', '1', '--seconds', '5',
                               '--vehicles', '2'], env_factory=Broken)
            result = json.loads((output/'result.json').read_text())
        self.assertEqual(code, 7)
        self.assertIn('recorded simulator disconnect', result['error'])
        self.assertFalse(result['probe_collection_ok'])

    def test_pair_gets_same_gap_and_cruise_and_retains_v11_ego_control(self):
        with contextlib.redirect_stdout(io.StringIO()) as stream:
            self.assertEqual(relay_main(['--dry-run', '--traffic-clear-gap', '5']), 0)
        configs = [json.loads(line)['effective'] for line in stream.getvalue().splitlines()]
        self.assertEqual({k for k in configs[0] if configs[0][k] != configs[1][k]},
                         {'DSH_METHOD', 'DSH_TAKE_COURNOT'})
        self.assertTrue(all(c['DSH_TRAFFIC_CLEAR_GAP']=='5.0' and c['DSH_CONTROL_PROFILE']=='paper_v11'
                            and c['DSH_EFE']=='0' for c in configs))


if __name__ == '__main__':
    unittest.main()
