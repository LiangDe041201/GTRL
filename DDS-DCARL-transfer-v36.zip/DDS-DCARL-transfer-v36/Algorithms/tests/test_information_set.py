# -*- coding: utf-8 -*-
"""式(11)(12)(13)(14)(15)(16)(17) 的语义回归测试。

这些测试的作用：把论文 §III.A 信息建模的**可检验命题**锁死，
避免再出现"注释写了式9/式17、实际只是把参数回传进 dict"的假实现（PLAN §30）。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Planning_library.information_set import (          # noqa: E402
    InformationSetTracker, HistoryPath, ParticipantStep,
    TYPE_SPACE, TYPE_PRIOR, with_beta)


# ============================================================
# 式(9)：β 进状态第 6 维
# ============================================================
def test_beta_enters_state_sixth_dim():
    """式(9) s_i = [x,y,v,acc,φ,**β**] —— β 必须是状态的一维，不是无人读的 dict 键。"""
    st = (0.1, 0.2, 6.0, 0.5, 0.3)          # 改造前的 5 维状态
    out = with_beta(st, 0.7)
    assert len(out) == 6, out
    assert abs(out[5] - 0.7) < 1e-12, out
    assert out[:5] == st, '前 5 维必须原样保留'


# ============================================================
# 式(17)：类型空间是共同知识
# ============================================================
def test_type_space_is_common_knowledge():
    """式(17)：Θ 与先验是公开的；先验归一。"""
    assert len(TYPE_SPACE) == 3
    assert abs(sum(TYPE_PRIOR.values()) - 1.0) < 1e-12
    t = InformationSetTracker()
    assert t.type_prior == TYPE_PRIOR, '实例先验必须等于共同知识先验'


# ============================================================
# 式(12)：历史路径 p_t
# ============================================================
def test_history_path_is_ordered_joint_actions():
    """式(12) p_t = (a_0, …, a_{t-1})：按帧序的**联合**动作，不含第 t 步本身。"""
    h = HistoryPath()
    h.reset(3)
    h.append(3, 0, {0: 'go', 1: 'rush'})
    h.append(3, 1, {0: 'wait', 1: 'yield'})
    h.append(3, 2, {0: 'go', 1: 'rush'})
    p2 = h.up_to(2)
    assert len(p2) == 2, p2                       # 严格早于 t=2 ⇒ 只有 a_0, a_1
    assert p2[0] == {0: 'go', 1: 'rush'}
    assert p2[1] == {0: 'wait', 1: 'yield'}
    assert h.actions_of(0) == ('go', 'wait', 'go')
    assert h.actions_of(1, step=2) == ('rush', 'yield')


def test_history_path_separates_episodes():
    """历史路径必须能界定一条路径的边界（经验池做不到，见 PLAN §30.2）。

    两个性质：(a) 用 `(episode, step)` 双键索引，不同回合的动作不会互相混入；
    (b) `reset()` 清空 —— 回合之间**不污染**（经验池是跨回合累积的，这正是它的缺陷）。
    """
    h = HistoryPath()
    # (a) 不 reset，直接按不同 episode 写入 ⇒ 查询能按回合分离
    h.episode = 1
    h.append(1, 0, {0: 'go'})
    h.append(1, 1, {0: 'wait'})
    h.append(2, 0, {0: 'go', 1: 'rush'})
    assert h.up_to(9, episode=1) == ({0: 'go'}, {0: 'wait'}), h.up_to(9, episode=1)
    assert h.up_to(9, episode=2) == ({0: 'go', 1: 'rush'},), h.up_to(9, episode=2)
    assert h.up_to(1, episode=1) == ({0: 'go'},), '严格早于 step=1 ⇒ 只有 a_0'
    # (b) reset 清空 ⇒ 新回合不带上一回合的历史
    h.reset(3)
    assert len(h) == 0, 'reset 后历史必须清空（否则就是经验池那种跨回合污染）'
    h.append(3, 0, {0: 'wait'})
    assert h.up_to(9, episode=1) == (), '新回合不该再查得到旧回合的动作'
    assert h.up_to(9, episode=3) == ({0: 'wait'},)


# ============================================================
# 式(11)：信息集 = 全体参与者的历史状态 + 效用序列
# ============================================================
def test_info_set_covers_all_participants_states_and_utilities():
    """式(11)：I_i 含**所有**参与者的 s 序列与 U 序列（不是单帧特征包）。"""
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1))
    t.observe(0, 0, (5.0, -120.0, 6.0, 0.0, 0.0), 'go', 1.5)
    t.observe(0, 1, (30.0, -138.0, 10.0, 0.0, 0.0), 'rush', -1.5)
    t.observe(1, 0, (5.5, -126.0, 6.0, 0.0, 0.0), 'go', 2.0)
    t.observe(1, 1, (20.0, -138.0, 9.0, 0.0, 0.0), 'yield', 0.5)
    t.append_joint_action(0, {0: 'go', 1: 'rush'})
    t.append_joint_action(1, {0: 'go', 1: 'yield'})

    I = t.info_set(0)
    assert set(I['states'].keys()) == {0, 1}, I['states'].keys()
    assert set(I['utilities'].keys()) == {0, 1}
    assert len(I['states'][1]) == 2, '对手的状态序列必须有 2 步'
    assert I['utilities'][1] == (-1.5, 0.5)
    assert len(I['history_path']) == 2, 'p_t 是联合动作序列'
    # "只含 3 辆车、每帧现造、无历史"的旧实现无法产生上面的长度 2


# ============================================================
# 式(13)(14)(15)(16)：信息集的基数与博弈性质
# ============================================================
def test_formula_14_initial_cardinality_exceeds_one():
    """式(14) |I_{i,0}| > 1：t=0 无历史、对 a_{-i} 不确定 ⇒ 基数 = |Θ| > 1。"""
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1))
    t.set_private_type(1, 0.5)
    assert t.initial_cardinality() == len(TYPE_SPACE) > 1


def test_formula_13_16_perfect_vs_imperfect():
    """式(13) 完美信息（基数恒 1）与式(16) 不完全信息（存在基数 > 1）互斥。

    注意 `|I_{i,t}|` 的口径：**自车知道自己的私有类型 β_0**（式17），
    所以不确定性只来自**别人**。因此查自车的信息集用 `cardinality(0)`。
    """
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1))
    # 未观测到任何东西 ⇒ 对手类型全可能 ⇒ |I_{0,t}| = |Θ| > 1 ⇒ 不完全信息
    assert t.cardinality(0) == len(TYPE_SPACE)
    assert t.is_imperfect() is True                     # 式(16) 成立
    assert t.is_perfect_information() is False           # 式(13) 不成立
    assert t.has_distinct_histories(0) is True           # 式(15) 成立
    # 观测把后验收敛到单一类型 ⇒ 自车信息集基数 1 ⇒ 变成完美信息
    t.set_posterior(1, {'normal': 1.0})
    assert t.cardinality(0) == 1
    assert t.is_perfect_information() is True            # 式(13) 成立
    assert t.has_distinct_histories(0) is False


def test_cardinality_counts_only_consistent_types():
    """式(15)：只有与观测**相容**（后验 > eps）的类型才算进 |I_{i,t}|。"""
    t = InformationSetTracker(consistency_eps=0.05)
    t.reset(1, participants=(0, 1))
    t.set_posterior(1, {'conservative': 0.02, 'normal': 0.48, 'aggressive': 0.50})
    assert t.cardinality(0) == 2, t.cardinality(0)       # 0.02 被剔除 ⇒ 剩 2 个
    t.set_posterior(1, {'conservative': 0.001, 'normal': 0.5, 'aggressive': 0.499})
    assert t.cardinality(0) == 2
    t.set_posterior(1, {'normal': 1.0})
    assert t.cardinality(0) == 1
    # 自车信息集 = Π_{j≠0} (#仍可能的 β_j)；自车自己的 β 不贡献不确定性
    assert t.cardinality(1) == 1, '自车知道自己类型 ⇒ 对手视角下自车类型唯一'


def test_cardinality_is_product_over_others():
    """式(11)(16)：多对手时 `|I_{i,t}|` 是"别人类型的联合组合数"（乘积）。"""
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1, 2))
    # 两个对手各 3 种可能 ⇒ 自车信息集 9 条不相容历史
    assert t.cardinality(0) == len(TYPE_SPACE) ** 2, t.cardinality(0)
    t.set_posterior(1, {'normal': 1.0})                 # 对手1 确定
    assert t.cardinality(0) == len(TYPE_SPACE), t.cardinality(0)
    t.set_posterior(2, {'aggressive': 1.0})             # 对手2 也确定
    assert t.cardinality(0) == 1


def test_formula_17_private_type_per_participant():
    """式(17)：`∀i_1..i_k, Θ_{i_k} ∈ I_{i_1}` —— 每个参与者有**自己的**私有类型。"""
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1, 2))
    t.set_private_type(0, 0.4)
    t.set_private_type(1, 0.8)
    t.set_private_type(2, 0.2)
    s = t.info_state()
    assert s['private_types'] == {0: 0.4, 1: 0.8, 2: 0.2}, s['private_types']
    assert s['n_participants'] == 3, '旧实现只含 3 辆车(ego/rv/fv)且无逐参与者类型'


def test_info_state_snapshot_is_serialisable():
    """info_state() 必须可 JSON 序列化（要进日志），且能判定 (13)(14)(16)。"""
    import json
    t = InformationSetTracker()
    t.reset(7, participants=(0, 1))
    t.set_private_type(1, 0.5)
    t.set_posterior(1, {'normal': 0.6, 'aggressive': 0.4})
    t.observe(0, 0, (1.0, 2.0, 3.0, 0.0, 0.1, 0.9), 'go', 1.0)
    t.append_joint_action(0, {0: 'go', 1: 'rush'})
    s = t.info_state()
    json.dumps(s)                                        # 不抛异常即通过
    assert s['episode'] == 7
    assert s['history_len'] == 1
    assert s['initial_cardinality'] == 3
    assert s['imperfect'] is True and s['perfect'] is False


def test_reset_clears_previous_episode():
    t = InformationSetTracker()
    t.reset(1, participants=(0, 1))
    t.set_posterior(1, {'normal': 1.0})
    t.observe(0, 0, (0, 0, 0, 0, 0, 0.5), 'go', 0.0)
    t.reset(2, participants=(0, 1))
    # 自车信息集 = 对手类型的不确定性 ⇒ reset 后必须回到 |Θ|
    assert t.cardinality(0) == len(TYPE_SPACE), 'reset 后后验必须清空'
    assert t.info_set(0)['states'][0] == (), 'reset 后状态序列必须清空'
    assert len(t.history) == 0


def test_participant_step_tuple():
    r = ParticipantStep(3, 'rv', (1.0, 2.0), 'yield', -0.5)
    assert r.as_tuple() == (3, 'rv', (1.0, 2.0), 'yield', -0.5)


if __name__ == '__main__':
    fns = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in fns:
        fn()
        print('ok  %s' % fn.__name__)
    print('\nALL %d PASSED' % len(fns))
