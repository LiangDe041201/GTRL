"""Realized-action Bellman updates and episode-based trust for rolling paths."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np

from Planning_library.soft_bellman import soft_value_policy

try:
    from Planning_library.rolling_learning_v24 import RollingLearner
except ImportError:
    RollingLearner=None


class RollingLearningTests(unittest.TestCase):
    def learner(self,**kw):
        self.assertIsNotNone(RollingLearner,'Local trajectory selection is not connected to learning')
        return RollingLearner(**kw)

    def begin(self,l,episode,context=None,allowed=(0,4)):
        return l.begin([0.]*16 if context is None else context,dict(alpha=1.,beta=1.),
                       0,allowed,[0.]*6,episode)

    def terminal(self,l,episode,action,reward):
        self.begin(l,episode); l.start(action); l.reward(reward); l.finish()

    def test_two_step_value_uses_realized_next_state_and_terminal_does_not_bootstrap(self):
        l=self.learner(gamma=.5)
        a=self.begin(l,1); l.start(4); l.reward(1.)
        b=self.begin(l,1,[30.]+[0.]*15,(0,)); l.start(0); l.reward(2.); l.finish()
        self.assertAlmostEqual(l.q[b][0],2.,places=8)
        self.assertAlmostEqual(l.q[a][4],2.,places=8)
        self.assertEqual(l.records[0]['next'],b)
        self.assertIsNone(l.records[-1]['next'])

    def test_twenty_correlated_options_in_one_episode_do_not_become_twenty_samples(self):
        l=self.learner(min_episodes=2)
        for _ in range(20): self.terminal(l,1,4,3.)
        self.begin(l,1)
        self.assertEqual(l.bounds(4)['n'],1)
        self.assertEqual(l.choose(epsilon=0.),0)
        self.assertFalse(l.last['certified'])

    def test_choose_only_evaluates_distinct_successors_of_the_current_state(self):
        l=self.learner()
        root=self.begin(l,1)
        for action in (0,4):
            self.begin(l,1); l.start(action); l.reward(1.)
            self.begin(l,1,[12.]+[0.]*15)
        for offset in (24.,36.,48.):
            self.begin(l,1,[offset]+[0.]*15)
        l.current=root
        with patch('Planning_library.rolling_learning_v24.soft_value_policy',wraps=soft_value_policy) as soft:
            self.assertEqual(l.choose(),0)
        self.assertEqual(soft.call_count,1)
        self.assertEqual([l.last['bounds'][a]['n'] for a in ('0','4')],[1,1])

    def test_synchronous_sweep_averages_episodes_before_actions(self):
        l=self.learner(gamma=.5)
        root=self.begin(l,1)
        l.start(4); l.reward(2.)
        successor=self.begin(l,1,[12.]+[0.]*15)
        l.start(0); l.reward(4.); l.finish()
        self.terminal(l,1,4,6.)
        self.terminal(l,2,4,10.)
        l.q[successor][:]=[2.,0.,0.,0.,1.,0.]
        value=soft_value_policy(l.q[successor],l.nodes[successor]['prior'],l.alpha)[0]
        expected=(((2.+.5*value)+6.)/2.+10.)/2.
        with patch('Planning_library.rolling_learning_v24.soft_value_policy',wraps=soft_value_policy) as soft:
            l.iterate(1)
        self.assertEqual(soft.call_count,0)
        self.assertAlmostEqual(l.q[root][4],expected,places=12)
        self.assertEqual(l.q[successor][0],4.)

    def test_supported_better_action_can_take_over_without_forced_control(self):
        l=self.learner(min_episodes=10)
        for ep in range(1,11):
            self.terminal(l,ep,0,0.); self.terminal(l,ep,4,3.)
        self.begin(l,11)
        self.assertEqual(l.choose(epsilon=0.),4)
        self.assertEqual(l.last['source'],'takeover')
        self.assertGreater(l.last['bounds']['4']['wcv'],l.last['bounds']['0']['bcv'])

    def test_only_actual_started_action_receives_the_real_reward(self):
        l=self.learner(); self.begin(l,1)
        l.choose(epsilon=1.,rng=np.random.RandomState(3))
        l.start(0); l.reward(2.,intervention=True); l.finish()
        self.assertEqual(l.records[0]['action'],0)
        self.assertEqual(l.records[0]['interventions'],1)
        self.assertEqual(l.q[l.records[0]['state']][4],0.)

    def test_frozen_evaluation_never_updates_or_saves_a_model(self):
        l=self.learner(); self.terminal(l,1,0,1.)
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'rolling_model.json'; l.save(p)
            before=hashlib.sha256(p.read_bytes()).hexdigest()
            e=self.learner(phase='eval',checkpoint=p)
            values={k:v.copy() for k,v in e.q.items()}; count=len(e.records)
            self.begin(e,2); e.choose(); e.start(0); e.reward(-10.); e.finish()
            self.assertEqual(len(e.records),count)
            for k,v in values.items(): np.testing.assert_array_equal(e.q[k],v)
            with self.assertRaises(ValueError): e.save(p)
            self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),before)

    def test_legacy_speed_ratio_checkpoint_and_nonfinite_rewards_are_rejected(self):
        l=self.learner(); self.begin(l,1); l.start(0)
        with self.assertRaises(ValueError): l.reward(float('nan'))
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'old.json'; p.write_text(json.dumps(dict(signature=dict(schema='trajectory_parameter_evolution_v22'))))
            with self.assertRaises(ValueError): self.learner(phase='eval',checkpoint=p)


if __name__=='__main__': unittest.main()
