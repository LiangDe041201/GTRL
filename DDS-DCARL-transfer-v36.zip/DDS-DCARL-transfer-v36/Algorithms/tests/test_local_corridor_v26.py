"""Road checks keep their body margin without runtime simulator point calls."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from Planning_library.road_corridor_v24 import RoadCorridorV24
from test_local_road_v26 import road,xodr

try:
    from Planning_library.local_corridor_v26 import LocalRoadCorridorV26
except ImportError:
    LocalRoadCorridorV26=None


class PublicMap:
    name='synthetic_line'
    def __init__(self): self.queries=0; self.exports=0; self.closed=False
    def get_waypoint(self,location,project_to_road,lane_type):
        if self.closed: raise AssertionError('Runtime CARLA map call')
        if project_to_road: raise AssertionError('Offroad projection')
        self.queries+=1
        if 0.<=location.x<=20. and 0.<=location.y<=4.:
            return SimpleNamespace(road_id=1,section_id=0,lane_id=-1,is_junction=False,lane_width=4.)
        return None
    def to_opendrive(self):
        if self.closed: raise AssertionError('Map re-exported during decision')
        self.exports+=1
        return xodr(road())


class LocalCorridorTests(unittest.TestCase):
    def setup_corridor(self,directory=None):
        self.assertIsNotNone(LocalRoadCorridorV26,'No local body-audit adapter')
        m=PublicMap()
        c=LocalRoadCorridorV26.from_carla(m,SimpleNamespace,'Driving',[[2.,2.],[18.,2.]],0.,directory)
        m.closed=True
        return m,c

    def test_setup_reads_map_once_and_all_later_body_checks_are_local(self):
        m,c=self.setup_corridor()
        setup=m.queries
        for i in range(3):
            self.assertTrue(c.audit([[4.,2.,0.],[10.,2.,0.]],2.,1.)['accepted'])
        self.assertEqual(m.queries,setup); self.assertEqual(m.exports,1)
        self.assertGreater(setup,1)
        self.assertEqual(c.statistics['map_queries'],0)
        self.assertEqual(c.statistics['map_query_ms'],0.)
        self.assertGreater(c.statistics['local_points'],100)
        self.assertGreater(c.statistics['local_query_ms'],0.)

    def test_body_margin_and_first_rejection_match_the_legacy_straight_lane(self):
        m,c=self.setup_corridor()
        def lookup(x,y):
            if 0.<=x<=20. and 0.<=y<=4.:
                return dict(lane=[1,0,-1],junction=None,is_junction=False,width=4.)
        old=RoadCorridorV24(lookup,[(1,0,-1)],[])
        for poses in ([[[4.,2.,0.],[10.,2.,0.]]],[[[4.,.6,0.]]]):
            poses=poses[0]
            a=c.audit(poses,2.,1.); b=old.audit(poses,2.,1.)
            for key in ('accepted','complete','checked_points','witness_hash','reason','first_rejection'):
                self.assertEqual(a[key],b[key],key)

    def test_invalid_geometry_cannot_pass(self):
        _,c=self.setup_corridor()
        for poses,length,width in (([[3.,2.,float('nan')]],2.,1.),([],2.,1.),([[3.,2.,0.]],-1.,1.)):
            r=c.audit(poses,length,width)
            self.assertFalse(r['accepted']); self.assertFalse(r['complete'])
            self.assertEqual(r['reason'],'invalid_geometry')

    def test_snapshot_records_source_and_coverage_without_runtime_api(self):
        with tempfile.TemporaryDirectory() as tmp:
            m,c=self.setup_corridor(tmp)
            snapshot=json.loads((Path(tmp)/'local_road_region_v26.json').read_text(encoding='utf8'))
            self.assertEqual(snapshot,c.metadata)
            self.assertEqual(snapshot['revision'],'analytic_local_road_v26')
            self.assertEqual(snapshot['route_lanes'],[[1,0,-1]])
            self.assertEqual(snapshot['setup_map_queries'],m.queries)
            self.assertFalse(snapshot['guarantee'])
            self.assertEqual((Path(tmp)/'public_map_v24.xodr').read_text(encoding='utf8'),xodr(road()))


if __name__=='__main__': unittest.main()
