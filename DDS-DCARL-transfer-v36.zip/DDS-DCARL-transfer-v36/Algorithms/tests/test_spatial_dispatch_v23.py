"""Exercise real CLI and driver dispatch while CARLA is an external boundary."""
import ast
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace as S
import unittest
from Tools.run_relay_validation import main, ARMS
import test_spatial_probe_v23 as fixtures


class SpatialDispatchTests(unittest.TestCase):
    def test_new_arms_preserve_cg_game_traffic_and_disable_learning(self):
        for arm, mode in [('S0_observe_v23', 'observe'), ('S1_center_v23', 'center'),
                          ('S2_plus_v23', 'plus'), ('S3_minus_v23', 'minus')]:
            self.assertIn(arm, ARMS, 'Spatial candidate mode is not exposed to remote CLI')
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                self.assertEqual(main(['--dry-run', '--arms', arm, '--traffic-interaction', 'v17']), 0)
            c = json.loads(out.getvalue())['effective']
            self.assertEqual(c['DSH_SPATIAL_PROBE'], mode)
            self.assertEqual((c['DSH_METHOD'], c['DSH_COURNOT_MODE'], c['DSH_FORECAST_MODEL']),
                             ('CG', 'matrix_v18', 'route_v18'))
            self.assertEqual((c['DSH_EFE'], c['DSH_WCV_BCV']), ('0', '0'))

    def test_actual_driver_selects_and_records_the_new_candidate_path(self):
        from Planning_library.matrix_turn_game import solve_candidates
        p, f = fixtures.SpatialProbeTests().fixture()
        dynamic, cs, game = f[1], f[2], f[4]
        primary, peer = cs[1]['controller'], cs[0]['controller']
        for c in (primary, peer):
            c.acknowledge_applied_control(.1, 0.)
        self_stub = S(dynamic_map=dynamic, trajectory_probe=p,
            env=S(goal_pose=(-21., -138.5, 3.14), INTERSECTION_CENTER=(6., -138.)),
            turn_feasibility=S(last={}))
        tree = ast.parse((Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf8'))
        blocks = [n for n in ast.walk(tree) if isinstance(n, ast.If) and any(
            isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == 'solve_candidates'
            for c in ast.walk(n))]
        block = min(blocks, key=lambda n: len(list(ast.walk(n))))
        ns = dict(self=self_stub, mpc_controller=primary, matrix_peer=peer, matrix_game=game,
            v_ref=4., _sd=14., road_right=False, _conf=dict(rv_veh=dynamic.objects[0], conflict_x=6., conflict_y=-138.),
            _previous_control=dict(a=.1, df=0.), solve_candidates=solve_candidates)
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(ast.Module(body=[block], type_ignores=[]), '<production spatial dispatch>', 'exec'), ns)
        self.assertIn('spatial_probe', game.last)
        np = __import__('numpy')
        np.testing.assert_array_equal(ns['mpc_controller'].last_pathway, ns['_choice']['path'])
        self.assertEqual(ns['v_ref'], 4.)


if __name__ == '__main__':
    unittest.main()
