"""Analytic local road membership, independent of a running CARLA server."""
import math
import unittest

import numpy as np

try:
    from Planning_library.local_road_v26 import LocalRoadRegion
except ImportError:
    LocalRoadRegion=None


def lane(identifier=-1,width=4.,kind='driving',records=None):
    records=records or [(0.,width,0.,0.,0.)]
    widths=''.join('<width sOffset="%s" a="%s" b="%s" c="%s" d="%s"/>'%r for r in records)
    return '<lane id="%d" type="%s">%s</lane>'%(identifier,kind,widths)


def road(identifier=1,junction=-1,x=0.,y=0.,heading=0.,length=20.,curvature=None,
         right=None,left='',offset='',sections=None):
    shape='<line/>' if curvature is None else '<arc curvature="%s"/>'%curvature
    right=lane() if right is None else right
    sections=sections or '<laneSection s="0"><left>%s</left><center><lane id="0" type="none"/></center><right>%s</right></laneSection>'%(left,right)
    return ('<road id="%s" junction="%s" length="%s"><planView><geometry s="0" x="%s" y="%s" hdg="%s" length="%s">%s</geometry></planView><lanes>%s%s</lanes></road>'
            %(identifier,junction,length,x,y,heading,length,shape,offset,sections))


def xodr(*roads):
    return '<OpenDRIVE>'+''.join(roads)+'</OpenDRIVE>'


class LocalRoadTests(unittest.TestCase):
    def region(self,text,lanes=((1,0,-1),),junctions=(),bounds=(-30.,-30.,40.,40.)):
        self.assertIsNotNone(LocalRoadRegion,'Road membership still requires repeated CARLA point queries')
        return LocalRoadRegion.from_opendrive(text,lanes,junctions,bounds)

    def test_right_lane_and_carla_y_axis_are_not_mirrored(self):
        r=self.region(xodr(road()))
        self.assertEqual(r.contains([[5.,2.],[5.,-2.],[21.,2.],[-1.,2.]]).tolist(),[True,False,False,False])

    def test_lane_offset_and_inner_nondriving_width_are_respected(self):
        text=xodr(road(right=lane(-1,1.,'shoulder')+lane(-2,3.),
            offset='<laneOffset s="0" a="1" b="0" c="0" d="0"/>'))
        r=self.region(text,lanes=((1,0,-2),))
        self.assertEqual(r.contains([[5.,2.],[5.,-.5],[5.,3.2]]).tolist(),[True,False,False])

    def test_width_polynomials_and_width_record_switches_change_the_drivable_edge(self):
        r=self.region(xodr(road(right=lane(records=[(0.,2.,.2,0.,0.)]))))
        self.assertEqual(r.contains([[5.,2.9],[5.,3.1],[15.,4.9],[15.,5.1]]).tolist(),[True,False,True,False])
        r=self.region(xodr(road(right=lane(records=[(0.,2.,0.,0.,0.),(5.,4.,0.,0.,0.)]))))
        self.assertEqual(r.contains([[4.,3.],[6.,3.]]).tolist(),[False,True])

    def test_section_switch_is_not_a_gap_or_the_wrong_width(self):
        sections=''.join('<laneSection s="%s"><right>%s</right></laneSection>'%(s,lane(width=w))
                         for s,w in ((0.,2.),(10.,4.)))
        r=self.region(xodr(road(sections=sections)),lanes=((1,0,-1),(1,1,-1)))
        self.assertEqual(r.contains([[9.,3.],[10.,3.],[11.,3.]]).tolist(),[False,True,True])

    def test_cubic_interior_extrema_cannot_be_cut_off_by_the_fast_bounding_box(self):
        # Width is 2 at both ends, but reaches 4 in the middle of the road.
        r=self.region(xodr(road(right=lane(records=[(0.,2.,.4,-.02,0.)]))))
        self.assertEqual(r.contains([[10.,3.9],[10.,4.1],[1.,3.9]]).tolist(),[True,False,False])
        # End widths are positive; the negative interior still makes it invalid.
        with self.assertRaises(ValueError):
            self.region(xodr(road(right=lane(records=[(0.,1.,-.4,.02,0.)]))))

    def test_left_arc_right_lane_is_outside_the_reference_circle(self):
        r=self.region(xodr(road(length=15.707963267948966,curvature=.1,right=lane(width=2.))))
        self.assertEqual(r.contains([[7.778174593052,-2.221825406948],
            [6.363961030679,-3.636038969321],[11.,-10.],[10.9,-11.]]).tolist(),[True,False,True,False])

    def test_right_arc_and_atan2_wrap_keep_the_correct_arc_interval(self):
        r=self.region(xodr(road(length=15.707963267948966,curvature=-.1,right=lane(width=2.))))
        self.assertEqual(r.contains([[6.363961030679,3.636038969321],
            [7.778174593052,2.221825406948]]).tolist(),[True,False])
        r=self.region(xodr(road(x=-10.,heading=-math.pi/2,length=15.707963267948966,
                               curvature=.1,right=lane(width=2.))))
        self.assertEqual(r.contains([[-7.778174593052,7.778174593052],
                                     [-7.778174593052,-7.778174593052]]).tolist(),[True,False])

    def test_task_junction_union_accepts_an_overlap_without_accepting_other_roads(self):
        text=xodr(road(),road(2,7,y=2.),road(3,8,y=10.))
        r=self.region(text,junctions=(7,))
        self.assertEqual(r.contains([[5.,-1.],[5.,-9.]]).tolist(),[True,False])
        detail=r.describe([5.,-9.])
        self.assertFalse(detail['accepted']); self.assertTrue(detail['driving'])
        self.assertEqual(detail['junction'],8)

    def test_non_task_driving_lane_is_not_confused_with_no_driving_surface(self):
        r=self.region(xodr(road(left=lane(1,4.))))
        detail=r.describe([5.,-2.])
        self.assertFalse(detail['accepted']); self.assertTrue(detail['driving'])
        self.assertEqual(detail['lane'],[1,0,1])
        self.assertFalse(r.describe([5.,8.])['driving'])

    def test_unknown_geometry_invalid_width_and_outside_coverage_are_not_projected(self):
        self.assertIsNotNone(LocalRoadRegion)
        unsupported=xodr(road()).replace('<line/>','<spiral curvStart="0" curvEnd=".1"/>')
        with self.assertRaises(ValueError): self.region(unsupported)
        with self.assertRaises(ValueError): self.region(xodr(road(right=lane(width=-1.))))
        r=self.region(xodr(road()),bounds=(0.,0.,10.,4.))
        self.assertFalse(r.contains([[15.,2.]])[0])
        self.assertFalse(r.describe([15.,2.])['covered'])
        with self.assertRaises(ValueError): r.contains([[float('nan'),2.]])


if __name__=='__main__': unittest.main()
