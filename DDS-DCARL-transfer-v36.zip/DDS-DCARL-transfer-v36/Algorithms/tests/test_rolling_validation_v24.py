"""Independent audit must reject forged paths and wrong realized-action credit."""
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
import test_rolling_planner_v24 as fixtures
from Planning_library.execution_guard import select_execution
from Planning_library.trajectory_guard import execution_acceleration


class RollingValidationTests(unittest.TestCase):
    def validator(self):
        try: from Tools.validate_rolling_v24 import validate_rolling_record
        except ImportError: self.fail('Independent rolling learning audit is missing')
        return validate_rolling_record

    def evidence(self,full=False,terminal=False):
        p,f=fixtures.RollingPlannerTests().fixture('train')
        out=fixtures.RollingPlannerTests().request(p,f)
        c=out[1]; controller=p.activate(f[2][1]['controller'],c['controller'])
        delivered,audit=select_execution(f[1].ego_vehicle,f[1].objects,c['path'],c['target'],
            execution_acceleration(c['a'],2.,c['target']),c['delta'],f[5]['previous'],p.geometry,
            prediction=c['prediction'],prediction_times=c['times'],plan=c['plan'])
        self.assertIsNone(p.review_execution(controller,f[1].ego_vehicle,f[1].objects,f[5]['previous'],audit))
        applied=dict(control_submit_ok=1,a_cmd=delivered['a'],delta_rad=delivered['delta'],
                     actuator_speed_target=delivered['target'],ego_v_after=2.)
        p.feedback(1,1,audit,applied,'complete' if terminal else None)
        row=copy.deepcopy(f[4].last)
        row.update(rolling_trajectory=copy.deepcopy(p.last),episode=1,frame=1,pre_audit_a=c['a'],
            pre_audit_delta=c['delta'],pre_audit_target=c['target'],applied_a=delivered['a'],
            applied_delta=delivered['delta'],applied_target=delivered['target'],guard_action=audit['action'],
            guard_override=audit['override'],guard_safe=audit['safe'],control_submit_ok=1)
        ego=dict(episode='1',frame='1',a_prev=str(round(f[5]['previous']['a'],3)),
                 steer_prev=str(round(f[5]['previous']['df'],3)),ego_v_after='2.',ego_v='2',ego_v_before='2',
                 a_mpc=str(c['a']),delta_mpc_rad=str(c['delta']),a_cmd=str(delivered['a']),delta_rad=str(delivered['delta']),
                 actuator_speed_target=str(round(delivered['target'],6)),v_ref=str(round(delivered['target'],3)),
                 guard_action=audit['action'],mpc_audit_override=str(int(audit['override'])),
                 mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10')
        return (row,ego,p,f,controller,audit,applied) if full else (row,ego)

    def test_real_mpc_payload_with_realized_action_credit_passes(self):
        validate=self.validator(); row,ego=self.evidence()
        self.assertEqual(validate(row,ego,'train'),{})

    def test_changed_path_hash_and_forged_feedback_action_are_rejected(self):
        validate=self.validator(); row,ego=self.evidence()
        bad=copy.deepcopy(row); bad['rolling_trajectory']['request']['path_hash']='0'*64
        self.assertTrue(validate(bad,ego,'train'))
        row['rolling_trajectory']['feedback']['actual_action']=0
        self.assertTrue(validate(row,ego,'train'))

    def test_full_precision_control_history_and_learning_context_are_checked(self):
        validate=self.validator(); row,ego=self.evidence()
        self.assertEqual(len(row['rolling_trajectory']['learning_context']),16)
        previous=dict(row['rolling_trajectory']['previous']); previous['a']+=.01
        self.assertTrue(validate(row,ego,'train',previous))

    def test_saved_cg_reference_cannot_be_replaced_by_an_executed_spatial_path(self):
        validate=self.validator(); row,ego=self.evidence()
        p=row['rolling_trajectory']
        self.assertNotEqual(p['request']['path_hash'],p['cg_reference_hash'])
        p['cg_reference_hash']=p['request']['path_hash']
        self.assertIn('isolated_cg_reference',validate(row,ego,'train'))

    def test_rejected_road_candidate_cannot_be_marked_executable(self):
        validate=self.validator(); row,ego=self.evidence()
        p=row['rolling_trajectory']; action=p['actual_action']
        self.assertNotEqual(action,0)
        next(c for c in p['candidates'] if c['action']==action)['road_predictions'][0]['accepted']=False
        self.assertTrue(validate(row,ego,'train'))

    def test_original_game_payoff_remains_checked_when_rolling_action_owns_control(self):
        from Tools.validate_matrix_game import validate_matrix_game
        self.validator(); row,ego,p,*_=self.evidence(full=True,terminal=True)
        with tempfile.TemporaryDirectory() as t:
            p.learner.save(Path(t)/'rolling_model/rolling_model.json')
            file=Path(t)/'matrix_decisions.jsonl'; file.write_text(json.dumps(row)+'\n',encoding='utf8')
            try: good=validate_matrix_game(t,[ego],'matrix_v18',expected_rolling='train')
            except TypeError: self.fail('Original matrix audit has no rolling request owner')
            self.assertTrue(good['matrix_contract_ok'],good)
            row['payoff_matrix'][0][0]+=1.
            file.write_text(json.dumps(row)+'\n',encoding='utf8')
            self.assertFalse(validate_matrix_game(t,[ego],'matrix_v18',expected_rolling='train')['matrix_contract_ok'])

    def test_entry_audit_requires_traceable_rolling_path_ownership(self):
        from Planning_library.control_path_v15 import ControlExperimentV15
        from Tools.validate_entry_path_v15 import validate_entry_path
        from types import SimpleNamespace as S
        self.validator(); row,ego,p,f,controller,audit,applied=self.evidence(full=True)
        with tempfile.TemporaryDirectory() as t:
            e=ControlExperimentV15('CG',True,'paper_v11','spatial_v15',directory=t)
            e.condition(S(trajectory=f[2][1]['controller'].last_pathway.copy()))
            applied['ego_v_before']=2.
            e.record(1,1,controller,audit,applied,f[1].ego_vehicle,False,selected=1,active=True)
            file=Path(t)/'matrix_decisions.jsonl'; file.write_text(json.dumps(row)+'\n',encoding='utf8')
            try: good=validate_entry_path(t,[ego],'matrix',rolling_phase='train')
            except TypeError: self.fail('Entry audit has no rolling path owner')
            self.assertTrue(good['entry_path_contract_ok'],good)
            row['rolling_trajectory']['request']['path_hash']='0'*64
            file.write_text(json.dumps(row)+'\n',encoding='utf8')
            self.assertFalse(validate_entry_path(t,[ego],'matrix',rolling_phase='train')['entry_path_contract_ok'])

    def test_checkpoint_options_match_realized_frame_rewards_and_reject_forged_action(self):
        from Tools.validate_rolling_v24 import validate_rolling_experience
        p,f=fixtures.RollingPlannerTests().fixture('train')
        frames=[]
        with tempfile.TemporaryDirectory() as t:
            p.directory=Path(t)
            for frame in (1,2):
                fixtures.RollingPlannerTests().request(p,f)
                fixtures.RollingPlannerTests().feedback(p,frame=frame,outcome='complete' if frame==2 else None)
                frames.append(dict(rolling_trajectory=copy.deepcopy(p.last)))
                p.age=.5
            good=validate_rolling_experience(t,frames,'train')
            self.assertTrue(good['rolling_experience_contract_ok'],good)
            file=Path(t)/'rolling_model/rolling_model.json'; model=json.loads(file.read_text())
            model['records'][0]['action']=(model['records'][0]['action']+1)%6
            file.write_text(json.dumps(model),encoding='utf8')
            self.assertFalse(validate_rolling_experience(t,frames,'train')['rolling_experience_contract_ok'])


if __name__=='__main__': unittest.main()
