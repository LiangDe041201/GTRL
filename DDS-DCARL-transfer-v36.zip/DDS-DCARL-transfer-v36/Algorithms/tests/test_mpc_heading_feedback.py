"""Regression checks for measured heading feedback, without CARLA."""
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from Agent.game_theory.MPC import MPCController
except ImportError:
    MPCController = None


@unittest.skipIf(MPCController is None, 'Requires CasADi')
class TestHeadingFeedback(unittest.TestCase):
    def controller(self, yaw, path_heading=0.):
        ego = SimpleNamespace(x=0., y=0., yaw=yaw, v=4.)
        lane = SimpleNamespace(front_vehicles=[], rear_vehicles=[])
        dynamic_map = SimpleNamespace(ego_vehicle=ego, lanes=[lane])
        controller = MPCController(10, .05, 2.7, .5,
                                   enable_lead_follow_cost=False,
                                   enable_boundary_thw=False)
        distance = np.arange(40.)
        path = np.column_stack((distance * math.cos(path_heading),
                                distance * math.sin(path_heading)))
        controller.reset_global_path(path, dynamic_map)
        return controller, dynamic_map

    def test_both_signs_of_heading_error_are_measured(self):
        for yaw in (-.2, .2):
            controller, dynamic_map = self.controller(yaw)
            self.assertAlmostEqual(controller.ego_info_convert(dynamic_map)['epsi'], yaw)

    def test_wraparound_uses_shortest_angle(self):
        controller, dynamic_map = self.controller(math.radians(179), math.radians(-179))
        self.assertAlmostEqual(controller.ego_info_convert(dynamic_map)['epsi'],
                               math.radians(-2), places=10)

    def test_frenet_and_world_lateral_motion_agree_on_straight_path(self):
        controller, dynamic_map = self.controller(.2)
        state = controller.ego_info_convert(dynamic_map)
        state['K'] = 0.
        future = controller.model.dynamics_step(state, dict(a=0., df=0.))
        self.assertGreater(float(future['l']), .03)
        self.assertAlmostEqual(float(future['l']), float(future['y']), places=10)

    def test_optimizer_corrects_heading_before_lateral_error_accumulates(self):
        for yaw in (-.2, .2):
            controller, dynamic_map = self.controller(yaw)
            _, steering = controller.solve(dynamic_map, 4., False)
            self.assertTrue(controller._solve_ok)
            self.assertLess(steering * yaw, -.001)
            self.assertAlmostEqual(controller.last_tracking_state['epsi'], yaw)


if __name__ == '__main__':
    unittest.main()
