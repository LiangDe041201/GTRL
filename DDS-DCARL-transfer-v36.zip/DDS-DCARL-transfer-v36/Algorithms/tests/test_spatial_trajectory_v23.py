"""New routes must satisfy boundary conditions, not scale an old point list."""
import math
from types import SimpleNamespace as S
import unittest
import numpy as np

try:
    from Planning_library.spatial_trajectory_v23 import SpatialFamily, quintic_boundary, evaluate
except ImportError:
    SpatialFamily = quintic_boundary = evaluate = None


class SpatialTrajectoryTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(SpatialFamily, 'Spatial polynomial trajectory family is missing')
        return SpatialFamily

    def test_quintic_respects_position_slope_and_curvature_at_both_ends(self):
        self.api()
        c = quintic_boundary((.2, .1, -.03), (.5, 0., 0.), 8.)
        for derivative, start, end in [(0, .2, .5), (1, .1, 0.), (2, -.03, 0.)]:
            self.assertAlmostEqual(evaluate(c, 0., derivative), start)
            self.assertAlmostEqual(evaluate(c, 8., derivative), end)
        c = quintic_boundary((0., 0., 0.), (1., 0., 0.), 1.)
        self.assertAlmostEqual(evaluate(c, .5), .5)
        self.assertAlmostEqual(evaluate(c, .5, 1), 1.875)

    def test_path_starts_at_observed_pose_reaches_offset_and_rejoins_route(self):
        family = self.api()(np.c_[np.arange(0., 51.), np.zeros(51)])
        p = family.generate(S(x=2., y=.2, yaw=.05), dict(df=0.), 2.86, .5)
        np.testing.assert_allclose(p['path'][0], [2., .2], atol=1e-7)
        self.assertAlmostEqual(p['poses'][0, 2], .05, places=6)
        peak = int(np.argmin(abs(p['arc']-p['peak_arc'])))
        self.assertAlmostEqual(p['path'][peak, 1], .5, places=7)
        np.testing.assert_allclose(p['path'][-1], [50., 0.], atol=1e-7)
        self.assertAlmostEqual(p['curvature'][0], 0., places=6)
        self.assertAlmostEqual(p['d'][-1], 0., places=7)

    def test_positive_and_negative_parameters_make_different_spatial_routes(self):
        family = self.api()(np.c_[np.arange(0., 51.), np.zeros(51)])
        ego = S(x=2., y=0., yaw=0.)
        a = family.generate(ego, dict(df=0.), 2.86, .5)
        b = family.generate(ego, dict(df=0.), 2.86, -.5)
        self.assertGreater(np.max(a['path'][:, 1]), .49)
        self.assertLess(np.min(b['path'][:, 1]), -.49)

    def test_offset_follows_curved_reference_normal_not_a_fixed_world_axis(self):
        theta = np.linspace(0., math.pi/2, 101)
        ref = np.c_[20.*np.cos(theta), 20.*np.sin(theta)]
        family = self.api()(ref)
        p = family.generate(S(x=20., y=0., yaw=math.pi/2), dict(df=math.atan(2.86/20.)), 2.86, .5)
        k = int(np.argmin(abs(p['arc']-p['peak_arc'])))
        self.assertAlmostEqual(np.linalg.norm(p['path'][k]), 19.5, delta=.005)
        np.testing.assert_allclose(p['path'][-1], ref[-1], atol=1e-7)

    def test_inadequate_route_or_reverse_heading_never_invents_a_continuation(self):
        family = self.api()(np.c_[np.arange(0., 21.), np.zeros(21)])
        with self.assertRaises(ValueError):
            family.generate(S(x=12., y=0., yaw=0.), dict(df=0.), 2.86, .5)
        with self.assertRaises(ValueError):
            family.generate(S(x=0., y=0., yaw=math.pi), dict(df=0.), 2.86, .5)

    def test_cannot_hide_extreme_curvature_by_clipping_geometry(self):
        family = self.api()(np.c_[np.arange(0., 51.), np.zeros(51)])
        p = family.generate(S(x=2., y=0., yaw=0.), dict(df=0.), 2.86, 1., transition=1., recovery=1.)
        self.assertGreater(max(abs(p['curvature'])), math.tan(.6)/2.86)


if __name__ == '__main__':
    unittest.main()
