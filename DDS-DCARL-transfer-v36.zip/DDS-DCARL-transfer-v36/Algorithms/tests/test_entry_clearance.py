#!/usr/bin/env python3
"""【创新点④·P3】进入冲突区的清空时间与"能否安全插入"判据（纯 stdlib，无 CARLA）。

修的是一个**乐观偏差**：旧代码用
    clearance = 4.0 / v_go        （只有自车车身长）
    safe      = (t_rv − t_ego_go) >= clearance + 0.5
漏掉了**自车必须整车穿过交叉车流带**这件事。实测 `expJ_paper_p100`（100 回合、
碰撞 76%）的碰撞**全部发生在进入阶段**（`committed=0`、`arc≈10.2 m`），形态是侧刮：
自车车头 y≈−137.02 正好压在交叉车体带 [−139,−137] 的边界上。

新式（论文 §VI-A "the time it will take for the LCV to enter Area A"）：
    t_clear = (ego_len + band) / v_go + margin
"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.boundary_safety import (
    entry_clearance_time, can_clear_safely,
    CLEAR_BAND_DEFAULT, CLEAR_MARGIN_DEFAULT,
)

INF = float("inf")


class TestEntryClearanceTime(unittest.TestCase):

    def test_includes_band_width_not_just_ego_body(self):
        """清空时间必须含交叉带宽度 —— 这正是旧式漏掉的部分。"""
        t = entry_clearance_time(4.0, ego_len=4.5, band=4.0, margin=1.0)
        self.assertAlmostEqual(t, (4.5 + 4.0) / 4.0 + 1.0)   # = 3.125
        old = 4.0 / 4.0 + 0.5                                # 旧式 = 1.5
        self.assertGreater(t, old, "新判据必须比旧式更保守")
        self.assertAlmostEqual(t - old, 1.625)

    def test_monotone_decreasing_in_speed(self):
        ts = [entry_clearance_time(v) for v in (1.0, 2.0, 4.0, 8.0)]
        self.assertEqual(ts, sorted(ts, reverse=True))

    def test_speed_floor_avoids_divergence(self):
        """v_go→0 时不得发散（否则永远判"不安全"→卡死）。"""
        self.assertTrue(abs(entry_clearance_time(0.0) - entry_clearance_time(0.5)) < 1e-9)

    def test_defaults_are_used(self):
        self.assertAlmostEqual(
            entry_clearance_time(4.0),
            (4.5 + CLEAR_BAND_DEFAULT) / 4.0 + CLEAR_MARGIN_DEFAULT)


class TestCanClearSafely(unittest.TestCase):

    def test_no_rv_means_safe(self):
        self.assertTrue(can_clear_safely(1.0, INF, 4.0))
        self.assertTrue(can_clear_safely(1.0, None, 4.0))

    def test_uses_clearance_time(self):
        # v_go=4 -> t_clear = (4.5+4)/4 + 1.0 = 3.125
        self.assertTrue(can_clear_safely(1.0, 4.125, 4.0))    # 恰好 3.125
        self.assertFalse(can_clear_safely(1.0, 4.124, 4.0))   # 差一点点

    def test_old_criterion_would_have_said_go(self):
        """反证：旧判据（只算车身）在同一情形下会放行 —— 这就是被修的乐观偏差。"""
        t_ego_go, v_go = 1.0, 4.0
        old_ok = (2.0 - t_ego_go) >= (4.0 / v_go + 0.5)   # 1.0 >= 1.5 -> False
        # 取一个"旧放行、新拦住"的点：t_rv - t_ego_go = 2.0
        t_rv = t_ego_go + 2.0
        self.assertTrue((t_rv - t_ego_go) >= (4.0 / v_go + 0.5),
                        "旧判据在这个时间差下确实会放行")
        self.assertFalse(can_clear_safely(t_ego_go, t_rv, v_go),
                         "新判据必须拦住它（2.0 < 3.125）")
        self.assertFalse(old_ok)  # 仅为保持变量被使用

    def test_band_zero_reduces_to_body_only_plus_margin(self):
        """band=0 且 ego_len=4.0 时退化成旧式 `4.0/v_go + margin`（便于消融对照）。"""
        # t_clear = (4.0 + 0)/4.0 + 0.5 = 1.5
        self.assertTrue(can_clear_safely(1.0, 2.5, 4.0, ego_len=4.0,
                                         band=0.0, margin=0.5))
        self.assertFalse(can_clear_safely(1.0, 2.49, 4.0, ego_len=4.0,
                                          band=0.0, margin=0.5))

    def test_slow_ego_needs_more_time(self):
        """自车越慢，需要的清空时间越长（→ 更倾向等待，符合"安全优先"）。"""
        self.assertGreater(entry_clearance_time(1.0), entry_clearance_time(4.0))
        self.assertFalse(can_clear_safely(0.0, 5.0, 1.0))
        self.assertTrue(can_clear_safely(0.0, 5.0, 4.0))


if __name__ == "__main__":
    unittest.main()
