#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【修复 D2】式56/57：−ambiguity 折进单步回报的回归测试（纯函数，无 CARLA）。

背景与论文依据（ADVEI-D-26-08155 §V）
------------------------------------------------------------------
  式54  EFE = risk + ambiguity
         risk      = D_KL[ q(o|a) ‖ p̃(o) ]        （与偏好观测的偏离）
         ambiguity = E_τ[ H(p(o|s,a))) ]           （对手隐状态的条件熵，式55 用**自然对数**）
  式56  r(s,a) = −EFE(s,a)                         ← **单步回报就是负 EFE**
  式58/59 MC 回报 Q̂ = mean_n[ γ^n·(−EFE) ]
  式60  WCV = Q̂ − (R_max−R_min)·√(ln(1/Pf)/(2n)) − 4σ/(n+1)
        原文："当对手意图模糊时，轨迹回报的**方差**相应增大 ⇒ 方差修正项压低保守下界"

修复前的缺陷（实证）
  默认 `DSH_EFE_MODE='per_action'` ⇒ 向 `causal_r` 加 EFE 的分支
  （只在 `efe_mode=='legacy'` 时执行）**永不运行** ⇒ **ambiguity 从未进入回报**
  ⇒ σ 与模糊无关 ⇒ 式60 的方差修正项无法发挥"模糊时更保守"的作用
  ⇒ **② 与 ③ 之间没有信息耦合**。

修法：`r += −w·r_behavior[a]`（只加 ambiguity，不加整个 −EFE，避免 risk 重复计数）。
消融：`DSH_EFE_R_W=0` ⇒ 完整复现修复前行为。

本文件只验证该项的**数值/符号/边界**语义，不断言"σ 一定变大"（那是闭环问题）。
"""
import math
import os
import sys
import unittest

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.active_inference import (
    ambiguity_reward, behavior_ambiguity, observation_entropy,
    efe_by_action, action_efe,
)


class TestAmbiguityReward(unittest.TestCase):

    # ---------- 基本语义：term = −w·ambiguity ----------
    def test_basic_formula(self):
        term, used = ambiguity_reward({3: 0.5}, 3, w=1.0)
        self.assertAlmostEqual(term, -0.5, places=12)
        self.assertAlmostEqual(used, 0.5, places=12)

    def test_weight_scales_linearly(self):
        for w in (0.0, 0.25, 1.0, 2.5, 10.0):
            term, _ = ambiguity_reward({3: 0.8}, 3, w=w)
            self.assertAlmostEqual(term, -w * 0.8, places=12)

    def test_zero_weight_is_ablation(self):
        """`w=0` ⇒ 恒 0 ⇒ 完整复现修复前行为（消融口径）。"""
        term, used = ambiguity_reward({3: 0.9}, 3, w=0.0)
        self.assertEqual(term, 0.0)
        self.assertAlmostEqual(used, 0.9)        # 仍回报"观测到的 ambiguity"，便于诊断

    def test_sign_is_non_positive(self):
        """符号必须 ≤ 0 ⇒ **越模糊回报越低**（与式56 一致）。"""
        for amb in (0.0, 0.01, 0.5, 1.386, 5.0):
            term, _ = ambiguity_reward({0: amb}, 0, w=1.0)
            self.assertLessEqual(term, 1e-15, f'ambiguity={amb} 时 term 应为 ≤0')

    def test_monotone_more_ambiguous_less_reward(self):
        """ambiguity 越大 ⇒ 回报越低（单调）。这是"模糊 ⇒ 保守"的激励基础。"""
        prev = 0.0
        for amb in (0.0, 0.1, 0.3, 0.7, 1.0, 1.386):
            term, _ = ambiguity_reward({0: amb}, 0, w=1.0)
            self.assertLessEqual(term, prev + 1e-15)
            prev = term

    # ---------- 逐动作：必须真的按动作取值 ----------
    def test_per_action_lookup(self):
        amb = {0: 0.1, 1: 0.2, 2: 0.9}
        self.assertAlmostEqual(ambiguity_reward(amb, 0)[0], -0.1, places=12)
        self.assertAlmostEqual(ambiguity_reward(amb, 1)[0], -0.2, places=12)
        self.assertAlmostEqual(ambiguity_reward(amb, 2)[0], -0.9, places=12)

    def test_action_not_present_returns_neutral(self):
        """动作不在表里 ⇒ 中性 0（不得猜、不得抛异常）。"""
        term, used = ambiguity_reward({0: 0.5}, 7, w=1.0)
        self.assertEqual(term, 0.0)
        self.assertIsNone(used)

    # ---------- 边界与健壮性（每帧热路径，绝不抛异常） ----------
    def test_none_table(self):
        self.assertEqual(ambiguity_reward(None, 0), (0.0, None))

    def test_empty_table(self):
        self.assertEqual(ambiguity_reward({}, 0), (0.0, None))

    def test_bad_ambiguity_values(self):
        for bad in ('x', None, float('nan'), float('inf'), float('-inf')):
            try:
                term, used = ambiguity_reward({0: bad}, 0, w=1.0)
            except (TypeError, ValueError):
                self.fail(f'ambiguity={bad!r} 不应抛异常')
            self.assertEqual(term, 0.0, f'ambiguity={bad!r} 应给中性 0')
            self.assertIsNone(used)

    def test_bad_action(self):
        for bad in ('x', None, 1.9):      # 1.9 → int() = 1（合法）
            try:
                ambiguity_reward({1: 0.5}, bad)
            except (TypeError, ValueError):
                self.fail(f'action={bad!r} 不应抛异常')

    def test_bad_weight(self):
        for bad in ('x', None):
            try:
                ambiguity_reward({0: 0.5}, 0, w=bad)
            except (TypeError, ValueError):
                self.fail(f'w={bad!r} 不应抛异常')

    def test_negative_ambiguity_clamped(self):
        """熵不可能为负；上游若给负值必须**截到 0**，不得产生"越模糊越赚"的反向激励。"""
        term, used = ambiguity_reward({0: -0.7}, 0, w=1.0)
        self.assertEqual(term, 0.0)
        self.assertEqual(used, 0.0)

    def test_non_dict_table(self):
        for bad in ([1, 2, 3], 'abc', 5):
            try:
                ambiguity_reward(bad, 0)
            except (TypeError, ValueError, AttributeError):
                self.fail(f'table={bad!r} 不应抛异常')

    # ---------- 与上游真实信号的量级/值域一致性 ----------
    def test_scale_matches_observation_entropy_range(self):
        """`r_behavior` 是 4 类观测的条件熵（自然对数）⇒ ∈ [0, ln4]。

        这条约束很重要：它决定本项在逐帧回报（约 −6）中的占比约 20%，
        既足以影响 σ，又不会淹没主目标。
        """
        self.assertAlmostEqual(observation_entropy([0.25] * 4), math.log(4), places=9)
        self.assertAlmostEqual(observation_entropy([1.0, 0.0, 0.0, 0.0]), 0.0, places=9)
        ln4 = math.log(4.0)
        # 均匀分布下 4 类的最大 ambiguity
        cond = {'tau0': np.array([0.25, 0.25, 0.25, 0.25]),
                'tau1': np.array([0.25, 0.25, 0.25, 0.25])}
        amb = behavior_ambiguity(cond, {'tau0': 0.5, 'tau1': 0.5})
        self.assertAlmostEqual(amb, ln4, places=9)
        term, _ = ambiguity_reward({0: amb}, 0, w=1.0)
        self.assertAlmostEqual(term, -ln4, places=9)

    def test_confident_opponent_gives_zero_ambiguity_reward(self):
        """对手行为完全确定（独热观测）⇒ 条件熵 0 ⇒ 本项 0（不惩罚确定的情形）。"""
        cond = {'tau0': np.array([1.0, 0.0, 0.0, 0.0])}
        amb = behavior_ambiguity(cond, {'tau0': 1.0})
        self.assertAlmostEqual(amb, 0.0, places=12)
        self.assertAlmostEqual(ambiguity_reward({0: amb}, 0)[0], 0.0, places=12)

    def test_end_to_end_from_efe_by_action(self):
        """与上游 `efe_by_action` 的 `r_behavior` 字段对接（真实数据形态）。"""
        margins = {0: {'yield': 0.2, 'rush': -0.5}, 1: {'yield': 3.0, 'rush': 2.0}}
        yprobs = {0: {'tau0': 0.5}, 1: {'tau0': 0.5}}
        belief = {'tau0': 1.0}
        res = efe_by_action(margins, yprobs, belief, clearance_by_action={0: 1.0, 1: 1.0},
                            t_ego_by_action={0: 2.0, 1: 1.0}, horizon=3.0)
        amb = {a: d['r_behavior'] for a, d in res.items()}
        # 逐动作必须能区分（否则"② 无动作区分度"的老问题会复现）
        self.assertGreater(len(set(round(v, 9) for v in amb.values())), 1,
                           'r_behavior 必须在候选动作间可区分')
        for a, d in res.items():
            term, used = ambiguity_reward(amb, a)
            self.assertAlmostEqual(used, d['r_behavior'], places=12)
            self.assertAlmostEqual(term, -d['r_behavior'], places=12)
            self.assertLessEqual(term, 1e-15)

    def test_does_not_double_count_cognition(self):
        """只加 ambiguity ⇒ 本项必须与 `r_cognition`（risk）**无函数关系**。

        若本项等同于 −EFE，就说明把 risk 也加进来了（重复计数）。
        """
        margins = {0: {'yield': 0.1, 'rush': -0.9}, 1: {'yield': 4.0, 'rush': 3.0}}
        yprobs = {0: {'tau0': 0.2}, 1: {'tau0': 0.9}}
        belief = {'tau0': 1.0}
        res = efe_by_action(margins, yprobs, belief, clearance_by_action={0: 1.0, 1: 1.0},
                            t_ego_by_action={0: 2.0, 1: 1.0}, horizon=3.0,
                            w_cognition=1.0, w_behavior=1.0)
        for a, d in res.items():
            term = ambiguity_reward({a: d['r_behavior']}, a)[0]
            # 本项 == −r_behavior（不含 cognition）
            self.assertAlmostEqual(term, -d['r_behavior'], places=12)
            # 若 r_cognition 明显非 0，则 term 不应等于 −efe（那会把 risk 也算进来）
            if abs(d['r_cognition']) > 1e-6:
                self.assertNotAlmostEqual(
                    term, d['reward'], places=6,
                    msg='本项不得等于 −EFE（否则 risk 被重复计数）')


if __name__ == '__main__':
    unittest.main(verbosity=2)
