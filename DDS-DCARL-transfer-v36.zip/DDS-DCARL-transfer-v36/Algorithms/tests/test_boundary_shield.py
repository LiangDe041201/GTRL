#!/usr/bin/env python3
"""【创新点④·P1-g】边界安全"保守确定性策略"动作屏蔽的单元测试（纯 stdlib，无 CARLA）。

背景（实测 expF_paper100，100 回合，碰撞率 77%）：
  `lcttc_rv < 1.0 s`（1 秒内车身边界就要撞上）的 1491 帧里，
  **1240 帧（83%）最终动作不是刹车**；其中 241 帧是 ε-greedy 在
  `lcttc_rv < 0.5 s` 时选了非刹车档。
  根因：④ 边界模型此前只进奖励与 WCV 方差，**从未约束动作空间**。
本模块验证把 ④ 变成硬约束后的纯函数语义。
"""
import os
import sys
import unittest

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # DDS-DCARL-Turn
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.boundary_safety import (
    boundary_shield_active, boundary_shield_mask,
    SHIELD_LCTTC_DEFAULT, SHIELD_LCTTC_CRITICAL, SHIELD_THW_DEFAULT,
)

INF = float("inf")
#: 与 Agent/tools_dds/LaneTrajectoryPlanner.TURN_SPEED_LEVELS 一致（8 档速度）
SPEEDS = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0]


class TestBoundaryShieldActive(unittest.TestCase):
    """危险判定：未越过冲突点 且 边界已逼近。"""

    def test_not_dangerous_when_far(self):
        self.assertFalse(boundary_shield_active(5.0, 6.0, committed=False))

    def test_dangerous_when_lcttc_below_threshold(self):
        self.assertTrue(boundary_shield_active(0.5, 6.0, committed=False))
        self.assertTrue(boundary_shield_active(SHIELD_LCTTC_DEFAULT - 1e-6, INF, committed=False))

    def test_boundary_of_threshold_is_not_dangerous(self):
        # 恰好等于阈值 -> 不危险（严格小于）
        self.assertFalse(boundary_shield_active(SHIELD_LCTTC_DEFAULT, INF, committed=False))

    def test_committed_disables_shield(self):
        # 已越过冲突点：加速驶离才是正确的保守动作，不能屏蔽
        self.assertFalse(boundary_shield_active(0.01, 0.01, committed=True))

    def test_non_finite_measurement_is_not_dangerous(self):
        """【反 P1-f 对称】没测到 != 危险，不能因为缺测量就锁死自车。"""
        for bad in (INF, float('nan'), None):
            self.assertFalse(boundary_shield_active(bad, bad, committed=False),
                             f"非有限测量 {bad!r} 不得判危险")

    def test_thw_is_the_primary_trigger_now(self):
        """【P4-⓪b】触发量已从 lcttc 换成最坏情况 THW，故 THW 档默认**开启**。

        旧行为（只看 lcttc）可用 shield_thw=0 复现做消融。
        """
        self.assertGreater(SHIELD_THW_DEFAULT, 0.0)
        # lcttc 很宽（5 s，物理上很安全）但 THW 很小 -> 仍应触发（这就是"提前量"）
        self.assertTrue(boundary_shield_active(5.0, 0.01, committed=False))
        # 关掉 THW 档 -> 退回只看 lcttc，不触发
        self.assertFalse(boundary_shield_active(5.0, 0.01, committed=False, shield_thw=0.0))

    def test_bad_types_do_not_raise(self):
        self.assertFalse(boundary_shield_active("oops", "oops", committed=False))
        self.assertFalse(boundary_shield_active("oops", "oops", committed=False, shield_thw=1.0))


class TestBoundaryShieldMask(unittest.TestCase):
    """危险时只允许"不加速"的档位。"""

    def test_all_allowed_when_safe(self):
        m = boundary_shield_mask(SPEEDS, 5.0, 6.0, committed=False, ego_v=3.0)
        self.assertEqual(m, [True] * len(SPEEDS))

    def test_first_tier_only_non_accelerating_allowed(self):
        """第一档（0.3s <= lcttc < 0.8s）：目标速度不得超过当前速度。"""
        m = boundary_shield_mask(SPEEDS, 0.5, INF, committed=False, ego_v=3.0)
        self.assertEqual(m, [True, True, True, True, False, False, False, False])
        # 严格不加速：ego_v=2.825 -> 3.0 档（action 3）也应被拦
        m2 = boundary_shield_mask(SPEEDS, 0.5, INF, committed=False, ego_v=2.825)
        self.assertTrue(m2[2] and not m2[3], "3.0 m/s > ego_v=2.825 必须被拦")

    def test_critical_tier_allows_only_brake(self):
        """第二档（lcttc < 0.3s）：只剩全力刹车 —— 5ms 的边界 TTC 没有滑行余地。"""
        for ego_v in (0.0, 1.0, 2.8, 8.0):
            m = boundary_shield_mask(SPEEDS, 0.05, INF, committed=False, ego_v=ego_v)
            self.assertEqual(m, [True, False, False, False, False, False, False, False],
                             f"临界档 ego_v={ego_v} 应只允许刹车")
        # 临界档与第一档在 0.3s 处切换
        self.assertTrue(boundary_shield_mask(SPEEDS, SHIELD_LCTTC_CRITICAL, INF,
                                             committed=False, ego_v=3.0)[3])
        self.assertFalse(boundary_shield_mask(SPEEDS, SHIELD_LCTTC_CRITICAL - 1e-6, INF,
                                              committed=False, ego_v=3.0)[3])

    def test_brake_always_allowed_even_when_stopped(self):
        m = boundary_shield_mask(SPEEDS, 0.5, INF, committed=False, ego_v=0.0)
        self.assertTrue(m[0], "刹车档必须永远可用")
        self.assertEqual(m, [True, False, False, False, False, False, False, False])

    def test_committed_ignores_shield(self):
        m = boundary_shield_mask(SPEEDS, 0.0, 0.0, committed=True, ego_v=1.0)
        self.assertEqual(m, [True] * len(SPEEDS))

    def test_at_least_one_action_survives(self):
        # 极端：米制档位全都高于 ego_v+margin 时，兜底保留最慢档
        m = boundary_shield_mask([5.0, 6.0, 8.0], 0.1, INF, committed=False, ego_v=0.0)
        self.assertTrue(any(m), "屏蔽后必须至少剩一个可执行动作")
        self.assertEqual(m, [True, False, False])

    def test_empty_speeds(self):
        self.assertEqual(boundary_shield_mask([], 0.1, INF, committed=False, ego_v=1.0), [])

    def test_never_removes_the_slowest_option(self):
        """危险时最小速度档必须保留 —— 否则自车无法避险。"""
        for v in (0.0, 0.5, 1.0, 3.0, 8.0):
            m = boundary_shield_mask(SPEEDS, 0.05, INF, committed=False, ego_v=v)
            self.assertTrue(m[0], f"ego_v={v} 时刹车档被屏蔽了")


class TestShieldRegressionExpF(unittest.TestCase):
    """用 expF_paper100 实测状态复现：不屏蔽会放行危险动作，屏蔽后不会。"""

    #: (ego_v, lcttc_rv, 当时最终执行的 action) —— 取自 expF_paper100 回合 5 帧 214~220
    #: 当时 rule_action=0、action=3、takeover=0（ε-greedy 覆盖），直到撞上。
    OBSERVED = [
        (2.825, 0.009, 3),
        (2.818, 0.005, 3),
        (2.798, 0.010, 3),
    ]

    def test_observed_dangerous_actions_are_blocked(self):
        """expF_paper100 回合 5 帧 214~220 的实测状态：lcttc≈0.005~0.01s。

        这三帧属于**第二档（临界）**，所以屏蔽后唯一允许的动作就是全力刹车。
        注意诚实说明：0.005s 的边界 TTC 其实**已经来不及救**了 —— 屏蔽的价值在于
        在更早（lcttc<0.8s）就阻止自车进入这种状态，而不是在此刻翻盘。
        """
        for ego_v, lcttc, act in self.OBSERVED:
            m = boundary_shield_mask(SPEEDS, lcttc, INF, committed=False, ego_v=ego_v)
            self.assertTrue(boundary_shield_active(lcttc, INF, committed=False),
                            f"lcttc={lcttc} 应判危险")
            self.assertFalse(m[act],
                             f"ego_v={ego_v} lcttc={lcttc} 时执行了 action={act}，"
                             f"屏蔽后必须被拦下")
            self.assertEqual(m, [True, False, False, False, False, False, False, False],
                             "临界档只允许刹车")

    def test_shield_acts_before_it_is_too_late(self):
        """屏蔽的真正价值：在 lcttc 还够刹住的更早阶段就不许加速。"""
        # lcttc=0.6s 时 ego 以 3 m/s 行驶，仍然来得及减速 -> 第一档拦截加速档
        m = boundary_shield_mask(SPEEDS, 0.6, INF, committed=False, ego_v=3.0)
        self.assertTrue(boundary_shield_active(0.6, INF, committed=False))
        self.assertFalse(m[5], "0.6s 时应拦下 5 m/s 的加速档")

    def test_old_behaviour_reproduced_by_disabling_shield(self):
        """反证：不判危险时（等价于旧行为）同一动作会被放行 —— 这就是 83% 那一栏。"""
        m = boundary_shield_mask(SPEEDS, INF, INF, committed=False, ego_v=2.825)
        self.assertTrue(m[3], "无危险信号时 action=3 放行（旧行为）")


if __name__ == "__main__":
    unittest.main()
