"""Remote protocol keeps training distinct from frozen evidence and archives failures."""
import contextlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import test_trajectory_workflow_v21 as old_fixtures


class EvolutionWorkflowTests(unittest.TestCase):
    def workflow(self):
        try:
            return importlib.import_module('Tools.run_evolution_validation_v22')
        except ImportError:
            self.fail('The trajectory evolution pilot launcher is missing')

    def run_fixture(self, args, failure=False, mismatch=False):
        helper = old_fixtures.TrajectoryWorkflowTests()
        output = Path(args[args.index('--output-root')+1])
        result = helper.run_fixture(output, args, failed=failure)
        if mismatch and output.name == '00_smoke':
            p = output/'E0_observe_v22_seed40/interaction_ego.csv'
            p.write_text(p.read_text(encoding='utf8').replace(',1,0,1,', ',2,0,1,', 1), encoding='utf8')
        if output.name == '01_train':
            from Planning_library.trajectory_evolution_learning_v22 import EvolutionLearner
            EvolutionLearner().save(output/'E1_train_v22_seed41/trajectory_model/evolution_model.json')
        return result

    def test_plan_is_20_executions_with_independent_frozen_checkpoint_evaluation(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            s = w.build_plan(output)
            self.assertEqual([x['episodes_total'] for x in s], [4, 12, 4])
            self.assertEqual(s[1]['arms'], ['E1_train_v22'])
            self.assertEqual(s[2]['arms'], ['M6_matrix_v18', 'E2_eval_v22'])
            self.assertIn('--evolution-checkpoint', s[2]['arguments'])
            self.assertNotEqual(s[1]['seeds'], s[2]['seeds'])
            self.assertFalse(output.exists())

    def test_successful_protocol_preserves_model_and_writes_one_archive_without_claiming_benefit(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            with patch.object(w.subprocess, 'run', side_effect=lambda cmd, **kw: self.run_fixture(cmd)), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertEqual(code, 0)
            report = json.loads((output/'EVOLUTION_REPORT.json').read_text(encoding='utf8'))
            self.assertEqual(report['actual_episodes'], 20)
            self.assertFalse(report['learning_benefit_established'])
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())

    def test_failed_training_preserves_partial_results_and_does_not_evaluate(self):
        w = self.workflow()
        with tempfile.TemporaryDirectory() as d:
            output = Path(d)/'result'
            def boundary(cmd, **kw):
                return self.run_fixture(cmd, failure='01_train' in cmd[cmd.index('--output-root')+1])
            with patch.object(w.subprocess, 'run', side_effect=boundary), contextlib.redirect_stdout(io.StringIO()):
                code = w.main(['--output-root', str(output)])
            self.assertNotEqual(code, 0)
            self.assertTrue((output/'01_train/manifest.json').is_file())
            self.assertFalse((output/'02_eval').exists())
            self.assertTrue(Path(str(output)+'.tar.gz').is_file())


if __name__ == '__main__':
    unittest.main()
