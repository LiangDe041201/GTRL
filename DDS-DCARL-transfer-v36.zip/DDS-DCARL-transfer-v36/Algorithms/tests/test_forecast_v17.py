import math
import contextlib
import io
import json
import tempfile
from pathlib import Path
import unittest
from types import SimpleNamespace as NS

import numpy as np

from Planning_library.forecast_v16 import predict as legacy_predict


class ForecastV17Tests(unittest.TestCase):
    def test_comparison_uses_same_repaired_traffic_for_every_arm(self):
        from Tools.run_relay_validation import main
        with contextlib.redirect_stdout(io.StringIO()) as output:
            code = main(['--dry-run', '--method', 'CG', '--traffic-interaction', 'v17',
                '--arms', 'B2_rule_spatial,M3_matrix_spatial,B4_rule_v17,M5_matrix_v17'])
        self.assertEqual(code, 0)
        config = [json.loads(line)['effective'] for line in output.getvalue().splitlines()]
        self.assertEqual([c['DSH_FORECAST_MODEL'] for c in config], ['legacy', 'legacy', 'route_v17', 'route_v17'])
        self.assertTrue(all(c['DSH_TRAFFIC_INTERACTION'] == 'v17' for c in config))
        self.assertEqual(config[-1]['DSH_COURNOT_AUTHORITY'], 'matrix_entry')

    def test_navigation_endpoint_is_not_a_stop_destination(self):
        ego = NS(x=0., y=0., yaw=0., v=4.)
        geometry = dict(max_steer=.6, wheelbase=2.7, forecast_route=[[0., 0.], [15., 0.]],
                        navigation_end_is_stop=False, forecast_model='route_v17')
        states, times, diag = legacy_predict(ego, [[0., 0.], [10., 0.]], 4., 0., 0.,
            dict(a=0., df=0.), geometry, horizon=3., lag=0.)
        self.assertAlmostEqual(states[5, -1], 4., places=6)
        self.assertAlmostEqual(states[0, -1], 12., places=6)

    def test_actual_waypoint_continuation_extends_coverage(self):
        from Planning_library.forecast_v17 import road_continuation, prediction_geometry, predict
        class Waypoint:
            def __init__(self, x):
                self.transform = NS(location=NS(x=x, y=0.), rotation=NS(yaw=0.))
                self.road_id, self.lane_id = 1, -1
            def next(self, distance):
                return [Waypoint(self.transform.location.x+distance)]
        navigation = [[0., 0.], [10., 0.]]
        road = road_continuation(navigation, Waypoint(10.), length=40.)
        geometry = prediction_geometry(dict(max_steer=.6, wheelbase=2.7), road,
                                       navigation_route=navigation)
        states, _, diag = predict(NS(x=8., y=.4, yaw=0., v=4.),
            [[8., .4], [10., .4]], 4., 0., 0., dict(a=0., df=0.), geometry)
        self.assertTrue(diag['valid'])
        self.assertGreater(states[0, -1], 28.)
        self.assertGreater(states[5, -1], 3.9)
        self.assertEqual(navigation, [[0., 0.], [10., 0.]])

    def test_missing_road_is_an_error_not_invented_straight_extension(self):
        from Planning_library.forecast_v17 import road_continuation
        waypoint = NS(transform=NS(location=NS(x=10., y=0.), rotation=NS(yaw=0.)),
                      next=lambda distance: [])
        with self.assertRaises(ValueError):
            road_continuation([[0., 0.], [10., 0.]], waypoint)

    def test_recovery_family_covers_returned_motion_and_ignores_private_labels(self):
        from Planning_library.opponent_forecast_v17 import tracks
        rv = NS(x=6.8749986, y=-138., yaw=math.pi, v=1.323136,
                vx=-1.323136, vy=0., ax=-.001327996, ay=0.)
        times = np.arange(0., 3.01, .1)
        family = tracks(rv, times, cruise=4.41202245)
        positions = [track[-1, 0] for track in family]
        actual_x = -1.25736475  # v16 seed5/E4 actor245, frame660 -> frame720
        self.assertLessEqual(min(positions), actual_x)
        self.assertGreaterEqual(max(positions), actual_x)
        rv._dsh_rv_behavior = 'yield'
        for before, after in zip(family, tracks(rv, times, cruise=4.41202245)):
            np.testing.assert_array_equal(before, after)

    def test_common_guard_consumes_recovery_not_only_constant_motion(self):
        from Planning_library.execution_guard import clearance
        from test_forecast_v16 import vehicle
        rv = vehicle(245, x=6.8749986, y=-138., yaw=math.pi, v=1.323136, acc=.001327996)
        ego = vehicle(239, x=-6., y=-138., yaw=math.pi, v=0., acc=0.)
        times = np.arange(0., 3.01, .1)
        states = np.zeros((7, len(times)))
        states[0], states[1], states[6] = ego.x, ego.y, ego.yaw
        old_gap, _ = clearance(states, times, [rv], ego)
        new_gap, identifier = clearance(states, times, [rv], ego, geometry={'forecast_model':'route_v17'})
        self.assertGreater(old_gap, .2)
        self.assertLess(new_gap, 0.)
        self.assertEqual(identifier, 245)

    def test_invalid_coverage_does_not_replace_physical_gap(self):
        from Planning_library.execution_guard import select_execution
        geometry = dict(max_steer=.6, wheelbase=2.7, execution_horizon=6.,
                        forecast_model='route_v17', navigation_end_is_stop=False)
        ego = NS(x=0., y=0., yaw=0., v=4.)
        chosen, audit = select_execution(ego, [], [[0., 0.], [2., 0.]], 4., 0., 0.,
            dict(a=0., df=0.), geometry, prediction=np.zeros((7, 2)),
            prediction_times=np.array([0., .1]))
        for candidate in audit['candidates']:
            self.assertEqual(candidate['gap'], float('inf'))
            self.assertFalse(candidate['safe'])
            self.assertFalse(candidate['forecast_valid'])
        self.assertEqual(chosen['action'], 'brake')

    def test_matrix_guard_and_journal_use_the_same_forecast_revision(self):
        from test_forecast_v16 import vehicle, candidate, OLD, PATH, PREVIOUS
        from Planning_library.forecast_v17 import prediction_geometry
        from Planning_library.forecast_v16 import ForecastRecorder
        from Planning_library.execution_guard import select_execution
        from Planning_library.matrix_turn_game_v17 import MatrixTurnGameV17
        from Tools.validate_matrix_game import validate_matrix_game
        from Tools.validate_forecast_v16 import validate_forecast
        road = np.c_[np.arange(0., 101., .5), np.zeros(202)]
        geometry = prediction_geometry(OLD, road, PATH)
        ego, rv = vehicle(v=0., acc=0.), vehicle(2, 25., 20., math.pi, 4., 0.)
        with tempfile.TemporaryDirectory() as directory:
            game = MatrixTurnGameV17(geometry, directory=directory)
            game.prepare(ego, [rv], dict(rv_veh=rv, conflict_x=0., conflict_y=20.), 4., 1., (100., 0., 0.))
            candidates = [candidate(0., -.3), candidate(4., .1)]
            chosen = game.choose(ego, [rv], rv, {}, candidates, PATH, dict(a=0., df=0.))
            c = candidates[chosen]
            selected, audit = select_execution(ego, [rv], PATH, c['target'], c['a'], 0., dict(a=0., df=0.),
                geometry, prediction=np.zeros((7, 2)), prediction_times=np.array([0., .1]))
            applied = dict(a_cmd=selected['a'], delta_rad=0., actuator_speed_target=selected['target'], control_submit_ok=1)
            game.record(1, 1, c['a'], 0., c['target'], audit, applied)
            ForecastRecorder(directory, geometry).record(1, 1, audit, applied)
            row = dict(episode='1', frame='1', a_mpc=str(c['a']), delta_mpc_rad='0', a_cmd=str(selected['a']),
                delta_rad='0', v_ref=str(selected['target']), actuator_speed_target=str(selected['target']),
                guard_action=audit['action'], mpc_audit_override=str(int(audit['override'])),
                guard_safe=str(int(audit['safe'])), mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10', ego_v='0')
            self.assertTrue(validate_matrix_game(directory, [row], 'matrix_v17')['matrix_contract_ok'])
            self.assertTrue(validate_forecast(directory, [row], revision='route_v17')['forecast_contract_ok'])
            metadata_path = Path(directory)/'forecast_metadata.json'
            metadata = json.loads(metadata_path.read_text())
            metadata['navigation_end_is_stop'] = True
            metadata_path.write_text(json.dumps(metadata))
            self.assertFalse(validate_forecast(directory, [row], revision='route_v17')['forecast_contract_ok'])


if __name__ == '__main__':
    unittest.main()
