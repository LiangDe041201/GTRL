"""Cross-frame driver regression for the CG reference after a spatial action.

Run the actual driver fragments and real MPC solvers, without a CARLA server.
The omitted environment step is replaced only by explicit observed controls.
"""
import ast
import contextlib
import io
from pathlib import Path
from types import SimpleNamespace as S
import unittest

import numpy as np
from Planning_library.control_path_v15 import ControlExperimentV15, path_hash
from Planning_library.matrix_turn_game import solve_candidates
from Planning_library.road_corridor_v24 import RoadCorridorV24
import test_rolling_planner_v24 as fixtures


def driver_fragments():
    path = Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
    tree = ast.parse(path.read_text(encoding='utf8'))
    frame = next(n for n in ast.walk(tree) if isinstance(n, ast.While) and any(
        isinstance(s, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '_new_trajectory'
                                        for t in s.targets) for s in n.body))
    after_observation = next(i+1 for i, n in enumerate(frame.body) if isinstance(n, ast.Expr)
        and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Attribute)
        and n.value.func.attr == 'spectator_update')
    new_path = next(n for n in frame.body if isinstance(n, ast.If)
                   and isinstance(n.test, ast.Name) and n.test.id == '_new_trajectory')
    prefix = frame.body[after_observation:frame.body.index(new_path)]
    reset_start = next(i for i, n in enumerate(new_path.body) if isinstance(n, ast.Expr)
        and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Attribute)
        and n.value.func.attr == 'condition')
    reset_end = next(i for i in range(reset_start+1, len(new_path.body))
                     if isinstance(new_path.body[i], ast.If) and isinstance(new_path.body[i].test, ast.Compare))
    # Stop at the unrelated belief-learning branch after the path reset.
    reset = new_path.body[reset_start:reset_end]
    blocks = [n for n in ast.walk(tree) if isinstance(n, ast.If) and any(
        isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id == 'solve_candidates'
        for c in ast.walk(n))]
    dispatch = [min(blocks, key=lambda n: len(list(ast.walk(n))))]
    return [compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec')
            for nodes in (prefix, reset, dispatch)]


class RollingReferenceTests(unittest.TestCase):
    def frame(self, code, ns):
        with contextlib.redirect_stdout(io.StringIO()):
            exec(code, ns)

    def fixture(self, phase='train'):
        p, f = fixtures.RollingPlannerTests().fixture(phase)
        dynamic, cs, game = f[1], f[2], f[4]
        primary, peer = cs[1]['controller'], cs[0]['controller']
        path = primary.last_pathway.copy()
        stub = S(dynamic_map=dynamic, trajectory_probe=p,
            control_experiment=ControlExperimentV15('CG', True, 'paper_v11'),
            env=S(goal_pose=(-21., -138.5, 3.14), INTERSECTION_CENTER=(6., -138.)),
            turn_feasibility=S(last={}))
        ns = dict(self=stub, mpc_controller=primary, matrix_peer=peer, matrix_game=game,
            v_ref=4., _sd=14., road_right=False, hybrid_action=1,
            used_trajectory=S(trajectory=path.copy()),
            _conf=dict(rv_veh=dynamic.objects[0], conflict_x=6., conflict_y=-138.),
            _previous_control=dict(primary.last_u), solve_candidates=solve_candidates)
        return p, f, ns, path, driver_fragments()

    def test_return_to_action_zero_without_new_upper_trajectory_restores_original_cg_path(self):
        p, f, ns, nominal, (start, reset, dispatch) = self.fixture()
        self.frame(start, ns)
        self.frame(reset, ns)
        self.frame(dispatch, ns)
        self.assertNotEqual(p.last['actual_action'], 0)
        self.assertNotEqual(path_hash(ns['mpc_controller'].last_pathway), path_hash(nominal))
        # No new upper trajectory: a rejected held candidate must return to true CG.
        applied = dict(a_cmd=.25, delta_rad=.02, actuator_speed_target=4.,
                       ego_v_after=2., control_submit_ok=1)
        ns['mpc_controller'].acknowledge_applied_control(.25, .02)
        ns['matrix_peer'].acknowledge_applied_control(.25, .02)
        p.acknowledge(.25, .02)
        p.feedback(1, 1, dict(action='mpc', override=False, unavoidable=False), applied)
        p.corridor = RoadCorridorV24(lambda x, y: None, [(1, 0, -1)], [])
        self.frame(start, ns)
        self.assertFalse(ns['_new_trajectory'])
        self.assertEqual(ns['mpc_controller'].last_u, dict(a=.25, df=.02))
        np.testing.assert_array_equal(ns['mpc_controller'].last_pathway, nominal)
        ns['_previous_control'] = dict(ns['mpc_controller'].last_u)
        self.frame(dispatch, ns)
        self.assertEqual(p.last['actual_action'], 0)
        self.assertEqual(p.last['baseline_path_hash'], path_hash(nominal))
        np.testing.assert_array_equal(ns['mpc_controller'].last_pathway, nominal)

    def test_new_upper_path_replaces_saved_cg_reference_after_previous_variant(self):
        p, f, ns, nominal, (start, reset, dispatch) = self.fixture()
        self.frame(start, ns); self.frame(reset, ns); self.frame(dispatch, ns)
        self.assertNotEqual(p.last['actual_action'], 0)
        replacement = nominal + np.array([.1, 0.])
        self.frame(start, ns)
        ns['used_trajectory'] = S(trajectory=replacement.copy())
        self.frame(reset, ns)
        self.frame(dispatch, ns)
        self.frame(start, ns)
        np.testing.assert_array_equal(ns['mpc_controller'].last_pathway, replacement)

    def test_observe_frames_keep_cg_geometry_controls_and_warm_start(self):
        p, f, ns, nominal, (start, reset, dispatch) = self.fixture('observe')
        self.frame(start, ns); self.frame(reset, ns); self.frame(dispatch, ns)
        primary = ns['mpc_controller']
        previous, warm = dict(primary.last_u), primary._warm_controls.copy()
        self.frame(start, ns)
        np.testing.assert_array_equal(primary.last_pathway, nominal)
        np.testing.assert_array_equal(primary._warm_controls, warm)
        self.assertEqual(primary.last_u, previous)

    def test_variant_warm_start_cannot_replace_cg_memory_or_real_control_history(self):
        p, f, ns, nominal, (start, reset, dispatch) = self.fixture()
        self.frame(start, ns); self.frame(reset, ns); self.frame(dispatch, ns)
        expected = p._base['controller']._warm_controls.copy()
        active = ns['mpc_controller']
        active._warm_controls = np.full_like(expected, 9.)
        active._previous_observed_speed = 99.
        active._solve_ok = False
        active.acknowledge_applied_control(.2, .01)
        self.frame(start, ns)
        np.testing.assert_array_equal(active._warm_controls, expected)
        self.assertEqual(active.last_u, dict(a=.2, df=.01))
        self.assertNotEqual(active._previous_observed_speed, 99.)
        self.assertTrue(active._solve_ok)
        p.reset(); active.reset_controller(); self.frame(start, ns)
        self.assertIsNone(active.last_pathway)


if __name__ == '__main__':
    unittest.main()
