"""Driving summaries distinguish initial standstill, collisions and mechanisms."""
import contextlib
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest

from Tools.summarize_matrix_comparison import episode_metrics, main, summarize
from Tools.validate_matrix_game import validate_matrix_game
from Tools.run_relay_validation import main as relay_main


def csv_file(path, rows):
    with path.open('w',newline='',encoding='utf8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


class TestDrivingSummary(unittest.TestCase):
    def test_fractional_targets_respect_both_csv_precisions_and_detect_real_mismatch(self):
        # Real v13 episode 1/frame 137: the old tolerance falsely rejected it.
        target=2.8307578640832483
        record=dict(revision='matrix_entry_v13',controller='matrix_v13',authority='matrix_entry',
            episode=1,frame=137,pure_nash=None,selected=1,control_submit_ok=1,active=True,
            pre_audit_a=.1,pre_audit_delta=0.,pre_audit_target=target,
            applied_a=.1,applied_delta=0.,applied_target=target,
            guard_action='mpc',guard_override=False,payoff_matrix=[[0.,0.],[1.,1.]],
            rv_payoff_matrix=[[0.,0.],[-1.,-1.]],p_yield=.5,u_wait=0.,u_go=1.,
            decision_mode='expected_response',candidate_targets=[0.,target],candidate_a=[-.1,.1],
            switch=False,decision_ms=1.)
        row=dict(episode='1',frame='137',a_mpc='.1',delta_mpc_rad='0',a_cmd='.1',
            delta_rad='0',v_ref='2.831',actuator_speed_target='2.830758',guard_action='mpc',
            mpc_audit_override='0',mpc_game_enabled='0',rl_active='0',mpc_solve_ms='10',ego_v='2')
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder)/'matrix_decisions.jsonl').write_text(json.dumps(record)+'\n',encoding='utf8')
            self.assertTrue(validate_matrix_game(folder,[row],'matrix_v13')['matrix_contract_ok'])
            for field,value,error in (
                ('v_ref','2.832','control_link_v_ref'),
                ('actuator_speed_target','2.831758','control_link_applied_target'),
                ('actuator_speed_target','nan','control_link_applied_target')):
                with self.subTest(field=field,value=value):
                    changed=dict(row);changed[field]=value
                    result=validate_matrix_game(folder,[changed],'matrix_v13')
                    self.assertFalse(result['matrix_contract_ok'])
                    self.assertEqual(result['matrix_contract_errors'][error],1)

    def test_initial_standstill_and_goal_stop_do_not_become_entry_wait(self):
        def row(v,sd=10.,goal=20.):
            return dict(ego_v=str(v),wait_standoff=str(sd),goal_remaining=str(goal),
                        mpc_audit_override='0',ego_acc_measured='0',mpc_l='0')
        rows=[row(0.)]*25+[row(2.),row(0.),row(0.),row(0.,-1.),row(0.,-2.,2.)]
        result=episode_metrics(rows,dict(episode='1',outcome='complete'))
        self.assertAlmostEqual(result['entry_wait_s'],.1)
        self.assertAlmostEqual(result['non_goal_stop_s'],.15)
        self.assertEqual(result['non_goal_stop_events'],1)

    def test_remote_paths_resolve_locally_and_smoke_stops_on_collision(self):
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            root=Path(folder);run=root/'M1_matrix_seed1';run.mkdir()
            manifest=dict(runs=[dict(arm='M1_matrix',seed=1,directory='/foreign/host/never/read',status='complete')])
            (root/'manifest.json').write_text(json.dumps(manifest))
            (run/'result.json').write_text(json.dumps(dict(matrix_active_rows=5)))
            rows=[dict(episode=str(i),frame='1',ego_v='2',wait_standoff='10',goal_remaining='20',
                mpc_audit_override='0',ego_acc_measured='0',mpc_l='0') for i in range(1,6)]
            episodes=[dict(episode=str(i),outcome='complete') for i in range(1,6)]
            csv_file(run/'interaction_ego.csv',rows);csv_file(run/'interaction_summary.csv',episodes)
            self.assertEqual(main([str(root),'--require-matrix-smoke']),0)
            episodes[-1]['outcome']='collision';csv_file(run/'interaction_summary.csv',episodes)
            self.assertEqual(main([str(root),'--require-matrix-smoke']),8)
            self.assertEqual(summarize(root)['groups']['M1_matrix']['success'],4)
            self.assertTrue((root/'comparison.json').is_file())

    def test_missing_or_non_object_matrix_records_fail_without_hiding_coverage(self):
        with tempfile.TemporaryDirectory() as folder:
            rows=[dict(episode='1',frame='1')]
            result=validate_matrix_game(folder,rows,'matrix_v13')
            self.assertFalse(result['matrix_contract_ok'])
            (Path(folder)/'matrix_decisions.jsonl').write_text('[]\nnot json\n')
            result=validate_matrix_game(folder,rows,'matrix_v13')
            self.assertEqual(result['matrix_contract_errors']['invalid_json'],2)
            self.assertFalse(result['matrix_contract_ok'])

    def test_matrix_arms_keep_explicit_authority_and_reject_unsupported_actuator(self):
        with contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(relay_main(['--dry-run','--arms','M0_legacy_matrix,M1_matrix']),0)
        configs=[json.loads(line)['effective'] for line in out.getvalue().splitlines()]
        self.assertTrue(all(c['DSH_COURNOT_AUTHORITY']=='matrix_entry' for c in configs))
        self.assertEqual({k for k in configs[0] if configs[0][k]!=configs[1][k]}, {'DSH_COURNOT_MODE'})
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            relay_main(['--dry-run','--arms','M1_matrix','--control-profile','paper_v9'])


if __name__=='__main__':
    unittest.main()
