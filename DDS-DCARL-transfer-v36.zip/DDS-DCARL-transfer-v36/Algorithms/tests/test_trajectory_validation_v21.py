"""The recorded proposal must match the actual selected controls, not just a label."""
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest

from Planning_library.execution_guard import select_execution
from Planning_library.trajectory_guard import execution_acceleration


class TrajectoryValidationTests(unittest.TestCase):
    def validator(self):
        try:
            from Tools.validate_trajectory_probe_v21 import validate_probe_record
        except ImportError:
            self.fail('There is no independent trajectory proposal/execution validator')
        return validate_probe_record

    def evidence(self):
        from test_trajectory_probe_v21 import TrajectoryProbeTests
        fixture = TrajectoryProbeTests().fixture('proceed')
        probe, dynamic, cs, baseline, game, seed, controllers = fixture
        with contextlib.redirect_stdout(io.StringIO()):
            output = probe.propose(dynamic, cs, baseline, game.last, seed, False, (6., -138.))
        chosen = output[baseline]
        a = execution_acceleration(chosen['a'], dynamic.ego_vehicle.v, chosen['target'])
        applied, audit = select_execution(dynamic.ego_vehicle, dynamic.objects, cs[1]['controller'].last_pathway,
            chosen['target'], a, chosen['delta'], seed['previous'], probe.geometry,
            prediction=chosen['prediction'], prediction_times=chosen['times'], plan=chosen['plan'])
        row = copy.deepcopy(game.last)
        row.update(trajectory_probe=copy.deepcopy(probe.last), episode=1, frame=1,
            pre_audit_a=chosen['a'], pre_audit_delta=chosen['delta'], pre_audit_target=chosen['target'],
            applied_a=applied['a'], applied_delta=applied['delta'], applied_target=applied['target'],
            guard_action=audit['action'], guard_override=audit['override'], guard_safe=audit['safe'],
            control_submit_ok=1)
        ego = dict(episode='1', frame='1', a_mpc=str(chosen['a']), delta_mpc_rad=str(chosen['delta']),
            a_cmd=str(applied['a']), delta_rad=str(applied['delta']),
            actuator_speed_target=str(round(applied['target'], 6)), v_ref=str(round(applied['target'], 3)),
            guard_action=audit['action'], mpc_audit_override=str(int(audit['override'])),
            mpc_game_enabled='0', rl_active='0', mpc_solve_ms='10', ego_v='2',
            a_prev=str(seed['previous']['a']), steer_prev=str(seed['previous']['df']))
        return row, ego

    def test_real_mpc_probe_record_links_to_the_applied_control(self):
        validate = self.validator()
        row, ego = self.evidence()
        self.assertTrue(row['trajectory_probe']['changed_request'])
        self.assertEqual(validate(row, ego, 'proceed'), {})

    def test_previous_control_respects_the_actual_logger_three_decimal_format(self):
        from Planning_library.interaction_logger import _r
        validate = self.validator()
        row, ego = self.evidence()
        row['trajectory_probe']['previous'] = dict(a=.619499435074006, df=-.11849995483494412)
        ego['a_prev'] = str(_r(.619499435074006))
        ego['steer_prev'] = str(_r(-.11849995483494412))
        self.assertEqual(validate(row, ego, 'proceed'), {})

    def test_incorrect_rounded_history_is_still_rejected(self):
        validate = self.validator()
        row, ego = self.evidence()
        row['trajectory_probe']['previous']['a'] = .619499435074006
        ego['a_prev'] = '.620'
        self.assertIn('applied_history', validate(row, ego, 'proceed'))

    def test_nonfinite_previous_control_display_is_rejected(self):
        validate = self.validator()
        row, ego = self.evidence()
        ego['a_prev'] = 'nan'
        self.assertIn('applied_history', validate(row, ego, 'proceed'))

    def test_full_precision_json_history_detects_changes_below_csv_resolution(self):
        from Tools.validate_matrix_game import validate_matrix_game
        row, ego = self.evidence()
        second, second_ego = copy.deepcopy(row), dict(ego)
        second['frame'] = 2
        second_ego['frame'] = '2'
        second['trajectory_probe']['previous'] = dict(a=row['applied_a'], df=row['applied_delta'])
        second_ego.update(a_prev=str(round(row['applied_a'], 3)),
                          steer_prev=str(round(row['applied_delta'], 3)))
        with tempfile.TemporaryDirectory() as d:
            path = Path(d, 'matrix_decisions.jsonl')
            path.write_text(json.dumps(row)+'\n'+json.dumps(second)+'\n', encoding='utf8')
            good = validate_matrix_game(d, [ego, second_ego], 'matrix_v18', expected_probe='proceed')
            self.assertTrue(good['matrix_contract_ok'], good)
            second['trajectory_probe']['previous']['df'] += .00001
            path.write_text(json.dumps(row)+'\n'+json.dumps(second)+'\n', encoding='utf8')
            bad = validate_matrix_game(d, [ego, second_ego], 'matrix_v18', expected_probe='proceed')
            self.assertIn('trajectory_probe_applied_history_exact', bad['matrix_contract_errors'])

    def test_a_request_cannot_claim_an_unlisted_trajectory(self):
        validate = self.validator()
        row, ego = self.evidence()
        row['trajectory_probe']['request_id'] = 'unpredicted_path'
        self.assertTrue(validate(row, ego, 'proceed'))

    def test_modified_actual_control_does_not_pass_as_a_probe_choice(self):
        validate = self.validator()
        row, ego = self.evidence()
        row['pre_audit_a'] += .1
        self.assertTrue(validate(row, ego, 'proceed'))

    def test_the_same_record_cannot_be_mislabelled_as_observe(self):
        validate = self.validator()
        row, ego = self.evidence()
        row['trajectory_probe']['mode'] = 'observe'
        self.assertTrue(validate(row, ego, 'observe'))

    def test_guard_rejection_cannot_be_relabelled_as_eligible(self):
        validate = self.validator()
        row, ego = self.evidence()
        selected = next(r for r in row['trajectory_probe']['candidates']
                        if r['id']==row['trajectory_probe']['request_id'])
        selected['execution']['accepted'] = False
        self.assertTrue(validate(row, ego, 'proceed'))

    def test_common_matrix_audit_checks_frozen_payoff_and_new_request_separately(self):
        self.validator()
        from Tools.validate_matrix_game import validate_matrix_game
        row, ego = self.evidence()
        with tempfile.TemporaryDirectory() as d:
            Path(d, 'matrix_decisions.jsonl').write_text(json.dumps(row)+'\n', encoding='utf8')
            report = validate_matrix_game(d, [ego], 'matrix_v18', expected_probe='proceed')
            self.assertTrue(report['matrix_contract_ok'], report)
            self.assertTrue(report['trajectory_probe_contract_ok'], report)
            self.assertIn('trajectory_probe_generated_variants', report)
            self.assertEqual(report['trajectory_probe_generated_variants'], 2)
            self.assertEqual(report['trajectory_probe_eligible_variants'], 2)
            self.assertEqual(report['trajectory_probe_active_rows'], 1)
            self.assertEqual(report['trajectory_probe_changed_requests'], 1)
            row['payoff_matrix'][0][0] += 1.
            Path(d, 'matrix_decisions.jsonl').write_text(json.dumps(row)+'\n', encoding='utf8')
            self.assertFalse(validate_matrix_game(d, [ego], 'matrix_v18',
                                                 expected_probe='proceed')['matrix_contract_ok'])


if __name__ == '__main__':
    unittest.main()
