"""The real CLI/driver must opt into diagnostics, with reward modes blocked."""
import ast
import contextlib
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace as S
import unittest
from unittest.mock import patch

from Tools.run_relay_validation import main,ARMS
from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner


class EFEDispatchTests(unittest.TestCase):
    def config(self,args):
        output=io.StringIO()
        with contextlib.redirect_stdout(output): self.assertEqual(main(['--dry-run','--traffic-interaction','v17']+args),0)
        return json.loads(output.getvalue())['effective']

    def test_new_arm_is_shadow_training_and_existing_training_keeps_efe_off(self):
        self.assertIn('T4_efe_shadow_v27',ARMS,'Shadow diagnostics are not exposed by the runner')
        with contextlib.redirect_stderr(io.StringIO()):
            c=self.config(['--arms','T4_efe_shadow_v27','--road-audit','local_v26'])
        self.assertEqual(c['DSH_ROLLING_EFE_MODE'],'shadow')
        self.assertEqual(c['DSH_ROLLING_PHASE'],'train')
        self.assertEqual((c['DSH_EFE'],c['DSH_COURNOT_MODE']),('0','matrix_v18'))
        old=self.config(['--arms','T2_train_v24'])
        self.assertEqual(old['DSH_ROLLING_EFE_MODE'],'off')

    def test_shadow_on_a_nonrolling_owner_and_unimplemented_reward_mode_are_rejected(self):
        for args in (['--arms','M6_matrix_v18','--rolling-efe-mode','shadow'],
                     ['--arms','T2_train_v24','--rolling-efe-mode','reward']):
            with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit): self.config(args)

    def test_driver_constructs_only_the_requested_rolling_owner(self):
        tree=ast.parse((Path(__file__).resolve().parents[1]/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf8'))
        block=next(n for n in ast.walk(tree) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='_rolling_phase')
        for mode,expected in (('off','normal'),('shadow','shadow')):
            stub=S(env=S(map=object(),ego_vehicle=S(get_location=lambda:S(z=0.))))
            ns=dict(self=stub,os=os,_rolling_phase='train',_prediction_geometry={'forecast_route':[[0.,0.],[1.,0.]]},
                _probe_controllers=[object()]*5,MODEL_DIR='unused',matrix_game=S(cruise=4.4),
                LocalRoadCorridorV26=S(from_carla=lambda *a,**kw:S()),RoadCorridorV24=S(from_carla=lambda *a,**kw:S()),
                RollingPlannerV24=lambda *a,**kw:S(owner='normal'),
                RollingShadowPlannerV27=lambda *a,**kw:S(owner='shadow'))
            # Exercise the real dispatcher, then substitute only construction.
            ns['select_rolling_planner']=lambda revision,mode: ns[select_rolling_planner(revision,mode).__name__]
            with patch.dict(os.environ,dict(DSH_ROAD_AUDIT='local_v26',DSH_EFE='0',DSH_ROLLING_EFE_MODE=mode)):
                with patch.dict('sys.modules',{'carla':S(Location=S,LaneType=S(Driving='Driving'))}):
                    exec(compile(ast.Module(body=[block],type_ignores=[]),'<real rolling owner setup>','exec'),ns)
            self.assertEqual(stub.trajectory_probe.owner,expected)


if __name__=='__main__': unittest.main()
