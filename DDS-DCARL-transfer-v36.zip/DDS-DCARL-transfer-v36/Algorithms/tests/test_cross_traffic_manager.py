import importlib.util
import math
import os
import pathlib
import sys
import types
import unittest


# Provide a minimal stub for the carla module so the scenario module can be imported
# in a plain test environment.
carla_stub = types.ModuleType("carla")
carla_stub.LaneType = types.SimpleNamespace(Driving="Driving")
carla_stub.Location = lambda x=0.0, y=0.0, z=0.0: types.SimpleNamespace(x=x, y=y, z=z)
carla_stub.Rotation = lambda yaw=0.0: types.SimpleNamespace(yaw=yaw)
carla_stub.Transform = lambda location=None, rotation=None: types.SimpleNamespace(location=location, rotation=rotation)
carla_stub.Vector3D = lambda x=0.0, y=0.0, z=0.0: types.SimpleNamespace(x=x, y=y, z=z)
carla_stub.VehicleControl = lambda: None
sys.modules.setdefault("carla", carla_stub)


class DummyBlueprint:
    def __init__(self):
        self.attrs = {}

    def has_attribute(self, name):
        return name in self.attrs

    def set_attribute(self, name, value):
        self.attrs[name] = value


class DummyBlueprintLibrary:
    def filter(self, _name):
        return [DummyBlueprint()]


class DummyWorld:
    def __init__(self):
        self._spawned = []

    def get_blueprint_library(self):
        return DummyBlueprintLibrary()

    def get_actors(self, ids=None):
        """run_step 用 get_actors(managed_ids) 取存活车辆；无 id 时返回已生成车辆。"""
        if ids is None:
            return []
        return []

    def try_spawn_actor(self, bp, transform):
        actor = DummySpawnedVehicle(len(self._spawned) + 1, transform)
        self._spawned.append(actor)
        return actor


class DummySpawnedVehicle:
    """spawn_one_vehicle 生成的车流车辆（最小接口）。"""

    def __init__(self, vid, transform=None):
        self.id = vid
        self.is_alive = True
        self.is_active = True
        self.transform = transform or carla_stub.Transform(carla_stub.Location(x=20., y=-138.),
                                                        carla_stub.Rotation(yaw=180.))
        self.bounding_box = DummyBoundingBox()
        self.velocity = carla_stub.Vector3D()

    def set_target_velocity(self, _v):
        self.velocity = _v

    def get_location(self):
        return self.transform.location

    def get_transform(self):
        return self.transform

    def get_velocity(self):
        return self.velocity

    def destroy(self):
        self.is_alive = self.is_active = False


class DummyBoundingBox:
    def __init__(self, length=3.6, offset=0.):
        self.length, self.offset = length, offset

    def get_world_vertices(self, transform):
        yaw = math.radians(transform.rotation.yaw)
        return [types.SimpleNamespace(
            x=transform.location.x+math.cos(yaw)*(x+self.offset)-math.sin(yaw)*y,
            y=transform.location.y+math.sin(yaw)*(x+self.offset)+math.cos(yaw)*y, z=z)
            for x in (-self.length/2., self.length/2.) for y in (-.8, .8) for z in (0., 1.)]


class DummyMap:
    def get_waypoint(self, location, project_to_road=True, lane_type=None):
        class DummyWaypoint:
            def __init__(self, loc):
                self.transform = types.SimpleNamespace(location=loc)
        return DummyWaypoint(location)


class DummyVehicle:
    def __init__(self, x, y=-138.0):
        self._x = x
        self._y = y

    def get_location(self):
        return types.SimpleNamespace(x=self._x, y=self._y, z=0.3)

    def get_velocity(self):
        return types.SimpleNamespace(x=5.0, y=0.0, z=0.0)


def load_module():
    module_path = pathlib.Path(__file__).resolve().parents[1] / "Test_Scenarios" / "cross_traffic_manager.py"
    spec = importlib.util.spec_from_file_location("cross_traffic_manager", module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class CrossTrafficManagerTests(unittest.TestCase):
    """车流生成门控（当前实现：ego 距路口 < 30m 才启动 + 按仿真帧间隔生成）。"""

    def test_no_spawn_before_ego_near_intersection(self):
        module = load_module()
        manager = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=10, flow_volume=0.4)
        far_ego = DummyVehicle(manager.cross_start.location.x + 100)

        manager.run_step(far_ego)

        self.assertFalse(manager._ego_near_intersection)
        self.assertEqual(manager._spawned_count, 0)

    def test_spawn_starts_when_ego_near_intersection(self):
        module = load_module()
        manager = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=10, flow_volume=0.4)
        # 距路口中心 (6.0, -138.0) < 30m
        near_ego = DummyVehicle(6.0 + 10.0)

        # 首车受 first_delay_frames（按 ego 预计到达时间对齐）延迟，故需推进若干帧
        spawned_at = None
        for f in range(1, manager._spawn_interval_frames + 10):
            manager.run_step(near_ego)
            if manager._spawned_count > 0:
                spawned_at = f
                break

        self.assertTrue(manager._ego_near_intersection)
        self.assertIsNotNone(spawned_at, "ego 进入 30m 后应触发车流生成")
        self.assertLessEqual(manager._spawned_count, manager._max_vehicles)

    def test_spawn_respects_interval(self):
        """首次生成后，在 _spawn_interval_frames-1 帧内不会再次生成（等间距车流）。"""
        module = load_module()
        manager = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=10, flow_volume=0.4)
        near_ego = DummyVehicle(6.0 + 10.0)

        for _ in range(manager._spawn_interval_frames + 10):
            manager.run_step(near_ego)
            if manager._spawned_count > 0:
                break
        first = manager._spawned_count
        self.assertEqual(first, 1)

        for _ in range(max(1, manager._spawn_interval_frames - 1)):
            manager.run_step(near_ego)

        self.assertEqual(manager._spawned_count, first)


    def test_yield_target_scales_with_cruise_speed(self):
        """【P1-d】让行目标 = 0.3×巡航速度，且与巡航有足够差速（否则间隙张不开）。"""
        module = load_module()
        m = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=6.0)
        self.assertAlmostEqual(m.rv_yield_target, 0.3 * m.rv_cruise_speed, places=6)
        # 让行必须与巡航有 >2 m/s 的差速（旧默认 3.0 m/s 在巡航 4.41 时只差 1.4 → 窗口太紧）
        self.assertGreater(m.rv_cruise_speed - m.rv_yield_target, 2.0)

    def test_yield_speed_env_override(self):
        os.environ['DSH_RV_YIELD_SPEED'] = '2.5'
        try:
            module = load_module()
            m = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=6.0)
            self.assertAlmostEqual(m.rv_yield_target, 2.5, places=6)
        finally:
            os.environ.pop('DSH_RV_YIELD_SPEED', None)

    def test_yield_propagation_default_on(self):
        module = load_module()
        m = module.CrossTrafficManager(DummyWorld(), DummyMap(), traffic_v=6.0)
        self.assertEqual(m.yield_propagate, 1)
        self.assertEqual(m.committed_yield, 'rear')

    def test_stuck_threshold_default_40s(self):
        """【P1-c】卡死判定默认放宽到 40 仿真秒（等整列车流离开是合法策略）。"""
        import inspect
        import pathlib as _pl
        src = (_pl.Path(__file__).resolve().parents[1] / "Test_Scenarios"
               / "TestScenario_Town03_turn.py").read_text()
        self.assertIn("DSH_STUCK_SEC", src)
        self.assertIn("'40.0'", src)


if __name__ == '__main__':
    unittest.main()
