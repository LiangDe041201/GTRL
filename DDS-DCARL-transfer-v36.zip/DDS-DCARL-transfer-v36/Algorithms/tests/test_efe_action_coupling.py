"""Execute the production EFE adapter without importing the CARLA runtime."""
import ast
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from Planning_library.active_inference import efe_by_action, lateral_arc_correction
from Planning_library.rv_decision import rv_yield_probability, time_to_cover
from Planning_library.type_inference import TypeInference


def _adapter_class():
    source = ROOT / 'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py'
    tree = ast.parse(source.read_text(encoding='utf-8-sig'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'DCARL_Turn')
    body = [n for n in cls.body if (
        isinstance(n, ast.FunctionDef) and n.name == '_efe_by_action') or (
        isinstance(n, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id.startswith('EFE_') for t in n.targets))]
    namespace = dict(math=math, N_ACTIONS=12, ACTION_MODE='2d',
                     action_speed=lambda a: (0.0, 2.0, 4.0, 6.0)[a // 3],
                     action_lateral=lambda a: (-1.5, 0.0, 1.5)[a % 3],
                     efe_by_action=efe_by_action, lateral_arc_correction=lateral_arc_correction,
                     rv_yield_probability=rv_yield_probability, time_to_cover=time_to_cover)
    isolated = ast.Module(body=[ast.ClassDef(
        name='Adapter', bases=[], keywords=[], body=body, decorator_list=[])], type_ignores=[])
    exec(compile(ast.fix_missing_locations(isolated), str(source), 'exec'), namespace)
    return namespace['Adapter']


class TestEfeActionCoupling(unittest.TestCase):
    def setUp(self):
        self.agent = _adapter_class()()
        self.agent.dynamic_map = SimpleNamespace(ego_vehicle=SimpleNamespace(x=6., y=-130., v=1.))
        self.agent.type_inf = TypeInference()
        self.agent.efe_lateral = True
        self.agent.efe_action_coupling = True
        self.agent.efe_sigma = .35
        self.agent.efe_w_cognition = self.agent.efe_w_behavior = 1.
        self.agent.info_w = self.agent.w_action_entropy = 0.
        self.agent._heading_change_ego_to_conflict = lambda conf: .8
        self.agent._info_cardinality = lambda: 1.
        self.agent._rv_action_entropy = lambda: 0.
        self.conf = dict(committed=False, n_vehicles=1,
                         rv_veh=SimpleNamespace(x=25., v=4.41),
                         arc_to_cross=12., conflict_x=4., conflict_y=-138.,
                         t_ego=8., ttc_boundary=3., rv_acc=0., rv_acc_follow=2.)

    def test_opponent_prediction_uses_each_candidate_arrival_time(self):
        self.agent._efe_by_action(self.conf)
        diagnostics = self.agent._efe_last
        self.assertTrue(diagnostics['active'], diagnostics)
        ego = dict(x=6., y=-130., v=1.)
        rv = dict(x=25., y=-138., v=4.41, vx=-4.41)
        for action, te in diagnostics['t_ego'].items():
            for tau, theta in self.agent.type_inf.types.items():
                expected = rv_yield_probability(ego, rv, 4., 3., theta=theta,
                                               acc_current=0., acc_follow=2., t_ego=te)
                self.assertAlmostEqual(diagnostics['yield_prob'][action][tau], expected)
        probabilities = diagnostics['yield_prob']
        self.assertGreater(abs(probabilities[4]['normal'] - probabilities[10]['normal']), .01)

    def test_legacy_switch_retains_shared_arrival_prediction(self):
        self.agent.efe_action_coupling = False
        self.agent._efe_by_action(self.conf)
        probabilities = list(self.agent._efe_last['yield_prob'].values())
        self.assertTrue(all(p == probabilities[0] for p in probabilities))

    def test_inactive_interaction_clears_lateral_diagnostics(self):
        self.agent._efe_by_action(self.conf)
        self.assertEqual(self.agent._last_efe_dpsi, .8)
        rewards = self.agent._efe_by_action(dict(self.conf, committed=True))
        self.assertTrue(all(r == 0. for r in rewards.values()))
        self.assertFalse(self.agent._efe_last['active'])
        self.assertIsNone(self.agent._last_efe_dpsi)

    def test_stopped_candidates_remain_finite_rewards(self):
        rewards = self.agent._efe_by_action(self.conf)
        self.assertTrue(all(math.isfinite(r) and r <= 0. for r in rewards.values()))
        self.assertTrue(math.isinf(self.agent._efe_last['t_ego'][1]))


if __name__ == '__main__':
    unittest.main()
