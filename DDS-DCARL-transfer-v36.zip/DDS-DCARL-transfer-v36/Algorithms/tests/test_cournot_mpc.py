"""Actual optimizer/control dispatch regressions for the continuous CG path."""
import ast
import math
from pathlib import Path
import sys
from types import SimpleNamespace as S
import unittest
from unittest.mock import Mock

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Planning_library.cournot_mpc import (
    game_configuration, stage_cost, validate_cost_parameters,
    observed_game_vehicles, vehicle_forecast)
from Planning_library.scenario_snapshot import VehicleState
from Planning_library.trajectory_guard import execution_acceleration

try:
    import casadi as ca
except ImportError:
    ca = None


class TestGameInputs(unittest.TestCase):
    def test_methods_have_separate_control_authority(self):
        for method in ('GTRL', 'CG'):
            self.assertTrue(game_configuration(method)['mpc'])
            self.assertFalse(game_configuration(method)['stackelberg'])
            self.assertFalse(game_configuration(method, False)['mpc'])
        self.assertTrue(game_configuration('SG')['stackelberg'])
        self.assertFalse(game_configuration('SG')['learning'])
        self.assertEqual(game_configuration('RULE')['controller'], 'none')
        self.assertTrue(game_configuration('CG', mode='discrete')['discrete'])
        for method, mode in [('typo', 'mpc'), ('CG', 'typo')]:
            with self.assertRaises(ValueError):
                game_configuration(method, mode=mode)

    def test_selected_snapshot_identity_and_missing_roles(self):
        rv = VehicleState(veh_id=42, x=8., y=0., vx=-2., vy=0., yaw=math.pi, v=2.)
        conf = dict(rv_veh=rv, fv_veh=None, arc_to_cross=8., committed=False)
        self.assertEqual(observed_game_vehicles(conf), (rv, None))
        conf['fv_veh'] = rv
        self.assertEqual(observed_game_vehicles(conf), (rv, None))
        conf['committed'] = True
        self.assertEqual(observed_game_vehicles(conf), (None, None))
        conf.update(committed=False, arc_to_cross=16.)
        self.assertEqual(observed_game_vehicles(conf), (None, None))

    def test_forecast_uses_measured_components_and_actual_dimensions(self):
        vehicle = S(x=8., y=3., yaw=math.pi, vx=-2., vy=.1, v=2., length=3.6, width=1.8)
        forecast = vehicle_forecast(vehicle, 3, .1)
        self.assertAlmostEqual(forecast[2][0], 7.6)
        self.assertAlmostEqual(forecast[2][1], 3.02)
        self.assertEqual(forecast[2][3:], [3.6, 1.8])
        vehicle.vx = float('nan')
        with self.assertRaises(ValueError):
            vehicle_forecast(vehicle, 3, .1)

    def test_invalid_cost_configuration_is_visible(self):
        for weights in ((1., -1., .3), (1., float('nan'), .3), (1., 2.)):
            with self.assertRaises(ValueError):
                validate_cost_parameters(weights, 1.5, .5, .3, 'deficit')
        with self.assertRaises(ValueError):
            validate_cost_parameters((1., 2., .3), 1.5, .5, .3, 'unknown')

    def test_production_dispatch_does_not_run_sg_inside_cg_or_gtrl(self):
        tree = ast.parse((ROOT/'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py').read_text(encoding='utf-8'))
        block = next(n for n in ast.walk(tree) if isinstance(n, ast.If)
                     and any(isinstance(x, ast.Attribute) and x.attr == 'game_config'
                             for x in ast.walk(n.test))
                     and any(isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute)
                             and isinstance(x.func.value, ast.Name) and x.func.value.id == 'game_planner'
                             for x in ast.walk(n)))
        for method in ('CG', 'GTRL', 'RULE', 'SG'):
            planner = S(plan=Mock(return_value=1.25))
            agent = S(game_config=game_configuration(method),
                      dynamic_map=S(lanes=[S(rear_vehicles=[object()])]))
            ns = dict(self=agent, game_planner=planner, v_ref=4., _stackelberg_active=False)
            exec(compile(ast.Module(body=[block], type_ignores=[]), '<production SG dispatch>', 'exec'), ns)
            self.assertEqual(ns['_stackelberg_active'], method == 'SG')
            self.assertEqual(planner.plan.call_count, int(method == 'SG'))
            self.assertEqual(ns['v_ref'], 1.25 if method == 'SG' else 4.)


@unittest.skipIf(ca is None, 'Continuous game checks require CasADi')
class TestGameCost(unittest.TestCase):
    def test_eq24_and_left_turn_contracts_are_distinct(self):
        kwargs = dict(speed=3., reference_speed=4., headways=[(1., 1.), (2., 1.)],
                      jerk=1., steering_rate=.4)
        eq = stage_cost(safety_mode='eq24', **kwargs)
        left = stage_cost(safety_mode='deficit', **kwargs)
        self.assertAlmostEqual(float(eq['safety']), 1.)
        self.assertAlmostEqual(float(left['safety']), .5)
        self.assertAlmostEqual(float(left['comfort']), .078)
        self.assertAlmostEqual(float(eq['total']), 2.078)

    def test_missing_participants_are_not_a_fabricated_utility(self):
        terms = stage_cost(8., 3., [(1000., 0.), (1000., 0.)], 2., .9)
        self.assertEqual(float(terms['total']), 0.)

    def test_safe_headway_is_not_penalized_for_exceeding_the_target(self):
        a = stage_cost(3., 3., [(2., 1.)], 0., 0.)
        b = stage_cost(3., 3., [(8., 1.)], 0., 0.)
        self.assertEqual(float(a['total']), 0.)
        self.assertEqual(float(b['total']), 0.)

    def test_symbolic_cost_and_derivatives_depend_on_control(self):
        z = ca.MX.sym('continuous_game_probe', 5)
        terms = stage_cost(z[0], 3., [(z[1], 1.), (z[2], 1.)], z[3], z[4])
        fn = ca.Function('game_gradient', [z], [terms['total'], ca.jacobian(terms['total'], z)])
        value, gradient = fn([2., .5, 1., 1., .5])
        self.assertTrue(math.isfinite(float(value)))
        self.assertTrue(np.isfinite(np.asarray(gradient)).all())
        self.assertTrue(np.all(np.abs(np.asarray(gradient)) > 0.))


@unittest.skipIf(ca is None, 'Optimizer integration checks require CasADi')
class TestGameController(unittest.TestCase):
    def controller(self, enabled):
        from Agent.game_theory.MPC import MPCController
        ego = S(x=0., y=0., yaw=0., v=3.)
        rv = VehicleState(veh_id=42, x=6., y=.7, vx=0., vy=0., yaw=.1, v=0.)
        dynamic = S(ego_vehicle=ego, lanes=[S(front_vehicles=[], rear_vehicles=[rv])])
        controller = MPCController(4, .05, 2.7, .5, enable_lead_follow_cost=False,
                                   enable_cournot_cost=enabled)
        controller.reset_global_path(np.column_stack((np.arange(40.), np.zeros(40))), dynamic)
        controller.last_u = dict(a=0., df=0.)
        conf = dict(rv_veh=rv, fv_veh=None, arc_to_cross=8., committed=False)
        controller.set_game_context(conf, ego)
        return controller, dynamic, conf

    def test_on_off_changes_actual_optimizer_output(self):
        commands = []
        for enabled in (False, True):
            controller, dynamic, _ = self.controller(enabled)
            commands.append(controller.solve(dynamic, 3., False, intersection_center=(0., 10.)))
            self.assertTrue(controller._solve_ok)
            diag = controller.last_game_diag
            self.assertEqual(diag['active'], enabled)
            self.assertEqual(diag['rv_id'], 42 if enabled else None)
            self.assertAlmostEqual(diag['total'], sum(diag[k] for k in ('speed', 'safety', 'comfort')))
        self.assertGreater(float(np.linalg.norm(np.subtract(*commands))), .01)

    def test_both_roles_enter_the_symbolic_objective_and_disappear_cleanly(self):
        controller, dynamic, conf = self.controller(True)
        fv = VehicleState(veh_id=43, x=-6., y=1., vx=-1., vy=0., yaw=math.pi, v=1.)
        conf['fv_veh'] = fv
        controller.set_game_context(conf, dynamic.ego_vehicle)
        self.assertEqual(controller.last_game_diag['fv_id'], 43)
        self.assertTrue(ca.depends_on(controller._game_horizon_terms['total'], controller.x))
        self.assertTrue(ca.depends_on(controller._game_horizon_terms['total'], controller.u))
        controller.set_game_context(None)
        controller.solve(dynamic, 3., False, intersection_center=(0., 10.))
        self.assertTrue(controller._solve_ok)
        self.assertFalse(controller.last_game_diag['active'])
        self.assertIsNone(controller.last_game_diag['rv_id'])
        self.assertIsNone(controller.last_game_diag['fv_id'])
        self.assertAlmostEqual(controller.last_game_diag['total'], 0.)

    def test_game_does_not_override_the_execution_stop_target(self):
        controller, dynamic, _ = self.controller(True)
        acceleration, _ = controller.solve(dynamic, 0., False, intersection_center=(0., 10.))
        self.assertTrue(controller._solve_ok)
        self.assertLessEqual(execution_acceleration(acceleration, dynamic.ego_vehicle.v, 0.), 0.)


if __name__ == '__main__':
    unittest.main()
