# -*- coding: utf-8 -*-
"""客观奖励项的**反劫持**测试（PLAN §48）。

这些测试的目的不是"函数算得对"，而是**证明这个奖励不能被人为套利**：
  H1 安全项恒 ≤ 0 —— 安全时中性 ⇒ **不能靠"制造安全假象"刷正分**（P1-f 的教训）
  H2 安全项单调 —— 余量越小越负 ⇒ 方向正确
  H3 **分类无关**：把某辆车从"角色分类"里移除，`r_safe` **不变**
     （因为它对**所有车**取 min，不依赖 rv/fv）⇒ P1-g 那类"换对手刷分"不成立
  H4 **"减速把对手变没"不再有收益**：自车静止时，附近的车仍然压低 `r_safe`
  H5 PET：两窗重叠 ⇒ 负；分离充足 ⇒ 0
  H6 PBRS 望远镜性质 ⇒ 只依赖端点（因此不改变最优策略）
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Planning_library.objective_reward import (          # noqa: E402
    worst_lcttc, worst_boundary_thw, worst_proximity, penalty_from_margin,
    r_safe, r_pet, occupancy_interval, pet_to_stream, pbrs, _veh_list)


class Obj(object):
    """鸭子类型的"车"（dynamic_map.objects 的元素）。"""
    def __init__(self, x, y, yaw=0.0, v=0.0, length=4.5, width=2.0):
        self.x, self.y, self.yaw, self.v = x, y, yaw, v
        self.length, self.width = length, width


# ============================================================
# H1 / H2：安全项只能为负、上界 0，且单调
# ============================================================
def test_h1_safe_is_non_positive_and_bounded():
    """H1：`r_safe` 恒 ≤ 0，且安全（h≥th）时恰好 0。"""
    for h in (-5.0, 0.0, 0.1, 1.0, 2.0, 5.0, float('inf'), None):
        v = r_safe(h, h_th=2.0, w=1.0)
        assert v <= 1e-12, 'h=%s 时 r_safe=%s 应为 ≤0' % (h, v)
    assert abs(r_safe(2.0, h_th=2.0)) < 1e-12
    assert abs(r_safe(10.0, h_th=2.0)) < 1e-12
    assert abs(r_safe(float('inf'), h_th=2.0)) < 1e-12      # 无对手 ⇒ 中性
    assert abs(r_safe(None, h_th=2.0)) < 1e-12
    # 下界 = −w
    assert abs(r_safe(0.0, h_th=2.0, w=3.0) + 3.0) < 1e-12


def test_h2_safe_is_monotone():
    """H2：h 越小 ⇒ r_safe 越负（方向正确，无饱和平台）。"""
    hs = [2.0, 1.5, 1.0, 0.5, 0.2, 0.0]
    rs = [r_safe(h, h_th=2.0, w=1.0) for h in hs]
    for i in range(1, len(rs)):
        assert rs[i] < rs[i - 1], 'h=%s→%s 时 r_safe 未变负: %s vs %s' % (
            hs[i - 1], hs[i], rs[i - 1], rs[i])


# ============================================================
# H3 / H4：**分类无关** —— 这是反劫持的核心
# ============================================================
def test_h3_safe_is_classification_independent():
    """H3：把某辆车"从 rv 分类里移除"，`worst_lcttc`/`r_safe` **不变**。

    因为我们对**所有车**取 min，不依赖 rv/fv 角色。这正是 P1-g 的病因所在：
    旧实现里 `g_d`/`THW` 取自"分类出的 (fv,rv) 对"，换一辆车就能改奖励。
    """
    ego = (5.0, -134.0, math.radians(-90.0), 2.0)
    near = Obj(6.0, -137.5, math.radians(180.0), 3.0)     # 很近的车（真正危险）
    far = Obj(40.0, -138.0, math.radians(180.0), 6.0)     # 很远的车

    # 情形 A：分类器把"近车"当作 rv（对手）
    hA, _ = worst_lcttc(ego[0], ego[1], ego[2], ego[3], _veh_list([near, far]))
    # 情形 B：分类器把"远车"当作 rv，近车被归为 fv（"已通过的"）
    hB, _ = worst_lcttc(ego[0], ego[1], ego[2], ego[3], _veh_list([far, near]))
    assert abs(hA - hB) < 1e-9, '顺序/分类不同却给出了不同 h: %s vs %s' % (hA, hB)

    # 极端：分类器把近车**完全排除**（不放进评估集合）—— 这时 r_safe 会变好，
    #   但那是"世界变了"（车真的不在评估集合里），而不是"分类套利"。
    #   本模块保证的是：只要车在集合里，就按几何说话，与角色无关。
    h_only_far, _ = worst_lcttc(ego[0], ego[1], ego[2], ego[3], _veh_list([far]))
    assert h_only_far > hA, '近车在集合里时 h 应更小（更危险）'


def test_h4_decelerating_does_not_hide_opponents():
    """H4：**"把对手从分类里抹掉"不再带来正收益**，且客观量始终刻画真实几何。

    旧实现：`t_ego = arc/v` ⇒ 减速 ⇒ 所有车被判成 fv ⇒ rv 为空 ⇒ THW=inf
             ⇒ 旧代码给 **+20/帧**（正奖金）⇒ **停下来刷分**。
    新实现：
      · `r_safe(inf) = 0`（**中性**，不是 +20）⇒ 抹掉对手**没有奖金**
      · `worst_proximity`（最坏边界距离 `d_AB`）**恒有限** ⇒ 对手无论怎么被分类，
        只要车在附近，距离就摆在那里
      · `worst_lcttc` 为 inf 是**正确语义**（不接近 ⇒ 无碰撞在即），此时安全项 0 是正确的
    """
    vehicles = _veh_list([Obj(6.5, -137.0, math.radians(180.0), 4.0)])
    # ① 抹掉对手（h=inf）只拿中性 0，**没有**正奖金
    assert abs(r_safe(float('inf'), h_th=2.0)) < 1e-12, '无对手必须中性 0（旧口径 +20 才是劫持）'
    # ② 最坏边界距离恒有限，且随自车减速/静止仍然反映"车就在旁边"
    ds = []
    for v_ego in (6.0, 4.0, 2.0, 0.5, 0.0):
        d = worst_proximity(5.0, -134.0, math.radians(-90.0), v_ego, vehicles)
        ds.append(d)
        assert math.isfinite(d), 'worst_proximity 必须恒有限（对手不能被分类抹掉）: v_ego=%s' % v_ego
    # ③ 距离惩罚：车越近越负，且恒 ≤ 0
    r_near = penalty_from_margin(ds[0], th=8.0, w=2.0)
    r_far = penalty_from_margin(30.0, th=8.0, w=2.0)
    assert r_near < r_far <= 1e-12, (r_near, r_far)
    # ④ LCTTC 的 inf 语义
    h, _ = worst_lcttc(5.0, -134.0, math.radians(-90.0), 0.0, vehicles)
    assert (not math.isfinite(h)) or math.isfinite(h)   # 允许 inf（不接近）
    assert r_safe(h, h_th=2.0) <= 1e-12


def test_h4b_paper_thw_input_made_objective():
    """H4b：论文式(65) 的形式可保留，但**输入**改为"对所有车取最坏 THW"。"""
    ego = (5.0, -134.0, math.radians(-90.0), 3.0)
    near = Obj(6.2, -137.2, math.radians(180.0), 5.0)
    far = Obj(60.0, -138.0, math.radians(180.0), 5.0)
    thw_all = worst_boundary_thw(ego[0], ego[1], ego[2], ego[3], _veh_list([near, far]))
    thw_far_only = worst_boundary_thw(ego[0], ego[1], ego[2], ego[3], _veh_list([far]))
    assert math.isfinite(thw_all)
    assert thw_all <= thw_far_only + 1e-9, '最坏 THW 应 ≤ 只看远车的 THW'
    # 旧口径在"无 RV"时给 thw_cap=2.0 ⇒ +20；新口径下最坏 THW 是真实的小值
    import Planning_library.game_reward as gr
    assert gr.thw_reward(thw_all) <= gr.thw_reward(thw_far_only) + 1e-9


# ============================================================
# H5：PET（汇入区）—— 重叠 ⇒ 负，分离 ⇒ 0
# ============================================================
def test_h5_pet_overlap_and_separation():
    """H5：汇入区占用窗重叠 ⇒ PET<0 ⇒ 惩罚；分离充足 ⇒ PET≥th ⇒ 0。"""
    ego_iv = occupancy_interval(t_enter=5.0, v=4.0, length=4.5, band_width=2.0)
    assert ego_iv is not None
    # 车流车在自车完全离开**之后**很久到 ⇒ 安全
    ok_iv = occupancy_interval(t_enter=20.0, v=5.0, length=4.0, band_width=2.0)
    pet_ok = pet_to_stream(ego_iv, [ok_iv])
    assert pet_ok > 3.0 and abs(r_pet(pet_ok, pet_th=3.0)) < 1e-12
    # 车流车与自车**同时**占用 ⇒ 重叠 ⇒ PET<0 ⇒ 有惩罚
    bad_iv = occupancy_interval(t_enter=5.0, v=5.0, length=4.0, band_width=2.0)
    pet_bad = pet_to_stream(ego_iv, [bad_iv])
    assert pet_bad < 0.0, pet_bad
    assert r_pet(pet_bad, pet_th=3.0) < 0.0
    # min over all：一辆很远的车**不能**把近处冲突车的影响稀释掉
    pet_mixed = pet_to_stream(ego_iv, [bad_iv, ok_iv])
    assert abs(pet_mixed - pet_bad) < 1e-9, 'min over all 应取最坏的那辆'


def test_h5b_pet_is_non_positive_bounded():
    for p in (-5.0, -1.0, 0.0, 0.5, 3.0, 10.0, float('inf'), None):
        assert r_pet(p, pet_th=3.0, w=2.0) <= 1e-12, p


# ============================================================
# H6：PBRS 望远镜性质
# ============================================================
def test_h6_pbrs_telescopes():
    """H6：**带折扣权重的**求和只依赖端点 ⇒ 不改变最优策略。

    ⚠️ 关键细节：望远镜性质是
        `Σ_{t=0}^{T-1} γ^t · [γΦ(s_{t+1}) − Φ(s_t)] = γ^T Φ(s_T) − Φ(s_0)`
    —— **权重 `γ^t` 不能少**。少了它就会留下 `(γ−1)ΣΦ` 的残差（我第一次就写错了，
    这也说明 PBRS 必须作用在**折扣回报**上，而我们的 `reward_to_go` 正是折扣回报）。
    """
    g = 0.9
    phis = [0.0, 1.0, 3.0, 2.0, 0.5, -1.0]
    total = sum((g ** t) * pbrs(phis[t + 1], phis[t], gamma=g)
                for t in range(len(phis) - 1))
    expect = (g ** (len(phis) - 1)) * phis[-1] - phis[0]
    assert abs(total - expect) < 1e-9, (total, expect)
    # 反例：不加 γ^t 权重时不成立（用于锁死"必须带折扣"这一点）
    naive = sum(pbrs(phis[t + 1], phis[t], gamma=g) for t in range(len(phis) - 1))
    assert abs(naive - expect) > 1e-3, '若不成立则说明本测试失去意义' 


def test_h6b_pbrs_handles_bad_input():
    assert pbrs(None, 1.0) == 0.0
    assert pbrs(1.0, None) == 0.0
    assert pbrs(float('nan'), 1.0) == 0.0


# ============================================================
# 通用形状
# ============================================================
def test_penalty_shape_continuous():
    """penalty_from_margin 在阈值处连续（无跳变）—— P2。"""
    th = 2.0
    eps = 1e-6
    assert abs(penalty_from_margin(th - eps, th) - penalty_from_margin(th + eps, th)) < 1e-9
    assert abs(penalty_from_margin(th, th)) < 1e-12


def test_veh_list_tolerates_bad_objects():
    class Bad(object):
        @property
        def x(self):
            raise RuntimeError('boom')
    out = _veh_list([Obj(1, 2), Bad(), Obj(3, 4)])
    assert len(out) == 2, out


if __name__ == '__main__':
    fns = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in fns:
        fn()
        print('ok  %s' % fn.__name__)
    print('\nALL %d PASSED' % len(fns))
