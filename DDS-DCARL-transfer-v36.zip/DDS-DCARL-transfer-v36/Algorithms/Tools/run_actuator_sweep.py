#!/usr/bin/env python3
"""Open-loop low-speed physics sweep; physical shocks are findings, not passes."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from Planning_library.pedal_control import PedalControllerV11


def cases():
    return [dict(case_id='v%d_b%03d_r%d' % (speed, round(brake*1000), repeat),
                 launch_speed=float(speed), pulse_brake=brake, repeat=repeat)
            for speed in (1, 2, 3) for brake in (0., .01, .15) for repeat in (1, 2)]


class SweepController(PedalControllerV11):
    def __init__(self, brake_gain, max_steer, brake):
        super().__init__(brake_gain, max_steer)
        self.pulse, self.pulse_brake = False, brake

    def command(self, acceleration, speed, target_speed, steering):
        if not self.pulse:
            return super().command(acceleration, speed, target_speed, 0.)
        self.mode, self.target_acceleration = 'open_loop_sweep', 0.
        self.throttle, self.brake, self.steer = 0., self.pulse_brake, 0.
        return dict(throttle=0., brake=self.brake, steer=0.,
                    hand_brake=False, reverse=False, manual_gear_shift=False)


def run_case(env, case, sink):
    env.reset(False)
    previous = env.pedal_controller
    controller = SweepController(previous.brake_gain, previous.max_steer, case['pulse_brake'])
    env.pedal_controller = controller
    rows, errors, phase, stable, pulse_frames = [], [], 'launch', 0., 0
    shock = False
    for frame in range(240):  # 8 s launch + at most 4 s pulse
        controller.pulse = phase == 'pulse'
        _, _, done, _ = env.step([.8 if phase == 'launch' else 0., 0.], target_speed=case['launch_speed'])
        row = dict(env.last_control, diagnostic_phase=phase, diagnostic_frame=frame+1, **case)
        rows.append(row)
        sink.append(row)  # preserve partial evidence if a later tick raises
        speed, acceleration = float(row['ego_v_after']), float(row['ego_acc_measured'])
        if not math.isfinite(speed) or not math.isfinite(acceleration):
            errors.append('nonfinite_motion')
            break
        if row.get('control_submit_ok') != 1 or row.get('control_transport') != 'batch_sync_pre_tick':
            errors.append('control_submission')
        if (row.get('control_tick_frame') != row.get('sim_frame_after') or
                row.get('control_feedback_frame') != row.get('sim_frame_after') or
                row['sim_frame_after']-row['sim_frame_before'] != 1 or abs(row['sim_dt']-.05) > 1e-4):
            errors.append('frame_alignment')
        for key in ('throttle', 'brake', 'steer'):
            if abs(row[key]-row['requested_'+key]) > 1e-5:
                errors.append('feedback_'+key)
        if row['reverse'] or row['hand_brake'] or row['manual_gear_shift']:
            errors.append('drivetrain_flags')
        if done:
            errors.append('unexpected_termination')
        if phase == 'pulse':
            pulse_frames += 1
        if abs(acceleration) > 6.:
            shock = True
            break  # retain triggering row and stop applying open-loop torque
        if errors:
            break
        if phase == 'launch':
            stable = stable+env.dt if speed >= case['launch_speed']-.1 else 0.
            if stable >= .25-1e-9:
                phase, stable = 'pulse', 0.
            elif frame+1 >= 160:
                errors.append('launch_timeout')
                break
        else:
            stable = stable+env.dt if speed < .1 else 0.
            if stable >= .25-1e-9 or pulse_frames >= 80:
                break
    pulse = [r for r in rows if r['diagnostic_phase'] == 'pulse']
    return dict(case, technical_ok=not errors, errors=sorted(set(errors)), physical_shock=shock,
        shock_phase=rows[-1]['diagnostic_phase'] if shock else None,
        launch_frames=len(rows)-len(pulse), pulse_frames=len(pulse),
        pulse_min_speed=min((r['ego_v_after'] for r in pulse), default=None),
        reached_below_0_8=any(r['ego_v_after'] < .8 for r in pulse),
        stopped=stable >= .25-1e-9 and bool(pulse),
        min_acceleration=min((r['ego_acc_measured'] for r in rows), default=None),
        max_acceleration=max((r['ego_acc_measured'] for r in rows), default=None))


def main(argv=None, env_factory=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    if args.dry_run:
        print(json.dumps(dict(stage='actuator_sweep', control_profile='paper_v11', mpc_used=False,
            cases=cases(), max_launch_seconds=8., max_pulse_seconds=4.,
            physical_shocks_are_diagnostic=True)))
        return 0
    if args.output_root is None:
        parser.error('--output-root is required')
    output = args.output_root.resolve()
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error('Output already exists: '+str(output))
    for key in list(os.environ):
        if key.startswith('DSH_'):
            del os.environ[key]
    os.environ.update(DSH_CONTROL_PROFILE='paper_v11', DSH_TRAFFIC='off', DSH_SEED='1',
        DSH_SAVE_DIR=str(output), DSH_PLOT_DIR=str(output/'plots'), DSH_CONTROL_PROBE='0')
    sources = [ROOT/'train_dcarl_turn.py', ROOT/'path_utils.py']
    for folder in ('Agent', 'Planning_library', 'Test_Scenarios', 'Tools'):
        sources.extend(sorted((ROOT/folder).rglob('*.py')))
    (output/'manifest.json').write_text(json.dumps(dict(revision='actuator_sweep_v11', cases=cases(),
        mpc_used=False, source_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                     for p in sources}), indent=2), encoding='utf8')
    env, rows, results, error = None, [], [], None
    try:
        if env_factory is None:
            from Test_Scenarios.TestScenario_Town03_turn import CarEnv_Town03_Turn
            env_factory = CarEnv_Town03_Turn
        env = env_factory()
        for case in cases():
            result = run_case(env, case, rows)
            results.append(result)
            print(json.dumps(result), flush=True)
    except Exception:
        error = traceback.format_exc()
        print(error, file=sys.stderr)
    finally:
        if env is not None:
            try:
                env.cleanup()
            except Exception:
                error = error or traceback.format_exc()
        if rows:
            with (output/'actuator_sweep.csv').open('w', newline='', encoding='utf8') as stream:
                writer = csv.DictWriter(stream, fieldnames=sorted({k for r in rows for k in r}))
                writer.writeheader()
                writer.writerows(rows)
        result = dict(mpc_used=False, technical_ok=error is None and len(results) == len(cases())
            and all(r['technical_ok'] for r in results), experiments=results, error=error,
            physical_shock_cases=sum(r['physical_shock'] for r in results),
            note='Open-loop shock findings are not closed-loop health passes; empty-road tests gate progression.')
        (output/'result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result), flush=True)
    return 0 if result['technical_ok'] else 6


if __name__ == '__main__':
    raise SystemExit(main())
