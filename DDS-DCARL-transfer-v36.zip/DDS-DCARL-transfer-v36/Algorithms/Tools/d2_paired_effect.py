#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【D2 效果测量·配对重算】在**同一批数据**上比较"回报含/不含 −ambiguity"。

为什么必须"配对"
------------------------------------------------------------------
仿真在轨迹级不可复现（同一 seed 两次跑的 `ego_x` 第 1 帧就分叉）。
⇒ 跨运行比较（跑一次 W=1、再跑一次 W=0）会被**交通实现差异**混淆。
本脚本改用**同一批回合数据**：逐帧已知 `reward`（含项）与 `rew_efe_amb`（该项本身），
于是可以**精确重构**"若无该项时的回报"：

    reward_without = reward_with
    G_without_t    = Σ_{k≥t} γ^{k−t}·reward_without_k
    G_with_t       = Σ_{k≥t} γ^{k−t}·reward_with_k

⇒ 两条序列来自**同一批轨迹**，差异**只来自该项本身** —— 无混淆。

⚠️ 关于两个折扣放大因子（最容易算错的地方）
------------------------------------------------------------------
  · **常数**偏移的放大 = 1/(1−γ)          （γ=0.98 ⇒ 50）
  · **波动**项的标准差放大 = 1/√(1−γ²)    （γ=0.98 ⇒ 5.025）
  两者相差 10 倍，混用会得出错误结论 ⇒ 本脚本分开报告"均值通道"与"方差通道"。

输出
------------------------------------------------------------------
  1. 校验：重构回报与 R-tree 里实际落盘的 G 是否一致（分布层面）
  2. 均值通道：逐动作 ΔQ̂ 与动作间极差
  3. 方差通道：逐动作 Δσ（含配对检验）
  4. **决策层**：用式43-46 复算 WCV/BCV，统计"含/不含该项"时接管判决的**翻转率**
     —— 这是"② 是否真的改变了 ③ 的偏好"的直接答案

用法
------------------------------------------------------------------
  python Tools/d2_paired_effect.py <run_dir> [gamma] [alpha]
"""
from __future__ import annotations

import collections
import csv
import math
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

RUN = sys.argv[1] if len(sys.argv) > 1 else 'A6fix100'
GAMMA = float(sys.argv[2]) if len(sys.argv) > 2 else 0.98
ALPHA = float(sys.argv[3]) if len(sys.argv) > 3 else 0.05


def _num(row, key):
    v = row.get(key)
    if v in (None, ''):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def rtg(vals, gamma):
    """式58/59 的折扣回报 G_t = Σ_{k≥t} γ^{k−t} r_k（与 active_inference.reward_to_go 同口径）。"""
    out = [0.0] * len(vals)
    acc = 0.0
    for i in range(len(vals) - 1, -1, -1):
        acc = vals[i] + gamma * acc
        out[i] = acc
    return out


def wcv_bcv(samples, alpha, rng):
    """式43/44/45/60：WCV = Q̂ − δ − 4σ/(n+1)，BCV = Q̂ + δ。"""
    n = len(samples)
    if n == 0:
        return None, None, None, 0
    mean = sum(samples) / n
    var = sum((x - mean) ** 2 for x in samples) / n
    sd = math.sqrt(max(var, 0.0))
    delta = float(rng) * math.sqrt(math.log(1.0 / alpha) / (2.0 * n))
    return (mean - delta - 4.0 * sd / (n + 1.0),   # WCV
            mean + delta,                           # BCV
            mean, n)


def main():
    ego = os.path.join(RUN, 'interaction_ego.csv')
    if not os.path.exists(ego):
        print(f'找不到 {ego}')
        return 1
    rows = list(csv.DictReader(open(ego)))
    eps = collections.defaultdict(list)
    for r in rows:
        eps[r.get('episode')].append(r)
    print(f'run={RUN}  帧={len(rows)}  回合={len(eps)}  γ={GAMMA}  α={ALPHA}')

    G_on = collections.defaultdict(list)     # action -> [G_with]
    G_off = collections.defaultdict(list)    # action -> [G_without]
    rule_of = collections.defaultdict(list)  # action -> [rule_action]
    n_term = 0
    term_vals = []
    ep_no = 0
    for ep, rs in eps.items():
        if not ep:
            continue
        ep_no += 1
        r_on = [_num(x, 'reward') or 0.0 for x in rs]
        term = [_num(x, 'rew_efe_amb') or 0.0 for x in rs]
        r_off = [a - b for a, b in zip(r_on, term)]
        g_on, g_off = rtg(r_on, GAMMA), rtg(r_off, GAMMA)
        for x, go, gf in zip(rs, g_on, g_off):
            a = x.get('action')
            if a in (None, ''):
                continue
            a = int(a)
            G_on[a].append(go)
            G_off[a].append(gf)
            ra = x.get('rule_action')
            rule_of[a].append(int(ra) if ra not in (None, '') else a)
        for t in term:
            if t != 0.0:
                n_term += 1
                term_vals.append(-t)          # 存 ambiguity 本身（正）

    print(f'\n含该项的帧: {n_term} ({100.0 * n_term / max(len(rows), 1):.1f}%)')
    if term_vals:
        mu = sum(term_vals) / len(term_vals)
        sd = math.sqrt(sum((x - mu) ** 2 for x in term_vals) / len(term_vals))
        print(f'ambiguity: 均值={mu:.4f}  sd={sd:.4f}  min={min(term_vals):.4f}  max={max(term_vals):.4f}')
    else:
        print('⚠️ 没有非零的 rew_efe_amb ⇒ D2 未生效？')
        return 1

    # ---------- 1) 均值通道 ----------
    acts = sorted(set(G_on) & set(G_off))
    print('\n' + '=' * 92)
    print('【通道1·均值 → Q̂ 的动作排序】（常数偏移放大 1/(1−γ)）')
    print('=' * 92)
    print(f"{'action':<8}{'n':<8}{'Q̂(不含)':<14}{'Q̂(含)':<14}{'ΔQ̂':<12}{'Δ来自项':<12}")
    q_on, q_off = {}, {}
    for a in acts:
        v_on, v_off = G_on[a], G_off[a]
        m_on = sum(v_on) / len(v_on)
        m_off = sum(v_off) / len(v_off)
        q_on[a], q_off[a] = m_on, m_off
        print(f'{a:<8}{len(v_on):<8}{m_off:<14.1f}{m_on:<14.1f}{m_on - m_off:<+12.1f}'
              f'{"":<12}')
    spread_off = max(q_off.values()) - min(q_off.values())
    spread_on = max(q_on.values()) - min(q_on.values())
    print(f'\n  动作间 Q̂ 极差: 不含={spread_off:.1f}  含={spread_on:.1f}')
    print(f'  ⇒ 该项目对"动作价值极差"的影响 ≈ {100.0 * abs(spread_on - spread_off) / max(spread_off, 1e-9):.2f}%')

    # ---------- 2) 方差通道 ----------
    print('\n' + '=' * 92)
    print('【通道2·方差 → 式60 的 σ 修正】（波动项放大 1/√(1−γ²)）')
    print('=' * 92)
    print(f"{'action':<8}{'n':<8}{'σ(不含)':<13}{'σ(含)':<13}{'Δσ':<12}{'Δσ%'}")
    dsig = []
    for a in acts:
        v_on, v_off = G_on[a], G_off[a]
        if len(v_on) < 3:
            continue
        m_on = sum(v_on) / len(v_on)
        m_off = sum(v_off) / len(v_off)
        s_on = math.sqrt(sum((x - m_on) ** 2 for x in v_on) / len(v_on))
        s_off = math.sqrt(sum((x - m_off) ** 2 for x in v_off) / len(v_off))
        dsig.append(s_on - s_off)
        print(f'{a:<8}{len(v_on):<8}{s_off:<13.1f}{s_on:<13.1f}{s_on - s_off:<+12.2f}'
              f'{100.0 * (s_on - s_off) / max(s_off, 1e-9):+.2f}%')
    if dsig:
        md = sum(dsig) / len(dsig)
        sdd = math.sqrt(sum((x - md) ** 2 for x in dsig) / max(len(dsig) - 1, 1))
        print(f'\n  Δσ 均值 = {md:+.3f}  (动作间 sd={sdd:.3f}, n_actions={len(dsig)})')
        if len(dsig) > 1 and sdd > 0:
            t = md / (sdd / math.sqrt(len(dsig)))
            print(f'  配对 t ≈ {t:+.2f}  ⇒ {"显著" if abs(t) > 2.0 else "不显著（含 0）"}')

    # ---------- 3) 决策层：WCV/BCV 判决翻转率 ----------
    print('\n' + '=' * 92)
    print('【决策层】用式43-46 复算 WCV/BCV，统计接管判决的翻转率')
    print('  （这是"② 是否真的改变了 ③ 的偏好"的直接答案）')
    print('=' * 92)

    def _range(vals):
        s = sorted(vals)
        if len(s) < 2:
            return 1.0
        lo = s[int(0.01 * (len(s) - 1))]
        hi = s[int(0.99 * (len(s) - 1))]
        return max(hi - lo, 1e-9)

    all_on = [v for a in acts for v in G_on[a]]
    all_off = [v for a in acts for v in G_off[a]]
    rng_on, rng_off = _range(all_on), _range(all_off)
    print(f'  (R_max−R_min): 不含={rng_off:.0f}  含={rng_on:.0f}')

    def decisions(G):
        rng = _range([v for a in acts for v in G[a]])
        iv = {}
        for a in acts:
            w, b, m, n = wcv_bcv(G[a], ALPHA, rng)
            iv[a] = (w, b)
        # 论文式46 形态：以**规则动作**为基线（用该动作样本的整体统计近似）
        rule_counts = collections.Counter()
        for a in acts:
            for ra in rule_of[a]:
                rule_counts[ra] += 1
        base = rule_counts.most_common(1)[0][0] if rule_counts else acts[0]
        if base not in iv:
            base = acts[0]
        bcv_b = iv[base][1]
        winners = [a for a in acts if a != base and iv[a][0] is not None and iv[a][0] > bcv_b]
        best = max((a for a in acts if iv[a][0] is not None), key=lambda a: iv[a][0])
        return base, winners, best, iv

    base_on, win_on, best_on, iv_on = decisions(G_on)
    base_off, win_off, best_off, iv_off = decisions(G_off)
    print(f'  基线动作: 不含={base_off}  含={base_on}')
    print(f'  可接管动作（WCV > BCV(基线)）:')
    print(f'    不含该项: {sorted(win_off)}')
    print(f'    含该项  : {sorted(win_on)}')
    flip = (set(win_on) != set(win_off)) or (best_on != best_off)
    print(f'  argmax WCV 动作: 不含={best_off}  含={best_on}')
    print(f'  ⇒ **判决是否翻转: {"是 ✅（② 改变了 ③ 的偏好）" if flip else "否 ❌（② 未改变 ③ 的偏好）"}**')
    return 0


if __name__ == '__main__':
    sys.exit(main())
