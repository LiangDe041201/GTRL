"""Read-only, stdlib checks that belief / KL / recursive learning actually ran."""
import csv
import json
import math
from pathlib import Path


def _finite(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None


def _distribution(value, size=None):
    if isinstance(value, str):
        value = json.loads(value)
    if not isinstance(value, list) or not value or (size is not None and len(value) != size):
        raise ValueError('Invalid distribution shape')
    p = [_finite(x) for x in value]
    if any(x is None or x < 0. for x in p) or abs(sum(p)-1.) > 1e-6:
        raise ValueError('Invalid probability mass')
    return p


def _kl(policy, prior, alpha):
    if any(p > 0. and p0 <= 0. for p, p0 in zip(policy, prior)):
        raise ValueError('Policy outside baseline support')
    return alpha * sum(p * math.log(p / p0) for p, p0 in zip(policy, prior) if p > 0.)


def validate_belief_learning(directory):
    """Checks execution/evidence integrity; does not claim learning performance."""
    directory = Path(directory)
    result = dict(learning_mechanisms_ok=False, belief_log_rows=0, invalid_belief_log_rows=0,
                  belief_update_decisions=0, belief_state_count=0, belief_transition_rows=0,
                  bellman_sweeps=0, bellman_residual=None, max_policy_kl_error=None)
    errors, kl_errors = [], []
    try:
        model = json.loads((directory / 'belief_soft_model.json').read_text(encoding='utf-8'))
        signature = model['signature']
        if signature['schema'] != 'belief_soft_bellman_v1':
            raise ValueError('Unexpected learning schema')
        alpha, gamma, actions = signature['alpha'], signature['gamma'], signature['actions']
        if _finite(alpha) is None or alpha <= 0. or not 0. < gamma < 1.:
            raise ValueError('Invalid learning parameters')
        nodes, q, records = model['nodes'], model['q'], model['records']
        for key, node in nodes.items():
            _distribution(node['belief'], 6)
            _distribution(node['prior'], actions)
            if len(node['context']) != 24 or any(_finite(x) is None for x in node['context']):
                raise ValueError('Missing joint game observation in a belief state')
            if len(q[key]) != actions or any(_finite(v) is None for v in q[key]):
                raise ValueError('Invalid recursive action values')
        with (directory / 'belief_transitions.jsonl').open(encoding='utf-8') as stream:
            logged = [json.loads(line) for line in stream if line.strip()]
        if logged != records:
            raise ValueError('Transition log and final model disagree')
        for record in records:
            _distribution(record['belief'], 6)
            if record['next'] is not None:
                _distribution(record['next_belief'], 6)
            if (record['state'] not in nodes or record['steps'] < 1 or
                    not 0 <= record['action'] < actions or _finite(record['reward']) is None or
                    _finite(record['discount']) is None or
                    abs(record['discount']-gamma**record['steps']) > 1e-9 or
                    (record['next'] is not None and record['next'] not in nodes)):
                raise ValueError('Invalid belief transition or option discount')
        if not records or not any(r['next'] is not None for r in records):
            raise ValueError('No nonterminal belief transitions were learned')
        if not any(r['next'] is None for r in records):
            raise ValueError('No terminal belief transition was learned')
        result.update(belief_state_count=len(nodes), belief_transition_rows=len(records),
                      bellman_sweeps=model['sweeps'], bellman_residual=model['residual'])
        if not model['sweeps'] or _finite(model['residual']) is None:
            raise ValueError('No finite Bellman update/residual')
        with (directory / 'interaction_ego.csv').open(newline='', encoding='utf-8-sig') as stream:
            for row in csv.DictReader(stream):
                result['belief_log_rows'] += 1
                try:
                    if row.get('learning_mode') != 'soft_belief':
                        raise ValueError('Learning mode missing')
                    if row.get('learning_reward_mode') != signature['reward_contract']:
                        raise ValueError('Learning reward differs from model')
                    belief = _distribution(row.get('belief_vector'), 6)
                    prior = _distribution(row.get('baseline_policy'), actions)
                    policy = _distribution(row.get('soft_policy'), actions)
                    entropy = _finite(row.get('belief_entropy'))
                    cost = _finite(row.get('soft_information_cost'))
                    if _finite(row.get('soft_value')) is None:
                        raise ValueError('Missing soft state value')
                    if entropy is None or abs(entropy + sum(p*math.log(p) for p in belief if p > 0.)) > 1e-5:
                        raise ValueError('Belief entropy disagrees')
                    if cost is None or abs(cost-_kl(policy, prior, alpha)) > 1e-5:
                        raise ValueError('Soft policy information cost disagrees')
                    kl_errors.append(abs(cost-_kl(policy, prior, alpha)))
                    if row.get('behavior_model_valid') == '1':
                        behavior = _distribution(row.get('behavior_policy'), actions)
                        cost = _finite(row.get('information_cost'))
                        if cost is None or abs(cost-_kl(behavior, prior, alpha)) > 1e-5:
                            raise ValueError('Executed policy information cost disagrees')
                        kl_errors.append(abs(cost-_kl(behavior, prior, alpha)))
                    elif row.get('behavior_model_valid') != '0' or row.get('information_cost') or row.get('behavior_policy'):
                        raise ValueError('Forced control retains an invalid policy cost')
                    if row.get('learning_decision') == '1' and row.get('belief_rv_id'):
                        evidence = _finite(row.get('belief_evidence'))
                        if evidence is None or not 0. < evidence <= 1.:
                            raise ValueError('Invalid observation evidence')
                        result['belief_update_decisions'] += 1
                except (ValueError, TypeError, KeyError):
                    result['invalid_belief_log_rows'] += 1
        if not result['belief_log_rows'] or result['invalid_belief_log_rows']:
            raise ValueError('Missing or invalid full-frame learning diagnostics')
        if not result['belief_update_decisions']:
            raise ValueError('No opponent belief update was observed')
        result['learning_mechanisms_ok'] = True
    except (OSError, ValueError, TypeError, KeyError) as exc:
        errors.append(str(exc))
    result['learning_validation_errors'] = errors
    result['max_policy_kl_error'] = max(kl_errors) if kl_errors else None
    return result
