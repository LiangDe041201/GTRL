"""Read-only episode-held-out aggregation and realized-objective diagnostics.

Coverage increases are not evidence of interchangeable states or driving
benefit. This tool never trains a pooled model or writes a checkpoint.
"""
import argparse
from collections import Counter,defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

FIELDS=('entry_standoff','ego_speed','cg_target_speed','rv_relative_x','rv_relative_y',
    'rv_speed','rv_acceleration','visible_leader_gap','visible_leader_speed','tracking_l',
    'tracking_epsi','previous_acceleration','previous_steer','interaction_phase',
    'rv_present','rv_acceleration_available')


def _projections(data):
    decoded={k:json.loads(k) for k in data['nodes']}
    if any(len(v)!=4 or len(v[0])!=16 for v in decoded.values()):raise ValueError('Expected v24 context keys')
    serialize=lambda v:json.dumps(v,separators=(',',':'))
    result={name:{k:serialize(v[:size]) for k,v in decoded.items()} for name,size in
        [('full',4),('without_available_set',3),('without_policy_context',2)]}
    for i,name in enumerate(FIELDS):
        result['without_'+name]={k:serialize([v[0][:i]+v[0][i+1:]]+v[1:]) for k,v in decoded.items()}
    return result


def compare_abstractions(data,train_through_episode=150):
    results={}; baseline_errors=None
    for name,aliases in _projections(data).items():
        observed=defaultdict(lambda:defaultdict(set)); train=defaultdict(lambda:defaultdict(list)); held=[]
        for index,r in enumerate(data['records']):
            pool=aliases[r['state']];observed[pool][r['action']].add(r['episode'])
            if not math.isfinite(r['reward']) or r['steps']<1:raise ValueError('Invalid actual experience')
            # Preserve action, duration and terminal/nonterminal status when
            # checking raw option-reward heterogeneity. No final Q leaks into
            # the held-out reward predictor.
            key=(pool,r['action'],r['steps'],r['next'] is None)
            if r['episode']<=train_through_episode:train[key][r['episode']].append(r['reward'])
            else:held.append((index,key,r['reward']))
        fitted={k:statistics.mean(statistics.mean(v) for v in groups.values())
                for k,groups in train.items() if len(groups)>=2}
        errors={i:(reward-fitted[k])**2 for i,k,reward in held if k in fitted}
        if baseline_errors is None:baseline_errors=errors
        common=set(errors)&set(baseline_errors)
        comparisons={}
        for key,node in data['nodes'].items():
            pool=aliases[key];d=node['default']
            for a in node['allowed']:
                if a!=d:comparisons[pool,d,a]=min(len(observed[pool][d]),len(observed[pool][a]))
        results[name]=dict(pools=len(set(aliases.values())),covered_comparisons=sum(n>=10 for n in comparisons.values()),
            maximum_joint_episodes=max(comparisons.values(),default=0),
            holdout=dict(train_through_episode=train_through_episode,total_records=len(held),predicted_records=len(errors),
                prediction_min_training_episodes=2,mean_squared_error=statistics.mean(errors.values()) if errors else None,
                common_records=len(common),common_mean_squared_error=statistics.mean(errors[i] for i in common) if common else None,
                baseline_common_mean_squared_error=statistics.mean(baseline_errors[i] for i in common) if common else None))
    results.update(production_changed=False,exchangeability_established=False,driving_benefit_established=False,
        note='Ablations retain actual episodes and actions; no synthetic experiences. Reward prediction uses earlier '
             'episodes only. Better coverage or held-out reward fit alone does not establish safe state pooling.')
    return results


def realized_options(data,ego_rows,summaries):
    """Reconstruct actual suffix options, then expose task and comfort terms."""
    gamma=float(data['signature']['gamma']);episodes=defaultdict(list);history=defaultdict(list)
    summary={int(v['episode']):v for v in summaries}
    fields=('frame','sim_dt','ego_v_after','a_cmd','ego_acc_signed','mpc_audit_override','guard_unavoidable')
    for v in ego_rows:episodes[int(v['episode'])].append({k:v.get(k) for k in fields})
    for record in data['records']:history[int(record['episode'])].append(record)
    if set(history)!=set(episodes) or set(history)!=set(summary) or not 0.<gamma<1.:
        raise ValueError('Expected complete matching v24 training episodes')
    options=[];errors=[]
    for ep,records in sorted(history.items()):
        frames=episodes[ep]
        if (len(frames)!=int(summary[ep]['frames']) or records[-1]['next'] is not None
                or [int(v['frame']) for v in frames]!=list(range(1,len(frames)+1))):
            raise ValueError('Incomplete or noncontiguous episode frames')
        cursor=len(frames)-sum(r['steps'] for r in records)
        if cursor<0 or any(r['steps']<1 for r in records):raise ValueError('Invalid option duration')
        # v24 engagement persists to terminal, hence the observed suffix is
        # uniquely determined by saved option durations. Verify every return.
        terminal={'complete':5.,'collision':-10.,'stuck':-5.}[summary[ep]['outcome']]
        for record in records:
            end=cursor+record['steps'];parts=Counter();measures=Counter();factor=1.
            for i in range(cursor,end):
                v=frames[i];speed=max(0.,float(v['ego_v_after']));acceleration=float(v['a_cmd'])
                if abs(float(v['sim_dt'])-.05)>1.e-4 or not all(math.isfinite(x) for x in (speed,acceleration)):
                    raise ValueError('Invalid actual frame motion or timestep')
                guard=v['mpc_audit_override']=='1' or v['guard_unavoidable']=='1'
                terms=dict(speed=.005*min(speed/4.,1.),time=-.001,
                    commanded_acceleration=-.0005*min((acceleration/3.)**2,1.),
                    intervention=-.001*guard,terminal=terminal if i==len(frames)-1 else 0.)
                for k,value in terms.items():parts[k]+=factor*value
                factor*=gamma;measures['seconds']+=.05
                measures['stopped_seconds']+=.05*(speed<.1);measures['guard_seconds']+=.05*guard
                try:
                    measured=float(v['ego_acc_signed'])
                    if math.isfinite(measured):
                        measures['measured_acceleration_integral']+=.05*min((measured/3.)**2,1.)
                        if i>0:
                            last=float(frames[i-1]['ego_acc_signed'])
                            if math.isfinite(last):
                                jerk=(measured-last)/.05
                                measures['measured_jerk_integral']+=.05*min((jerk/3.)**2,1.)
                                measures['jerk_observations']+=1
                except (TypeError,ValueError):pass
            error=sum(parts.values())-record['reward']
            if not math.isclose(error,0.,abs_tol=2.e-6):
                errors.append(dict(episode=ep,first_frame=int(frames[cursor]['frame']),difference=error))
            options.append(dict(state=record['state'],action=record['action'],episode=ep,steps=record['steps'],
                reward=record['reward'],first_frame=int(frames[cursor]['frame']),last_frame=int(frames[end-1]['frame']),
                components=dict(parts),metrics=dict(measures)))
            cursor=end
    return dict(realized_reward_contract_ok=not errors,reward_mismatches=errors,options=options,
        new_reward_applied=False,jerk_added_to_reward=False,
        note='Complete v24 suffix reconstruction with per-option reward checks. Measured jerk is diagnostic '
             'and is not a trained reward or an outcome for an unexecuted action.')


def _csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):yield row


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('checkpoint',type=Path);p.add_argument('--train-through-episode',type=int,default=150)
    p.add_argument('--run-directory',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args(argv)
    if args.output.exists():p.error('Choose an unused output; previous analyses are never overwritten')
    raw=args.checkpoint.read_bytes();data=json.loads(raw)
    report=dict(checkpoint_sha256=hashlib.sha256(raw).hexdigest(),abstractions=compare_abstractions(data,args.train_through_episode),
        production_changed=False,model_changed=False)
    if args.run_directory is not None:
        report['realized']=realized_options(data,_csv(args.run_directory/'interaction_ego.csv'),_csv(args.run_directory/'interaction_summary.csv'))
    assert args.checkpoint.read_bytes()==raw
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(dict(output=str(args.output),checkpoint_unchanged=True,
        real_reward_ok=report.get('realized',{}).get('realized_reward_contract_ok'))))
    return 0 if report.get('realized',{}).get('realized_reward_contract_ok',True) else 1


if __name__=='__main__':raise SystemExit(main())
