"""Replay public JSON candidates without CARLA, optimization or pickle.

v15 snapshots do NOT contain the full route. Report that missing evidence;
never synthesize it from future observed motion to claim a six-second benefit.
"""
import argparse
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def replay(row):
    import numpy as np
    from Planning_library.execution_guard import rollout
    from Planning_library.forecast_v16 import predict
    result = dict(episode=row['episode'], frame=row['frame'],
                  public_route_available='forecast_route' in row['geometry'], candidates=[])
    ego = SimpleNamespace(**row['ego'])
    for i, candidate in enumerate(row['candidates']):
        plan = None if candidate['plan'] is None else np.asarray(candidate['plan'])
        times = None if candidate['times'] is None else np.asarray(candidate['times'])
        arguments = (ego, row['path'], candidate['target'], candidate['a'], candidate['delta'],
                     row['previous'], row['geometry'])
        old, _ = rollout(*arguments, horizon=6., lag=.4, plan=plan, plan_times=times)
        modes = {}
        for horizon in (2.3, 6.):
            states, _, diag = predict(*arguments, horizon=horizon, lag=.4, plan=plan, plan_times=times)
            modes[str(horizon)] = dict(diag, traveled_distance=float(np.linalg.norm(
                np.diff(states[:2], axis=1), axis=0).sum()))
        result['candidates'].append(dict(target=candidate['target'],
            original_progress=row['decision']['components'][i][0]['progress'],
            original_max_speed=float(old[5].max()), original_end_speed=float(old[5, -1]),
            repaired=modes))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshots', type=Path)
    parser.add_argument('--episode', type=int, required=True)
    parser.add_argument('--frames', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    if args.output.exists():
        parser.error('Choose a new output; never overwrite prior evidence')
    wanted = {int(v) for v in args.frames.split(',')}
    records = []
    with args.snapshots.open(encoding='utf8') as stream:
        for line in stream:
            row = json.loads(line)
            if row['episode'] == args.episode and row['frame'] in wanted:
                record = replay(row); records.append(record)
                print(json.dumps(record, allow_nan=False), flush=True)
    if {r['frame'] for r in records} != wanted:
        raise ValueError('Some requested snapshots were missing')
    output = dict(records=records, limitation='Same-observation model diagnostic only. '
        'No CARLA success/safety conclusion; a v15 local-only path cannot establish full-route scoring quality.')
    args.output.write_text(json.dumps(output, allow_nan=False, indent=2), encoding='utf8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
