#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【阶段 0·离线判决回放】不跑 CARLA，判定"改哪个口径能让 ③ 接管横向动作"。

为什么需要它（HANDOFF §5 / STATUS §6）
------------------------------------------------------------------
实测：规则**只用横向 d=0**（100%），而 EFE 只想要 **d=−1.5**（100%）
⇒ 横向动作样本只有 111~520（规则动作 9000~16000）
⇒ 在 Hoeffding 置信界下 `δ(111)=340`，接管条件 `ΔQ̂ > δ(a)+δ(rule)` 需 **>419**，
   而实测 ΔQ̂ 只有 **+79** ⇒ **③ 永远无法选中横向动作**。

本脚本用**现有 R-tree**（state/action/return）复现式43-46 的判决，比较不同口径：

  V0 现状           : Hoeffding, range=p1–p99, var_weight=1.0
  V1 p5–p95         : Hoeffding, range=p5–p95
  V2 方差型 t-CI    : δ = z·σ/√n（不用 range）
  V3 var_weight×30  : 论文式60 的方差项加权到与 Hoeffding 同量级
  V4 论文原式       : Hoeffding, range=全极差（最保守）

核心判据（**不需要 rule_action**）：
  「**argmax WCV 的动作，是否带横向 offset（≠ d=0）**」
  —— 若在任何口径下都恒为 d=0，说明 ③ 的**排序**根本不会偏好横向（改 δ 无用）；
     若在某口径下出现横向，则该口径就是解锁点。

⚠️ 本脚本**忠实复现** `trustset_dds.TS_traj_ConfidenceValue` 的逻辑（含 ±1e9 哨兵、
   `n_thres=10`、`BCV = min(bcv_max, mean + δ)`、`WCV = mean − δ − var_weight·4σ/(n+1)`）
   与 `active_inference.takeover_rule` 的阈值语义。

用法： python Tools/offline_wcv_replay.py <run_dir> [n_query] [seed]
"""
from __future__ import annotations

import collections
import math
import os
import pickle
import sys

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

RUN = sys.argv[1] if len(sys.argv) > 1 else 'A6fix100'
NQ = int(sys.argv[2]) if len(sys.argv) > 2 else 400
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 0

# ===== 与真实代码一致的常量（逐一对照 trustset_dds.py）=====
N_THRES = 10
ALPHA = 0.05
BCV_MAX = 1e9
WCV_MIN = -1e9
B = 0.1                       # Rtree_env.b 状态离散化参数
#: compare_signs 的 8 维容差（trustset_dds.compare_signs）
TOL8 = np.array([3.0, 3.0, 3.0, 3.0, 0.8, 3.0, 0.02, 1.5])
LAT_OF = lambda a: int(a) % 3          # 0→d=−1.5, 1→d=0.0, 2→d=+1.5
LAT_NAME = {0: '-1.5', 1: '0.0', 2: '+1.5'}


def load(run):
    p = os.path.join(run, 'rtree_env_data.pkl')
    d = pickle.load(open(p, 'rb'))
    loc = d['locations']
    S = np.array([u[0] for u in loc], float)
    E = np.array([u[1] for u in loc], float)
    A = np.array([int(u[2]) for u in loc], int)
    G = np.array([float(u[3]) for u in loc], float)
    sb = np.asarray(d['state_bounds'], float)
    return S, E, A, G, sb


def _delta(vals, rng, mode):
    """按口径返回置信半径。"""
    n = len(vals)
    if n <= 0:
        return float('inf')
    if mode == 't':
        sd = float(np.std(vals, ddof=1)) if n > 1 else 0.0
        return 1.96 * sd / math.sqrt(n)
    return float(rng) * math.sqrt(math.log(1.0 / ALPHA) / (2.0 * n))


def _var_corr(vals, w):
    n = len(vals)
    if n <= 1:
        return 0.0
    return float(w) * 4.0 * float(np.std(vals, ddof=1)) / (n + 1.0)


def replay(S, E, A, G, sr, qidx, mode, rng, var_w):
    """对每个 query 状态复现判决，返回 (argmax 动作, 各动作 n) 列表。"""
    out = []
    for i in qidx:
        m = np.all(np.abs(S - S[i]) <= sr, axis=1)
        m &= np.all(np.abs(E - E[i]) <= TOL8, axis=1)
        js = np.where(m)[0]
        if len(js) == 0:
            out.append((None, {}))
            continue
        by = collections.defaultdict(list)
        for j in js:
            by[A[j]].append(G[j])
        # ---- 复现 TS_traj_ConfidenceValue：非规则动作取 WCV；此处对**所有**动作算 WCV ----
        wcv = {}
        for a, v in by.items():
            if len(v) < N_THRES:
                wcv[a] = WCV_MIN            # 哨兵：样本不足
                continue
            mu = float(np.mean(v))
            wcv[a] = mu - _delta(v, rng, mode) - _var_corr(v, var_w)
        if not wcv:
            out.append((None, {}))
            continue
        best = max(wcv, key=lambda a: wcv[a])
        if wcv[best] <= WCV_MIN + 1.0:      # 全是哨兵
            best = None
        out.append((best, {a: len(v) for a, v in by.items()}))
    return out


def main():
    if not os.path.exists(os.path.join(RUN, 'rtree_env_data.pkl')):
        print(f'找不到 {RUN}/rtree_env_data.pkl')
        return 1
    S, E, A, G, sb = load(RUN)
    sr = B * (sb[1] - sb[0])
    s = np.sort(G)
    R_FULL = float(s[-1] - s[0])
    R_199 = float(s[int(0.99 * (len(s) - 1))] - s[int(0.01 * (len(s) - 1))])
    R_595 = float(s[int(0.95 * (len(s) - 1))] - s[int(0.05 * (len(s) - 1))])

    print('=' * 96)
    print(f'【阶段 0·离线判决回放】run={RUN}  R-tree 样本={len(S)}  查询数={min(NQ, len(S))}')
    print('=' * 96)
    print(f'  (R_max−R_min): 全极差={R_FULL:.0f}  p1–p99={R_199:.0f}  p5–p95={R_595:.0f}')
    # 样本分布（说明横向动作有多缺样本）
    cnt = collections.Counter(A.tolist())
    print(f'\n  逐动作全局样本数: ' + '  '.join(f'{a}:{cnt.get(a,0)}' for a in range(12)))
    minlat = min(cnt.get(a, 0) for a in range(12) if LAT_OF(a) != 1)
    print(f'  ⇒ 横向动作最小样本 = {minlat}；规则主力动作(action 4) = {cnt.get(4,0)}')

    rng_ = np.random.RandomState(SEED)
    qidx = rng_.choice(len(S), size=min(NQ, len(S)), replace=False)

    VARIANTS = [
        ('V0 现状(Hoeffding,p1–p99,w=1)', 'hoef', R_199, 1.0),
        ('V1 Hoeffding,p5–p95,w=1', 'hoef', R_595, 1.0),
        ('V2 全极差(论文原式最保守)', 'hoef', R_FULL, 1.0),
        ('V3 Hoeffding,p1–p99,w=30', 'hoef', R_199, 30.0),
        ('V4 方差型 t-CI(不用range)', 't', 0.0, 1.0),
    ]
    print('\n' + '=' * 96)
    print('【结果】不同置信口径下，**argmax WCV 的横向分布**')
    print('=' * 96)
    print(f"{'口径':<34}{'有效查询':<10}{'d=−1.5':<10}{'d=0.0':<10}{'d=+1.5':<10}{'横向占比'}")
    summary = {}
    for name, mode, R, vw in VARIANTS:
        res = replay(S, E, A, G, sr, qidx, mode, R, vw)
        lat = collections.Counter()
        nq = 0
        for best, _ in res:
            if best is None:
                continue
            nq += 1
            lat[LAT_OF(best)] += 1
        if nq == 0:
            print(f'{name:<34}{0:<10}(无有效查询)')
            continue
        pct_lat = 100.0 * (lat[0] + lat[2]) / nq
        print(f'{name:<34}{nq:<10}{lat[0]:<10}{lat[1]:<10}{lat[2]:<10}{pct_lat:.1f}%')
        summary[name] = (nq, dict(lat), pct_lat)

    print('\n' + '=' * 96)
    print('判读：')
    print('  · 若某口径下 **d=−1.5 的占比从 0 变成 >0** ⇒ 该口径**解锁**了横向偏好 ✅')
    print('  · 若所有口径下 d=0 仍占绝大多数 ⇒ **改 δ 无用**，问题在 Q̂ 本身')
    print('    （即横向动作的**价值估计**确实更差，而不只是置信界太宽）')
    print('  ⚠️ 本回放用的是**全回合回报**（R-tree 里存的就是它）；')
    print('     式38 窗口回报的效果需等 G10（日志补全）修好后才能精确回放。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
