#!/usr/bin/env python3
"""Reference-isolation repair, measured overhead and a frozen learning pilot."""
import argparse
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile

if __package__:
    from . import run_rolling_validation_v24 as base
else:
    import run_rolling_validation_v24 as base

ROOT=base.ROOT
TIMINGS=('generation_ms','mpc_reset_ms','mpc_solve_ms','execution_ms','score_ms',
         'prediction_ms','road_audit_ms','selection_ms','cg_restore_ms','feedback_road_ms')


def build_plan(output,train_episodes=20,probe_episodes=3,eval_episodes=2,eval_seeds=None):
    return base.build_plan(output,train_episodes,probe_episodes,eval_episodes,
                           [81,82] if eval_seeds is None else eval_seeds)


def summary(values):
    if not values: return dict(n=0,mean=None,p95=None,maximum=None)
    ordered=sorted(values); position=.95*(len(ordered)-1); lower=int(position)
    p95=ordered[lower]+(position-lower)*(ordered[min(lower+1,len(ordered)-1)]-ordered[lower])
    return dict(n=len(values),mean=statistics.mean(values),p95=p95,maximum=max(values))


def inspect_runtime(directory):
    errors=Counter(); timing=defaultdict(list); replan=defaultdict(list); held=defaultdict(list)
    counts=Counter(); rows=reference_errors=0
    try:
        meta=json.loads((directory/'rolling_metadata_v24.json').read_text(encoding='utf8'))
        if (meta['execution_revision']!='isolated_cg_v25' or meta['audit_revision']!='shared_forecast_v25'):
            errors['runtime_revision']+=1
        with (directory/'matrix_decisions.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                p=json.loads(line)['rolling_trajectory']; rows+=1
                if (p['execution_revision']!='isolated_cg_v25' or len(p['cg_reference_hash'])!=64
                        or p['cg_reference_hash']!=p['baseline_path_hash']):
                    reference_errors+=1; errors['cg_reference']+=1
                profile=p['timing']
                for key in TIMINGS:
                    value=profile[key]
                    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0.:
                        errors['invalid_timing']+=1; continue
                    timing[key].append(value)
                    (replan if p['replanned'] else held)[key].append(value)
                for key in ('prediction_calls','prediction_hits'):
                    if not isinstance(profile[key],int) or isinstance(profile[key],bool) or profile[key]<0:
                        errors['invalid_prediction_counts']+=1
                    else: counts[key]+=profile[key]
                for key in ('map_queries','map_cache_hits','map_query_ms','audit_calls'):
                    value=p['map_statistics'][key]
                    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0.:
                        errors['invalid_map_statistics']+=1
                    else: counts[key]+=value
        if not rows: errors['empty_runtime']+=1
    except (OSError,ValueError,KeyError,TypeError,OverflowError): errors['missing_or_invalid_runtime_evidence']+=1
    return dict(ok=not errors,rows=rows,reference_error_frames=reference_errors,errors=dict(errors),
        counters=dict(counts),timing={key:summary(v) for key,v in timing.items()},
        replans={key:summary(v) for key,v in replan.items()},held={key:summary(v) for key,v in held.items()})


def collect_report(output,stages):
    report=base.collect_report(output,stages)
    runs=[]; errors=Counter(); reference_errors=0
    for planned,current in zip(stages,report['stages']):
        for arm in planned['arms']:
            if not arm.startswith('T'): continue
            for seed in planned['seeds']:
                directory=output/planned['name']/('%s_seed%d'%(arm,seed))
                if not directory.exists(): continue
                audit=inspect_runtime(directory)
                runs.append(dict(stage=planned['name'],arm=arm,seed=seed,**audit))
                errors.update(audit['errors']); reference_errors+=audit['reference_error_frames']
                if not audit['ok']:
                    current['collection_ok']=False
                    current['errors'].append('%s seed%d: v25 reference/timing evidence failed'%(arm,seed))
    report.update(revision='rolling_reference_repair_v25',
        v25_runtime=dict(ok=not errors,reference_error_frames=reference_errors,errors=dict(errors),runs=runs),
        timing_note='Stage timers are inclusive: generation includes generated-path road checks; '
                    'execution/score include their forecast time. Do not sum overlapping timers. '
                    'No real-time or driving-benefit claim follows from successful collection.')
    report['collection_ok']=report['smoke_identity']['ok'] and all(s['collection_ok'] for s in report['stages'])
    (output/'ROLLING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    with (output/'COMPARISON.txt').open('a',encoding='utf8') as stream:
        stream.write('v25 reference errors=%d; runtime errors=%s\n'%(reference_errors,json.dumps(dict(errors))))
        stream.write(report['timing_note']+'\n')
    return report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-episodes',type=int,default=20)
    parser.add_argument('--probe-episodes',type=int,default=3)
    parser.add_argument('--eval-episodes',type=int,default=2)
    parser.add_argument('--eval-seeds',default='81,82')
    parser.add_argument('--output-root',type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args(argv)
    try:
        seeds=[int(value) for value in args.eval_seeds.split(',')]
        if min(args.train_episodes,args.probe_episodes,args.eval_episodes)<1 or not seeds or len(set(seeds))!=len(seeds):
            raise ValueError('Positive counts and unique evaluation seeds are required')
        if any(seed in (70,71,72,73) for seed in seeds):
            raise ValueError('Evaluation seeds must be separate from smoke/probe/train seeds')
    except ValueError as exc: parser.error(str(exc))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_rolling_v25_'+stamp)).resolve()
    stages=build_plan(output,args.train_episodes,args.probe_episodes,args.eval_episodes,seeds)
    if args.dry_run:
        for stage in stages: print(json.dumps(stage))
        return 0
    archive=Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists(): parser.error('Output/archive already exists; choose a new output-root')
    output.mkdir(parents=True)
    workflow=dict(revision='rolling_reference_repair_v25',planned_episodes=sum(s['episodes_total'] for s in stages),
                  stages=stages,overall_success=None,efe_enabled=False)
    file=output/'WORKFLOW.json'; status=1; checkpoint_hash=None
    checkpoint=output/'02_train/T2_train_v24_seed73/rolling_model/rolling_model.json'
    try:
        for stage in stages:
            if stage['name']=='03_eval': checkpoint_hash=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            stage['status']='running'; file.write_text(json.dumps(workflow,indent=2),encoding='utf8')
            print('[%s] planned episodes=%d'%(stage['name'],stage['episodes_total']),flush=True)
            run=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
            stage['returncode']=run.returncode
            report=collect_report(output,stages)
            current=next(s for s in report['stages'] if s['name']==stage['name'])
            status=run.returncode or (15 if not current['collection_ok'] else 0)
            if stage['name']=='00_smoke' and not report['smoke_identity']['ok']: status=status or 12
            if stage['name']=='01_probe' and not report['spatial_execution_observed']:
                status=status or 13
                workflow['stop_reason']='No new spatial action executed; preserve logs before expanding training'
            if stage['name']=='03_eval':
                unchanged=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==checkpoint_hash
                report['frozen_checkpoint_unchanged']=unchanged
                (output/'ROLLING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
                if not unchanged: status=status or 14
            stage['status']='collected' if status==0 else 'failed'
            if status:
                workflow.setdefault('stop_reason','Stage failed independent collection/reference checks; return all logs')
                break
    except KeyboardInterrupt: status=130; workflow['error']='Interrupted; partial results retained'
    except Exception as exc: status=1; workflow['error']='%s: %s'%(type(exc).__name__,exc)
    finally:
        workflow.update(exit_code=status,overall_success=status==0,finished_utc=datetime.now(timezone.utc).isoformat())
        file.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
        with tarfile.open(str(archive),'w:gz') as stream: stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__': raise SystemExit(main())
