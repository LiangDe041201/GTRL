"""Validate spatial proposal ownership separately from frozen CG payoffs."""
from collections import Counter
import math
from Tools.validate_trajectory_probe_v21 import _validate_payload


def _road_ok(audit):
    return bool(audit['accepted'] and audit['complete'] and audit['checked_points'] > 0
                and isinstance(audit['witness_hash'], str) and len(audit['witness_hash']) == 64
                and audit['reason'] is None)


def validate_spatial_record(row, ego, mode, previous_control=None):
    errors = Counter()
    try:
        p = row['spatial_probe']
        offsets = dict(observe=0., center=0., plus=.5, minus=-.5)
        if (mode not in offsets or p['mode'] != mode or p['revision'] != 'spatial_probe_v23'
                or p['active'] != row['active'] or p['baseline_intent'] != row['selected']
                or p['learning_enabled'] or p['efe_reward_enabled'] or not p['final_reviewed']
                or p['proposal']['offset_m'] != offsets[mode]):
            errors['mode'] += 1
        cs = p['candidates']
        by_id = {c['id']: c for c in cs}
        if not 2 <= len(cs) <= 3 or len(by_id) != len(cs):
            errors['candidate_set'] += 1
        for c in cs:
            try:
                _validate_payload(dict(path=c['path'], path_hash=c['path_hash'], candidates=[c]))
            except (KeyError, TypeError, ValueError, IndexError, OverflowError):
                errors['path_or_plan_payload'] += 1
            if c['solve_ok'] and (abs(c['plan'][0][0]-c['a']) > 1e-8 or abs(c['plan'][1][0]-c['delta']) > 1e-8):
                errors['first_control'] += 1
        names = ('defer', 'proceed')
        baseline = row['selected']
        for i, name in enumerate(names):
            c = by_id[name+'_base']
            if c['source'] != 'cg' or c['intent'] != name or c['path_hash'] != p['baseline_path_hash']:
                errors['original_path'] += 1
            for field, source in [('target', 'candidate_targets'), ('a', 'candidate_a'), ('delta', 'candidate_delta')]:
                if abs(c[field]-row[source][i]) > 1e-8:
                    errors['original_candidate'] += 1
        eligible = False
        if len(cs) == 3:
            c = cs[2]
            execution = c['execution']
            road_ok = len(c['road_predictions']) == 3 and all(_road_ok(r) for r in c['road_predictions'])
            gap = execution['proposed_gap']
            gap_ok = execution['unbounded_gap'] if gap is None else math.isfinite(gap) and gap >= .2
            if execution['accepted'] and not (execution['solve_ok'] and execution['forecast_valid'] and execution['stop_feasible'] and gap_ok):
                errors['execution_acceptance'] += 1
            if c['road_predictions_ok'] != road_ok:
                errors['road_prediction'] += 1
            eligible = bool(c['solve_ok'] and execution['accepted'] and road_ok
                            and all(part['admissible'] for part in c['components']))
            if (c['eligible'] != eligible or c['intent'] != 'proceed'
                    or abs(c['target']-row['candidate_targets'][1]) > 1e-8
                    or not _road_ok(p['proposal']['path_road'])
                    or p['proposal']['max_curvature'] > p['proposal']['curvature_limit']):
                errors['spatial_qualification'] += 1
        expected_change = bool(eligible and baseline == 1 and mode != 'observe' and not p['retracted'])
        request = by_id.get(p['request_id'])
        if (p['changed_request'] != expected_change or request != p['request'] or request is None
                or not expected_change and p['request_id'] != names[baseline]+'_base'):
            errors['request_owner'] += 1
        if request is not None:
            for field, logged in [('a', 'pre_audit_a'), ('delta', 'pre_audit_delta'), ('target', 'pre_audit_target')]:
                if abs(request[field]-row[logged]) > 1e-8:
                    errors['request_control'] += 1
        for field, display in [('a', 'a_prev'), ('df', 'steer_prev')]:
            value, saved = float(p['previous'][field]), float(ego[display])
            if not math.isfinite(value) or not math.isfinite(saved) or abs(round(value, 3)-saved) > 1e-12:
                errors['previous_control'] += 1
            if previous_control is not None and abs(value-previous_control[field]) > 1e-8:
                errors['previous_control_exact'] += 1
        f = p['feedback']
        if f['episode'] != row['episode'] or f['frame'] != row['frame'] or f['guard_action'] != row['guard_action']:
            errors['feedback'] += 1
        for field in ('applied_a', 'applied_delta', 'applied_target'):
            if abs(f[field]-row[field]) > 1e-8:
                errors['feedback'] += 1
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        errors['invalid_spatial_record'] += 1
    return dict(errors)
