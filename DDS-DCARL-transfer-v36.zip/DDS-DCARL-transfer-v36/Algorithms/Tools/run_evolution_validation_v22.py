#!/usr/bin/env python3
"""20-execution mechanism pilot: CG identity, parameter training, frozen replay.

Twelve training episodes are NOT a coverage or performance claim. Keep all
failures. Never disable trust in evaluation to force an apparent improvement.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

if __package__:
    from .run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS
else:
    from run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS

ROOT = Path(__file__).resolve().parents[1]


def build_plan(output, train_episodes=12):
    common = ['--method', 'CG', '--game-mode', 'matrix_v18', '--traffic', 'on',
              '--traffic-interaction', 'v17', '--control-profile', 'paper_v11',
              '--completion-mode', 'strict', '--belief-min-episodes', '10', '--keep-going']
    checkpoint = output/'01_train/E1_train_v22_seed41/trajectory_model/evolution_model.json'
    stages = []
    for name, episodes, seeds, arms in [
            ('00_smoke', 2, [40], ['M6_matrix_v18', 'E0_observe_v22']),
            ('01_train', train_episodes, [41], ['E1_train_v22']),
            ('02_eval', 2, [51], ['M6_matrix_v18', 'E2_eval_v22'])]:
        args = common+['--episodes', str(episodes), '--seeds', ','.join(map(str, seeds)),
            '--arms', ','.join(arms), '--output-root', str(output/name)]
        if name == '02_eval':
            args += ['--evolution-checkpoint', str(checkpoint)]
        stages.append(dict(name=name, episodes_per_run=episodes, seeds=seeds, arms=arms,
                           episodes_total=episodes*len(seeds)*len(arms), arguments=args))
    return stages


def identity(output):
    try:
        data = [_rows(output/'00_smoke'/(arm+'_seed40')/'interaction_ego.csv')
                for arm in ('M6_matrix_v18', 'E0_observe_v22')]
        if any(not rows or any(any(r.get(k) in (None, '') for k in PHYSICAL_FIELDS) for r in rows) for rows in data):
            raise ValueError('Missing physical evidence')
        values = [[tuple(r[k] for k in PHYSICAL_FIELDS) for r in rows] for rows in data]
        return dict(ok=values[0] == values[1], rows=[len(r) for r in data])
    except (OSError, ValueError, KeyError) as exc:
        return dict(ok=False, error=str(exc))


def collect_report(output, stages):
    reports = [_stage_report(output, s) for s in stages]
    report = dict(revision='trajectory_evolution_pilot_v22', stages=reports,
        actual_episodes=sum(g['n'] for s in reports for g in s['arms'].values()),
        planned_episodes=sum(s['episodes_total'] for s in stages), smoke_identity=identity(output),
        training={}, learning_benefit_established=False, beta_calibrated=False,
        note='Pilot only: CG owns intent; learning proposes bounded speed-profile parameters. '
             'EFE/lateral evolution are off. Exploration is not a trusted takeover. '
             'Insufficient coverage keeps CG; do not infer success from collection alone.')
    for s in reports:
        for group in s['arms'].values():
            group.pop('probe', None)  # Those fields describe the separate v21 experiment.
    model = output/'01_train/E1_train_v22_seed41/trajectory_model/evolution_model.json'
    if model.is_file():
        data = json.loads(model.read_text(encoding='utf8'))
        by_state = defaultdict(lambda: defaultdict(set))
        for r in data['records']:
            by_state[r['state']][str(r['ratio'])].add(r['episode'])
        report['training'] = dict(records=len(data['records']), states=len(data['nodes']),
            executed_ratios=dict(Counter(str(r['ratio']) for r in data['records'])),
            generated_ratios=sorted({r for n in data['nodes'].values() for r in n['proposed']}),
            covered_comparison_states=sum(len(v.get('1.0', set())) >= 10 and
                any(k != '1.0' and len(eps) >= 10 for k, eps in v.items()) for v in by_state.values()),
            checkpoint_sha256=hashlib.sha256(model.read_bytes()).hexdigest())
    report['collection_ok'] = all(s['collection_ok'] for s in reports) and report['smoke_identity']['ok']
    report['all_episodes_successful'] = report['collection_ok'] and all(
        g['n'] == g['success'] for s in reports for g in s['arms'].values())
    report['learning_mechanisms_observed'] = bool(report['training'].get('records'))
    report['new_parameter_executed'] = any(float(r) not in (1., .75)
                                          for r in report['training'].get('executed_ratios', {}))
    (output/'EVOLUTION_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = [report['note'], 'Executed episodes: %d/%d' % (report['actual_episodes'], report['planned_episodes']),
             'Collection=%s; all driving episodes successful=%s' % (report['collection_ok'], report['all_episodes_successful'])]
    for s in reports:
        for arm, g in s['arms'].items():
            lines.append('%s/%s: n=%d success=%d collision=%d stuck=%d mean_sim_s=%s' %
                (s['name'], arm, g['n'], g['success'], g['collisions'], g['stuck'], g['mean_all_episode_s']))
    lines.append('Training/coverage: '+json.dumps(report['training'], ensure_ascii=False))
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n', encoding='utf8')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-episodes', type=int, default=12)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    if args.train_episodes < 1:
        parser.error('Training episodes must be positive')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output = (args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_evolution_v22_'+stamp)).resolve()
    stages = build_plan(output, args.train_episodes)
    if args.dry_run:
        for s in stages:
            print(json.dumps(s))
        return 0
    archive = Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():
        parser.error('Output or archive already exists; choose a new output-root')
    output.mkdir(parents=True)
    workflow = dict(revision='trajectory_evolution_v22', planned_episodes=sum(s['episodes_total'] for s in stages),
                    stages=stages, overall_success=None, performance_claim=False)
    status = 1
    try:
        for stage in stages:
            print('[%s] planned episodes=%d' % (stage['name'], stage['episodes_total']), flush=True)
            completed = subprocess.run([sys.executable, '-u', str(ROOT/'Tools/run_relay_validation.py')]
                                       +stage['arguments'], cwd=str(ROOT))
            stage['returncode'] = completed.returncode
            current = _stage_report(output, stage)
            status = completed.returncode or (11 if not current['collection_ok'] else 0)
            if stage['name'] == '00_smoke' and not identity(output)['ok']:
                status = status or 12
            if stage['name'] == '01_train' and not (output/'01_train/E1_train_v22_seed41/trajectory_model/evolution_model.json').is_file():
                status = status or 13
            if status:
                break
        report = collect_report(output, stages)
        if not status and not report['collection_ok']:
            status = 11
    except KeyboardInterrupt:
        status = 130
        workflow['error'] = 'Interrupted; partial results preserved'
    except Exception as exc:
        status = 1
        workflow['error'] = '%s: %s' % (type(exc).__name__, exc)
    finally:
        workflow.update(exit_code=status, overall_success=status == 0,
                        finished_utc=datetime.now(timezone.utc).isoformat())
        (output/'WORKFLOW.json').write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
        with tarfile.open(str(archive), 'w:gz') as stream:
            stream.add(str(output), arcname=output.name)
        print('Result folder: '+str(output), flush=True)
        print('Return this archive, including failed runs: '+str(archive), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
