#!/usr/bin/env python3
"""Recheck the v13 precision false alarm without modifying original results."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from Tools.validate_matrix_game import validate_matrix_game

# Only the verification formula changed. Reusing a smoke test is inappropriate
# if any of its recorded driving/runtime source files changed.
ALLOWED_SOURCE_CHANGES = {'Tools/validate_matrix_game.py'}
REQUIRED_SOURCES = {
    'train_dcarl_turn.py', 'Agent/drl_library/dds_dcarl/dds_dcarl_turn.py',
    'Agent/game_theory/MPC.py', 'Planning_library/matrix_turn_game.py',
    'Planning_library/execution_guard.py', 'Planning_library/pedal_control.py',
    'Test_Scenarios/TestScenario_Town03_turn.py',
    'Test_Scenarios/cross_traffic_manager.py', 'Tools/validate_matrix_game.py',
}
REQUIRED_FLAGS = ('complete', 'ego_log_complete', 'execution_contract_ok',
                  'game_contract_ok', 'profile_contract_ok', 'actuator_contract_ok',
                  'traffic_spacing_contract_ok')


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _rows(path):
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def recheck_smoke(directory, source_root=None):
    root=Path(directory).resolve()
    source=Path(source_root or ROOT).resolve()
    manifest_path=root/'manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf8'))
    errors=[]
    runs=manifest.get('runs', [])
    if (manifest.get('episodes')!=5 or len(runs)!=1
            or runs[0].get('arm')!='M1_matrix' or runs[0].get('seed')!=1):
        raise ValueError('Expected the original 5-episode M1_matrix seed=1 smoke directory')
    config=runs[0].get('config', {})
    required_config=dict(DSH_METHOD='CG',DSH_COURNOT_MODE='matrix',DSH_TAKE_COURNOT='1',
        DSH_CONTROL_PROFILE='paper_v11',DSH_TRAFFIC='on',DSH_TRAFFIC_CLEAR_GAP='5.0',
        DSH_EFE='0',DSH_WCV_BCV='0')
    if any(config.get(key)!=value for key,value in required_config.items()):
        errors.append('smoke_configuration_changed')
    original_hashes=manifest.get('source_sha256', {})
    if not REQUIRED_SOURCES.issubset(original_hashes):
        errors.append('missing_required_source_hashes')
    differences=[]
    for name, expected in original_hashes.items():
        target=(source/name).resolve()
        if source not in target.parents or not target.is_file() or _hash(target)!=expected:
            differences.append(name)
    unexpected=sorted(set(differences)-ALLOWED_SOURCE_CHANGES)
    if unexpected:
        errors.append('driving_source_changed')
    run=root/'M1_matrix_seed1'
    result_path=run/'result.json'
    original=json.loads(result_path.read_text(encoding='utf8'))
    failed_flags=[flag for flag in REQUIRED_FLAGS if original.get(flag) is not True]
    if failed_flags:
        errors.append('original_non_matrix_checks_failed')
    if (original.get('returncode')!=0 or original.get('finished_episodes')!=5
            or original.get('expected_episodes')!=5):
        errors.append('original_run_incomplete')
    rows=_rows(run/'interaction_ego.csv')
    episodes=_rows(run/'interaction_summary.csv')
    outcomes=dict(Counter(row['outcome'] for row in episodes))
    if (outcomes!={'complete':5} or {row['episode'] for row in episodes}!={'1','2','3','4','5'}
            or {row['episode'] for row in rows}!={'1','2','3','4','5'}):
        errors.append('smoke_driving_not_five_successes')
    corrected=validate_matrix_game(run, rows, 'matrix_v13')
    if not corrected['matrix_contract_ok']:
        errors.append('corrected_matrix_check_failed')
    return dict(revision='matrix_precision_recheck_v13_1', original_directory=str(root),
        recheck_ok=not errors, errors=errors, outcomes=outcomes, failed_original_flags=failed_flags,
        original_matrix_errors=original.get('matrix_contract_errors'),
        changed_source_files=sorted(differences),unexpected_source_changes=unexpected,
        checked_source_hashes=len(original_hashes),corrected_matrix_check=corrected,
        original_file_sha256={
            'manifest.json':_hash(manifest_path), 'result.json':_hash(result_path),
            'interaction_ego.csv':_hash(run/'interaction_ego.csv'),
            'interaction_summary.csv':_hash(run/'interaction_summary.csv'),
            'matrix_decisions.jsonl':_hash(run/'matrix_decisions.jsonl')},
        note='Original files are unchanged. Recheck fixes CSV rounding validation only; '
             'it is not a new CARLA run or evidence of comparative driving benefit.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    parser.add_argument('--output',type=Path,required=True,help='New report path; never overwrites an existing file')
    args=parser.parse_args(argv)
    try:
        report=recheck_smoke(args.directory)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        report=dict(revision='matrix_precision_recheck_v13_1',recheck_ok=False,
                    errors=['unreadable_or_invalid_smoke'],detail=str(exc))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf8') as stream:
        json.dump(report,stream,ensure_ascii=False,indent=2)
    print(json.dumps(report,ensure_ascii=False))
    return 0 if report['recheck_ok'] else 9


if __name__=='__main__':
    raise SystemExit(main())
