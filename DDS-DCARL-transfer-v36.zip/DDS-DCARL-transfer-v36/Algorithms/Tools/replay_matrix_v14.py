#!/usr/bin/env python3
"""Offline prediction/decision replay, never a substitute for a new CARLA run."""
import argparse
from collections import defaultdict
import csv
import json
import math
from pathlib import Path
import statistics
import sys
from types import SimpleNamespace

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
from Planning_library.cournot_game import expected_payoff_response
from Planning_library.matrix_motion_v14 import MotionHistory, rv_action_track
from Planning_library.matrix_turn_game import rv_action_track as old_track, score_candidates as old_score
from Planning_library.matrix_turn_game_v14 import score_candidates


def _rows(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))


def motion_replay(comparison,arm='M1_matrix',seed=None,episode=None,stride=20):
    root=Path(comparison)
    manifest=json.loads((root/'manifest.json').read_text(encoding='utf8'))
    errors=defaultdict(lambda:dict(v13=[],v14=[]))
    considered=0
    for run in manifest['runs']:
        if run['arm']!=arm or seed is not None and run['seed']!=seed:
            continue
        directory=root/('%s_seed%d'%(arm,run['seed']))
        metadata=json.loads((directory/'traffic_spacing_metadata.json').read_text(encoding='utf8'))
        cruise=float(metadata['cruise_speed']);length=float(metadata['measured_length'])
        grouped=defaultdict(dict)
        for row in _rows(directory/'traffic_spacing_samples.csv'):
            ep,frame=int(row['episode']),int(row['frame'])
            if episode is not None and ep!=episode:
                continue
            # Do not read behavior, policy, commanded_speed or future intent.
            grouped[ep,frame][int(row['actor_id'])]=dict(x=float(row['x']),y=float(row['y']),
                                                       v=float(row['observed_speed']))
        decisions={}
        with (directory/'matrix_decisions.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                row=json.loads(line)
                if row['active']:
                    decisions[row['episode'],row['frame']]=row
        history=None;last_episode=None
        for (ep,frame),sample in sorted(grouped.items()):
            if ep!=last_episode:
                history=MotionHistory(cruise);last_episode=ep
            objects=[]
            for identity,observed in sample.items():
                before=grouped.get((ep,frame-1),{}).get(identity)
                acc=None if before is None else (observed['v']-before['v'])/.05
                objects.append(SimpleNamespace(veh_id=identity,x=observed['x'],y=observed['y'],
                    v=observed['v'],vx=-observed['v'],vy=0.,yaw=math.pi,length=length,width=1.9,
                    acc=acc,acc_source='unavailable' if acc is None else 'observed_speed_difference'))
            history.observe(objects,frame)
            decision=decisions.get((ep,frame))
            if decision is None:
                continue
            rv=next((v for v in objects if v.veh_id==decision['rv_id']),None)
            if rv is None:
                continue
            _,_,evidence=history.estimate(rv,objects)
            if frame%stride:
                continue
            considered+=1
            times=np.linspace(0.,6.,121)
            old=old_track(rv,objects,times,cruise,False)
            new=rv_action_track(rv,objects,times,cruise,False,acceleration=evidence['acceleration'])
            for seconds in (1,3,6):
                actual=grouped.get((ep,frame+20*seconds),{}).get(rv.veh_id)
                if actual is None:
                    continue
                index=20*seconds
                for label,track in (('v13',old),('v14',new)):
                    errors[seconds][label].append(math.hypot(track[index,0]-actual['x'],track[index,1]-actual['y']))
    stats={str(seconds):dict(n=len(values['v13']),
        v13_mean_position_error_m=statistics.mean(values['v13']) if values['v13'] else None,
        v14_mean_position_error_m=statistics.mean(values['v14']) if values['v14'] else None)
        for seconds,values in sorted(errors.items())}
    return dict(kind='fixed_observation_prediction_only',considered_frames=considered,
        horizons_seconds=stats,
        note='Continue-column position error on recorded trajectories, conditional on future samples existing. '
             'Future samples are used only for scoring. This is not a new driving run, '
             'does not replay a different ego policy, and does not calibrate yield probabilities.')


def snapshot_replay(path,limit=20):
    results=[]
    with Path(path).open(encoding='utf8') as stream:
        for line in stream:
            row=json.loads(line)
            if not row['decision']['active']:
                continue
            ego=SimpleNamespace(**row['ego'])
            objects=[SimpleNamespace(**v) for v in row['objects']]
            rv=next((v for v in objects if v.veh_id==row['rv_id']),None)
            candidates=[]
            for candidate in row['candidates']:
                candidates.append(dict(candidate,**{key:None if candidate[key] is None else np.asarray(candidate[key],dtype=float)
                    for key in ('plan','prediction','times')}))
            args=(ego,objects,rv,candidates,row['geometry'],np.asarray(row['path']),row['previous'],row['cruise'])
            matrix,_=score_candidates(*args,observed_acceleration=row['decision']['motion_evidence'].get('acceleration'))
            for i in range(2):
                for j in range(2):
                    matrix[i][j]-=row['decision']['components'][i][j]['switch_cost']
            response=expected_payoff_response(matrix,row['decision']['p_yield'])
            residual=float(np.max(np.abs(np.asarray(matrix)-np.asarray(row['decision']['payoff_matrix']))))
            match=(response['ego_action']==row['decision']['selected']
                   or row['decision']['decision_mode']!='expected_response')
            old,_=old_score(*args)
            results.append(dict(episode=row['episode'],frame=row['frame'],payoff_residual=residual,
                choice_matches=match,v14_selected=response['ego_action'],
                v13_forecast_selected=expected_payoff_response(old,row['decision']['p_yield'])['ego_action']))
            if len(results)>=limit:
                break
    return dict(kind='recorded_candidate_payoff_replay',records=results,
        replay_ok=bool(results) and all(r['payoff_residual']<=1e-8 and r['choice_matches'] for r in results),
        note='Recomputes scores of recorded candidates; it does not simulate a changed closed-loop driving policy.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='mode',required=True)
    motion_parser=sub.add_parser('motion')
    motion_parser.add_argument('directory',type=Path)
    motion_parser.add_argument('--arm',default='M1_matrix')
    motion_parser.add_argument('--seed',type=int)
    motion_parser.add_argument('--episode',type=int)
    motion_parser.add_argument('--stride',type=int,default=20)
    snapshot_parser=sub.add_parser('snapshots')
    snapshot_parser.add_argument('path',type=Path)
    snapshot_parser.add_argument('--limit',type=int,default=20)
    for child in (motion_parser,snapshot_parser):
        child.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(argv)
    if args.mode=='motion':
        if args.stride<1:parser.error('stride must be positive')
        result=motion_replay(args.directory,args.arm,args.seed,args.episode,args.stride)
    else:
        if args.limit<1:parser.error('limit must be positive')
        result=snapshot_replay(args.path,args.limit)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf8') as stream:
        json.dump(result,stream,ensure_ascii=False,indent=2)
    print(json.dumps(result,ensure_ascii=False))
    return 0 if result.get('replay_ok',result.get('considered_frames',0)>0) else 1


if __name__=='__main__':
    raise SystemExit(main())
