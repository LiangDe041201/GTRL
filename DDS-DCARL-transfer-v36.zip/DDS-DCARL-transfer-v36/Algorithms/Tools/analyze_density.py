#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【密度扫描分析】2×2 因子设计：窗口宽度 × 窗口频率 → 规则退化曲线。

设计（run_density_sweep.sh）
------------------------------------------------------------------
  A  GAP_AFTER=3  GAP_SEC=11.0   现状（也是"当前代码 vs 旧代码 A0"的对照）
  B  GAP_AFTER=3  GAP_SEC= 6.0   窗口更紧
  C  GAP_AFTER=8  GAP_SEC=11.0   窗口更稀有
  D  GAP_AFTER=8  GAP_SEC= 6.0   两者都收紧

预先登记的判读（**在跑之前就定好**，避免事后解释）
------------------------------------------------------------------
  · B 退化而 C 不退化 ⇒ 窗口**宽度**是约束 ⇒ ① 有空间
  · C 退化而 B 不退化 ⇒ **等待代价**是约束 ⇒ ③/② 有空间
  · 两者都退化        ⇒ 在退化的格子里做归因
  · **都不退化**      ⇒ **密度不是杠杆，停止这条路**

用法： python Tools/analyze_density.py [EPISODES]
"""
from __future__ import annotations

import collections
import csv
import math
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARMS = [('D_A_ga3_gs11', 3, 11.0), ('D_B_ga3_gs6', 3, 6.0),
        ('D_C_ga8_gs11', 8, 11.0), ('D_D_ga8_gs6', 8, 6.0)]
#: 已知的旧代码规则基线（用于核对代码改动是否影响规则行为）
A0_LEGACY = 76.0


def outcomes(run):
    p = os.path.join(_HERE, run, 'interaction_summary.csv')
    if not os.path.exists(p):
        return None
    s = [r for r in csv.DictReader(open(p)) if r.get('episode')]
    if not s:
        return None
    c = collections.Counter(r['outcome'] for r in s)
    n = sum(c.values())
    pr = c['complete'] / n
    return dict(n=n, comp=100 * pr, se=100 * math.sqrt(pr * (1 - pr) / n),
                coll=100 * c['collision'] / n, stuck=100 * c['stuck'] / n)


def decision_stats(run):
    """从 ego 日志取规则判据统计（口径：rl_active 帧；纯规则臂 rl_active=False ⇒ 用 rv 日志兜底）。

    ⚠️ G10：ego 日志只记 rl_active 帧。纯规则臂（CG）rl_active=False ⇒ ego 日志**全空**。
       因此对纯规则臂，判据统计不可得 ⇒ 返回 None（如实标注，不臆造）。
    """
    p = os.path.join(_HERE, run, 'interaction_ego.csv')
    if not os.path.exists(p):
        return None
    rows = list(csv.DictReader(open(p)))
    if not rows:
        return None

    def g(r, k):
        v = r.get(k)
        return None if v in (None, '') else v

    n = len(rows)
    return dict(n=n,
                gap_ok=100.0 * sum(1 for r in rows if g(r, 'gap_ok') == '1') / n,
                entry=100.0 * sum(1 for r in rows if g(r, 'entry_granted') == '1') / n)


def main():
    print('=' * 96)
    print('【密度扫描】2×2 因子设计（全部纯规则；只改交通密度）')
    print('=' * 96)
    res = {}
    for run, ga, gs in ARMS:
        o = outcomes(run)
        if o:
            res[(ga, gs)] = o

    print(f"\n{'格子':<8}{'GAP_AFTER':<11}{'GAP_SEC':<10}{'n':<6}{'成功%':<9}{'±95%CI':<9}"
          f"{'碰撞%':<9}{'卡死%'}")
    for run, ga, gs in ARMS:
        o = res.get((ga, gs))
        tag = run.split('_')[1]          # 'A' / 'B' / 'C' / 'D'
        if o is None:
            print(f"{tag:<8}{ga:<11}{gs:<10}(无数据)")
            continue
        print(f"{tag:<8}{ga:<11}{gs:<10}{o['n']:<6}{o['comp']:<9.1f}{1.96*o['se']:<9.1f}"
              f"{o['coll']:<9.1f}{o['stuck']:<9.1f}")

    # ---------- 对照：当前代码的 A 格 vs 旧代码 A0 ----------
    a = res.get((3, 11.0))
    if a:
        print(f"\n【对照】当前代码 A 格 = {a['comp']:.1f}%  vs  旧代码 A0_rule_base = {A0_LEGACY:.1f}%")
        d = a['comp'] - A0_LEGACY
        print(f"  差 = {d:+.1f} pp（±{1.96*math.sqrt(a['se']**2 + (8.4/1.96)**2):.1f}）")
        print(f"  ⇒ {'✅ 代码改动未影响规则基线（对照通过）' if abs(d) < 13 else '⚠️ 差异较大，需查因'}")

    # ---------- 因子效应 ----------
    print('\n' + '=' * 96)
    print('【因子效应】窗口宽度 与 窗口频率 各自对规则成功率的影响')
    print('=' * 96)

    def diff(k1, k2, label):
        o1, o2 = res.get(k1), res.get(k2)
        if not o1 or not o2:
            print(f'  {label}: 数据不全')
            return None
        d = o2['comp'] - o1['comp']
        se = math.sqrt(o1['se'] ** 2 + o2['se'] ** 2)
        ci = 1.96 * se
        verdict = ('✅ 显著下降' if d + ci < 0 else
                   ('✅ 显著上升' if d - ci > 0 else '⚠️ 不显著'))
        print(f"  {label:<40}{d:+6.1f} pp  (±{ci:.1f})  {verdict}")
        return d

    print('  —— 窗口宽度效应（GAP_SEC 11.0 → 6.0，固定 GAP_AFTER）——')
    w3 = diff((3, 11.0), (3, 6.0), 'GAP_AFTER=3: 11.0s → 6.0s')
    w8 = diff((8, 11.0), (8, 6.0), 'GAP_AFTER=8: 11.0s → 6.0s')
    print('  —— 窗口频率效应（GAP_AFTER 3 → 8，固定 GAP_SEC）——')
    f11 = diff((3, 11.0), (8, 11.0), 'GAP_SEC=11.0: 每3辆 → 每8辆')
    f6 = diff((3, 6.0), (8, 6.0), 'GAP_SEC=6.0: 每3辆 → 每8辆')

    # ---------- 预先登记的判读 ----------
    print('\n' + '=' * 96)
    print('【预先登记的判读】')
    print('=' * 96)
    wdeg = (w3 is not None and w3 < -13) or (w8 is not None and w8 < -13)
    fdeg = (f11 is not None and f11 < -13) or (f6 is not None and f6 < -13)
    if wdeg and not fdeg:
        print('  ⇒ **窗口宽度**是约束（B 退化、C 不退化）⇒ ① 的授权机制有作用空间')
    elif fdeg and not wdeg:
        print('  ⇒ **等待代价**是约束（C 退化、B 不退化）⇒ ③/② 有作用空间')
    elif wdeg and fdeg:
        print('  ⇒ **两者都是约束** ⇒ 在退化最明显的格子里做归因实验')
    else:
        print('  ⇒ **都没有显著退化** ⇒ **密度不是杠杆，应停止这条路**')
        print('     （注：门槛取 13pp，即 100 回合的分辨极限）')
    print('\n  ⚠️ 分辨率：100 回合只能分辨 ≥13 pp；小于此的差异不可判读。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
