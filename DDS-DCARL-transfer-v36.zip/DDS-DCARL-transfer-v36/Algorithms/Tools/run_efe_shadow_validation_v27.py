#!/usr/bin/env python3
"""Six-episode optional EFE observer regression, not an EFE benefit experiment."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

if __package__:
    from .run_trajectory_validation_v21 import _rows,_stage_report,PHYSICAL_FIELDS
else:
    from run_trajectory_validation_v21 import _rows,_stage_report,PHYSICAL_FIELDS

ROOT=Path(__file__).resolve().parents[1]


def build_plan(output,episodes=3,seed=104):
    arms=['T2_train_v24','T4_efe_shadow_v27']
    args=['--method','CG','--game-mode','matrix_v18','--traffic','on','--traffic-interaction','v17',
        '--control-profile','paper_v11','--completion-mode','strict','--keep-going',
        '--road-audit','local_v26','--rolling-epsilon','.3','--episodes',str(episodes),
        '--seeds',str(seed),'--arms',','.join(arms),'--output-root',str(output/'00_shadow')]
    return [dict(name='00_shadow',episodes_per_run=episodes,seeds=[seed],arms=arms,
                 episodes_total=2*episodes,arguments=args)]


def _canonical(value,actors,key=None):
    # CARLA actor IDs and absolute simulator frame numbers differ between two
    # sequential runs. Preserve per-episode frames, all physics and model data.
    ignored={'efe_shadow','timing','audit_profile','observed_sim_frame'}
    actor_keys={'id','actor','actor_id','rv_id','leader_id','follower_id'}
    if isinstance(value,dict):
        return {k:_canonical(v,actors,k) for k,v in value.items()
                if k not in ignored and not k.endswith('_ms')}
    if isinstance(value,list): return [_canonical(v,actors,key) for v in value]
    if key in actor_keys and value is not None and str(value).isdigit():
        actor=str(value)
        if actor not in actors: actors[actor]='actor_%d'%len(actors)
        return actors[actor]
    return value


def compare_runs(off,shadow):
    """Exact physical CSV, normalized diagnostic records and byte-identical Q."""
    errors=[]; counts=[]
    try:
        signatures=[]
        for root in (Path(off),Path(shadow)):
            rows=_rows(root/'interaction_ego.csv')
            if not rows or any(any(r.get(k) in (None,'') for k in PHYSICAL_FIELDS) for r in rows):
                raise ValueError('Missing physical/control evidence')
            signatures.append([tuple(r[k] for k in PHYSICAL_FIELDS) for r in rows]); counts.append(len(rows))
        if signatures[0]!=signatures[1]: errors.append('physical_control_changed')
        actors=[{},{}]; count=0
        with (Path(off)/'matrix_decisions.jsonl').open(encoding='utf8') as a:
            with (Path(shadow)/'matrix_decisions.jsonl').open(encoding='utf8') as b:
                from itertools import zip_longest
                for left,right in zip_longest(a,b):
                    count+=1
                    if left is None or right is None: errors.append('record_count'); break
                    x,y=json.loads(left),json.loads(right)
                    if _canonical(x,actors[0])!=_canonical(y,actors[1]):
                        errors.append('control_prediction_learning_record_changed_at_%d'%count); break
        if count!=counts[0]: errors.append('record_frame_coverage')
        models=[(Path(p)/'rolling_model/rolling_model.json').read_bytes() for p in (off,shadow)]
        if models[0]!=models[1]: errors.append('learned_model_bytes_changed')
        hashes=[hashlib.sha256(v).hexdigest() for v in models]
    except (OSError,ValueError,KeyError,TypeError) as exc:
        errors.append('missing_or_invalid_pair_evidence: '+str(exc)); hashes=[]
    return dict(ok=not errors,errors=errors,physical_rows=counts,model_sha256=hashes,
        excluded='Shadow data, CPU timers, absolute simulator frames; actor IDs renamed consistently. '
                 'Requests, predictions, rewards, experience and model values are compared.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--episodes',type=int,default=3,help='Episodes per arm; default total is six')
    parser.add_argument('--seed',type=int,default=104)
    parser.add_argument('--output-root',type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args(argv)
    if args.episodes<1: parser.error('Episodes must be positive')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_efe_shadow_v27_'+stamp)).resolve()
    stage=build_plan(output,args.episodes,args.seed)[0]
    if args.dry_run: print(json.dumps(stage)); return 0
    archive=Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists(): parser.error('Choose an unused output-root; previous evidence is never overwritten')
    output.mkdir(parents=True)
    workflow=dict(revision='efe_shadow_regression_v27',planned_episodes=stage['episodes_total'],
        stage=stage,efe_reward_enabled=False,efe_probability_calibrated=False,benefit_established=False,overall_success=None)
    path=output/'WORKFLOW.json'; status=1
    path.write_text(json.dumps(workflow,indent=2),encoding='utf8')
    try:
        print('[EFE shadow] %d episodes; driving policy and reward unchanged.'%stage['episodes_total'],flush=True)
        run=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
        collected=_stage_report(output,stage)
        pair=compare_runs(output/'00_shadow'/('T2_train_v24_seed%d'%args.seed),
                          output/'00_shadow'/('T4_efe_shadow_v27_seed%d'%args.seed))
        status=run.returncode or (16 if not collected['collection_ok'] or not pair['ok'] else 0)
        report=dict(collection=collected,off_shadow_identity=pair,efe_benefit_established=False,
            note='A match validates non-interference, not driving benefit or probability calibration.')
        (output/'EFE_SHADOW_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    except KeyboardInterrupt: status=130; workflow['error']='Interrupted; partial results retained'
    except Exception as exc: status=1; workflow['error']='%s: %s'%(type(exc).__name__,exc)
    finally:
        workflow.update(exit_code=status,overall_success=status==0,finished_utc=datetime.now(timezone.utc).isoformat())
        path.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
        with tarfile.open(str(archive),'w:gz') as stream: stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__': raise SystemExit(main())
