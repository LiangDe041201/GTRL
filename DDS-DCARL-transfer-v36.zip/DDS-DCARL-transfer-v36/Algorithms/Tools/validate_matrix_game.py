"""Audit matrix entry authority against full-frame applied-control evidence."""
import json
import math
from collections import Counter
from pathlib import Path


def _matches_precision(value, logged, decimals):
    """Compare a full-precision value with the CSV writer's declared rounding."""
    actual, saved = float(value), float(logged)
    return (math.isfinite(actual) and math.isfinite(saved)
            and abs(round(actual, decimals)-saved) <= 1e-12)


def _matrix_records(path, errors=None):
    if path.is_file():
        with path.open(encoding='utf8') as stream:
            for line in stream:
                try:
                    record = json.loads(line)
                    if not isinstance(record, dict):
                        raise ValueError('Expected a JSON object')
                    yield record
                except (ValueError, TypeError):
                    if errors is not None: errors['invalid_json'] += 1


def validate_matrix_game(directory, ego_rows, expected_controller, expected_probe=None, expected_evolution=None, expected_spatial=None, expected_rolling=None, expected_rolling_learner='legacy_v24'):
    # v19 retains the v18 payoff kernel, with a separate audited request owner.
    kernel='matrix_v18' if expected_controller in ('matrix_v19','matrix_v20') else expected_controller
    path = Path(directory)/'matrix_decisions.jsonl'
    errors, rows_read = Counter(), 0
    expected = {(str(r['episode']), str(r['frame'])): r for r in ego_rows}
    seen = set()
    active, choices, accepted, overridden = 0, Counter(), Counter(), Counter()
    switches, moving_defers, fallback, opportunity_waits = 0, 0, 0, 0
    revision=('matrix_entry_v20' if expected_controller=='matrix_v20' else
              'matrix_entry_v19' if expected_controller=='matrix_v19' else
              'matrix_entry_v18' if expected_controller=='matrix_v18' else
              'matrix_entry_v17' if expected_controller=='matrix_v17' else
              'matrix_entry_v16' if expected_controller=='matrix_v16' else
              'matrix_entry_v14' if expected_controller=='matrix_v14' else 'matrix_entry_v13')
    times, actual_times, stops = [], [], Counter()
    probe_errors, probe_rows, probe_changes = Counter(), 0, 0
    probe_active, probe_generated, probe_eligible = 0, 0, 0
    previous_submissions = {}
    evolution_errors, evolution_counts, evolution_ratios = Counter(), Counter(), Counter()
    spatial_errors, spatial_counts, spatial_statuses = Counter(), Counter(), Counter()
    rolling_errors, rolling_rows = Counter(), 0
    for row in _matrix_records(path,errors):
        rows_read += 1
        key = (str(row.get('episode')), str(row.get('frame')))
        ego = expected.get(key)
        if key in seen:
            errors['duplicate_frame'] += 1
        seen.add(key)
        if ego is None:
            errors['unknown_ego_frame'] += 1
            continue
        try:
            if expected_rolling is not None:
                from Tools.validate_rolling_v24 import SELECT_FIRST_LEARNERS, select_first_audit_hold, validate_rolling_record
                previous = previous_submissions.get(key[0])
                frame = int(row['frame'])
                adjacent = previous is not None and previous['frame']+1 == frame
                previous_control = previous['control'] if adjacent else None
                previous_audit_hold = previous.get('audit_hold') if adjacent else None
                row_errors = validate_rolling_record(row,ego,expected_rolling,previous_control,
                                                     expected_rolling_learner,previous_audit_hold)
                rolling_errors.update(row_errors)
                audit_hold = None
                if expected_rolling_learner in SELECT_FIRST_LEARNERS and not row_errors:
                    rolling = row['rolling_trajectory']
                    if rolling['exact_audit_rejected']:
                        audit_hold = rolling['generation_id'],rolling['learning']
                    elif select_first_audit_hold(rolling,previous_audit_hold):
                        audit_hold = previous_audit_hold
                previous_submissions[key[0]] = dict(frame=frame,audit_hold=audit_hold,
                    control=dict(a=float(row['applied_a']), df=float(row['applied_delta'])))
                rolling_rows += 1
            elif 'rolling_trajectory' in row:
                errors['unexpected_rolling_trajectory'] += 1
            if expected_spatial is not None:
                from Tools.validate_spatial_probe_v23 import validate_spatial_record
                previous = previous_submissions.get(key[0])
                previous_control = previous['control'] if previous is not None and previous['frame']+1 == int(row['frame']) else None
                spatial_errors.update(validate_spatial_record(row, ego, expected_spatial, previous_control))
                previous_submissions[key[0]] = dict(frame=int(row['frame']),
                    control=dict(a=float(row['applied_a']), df=float(row['applied_delta'])))
                sp = row['spatial_probe']
                spatial_counts['rows'] += 1
                spatial_counts['changed_requests'] += bool(sp['changed_request'])
                spatial_counts['retracted_requests'] += bool(sp['retracted'])
                spatial_counts['eligible_candidates'] += sum(bool(c.get('eligible')) for c in sp['candidates'][2:])
                spatial_counts['observed_road_rejections'] += bool(sp['feedback']['observed_body'] is not None
                                                                 and not sp['feedback']['observed_body']['accepted'])
                spatial_statuses[sp['proposal_status']] += 1
            elif 'spatial_probe' in row:
                errors['unexpected_spatial_probe'] += 1
            if expected_evolution is not None:
                from Tools.validate_trajectory_evolution_v22 import validate_evolution_record
                previous = previous_submissions.get(key[0])
                previous_control = (previous['control'] if previous is not None
                                    and previous['frame']+1 == int(row['frame']) else None)
                evolution_errors.update(validate_evolution_record(row, ego, expected_evolution, previous_control))
                previous_submissions[key[0]] = dict(frame=int(row['frame']),
                    control=dict(a=float(row['applied_a']), df=float(row['applied_delta'])))
                ev = row['trajectory_evolution']
                evolution_counts['rows'] += 1
                evolution_counts['changed_requests'] += bool(ev['changed_request'])
                evolution_counts['decisions'] += bool(ev['decision'])
                evolution_counts['takeovers'] += bool(ev['decision'] and ev['learning']['source'] == 'takeover')
                evolution_counts['explorations'] += bool(ev['decision'] and ev['learning']['source'] == 'explore')
                evolution_counts['belief_observations'] += bool(ev['beta']['evidence_applied'])
                for candidate in ev['candidates'][2:]:
                    evolution_ratios[str(candidate['ratio'])] += 1
            elif 'trajectory_evolution' in row:
                errors['unexpected_trajectory_evolution'] += 1
            if expected_probe is not None:
                from Tools.validate_trajectory_probe_v21 import validate_probe_record
                probe_rows += 1
                previous = previous_submissions.get(key[0])
                previous_control = (previous['control'] if previous is not None
                                    and previous['frame']+1 == int(row['frame']) else None)
                probe_errors.update(validate_probe_record(row, ego, expected_probe, previous_control))
                previous_submissions[key[0]] = dict(frame=int(row['frame']),
                    control=dict(a=float(row['applied_a']), df=float(row['applied_delta'])))
                probe_changes += bool(row.get('trajectory_probe', {}).get('changed_request'))
                probe_active += bool(row['active'])
                variants = [c for c in row['trajectory_probe']['candidates'] if c['id'].endswith('_slow')]
                probe_generated += len(variants)
                probe_eligible += sum(bool(c['eligible']) for c in variants)
            elif 'trajectory_probe' in row:
                errors['unexpected_trajectory_probe'] += 1
            if (row['controller'] != expected_controller or row['authority'] != 'matrix_entry'
                    or row['revision'] != revision or row['pure_nash'] is not None):
                errors['mode'] += 1
            selected = row['selected']
            if selected not in (0, 1) or row['control_submit_ok'] != 1:
                errors['selection_or_submission'] += 1
            for field, logged in (('pre_audit_a', 'a_mpc'), ('pre_audit_delta', 'delta_mpc_rad'),
                                  ('applied_a', 'a_cmd'), ('applied_delta', 'delta_rad')):
                # Physical delta is also logged as normalized steer * limit.
                value = ego.get(logged)
                if logged == 'delta_rad' and value is None:
                    value = float(ego['steer'])*float(ego['physical_max_steer'])
                if (not math.isfinite(float(row[field])) or not math.isfinite(float(value))
                        or abs(float(row[field])-float(value)) > 3e-5):
                    errors['control_link_'+field] += 1
            # v_ref is a 3-decimal display field, whereas the actual actuator
            # target is logged at 6 decimals. Require BOTH links at their real
            # precision, rather than applying a 3e-5 tolerance to v_ref.
            if not _matches_precision(row['applied_target'], ego['actuator_speed_target'], 6):
                errors['control_link_applied_target'] += 1
            if not _matches_precision(row['applied_target'], ego['v_ref'], 3):
                errors['control_link_v_ref'] += 1
            if row['guard_action'] != ego['guard_action'] or bool(row['guard_override']) != (ego['mpc_audit_override']=='1'):
                errors['audit_link'] += 1
            if ego.get('mpc_game_enabled') != '0' or ego.get('rl_active') != '0':
                errors['double_game_or_learning'] += 1
            if row['active']:
                active += 1
                matrix, reverse, p = row['payoff_matrix'], row['rv_payoff_matrix'], float(row['p_yield'])
                if len(matrix) != 2 or any(len(r) != 2 for r in matrix) or not 0. <= p <= 1.:
                    raise ValueError('matrix shape/probability')
                for i in range(2):
                    for j in range(2):
                        if not math.isfinite(float(matrix[i][j])) or abs(matrix[i][j]+reverse[i][j]) > 1e-8:
                            errors['zero_sum_payoff'] += 1
                values = [(1.-p)*r[0]+p*r[1] for r in matrix]
                if kernel in ('matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18'):
                    if row['forecast_model']!='observed_motion_v14' or not .2-1e-9<=p<=.8+1e-9:
                        errors['v14_motion_contract']+=1
                    target=row['candidate_targets'][0]
                    if 0.<target<.2-1e-9:
                        errors['v14_near_zero_target']+=1
                    for i in range(2):
                        for j in range(2):
                            part=row['components'][i][j]
                            penalty=part['forecast_penalty'] if kernel in ('matrix_v16','matrix_v17','matrix_v18') else 0.
                            total=(part['progress']-.25*part['stopped_fraction']-.05*part['comfort']
                                   -4.*part['risk']-part['switch_cost']
                                   -(0. if row['candidate_solve_ok'][i] else 1000.)-penalty)
                            if kernel=='matrix_v18':
                                total -= part['admissibility_penalty']
                                feasible = all(d['stop_before_band'] for d in part['forecasts'])
                                if (part['stop_feasible']!=feasible or
                                        part['admissible']!=(part['forecast_valid'] and feasible)
                                        or part['admissibility_penalty']!=(0. if feasible else 1000.)):
                                    errors['v18_admissibility']+=1
                            if (not math.isfinite(total) or abs(total-matrix[i][j])>1e-8 or
                                    abs(sum(a['risk'] for a in part['actors'])-part['risk'])>1e-8):
                                errors['v14_payoff_components']+=1
                            if kernel in ('matrix_v16','matrix_v17','matrix_v18'):
                                if (row['ego_forecast_model']!=({'matrix_v17':'route_v17','matrix_v18':'route_v18'}.get(kernel,'route_v16')) or
                                        part['forecast_valid']!=all(d['valid'] for d in part['forecasts']) or
                                        penalty!=(0. if part['forecast_valid'] else 1000.) or
                                        len(part['forecasts'])!=2 or
                                        abs(part['progress']-part['forecasts'][1]['progress_m']/24.)>1e-8):
                                    errors['v16_candidate_forecast']+=1
                    if row['switch_penalty']>0. and any(c['risk']>1e-12 for r in row['components'] for c in r):
                        errors['v14_safety_delayed_by_switch_cost']+=1
                    opportunity_waits+=bool(row['model_safe_proceed_while_defer'])
                if abs(values[0]-row['u_wait']) > 1e-8 or abs(values[1]-row['u_go']) > 1e-8:
                    errors['expected_payoff'] += 1
                base_selected=selected
                mode=row['decision_mode']
                if expected_controller in ('matrix_v19','matrix_v20'):
                    base_selected=row['baseline_selected']
                    mode=row['baseline_decision_mode']
                    if (row['decision_mode']!='candidate_learning' or
                            selected not in row['learning']['allowed'] or
                            row['learning']['requested']!=selected or row['learning']['cg']!=base_selected):
                        errors['candidate_learning_authority']+=1
                    usable=[row['candidate_solve_ok'][i] and row['components'][i][0]['admissible']
                            for i in range(2)]
                    if any(usable) and not usable[selected]:errors['unusable_learning_request']+=1
                if mode == 'expected_response':
                    wanted = 1 if values[1] > values[0]+1e-9 else 0
                    if base_selected != wanted:
                        errors['best_response'] += 1
                elif mode == 'optimizer_failure_override':
                    fallback += 1
                    if kernel in ('matrix_v16','matrix_v17','matrix_v18') and (not row['candidate_solve_ok'][base_selected]
                            or row['candidate_solve_ok'][1-base_selected]):
                        errors['invalid_optimizer_override'] += 1
                elif kernel in ('matrix_v16','matrix_v17','matrix_v18') and mode in (
                        'all_candidates_failed', 'all_forecasts_invalid', 'forecast_failure_override',
                        'all_candidates_inadmissible','admissibility_override'):
                    field = 'admissible' if kernel=='matrix_v18' else 'forecast_valid'
                    usable=[row['candidate_solve_ok'][i] and row['components'][i][0][field]
                            for i in range(2)]
                    if mode=='all_candidates_failed':
                        valid=not any(row['candidate_solve_ok']) and base_selected==0
                    elif mode in ('all_forecasts_invalid','all_candidates_inadmissible'):
                        valid=not any(usable) and base_selected==0
                    else:
                        valid=usable[base_selected] and not usable[1-base_selected]
                    if not valid:
                        errors['invalid_forecast_override']+=1
                else:
                    errors['decision_mode'] += 1
                request = (row['rolling_trajectory']['request'] if expected_rolling is not None else
                           row['spatial_probe']['request'] if expected_spatial is not None else
                           row['trajectory_evolution']['request'] if expected_evolution is not None else
                           row['trajectory_probe']['request'] if expected_probe is not None else
                           dict(target=row['candidate_targets'][selected], a=row['candidate_a'][selected]))
                if abs(row['pre_audit_target']-request['target']) > 1e-8:
                    errors['target_authority'] += 1
                if abs(row['pre_audit_a']-request['a']) > 1e-8:
                    errors['candidate_authority'] += 1
                label = 'defer' if selected == 0 else 'proceed'
                choices[label] += 1
                (overridden if row['guard_override'] else accepted)[label] += 1
                moving_defers += selected == 0 and row['pre_audit_target'] > .1
                switches += bool(row['switch'])
            times.append(float(row['decision_ms']))
            actual_times.append(float(ego['mpc_solve_ms'])+float(row['decision_ms']))
            if float(ego['ego_v']) < .1:
                stops[key[0]] += .05
        except (KeyError, TypeError, ValueError, IndexError, OverflowError):
            errors['invalid_matrix_record'] += 1
    if seen != set(expected) or rows_read != len(expected):
        errors['full_frame_coverage'] += 1
    if not active:
        errors['no_active_matrix_evidence'] += 1
    if expected_probe is not None:
        if probe_rows != len(expected):probe_errors['full_frame_coverage'] += 1
        errors.update(dict(('trajectory_probe_'+key, count) for key, count in probe_errors.items()))
    if expected_evolution is not None:
        if evolution_counts['rows'] != len(expected):
            evolution_errors['full_frame_coverage'] += 1
        errors.update(dict(('trajectory_evolution_'+key, count) for key, count in evolution_errors.items()))
    if expected_spatial is not None:
        if spatial_counts['rows'] != len(expected):
            spatial_errors['full_frame_coverage'] += 1
        errors.update(dict(('spatial_probe_'+key, count) for key, count in spatial_errors.items()))
    if expected_rolling is not None:
        if rolling_rows != len(expected): rolling_errors['full_frame_coverage'] += 1
        errors.update(dict(('rolling_'+key, count) for key, count in rolling_errors.items()))
    result = dict(matrix_contract_ok=not errors, matrix_contract_errors=dict(errors),
        matrix_controller=expected_controller, matrix_rows=rows_read, matrix_active_rows=active,
        matrix_choices=dict(choices), matrix_accepted_choices=dict(accepted),
        matrix_overridden_choices=dict(overridden), matrix_moving_defer_rows=moving_defers,
        matrix_switch_rows=switches, matrix_optimizer_failure_overrides=fallback,
        matrix_model_safe_proceed_while_defer_rows=opportunity_waits,
        matrix_decision_p95_ms=sorted(times)[int(.95*(len(times)-1))] if times else None,
        matrix_candidate_solve_and_decision_p95_ms=sorted(actual_times)[int(.95*(len(actual_times)-1))] if actual_times else None)
    if expected_probe is not None:
        result.update(trajectory_probe_contract_ok=not probe_errors,
            trajectory_probe_errors=dict(probe_errors), trajectory_probe_mode=expected_probe,
            trajectory_probe_rows=probe_rows, trajectory_probe_changed_requests=probe_changes,
            trajectory_probe_active_rows=probe_active, trajectory_probe_generated_variants=probe_generated,
            trajectory_probe_eligible_variants=probe_eligible)
    if expected_evolution is not None:
        result.update(trajectory_evolution_contract_ok=not evolution_errors,
            trajectory_evolution_errors=dict(evolution_errors), trajectory_evolution_phase=expected_evolution,
            trajectory_evolution_counts=dict(evolution_counts), trajectory_evolution_ratios=dict(evolution_ratios))
    if expected_spatial is not None:
        result.update(spatial_probe_contract_ok=not spatial_errors, spatial_probe_errors=dict(spatial_errors),
            spatial_probe_mode=expected_spatial, spatial_probe_counts=dict(spatial_counts),
            spatial_probe_statuses=dict(spatial_statuses))
    if expected_rolling is not None:
        from Tools.validate_rolling_v24 import validate_rolling_experience
        experience = validate_rolling_experience(directory, _matrix_records(path), expected_rolling,
                                                 expected_rolling_learner)
        result.update(rolling_contract_ok=not rolling_errors, rolling_errors=dict(rolling_errors),
                      rolling_phase=expected_rolling)
        result.update(experience)
        if not experience['rolling_experience_contract_ok']:
            result['matrix_contract_ok'] = False
            result['matrix_contract_errors'].update(dict(('rolling_experience_'+k,v)
                for k,v in experience['rolling_experience_errors'].items()))
    return result
