#!/usr/bin/env python3
"""Describe paired-arm driving outcomes; never infer benefit from contract flags."""
import argparse
from collections import Counter
import csv
import json
import math
from pathlib import Path
import statistics


def number(row, key, default=None):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else default
    except (ValueError, TypeError):
        return default


def learning_comparisons(groups):
    result={}
    suffix='v20' if any(a.endswith('_v20') for a in groups) else 'v19'
    for name,treatment,baseline in (
            ('learning_vs_CG','L0_learning_'+suffix,'M6_matrix_v18'),
            ('EFE_vs_learning','L1_efe_'+suffix,'L0_learning_'+suffix),
            ('full_GTRL_vs_CG','L1_efe_'+suffix,'M6_matrix_v18'),
            ('full_GTRL_vs_RULE','L1_efe_'+suffix,'B5_rule_v18'),
            ('no_gate_vs_full','L2_no_gate_'+suffix,'L1_efe_'+suffix)):
        if treatment not in groups or baseline not in groups:continue
        a,b=groups[treatment],groups[baseline]
        result[name]=dict(treatment=treatment,baseline=baseline,
            success_rate_delta=a['success_rate']-b['success_rate'],
            collision_count_delta=a['collisions']-b['collisions'],
            mean_all_episode_s_delta=a['mean_all_episode_s']-b['mean_all_episode_s'],
            mean_entry_wait_s_delta=a['mean_entry_wait_s']-b['mean_entry_wait_s'],
            mean_stop_events_delta=a['mean_non_goal_stop_events']-b['mean_non_goal_stop_events'])
    return result


def episode_metrics(rows, summary):
    moving, was_stopped, stops, wait, non_goal_stop = False, False, 0, 0., 0.
    stop_run,max_stop,entry_start,entry_end=0.,0.,None,None
    for index,row in enumerate(rows):
        speed = number(row, 'ego_v', 0.)
        eligible = moving and number(row, 'goal_remaining', 0.) > 5.
        stopped = speed < .1
        if eligible and stopped:
            non_goal_stop += .05
            stop_run+=.05;max_stop=max(max_stop,stop_run)
            sd = number(row, 'wait_standoff')
            if sd is not None and 0. < sd <= 18.:
                wait += .05
            stops += not was_stopped
        else:
            stop_run=0.
        sd=number(row,'wait_standoff')
        if entry_start is None and sd is not None and 0.<sd<=18.:
            entry_start=index
        if entry_start is not None and entry_end is None and sd is not None and sd<=0.:
            entry_end=index
        moving = moving or not stopped
        was_stopped = stopped
    gaps = [v for v in (number(r, 'guard_selected_gap') for r in rows) if v is not None]
    return dict(episode=int(summary['episode']), outcome=summary['outcome'],
        seconds=.05*len(rows), entry_wait_s=wait, non_goal_stop_s=non_goal_stop,
        non_goal_stop_events=stops,
        longest_non_goal_stop_s=max_stop,
        entry_approach_s=(.05*((entry_end if entry_end is not None else len(rows))-entry_start)
                          if entry_start is not None else None),
        guard_override_rows=sum(r.get('mpc_audit_override')=='1' for r in rows),
        guard_prediction_unsafe_rows=sum(r.get('guard_safe')=='0' for r in rows),
        severe_deceleration_rows=sum(number(r,'ego_acc_measured',0.) < -6. for r in rows),
        severe_acceleration_rows=sum(number(r,'ego_acc_measured',0.) > 6. for r in rows),
        tracking_over_half_m_rows=sum(abs(number(r,'mpc_l',0.)) > .5 for r in rows),
        minimum_predicted_guard_gap=min(gaps) if gaps else None)


def summarize(root):
    manifest=json.loads((root/'manifest.json').read_text(encoding='utf8'))
    groups={}
    for run in manifest['runs']:
        # Stored manifest paths belong to the remote host. Resolve locally.
        directory=root/('%s_seed%d'%(run['arm'],run['seed']))
        result=json.loads((directory/'result.json').read_text(encoding='utf8'))
        with (directory/'interaction_ego.csv').open(newline='',encoding='utf-8-sig') as stream:
            rows=list(csv.DictReader(stream))
        with (directory/'interaction_summary.csv').open(newline='',encoding='utf-8-sig') as stream:
            episodes=list(csv.DictReader(stream))
        group=groups.setdefault(run['arm'],dict(episodes=[],matrix_active_rows=0,
            matrix_accepted_choices=Counter(),matrix_overridden_choices=Counter(),
            collection_contract_ok=True,matrix_model_safe_proceed_while_defer_rows=0,
            matrix_accepted_go_low_speed_rows=0,matrix_longest_accepted_go_low_speed_s=0.))
        group['collection_contract_ok'] = group['collection_contract_ok'] and run.get('status')=='complete'
        for summary in episodes:
            selected=[r for r in rows if r['episode']==summary['episode']]
            group['episodes'].append(dict(episode_metrics(selected,summary),seed=run['seed']))
        group['matrix_active_rows']+=result.get('matrix_active_rows',0)
        group['matrix_accepted_choices'].update(result.get('matrix_accepted_choices',{}))
        group['matrix_overridden_choices'].update(result.get('matrix_overridden_choices',{}))
        group['matrix_model_safe_proceed_while_defer_rows']+=result.get('matrix_model_safe_proceed_while_defer_rows',0)
        group['matrix_accepted_go_low_speed_rows']+=result.get('matrix_accepted_go_low_speed_rows',0)
        group['matrix_longest_accepted_go_low_speed_s']=max(group['matrix_longest_accepted_go_low_speed_s'],
            result.get('matrix_longest_accepted_go_low_speed_s',0.))
        if 'forecast_contract_ok' in result:
            for key in ('forecast_invalid_candidates', 'forecast_all_candidates_invalid_rows',
                        'forecast_infeasible_stop_candidates','forecast_all_candidates_inadmissible_rows'):
                if key in result:
                    group[key]=group.get(key,0)+result[key]
        for key in ('traffic_ego_leader_rows', 'traffic_ego_follow_stopped_rows', 'traffic_following_invalid_rows'):
            group[key] = group.get(key, 0)+result.get(key, 0)
        for key in ('candidate_decisions','candidate_takeover_decisions','candidate_exploration_decisions',
                    'candidate_unseen_eval_decisions','candidate_intervention_rows'):
            group[key]=group.get(key,0)+result.get(key,0)
    for group in groups.values():
        episodes=group['episodes']; completed=[e for e in episodes if e['outcome']=='complete']
        group.update(n=len(episodes),success=len(completed),outcomes=dict(Counter(e['outcome'] for e in episodes)),
            collisions=sum(e['outcome']=='collision' for e in episodes),
            stuck=sum(e['outcome']=='stuck' for e in episodes),
            success_rate=len(completed)/len(episodes) if episodes else None,
            mean_all_episode_s=statistics.mean(e['seconds'] for e in episodes) if episodes else None,
            max_episode_s=max((e['seconds'] for e in episodes),default=None),
            episodes_over_60_s=sum(e['seconds']>60. for e in episodes),
            episodes_over_90_s=sum(e['seconds']>90. for e in episodes),
            mean_completed_s=statistics.mean(e['seconds'] for e in completed) if completed else None,
            median_completed_s=statistics.median(e['seconds'] for e in completed) if completed else None)
        for metric in ('entry_wait_s','non_goal_stop_s','non_goal_stop_events','guard_override_rows',
                       'severe_deceleration_rows','severe_acceleration_rows','tracking_over_half_m_rows',
                       'longest_non_goal_stop_s','guard_prediction_unsafe_rows'):
            group['mean_'+metric]=statistics.mean(e[metric] for e in episodes) if episodes else None
        group['matrix_accepted_choices']=dict(group['matrix_accepted_choices'])
        group['matrix_overridden_choices']=dict(group['matrix_overridden_choices'])
    rule=groups.get('B0_rule')
    for name,group in groups.items():
        if name!='B0_rule' and rule and group['n']==group['success'] and rule['n']==rule['success']:
            group['descriptive_delta_vs_rule']={metric:group[metric]-rule[metric]
                for metric in ('mean_completed_s','mean_entry_wait_s','mean_non_goal_stop_events')}
    comparisons={}
    for name,baseline in (('M3_vs_minimal_RULE', 'B1_rule_minimal'),
                          ('M3_vs_full_RULE', 'B2_rule_spatial'),
                          ('full_vs_minimal_RULE', 'B1_rule_minimal'),
                          ('M3_vs_frozen_M2', 'M2_matrix_v14'),
                          ('M4_vs_shared_forecast_RULE', 'B3_rule_forecast'),
                          ('M4_vs_frozen_M3', 'M3_matrix_spatial'),
                          ('M5_vs_v17_RULE', 'B4_rule_v17'),
                          ('M5_vs_old_ego_matrix_shared_v17_traffic', 'M3_matrix_spatial'),
                          ('M6_vs_v18_RULE','B5_rule_v18'),
                          ('M6_vs_v17_matrix','M5_matrix_v17'),
                          ('v18_RULE_vs_v17_RULE','B4_rule_v17'),
                          ('v17_RULE_vs_old_ego_RULE_shared_v17_traffic', 'B2_rule_spatial'),
                          ('shared_forecast_RULE_vs_frozen_RULE', 'B2_rule_spatial')):
        treatment=('M6_matrix_v18' if name.startswith('M6_') else
                   'B5_rule_v18' if name.startswith('v18_RULE_') else
                   'M5_matrix_v17' if name.startswith('M5_') else
                   'B4_rule_v17' if name.startswith('v17_RULE_') else
                   'B3_rule_forecast' if name=='shared_forecast_RULE_vs_frozen_RULE' else
                   'M4_matrix_forecast' if name.startswith('M4_') else
                   'B2_rule_spatial' if name=='full_vs_minimal_RULE' else 'M3_matrix_spatial')
        if treatment in groups and baseline in groups:
            a,b=groups[treatment],groups[baseline]
            comparisons[name]=dict(treatment=treatment,baseline=baseline,
                same_geometry=baseline!='M2_matrix_v14',
                success_rate_delta=a['success_rate']-b['success_rate'],
                collision_count_delta=a['collisions']-b['collisions'],
                mean_all_episode_s_delta=a['mean_all_episode_s']-b['mean_all_episode_s'],
                mean_entry_wait_s_delta=a['mean_entry_wait_s']-b['mean_entry_wait_s'],
                mean_stop_events_delta=a['mean_non_goal_stop_events']-b['mean_non_goal_stop_events'])
    comparisons.update(learning_comparisons(groups))
    return dict(revision='learning_comparison_v19' if 'L1_efe_v19' in groups else
                'matrix_comparison_v18' if 'M6_matrix_v18' in groups else
                'matrix_comparison_v17' if 'M5_matrix_v17' in groups else
                'matrix_comparison_v16' if 'M4_matrix_forecast' in groups else 'matrix_comparison_v15',groups=groups,comparisons=comparisons,
        priority='Assess collisions and completion first; then waiting, comfort, tracking and computational cost.',
        note='Exploratory description only. Entry wait excludes initial standstill and counts ego_v<0.1, '
             '0<wait_standoff<=18, goal_remaining>5 after initial motion. '
             'A complete collection is not proof of driving benefit; paired seeds do not force identical closed-loop traffic.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    parser.add_argument('--require-matrix-smoke',action='store_true')
    parser.add_argument('--smoke-arm',choices=('M1_matrix','M2_matrix_v14','M3_matrix_spatial','M4_matrix_forecast','M5_matrix_v17','M6_matrix_v18'),default='M1_matrix')
    args=parser.parse_args(argv)
    report=summarize(args.directory)
    (args.directory/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    lines=[report['priority'],
        'arm | success | collision | stuck | mean all seconds | max seconds | mean entry wait | mean non-goal stops']
    for name,group in report['groups'].items():
        lines.append('%s | %d/%d | %d | %d | %s | %s | %.3f | %.3f'%(name,group['success'],group['n'],
            group['collisions'],group['stuck'],
            'NA' if group['mean_all_episode_s'] is None else '%.3f'%group['mean_all_episode_s'],
            'NA' if group['max_episode_s'] is None else '%.3f'%group['max_episode_s'],
            group['mean_entry_wait_s'],group['mean_non_goal_stop_events']))
    lines.append(report['note'])
    text='\n'.join(lines)+'\n'
    (args.directory/'COMPARISON.txt').write_text(text,encoding='utf8')
    print(text)
    if args.require_matrix_smoke:
        group=report['groups'].get(args.smoke_arm,{})
        if not (group.get('n',0)>=5 and group.get('success')==group.get('n')
                and group.get('collection_contract_ok') and group.get('matrix_active_rows',0)>0):
            print('Smoke failed: preserve this folder; do not expand the experiment.')
            return 8
    return 0


if __name__=='__main__':
    raise SystemExit(main())
