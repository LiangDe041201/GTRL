#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【② 标定扫参分析】`DSH_EFE_VALUE_W` 对成功率的影响。

背景（HANDOFF §24）
------------------------------------------------------------------
EFE 动作间跨度实测中位 **2.92 nats**，而接管比较的判别尺度 δ ≈ **32~387**（中位 185）。
`DSH_EFE_VALUE_W = 1.0`（默认）⇒ ② 的影响力仅 **0.9~2.9%** ⇒ 被淹没（实测消融 +0.0 pp）。
标定目标：`w × 2.92` 与 δ 可比 ⇒ w ≈ 6（0.1×δ）、19（0.3×δ）、32（0.5×δ）。

⚠️ **为什么必须闭环实测**：离线数据**原理上判不了方向** ——
   动作是"按状态选择"的，存在**选择偏差**（自车在安全时才加速到 v=6）。
   §24.3 记录了两个方向相反的受污染分析。⇒ 只能跑。

本脚本输出
------------------------------------------------------------------
  1. 各臂成功率 + 95%CI + 与 w=1 基线的差值（配对式隔离：三臂只差 w）
  2. **机制级指标**：EFE 是否真的改变了动作分布 / 接管率
     —— 这是"标定是否生效"的直接证据（比成功率更敏感、噪声更小）
  3. 逐动作分布对比（标定是否把执行动作推向 EFE 的偏好）

用法： python Tools/analyze_efe_calib.py [基线臂名]
"""
from __future__ import annotations

import collections
import csv
import math
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

ARMS = [('E1_efew1', 'w=1（修复前默认，未标定）'),
        ('E2_efew10', 'w=10'),
        ('E3_efew30', 'w=30')]
BASE = sys.argv[1] if len(sys.argv) > 1 else 'E1_efew1'


def outcomes(run):
    p = os.path.join(run, 'interaction_summary.csv')
    if not os.path.exists(p):
        return None
    s = [r for r in csv.DictReader(open(p)) if r.get('episode')]
    if not s:
        return None
    c = collections.Counter(r['outcome'] for r in s)
    n = sum(c.values())
    pr = c['complete'] / n
    return dict(n=n, comp=100 * pr, se=100 * math.sqrt(pr * (1 - pr) / n),
                coll=100 * c['collision'] / n, stuck=100 * c['stuck'] / n)


def frame_stats(run):
    """逐帧机制级指标：EFE 是否改变了决策。"""
    p = os.path.join(run, 'interaction_ego.csv')
    if not os.path.exists(p):
        return None
    rows = list(csv.DictReader(open(p)))

    def g(r, k):
        v = r.get(k)
        return None if v in (None, '') else v

    acts = collections.Counter(g(r, 'action') for r in rows if g(r, 'action') is not None)
    to = collections.Counter(g(r, 'takeover') for r in rows if g(r, 'takeover') is not None)
    n = max(len(rows), 1)
    # 探索帧占比（探索会绕过 EFE，必须扣除）
    n_explore = sum(1 for r in rows if g(r, 'decision_src') == 'explore')
    # EFE 偏好与实际动作的一致率（仅非探索帧）
    agree = tot = 0
    for r in rows:
        if g(r, 'decision_src') == 'explore':
            continue
        b, a = g(r, 'efe_best_action'), g(r, 'action')
        if b is None or a is None:
            continue
        tot += 1
        if int(float(b)) == int(float(a)):
            agree += 1
    return dict(n=n, acts=acts, takeover_rate=100.0 * to.get('1', 0) / n,
                n_explore=n_explore, explore_pct=100.0 * n_explore / n,
                agree_pct=(100.0 * agree / tot if tot else float('nan')), agree_n=tot)


def main():
    print('=' * 92)
    print('【② EFE 标定扫参】`DSH_EFE_VALUE_W` 的作用（各 100 回合，同种子，只差 w）')
    print('=' * 92)
    res = {}
    for run, label in ARMS:
        o = outcomes(run)
        if o is None:
            print(f'  {run}: 数据不完整，跳过')
            continue
        res[run] = o
    if not res:
        print('没有可用数据')
        return 1

    print(f"\n{'臂':<28}{'成功%':<9}{'±95%CI':<9}{'碰撞%':<9}{'卡死%':<9}{'n'}")
    for run, label in ARMS:
        if run not in res:
            continue
        o = res[run]
        print(f"{label:<28}{o['comp']:<9.1f}{1.96 * o['se']:<9.1f}"
              f"{o['coll']:<9.1f}{o['stuck']:<9.1f}{o['n']}")

    if BASE in res:
        print(f"\n相对基线（{BASE}）的差值（配对式隔离：三臂只差 w）：")
        b = res[BASE]
        for run, label in ARMS:
            if run not in res or run == BASE:
                continue
            o = res[run]
            d = o['comp'] - b['comp']
            se = math.sqrt(b['se'] ** 2 + o['se'] ** 2)
            ci = 1.96 * se
            verdict = ('✅ 显著正' if d - ci > 0 else
                       ('❌ 显著负' if d + ci < 0 else '⚠️ 不显著'))
            print(f"  {label:<28}{d:+6.1f} pp  (±{ci:.1f})   {verdict}")

    # ---------- 机制级：标定是否真的改变了决策 ----------
    print('\n' + '=' * 92)
    print('【机制级】EFE 是否真的改变了决策（比成功率更敏感）')
    print('=' * 92)
    fs = {}
    for run, label in ARMS:
        s = frame_stats(run)
        if s:
            fs[run] = s
    if fs:
        print(f"\n{'臂':<28}{'接管率%':<10}{'探索帧%':<10}{'EFE偏好=执行%':<16}{'样本'}")
        for run, label in ARMS:
            if run not in fs:
                continue
            s = fs[run]
            print(f"{label:<28}{s['takeover_rate']:<10.2f}{s['explore_pct']:<10.1f}"
                  f"{s['agree_pct']:<16.2f}{s['agree_n']}")
        print('\n逐动作执行分布（前三名）：')
        for run, label in ARMS:
            if run not in fs:
                continue
            top = fs[run]['acts'].most_common(3)
            print(f"  {label:<28}{top}")

    print('\n' + '=' * 92)
    print('判读指引：')
    print('  · **EFE偏好=执行%** 升高 ⇒ 标定确实让 EFE 影响了动作选择（机制生效）')
    print('  · **接管率%** 变化 ⇒ 接管规则的判决被改变')
    print('  · 成功率差值 ±CI 跨 0 ⇒ 100 回合分辨不出（需 ≥336 回合才能分辨 10pp）')
    return 0


if __name__ == '__main__':
    sys.exit(main())
