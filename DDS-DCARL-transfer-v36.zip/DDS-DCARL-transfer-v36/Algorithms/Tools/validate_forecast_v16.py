"""Check forecast/control provenance; report model quality separately."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct


def validate_forecast(directory, ego_rows, revision='route_v16'):
    directory = Path(directory)
    errors, sources = Counter(), Counter()
    seen, invalid, all_invalid, max_speed, cross_track = set(), 0, 0, [], []
    infeasible_stops,all_inadmissible = 0,0
    expected = {(int(r['episode']), int(r['frame'])): r for r in ego_rows}
    try:
        metadata = json.loads((directory/'forecast_metadata.json').read_text(encoding='utf8'))
        packed = b''.join(struct.pack('<d', float(v)) for p in metadata['route'] for v in p)
        if (metadata['revision'] != revision or metadata['response_calibrated'] is not False
                or metadata['response_lags'] != [0., .4] or len(metadata['route']) < 2
                or hashlib.sha256(packed).hexdigest() != metadata['route_sha256']):
            errors['metadata'] += 1
        if revision in ('route_v17','route_v18') and (metadata.get('navigation_end_is_stop') is not False
                or metadata.get('road_source') != 'carla_waypoint_next'
                or metadata.get('opponent_model') != ('leader_conditioned_v18' if revision=='route_v18' else 'recovery_family_v17')
                or metadata.get('recovery_acceleration_bound') != 2.
                or metadata.get('recovery_delays') != [0., 1.]
                or len(metadata.get('navigation_route', [])) >= len(metadata['route'])):
            errors['v17_road_or_recovery_metadata'] += 1
        if revision=='route_v18' and (metadata.get('candidate_conditioned') is not True
                or metadata.get('ego_predictor')!='dense_mpc_prefix_feedback_v18'
                or metadata.get('integration_dt')!=.05 or metadata.get('plan_prefix_max_s')!=.3
                or metadata.get('following_brake_bound')!=5.
                or metadata.get('leader_response_delays')!=[0.,.3] or metadata.get('stop_band_margin')!=.15):
            errors['v18_conditional_model_metadata'] += 1
    except (OSError, ValueError, TypeError, KeyError):
        errors['missing_or_invalid_metadata'] += 1
    try:
        with (directory/'forecast_audit.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                    key = int(row['episode']), int(row['frame'])
                    if key in seen or key not in expected:
                        errors['unknown_or_duplicate_frame'] += 1
                    seen.add(key)
                    ego = expected.get(key)
                    if row['revision'] != revision:
                        errors['revision'] += 1
                    if ego is not None:
                        for field, logged in (('applied_a', 'a_cmd'), ('target', 'actuator_speed_target')):
                            if (not math.isfinite(float(row[field])) or
                                    abs(float(row[field])-float(ego[logged])) > 1e-5):
                                errors['motion_link'] += 1
                        if (row['selected'] != ego['guard_action'] or
                                row['override'] != (ego['mpc_audit_override'] == '1') or
                                row['safe'] != (ego['guard_safe'] == '1')):
                            errors['guard_link'] += 1
                    candidates = row['candidates']
                    selected = next(c for c in candidates if c['action'] == row['selected'])
                    all_invalid += all(not c['forecast_valid'] for c in candidates)
                    if revision=='route_v18':
                        all_inadmissible += all(not c['admissible'] for c in candidates)
                    for candidate in candidates:
                        forecasts = candidate['forecasts']
                        if (len(forecasts) != 2 or [d['lag'] for d in forecasts] != [0., .4]
                                or candidate['forecast_valid'] != all(d['valid'] for d in forecasts)):
                            errors['forecast_family'] += 1
                        invalid += not candidate['forecast_valid']
                        if revision=='route_v18':
                            feasible = all(d['stop_before_band'] for d in forecasts)
                            infeasible_stops += not feasible
                            if (candidate['stop_feasible']!=feasible or
                                    candidate['admissible']!=(candidate['forecast_valid'] and feasible)
                                    or candidate['safe'] and not candidate['admissible']):
                                errors['v18_candidate_admissibility'] += 1
                        if candidate['safe'] and not candidate['forecast_valid']:
                            errors['invalid_marked_safe'] += 1
                        for d in forecasts:
                            sources[d['source']] += 1
                            if (d['revision'] != revision or d['horizon'] != 6.
                                    or any(not math.isfinite(float(d[k])) for k in
                                           ('progress_m', 'max_speed', 'end_speed', 'max_cross_track'))
                                    or d['valid'] != (not d['coverage_exhausted'] and d['max_cross_track'] <= 2.)):
                                errors['forecast_diagnostics'] += 1
                            max_speed.append(d['max_speed']); cross_track.append(d['max_cross_track'])
                            if revision=='route_v18' and (d['integration_dt']!=.05
                                    or not 0.<=d['plan_prefix_s']<=.3
                                    or d['future_control']!='path_feedback_after_dense_mpc_prefix'
                                    or not math.isfinite(d['min_standoff'])
                                    or d['stop_before_band']!=(not d['stop_check_required'] or d['min_standoff']>=.15)):
                                errors['v18_forecast_diagnostics'] += 1
                    if row['safe'] != selected['safe']:
                        errors['selected_safety'] += 1
                except (ValueError, TypeError, KeyError, IndexError, StopIteration, OverflowError):
                    errors['invalid_record'] += 1
    except OSError:
        errors['missing_audit'] += 1
    if not expected or seen != set(expected):
        errors['frame_coverage'] += 1
    extra = dict(forecast_infeasible_stop_candidates=infeasible_stops,
                 forecast_all_candidates_inadmissible_rows=all_inadmissible) if revision=='route_v18' else {}
    return dict(extra,forecast_contract_ok=not errors, forecast_contract_errors=dict(errors),
        forecast_sources=dict(sources), forecast_invalid_candidates=invalid,
        forecast_all_candidates_invalid_rows=all_invalid,
        forecast_max_speed=max(max_speed) if max_speed else None,
        forecast_max_cross_track=max(cross_track) if cross_track else None,
        forecast_response_calibrated=False)
