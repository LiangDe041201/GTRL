#!/usr/bin/env python3
"""Matched CG/fixed-candidate diagnostic, not another long learning run."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys
import tarfile

if __package__:
    from .run_trajectory_validation_v21 import _stage_report
    from .run_local_road_validation_v26 import inspect_runtime
else:
    from run_trajectory_validation_v21 import _stage_report
    from run_local_road_validation_v26 import inspect_runtime

ROOT=Path(__file__).resolve().parents[1]


def build_plan(output,episodes=5,seeds=None):
    seeds=[104,105] if seeds is None else list(seeds)
    arms=['M6_matrix_v18','T1_fixed_v24']
    args=['--method','CG','--game-mode','matrix_v18','--traffic','on','--traffic-interaction','v17',
        '--control-profile','paper_v11','--completion-mode','strict','--road-audit','local_v26',
        '--keep-going','--episodes',str(episodes),'--seeds',','.join(map(str,seeds)),
        '--arms',','.join(arms),'--output-root',str(output/'00_candidates')]
    return [dict(name='00_candidates',episodes_per_run=episodes,seeds=seeds,arms=arms,
        episodes_total=episodes*len(seeds)*len(arms),arguments=args)]


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--episodes',type=int,default=5,help='Episodes per arm and seed; default total is 20')
    p.add_argument('--seeds',default='104,105');p.add_argument('--output-root',type=Path)
    p.add_argument('--dry-run',action='store_true');args=p.parse_args(argv)
    try:
        seeds=[int(v) for v in args.seeds.split(',')]
        if args.episodes<1 or not seeds or len(seeds)!=len(set(seeds)):raise ValueError('Positive episodes and unique seeds required')
    except ValueError as exc:p.error(str(exc))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_candidates_v28_'+stamp)).resolve()
    stage=build_plan(output,args.episodes,seeds)[0]
    if args.dry_run:print(json.dumps(stage));return 0
    archive=Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():p.error('Choose an unused output-root')
    output.mkdir(parents=True)
    workflow=dict(revision='recovery_and_candidate_diagnostic_v28',planned_episodes=stage['episodes_total'],
        stage=stage,learning_training=False,efe_reward_enabled=False,driving_benefit_established=False,overall_success=None)
    status=1;file=output/'WORKFLOW.json'
    file.write_text(json.dumps(workflow,indent=2),encoding='utf8')
    try:
        print('[v28] %d episodes: CG vs fixed candidates, no long training; retain failures.'%stage['episodes_total'],flush=True)
        run=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
        collected=_stage_report(output,stage);checks=[]
        for seed in seeds:
            directory=output/stage['name']/('T1_fixed_v24_seed%d'%seed)
            if directory.exists():checks.append(dict(seed=seed,**inspect_runtime(directory)))
        a={(r['seed'],r['episode']):r for r in collected['arms'].get('T1_fixed_v24',{}).get('episodes',[])}
        b={(r['seed'],r['episode']):r for r in collected['arms'].get('M6_matrix_v18',{}).get('episodes',[])}
        pairs=[dict(seed=k[0],episode=k[1],cg_outcome=b[k]['outcome'],fixed_outcome=a[k]['outcome'],
            fixed_minus_cg_seconds=a[k]['seconds']-b[k]['seconds'],
            fixed_minus_cg_entry_wait_s=a[k]['entry_wait_s']-b[k]['entry_wait_s']) for k in sorted(set(a)&set(b))]
        complete=bool(collected['collection_ok'] and len(checks)==len(seeds) and all(c['ok'] for c in checks))
        status=run.returncode or (0 if complete else 17)
        report=dict(collection=collected,local_runtime_checks=checks,paired_candidates_vs_cg=pairs,
            learning_benefit_established=False,efe_benefit_established=False,
            priority='Success/collision/stuck first; supplement margins, waiting, comfort and background braking.',
            note='Candidate-pool diagnostic. Fixed candidate execution is not a learned takeover. '
                 'Identical initial seeds do not force identical closed-loop traffic.')
        (output/'CANDIDATE_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    except KeyboardInterrupt:status=130;workflow['error']='Interrupted; partial results preserved'
    except Exception as exc:status=1;workflow['error']='%s: %s'%(type(exc).__name__,exc)
    finally:
        workflow.update(overall_success=status==0,exit_code=status,finished_utc=datetime.now(timezone.utc).isoformat())
        file.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
        with tarfile.open(str(archive),'w:gz') as stream:stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__':raise SystemExit(main())
