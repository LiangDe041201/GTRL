#!/usr/bin/env python3
"""Two short straight-road actuator experiments, explicitly without MPC."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Planning_library.pedal_control import PedalControllerV10


class ProbeController(PedalControllerV10):
    """Use normal feedback for launch, then exactly coast or brake=0.01."""
    def __init__(self, brake_gain, max_steer, mode):
        super().__init__(brake_gain, max_steer)
        self.experiment_mode, self.pulse = mode, False

    def command(self, acceleration, speed, target_speed, steering):
        if not self.pulse:
            return super().command(acceleration, speed, target_speed, 0.)
        self.mode = 'diagnostic_'+self.experiment_mode
        self.target_acceleration = 0.  # no acceleration tracking in open loop
        self.throttle, self.brake, self.steer = 0., .01 if self.experiment_mode == 'light_brake' else 0., 0.
        return dict(throttle=self.throttle, brake=self.brake, steer=0.,
                    hand_brake=False, reverse=False, manual_gear_shift=False)


def run_case(env, mode, sink=None):
    env.reset(False)
    previous = env.pedal_controller
    controller = ProbeController(previous.brake_gain, previous.max_steer, mode)
    env.pedal_controller = controller
    rows, stable, phase, errors = [], 0., 'launch', []
    pulse_frames = 0
    for frame in range(120):  # at most 5 s launch + 1 s open-loop pulse
        command_phase = phase
        controller.pulse = phase != 'launch'
        _, _, done, _ = env.step([.8 if phase == 'launch' else 0., 0.], target_speed=2.)
        control = dict(env.last_control)
        control.update(experiment=mode, diagnostic_phase=command_phase, diagnostic_frame=frame+1)
        rows.append(control)
        if sink is not None:
            sink.append(control)
        speed = float(control['ego_v_after'])
        if not math.isfinite(speed):
            errors.append('nonfinite_speed')
            break
        if command_phase == 'launch':
            stable = stable+env.dt if speed >= 2. else 0.
            if stable >= .25-1e-9:
                phase = 'pulse'
            elif frame+1 >= 100:
                errors.append('launch_timeout')
                break
        else:
            pulse_frames += 1
        if done:
            errors.append('unexpected_environment_termination')
            break
        # Stop the experiment after a physical shock instead of repeatedly
        # applying the same brake. Always retain the triggering sample.
        if float(control['ego_acc_measured']) < -6.:
            errors.append('severe_deceleration')
            break
        if command_phase == 'pulse' and pulse_frames >= 20:
            break
    if pulse_frames < 20 and not errors:
        errors.append('incomplete_pulse')
    for row in rows:
        if (row.get('control_submit_ok') != 1 or row.get('control_transport') != 'batch_sync_pre_tick' or
                row.get('control_tick_frame') != row.get('sim_frame_after') or
                row.get('control_feedback_frame') != row.get('sim_frame_after')):
            errors.append('submission_or_frame_alignment')
        for key in ('throttle', 'brake', 'steer'):
            if abs(float(row[key])-float(row['requested_'+key])) > 1e-5:
                errors.append('pedal_feedback_'+key)
        if row['reverse'] or row['hand_brake'] or row['manual_gear_shift']:
            errors.append('drivetrain_flags')
        if abs(float(row['sim_dt'])-.05) > .0001 or row['sim_frame_after']-row['sim_frame_before'] != 1:
            errors.append('simulator_tick')
    pulse = [row for row in rows if row['diagnostic_phase'] == 'pulse']
    result = dict(experiment=mode, mpc_used=False, ok=not errors, errors=sorted(set(errors)),
        launch_frames=len(rows)-len(pulse), pulse_frames=len(pulse),
        pulse_min_acceleration=min((r['ego_acc_measured'] for r in pulse), default=None),
        pulse_max_acceleration=max((r['ego_acc_measured'] for r in pulse), default=None),
        pulse_start_speed=pulse[0]['ego_v_before'] if pulse else None,
        pulse_end_speed=pulse[-1]['ego_v_after'] if pulse else None)
    return rows, result


def main(argv=None, env_factory=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    if args.dry_run:
        print(json.dumps(dict(stage='actuator_probe', control_profile='paper_v10', mpc_used=False,
            experiments=['coast', 'light_brake'], light_brake=.01, pulse_seconds=1.,
            fixed_delta_seconds=.05, max_substep_delta_time=.005)))
        return 0
    if args.output_root is None:
        parser.error('--output-root is required')
    output = args.output_root.resolve()
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error('Output already exists: '+str(output))
    for key in list(os.environ):
        if key.startswith('DSH_'):
            del os.environ[key]
    os.environ.update(DSH_CONTROL_PROFILE='paper_v10', DSH_TRAFFIC='off', DSH_SEED='1',
                      DSH_SAVE_DIR=str(output), DSH_PLOT_DIR=str(output/'plots'), DSH_CONTROL_PROBE='0')
    sources = [ROOT/'train_dcarl_turn.py', ROOT/'path_utils.py']
    for folder in ('Agent', 'Planning_library', 'Test_Scenarios', 'Tools'):
        sources.extend(sorted((ROOT/folder).rglob('*.py')))
    (output/'manifest.json').write_text(json.dumps(dict(revision='actuator_probe_v10', mpc_used=False,
        source_sha256={str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in sources}), indent=2), encoding='utf8')
    env, rows, results = None, [], []
    error = None
    try:
        if env_factory is None:
            from Test_Scenarios.TestScenario_Town03_turn import CarEnv_Town03_Turn
            env_factory = CarEnv_Town03_Turn
        env = env_factory()
        for mode in ('coast', 'light_brake'):
            _, result = run_case(env, mode, sink=rows)
            results.append(result)
            print(json.dumps(result), flush=True)
    except Exception:
        error = traceback.format_exc()
        print(error, file=sys.stderr)
    finally:
        if env is not None:
            try:
                env.cleanup()
            except Exception:
                if error is None:
                    error = traceback.format_exc()
        if rows:
            keys = sorted(set(key for row in rows for key in row))
            with (output/'actuator_probe.csv').open('w', newline='', encoding='utf8') as stream:
                writer = csv.DictWriter(stream, fieldnames=keys)
                writer.writeheader()
                writer.writerows(rows)
        result = dict(mpc_used=False, ok=error is None and len(results) == 2 and all(r['ok'] for r in results),
                      experiments=results, error=error)
        (output/'result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result), flush=True)
    return 0 if result['ok'] else 6


if __name__ == '__main__':
    raise SystemExit(main())
