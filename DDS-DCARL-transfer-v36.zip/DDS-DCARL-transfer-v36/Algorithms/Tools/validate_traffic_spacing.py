"""Audit measured traffic spacing; distinguish contracts from traffic outcomes."""
import csv
import json
import math
from pathlib import Path


def _rows(path):
    if not path.is_file():
        return []
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def _number(row, key):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def _stats(values):
    values = sorted(values)
    return None if not values else dict(min=values[0], p05=values[int(.05*(len(values)-1))],
        median=values[int(.5*(len(values)-1))], p95=values[int(.95*(len(values)-1))], max=values[-1])


def validate_following_rows(samples):
    invalid, ego_rows, stopped_rows, ids = 0, 0, 0, set()
    gaps = []
    for row in samples:
        role = row.get('following_leader_role')
        leader = _number(row, 'following_leader_id')
        actor = _number(row, 'actor_id')
        gap = _number(row, 'following_gap')
        speed = _number(row, 'commanded_speed')
        valid = row.get('interaction_revision') == 'v17' and role in ('none', 'background', 'ego')
        valid = valid and speed is not None and speed >= 0.
        if role != 'none':
            valid = valid and leader is not None and leader != actor and gap is not None
            valid = valid and _number(row, 'following_leader_speed') is not None
        else:
            valid = valid and leader is None and gap is None
        invalid += not valid
        if role == 'ego':
            ego_rows += 1
            ids.add(str(row.get('actor_id')))
            if gap is not None:
                gaps.append(gap)
            stopped_rows += speed is not None and speed < .1
    return dict(traffic_following_contract_ok=bool(samples) and invalid == 0,
        traffic_following_invalid_rows=invalid, traffic_ego_leader_rows=ego_rows,
        traffic_ego_followers=sorted(ids), traffic_ego_follow_stopped_rows=stopped_rows,
        traffic_ego_follow_gaps=_stats(gaps))


def validate_traffic_spacing(directory, expected_spawns=None, expected_trials=None, probe=False,
                             interaction_revision=None):
    directory = Path(directory)
    errors = []
    metadata_path = directory/'traffic_spacing_metadata.json'
    metadata = json.loads(metadata_path.read_text(encoding='utf8')) if metadata_path.is_file() else {}
    if metadata.get('revision') != 'spacing_v12' or metadata.get('length_source') != 'actor_bbox_world_vertices':
        errors.append('missing_measured_geometry_or_revision')
    target = _number(metadata, 'target_clear_gap')
    speed = _number(metadata, 'cruise_speed')
    length = _number(metadata, 'measured_length')
    interval = _number(metadata, 'interval_seconds')
    if any(v is None or v <= 0. for v in (target, speed, length, interval)):
        errors.append('invalid_spacing_configuration')
    elif interval*speed-length < target-1e-6:
        errors.append('interval_speed_distance_inconsistent')
    if probe and (metadata.get('interactions_enabled') is not False or metadata.get('gap_after') != 0):
        errors.append('probe_has_interactions_or_long_gaps')
    events = _rows(directory/'traffic_spawns.csv')
    spawned = [r for r in events if r.get('event') == 'spawned']
    samples = _rows(directory/'traffic_spacing_samples.csv')
    if len(spawned) < 2 or not samples:
        errors.append('insufficient_traffic_evidence')
    if expected_spawns is not None and len(spawned) != expected_spawns:
        errors.append('spawn_count')
    if expected_trials is not None and {r.get('trial') for r in spawned} != {str(i) for i in expected_trials}:
        errors.append('trial_coverage')
    spawn_gaps, first_observed_gaps, sample_gaps, conflict_gaps, speeds = [], [], [], [], []
    invalid, overlaps, early_brakes = 0, 0, 0
    identities = set()
    for row in spawned:
        gap, wanted = _number(row, 'projected_clear_gap'), _number(row, 'target_clear_gap')
        if row.get('pose_source') != 'requested_spawn_transform':
            invalid += 1
        if wanted is None or target is None or abs(wanted-target) > 1e-6:
            invalid += 1
        if row.get('leader_id') and gap is None:
            invalid += 1
        if gap is not None:
            spawn_gaps.append(gap)
            if wanted is None or gap < wanted-.001:
                invalid += 1
        identities.add((row.get('episode'), row.get('trial'), row.get('actor_id')))
    seen_samples, frame_keys = set(), set()
    for row in samples:
        identity = (row.get('episode'), row.get('trial'), row.get('actor_id'))
        first_observed = identity not in seen_samples
        seen_samples.add(identity)
        key = identity+(row.get('frame'),)
        if key in frame_keys:
            invalid += 1
        frame_keys.add(key)
        measured, gap = _number(row, 'observed_speed'), _number(row, 'actual_clear_gap')
        if row.get('pose_source') != 'actor_snapshot':
            invalid += 1
        if measured is None or measured < 0. or row.get('leader_id') and gap is None:
            invalid += 1
        if measured is not None:
            speeds.append(measured)
        if gap is not None:
            if first_observed:
                first_observed_gaps.append(gap)
            sample_gaps.append(gap)
            overlaps += gap < 0.
            if row.get('at_conflict') == '1':
                conflict_gaps.append(gap)
        if probe and row.get('policy') != 'cruise_only_probe':
            invalid += 1
        age, acc = _number(row, 'age_s'), _number(row, 'following_acceleration')
        early_brakes += age is not None and age <= 1. and acc is not None and acc < -.1
    if invalid:
        errors.append('invalid_spacing_rows')
    # run_step samples existing actors before its end-of-step spawn. A vehicle
    # born on a proven terminal frame has no subsequent sampling opportunity.
    # Require BOTH full ego frame coverage and the episode summary; do not
    # excuse a missing actor in the middle of an episode or a spacing probe.
    terminal_frames={}
    if not probe:
        by_episode={}
        for row in _rows(directory/'interaction_ego.csv'):
            frame=_number(row,'frame')
            if frame is not None and frame.is_integer():
                by_episode.setdefault(row.get('episode'),set()).add(int(frame))
        for row in _rows(directory/'interaction_summary.csv'):
            frames=_number(row,'frames');seen=by_episode.get(row.get('episode'),set())
            if (frames is not None and frames.is_integer() and frames>=1 and
                    row.get('outcome') in ('complete','collision','stuck') and
                    seen==set(range(1,int(frames)+1))):
                terminal_frames[row.get('episode')]=int(frames)
    missing=identities-seen_samples
    censored=[]
    for row in spawned:
        identity=(row.get('episode'),row.get('trial'),row.get('actor_id'))
        frame=_number(row,'frame')
        if (identity in missing and row.get('trial')=='0' and frame is not None and
                frame==terminal_frames.get(row.get('episode'))):
            censored.append(dict(episode=identity[0],trial=identity[1],actor_id=identity[2],
                                 frame=int(frame),reason='terminal_frame_no_next_sample'))
    explained={(r['episode'],r['trial'],r['actor_id']) for r in censored}
    unexpected=missing-explained
    if not spawn_gaps or not first_observed_gaps or not sample_gaps or unexpected:
        errors.append('missing_actual_gap_or_actor_samples')
    # Following/physical transients and collisions remain visible outcomes;
    # they must not be confused with an invalid spawn-distance contract.
    warnings = []
    if target is not None and any(g < target-.05 for g in first_observed_gaps):
        warnings.append('first_observed_gap_below_target')
    if overlaps:
        warnings.append('observed_body_overlap')
    if early_brakes:
        warnings.append('birth_follow_braking')
    if interaction_revision == 'v17':
        following = validate_following_rows(samples)
        if metadata.get('interaction_revision') != 'v17' or not following['traffic_following_contract_ok']:
            errors.append('v17_following_contract')
    else:
        following = {}
    return dict(following, traffic_spacing_contract_ok=not errors, traffic_spacing_errors=sorted(set(errors)),
        traffic_interaction_revision=metadata.get('interaction_revision', 'legacy'),
        traffic_spacing_quality_warnings=warnings,
        traffic_revision=metadata.get('revision'), traffic_interactions_enabled=metadata.get('interactions_enabled'),
        traffic_target_clear_gap=target, traffic_cruise_target=speed, traffic_measured_length=length,
        traffic_spawn_interval_s=interval, traffic_spawn_count=len(spawned),
        traffic_deferred_spawn_rows=sum(r.get('event', '').startswith('deferred') for r in events),
        traffic_spawn_projected_clear_gaps=_stats(spawn_gaps),
        traffic_first_observed_clear_gaps=_stats(first_observed_gaps), traffic_sample_clear_gaps=_stats(sample_gaps),
        traffic_conflict_clear_gaps=_stats(conflict_gaps), traffic_observed_speeds=_stats(speeds),
        traffic_sample_rows=len(samples), traffic_invalid_rows=invalid,
        traffic_overlap_rows=overlaps, traffic_birth_follow_braking_rows=early_brakes,
        traffic_terminal_unobserved_spawns=censored,
        traffic_unexpected_unsampled_actors=[dict(episode=e,trial=t,actor_id=a)
                                            for e,t,a in sorted(unexpected,key=str)])
