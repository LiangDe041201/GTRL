#!/usr/bin/env python3
"""Small guarded-trajectory pilot; no Q training, reward or confidence changes."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile

if __package__:
    from .summarize_matrix_comparison import episode_metrics
else:
    from summarize_matrix_comparison import episode_metrics

ROOT = Path(__file__).resolve().parents[1]
PHYSICAL_FIELDS = ('episode', 'frame', 'ego_x', 'ego_y', 'ego_v', 'ego_v_after',
    'a_cmd', 'delta_rad', 'steer', 'actuator_speed_target', 'guard_action', 'mpc_audit_override')
PROBE_FIELDS = ('active_rows', 'generated_variants', 'eligible_variants', 'changed_requests')


def build_plan(output, probe_episodes=3, seeds=None, smoke_episodes=2):
    seeds = [31, 32, 33] if seeds is None else list(seeds)
    common = ['--method', 'CG', '--game-mode', 'matrix_v18', '--traffic', 'on',
        '--traffic-interaction', 'v17', '--control-profile', 'paper_v11',
        '--completion-mode', 'strict', '--keep-going']
    result = []
    for name, episodes, stage_seeds, arms in (
            ('00_smoke', smoke_episodes, [30], ['M6_matrix_v18', 'P0_observe_v21']),
            ('01_probe', probe_episodes, seeds,
             ['P0_observe_v21', 'P1_defer_v21', 'P2_proceed_v21'])):
        arguments = common+['--episodes', str(episodes), '--seeds', ','.join(map(str, stage_seeds)),
            '--arms', ','.join(arms), '--output-root', str(output/name)]
        result.append(dict(name=name, episodes_per_run=episodes, seeds=stage_seeds, arms=arms,
            episodes_total=episodes*len(stage_seeds)*len(arms), arguments=arguments))
    return result


def _rows(path):
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def _observe_identity(output):
    stage = output/'00_smoke'
    paths = [stage/(arm+'_seed30')/'interaction_ego.csv'
             for arm in ('M6_matrix_v18', 'P0_observe_v21')]
    try:
        data = [_rows(path) for path in paths]
        for rows in data:
            if not rows or any(any(r.get(key) in (None, '') for key in PHYSICAL_FIELDS) for r in rows):
                raise ValueError('Missing physical rows or required physical signature fields')
        signatures = [[tuple(r[key] for key in PHYSICAL_FIELDS) for r in rows] for rows in data]
        same = signatures[0] == signatures[1]
        return dict(ok=same, baseline_rows=len(data[0]), observe_rows=len(data[1]),
                    reason='identical_at_recorded_precision' if same else 'physical_records_differ')
    except (OSError, ValueError, csv.Error) as exc:
        return dict(ok=False, reason=str(exc))


def _stage_report(output, stage):
    root = output/stage['name']
    result = dict(name=stage['name'], planned_episodes=stage['episodes_total'],
                  collected_runs=0, collection_ok=False, arms={}, errors=[])
    try:
        manifest = json.loads((root/'manifest.json').read_text(encoding='utf8'))
        runs = manifest['runs']
        expected = {(arm, seed) for seed in stage['seeds'] for arm in stage['arms']}
        actual = [(r['arm'], r['seed']) for r in runs]
        result['collected_runs'] = len(runs)
        if set(actual) != expected or len(actual) != len(expected):
            result['errors'].append('Missing, duplicated or unexpected arm/seed runs')
        if manifest.get('overall_success') is not True or manifest.get('collection_finished') is not True:
            result['errors'].append('Relay collection or contract validation failed')
        for run in runs:
            arm, seed = run['arm'], run['seed']
            # Returned manifests contain remote absolute paths; resolve locally.
            directory = root/('%s_seed%d' % (arm, seed))
            group = result['arms'].setdefault(arm, dict(episodes=[],
                probe=dict(dict.fromkeys(PROBE_FIELDS, 0), reported_runs=0, missing_runs=0)))
            group['probe']['missing_runs'] += 1
            try:
                run_result = json.loads((directory/'result.json').read_text(encoding='utf8'))
                complete_probe = True
                for field in PROBE_FIELDS:
                    count = run_result.get('trajectory_probe_'+field)
                    if isinstance(count, int) and not isinstance(count, bool) and count >= 0:
                        group['probe'][field] += count
                    else:
                        complete_probe = False
                if complete_probe:
                    group['probe']['reported_runs'] += 1
                    group['probe']['missing_runs'] -= 1
                if (run.get('status') != 'complete' or run_result.get('complete') is not True
                        or run_result.get('ego_log_complete') is not True
                        or any(v is False for k, v in run_result.items() if k.endswith('_contract_ok'))):
                    result['errors'].append('%s_seed%d failed collection/contracts' % (arm, seed))
                summaries = _rows(directory/'interaction_summary.csv')
                rows = _rows(directory/'interaction_ego.csv')
                by_episode = defaultdict(list)
                for row in rows:by_episode[row['episode']].append(row)
                episodes = [r['episode'] for r in summaries]
                if (len(episodes) != stage['episodes_per_run'] or len(set(episodes)) != len(episodes)
                        or set(episodes) != set(by_episode)):
                    result['errors'].append('%s_seed%d incomplete episode records' % (arm, seed))
                for summary in summaries:
                    selected = by_episode[summary['episode']]
                    if int(summary['frames']) != len(selected):
                        result['errors'].append('%s_seed%d frame count mismatch' % (arm, seed))
                    group['episodes'].append(dict(episode_metrics(selected, summary), seed=seed))
            except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
                result['errors'].append('%s_seed%d: %s' % (arm, seed, exc))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result['errors'].append(str(exc))
    for group in result['arms'].values():
        episodes = group['episodes']
        completed = [e for e in episodes if e['outcome'] == 'complete']
        outcomes = dict(Counter(e['outcome'] for e in episodes))
        group.update(n=len(episodes), success=len(completed), outcomes=outcomes,
            collisions=outcomes.get('collision', 0), stuck=outcomes.get('stuck', 0),
            success_rate=len(completed)/len(episodes) if episodes else None,
            mean_all_episode_s=statistics.mean(e['seconds'] for e in episodes) if episodes else None,
            mean_completed_s=statistics.mean(e['seconds'] for e in completed) if completed else None,
            mean_entry_wait_s=statistics.mean(e['entry_wait_s'] for e in episodes) if episodes else None,
            mean_non_goal_stop_events=statistics.mean(e['non_goal_stop_events'] for e in episodes) if episodes else None)
    count = sum(g['n'] for g in result['arms'].values())
    result['collection_ok'] = not result['errors'] and count == stage['episodes_total']
    return result


def collect_report(output, stages):
    collected = [_stage_report(output, stage) for stage in stages]
    identity = _observe_identity(output)
    report = dict(revision='trajectory_pilot_v21', stages=collected,
        smoke_observe_identity=identity, collection_ok=bool(collected) and identity['ok']
            and all(s['collection_ok'] for s in collected),
        all_episodes_successful=False, comparisons={}, benefit_established=False,
        note='No Q training or learned takeover. Include collision/stuck episodes in all-episode means. '
             'Paired initial seeds do not force identical closed-loop traffic. This pilot does not prove benefit.',
        probe_counts='Group probe fields sum trajectory_probe_* run counters: active frame rows, generated '
            'variants, guard-eligible variants and changed requests. These are not independent learning samples. '
            'Only runs reporting all four nonnegative integer counters enter reported_runs; absent/partial '
            'metrics enter missing_runs. Missing counts add zero without claiming measured inactivity; '
            'the frozen M6 baseline normally has no probe counters.')
    report['all_episodes_successful'] = report['collection_ok'] and all(
        g['n'] == g['success'] for stage in collected for g in stage['arms'].values())
    formal = next((s for s in collected if s['name'] == '01_probe'), None)
    groups = formal['arms'] if formal is not None else {}
    baseline = {(e['seed'], e['episode']): e for e in groups.get('P0_observe_v21', {}).get('episodes', [])}
    for name, arm in (('defer_vs_observe', 'P1_defer_v21'), ('proceed_vs_observe', 'P2_proceed_v21')):
        treatment = {(e['seed'], e['episode']): e for e in groups.get(arm, {}).get('episodes', [])}
        pairs = []
        for key in sorted(set(baseline) & set(treatment)):
            a, b = treatment[key], baseline[key]
            pairs.append(dict(seed=key[0], episode=key[1], treatment_outcome=a['outcome'],
                baseline_outcome=b['outcome'], seconds_delta=a['seconds']-b['seconds'],
                entry_wait_s_delta=a['entry_wait_s']-b['entry_wait_s']))
        report['comparisons'][name] = dict(treatment=arm, baseline='P0_observe_v21',
            paired_episodes=len(pairs), treatment_unpaired=len(set(treatment)-set(baseline)),
            baseline_unpaired=len(set(baseline)-set(treatment)), pairs=pairs,
            mean_all_episode_s_delta=statistics.mean(p['seconds_delta'] for p in pairs) if pairs else None)
    (output/'TRAJECTORY_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = ['v21 guarded trajectory pilot (simulation seconds)',
             'Collection complete: %s; every episode successful: %s' %
             (report['collection_ok'], report['all_episodes_successful']),
             'Observe-only physical identity: %s' % identity['ok'], report['note']]
    for stage in collected:
        lines.append('[%s] collection=%s' % (stage['name'], stage['collection_ok']))
        for arm, group in stage['arms'].items():
            lines.append('%s: n=%d success=%d collision=%d stuck=%d mean_all_s=%s mean_completed_s=%s' %
                (arm, group['n'], group['success'], group['collisions'], group['stuck'],
                 group['mean_all_episode_s'], group['mean_completed_s']))
            p = group['probe']
            lines.append('  probe_active=%d probe_generated=%d probe_changed=%d probe_eligible=%d '
                'probe_metric_runs=%d probe_missing_runs=%d' %
                (p['active_rows'], p['generated_variants'], p['changed_requests'],
                 p['eligible_variants'], p['reported_runs'], p['missing_runs']))
        lines.extend('ERROR: '+error for error in stage['errors'])
    lines.append(report['probe_counts'])
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n', encoding='utf8')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe-episodes', type=int, default=3)
    parser.add_argument('--smoke-episodes', type=int, default=2)
    parser.add_argument('--seeds', default='31,32,33')
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    try:
        seeds = [int(s) for s in args.seeds.split(',')]
        if (not seeds or len(seeds) != len(set(seeds)) or 30 in seeds
                or args.probe_episodes < 1 or args.smoke_episodes < 1):
            raise ValueError('Positive episodes and unique formal seeds distinct from smoke seed 30 required')
    except ValueError as exc:parser.error(str(exc))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output = (args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_trajectory_v21_'+stamp)).resolve()
    stages = build_plan(output, args.probe_episodes, seeds, args.smoke_episodes)
    if args.dry_run:
        for stage in stages:print(json.dumps(stage, ensure_ascii=False))
        return 0
    archive = Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():parser.error('Output or archive already exists; choose a new --output-root')
    output.mkdir(parents=True, exist_ok=False)
    workflow = dict(revision='trajectory_pilot_v21', planned_episodes=sum(s['episodes_total'] for s in stages),
        stages=stages, overall_success=None, learned_takeover=False,
        note='CG default remains frozen; observe records candidates without changing controls. '
             'Prespecified guarded trajectory interventions are not learned improvements.')
    workflow_path = output/'WORKFLOW.json'
    status = 1
    workflow_path.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
    try:
        status = 0
        for stage in stages:
            stage['status'] = 'running'
            workflow_path.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
            print('[%s] planned episodes=%d' % (stage['name'], stage['episodes_total']), flush=True)
            completed = subprocess.run([sys.executable, '-u', str(ROOT/'Tools/run_relay_validation.py')]
                                       +stage['arguments'], cwd=str(ROOT))
            stage['returncode'] = completed.returncode
            partial = collect_report(output, stages)
            stage_report = next(s for s in partial['stages'] if s['name'] == stage['name'])
            status = completed.returncode or (11 if not stage_report['collection_ok'] else 0)
            if stage['name'] == '00_smoke' and not partial['smoke_observe_identity']['ok']:
                status = status or 12
            stage['status'] = 'collected' if status == 0 else 'failed'
            if status:
                print('Collection/contract failure; preserving all completed and partial runs.', flush=True)
                break
        report = collect_report(output, stages)
        if status == 0 and not report['collection_ok']:status = 11
    except KeyboardInterrupt:
        status = 130;workflow['error'] = 'Interrupted by user'
    except Exception as exc:
        status = 1;workflow['error'] = '%s: %s' % (type(exc).__name__, exc)
    finally:
        workflow['overall_success'] = status == 0
        workflow['exit_code'] = status
        workflow_path.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
        collect_report(output, stages)
        with tarfile.open(str(archive), 'x:gz') as stream:
            stream.add(str(output), arcname=output.name)
        print('Result folder: '+str(output), flush=True)
        print('Return this archive, including failed runs: '+str(archive), flush=True)
    return status


if __name__ == '__main__':raise SystemExit(main())
