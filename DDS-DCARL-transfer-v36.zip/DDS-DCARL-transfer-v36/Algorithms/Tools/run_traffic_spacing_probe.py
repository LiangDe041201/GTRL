#!/usr/bin/env python3
"""Observe background traffic alone, with a stationary ego and no MPC/RL/game."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from Planning_library.traffic_spacing import FlowSpacing
from Tools.validate_traffic_spacing import validate_traffic_spacing


def main(argv=None, env_factory=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--trials', type=int, default=3)
    parser.add_argument('--seconds', type=float, default=25.)
    parser.add_argument('--vehicles', type=int, default=8)
    parser.add_argument('--clear-gap', type=float, default=5.)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    if args.trials < 1 or args.vehicles < 2 or not math.isfinite(args.seconds) or args.seconds <= 0.:
        parser.error('Positive trials/seconds and at least 2 vehicles are required')
    try:
        spacing = FlowSpacing(clear_gap=args.clear_gap)
    except ValueError as exc:
        parser.error(str(exc))
    if args.dry_run:
        print(json.dumps(dict(stage='traffic_spacing_probe', revision='spacing_v12',
            control_profile='paper_v11', mpc_used=False, ego_stationary=True,
            interactions_enabled=False, trials=args.trials, seconds_per_trial=args.seconds,
            vehicles_per_trial=args.vehicles, spacing=spacing.metadata())))
        return 0
    if args.output_root is None:
        parser.error('--output-root is required')
    output = args.output_root.resolve()
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error('Output already exists: '+str(output))
    for key in list(os.environ):
        if key.startswith('DSH_'):
            del os.environ[key]
    os.environ.update(DSH_CONTROL_PROFILE='paper_v11', DSH_TRAFFIC='on', DSH_SEED='1',
        DSH_SAVE_DIR=str(output), DSH_PLOT_DIR=str(output/'plots'), DSH_CONTROL_PROBE='0',
        DSH_TRAFFIC_CLEAR_GAP=str(args.clear_gap), DSH_GAP_AFTER='0', DSH_RV_MAX=str(args.vehicles))
    sources = [ROOT/'train_dcarl_turn.py', ROOT/'path_utils.py']
    for folder in ('Agent', 'Planning_library', 'Test_Scenarios', 'Tools'):
        sources.extend(sorted((ROOT/folder).rglob('*.py')))
    (output/'manifest.json').write_text(json.dumps(dict(revision='traffic_spacing_probe_v12',
        trials=args.trials, seconds_per_trial=args.seconds, vehicles_per_trial=args.vehicles,
        target_clear_gap=args.clear_gap, mpc_used=False, ego_stationary=True,
        source_sha256={p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in sources}), indent=2), encoding='utf8')
    env, error, trials = None, None, []
    try:
        if env_factory is None:
            from Test_Scenarios.TestScenario_Town03_turn import CarEnv_Town03_Turn
            env_factory = CarEnv_Town03_Turn
        env = env_factory()
        for trial in range(1, args.trials+1):
            random.seed(trial)
            env.reset(False)
            flow = env.cross_traffic
            flow.interactions_enabled = False
            flow.ilog.begin_episode(trial)
            flow.start_flow(trial=trial)
            before_count = flow._spawned_count
            for _ in range(int(math.ceil(args.seconds/env.dt-1e-9))):
                _, _, done, _ = env.step([-.3, 0.], target_speed=0.)
                control = env.last_control
                if float(control['ego_v_after']) >= .1:
                    raise RuntimeError('Spacing probe ego did not remain stationary')
                if control['control_submit_ok'] != 1 or control['control_tick_frame'] != control['sim_frame_after']:
                    raise RuntimeError('Invalid stationary-ego control submission')
                if done:
                    raise RuntimeError('Unexpected spacing probe environment termination')
            trials.append(dict(trial=trial, spawned=flow._spawned_count-before_count,
                               seconds=args.seconds, interactions_enabled=flow.interactions_enabled))
            print(json.dumps(trials[-1]), flush=True)
    except Exception:
        error = traceback.format_exc()
        print(error, file=sys.stderr)
    finally:
        if env is not None:
            try:
                env.cleanup()
            except Exception:
                error = error or traceback.format_exc()
    evidence = validate_traffic_spacing(output, expected_spawns=args.trials*args.vehicles,
        expected_trials=range(1, args.trials+1), probe=True)
    result = dict(evidence, trials=trials, error=error, mpc_used=False,
        complete=error is None and len(trials) == args.trials,
        note='Spacing contracts gate progression; measured speed/spacing transients remain reported outcomes.')
    result['probe_collection_ok'] = result['complete'] and result['traffic_spacing_contract_ok']
    (output/'result.json').write_text(json.dumps(result, indent=2), encoding='utf8')
    print(json.dumps(result), flush=True)
    return 0 if result['probe_collection_ok'] else 7


if __name__ == '__main__':
    raise SystemExit(main())
