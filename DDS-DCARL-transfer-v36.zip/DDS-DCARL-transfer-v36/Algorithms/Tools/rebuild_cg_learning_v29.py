"""Replay v24 real transitions with CG0 and the v29 neutral soft reference.

This is off-policy empirical Bellman replay, not additional CARLA training.
It keeps the observed state partition, action ownership, returns, durations,
interventions and independent episode identities. Unexecuted actions get no
synthetic samples. Old fitted Q values and geometry priors are discarded.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
from Planning_library.rolling_learning_v24 import RollingLearner


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _integer(value, minimum=0, maximum=None):
    return (isinstance(value, int) and not isinstance(value, bool)
            and value >= minimum and (maximum is None or value <= maximum))


def _finite_vector(value, length):
    return (isinstance(value, list) and len(value) == length
            and all(isinstance(v, (int, float)) and not isinstance(v, bool)
                    and math.isfinite(v) for v in value))


def _beta_bins(beta):
    _require(isinstance(beta, dict) and set(beta) >= {'alpha', 'beta'}, 'Missing beta parameters')
    a, b = beta['alpha'], beta['beta']
    _require(all(isinstance(v, (int, float)) and not isinstance(v, bool)
                 and math.isfinite(v) and v >= 1. for v in (a, b)), 'Invalid beta parameters')
    _require(math.isfinite(a + b), 'Nonfinite beta sum')
    mean, var = a / (a + b), a * b / ((a + b) ** 2 * (a + b + 1.))
    return [int(round(mean * 4)), int(round(var / .02))]


def _context_matches(context, beta, parts):
    _require(_finite_vector(context, 16), 'Invalid observed physical context')
    bins = np.rint(np.asarray(context) / RollingLearner.WIDTHS).astype(int).tolist()
    _require(bins == parts[0] and _beta_bins(beta) == parts[1],
             'Observed context/beta does not match its original state key')


def _validate(data):
    old = RollingLearner()
    _require(isinstance(data, dict) and data.get('signature') == old.signature(),
             'Only the exact supported v24 state/action/reward/configuration signature can be replayed')
    nodes, records, values = data.get('nodes'), data.get('records'), data.get('q')
    _require(isinstance(nodes, dict) and isinstance(records, list) and isinstance(values, dict),
             'Expected old nodes, records and fitted q objects')
    _require(set(nodes) == set(values), 'Old Q and node keys differ')
    decoded = {}
    for key, node in nodes.items():
        try:
            parts = json.loads(key)
        except (ValueError, TypeError):
            raise ValueError('Invalid old state key')
        _require(isinstance(parts, list) and len(parts) == 4
                 and isinstance(parts[0], list) and len(parts[0]) == 16
                 and all(isinstance(v, int) and not isinstance(v, bool) for v in parts[0])
                 and isinstance(parts[1], list) and len(parts[1]) == 2
                 and all(_integer(v) for v in parts[1])
                 and _integer(parts[2], 0, 5), 'Invalid old state partition')
        allowed = parts[3]
        _require(isinstance(allowed, list) and allowed and all(_integer(v, 0, 5) for v in allowed)
                 and allowed == sorted(set(allowed)) and 0 in allowed and parts[2] in allowed,
                 'Original admissible set must contain CG0 and its geometry proposal')
        _require(isinstance(node, dict) and node.get('allowed') == allowed
                 and _integer(node.get('default'), 0, 5) and node['default'] == parts[2],
                 'Old geometry default differs from its state key/admissible set')
        _context_matches(node.get('context'), node.get('beta'), parts)
        prior = node.get('prior')
        _require(_finite_vector(prior, 6) and all(v >= 0. for v in prior)
                 and math.isclose(sum(prior), 1., rel_tol=0., abs_tol=1.e-10)
                 and all((prior[a] > 0.) == (a in allowed) for a in range(6)),
                 'Invalid old reference distribution')
        _require(_finite_vector(values[key], 6), 'Invalid old fitted values')
        decoded[key] = parts
    required = {'state', 'action', 'episode', 'context', 'beta', 'reward',
                'discount', 'steps', 'interventions', 'next'}
    for record in records:
        _require(isinstance(record, dict) and set(record) >= required, 'Incomplete actual transition')
        state, action, next_key = record['state'], record['action'], record['next']
        _require(isinstance(state, str) and state in nodes
                 and (next_key is None or isinstance(next_key, str) and next_key in nodes),
                 'Actual transition references an unknown state')
        _require(_integer(action, 0, 5) and action in nodes[state]['allowed'],
                 'Actual action was not in its original admissible set')
        _require(_integer(record['episode'], 1) and _integer(record['steps'], 1)
                 and _integer(record['interventions'], 0, record['steps']),
                 'Invalid original episode/duration/intervention count')
        _require(all(isinstance(record[name], (int, float)) and not isinstance(record[name], bool)
                     and math.isfinite(record[name]) for name in ('reward', 'discount')),
                 'Nonfinite actual return/discount')
        _require(math.isclose(record['discount'], old.gamma ** record['steps'],
                              rel_tol=1.e-10, abs_tol=1.e-10),
                 'Actual continuation discount differs from gamma ** duration')
        _context_matches(record['context'], record['beta'], decoded[state])
    return decoded


def _digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False,
                      separators=(',', ':')).encode('utf8')


def _post_residual(learner):
    values = learner._values()
    return float(max((abs(learner.q[key][action] - float(np.mean(learner._samples(key, action, values))))
                      for key, action in learner.edges), default=0.))


def rebuild(source_path, output_path, audit_path=None, max_sweeps=2000):
    """Re-fit the supported old real-experience model without changing coverage.

    Both output files are exclusive creations. A finite sweep budget may leave
    an empirical Bellman residual; callers must inspect ``bellman_converged``.
    This result estimates a changed empirical soft objective off-policy. It
    cannot establish closed-loop driving improvement or causal safety benefit.
    """
    source = Path(source_path).resolve()
    output = Path(output_path).resolve()
    audit = Path(audit_path).resolve() if audit_path is not None else output.with_suffix('.audit.json')
    _require(len({source, output, audit}) == 3, 'Source, rebuilt model and audit must have distinct paths')
    _require(_integer(max_sweeps, 1), 'max_sweeps must be a positive integer')
    for target in (output, audit):
        if target.exists():
            raise FileExistsError('Refusing to overwrite existing evidence: {}'.format(target))
    before = source.read_bytes()
    data = json.loads(before.decode('utf8'), parse_constant=lambda value:
                      (_ for _ in ()).throw(ValueError('Nonfinite JSON constant: ' + value)))
    decoded = _validate(data)
    learner = CGTrajectoryLearnerV29(phase='train')
    learner.nodes = copy.deepcopy(data['nodes'])
    learner.q = {key: np.zeros(6) for key in learner.nodes}
    learner.records = copy.deepcopy(data['records'])
    for key, node in learner.nodes.items():
        node['default'] = 0
        node['proposal_geometry_stratum'] = decoded[key][2]
        node['prior'] = [1. / len(node['allowed']) if a in node['allowed'] else 0. for a in range(6)]
    for record in learner.records:
        learner.edges[(record['state'], record['action'])].append(record)
    learner.iterate(sweeps=max_sweeps)
    residual = _post_residual(learner)
    # Coverage remains a count of distinct original CARLA episodes per edge.
    coverage = {edge: len({r['episode'] for r in records}) for edge, records in learner.edges.items()}
    comparisons, covered_states, max_joint = 0, set(), 0
    for key, node in learner.nodes.items():
        for action in node['allowed']:
            if action == 0:
                continue
            joint = min(coverage.get((key, 0), 0), coverage.get((key, action), 0))
            max_joint = max(max_joint, joint)
            if joint >= learner.min_episodes:
                comparisons += 1
                covered_states.add(key)
    saved = dict(signature=learner.signature(), nodes=learner.nodes, records=learner.records,
                 q={key: values.tolist() for key, values in learner.q.items()})
    _require(saved['records'] == data['records'] and set(saved['nodes']) == set(data['nodes']),
             'Replay changed original evidence or state identities')
    _require(source.read_bytes() == before, 'Source changed during replay; no model written')
    raw = _json_bytes(saved)
    source_hash = _digest(before)
    report = dict(source_path=str(source), output_path=str(output), audit_path=str(audit),
        source_sha256=source_hash, output_sha256=_digest(raw), source_unchanged=True,
        source_signature=data['signature'], output_signature=saved['signature'],
        real_state_count=len(learner.nodes), real_transition_records=len(learner.records),
        real_episode_count=len({r['episode'] for r in learner.records}),
        synthetic_transition_records=0, new_CARLA_episodes=0, merged_state_count=0,
        max_state_action_episode_coverage=max(coverage.values(), default=0),
        cg_comparisons_meeting_coverage=comparisons, cg_states_meeting_coverage=len(covered_states),
        max_cg_joint_episode_coverage=max_joint, minimum_independent_episodes=learner.min_episodes,
        records_sha256=_digest(_json_bytes(data['records'])),
        old_q_discarded=True, old_reference_discarded=True, initial_q='zero_without_pseudo_samples',
        bellman_sweeps=learner.sweeps, bellman_residual=residual, bellman_converged=residual <= 1.e-7,
        confidence_guarantee=False, learning_benefit_established=False,
        replay_kind='off_policy_empirical_soft_bellman_real_transitions',
        limitation='No new CARLA episodes, counterfactual returns, sample coverage or closed-loop benefit are created.')
    audit_raw = _json_bytes(report)
    output.parent.mkdir(parents=True, exist_ok=True)
    audit.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        stream.write(raw)
    _require(_digest(source.read_bytes()) == source_hash, 'Source changed before final audit')
    with audit.open('xb') as stream:
        stream.write(audit_raw)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', help='Unmodified original v24 rolling_model.json')
    parser.add_argument('--output', required=True, help='New v29 model path; must not exist')
    parser.add_argument('--audit', help='New audit JSON path; defaults to output stem.audit.json')
    parser.add_argument('--max-sweeps', type=int, default=2000)
    args = parser.parse_args(argv)
    try:
        report = rebuild(args.source, args.output, args.audit, args.max_sweeps)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(report, ensure_ascii=False, allow_nan=False))
    return 0 if report['bellman_converged'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
