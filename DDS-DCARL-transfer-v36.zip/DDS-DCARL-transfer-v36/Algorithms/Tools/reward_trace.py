#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【奖励分量在线核账】逐帧打印 compute_causal_reward 的每一个分量。

为什么要这个脚本（不要删）
------------------------------------------------------------------
实测 A6（全开，59416 帧）：逐帧 reward **均值 −31.33**、正帧仅 10.0%。
但逐个核账只找到：
    r_safe_obj + r_prox_obj + r_pet_obj ≈ −1.48/帧
    r_thw（式65, penalty 形式）        ≈ −0.30/帧
    wait_cost                          ≈ −0.5/帧
加起来不到 −2.3，**解释不了 −31**。

⇒ 剩下的 ≈ −29/帧**来源不明**。在把奖励重标定之前，必须先知道"哪一项在支配"。
   否则任何改动都是盲改（本项目已经因为"盲改 + 无法观测"浪费过很多轮）。

本脚本用 `sys.settrace` 监视 `compute_causal_reward` 内部的 `r` 赋值，
**不修改任何业务代码**，只打印。追踪会产生一定开销（约 2~3 倍），
故只建议跑 1~2 个回合。

用法
------------------------------------------------------------------
  cd /home/liangde/PRB/DDS-DCARL-Turn/Algorithms
  DSH_EPISODES=1 DSH_ILOG=1 ... \
    /home/liangde/miniconda3/envs/carla/bin/python Tools/reward_trace.py

  # 只看前 N 帧（默认 400，避免日志过长）
  DSH_TRACE_FRAMES=400 ... python Tools/reward_trace.py
"""
from __future__ import annotations

import collections
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

MAX_FRAMES = int(os.environ.get('DSH_TRACE_FRAMES', '400'))
TARGET_FUNC = 'compute_causal_reward'

#: 每一项的累计统计：{标签: [次数, 累计值, 累计绝对值, 最小, 最大]}
STATS = collections.defaultdict(lambda: [0, 0.0, 0.0, float('inf'), float('-inf')])
#: 每帧各分量的值（用于算"每帧贡献"）
PER_FRAME = []
_CUR = {}
_frame_no = [0]
_lines_printed = [0]


def _record(label, value):
    """记一项的值。label 用源码行号 + 变量名，保证可追溯到具体代码。"""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return
    s = STATS[label]
    s[0] += 1
    s[1] += v
    s[2] += abs(v)
    s[3] = min(s[3], v)
    s[4] = max(s[4], v)
    _CUR[label] = v


def _flush_frame():
    if _CUR:
        PER_FRAME.append(dict(_CUR))
        _CUR.clear()


class _Tracer(object):
    """用 settrace 在 compute_causal_reward 里捕获每一次 `r = ...`。"""

    def __init__(self):
        self.depth = 0
        self.active = False
        self.entered = 0

    def __call__(self, frame, event, arg):
        code = frame.f_code
        # 只在目标函数（及其调用链）内活动
        if event == 'call':
            if code.co_name == TARGET_FUNC:
                self.active = True
                self.depth = 1
                _frame_no[0] += 1
                return self
            if self.active:
                self.depth += 1
            return self
        if not self.active:
            return self
        if event == 'return':
            self.depth -= 1
            if self.depth <= 0:
                self.active = False
                self.depth = 0
            return self
        if event == 'line':
            self._on_line(frame)
            return self
        return self

    def _on_line(self, frame):
        code = frame.f_code
        if code.co_name == TARGET_FUNC:
            _flush_frame()          # 进入新的一帧 ⇒ 结算上一帧
            if _frame_no[0] > MAX_FRAMES:
                raise KeyboardInterrupt('追踪帧数已达上限')
        # 捕获 `r = <expr>` 与 `r += <expr>`
        for nm in ('r', 'r_game', 'r_thw', 'r_yaw', 'r_lat'):
            if nm in frame.f_locals:
                try:
                    idx = list(code.co_names).index(nm)
                except ValueError:
                    idx = -1
                label = '%s@%d' % (nm, frame.f_lineno)
                _record(label, frame.f_locals[nm])


def main():
    # 延迟 import：确保 tracer 在训练脚本 import 完之后再装
    import importlib
    mod = importlib.import_module('Agent.drl_library.dds_dcarl.dds_dcarl_turn')

    # 定位目标函数所在文件（用于校验名字没变）
    modfile = getattr(mod, '__file__', None)
    print(f'[reward_trace] 目标模块: {modfile}')
    print(f'[reward_trace] 追踪函数: {TARGET_FUNC}（前 {MAX_FRAMES} 帧）')
    print('[reward_trace] 注意：settrace 会显著拖慢仿真，仅用于诊断\n')

    tracer = _Tracer()
    sys.settrace(tracer)
    try:
        import runpy
        runpy.run_path(os.path.join(_HERE, 'train_dcarl_turn.py'), run_name='__main__')
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        sys.settrace(None)

    print('\n' + '=' * 88)
    print('【奖励分量核账】按 |累计| 排序（只列非零项）')
    print('=' * 88)
    print(f"{'标签（变量@行号）':<26}{'次数':<8}{'累计':<14}{'均值':<11}{'min':<10}{'max'}")
    rows = [(k, v) for k, v in STATS.items() if v[0] > 0]
    rows.sort(key=lambda kv: -kv[1][2])
    for k, (n, tot, abstot, mn, mx) in rows:
        print(f'{k:<26}{n:<8}{tot:<14.1f}{tot / n:<11.3f}{mn:<10.2f}{mx:.2f}')
    print()
    print('提示：`r@行号` 表示该行执行了一次 `r = ...`（或读到了 r 的当前值）。')
    print('      行号可在 Agent/drl_library/dds_dcarl/dds_dcarl_turn.py 中对照代码。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
