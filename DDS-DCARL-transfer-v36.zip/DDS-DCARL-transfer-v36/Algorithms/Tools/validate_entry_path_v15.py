"""Check the entry ablation, shared path and actual post-audit motion evidence."""
from collections import Counter
import json
import math
from pathlib import Path


def validate_entry_path(directory, ego_rows, policy, spatial_mode=None, rolling_phase=None):
    expected = {(int(r['episode']), int(r['frame'])): r for r in ego_rows}
    errors, statuses = Counter(), Counter()
    seen, accepted_slow, slow_run, longest = set(), 0, 0, 0
    previous_key = None
    bounds, curvatures = [], []
    spatial = {}
    if spatial_mode is not None or rolling_phase is not None:
        try:
            with (Path(directory)/'matrix_decisions.jsonl').open(encoding='utf8') as stream:
                for line in stream:
                    item = json.loads(line)
                    spatial[(int(item['episode']), int(item['frame']))] = item[
                        'rolling_trajectory' if rolling_phase is not None else 'spatial_probe']
        except (OSError, ValueError, KeyError, TypeError):
            errors['missing_spatial_owner'] += 1
    path = Path(directory)/'entry_path_audit.jsonl'
    if not path.is_file():
        errors['missing_file'] += 1
    else:
        with path.open(encoding='utf8') as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                    key = int(row['episode']), int(row['frame'])
                    ego = expected.get(key)
                    if key in seen or ego is None:
                        errors['duplicate_or_unknown_frame'] += 1
                    seen.add(key)
                    if (row['revision']!='entry_path_v15' or row['entry_policy']!=policy
                            or row['advance_enabled']!=(policy=='full')
                            or row['advance_called']!=(policy=='full')
                            or row['final_guard_enabled'] is not True):
                        errors['entry_policy'] += 1
                    diag = row['path']; statuses[diag['status']] += 1
                    if diag['revision']!='spatial_v15':
                        errors['path_revision'] += 1
                    if diag['status']=='resampled':
                        bound=float(diag['deviation_bound'])
                        bounds.append(bound)
                        if not math.isfinite(bound) or not 0. <= bound <= .05:
                            errors['geometry_deviation'] += 1
                        if row['geometry_source']=='planned' and diag['output_hash']!=row['actual_path_hash']:
                            owner = spatial.get(key)
                            mode_ok = owner is not None and (owner.get('phase') == rolling_phase if rolling_phase is not None
                                                             else owner.get('mode') == spatial_mode)
                            legitimate = (mode_ok
                                and owner['changed_request'] and owner['final_reviewed']
                                and owner['baseline_path_hash'] == diag['output_hash']
                                and owner['request']['path_hash'] == row['actual_path_hash'])
                            if not legitimate:
                                errors['mpc_path_mismatch'] += 1
                    curvature = float(row['mpc_kappa'])
                    if not math.isfinite(curvature):
                        errors['nonfinite_curvature'] += 1
                    curvatures.append(abs(curvature))
                    if ego is not None:
                        for field,csvfield in (('applied_target','actuator_speed_target'),
                                               ('speed_before','ego_v_before'),('speed_after','ego_v_after'),
                                               ('applied_a','a_cmd')):
                            value,saved=float(row[field]),float(ego[csvfield])
                            if not math.isfinite(value) or not math.isfinite(saved) or abs(value-saved)>1e-5:
                                errors['motion_link_'+field] += 1
                        if (row['guard_action']!=ego['guard_action'] or
                                bool(row['guard_override'])!=(ego['mpc_audit_override']=='1')):
                            errors['guard_link'] += 1
                    slow = (row['matrix_active'] and row['matrix_selected']==1
                            and not row['guard_override'] and row['applied_target']>=1.
                            and row['speed_after']<.1)
                    accepted_slow += bool(slow)
                    consecutive = previous_key is not None and key==(previous_key[0],previous_key[1]+1)
                    slow_run = (slow_run+1 if consecutive else 1) if slow else 0
                    longest=max(longest,slow_run); previous_key=key
                except (ValueError,TypeError,KeyError,IndexError,OverflowError):
                    errors['invalid_record'] += 1
    if seen!=set(expected) or not expected:
        errors['frame_coverage'] += 1
    return dict(entry_path_contract_ok=not errors, entry_path_errors=dict(errors),
        entry_policy=policy, spatial_path_statuses=dict(statuses),
        spatial_path_max_deviation_bound=max(bounds) if bounds else None,
        mpc_max_abs_reference_curvature=max(curvatures) if curvatures else None,
        matrix_accepted_go_low_speed_rows=accepted_slow,
        matrix_longest_accepted_go_low_speed_s=.05*longest)
