"""Re-solve saved public JSON snapshots; no CARLA and no pickle loading.

This is a same-observation model diagnostic, not a closed-loop performance test.
"""
import argparse
import contextlib
import io
import json
from pathlib import Path
import sys
from types import SimpleNamespace as S

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def replay(row):
    import numpy as np
    from Agent.game_theory.MPC import MPCController
    from Planning_library.control_path_v15 import spatial_path
    from Planning_library.matrix_turn_game import solve_candidates
    from Planning_library.matrix_turn_game_v14 import score_candidates
    from Planning_library.cournot_game import expected_payoff_response
    from Planning_library.execution_guard import select_execution
    from Planning_library.trajectory_guard import execution_acceleration
    ego = S(**row['ego'])
    dynamic = S(ego_vehicle=ego, objects=[S(**v) for v in row['objects']],
                lanes=[S(front_vehicles=[], rear_vehicles=[])])
    rv = next((o for o in dynamic.objects if o.veh_id==row['rv_id']), None)
    result = dict(episode=row['episode'], frame=row['frame'], ego_v=ego.v, modes={})
    for mode in ('legacy', 'spatial_v15'):
        path = np.asarray(row['path'])
        diag = None
        if mode=='spatial_v15':
            path,diag = spatial_path(path)
        captured = io.StringIO()
        with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
            controllers = [MPCController(16,.05,2.7,.5,enable_lead_follow_cost=False,
                enable_boundary_thw=False,enable_cournot_cost=False,cost_profile='paper_v11',
                step_dts=[.05]*6+[.2]*10,vehicle_geometry=row['geometry']) for _ in range(2)]
            controllers[0].reset_global_path(path,dynamic)
            controllers[0].last_u = dict(row['previous'])
            targets = [c['target'] for c in row['candidates']]
            candidates = solve_candidates(*controllers,dynamic,targets[1],targets[0],False,(6.,-138.),True)
            actual_path = controllers[0].last_pathway
            matrix,parts = score_candidates(ego,dynamic.objects,rv,candidates,row['geometry'],
                actual_path,row['previous'],row['cruise'],observed_acceleration=
                row['decision'].get('motion_evidence',{}).get('acceleration'))
            # Match the saved declared switch cost, without inferring a new
            # history from a single snapshot. The v14 safety condition remains.
            if all(cell['risk']<=1e-12 for line in parts for cell in line):
                for i in range(2):
                    for j in range(2):
                        matrix[i][j] -= row['decision'].get('components',[[{},{}],[{},{}]])[i][j].get('switch_cost',0.)
            response = expected_payoff_response(matrix,row['decision']['p_yield'])
            choice = candidates[response['ego_action']]
            selected,audit = select_execution(ego,dynamic.objects,actual_path,choice['target'],
                execution_acceleration(choice['a'],max(float(ego.v),0.),choice['target']),
                choice['delta'],row['previous'],row['geometry'],
                prediction=choice['prediction'],prediction_times=choice['times'],
                plan=choice['plan'],solve_ok=choice['solve_ok'],allow_clear=True)
        result['modes'][mode] = dict(path=diag, kappa=float(controllers[0].reference_path.
            frenet_convertor.get_kappa(ego.x,ego.y)), solve_ok=[c['solve_ok'] for c in candidates],
            candidate_a=[c['a'] for c in candidates], candidate_speed_03s=
                [float(c['prediction'][5,6]) if c['prediction'] is not None else None for c in candidates],
            candidate_end_speed=[float(c['prediction'][5,-1]) if c['prediction'] is not None else None
                                 for c in candidates],
            selected=response['ego_action'],payoff_matrix=matrix,
            guard_action=audit['action'],guard_override=audit['override'],applied_target=selected['target'])
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshots',type=Path)
    parser.add_argument('--episode',type=int,default=5)
    parser.add_argument('--frames',default='779,800,820,1000,1003,1400')
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args(argv)
    frames = {int(f) for f in args.frames.split(',')}
    records = []
    with args.snapshots.open(encoding='utf8') as stream:
        for line in stream:
            row=json.loads(line)
            if row['episode']==args.episode and row['frame'] in frames:
                record=replay(row); records.append(record)
                print(json.dumps(record),flush=True)
    found={r['frame'] for r in records}
    if found!=frames:
        raise ValueError('Requested snapshots missing: '+str(sorted(frames-found)))
    report=dict(records=records,limitation='Same-observation, cold-start model re-solves only. '
        'No reconstruction of original warm starts; no CARLA closed-loop success/safety claim.')
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
