#!/usr/bin/env python3
"""Reproducible pilot: wiring smoke -> matched training -> frozen new-seed eval."""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[1]


def build_plan(output,train_episodes=50,eval_episodes=10,seeds=None,include_no_gate=False):
    seeds=[2,6,7] if seeds is None else list(seeds)
    learning=['L0_learning_v20','L1_efe_v20']+(['L2_no_gate_v20'] if include_no_gate else [])
    evaluation=['B5_rule_v18','M6_matrix_v18']+learning
    common=['--traffic-interaction','v17','--control-profile','paper_v11',
        '--soft-alpha','.1','--discount-half-life','10','--candidate-reward','task_efe',
        '--candidate-efe-weight','.1','--keep-going']
    specifications=[('00_smoke',5,[1],['M6_matrix_v18']+learning,'train'),
                    ('01_train',train_episodes,seeds,learning,'train'),
                    ('02_eval',eval_episodes,seeds,evaluation,'eval')]
    result=[]
    for name,episodes,replicas,arms,phase in specifications:
        arguments=common+['--episodes',str(episodes),'--seeds',','.join(map(str,replicas)),
            '--arms',','.join(arms),'--candidate-phase',phase,'--output-root',str(output/name)]
        if phase=='eval':
            arguments+=['--checkpoint-root',str(output/'01_train'),'--environment-seed-offset','2000']
        result.append(dict(name=name,episodes_total=episodes*len(replicas)*len(arms),arguments=arguments))
    return result


def collect_report(output,stages):
    report=dict(revision='candidate_learning_pilot_v20',stages=[],
        interpretation='Smoke and training are not pooled into evaluation. Zero takeovers is reported, not hidden.',
        confidence_guarantee=False,benefit_established=False)
    for stage in stages:
        path=output/stage['name']/'manifest.json'
        if not path.is_file():continue
        try:manifest=json.loads(path.read_text(encoding='utf8'))
        except (OSError,ValueError) as exc:
            report['stages'].append(dict(name=stage['name'],collection_ok=False,
                                        incomplete_manifest=str(exc),arms={}))
            continue
        arms={}
        for run in manifest['runs']:
            r=run.get('result',{})
            group=arms.setdefault(run['arm'],dict(episodes=0,outcomes={},takeovers=0,
                decisions=0,unseen_eval_decisions=0,max_local_episode_clusters=0))
            group['episodes']+=r.get('finished_episodes',0)
            for key,n in r.get('outcomes',{}).items():group['outcomes'][key]=group['outcomes'].get(key,0)+n
            group['takeovers']+=r.get('candidate_takeover_decisions',0)
            group['decisions']+=r.get('candidate_decisions',0)
            group['unseen_eval_decisions']+=r.get('candidate_unseen_eval_decisions',0)
            group['max_local_episode_clusters']=max(group['max_local_episode_clusters'],r.get('candidate_max_local_episode_clusters',0))
        report['stages'].append(dict(name=stage['name'],collection_ok=manifest['overall_success'],arms=arms))
    (output/'LEARNING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    return report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-episodes',type=int,default=50)
    parser.add_argument('--eval-episodes',type=int,default=10)
    parser.add_argument('--seeds',default='2,6,7')
    parser.add_argument('--include-no-gate',action='store_true')
    parser.add_argument('--output-root',type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args(argv)
    try:
        seeds=[int(s) for s in args.seeds.split(',')]
        if not seeds or len(set(seeds))!=len(seeds) or args.train_episodes<1 or args.eval_episodes<1:
            raise ValueError('Positive episodes and unique nonempty seed replicas required')
    except ValueError as exc:parser.error(str(exc))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_learning_v20_'+stamp)).resolve()
    stages=build_plan(output,args.train_episodes,args.eval_episodes,seeds,args.include_no_gate)
    if args.dry_run:
        for stage in stages:print(json.dumps(stage,ensure_ascii=False))
        return 0
    try:output.mkdir(parents=True,exist_ok=False)
    except FileExistsError:parser.error('Output already exists; use a new --output-root: '+str(output))
    status=1
    archive=Path(str(output)+'.tar.gz')
    workflow=dict(revision='learning_pilot_v20',planned_episodes=sum(s['episodes_total'] for s in stages),
        stages=stages,overall_success=None,
        note='Each training replica is evaluated at environment seed replica+2000. Public guard stays enabled.')
    (output/'WORKFLOW.json').write_text(json.dumps(workflow,indent=2),encoding='utf8')
    try:
        status=0
        for stage in stages:
            print('[%s] planned episodes=%d'%(stage['name'],stage['episodes_total']),flush=True)
            completed=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
            if completed.returncode:
                status=completed.returncode
                print('Collection/contract failure: retaining this stage and all earlier evidence.',flush=True)
                break
        report=collect_report(output,stages)
        if status==0 and any(s['collection_ok'] is not True for s in report['stages']):status=11
        if status==0:
            completed=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/summarize_matrix_comparison.py'),
                                      str(output/'02_eval')],cwd=str(ROOT))
            status=completed.returncode
        workflow['overall_success']=status==0
        (output/'WORKFLOW.json').write_text(json.dumps(workflow,indent=2),encoding='utf8')
    finally:
        # Exactly one archive; failures/partial runs remain part of the result.
        if not (output/'LEARNING_REPORT.json').exists():collect_report(output,stages)
        with tarfile.open(str(archive),'x:gz') as stream:
            stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__':raise SystemExit(main())
