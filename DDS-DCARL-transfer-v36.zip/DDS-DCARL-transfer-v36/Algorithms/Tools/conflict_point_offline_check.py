#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【离线验证】冲突点定义的三种口径对比（不启动 CARLA）。

要回答的问题
------------------------------------------------------------------
用户提出：不要"自己定一个点"，改成**实时计算几何最近点**作为冲突点。
本脚本用现有日志 + 参考路径几何，把三种口径放在同一批帧上对比：

  C1 = **现行**：固定冲突点 = 自车车头首次穿越交叉带北边缘
       （`define_state_space_turn.py::_find_conflict_point`），弧长 s1 ≈ 34.75 m
  C2 = **用户的**：把对手位置投影到自车参考路径，取投影点作为冲突点（随对手移动）
  C3 = **路径相交的扫掠区**：自车参考路径 ∩ 交叉车流车道中心线，取第一个交点
       （= 道路拓扑确定的"两条路径相交处"）

给用户看的四组数据
------------------------------------------------------------------
1. **稳定性**：三种口径的冲突点弧长随帧的变化（尤其**换车瞬间**是否阶跃）
2. **投影落点**：C2 的投影点落在哪里（会不会落到"尾段"）
3. **t_veh 抖动**：逐帧 t_veh 的一阶差分 |Δt_veh|（越小越稳）
4. **语义自检**：三种口径给出的冲突点与"车头进带时 ego_x≈4.19"的偏差

数据可用性（重要，先说清楚）
------------------------------------------------------------------
日志**只记录了一个**被分类的对手（`rv_id` / `rv_x` / `rv_v`），
**没有全部车辆的逐帧快照**（`n_vehicles` 只有计数）。
⇒ 凡是需要"所有车"的定义（C2/C3 的全局版）只能在这一辆车的数据上演示。
⇒ **要真正做"全部车"的分析，必须先在 `_approach_candidates` 处落盘逐车快照**
   （已在 `HANDOFF_2026-10-10.md` §4 S1 记过同类埋点问题）。

用法
----
  /home/liangde/miniconda3/envs/carla/bin/python Tools/conflict_point_offline_check.py
"""
from __future__ import annotations

import csv
import math
import os
import statistics as st
import sys

import numpy as np

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from Planning_library.gap_analysis import polyline_cumlen, project_point_on_polyline
from Planning_library.define_state_space_turn import _find_conflict_point

BASE = _HERE
PATH_PKL = os.path.join(BASE, 'expS82_gap_seed1', 'path_diag.pkl')
EGO_CSV = os.path.join(BASE, 'expFIX2_base20', 'interaction_ego.csv')
CROSS_Y = -138.0
#: 实测：车头跨过带北边缘时 ego_x 中位（60 回合）
BAND_ENTRY_X = 4.187


def _f(row, key):
    try:
        return float(row[key])
    except (KeyError, TypeError, ValueError):
        return None


def load_path():
    import pickle
    d = pickle.load(open(PATH_PKL, 'rb'))
    return np.asarray(d['static']['ref_path_array'], dtype=float)


def c1_fixed(path, cum):
    """现行口径：车头首次穿越带北边缘。"""
    ci, cx, s, mode = _find_conflict_point(path, CROSS_Y)
    return s, cx, mode


def c2_nearest_projection(path, cum, rv_x, rv_y=CROSS_Y):
    """用户口径：对手位置投影到自车路径的最近点。"""
    pr = project_point_on_polyline(path, rv_x, rv_y, cumlen=cum)
    return pr['s'], pr['lat']


def c3_path_crossing(path, cum, cross_y=CROSS_Y, band_half=1.0):
    """拓扑口径：自车路径 ∩ 交叉车流车道中心线，取**第一个**交点。

    与 C1 的区别：C1 锚在"车头进带"（含车身半长），C3 锚在**路径与车道中心线的交点**
    —— 完全不依赖车身尺寸，是纯道路拓扑量。
    """
    for i in range(1, len(path)):
        y0, y1 = float(path[i - 1][1]), float(path[i][1])
        if y0 > cross_y >= y1:                      # 向南穿越车道中心线
            t = 0.0 if y0 == y1 else (y0 - cross_y) / (y0 - y1)
            cx = float(path[i - 1][0] + t * (float(path[i][0]) - float(path[i - 1][0])))
            seglen = math.hypot(float(path[i][0]) - float(path[i - 1][0]),
                                float(path[i][1]) - float(path[i - 1][1]))
            return float(cum[i - 1] + t * seglen), cx
    return None, None


def main():
    path = load_path()
    cum = polyline_cumlen(path)
    s1, cx1, mode1 = c1_fixed(path, cum)
    s3, cx3 = c3_path_crossing(path, cum)

    print('=' * 84)
    print('【0】三种口径各自的冲突点（静态几何量）')
    print('=' * 84)
    print(f'  {"口径":<34}{"弧长 s (m)":<14}{"x (m)":<11}{"与实测 4.187 偏差"}')
    print(f'  {"C1 现行: 车头首次穿越带边缘":<34}{s1:<14.3f}{cx1:<11.3f}{cx1-BAND_ENTRY_X:+.3f}')
    if s3 is not None:
        print(f'  {"C3 拓扑: 路径∩车道中心线":<34}{s3:<14.3f}{cx3:<11.3f}{cx3-BAND_ENTRY_X:+.3f}')
    print(f'  {"实测基准: 车头进带时 ego_x 中位":<34}{"—":<14}{BAND_ENTRY_X:<11.3f}{0.0:+.3f}')
    print()
    print('  注：C1 与 C3 相差的就是"车身半长投影"（车头 vs 车身中心），')
    print('      这是有物理含义的差异，不是误差。')

    # ---------- 逐帧对比（C1 vs C2）----------
    rows = [r for r in csv.DictReader(open(EGO_CSV))]
    s2_seq, id_seq, v_seq, s1_seq = [], [], [], []
    for r in rows:
        rvx = _f(r, 'rv_x')
        if rvx is None:
            s2_seq.append(None); id_seq.append(None); v_seq.append(None); s1_seq.append(None)
            continue
        s2, lat2 = c2_nearest_projection(path, cum, rvx)
        s2_seq.append((s2, lat2))
        id_seq.append(r.get('rv_id'))
        v_seq.append(_f(r, 'rv_v'))
        s1_seq.append(s1)

    valid = [(a, b, c, d) for a, b, c, d in zip(s2_seq, id_seq, v_seq, s1_seq) if a is not None]
    print('=' * 84)
    print(f'【1】稳定性：冲突点弧长随帧变化（n={len(valid)} 个有对手的帧）')
    print('=' * 84)
    c1_vals = [s for _, _, _, s in valid]           # 固定 ⇒ 常数
    c2_vals = [a[0] for a, _, _, _ in valid]        # 投影 ⇒ 抖动
    print(f'  C1(固定)   弧长: 唯一值={len(set(round(x,3) for x in c1_vals))}，'
          f'极差={max(c1_vals)-min(c1_vals):.4f} m  ⇒ **恒定**')
    print(f'  C2(投影)   弧长: 极差={max(c2_vals)-min(c2_vals):.3f} m，'
          f'sd={st.stdev(c2_vals):.3f} m')
    print(f'  C2 投影的**横向偏差** lat: 中位={st.median([a[1] for a,_,_,_ in valid]):.2f} m, '
          f'最大={max(a[1] for a,_,_,_ in valid):.2f} m')
    print('  ⚠️ 横向偏差 >5 m 说明投影点**不在**交叉路口，而是落在了路径尾段 —— 见【2】')

    # 换车瞬间的阶跃
    print()
    print('=' * 84)
    print('【2】换车瞬间的阶跃（C2 的定义性问题）')
    print('=' * 84)
    jumps = []
    for i in range(1, len(valid)):
        if valid[i][1] != valid[i - 1][1]:
            jumps.append((i, valid[i - 1][1], valid[i][1],
                          c2_vals[i] - c2_vals[i - 1]))
    print(f'  检测到 {len(jumps)} 次换车；换车时 C2 弧长的阶跃：')
    if jumps:
        for i, a, b, d in jumps[:6]:
            print(f'    rv_id {a} -> {b}: 弧长阶跃 {d:+.2f} m')
        print(f'    阶跃绝对值: 中位={st.median([abs(x[3]) for x in jumps]):.2f} m, '
              f'最大={max(abs(x[3]) for x in jumps):.2f} m')
    print(f'  而 C1 在换车时阶跃 = 0（它是常数）')

    # 逐帧一阶差分（抖动）
    d1 = []; d2 = []
    for i in range(1, len(valid)):
        d1.append(abs(c1_vals[i] - c1_vals[i - 1]))
        d2.append(abs(c2_vals[i] - c2_vals[i - 1]))
    print()
    print(f'  逐帧一阶差分 |Δs|:  C1 中位={st.median(d1):.4f} m  C2 中位={st.median(d2):.4f} m')
    print(f'                        C1 p90={sorted(d1)[int(.9*len(d1))]:.4f} m  '
          f'C2 p90={sorted(d2)[int(.9*len(d2))]:.4f} m')

    print()
    print('=' * 84)
    print('【3】结论')
    print('=' * 84)
    print('  C1/C3 给出**道路拓扑唯一确定**的冲突点（常数），满足"通行权次序"的语义；')
    print('  C2 的投影点会落到路径尾段（横向偏差可达 %.1f m），且换车时阶跃可达 %.1f m。'
          % (max(a[1] for a, _, _, _ in valid), max(abs(x[3]) for x in jumps) if jumps else 0.0))
    print('  ⇒ 用户提议的"实时最近点"**不适合**做博弈层的冲突点；')
    print('     它适合做**安全层**的独立判据（见 HANDOFF §4 S6）。')
    print()
    print('  ⚠️ 本脚本只用了**一个**被分类对手（日志没有全车快照）。')
    print('     要做"全部车辆"的版本，必须先落盘逐车快照（t_veh_sorted 已有，但缺每车 x/v）。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
