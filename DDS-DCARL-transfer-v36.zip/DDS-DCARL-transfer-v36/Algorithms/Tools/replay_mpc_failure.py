#!/usr/bin/env python3
"""Replay a v8 JSON optimizer snapshot without CARLA; never overwrite the run."""
import argparse
from contextlib import redirect_stdout
import io
import json
import math
import os
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def replay(data):
    import casadi
    import numpy as np
    from Agent.game_theory.MPC import MPCController
    if data.get('format') != 'mpc_v8_failure_v1':
        raise ValueError('Expected a v8 JSON failure snapshot')
    x0 = data['x0']
    size = data['ego_size']
    ego = SimpleNamespace(x=x0['x'], y=x0['y'], yaw=x0['heading'], v=x0['v'],
        vx=x0['v']*math.cos(x0['heading']), vy=x0['v']*math.sin(x0['heading']),
        veh_id=-1, length=size[0], width=size[1])
    objects = [SimpleNamespace(**v) for v in data['observed_vehicles']]
    dynamic = SimpleNamespace(ego_vehicle=ego, objects=objects,
        lanes=[SimpleNamespace(front_vehicles=[], rear_vehicles=[])])
    controller = MPCController(data['N'], data['dt'], 2.7, .5,
        enable_lead_follow_cost=False, enable_boundary_thw=False,
        enable_cournot_cost=data['game_enabled'], cost_profile=data.get('cost_profile', 'paper_v8'),
        cournot_weights=tuple(data['game_weights']), cournot_thresholds=tuple(data['game_thresholds']),
        step_dts=data['step_dts'], vehicle_geometry=data['geometry'])
    controller.reset_global_path(data['path'], dynamic)
    controller.set_game_context(dict(observed_vehicles=objects), ego)
    controller.last_u = dict(data['previous'])
    if data.get('warm_previous') is not None:
        controller._warm_controls = np.asarray(data['warm_previous'], dtype=float)
    # Replaying may fail too; preserve the source snapshot and its experiment.
    previous_destination = os.environ.pop('DSH_SAVE_DIR', None)
    try:
        acceleration, steering = controller.solve(dynamic, data['target'], False)
    finally:
        if previous_destination is not None:
            os.environ['DSH_SAVE_DIR'] = previous_destination
    return dict(original_status=data['status'], replay_status=controller.last_solver_status,
        solve_ok=controller._solve_ok, acceleration=acceleration, physical_steering=steering,
        game_cost=controller.last_game_diag, casadi_version=casadi.__version__)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot', type=Path)
    args = parser.parse_args(argv)
    data = json.loads(args.snapshot.read_text(encoding='utf8'))
    stream = io.StringIO()
    with redirect_stdout(stream):
        result = replay(data)
    print(stream.getvalue(), end='', file=sys.stderr)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['solve_ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
