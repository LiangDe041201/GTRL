#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【卡死超时验证】卡死回合并未"无窗口"，是否只是超时太短？

背景（HANDOFF §27 + 本次实测）
------------------------------------------------------------------
密度扫描发现：密度把纯规则成功率从 71% 压到 23%，主要失效模式是**卡死**（2%→47%）。
但进一步检查发现：

  · 卡死判据 = 速度连续 <0.2 m/s 超过 `DSH_STUCK_SEC`（默认 **40 仿真秒**）
  · D 格车流**最后一辆车**通过冲突点 = 47.3 s，而卡死回合结束于 47.5 s
    ⇒ **计时器在最后一辆车通过的瞬间到期**
  · 而完成回合在车流走完后 **0.6 秒**就完成了
  · 卡死回合末帧仍有 RV 在冲突点附近（最近 2.7 m）⇒ 不是"路空不走"

⇒ 假说：**卡死主要是"超时设置 vs 车流时长"的竞赛结果**，而非真实的"无法插入"。

本实验：**只改 `DSH_STUCK_SEC` 40→90**，其余（密度、种子、配置）完全不变。

预先登记的判读
------------------------------------------------------------------
  · 成功率**大幅上升** ⇒ 卡死主因是**超时伪影** ⇒ 密度扫描的"规则退化"被高估，需重做
  · 成功率**基本不变** ⇒ 卡死是**真实"无法插入"** ⇒ 密度扫描结论成立，B 格是好测试床

用法： python Tools/analyze_stuck_timeout.py
"""
from __future__ import annotations

import collections
import csv
import math
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAIRS = [('D_D_ga8_gs6', 'S_D_long', '每8辆/6.0s'),
         ('D_B_ga3_gs6', 'S_B_long', '每3辆/6.0s')]
FPS = 20.3


def stats(run):
    p = os.path.join(_HERE, run, 'interaction_summary.csv')
    if not os.path.exists(p):
        return None
    s = [r for r in csv.DictReader(open(p)) if r.get('episode')]
    if not s:
        return None
    c = collections.Counter(r['outcome'] for r in s)
    n = sum(c.values())
    pr = c['complete'] / n
    L = []
    for r in s:
        for k in ('frames', 'steps', 'length'):
            v = r.get(k)
            if v not in (None, ''):
                try:
                    L.append(float(v)); break
                except ValueError:
                    pass
    return dict(n=n, comp=100 * pr, se=100 * math.sqrt(pr * (1 - pr) / n),
                coll=100 * c['collision'] / n, stuck=100 * c['stuck'] / n,
                len_med=(sorted(L)[len(L) // 2] if L else None))


def main():
    print('=' * 94)
    print('【卡死超时验证】只改 DSH_STUCK_SEC 40 → 90，其余完全不变')
    print('=' * 94)
    print(f"\n{'密度':<14}{'臂':<12}{'STUCK_SEC':<11}{'n':<6}{'成功%':<9}{'±95%CI':<9}"
          f"{'碰撞%':<9}{'卡死%':<9}{'回合长度中位'}")
    res = {}
    for base, long_, label in PAIRS:
        for run, thr in ((base, 40), (long_, 90)):
            st = stats(run)
            if st is None:
                print(f"{label:<14}{run:<12}{thr:<11}(无数据)")
                continue
            res[(label, thr)] = st
            lm = f"{st['len_med']:.0f}" if st['len_med'] else '—'
            print(f"{label:<14}{run:<12}{thr:<11}{st['n']:<6}{st['comp']:<9.1f}"
                  f"{1.96*st['se']:<9.1f}{st['coll']:<9.1f}{st['stuck']:<9.1f}{lm}")

    print('\n' + '=' * 94)
    print('【效应】超时放宽后成功率的变化')
    print('=' * 94)
    for base, long_, label in PAIRS:
        a, b = res.get((label, 40)), res.get((label, 90))
        if not a or not b:
            print(f'  {label}: 数据不全'); continue
        d = b['comp'] - a['comp']
        se = math.sqrt(a['se'] ** 2 + b['se'] ** 2)
        ci = 1.96 * se
        v = ('✅ 显著上升' if d - ci > 0 else ('❌ 显著下降' if d + ci < 0 else '⚠️ 不显著'))
        print(f"  {label:<14}成功 {a['comp']:.1f}% → {b['comp']:.1f}%  "
              f"Δ={d:+6.1f} pp (±{ci:.1f})  {v}")
        print(f"  {'':14}卡死 {a['stuck']:.1f}% → {b['stuck']:.1f}%   "
              f"碰撞 {a['coll']:.1f}% → {b['coll']:.1f}%")

    print('\n' + '=' * 94)
    print('【预先登记的判读】')
    print('=' * 94)
    conv = []
    for base, long_, label in PAIRS:
        a, b = res.get((label, 40)), res.get((label, 90))
        if a and b:
            conv.append(b['comp'] - a['comp'])
    if conv:
        m = sum(conv) / len(conv)
        if m >= 13:
            print(f'  ⇒ 成功率平均 +{m:.1f} pp（≥13pp 门槛）⇒ **卡死主要是超时伪影**')
            print('     ⇒ 密度扫描的"规则退化"被高估 ⇒ 需要重做密度实验（统一较长的超时）')
        elif m >= 5:
            print(f'  ⇒ 成功率平均 +{m:.1f} pp（未达 13pp 门槛）⇒ **部分伪影**，需更多回合分辨')
        else:
            print(f'  ⇒ 成功率平均 {m:+.1f} pp ⇒ **卡死是真实"无法插入"**')
            print('     ⇒ 密度扫描结论成立 ⇒ B 格是有效的创新点测试床')
    print('\n  ⚠️ 注意：本实验仍受"仿真跨运行不可复现"影响；但两臂密度/种子相同，')
    print('     唯一差异是超时阈值 ⇒ 差值可归因于它。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
