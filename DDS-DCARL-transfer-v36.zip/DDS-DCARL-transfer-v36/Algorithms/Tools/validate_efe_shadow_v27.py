"""Independent EFE math, evidence ownership and full-frame shadow audit.

Uses only saved inputs and standard-library arithmetic, never production EFE
math, a solver, simulator, map lookup or a deserialized legacy checkpoint.
"""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path


def _hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),
        allow_nan=False).encode('utf8')).hexdigest()


def _same(a,b):
    if isinstance(a,dict) and isinstance(b,dict):
        return a.keys()==b.keys() and all(_same(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
        return len(a)==len(b) and all(_same(x,y) for x,y in zip(a,b))
    if isinstance(a,(float,int)) and isinstance(b,(float,int)):
        return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,abs_tol=1.e-10,rel_tol=1.e-10)
    return a==b


def _score(z,b,p):
    """Reconstruct risk + conditional entropy without calling the runtime core."""
    if (not z or len(z)!=len(b) or len(p)!=4 or min(p)<=0. or not _same(sum(p),1.)
            or min(b)<0. or not _same(sum(b),1.) or any(len(r)!=4 or min(r)<0.
                or not _same(sum(r),1.) for r in z)):
        raise ValueError('Invalid saved probability model')
    ent=lambda r:-sum(v*math.log(v) for v in r if v>0.)
    q=[sum(w*r[i] for w,r in zip(b,z)) for i in range(4)]
    risk=sum(v*math.log(v/p[i]) for i,v in enumerate(q) if v>0.)
    ambiguity=sum(w*ent(r) for w,r in zip(b,z)); maximum=-math.log(min(p))
    return dict(risk=max(0.,risk),ambiguity=ambiguity,efe=max(0.,risk)+ambiguity,
        maximum_efe=maximum,normalized_efe=(max(0.,risk)+ambiguity)/maximum,
        marginal=q,conditional=z,belief=b,preference=p,marginal_entropy=ent(q),
        mutual_information=max(0.,ent(q)-ambiguity),preference_cross_entropy=-sum(v*math.log(t) for v,t in zip(q,p)))


def _distribution(part,context,meta):
    if not part.get('forecast_valid',False): return None,'invalid_forecast'
    if not part.get('forecasts'): return None,'missing_forecast_summaries'
    progress=min(float(v['progress_m']) for v in part['forecasts'])
    if not math.isfinite(progress): return None,'invalid_progress'
    gap=part.get('min_gap',part.get('gap')); gap=100. if gap is None else float(gap)
    if not math.isfinite(gap): return None,'invalid_gap'
    cdf=lambda x:.5*math.erfc(-x/math.sqrt(2.))
    blocked=cdf((meta['blocked_gap_m']-gap)/meta['gap_sigma_m'])
    tight=max(0.,cdf((meta['tight_gap_m']-gap)/meta['gap_sigma_m'])-blocked)
    clear=max(0.,1.-blocked-tight)
    stall=cdf((max(0.,context['standoff'])-progress)/meta['progress_sigma_m'])
    return [clear*(1.-stall),tight*(1.-stall),(clear+tight)*stall,blocked],None


def _candidate(parts,p,context,meta):
    if not p['active']: return None,'inactive'
    if parts is None or len(parts)!=2: return None,'missing_candidate_components'
    beta=context['beta']; actor=context['rv_id']
    if actor is None or beta.get('actor_id') is None: return None,'response_unidentified'
    if str(actor)!=str(beta['actor_id']): return None,'belief_actor_mismatch'
    a,b=float(beta['alpha']),float(beta['beta']); mean=float(beta['mean'])
    if not all(math.isfinite(v) for v in (a,b,mean)) or min(a,b)<1. or not _same(mean,a/(a+b)):
        return None,'invalid_response_belief'
    z=[]
    for part in parts:
        dist,reason=_distribution(part,context,meta)
        if reason: return None,reason
        z.append(dist)
    return _score(z,[1.-mean,mean],meta['preference']),None


def _request(c):
    return {k:c.get(k) for k in ('action','id','path_hash','plan_hash','prediction_hash','a','delta','target')}


def _controls_same(a,b):
    # Match the runtime's declared 1e-8 transport tolerance only here.
    # EFE arithmetic, rewards, command hashes and metadata stay stricter.
    return all(math.isclose(float(a[k]),float(b[k]),abs_tol=1.e-8,rel_tol=0.) for k in ('a','delta','target'))


def validate_shadow_record(row,meta):
    errors=Counter()
    try:
        p=row['rolling_trajectory']; s=p['efe_shadow']; sha=meta['model_sha256']
        if (s['status']!='ok' or s['revision']!=meta['revision'] or s['mode']!='shadow'
                or s['model_sha256']!=sha or s['calibrated'] is not False
                or s['reward_applied'] is not False): errors['shadow_mode_or_error']+=1
        for key in ('proposal_ms','feedback_ms'):
            if not math.isfinite(s[key]) or s[key]<0.: errors['timing']+=1
        context=dict(observation=p['observation'],previous=p['previous'],beta=p['beta'],
                     standoff=float(row['standoff']),rv_id=row.get('rv_id'))
        by={c['action']:c for c in p['candidates']}; scores={}
        if (len(s['candidates'])!=len(by) or len({c['action'] for c in s['candidates']})!=len(by)):
            errors['candidate_coverage']+=1
        for c in s['candidates']:
            original=by[c['action']]
            if c['request_id']!=original['id'] or c['path_hash']!=original['path_hash']:
                errors['candidate_owner']+=1
            parts=(None if row.get('components') is None else row['components'][row['selected']]) if c['action']==0 else original.get('components')
            identity=_hash(dict(model=sha,context=context,request=_request(original),components=parts))
            if c['input_signature']!=identity: errors['candidate_input_signature']+=1
            try: score,reason=_candidate(parts,p,context,meta)
            except (KeyError,ValueError,TypeError,IndexError,OverflowError): score,reason=None,'invalid_candidate_evidence'
            if c['available']!=(score is not None) or c['reason']!=reason or not _same(c['score'],score):
                errors['candidate_model_or_math']+=1
            scores[c['action']]=(score,reason)
        f=s['feedback']; request=p['request']; command=dict(a=row['applied_a'],delta=row['applied_delta'],target=row['applied_target'])
        if (f['episode']!=row['episode'] or f['frame']!=row['frame'] or f['owner_action']!=p['actual_action']
                or f['request_id']!=request['id'] or f['path_hash']!=request['path_hash']
                or f['model_sha256']!=sha or f['control_signature']!=_hash(command)
                or not _same(f['command'],command) or f['guard_action']!=row['guard_action']
                or f['guard_override']!=row['guard_override'] or row['control_submit_ok']!=1): errors['final_owner']+=1
        if f['reward_applied'] is not False or not _same(f['actual_task_reward'],p['feedback']['reward']):
            errors['reward_changed']+=1
        if f['dt']!=.05: errors['simulation_time']+=1
        expected=None; reason=None; source='unavailable'; original=by[p['actual_action']]
        # Mirror the documented actuator clamp, not its implementation function.
        a=max(-3.,min(2.,float(original['a'])))
        speed=float(context['observation']['ego']['v']); target=float(original['target'])
        if target<=.01: a=min(a,-min(3.,max(.3,speed*1.5)))
        else:
            if speed>target+.5 and a>0.: a=0.
            if speed>target+2.: a=min(a,-.8)
        unmodified=(not row['guard_override'] and row['guard_action']=='mpc'
                    and _controls_same(command,dict(a=a,delta=original['delta'],target=target)))
        if _request(original)!=_request(request): reason='request_changed_without_proposal'
        elif unmodified:
            expected,reason=scores[p['actual_action']]
            if expected is not None: source='candidate_prediction'
        else:
            evidence=f.get('evidence')
            if evidence is None: reason='unmatched_final_control'
            elif evidence['action']!=row['guard_action'] or not _controls_same(evidence,command):
                errors['guard_evidence_owner']+=1; reason='unmatched_final_control'
            else:
                dist,reason=_distribution(evidence,context,meta)
                if reason is None: expected=_score([dist],[1.],meta['preference']); source='guard_envelope'
        if (f['available']!=(expected is not None) or f['reason']!=reason or f['source']!=source
                or not _same(f['score'],expected)): errors['final_model_or_math']+=1
        cost=None if expected is None else expected['normalized_efe']*.05
        if not _same(f['cost_seconds'],cost): errors['cost_time_integral']+=1
        if expected is not None:
            identity=_hash(dict(model=sha,context=context,request=_request(request),command=command,
                source=source,conditional=f['score']['conditional']))
            if f['input_signature']!=identity: errors['final_input_signature']+=1
    except (KeyError,ValueError,TypeError,IndexError,OverflowError): errors['invalid_shadow_record']+=1
    return dict(errors)


def validate_efe_shadow(directory,ego_rows):
    root=Path(directory); errors=Counter(); counts=Counter(); reasons=Counter(); seen=set(); timings=[]
    expected={(str(r['episode']),str(r['frame'])) for r in ego_rows}
    try:
        meta=json.loads((root/'efe_shadow_metadata_v27.json').read_text(encoding='utf8'))
        plain={k:v for k,v in meta.items() if k not in ('model_sha256','learning_signature')}
        if (meta['model_sha256']!=_hash(plain) or meta['revision']!='rolling_efe_shadow_v27'
                or meta['mode']!='shadow' or meta['calibrated'] is not False or meta['reward_applied'] is not False
                or meta['additional_mpc_solves']!=0 or meta['additional_map_queries']!=0
                or meta['learning_signature']['reward']!='measured_task_v19_without_EFE'):
            errors['metadata_identity']+=1
        with (root/'matrix_decisions.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                try:
                    row=json.loads(line); key=(str(row['episode']),str(row['frame']))
                    if key in seen: errors['duplicate_frame']+=1
                    seen.add(key); counts['rows']+=1
                    errors.update(validate_shadow_record(row,meta))
                    s=row['rolling_trajectory']['efe_shadow']
                    counts['available_candidates']+=sum(c['available'] for c in s['candidates'])
                    counts['available_final_frames']+=s['feedback']['available']
                    for c in s['candidates']:
                        if not c['available']: reasons[c['reason']]+=1
                    timings.append(float(s['proposal_ms'])+float(s['feedback_ms']))
                except (ValueError,KeyError,TypeError,OverflowError): errors['invalid_json_or_fields']+=1
        if not seen or seen!=expected or len(expected)!=len(ego_rows): errors['frame_coverage']+=1
        if not counts['available_candidates'] or not counts['available_final_frames']: errors['no_valid_efe_evidence']+=1
    except (OSError,ValueError,KeyError,TypeError,OverflowError): errors['missing_or_invalid_shadow_files']+=1
    timings.sort()
    return dict(efe_shadow_contract_ok=not errors,efe_shadow_errors=dict(errors),efe_shadow_counts=dict(counts),
        efe_shadow_unavailable_reasons=dict(reasons),efe_shadow_p95_ms=timings[int(.95*(len(timings)-1))] if timings else None,
        efe_reward_enabled=False,efe_probability_calibrated=False,efe_benefit_established=False)
