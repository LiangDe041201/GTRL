#!/usr/bin/env python3
"""Run isolated CARLA checks for relay fixes, with full-frame log validation."""
import argparse
from collections import Counter, deque
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

if __package__:
    from .validate_belief_learning import validate_belief_learning
    from .validate_control_health import validate_control_health
    from .validate_traffic_spacing import validate_traffic_spacing
    from .validate_matrix_game import validate_matrix_game
    from .validate_entry_path_v15 import validate_entry_path
    from .validate_forecast_v16 import validate_forecast
else:
    from validate_belief_learning import validate_belief_learning
    from validate_control_health import validate_control_health
    from validate_traffic_spacing import validate_traffic_spacing
    from validate_matrix_game import validate_matrix_game
    from validate_entry_path_v15 import validate_entry_path
    from validate_forecast_v16 import validate_forecast

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
ARMS = {
    'B0_rule': {'DSH_METHOD': 'RULE', 'DSH_TAKE_COURNOT': '0'},
    'C1_cg': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1'},
    'M0_legacy_matrix': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1', 'DSH_COURNOT_MODE': 'matrix_legacy'},
    'M1_matrix': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1', 'DSH_COURNOT_MODE': 'matrix'},
    'M2_matrix_v14': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1', 'DSH_COURNOT_MODE': 'matrix_v14'},
    'B1_rule_minimal': {'DSH_METHOD': 'RULE', 'DSH_TAKE_COURNOT': '0',
                        'DSH_CONTROL_PATH': 'spatial_v15', 'DSH_ENTRY_POLICY': 'minimal'},
    'B2_rule_spatial': {'DSH_METHOD': 'RULE', 'DSH_TAKE_COURNOT': '0',
                       'DSH_CONTROL_PATH': 'spatial_v15'},
    'M3_matrix_spatial': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1',
                         'DSH_COURNOT_MODE': 'matrix_v14', 'DSH_CONTROL_PATH': 'spatial_v15'},
    'B3_rule_forecast': {'DSH_METHOD': 'RULE', 'DSH_TAKE_COURNOT': '0',
                         'DSH_CONTROL_PATH': 'spatial_v15', 'DSH_FORECAST_MODEL': 'route_v16'},
    'M4_matrix_forecast': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1',
                         'DSH_COURNOT_MODE': 'matrix_v16', 'DSH_CONTROL_PATH': 'spatial_v15',
                         'DSH_FORECAST_MODEL': 'route_v16'},
    'B4_rule_v17': {'DSH_METHOD': 'RULE', 'DSH_TAKE_COURNOT': '0',
                     'DSH_CONTROL_PATH': 'spatial_v15', 'DSH_FORECAST_MODEL': 'route_v17'},
    'M5_matrix_v17': {'DSH_METHOD': 'CG', 'DSH_TAKE_COURNOT': '1',
                     'DSH_COURNOT_MODE': 'matrix_v17', 'DSH_CONTROL_PATH': 'spatial_v15',
                     'DSH_FORECAST_MODEL': 'route_v17'},
    'B5_rule_v18': {'DSH_METHOD':'RULE','DSH_TAKE_COURNOT':'0',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18'},
    'M6_matrix_v18': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18'},
    'P0_observe_v21': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_PROBE':'observe'},
    'P1_defer_v21': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_PROBE':'defer'},
    'P2_proceed_v21': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_PROBE':'proceed'},
    'E0_observe_v22': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_EVOLUTION':'observe'},
    'E1_train_v22': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_EVOLUTION':'train'},
    'E2_eval_v22': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_TRAJECTORY_EVOLUTION':'eval'},
    'S0_observe_v23': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_SPATIAL_PROBE':'observe'},
    'S1_center_v23': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_SPATIAL_PROBE':'center'},
    'S2_plus_v23': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_SPATIAL_PROBE':'plus'},
    'S3_minus_v23': {'DSH_METHOD':'CG','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v18',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_SPATIAL_PROBE':'minus'},
    'L0_learning_v19': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v19',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'0','DSH_WCV_BCV':'1'},
    'L1_efe_v19': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v19',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'1','DSH_WCV_BCV':'1'},
    'L2_no_gate_v19': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v19',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'1',
                    'DSH_WCV_BCV':'0'},
    'L0_learning_v20': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v20',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'0','DSH_WCV_BCV':'1'},
    'L1_efe_v20': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v20',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'1','DSH_WCV_BCV':'1'},
    'L2_no_gate_v20': {'DSH_METHOD':'GTRL','DSH_TAKE_COURNOT':'1','DSH_COURNOT_MODE':'matrix_v20',
                    'DSH_CONTROL_PATH':'spatial_v15','DSH_FORECAST_MODEL':'route_v18','DSH_EFE':'1','DSH_WCV_BCV':'0'},
    'R0_fixed_base': {'DSH_EFE_ACTION_COUPLING': '0', 'DSH_MPC_BOUNDARY_MODE': 'legacy'},
    'R1_efe': {'DSH_EFE_ACTION_COUPLING': '1', 'DSH_MPC_BOUNDARY_MODE': 'legacy'},
    'R2_boundary': {'DSH_EFE_ACTION_COUPLING': '0', 'DSH_MPC_BOUNDARY_MODE': 'symbolic'},
    'R3_both': {'DSH_EFE_ACTION_COUPLING': '1', 'DSH_MPC_BOUNDARY_MODE': 'symbolic'},
    'G0_no_game': {'DSH_TAKE_COURNOT': '0'},
    'G1_mpc_game': {'DSH_TAKE_COURNOT': '1', 'DSH_COURNOT_MODE': 'mpc'},
}
for _rolling_arm, _rolling_phase in [('T0_observe_v24', 'observe'), ('T1_fixed_v24', 'fixed'),
                                     ('T2_train_v24', 'train'), ('T3_eval_v24', 'eval')]:
    ARMS[_rolling_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_rolling_phase)
ARMS['T4_efe_shadow_v27'] = dict(ARMS['T2_train_v24'], DSH_ROLLING_EFE_MODE='shadow')
for _cg_arm, _cg_phase in [('U0_cg_observe_v29','observe'), ('U1_cg_train_v29','train'),
                           ('U2_cg_eval_v29','eval')]:
    ARMS[_cg_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_cg_phase,
                        DSH_ROLLING_LEARNER='cg_v29')
for _long_arm, _long_phase in [('U3_long_train_v31','train'), ('U4_long_eval_v31','eval')]:
    ARMS[_long_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_long_phase,
                         DSH_ROLLING_LEARNER='longitudinal_v31')
for _joint_arm, _joint_phase in [('U5_joint_train_v32','train'), ('U6_joint_eval_v32','eval')]:
    ARMS[_joint_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_joint_phase,
                          DSH_ROLLING_LEARNER='joint_v32')
for _select_arm, _select_phase in [('U7_select_train_v33','train'), ('U8_select_eval_v33','eval')]:
    ARMS[_select_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_select_phase,
                           DSH_ROLLING_LEARNER='select_first_v33')
for _paired_arm, _paired_phase in [('U9_paired_train_v34','train'), ('U10_paired_eval_v34','eval')]:
    ARMS[_paired_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_paired_phase,
                           DSH_ROLLING_LEARNER='paired_v34')
for _entry_arm, _entry_phase in [('U11_entry_train_v35','train'), ('U12_entry_eval_v35','eval')]:
    ARMS[_entry_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_entry_phase,
                          DSH_ROLLING_LEARNER='entry_v35')
for _reward_arm, _reward_phase in [('U13_reward_train_v36','train'), ('U14_reward_eval_v36','eval')]:
    ARMS[_reward_arm] = dict(ARMS['M6_matrix_v18'], DSH_ROLLING_PHASE=_reward_phase,
                           DSH_ROLLING_LEARNER='reward_v36')
COMMON = {
    'DSH_ROLLING_LEARNER': 'legacy_v24',
    'DSH_METHOD': 'GTRL', 'DSH_ACTION_MODE': '2d', 'DSH_LAT_LEVELS': '3',
    'DSH_WCV_BCV': '1', 'DSH_EFE': '1', 'DSH_EFE_MODE': 'per_action',
    'DSH_EFE_VALUE_W': '1', 'DSH_EFE_R_W': '1', 'DSH_EFE_LATERAL': '1',
    'DSH_TAKE_COURNOT': '1', 'DSH_COURNOT_AUTHORITY': 'gate', 'DSH_SHIELD': '1',
    'DSH_PAPER_REWARD': '1', 'DSH_REWARD_RANGE': 'auto', 'DSH_ENV_TOL_SCALE': '1',
    'DSH_TERMINAL_SCALE': '10', 'DSH_GAMMA': '.98',
    'DSH_GAP_AFTER': '3', 'DSH_GAP_SEC': '11', 'DSH_STUCK_SEC': '90',
    'DSH_ILOG': '1', 'DSH_VIEW': '0',
    'DSH_TURN_COMPLETE_MODE': 'strict',
    'DSH_LEARNING_MODE': 'soft_belief', 'DSH_BELIEF_REWARD': 'task_ambiguity',
    'DSH_SOFT_ALPHA': '1.0', 'DSH_BASELINE_SUPPORT': '.05',
    'DSH_COURNOT_MODE': 'mpc', 'DSH_COURNOT_MPC_SAFETY': 'deficit',
    'DSH_CONTROL_PATH': 'legacy', 'DSH_ENTRY_POLICY': 'full',
    'DSH_FORECAST_MODEL': 'legacy', 'DSH_TRAFFIC_INTERACTION': 'legacy',
}


def effective_configuration(common, arm):
    config = dict(common, **ARMS[arm])
    if config.get('DSH_ROLLING_PHASE') != 'eval':
        config.pop('DSH_ROLLING_CHECKPOINT', None)
    else:
        config['DSH_ROLLING_EPSILON'] = '0'
    if config['DSH_METHOD'] != 'GTRL':
        config.update(DSH_EFE='0', DSH_WCV_BCV='0')
    if config['DSH_COURNOT_MODE'] in ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20') and config['DSH_TAKE_COURNOT'] == '1':
        config['DSH_COURNOT_AUTHORITY'] = 'matrix_entry'
    return config


def _read_rows(path):
    if not path.is_file():
        return []
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def _number(row, key):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def execution_target_interval(row):
    """Return the execution target and half a unit of its recorded precision.

    A threshold inside this rounding interval is ambiguous, not evidence of a
    contradictory command. Missing legacy actuator fields use the 3-dp v_ref.
    A present nonfinite actuator field is invalid and must not fall back.
    """
    if row.get('actuator_speed_target') not in (None, ''):
        return _number(row, 'actuator_speed_target'), .500001e-6
    return _number(row, 'v_ref'), .500001e-3


def summarize(directory, expected_episodes, returncode, learning_mode=None,
              expected_game=None, expected_method=None):
    episodes = _read_rows(directory / 'interaction_summary.csv')
    counts = Counter(row.get('outcome', 'unknown') for row in episodes)
    result = dict(returncode=returncode, finished_episodes=len(episodes),
                  expected_episodes=expected_episodes, outcomes=dict(counts),
                  complete=(returncode == 0 and len(episodes) == expected_episodes))
    ego_rows = takeover_rows = nonrl_rows = completion_reward_rows = 0
    strict_rows = legacy_rows = 0
    frame_keys = set()
    columns = set()
    residuals = []
    sources = Counter()
    geometry_sources, planning_statuses, guards = Counter(), Counter(), Counter()
    acceleration_sources = Counter()
    observed_acc_rows = predicted_acc_rows = 0
    limits = {'a_mpc': (-3., 2.), 'a_cmd': (-3., 2.),
              'delta_mpc_rad': (-1., 1.), 'steer': (-1., 1.)}
    violations = Counter()
    invalid_controls = stop_acceleration = planner_stop_motion = feedback_mismatch = 0
    stop_threshold_ambiguous = 0
    target_display_mismatch = 0
    previous_controls = {}
    game_controllers = Counter()
    game_enabled = game_active = game_nonzero = game_invalid = sg_active = 0
    game_residuals = []
    path = directory / 'interaction_ego.csv'
    if path.is_file():
        with path.open(newline='', encoding='utf-8-sig') as stream:
            reader = csv.DictReader(stream)
            columns = set(reader.fieldnames or [])
            for row in reader:
                ego_rows += 1
                frame_keys.add((row.get('episode'), row.get('frame')))
                takeover_rows += row.get('takeover') == '1'
                nonrl_rows += row.get('rl_active') == '0'
                completion_reward_rows += row.get('complete_fired') == '1'
                strict_rows += row.get('complete_strict') == '1'
                legacy_rows += row.get('complete_legacy') == '1'
                sources[row.get('decision_src', '')] += 1
                game_controllers[row.get('game_controller', '')] += 1
                game_enabled += row.get('mpc_game_enabled') == '1'
                game_active += row.get('mpc_game_active') == '1'
                sg_active += row.get('stackelberg_active') == '1'
                if row.get('mpc_game_enabled') in ('0', '1'):
                    costs = [_number(row, 'mpc_game_'+key+'_cost')
                             for key in ('speed', 'safety', 'comfort', 'total')]
                    valid = (all(v is not None and v >= -1e-6 for v in costs)
                             and abs(sum(costs[:3])-costs[3]) < 4e-6+1e-9*max(1., costs[3]))
                    if valid:
                        game_residuals.append(abs(sum(costs[:3])-costs[3]))
                        game_nonzero += costs[3] > 1e-6
                        valid = (row.get('mpc_game_active') == '1' or costs[3] <= 1e-6)
                    valid = valid and (row.get('mpc_game_active') != '1' or
                                      (row.get('mpc_game_enabled') == '1' and
                                       bool(row.get('mpc_game_rv_id') or row.get('mpc_game_fv_id')
                                            or row.get('mpc_game_participant_ids'))))
                    game_invalid += not valid
                elif expected_game is not None:
                    game_invalid += 1
                geometry_sources[row.get('mpc_geometry_source', '')] += 1
                acceleration_sources[row.get('rv_acc_source', '')] += 1
                observed_acc_rows += _number(row, 'rv_acc_observed') is not None
                predicted_acc_rows += _number(row, 'rv_acc_follow_pred') is not None
                planning_statuses[row.get('planning_status', '')] += 1
                guards.update(reason for reason in row.get('execution_guard_reason', '').split(';')
                              if reason)
                controls = {key: _number(row, key) for key in limits}
                target, target_rounding = execution_target_interval(row)
                previous = (_number(row, 'a_prev'), _number(row, 'steer_prev'))
                if any(value is None for value in list(controls.values()) + [target, _number(row, 'v_ref')] + list(previous)):
                    invalid_controls += 1
                for key, (lower, upper) in limits.items():
                    value = controls[key]
                    # CSV controls are rounded to three decimals.
                    if value is not None and not lower - .0011 <= value <= upper + .0011:
                        violations[key] += 1
                if target is not None:
                    displayed=_number(row,'v_ref')
                    if displayed is not None and row.get('actuator_speed_target') not in (None,''):
                        target_display_mismatch+=abs(target-displayed)>.500001e-3+target_rounding
                    stop_threshold_ambiguous += abs(target-.01) <= target_rounding
                    stop_acceleration += (target+target_rounding <= .01 and controls['a_cmd'] is not None
                                          and controls['a_cmd'] > .0011)
                    planner_stop_motion += row.get('trajectory_force_stop') == '1' and target-target_rounding > .01
                episode = row.get('episode')
                if episode in previous_controls and all(value is not None for value in previous):
                    feedback_mismatch += any(abs(a - b) > .0011 for a, b in
                                             zip(previous, previous_controls[episode]))
                if (controls['a_cmd'] is not None and controls['steer'] is not None and
                        (row.get('control_profile') not in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11') or _number(row, 'delta_rad') is not None)):
                    previous_controls[episode] = (controls['a_cmd'],
                        _number(row, 'delta_rad') if row.get('control_profile') in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11') else controls['steer'])
                try:
                    value = float(row.get('rew_resid', ''))
                    if math.isfinite(value):
                        residuals.append(abs(value))
                except (TypeError, ValueError):
                    continue
    with (directory / 'run.log').open(encoding='utf-8', errors='replace') as stream:
        result['mpc_fallback_log_lines'] = sum('求解失败 fallback' in line for line in stream)
    result.update(ego_log_rows=ego_rows, takeover_log_rows=takeover_rows,
                  decision_sources=dict(sources),
                  max_abs_reward_residual=max(residuals) if residuals else None)
    expected_rows = sum(int(row['frames']) for row in episodes)
    required = {'rl_active', 'complete_strict', 'complete_legacy', 'a_cmd', 'mpc_epsi',
                'planning_status', 'trajectory_force_stop', 'trajectory_speed_limit',
                'execution_guard_reason', 'v_ref_before_guard', 'goal_remaining',
                'rv_acc_observed', 'rv_acc_source', 'rv_acc_follow_pred', 'rv_acc_follow_source',
                'mpc_geometry_source', 'a_prev', 'steer_prev'}
    required.update(('game_controller', 'mpc_game_enabled', 'mpc_game_active',
                     'mpc_game_rv_id', 'mpc_game_fv_id', 'mpc_game_safety_mode',
                     'mpc_game_speed_cost', 'mpc_game_safety_cost', 'mpc_game_comfort_cost',
                     'mpc_game_total_cost', 'stackelberg_active'))
    missing_columns = sorted(required - columns)
    logs_complete = bool(expected_rows > 0 and ego_rows == expected_rows and
                         len(frame_keys) == ego_rows and not missing_columns)
    result.update(expected_ego_log_rows=expected_rows,
                  nonrl_log_rows=nonrl_rows,
                  completion_reward_log_rows=completion_reward_rows,
                  strict_complete_log_rows=strict_rows,
                  legacy_complete_log_rows=legacy_rows,
                  missing_log_columns=missing_columns, ego_log_complete=logs_complete)
    result['complete'] = result['complete'] and logs_complete
    result.update(mpc_geometry_sources=dict(geometry_sources),
                  rv_acc_sources=dict(acceleration_sources),
                  rv_acc_observed_rows=observed_acc_rows,
                  rv_acc_follow_prediction_rows=predicted_acc_rows,
                  planning_statuses=dict(planning_statuses), execution_guard_counts=dict(guards),
                  control_bound_violations=dict(violations), invalid_control_rows=invalid_controls,
                  stop_target_positive_acceleration_rows=stop_acceleration,
                  stop_threshold_ambiguous_rows=stop_threshold_ambiguous,
                  execution_target_display_mismatch_rows=target_display_mismatch,
                  planner_stop_positive_target_rows=planner_stop_motion,
                  applied_feedback_mismatch_rows=feedback_mismatch,
                  execution_contract_ok=bool(logs_complete and not (violations or invalid_controls or
                      stop_acceleration or planner_stop_motion or feedback_mismatch or target_display_mismatch)))
    if learning_mode == 'soft_belief':
        result.update(validate_belief_learning(directory))
    game_ok = bool(logs_complete and not game_invalid)
    if expected_game is True:
        game_ok = game_ok and game_enabled == ego_rows and game_active > 0 and game_nonzero > 0
    elif expected_game is False:
        game_ok = game_ok and game_enabled == game_active == game_nonzero == 0
    if expected_method in ('CG', 'GTRL', 'RULE'):
        game_ok = game_ok and sg_active == 0
    result.update(game_controllers=dict(game_controllers), mpc_game_enabled_rows=game_enabled,
                  mpc_game_active_rows=game_active, mpc_game_nonzero_cost_rows=game_nonzero,
                  mpc_game_invalid_rows=game_invalid, stackelberg_active_rows=sg_active,
                  max_game_cost_residual=max(game_residuals) if game_residuals else None,
                  game_contract_ok=bool(game_ok))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--episodes', type=int, default=3)
    parser.add_argument('--seeds', default='1', help='Comma-separated integer seeds')
    parser.add_argument('--environment-seed-offset', type=int, default=0,
                        help='Offset environment RNG seeds without changing checkpoint replica IDs')
    parser.add_argument('--arms', default='B0_rule,C1_cg', help='Comma-separated arm names')
    parser.add_argument('--control-profile', choices=('paper_v11', 'paper_v10', 'paper_v9', 'paper_v8', 'paper_v7', 'legacy'), default='paper_v11')
    parser.add_argument('--traffic', choices=('on', 'off'), default='on')
    parser.add_argument('--traffic-interaction', choices=('legacy', 'v17'), default='legacy')
    parser.add_argument('--traffic-clear-gap', type=float, default=5.)
    parser.add_argument('--traffic-flow-mode', choices=('legacy', 'continuous_v30'), default='legacy',
                        help='Continuous v30 removes platoon gaps and the total spawn cap')
    parser.add_argument('--traffic-cruise-speed', type=float)
    parser.add_argument('--method', choices=('GTRL', 'CG', 'SG', 'RULE'), default='GTRL')
    parser.add_argument('--game-mode', choices=('mpc', 'discrete', 'matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20'), default='mpc')
    parser.add_argument('--cournot-safety', choices=('deficit', 'eq24'), default='deficit')
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--keep-going', action='store_true', help='Collect all seeds/arms, then fail if any run failed checks')
    parser.add_argument('--probe-cruise-speed', type=float, help='Empty-road probe speed in [2,4] m/s')
    parser.add_argument('--learning-mode', choices=('soft_belief', 'mc_legacy'), default='soft_belief')
    parser.add_argument('--learning-reward', choices=('task_ambiguity', 'negative_efe'), default='task_ambiguity')
    parser.add_argument('--soft-alpha', type=float, default=1.)
    parser.add_argument('--baseline-support', type=float, default=.05)
    parser.add_argument('--candidate-phase', choices=('train','eval'), default='train')
    parser.add_argument('--checkpoint-root', type=Path, help='Training root with arm_seedN/candidate_model checkpoints')
    parser.add_argument('--discount-half-life', type=float, default=10., help='Simulation seconds, candidate branch only')
    parser.add_argument('--candidate-reward', choices=('task_efe','negative_efe'), default='task_efe')
    parser.add_argument('--candidate-efe-weight', type=float, default=.1)
    parser.add_argument('--candidate-epsilon', type=float, default=.3)
    parser.add_argument('--candidate-confidence-range',choices=('local_empirical','known_support'),
                        default='local_empirical')
    parser.add_argument('--belief-min-episodes', type=int, default=10)
    parser.add_argument('--evolution-checkpoint', type=Path, help='New-schema trajectory model JSON, not a v20 checkpoint')
    parser.add_argument('--rolling-checkpoint', type=Path, help='Frozen rolling trajectory model JSON with matching learner schema')
    parser.add_argument('--rolling-learner', choices=('legacy_v24','cg_v29','longitudinal_v31','joint_v32','select_first_v33','paired_v34','entry_v35','reward_v36'),
                        default='legacy_v24')
    parser.add_argument('--rolling-epsilon', type=float, default=.3)
    parser.add_argument('--rolling-efe-mode', choices=('off','shadow'), default='off',
                        help='Optional diagnostics only; no EFE reward or control modification')
    parser.add_argument('--road-audit', choices=('carla_v25','local_v26'), default='carla_v25',
                        help='Rolling proposals: legacy point API, or startup OpenDRIVE/local batch membership')
    parser.add_argument('--belief-model', type=Path, help='Optional declared likelihood/preference calibration JSON')
    parser.add_argument('--completion-mode', choices=('strict', 'legacy'), default='strict',
                        help='Use strict completion, or legacy only for comparison')
    args = parser.parse_args(argv)
    try:
        from Planning_library.traffic_spacing import FlowSpacing
        FlowSpacing(clear_gap=args.traffic_clear_gap, cruise_speed=args.traffic_cruise_speed)
        if args.traffic_flow_mode == 'continuous_v30' and (
                args.traffic != 'on' or args.traffic_interaction != 'v17'):
            raise ValueError('continuous_v30 requires traffic on and traffic-interaction v17')
        if args.probe_cruise_speed is not None and (args.traffic != 'off' or args.control_profile != 'paper_v11' or not 2. <= args.probe_cruise_speed <= 4.):
            raise ValueError('probe-cruise-speed requires empty-road paper_v11 and speed in [2,4]')
        seeds = [int(seed) for seed in args.seeds.split(',')]
        arms = args.arms.split(',')
        if args.traffic == 'off' and arms != ['B0_rule']:
            raise ValueError('Empty-road control check must use --arms B0_rule')
        if args.episodes < 1 or len(seeds) != len(set(seeds)) or len(arms) != len(set(arms)):
            raise ValueError('Episodes must be positive; seeds and arms must be unique')
        if any(arm not in ARMS for arm in arms):
            raise ValueError('Available arms: ' + ', '.join(ARMS))
        if not math.isfinite(args.soft_alpha) or args.soft_alpha <= 0. or not 0. < args.baseline_support <= 1.:
            raise ValueError('soft-alpha must be positive; baseline-support must be in (0,1]')
        if (not math.isfinite(args.discount_half_life) or args.discount_half_life<=0.
                or not math.isfinite(args.candidate_efe_weight) or args.candidate_efe_weight<0.
                or not 0.<=args.candidate_epsilon<=1. or not 0.<=args.rolling_epsilon<=1. or args.belief_min_episodes<2):
            raise ValueError('Invalid candidate discount/reward/exploration/coverage configuration')
    except ValueError as exc:
        parser.error(str(exc))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output = (args.output_root or ROOT / ('relay_validation_' + stamp)).resolve()
    plan = [(arm, seed, output / ('%s_seed%d' % (arm, seed))) for seed in seeds for arm in arms]
    common = dict(COMMON, DSH_LEARNING_MODE=args.learning_mode, DSH_BELIEF_REWARD=args.learning_reward,
                  DSH_SOFT_ALPHA=str(args.soft_alpha), DSH_BASELINE_SUPPORT=str(args.baseline_support),
                  DSH_METHOD=args.method, DSH_COURNOT_MODE=args.game_mode,
                  DSH_CONTROL_PROFILE=args.control_profile, DSH_TRAFFIC=args.traffic,
                  DSH_TRAFFIC_INTERACTION=args.traffic_interaction,
                  DSH_ROAD_AUDIT=args.road_audit,
                  DSH_ROLLING_EFE_MODE=args.rolling_efe_mode,
                  DSH_ROLLING_LEARNER=args.rolling_learner,
                  DSH_CONTROL_PROBE='1' if args.control_profile in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11') and args.traffic == 'off' else '0',
                  DSH_COURNOT_MPC_SAFETY=args.cournot_safety,
                  DSH_CANDIDATE_PHASE=args.candidate_phase,
                  DSH_DISCOUNT_HALF_LIFE=str(args.discount_half_life),
                  DSH_CANDIDATE_REWARD=args.candidate_reward,
                  DSH_CANDIDATE_EFE_WEIGHT=str(args.candidate_efe_weight),
                  DSH_CANDIDATE_EPSILON='0' if args.candidate_phase=='eval' else str(args.candidate_epsilon),
                  DSH_CANDIDATE_CONFIDENCE_RANGE=args.candidate_confidence_range,
                  DSH_BELIEF_MIN_EPISODES=str(args.belief_min_episodes))
    if args.belief_model is not None:
        if not args.belief_model.is_file():parser.error('Belief model JSON does not exist')
        common['DSH_CANDIDATE_BELIEF_MODEL']=str(args.belief_model.resolve())
    if args.control_profile in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
        if args.method == 'SG' or args.game_mode == 'discrete':
            parser.error('paper profiles require MPC tracking or matrix entry with MPC tracking')
        if args.cournot_safety != 'deficit':
            parser.error('paper profiles use relative-clearance safety; eq24 requires --control-profile legacy')
        common.update(DSH_SHIELD='0', DSH_LAT_LEVELS='tight')
    if args.probe_cruise_speed is not None:
        common['DSH_PROBE_CRUISE_SPEED'] = str(args.probe_cruise_speed)
    common['DSH_TRAFFIC_CLEAR_GAP'] = str(args.traffic_clear_gap)
    common['DSH_TRAFFIC_FLOW_MODE'] = args.traffic_flow_mode
    if args.traffic_flow_mode == 'continuous_v30':
        common['DSH_GAP_AFTER'] = '0'
    if args.evolution_checkpoint is not None:
        if not args.dry_run and not args.evolution_checkpoint.is_file():
            parser.error('Trajectory evolution checkpoint does not exist')
        common['DSH_EVOLUTION_CHECKPOINT'] = str(args.evolution_checkpoint.resolve())
    common['DSH_ROLLING_EPSILON'] = str(args.rolling_epsilon)
    if args.rolling_checkpoint is not None:
        if not args.dry_run and not args.rolling_checkpoint.is_file():
            parser.error('Rolling trajectory checkpoint does not exist')
        common['DSH_ROLLING_CHECKPOINT'] = str(args.rolling_checkpoint.resolve())
    if args.traffic_cruise_speed is not None:
        common['DSH_RV_CRUISE_SPEED'] = str(args.traffic_cruise_speed)
    if args.method != 'GTRL':
        common.update(DSH_WCV_BCV='0', DSH_EFE='0')
    if args.method in ('SG', 'RULE'):
        common['DSH_TAKE_COURNOT'] = '0'
    for arm, _, _ in plan:
        effective = effective_configuration(common, arm)
        if effective['DSH_ROLLING_LEARNER']!='legacy_v24' and effective['DSH_ROLLING_EFE_MODE']!='off':
            parser.error('CG/GTRL comparison requires EFE disabled')
        if effective['DSH_ROLLING_EFE_MODE'] == 'shadow' and not effective.get('DSH_ROLLING_PHASE'):
            parser.error('Rolling EFE shadow requires an explicit rolling trajectory owner')
        if effective.get('DSH_ROLLING_PHASE') and args.belief_min_episodes != 10:
            parser.error('v24 pilot fixes trust coverage at 10 independent episode clusters')
        if effective.get('DSH_ROLLING_PHASE') == 'eval' and args.rolling_checkpoint is None:
            parser.error('Frozen rolling evaluation requires --rolling-checkpoint')
        if effective.get('DSH_TRAJECTORY_EVOLUTION') and args.belief_min_episodes != 10:
            parser.error('v22 pilot fixes the trust coverage threshold at 10 episode clusters')
        if effective.get('DSH_TRAJECTORY_EVOLUTION') == 'eval' and args.evolution_checkpoint is None:
            parser.error('Frozen trajectory evaluation requires --evolution-checkpoint')
        candidate=effective['DSH_COURNOT_MODE'] in ('matrix_v19','matrix_v20')
        if candidate:
            if args.learning_mode!='soft_belief' or effective['DSH_METHOD']!='GTRL':
                parser.error('Candidate mode requires its single soft candidate learner')
            if args.candidate_reward=='negative_efe' and effective['DSH_EFE']!='1':
                parser.error('negative_efe requires EFE enabled; use task_efe for matched EFE ablation')
            if args.candidate_phase=='eval' and args.checkpoint_root is None:
                parser.error('Frozen candidate evaluation requires --checkpoint-root')
        from Planning_library.control_path_v15 import ControlExperimentV15
        try:
            ControlExperimentV15(effective['DSH_METHOD'], effective['DSH_COURNOT_MODE'] in
                ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20') and effective['DSH_TAKE_COURNOT']=='1',
                args.control_profile, effective['DSH_CONTROL_PATH'], effective['DSH_ENTRY_POLICY'],
                candidate_learning=candidate)
        except ValueError as exc:
            parser.error(str(exc))
        if effective['DSH_COURNOT_MODE'] in ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18') and (
                effective['DSH_METHOD'] not in ('RULE', 'CG') or args.control_profile != 'paper_v11'):
            parser.error('Matrix comparison requires RULE/CG and paper_v11')
        if effective['DSH_FORECAST_MODEL'] in ('route_v16','route_v17','route_v18') and (args.control_profile!='paper_v11'
                or effective['DSH_METHOD'] not in ('RULE','CG') and not candidate
                or effective['DSH_CONTROL_PATH']!='spatial_v15'):
            parser.error('route_v16 requires spatial_v15 RULE/CG with paper_v11')
        if effective['DSH_METHOD']=='CG' and effective['DSH_FORECAST_MODEL'] != {
                'matrix_v16':'route_v16', 'matrix_v17':'route_v17', 'matrix_v18':'route_v18'}.get(effective['DSH_COURNOT_MODE'], 'legacy'):
            parser.error('Matrix and common forecast revisions must match')
        if effective['DSH_FORECAST_MODEL'] in ('route_v17','route_v18') and args.traffic_interaction != 'v17':
            parser.error('v17 forecast comparison requires --traffic-interaction v17 for every arm')
        if candidate and (effective['DSH_FORECAST_MODEL']!='route_v18' or args.control_profile!='paper_v11'):
            parser.error('Candidate learning requires the frozen v18 forecast and paper_v11 actuator')
    checkpoints={}
    if args.candidate_phase=='eval':
        for arm,seed,_ in plan:
            if effective_configuration(common,arm)['DSH_COURNOT_MODE'] not in ('matrix_v19','matrix_v20'):continue
            path=args.checkpoint_root.resolve()/('%s_seed%d'%(arm,seed))/'candidate_model/belief_soft_model.json'
            if not args.dry_run and not path.is_file():parser.error('Missing trained checkpoint: '+str(path))
            checkpoints[(arm,seed)]=str(path)
    if args.dry_run:
        for arm, seed, directory in plan:
            print(json.dumps(dict(arm=arm, seed=seed, episodes=args.episodes,
                                  environment_seed=seed+args.environment_seed_offset,
                                  output=str(directory), common=common, overrides=ARMS[arm],
                                  effective=dict(effective_configuration(common, arm),
                                      **({'DSH_CANDIDATE_CHECKPOINT':checkpoints[(arm,seed)]}
                                         if (arm,seed) in checkpoints else {}))), ensure_ascii=False))
        return 0
    # Never reuse a training directory or delete an earlier experiment.
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error('Output already exists: %s. Choose a new --output-root (for example, add _retry1).'
                     % output)
    sources = [ROOT / 'train_dcarl_turn.py', ROOT / 'path_utils.py', Path(__file__).resolve()]
    for folder in ('Agent', 'Planning_library', 'Test_Scenarios', 'Tools'):
        sources.extend(sorted((ROOT / folder).rglob('*.py')))
    manifest = dict(revision='relay_rolling_v24' if any('DSH_ROLLING_PHASE' in ARMS[a] for a in arms) else
                            'relay_spatial_v23' if any('DSH_SPATIAL_PROBE' in ARMS[a] for a in arms)
                    else 'relay_evolution_v22' if any('DSH_TRAJECTORY_EVOLUTION' in ARMS[a] for a in arms)
                    else 'relay_trajectory_v21' if any('DSH_TRAJECTORY_PROBE' in ARMS[a] for a in arms)
                    else 'relay_learning_v20' if any(effective_configuration(common,a)['DSH_COURNOT_MODE']=='matrix_v20' for a in arms)
                    else 'relay_learning_v19' if any(effective_configuration(common,a)['DSH_COURNOT_MODE']=='matrix_v19' for a in arms)
                    else 'relay_prediction_v18', control_profile=args.control_profile,
                    traffic_revision='spacing_v12', evaluation_scope='exploratory_traffic' if args.traffic == 'on'
                    else 'empty_road_control_check', created_utc=stamp,
                    python=sys.executable, episodes=args.episodes,
                    common=common, environment_seed_offset=args.environment_seed_offset,
                    keep_going=args.keep_going, planned_runs=len(plan), overall_success=None, runs=[], source_sha256={
                        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in sources})
    manifest_path = output / 'manifest.json'
    failures = []
    for arm, seed, directory in plan:
        directory.mkdir()
        env = {key: value for key, value in os.environ.items() if not key.startswith('DSH_')}
        env.update(effective_configuration(common, arm))
        if (arm,seed) in checkpoints:env['DSH_CANDIDATE_CHECKPOINT']=checkpoints[(arm,seed)]
        env['DSH_TURN_COMPLETE_MODE'] = args.completion_mode
        env.update(DSH_SEED=str(seed+args.environment_seed_offset), DSH_EPISODES=str(args.episodes),
                   DSH_SAVE_DIR=str(directory), DSH_PLOT_DIR=str(directory / 'plots'))
        config = {key: value for key, value in env.items() if key.startswith('DSH_')}
        run = dict(arm=arm, seed=seed, environment_seed=seed+args.environment_seed_offset,
                   directory=str(directory), config=config, status='running')
        manifest['runs'].append(run)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        print('Running %s seed=%d; log=%s' % (arm, seed, directory / 'run.log'), flush=True)
        with (directory / 'run.log').open('w', encoding='utf-8') as log:
            process = subprocess.run([sys.executable, '-u', str(ROOT / 'train_dcarl_turn.py')],
                                     cwd=str(ROOT), env=env, stdout=log, stderr=subprocess.STDOUT)
        expected_game = (config['DSH_METHOD'] in ('CG', 'GTRL') and
                         config['DSH_TAKE_COURNOT'] == '1' and config['DSH_COURNOT_MODE'] == 'mpc')
        result = summarize(directory, args.episodes, process.returncode,
                           args.learning_mode if config['DSH_METHOD'] == 'GTRL' and config['DSH_COURNOT_MODE'] not in ('matrix_v19','matrix_v20') else None,
                           expected_game=expected_game, expected_method=config['DSH_METHOD'])
        if config['DSH_CONTROL_PROFILE'] in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
            rows = _read_rows(directory/'interaction_ego.csv')
            profiles = Counter(row.get('control_profile', '') for row in rows)
            phases = Counter(row.get('feasibility_phase', '') for row in rows)
            valid = bool(rows) and set(profiles) == {config['DSH_CONTROL_PROFILE']}
            valid = valid and all(row.get('feasibility_safe') in ('0', '1')
                and row.get('mpc_audit_override') in ('0', '1')
                and _number(row, 'mpc_prediction_horizon') == 2.3 for row in rows)
            if config['DSH_METHOD'] != 'GTRL':
                valid = valid and all(row.get('rl_active') == '0' for row in rows)
            solve_times = sorted(v for v in (_number(row, 'mpc_solve_ms') for row in rows)
                                 if v is not None)
            result.update(control_profiles=dict(profiles), feasibility_phases=dict(phases),
                          mpc_audit_override_rows=sum(row.get('mpc_audit_override') == '1' for row in rows),
                          stopped_seconds=.05*sum((_number(row, 'ego_v') or 0.) < .1 for row in rows),
                          mpc_solve_p95_ms=solve_times[int(.95*(len(solve_times)-1))] if solve_times else None,
                          profile_contract_ok=bool(valid))
        if config['DSH_CONTROL_PROFILE'] in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
            result.update(validate_control_health(rows, result['outcomes'], args.traffic,
                require_probe=config['DSH_CONTROL_PROBE'] == '1', profile=config['DSH_CONTROL_PROFILE'],
                probe_cruise_speed=args.probe_cruise_speed))
            lateral = sorted(abs(v) for v in (_number(r, 'mpc_l') for r in rows) if v is not None)
            warnings = []
            if result['severe_deceleration_rows']:
                warnings.append('severe_deceleration')
            if result['severe_acceleration_rows']:
                warnings.append('severe_acceleration')
            if lateral and lateral[-1] > .5:
                warnings.append('tracking_l_over_0_5')
            result.update(control_quality_warnings=warnings, tracking_l_max_abs=lateral[-1] if lateral else None,
                tracking_l_p95_abs=lateral[int(.95*(len(lateral)-1))] if lateral else None,
                evaluation_scope='exploratory_traffic' if args.traffic == 'on' else 'empty_road_control_check')
        if args.traffic == 'on' and config['DSH_CONTROL_PROFILE'] == 'paper_v11':
            result.update(validate_traffic_spacing(directory,
                interaction_revision=config['DSH_TRAFFIC_INTERACTION']))
        if config['DSH_COURNOT_MODE'] in ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18') and config['DSH_METHOD'] == 'CG':
            result.update(validate_matrix_game(directory, rows,
                {'matrix':'matrix_v13','matrix_legacy':'matrix_legacy','matrix_v14':'matrix_v14',
                 'matrix_v16':'matrix_v16','matrix_v17':'matrix_v17','matrix_v18':'matrix_v18'}[config['DSH_COURNOT_MODE']],
                 expected_probe=config.get('DSH_TRAJECTORY_PROBE'),
                 expected_evolution=config.get('DSH_TRAJECTORY_EVOLUTION'),
                 expected_spatial=config.get('DSH_SPATIAL_PROBE'),
                 expected_rolling=config.get('DSH_ROLLING_PHASE'),
                 expected_rolling_learner=config['DSH_ROLLING_LEARNER']))
        if config['DSH_CONTROL_PATH']=='spatial_v15':
            policy = 'matrix' if config['DSH_METHOD']=='CG' or config['DSH_COURNOT_MODE'] in ('matrix_v19','matrix_v20') else config['DSH_ENTRY_POLICY']
            result.update(validate_entry_path(directory, rows, policy,
                spatial_mode=config.get('DSH_SPATIAL_PROBE'),
                rolling_phase=config.get('DSH_ROLLING_PHASE')))
        if config['DSH_COURNOT_MODE'] in ('matrix_v19','matrix_v20'):
            from Tools.validate_candidate_learning_v19 import validate_candidate_learning
            result.update(validate_matrix_game(directory,rows,config['DSH_COURNOT_MODE']))
            result.update(validate_candidate_learning(directory,rows))
        if config['DSH_FORECAST_MODEL'] in ('route_v16','route_v17','route_v18'):
            result.update(validate_forecast(directory, rows, revision=config['DSH_FORECAST_MODEL']))
        if config['DSH_ROLLING_EFE_MODE'] == 'shadow':
            from Tools.validate_efe_shadow_v27 import validate_efe_shadow
            result.update(validate_efe_shadow(directory, rows))
        (directory / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        mechanisms_ok = result.get('learning_mechanisms_ok', True)
        status = ('incomplete' if not result['complete'] else
                  'profile_error' if not result.get('profile_contract_ok', True) else
                  'traffic_spacing_error' if not result.get('traffic_spacing_contract_ok', True) else
                  'control_health_error' if not (result.get('actuator_contract_ok', True) and result.get('empty_road_health_ok', True)) else
                  'execution_error' if not result['execution_contract_ok'] else
                  'entry_path_error' if not result.get('entry_path_contract_ok', True) else
                  'forecast_error' if not result.get('forecast_contract_ok', True) else
                  'efe_shadow_error' if not result.get('efe_shadow_contract_ok', True) else
                  'game_error' if not result['game_contract_ok'] or not result.get('matrix_contract_ok', True) else
                  'complete' if mechanisms_ok else 'learning_error')
        run.update(status=status, result=result)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False), flush=True)
        code = {'incomplete': 1, 'profile_error': 5, 'control_health_error': 6,
                'execution_error': 2, 'game_error': 4, 'learning_error': 3, 'traffic_spacing_error': 7,
                'entry_path_error': 9, 'forecast_error': 10, 'efe_shadow_error': 15}.get(status, 0)
        if code:
            failures.append(dict(arm=arm, seed=seed, status=status, exit_code=code))
            print('Run failed checks: %s seed=%d status=%s. Preserve all logs.' %
                  (arm, seed, status), file=sys.stderr)
            if status == 'incomplete':
                with (directory/'run.log').open(encoding='utf8', errors='replace') as log:
                    print('Last 40 log lines:\n'+''.join(deque(log, maxlen=40)), file=sys.stderr)
            if not args.keep_going:
                manifest.update(overall_success=False, failures=failures, collection_finished=False)
                manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
                return code
    manifest.update(overall_success=not failures, failures=failures, collection_finished=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    if failures:
        print('Collection finished with failed checks; following stages must not proceed.', file=sys.stderr)
        return failures[0]['exit_code']
    print('Finished: requested episodes and logs collected. Read outcomes/task_success_episodes for driving success; complete=true alone does not mean success.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
