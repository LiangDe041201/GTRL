"""Read-only actual-body/supply audit shared by CG and GTRL evaluation.

An unseen rear vehicle means unknown rear clearance. This audit does not use
learner-only observations, predicted future gaps, pickle, or CARLA APIs.
Primary driving outcomes/comfort/background metrics remain the v29 analysis.
"""
import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

REVISION = 'continuous_traffic_audit_v30'


def _number(row, key):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def _integer(row, key, minimum=0):
    value = _number(row, key)
    return int(value) if value is not None and value >= minimum and value == int(value) else None


def _boolean(value):
    if value is True or value in ('1', 'True', 'true', 1):
        return True
    if value is False or value in ('0', 'False', 'false', 0):
        return False
    return None


def _key(row):
    episode, frame = _integer(row, 'episode', 1), _integer(row, 'frame', 1)
    return None if episode is None or frame is None else (episode, frame)


def _box(row, ego=False):
    fields = (('ego_x', 'ego_y', 'ego_yaw', 'ego_length', 'ego_width') if ego
              else ('x', 'y', 'observed_yaw_rad', 'observed_length', 'observed_width'))
    values = [_number(row, name) for name in fields]
    if any(value is None for value in values) or min(values[3:]) <= 0.:
        return None
    x, y, yaw, length, width = values
    tangent = math.cos(yaw), math.sin(yaw)
    normal = -tangent[1], tangent[0]
    return dict(x=x, y=y, yaw=yaw, length=length, width=width,
        vertices=[(x+u*length/2*tangent[0]+v*width/2*normal[0],
                   y+u*length/2*tangent[1]+v*width/2*normal[1])
                  for u, v in ((-1, -1), (1, -1), (1, 1), (-1, 1))])


def _clip_y(polygon, bound, above):
    if not polygon:
        return []
    output = []
    first = polygon[-1]
    inside_first = first[1] >= bound if above else first[1] <= bound
    for second in polygon:
        inside_second = second[1] >= bound if above else second[1] <= bound
        if inside_first != inside_second:
            ratio = (bound-first[1])/(second[1]-first[1])
            output.append((first[0]+ratio*(second[0]-first[0]), bound))
        if inside_second:
            output.append(second)
        first, inside_first = second, inside_second
    return output


def _geometry(box, actors, band, conflict_x):
    clipped = _clip_y(_clip_y(box['vertices'], band[0], True), band[1], False)
    area = abs(sum(a[0]*b[1]-a[1]*b[0] for a, b in
                   zip(clipped, clipped[1:]+clipped[:1])))/2 if clipped else 0.
    overlap = area > 1.e-8
    low = min(point[0] for point in clipped) if overlap else None
    high = max(point[0] for point in clipped) if overlap else None
    center = (low+high)/2 if overlap else box['x']
    in_strip = [actor for actor in actors
                if min(point[1] for point in actor['box']['vertices']) < band[1]
                and max(point[1] for point in actor['box']['vertices']) > band[0]]
    front = [actor for actor in in_strip if actor['box']['x'] < center]
    rear = [actor for actor in in_strip if actor['box']['x'] >= center]
    front = max(front, key=lambda actor:actor['box']['x']) if front else None
    rear = min(rear, key=lambda actor:actor['box']['x']) if rear else None
    front_edge = max(point[0] for point in front['box']['vertices']) if front else None
    rear_edge = min(point[0] for point in rear['box']['vertices']) if rear else None
    angle = abs(math.atan2(math.sin(box['yaw']-math.pi), math.cos(box['yaw']-math.pi)))
    aligned = (overlap and band[0] <= box['y'] <= band[1]
               and max(point[0] for point in box['vertices']) < conflict_x
               and angle <= math.radians(10.))
    return dict(overlap=overlap, aligned_cleared=aligned, angle_to_flow_deg=math.degrees(angle),
        in_strip_span_m=high-low if overlap else None, front_actor_id=front['id'] if front else None,
        rear_actor_id=rear['id'] if rear else None,
        front_clearance_m=low-front_edge if overlap and front else None,
        rear_clearance_m=rear_edge-high if overlap and rear else None,
        witnessed_pair_gap_m=rear_edge-front_edge if front and rear else None)


def _minimum(values):
    values = [value for value in values if value is not None]
    return min(values) if values else None


def analyze_rows(ego_rows, traffic_rows, spawn_rows, flow_rows, metadata):
    """Classify observations, independently of whether the drive succeeded."""
    errors, episode_errors = Counter(), defaultdict(Counter)
    metadata_errors = Counter()
    mode = metadata.get('flow_mode')
    continuous = metadata.get('continuous_supply') is True
    limit = metadata.get('finite_spawn_limit')
    center = _number(metadata, 'flow_center_y')
    conflict_x = _number(metadata, 'conflict_x')
    dt = _number(metadata, 'expected_sample_dt')
    finite_limit = isinstance(limit, int) and not isinstance(limit, bool) and limit > 0
    if (metadata.get('flow_revision') != 'traffic_flow_v30'
            or mode not in ('continuous_v30', 'finite_v30') or center is None or conflict_x is None
            or dt is None or not math.isclose(dt, .05, rel_tol=0., abs_tol=1.e-12)):
        metadata_errors['flow_metadata'] += 1
    if mode == 'continuous_v30' and (not continuous or limit is not None
            or metadata.get('artificial_long_gaps_enabled') is not False):
        metadata_errors['continuous_supply_metadata'] += 1
    if mode == 'finite_v30' and (continuous or not finite_limit):
        metadata_errors['finite_supply_metadata'] += 1

    ego, events, actors, births = {}, {}, defaultdict(list), defaultdict(dict)
    episode_keys = defaultdict(list)
    for row in ego_rows:
        key = _key(row)
        if key is None:
            errors['ego_frame_key'] += 1
            continue
        ep, frame = key
        if key in ego:
            episode_errors[ep]['duplicate_ego_frame'] += 1
        box = _box(row, True)
        if box is None:
            episode_errors[ep]['ego_geometry'] += 1
        ego[key] = dict(row=row, box=box)
        episode_keys[ep].append(frame)
    for row in flow_rows:
        key = _key(row)
        if key is None:
            errors['flow_frame_key'] += 1
            continue
        if key in events:
            episode_errors[key[0]]['duplicate_flow_frame'] += 1
        events[key] = row
    for row in spawn_rows:
        if row.get('event') != 'spawned':
            continue
        key, actor = _key(row), str(row.get('actor_id', ''))
        if key is None or not actor:
            errors['spawn_record'] += 1
            continue
        if actor in births[key[0]]:
            episode_errors[key[0]]['duplicate_spawn_actor'] += 1
        births[key[0]][actor] = key[1]
        if continuous and row.get('interval_kind') == 'long':
            episode_errors[key[0]]['artificial_long_gap'] += 1
    for row in traffic_rows:
        key, actor = _key(row), str(row.get('actor_id', ''))
        if key is None or not actor:
            errors['traffic_frame_key'] += 1
            continue
        box = _box(row)
        if box is None or row.get('pose_source') != 'actor_snapshot':
            episode_errors[key[0]]['rv_geometry'] += 1
        if actor not in births[key[0]] or births[key[0]][actor] > key[1]:
            episode_errors[key[0]]['unobserved_spawn_actor'] += 1
        if any(value['id'] == actor for value in actors[key]):
            episode_errors[key[0]]['duplicate_traffic_actor_frame'] += 1
        actors[key].append(dict(id=actor, box=box))
    for key in set(events)-set(ego):
        episode_errors[key[0]]['flow_frame_coverage'] += 1
    for key in set(actors)-set(ego):
        episode_errors[key[0]]['traffic_frame_coverage'] += 1
    if not ego:
        errors['empty_ego'] += 1

    episodes = []
    for ep, frames in sorted(episode_keys.items()):
        local = episode_errors[ep]
        ordered = sorted(set(frames))
        if ordered != list(range(1, max(ordered)+1)):
            local['ego_frame_coverage'] += 1
        widths = [actor['box']['width'] for key, values in actors.items() if key[0] == ep
                  for actor in values if actor['box'] is not None]
        band = None if center is None or not widths else (center-max(widths)/2, center+max(widths)/2)
        active, observed = {}, {}
        supply_started = False
        for frame in ordered:
            key = ep, frame
            event = events.get(key)
            if event is None:
                local['flow_frame_coverage'] += 1
                continue
            supply = _boolean(event.get('supply_active'))
            count = _integer(event, 'observed_actor_count')
            spawned = _integer(event, 'spawned_count')
            if event.get('flow_mode') != mode or supply is None or spawned is None:
                local['flow_event_fields'] += 1
            if count is None or count != len(actors[key]):
                local['observed_actor_coverage'] += 1
            if spawned != sum(birth <= frame for birth in births[ep].values()):
                local['spawn_count_coverage'] += 1
            if continuous and supply_started and supply is False:
                local['continuous_supply_stopped'] += 1
            supply_started = supply_started or supply is True
            active[frame] = supply
            if band is not None and conflict_x is not None and ego[key]['box'] is not None and all(
                    actor['box'] is not None for actor in actors[key]):
                observed[frame] = _geometry(ego[key]['box'], actors[key], band, conflict_x)
        episode = dict(episode=ep, classification='indeterminate', reason='incomplete_common_source_evidence',
            first_overlap_frame=None, aligned_cleared_frame=None, insertion_duration_s=None,
            insertion_duration_lower_s=None, insertion_duration_upper_s=None,
            first_overlap_speed_mps=None, aligned_cleared_speed_mps=None,
            flow_body_strip_y=None if band is None else list(band),
            minimum_front_clearance_m=None, minimum_rear_clearance_m=None,
            minimum_witnessed_pair_gap_m=None, front_rear_witness_frames=0,
            front_rear_witness_at_alignment=False,
            supply_active_through_insertion=False, errors=dict(local))
        if not metadata_errors and not local and not errors:
            start = next((frame for frame in ordered if observed.get(frame, {}).get('overlap')), None)
            end = next((frame for frame in ordered if start is not None and frame >= start
                        and observed.get(frame, {}).get('aligned_cleared')), None)
            episode.update(first_overlap_frame=start, aligned_cleared_frame=end)
            if start is None:
                episode['reason'] = 'no_observed_body_overlap_with_flow_strip'
            elif end is None:
                episode['reason'] = 'terminated_before_observed_alignment_and_clearance'
            else:
                segment = [observed[frame] for frame in ordered if start <= frame <= end]
                witness = [value for value in segment if value['front_actor_id'] is not None
                           and value['rear_actor_id'] is not None]
                final_witness = (observed[end]['front_actor_id'] is not None
                                 and observed[end]['rear_actor_id'] is not None)
                active_through = all(active[frame] is True for frame in range(start, end+1))
                episode.update(insertion_duration_s=(end-start)*dt,
                    insertion_duration_lower_s=max(0., (end-start-1)*dt),
                    insertion_duration_upper_s=(end-start+1)*dt,
                    first_overlap_speed_mps=_number(ego[ep, start]['row'], 'ego_v'),
                    aligned_cleared_speed_mps=_number(ego[ep, end]['row'], 'ego_v'),
                    minimum_front_clearance_m=_minimum(value['front_clearance_m'] for value in segment),
                    minimum_rear_clearance_m=_minimum(value['rear_clearance_m'] for value in segment),
                    minimum_witnessed_pair_gap_m=_minimum(value['witnessed_pair_gap_m'] for value in witness),
                    front_rear_witness_frames=len(witness), front_rear_witness_at_alignment=final_witness,
                    supply_active_through_insertion=active_through)
                if continuous and active_through and final_witness:
                    episode.update(classification='in_flow_merge',
                                   reason='actual_front_rear_at_alignment_and_continued_supply_witness')
                elif (not continuous and finite_limit and len(births[ep]) == limit
                      and all(active[frame] is False for frame in range(start, end+1))
                      and all(birth <= start for birth in births[ep].values())
                      and any(value['front_actor_id'] is not None for value in segment)
                      and all(value['front_clearance_m'] is None or value['front_clearance_m'] >= 0.
                              for value in segment)
                      and all(value['rear_actor_id'] is None for value in segment)):
                    episode.update(classification='after_tail_merge', reason='finite_supply_exhausted_and_observed_tail_passed')
                elif not active_through:
                    episode['reason'] = 'supply_not_confirmed_active_through_insertion'
                else:
                    episode['reason'] = 'no_actual_front_rear_witness_rear_clearance_unknown'
        episodes.append(episode)
    errors.update(metadata_errors)
    for local in episode_errors.values():
        errors.update(local)
    return dict(continuous_traffic_revision=REVISION, continuous_traffic_contract_ok=not errors,
        continuous_traffic_errors=dict(errors),
        continuous_traffic_classification_counts=dict(Counter(value['classification'] for value in episodes)),
        continuous_traffic_episodes=episodes, continuous_traffic_mode=mode,
        continuous_traffic_note='Classification describes a physical insertion event, not whole-episode success, '
            'driving benefit or safety. A later collision/stuck outcome remains a failed drive. '
            'Unseen rear vehicles have unknown clearance. A complete run may remain indeterminate. '
            'Primary success/collision/stuck, waiting, comfort and background braking use the unchanged v29 metrics.',
        continuous_traffic_geometry_note='Ego and RV dimensions/yaw come from their common recorded snapshots. '
            'Entry is positive-area overlap with the observed westbound RV body-sweep strip; '
            'completion is center in that strip, heading within 10deg of west, and entire rear west of conflict_x. '
            'The strip is not a map lane boundary. Observed clipped-box x clearances are not future collision guarantees.')


def _rows(path):
    with path.open(newline='', encoding='utf-8-sig') as stream:
        return list(csv.DictReader(stream))


def validate_continuous_traffic(directory):
    """Read existing common logs only; no output files or model mutations."""
    directory = Path(directory)
    try:
        metadata = json.loads((directory/'traffic_spacing_metadata.json').read_text(encoding='utf8'))
        inputs = [_rows(directory/name) for name in ('interaction_ego.csv', 'traffic_spacing_samples.csv',
                  'traffic_spawns.csv', 'traffic_flow_events_v30.csv')]
        return analyze_rows(*(inputs+[metadata]))
    except (OSError, ValueError, KeyError, TypeError, csv.Error, OverflowError) as exc:
        return dict(continuous_traffic_revision=REVISION, continuous_traffic_contract_ok=False,
            continuous_traffic_errors={'missing_or_invalid_common_evidence':1},
            continuous_traffic_classification_counts={'indeterminate':1},
            continuous_traffic_episodes=[], continuous_traffic_error_detail=str(exc))


validate_directory = validate_continuous_traffic


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args(argv)
    report = validate_continuous_traffic(args.directory)
    print(json.dumps(report, ensure_ascii=False, allow_nan=False))
    return 0 if report['continuous_traffic_contract_ok'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
