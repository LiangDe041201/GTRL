#!/usr/bin/env python3
"""Twenty geometric pilot executions, no learning; always preserve failures."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile

if __package__:
    from .run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS
else:
    from run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS

ROOT = Path(__file__).resolve().parents[1]


def build_plan(output, probe_episodes=2):
    common = ['--method', 'CG', '--game-mode', 'matrix_v18', '--traffic', 'on',
        '--traffic-interaction', 'v17', '--control-profile', 'paper_v11', '--completion-mode', 'strict', '--keep-going']
    stages = []
    for name, episodes, seeds, arms in [
            ('00_smoke', 2, [60], ['M6_matrix_v18', 'S0_observe_v23']),
            ('01_probe', probe_episodes, [61, 62],
             ['S0_observe_v23', 'S1_center_v23', 'S2_plus_v23', 'S3_minus_v23'])]:
        stages.append(dict(name=name, episodes_per_run=episodes, seeds=seeds, arms=arms,
            episodes_total=episodes*len(seeds)*len(arms), arguments=common+[
                '--episodes', str(episodes), '--seeds', ','.join(map(str, seeds)),
                '--arms', ','.join(arms), '--output-root', str(output/name)]))
    return stages


def identity(output):
    try:
        data = [_rows(output/'00_smoke'/(arm+'_seed60')/'interaction_ego.csv')
                for arm in ('M6_matrix_v18', 'S0_observe_v23')]
        if any(not rows or any(any(r.get(k) in (None, '') for k in PHYSICAL_FIELDS) for r in rows) for rows in data):
            raise ValueError('Missing physical signature evidence')
        sig = [[tuple(r[k] for k in PHYSICAL_FIELDS) for r in rows] for rows in data]
        return dict(ok=sig[0] == sig[1], rows=[len(r) for r in data])
    except (OSError, KeyError, ValueError) as exc:
        return dict(ok=False, error=str(exc))


def collect_report(output, stages):
    reports = [_stage_report(output, stage) for stage in stages]
    for stage in reports:
        for arm, group in stage['arms'].items():
            group.pop('probe', None)
            counts, statuses = Counter(), Counter()
            available, missing = 0, 0
            planned = next(s for s in stages if s['name'] == stage['name'])
            for seed in planned['seeds']:
                file = output/stage['name']/('%s_seed%d' % (arm, seed))/'result.json'
                try:
                    data = json.loads(file.read_text(encoding='utf8'))
                    if arm.startswith('S'):
                        values = data['spatial_probe_counts']
                        if not isinstance(values.get('rows'), int):
                            raise ValueError('Missing spatial frame count')
                        counts.update(values)
                        statuses.update(data['spatial_probe_statuses'])
                        available += 1
                except (OSError, KeyError, ValueError, TypeError):
                    if arm.startswith('S'):
                        missing += 1
            group['spatial'] = dict(counts=counts, statuses=statuses, reported_runs=available, missing_runs=missing)
            if missing:
                stage['errors'].append(arm+': missing spatial mechanism statistics')
                stage['collection_ok'] = False
    report = dict(revision='spatial_pilot_v23', stages=reports, smoke_identity=identity(output),
        actual_episodes=sum(g['n'] for s in reports for g in s['arms'].values()),
        planned_episodes=sum(s['episodes_total'] for s in stages),
        collection_ok=False, benefit_established=False, learning_enabled=False, efe_enabled=False,
        note='CG intent/speed and public guard remain frozen. Compare center generator separately from lateral offsets. '
             'A geometric request is not a learned takeover. Map samples are not a safety proof.')
    report['collection_ok'] = report['smoke_identity']['ok'] and all(s['collection_ok'] for s in reports)
    report['all_episodes_successful'] = report['collection_ok'] and all(
        g['n'] == g['success'] for s in reports for g in s['arms'].values())
    formal = next(s for s in reports if s['name'] == '01_probe')['arms']
    comparisons = {}
    for treatment, baseline in [('S1_center_v23', 'S0_observe_v23'),
            ('S2_plus_v23', 'S0_observe_v23'), ('S3_minus_v23', 'S0_observe_v23'),
            ('S2_plus_v23', 'S1_center_v23'), ('S3_minus_v23', 'S1_center_v23')]:
        a = {(e['seed'], e['episode']): e for e in formal.get(treatment, {}).get('episodes', [])}
        b = {(e['seed'], e['episode']): e for e in formal.get(baseline, {}).get('episodes', [])}
        pairs = [dict(seed=k[0], episode=k[1], treatment_outcome=a[k]['outcome'], baseline_outcome=b[k]['outcome'],
                      seconds_delta=a[k]['seconds']-b[k]['seconds']) for k in sorted(set(a) & set(b))]
        comparisons[treatment+'_vs_'+baseline] = dict(pairs=pairs,
            mean_delta=statistics.mean(p['seconds_delta'] for p in pairs) if pairs else None)
    report['comparisons'] = comparisons
    (output/'SPATIAL_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = [report['note'], 'Executed %d/%d; collection=%s' %
             (report['actual_episodes'], report['planned_episodes'], report['collection_ok'])]
    for s in reports:
        for arm, g in s['arms'].items():
            lines.append('%s/%s: n=%d success=%d collision=%d stuck=%d mean_sim_s=%s spatial=%s' %
                (s['name'], arm, g['n'], g['success'], g['collisions'], g['stuck'],
                 g['mean_all_episode_s'], json.dumps(g['spatial'])))
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n', encoding='utf8')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe-episodes', type=int, default=2)
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    if args.probe_episodes < 1:
        parser.error('Probe episodes must be positive')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output = (args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_spatial_v23_'+stamp)).resolve()
    stages = build_plan(output, args.probe_episodes)
    if args.dry_run:
        for s in stages:
            print(json.dumps(s))
        return 0
    archive = Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():
        parser.error('Output or archive already exists; choose a new output-root')
    output.mkdir(parents=True)
    workflow = dict(revision='spatial_probe_v23', planned_episodes=sum(s['episodes_total'] for s in stages),
                    stages=stages, overall_success=None, learning_enabled=False)
    file = output/'WORKFLOW.json'
    status = 1
    try:
        for s in stages:
            s['status'] = 'running'
            file.write_text(json.dumps(workflow, indent=2), encoding='utf8')
            print('[%s] planned episodes=%d' % (s['name'], s['episodes_total']), flush=True)
            p = subprocess.run([sys.executable, '-u', str(ROOT/'Tools/run_relay_validation.py')]+s['arguments'], cwd=str(ROOT))
            s['returncode'] = p.returncode
            report = collect_report(output, stages)
            current = next(r for r in report['stages'] if r['name'] == s['name'])
            status = p.returncode or (11 if not current['collection_ok'] else 0)
            if s['name'] == '00_smoke' and not report['smoke_identity']['ok']:
                status = status or 12
            s['status'] = 'collected' if status == 0 else 'failed'
            if status:
                break
    except KeyboardInterrupt:
        status = 130; workflow['error'] = 'Interrupted; partial results preserved'
    except Exception as exc:
        status = 1; workflow['error'] = '%s: %s' % (type(exc).__name__, exc)
    finally:
        workflow.update(exit_code=status, overall_success=status == 0, finished_utc=datetime.now(timezone.utc).isoformat())
        file.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
        with tarfile.open(str(archive), 'w:gz') as stream:
            stream.add(str(output), arcname=output.name)
        print('Result folder: '+str(output), flush=True)
        print('Return this archive, including failed runs: '+str(archive), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
