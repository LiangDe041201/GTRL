#!/usr/bin/env python3
"""Train in continuous 8 m traffic, then compare CG with frozen CG+GTRL."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import tarfile
import time

if __package__:
    from .run_cg_learning_validation_v29 import _supplement
    from .run_trajectory_validation_v21 import _stage_report
    from .run_local_road_validation_v26 import inspect_runtime
else:
    from run_cg_learning_validation_v29 import _supplement
    from run_trajectory_validation_v21 import _stage_report
    from run_local_road_validation_v26 import inspect_runtime

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
CG_ARM, TRAIN_ARM, EVAL_ARM = 'M6_matrix_v18', 'U1_cg_train_v29', 'U2_cg_eval_v29'
REVISION = 'continuous_8m_training_and_frozen_comparison_v30'
LONGITUDINAL='longitudinal_v31'
JOINT='joint_v32'
SELECT_FIRST='select_first_v33'
PAIRED='paired_v34'
ENTRY='entry_v35'
REWARD='reward_v36'
LEARNER_ARMS={'cg_v29':(TRAIN_ARM,EVAL_ARM), LONGITUDINAL:('U3_long_train_v31','U4_long_eval_v31'),
              JOINT:('U5_joint_train_v32','U6_joint_eval_v32'),
              SELECT_FIRST:('U7_select_train_v33','U8_select_eval_v33'),
              PAIRED:('U9_paired_train_v34','U10_paired_eval_v34'),
              ENTRY:('U11_entry_train_v35','U12_entry_eval_v35'),
              REWARD:('U13_reward_train_v36','U14_reward_eval_v36')}


def experiment_revision(learner):
    return {LONGITUDINAL:'continuous_8m_longitudinal_comparison_v31',
            JOINT:'continuous_8m_joint_comparison_v32',
            SELECT_FIRST:'continuous_8m_select_first_v33',PAIRED:'continuous_8m_paired_v34',
            ENTRY:'continuous_8m_reversible_entry_v35',REWARD:'continuous_8m_task_time_reward_v36'}.get(learner,REVISION)


def scenario_configuration():
    """The shared scenario is explicit; inherited DSH variables cannot alter it."""
    return dict(DSH_TRAFFIC_FLOW_MODE='continuous_v30', DSH_TRAFFIC_CLEAR_GAP='8.0',
        DSH_GAP_AFTER='0', DSH_RV_CRUISE_SPEED='4.412022451715821', DSH_TRAFFIC='on',
        DSH_TRAFFIC_INTERACTION='v17', DSH_CONTROL_PROFILE='paper_v11',
        DSH_TURN_COMPLETE_MODE='strict', DSH_ROAD_AUDIT='local_v26',
        DSH_CONTROL_PATH='spatial_v15', DSH_COURNOT_MODE='matrix_v18',
        DSH_FORECAST_MODEL='route_v18', DSH_EFE='0', DSH_ROLLING_EFE_MODE='off')


def build_plan(output, train_episodes=150, eval_episodes=30, eval_seeds=None, train_seed=None, learner='cg_v29'):
    default_train_seed={LONGITUDINAL:301,JOINT:401,SELECT_FIRST:401,PAIRED:501,ENTRY:501,REWARD:501}.get(learner,201)
    default_seeds=range(default_train_seed+10,default_train_seed+15)
    seeds = list(default_seeds) if eval_seeds is None else list(eval_seeds)
    train_seed = default_train_seed if train_seed is None else train_seed
    if (min(train_episodes, eval_episodes) < 1 or not seeds
            or len(set(seeds)) != len(seeds) or train_seed in seeds):
        raise ValueError('Positive episode counts and unique evaluation seeds separate from training are required')
    output = Path(output)
    train_arm,eval_arm=LEARNER_ARMS[learner]
    checkpoint = output/'01_train'/('%s_seed%d' % (train_arm, train_seed))/'rolling_model/rolling_model.json'
    common = ['--method', 'CG', '--game-mode', 'matrix_v18', '--traffic', 'on',
        '--traffic-interaction', 'v17', '--control-profile', 'paper_v11',
        '--completion-mode', 'strict', '--keep-going', '--road-audit', 'local_v26',
        '--rolling-learner', learner, '--traffic-flow-mode', 'continuous_v30',
        '--traffic-clear-gap', '8.0', '--traffic-cruise-speed', '4.412022451715821']
    stages = []
    for name, episodes, stage_seeds, arms in (
            ('01_train', train_episodes, [train_seed], [train_arm]),
            ('02_eval', eval_episodes, seeds, [CG_ARM, eval_arm])):
        arguments = common+['--episodes', str(episodes), '--seeds', ','.join(map(str, stage_seeds)),
            '--arms', ','.join(arms), '--output-root', str(output/name)]
        if name == '02_eval':
            arguments += ['--rolling-checkpoint', str(checkpoint)]
        stages.append(dict(name=name, kind='carla', tool='run_relay_validation.py',
            episodes_per_run=episodes, seeds=stage_seeds, arms=arms,
            episodes_total=episodes*len(stage_seeds)*len(arms), arguments=arguments, learner=learner))
    return stages


def _json(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _checkpoint_paths(output, train):
    root = Path(output)/train['name']
    run = root/('%s_seed%d' % (train['arms'][0], train['seeds'][0]))
    return root, run, run/'rolling_model/rolling_model.json'


def validate_stage_manifest(manifest, stage, training_sources=None):
    runs = manifest.get('runs', [])
    expected = {(arm, seed) for seed in stage['seeds'] for arm in stage['arms']}
    actual = [(row.get('arm'), row.get('seed')) for row in runs]
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError('Actual arm/seed identities differ from the planned stage')
    if training_sources is not None and manifest.get('source_sha256') != training_sources:
        raise ValueError('Training and evaluation executable sources differ')
    learner=stage.get('learner','cg_v29')
    train_arm,eval_arm=LEARNER_ARMS[learner]
    for row in runs:
        config = row.get('config', {})
        if (any(config.get(key) != value for key, value in scenario_configuration().items())
                or row.get('environment_seed') != row['seed'] or config.get('DSH_SEED') != str(row['seed'])
                or config.get('DSH_ROLLING_LEARNER') != learner):
            raise ValueError('An actual runtime configuration differs from the shared continuous 8 m scene')
        phase = {train_arm:'train', eval_arm:'eval'}.get(row['arm'])
        if config.get('DSH_ROLLING_PHASE') != phase:
            raise ValueError('Actual learner phase differs from training/frozen evaluation plan')
        if phase == 'eval' and config.get('DSH_ROLLING_EPSILON') != '0':
            raise ValueError('Frozen evaluation cannot explore')
        if phase != 'eval' and config.get('DSH_ROLLING_CHECKPOINT'):
            raise ValueError('Only frozen evaluation may import a checkpoint')


def _training_evidence(output, train):
    root, run, checkpoint = _checkpoint_paths(output, train)
    manifest, result, model = _json(root/'manifest.json'), _json(run/'result.json'), _json(checkpoint)
    validate_stage_manifest(manifest, train)
    runs = manifest.get('runs', [])
    learner=train.get('learner','cg_v29')
    train_arm=LEARNER_ARMS[learner][0]
    if (train['arms'] != [train_arm] or len(train['seeds']) != 1 or len(runs) != 1
            or manifest.get('overall_success') is not True
            or manifest.get('collection_finished') is not True
            or manifest.get('episodes') != train['episodes_per_run']
            or runs[0].get('arm') != train_arm or runs[0].get('seed') != train['seeds'][0]
            or runs[0].get('environment_seed') != train['seeds'][0]
            or runs[0].get('status') != 'complete'
            or result.get('complete') is not True or result.get('ego_log_complete') is not True
            or result.get('finished_episodes') != train['episodes_per_run']
            or result.get('expected_episodes') != train['episodes_per_run']
            or any(value is False for key, value in result.items() if key.endswith('_contract_ok'))):
        raise ValueError('New-scene training must finish with complete real episode/log evidence')
    config = runs[0].get('config', {})
    if any(config.get(key) != value for key, value in scenario_configuration().items()):
        raise ValueError('Training scenario differs from the continuous 8 m contract')
    if (config.get('DSH_ROLLING_PHASE') != 'train' or config.get('DSH_ROLLING_LEARNER') != learner
            or config.get('DSH_SEED') != str(train['seeds'][0]) or config.get('DSH_ROLLING_CHECKPOINT')):
        raise ValueError('Expected new CG trajectory training without an imported old checkpoint')
    from Tools.validate_rolling_v24 import _signature
    if model.get('signature') != _signature(learner):
        raise ValueError('Checkpoint learner schema differs from the planned GTRL action space')
    records = model.get('records', [])
    return dict(revision=experiment_revision(learner), map='Town03', scenario=scenario_configuration(),
        random_key_revision='keyed_uniform_sha256_v30', checkpoint=checkpoint.relative_to(Path(output)).as_posix(),
        checkpoint_sha256=_hash(checkpoint), training_manifest_sha256=_hash(root/'manifest.json'),
        training_sources=manifest['source_sha256'], training_seed=train['seeds'][0],
        finished_training_episodes=result['finished_episodes'], learner_signature=model['signature'],
        real_transition_records=len(records),
        real_record_episode_coverage=len({row['episode'] for row in records}),
        independent_training_replicates=1)


def seal_checkpoint(output, train):
    evidence = _training_evidence(output, train)
    path = Path(output)/'SCENARIO_CHECKPOINT.json'
    with path.open('x', encoding='utf8') as stream:
        json.dump(evidence, stream, ensure_ascii=False, indent=2)
    return evidence


def verify_checkpoint(output, train):
    expected = _json(Path(output)/'SCENARIO_CHECKPOINT.json')
    actual = _training_evidence(output, train)
    if expected != actual:
        raise ValueError('Frozen model, completed training manifest or scenario evidence changed')
    return actual


def collect_report(output, stages):
    from Tools.validate_continuous_traffic_v30 import validate_continuous_traffic
    output = Path(output)
    learner=stages[0].get('learner','cg_v29')
    eval_arm=LEARNER_ARMS[learner][1]
    reports, traffic_runs, runtime_runs = [], [], []
    training_manifest = output/stages[0]['name']/'manifest.json'
    training_sources = _json(training_manifest).get('source_sha256') if training_manifest.is_file() else None
    for planned in stages:
        current = _stage_report(output, planned)
        manifest_path = output/planned['name']/'manifest.json'
        if manifest_path.is_file():
            try:
                validate_stage_manifest(_json(manifest_path), planned, training_sources)
            except (ValueError, KeyError, TypeError) as exc:
                current['collection_ok'] = False
                current['errors'].append(str(exc))
        reports.append(current)
        for arm, group in current['arms'].items():
            group.pop('probe', None)
            directories = [output/planned['name']/('%s_seed%d' % (arm, seed)) for seed in planned['seeds']]
            _supplement(group, directories)
            classes, counts, actions = Counter(), Counter(), Counter()
            insertion_episodes = {}
            for seed, directory in zip(planned['seeds'], directories):
                if not directory.exists():
                    continue
                traffic = validate_continuous_traffic(directory)
                traffic_runs.append(dict(stage=planned['name'], arm=arm, seed=seed, **traffic))
                classes.update(traffic.get('continuous_traffic_classification_counts', {}))
                for episode in traffic.get('continuous_traffic_episodes', []):
                    insertion_episodes[(seed, episode['episode'])] = episode
                if traffic.get('continuous_traffic_contract_ok') is not True:
                    current['collection_ok'] = False
                    current['errors'].append('%s seed%d: continuous-flow evidence failed' % (arm, seed))
                if arm.startswith('U'):
                    runtime = inspect_runtime(directory)
                    runtime_runs.append(dict(stage=planned['name'], arm=arm, seed=seed, **runtime))
                    if not runtime['ok']:
                        current['collection_ok'] = False
                        current['errors'].append('%s seed%d: learning geometry/timing evidence failed' % (arm, seed))
                    try:
                        result = _json(directory/'result.json')
                        if not isinstance(result['rolling_counts'].get('rows'), int):
                            raise ValueError('Missing rolling frame coverage')
                        for key,value in result['rolling_counts'].items():
                            if learner in (JOINT,SELECT_FIRST,PAIRED,ENTRY,REWARD) and (key in ('trained_states','covered_state_action_pairs',
                                    'max_state_action_episodes','paired_joint_states','joint_training_records',
                                    'paired_support_max','entry_creep_training_records',
                                    'entry_creep_paired_support_max') or key.startswith('paired_cells_ge_')):
                                counts[key]=max(counts[key],value)
                            else:
                                counts[key]+=value
                        actions.update(result['rolling_actual_actions'])
                    except (OSError, ValueError, TypeError, KeyError) as exc:
                        current['collection_ok'] = False
                        current['errors'].append('%s seed%d: %s' % (arm, seed, exc))
            group['insertion_classifications'] = dict(classes)
            for episode in group['episodes']:
                insertion = insertion_episodes.get((episode['seed'], episode['episode']), {})
                episode['insertion_classification'] = insertion.get('classification')
                for field in ('minimum_front_clearance_m', 'minimum_rear_clearance_m',
                              'minimum_witnessed_pair_gap_m', 'insertion_duration_s'):
                    episode[field] = insertion.get(field)
            group['task_successful_in_flow_merges'] = sum(episode['outcome'] == 'complete'
                and episode['insertion_classification'] == 'in_flow_merge' for episode in group['episodes'])
            group['task_successful_after_tail_merges'] = sum(episode['outcome'] == 'complete'
                and episode['insertion_classification'] == 'after_tail_merge' for episode in group['episodes'])
            if arm.startswith('U'):
                group['rolling'] = dict(counts=dict(counts), actual_actions=dict(actions))
    formal = next((stage for stage in reports if stage['name'] == '02_eval'), {})
    checkpoint_ok, checkpoint_error = None, None
    if (output/'02_eval/manifest.json').is_file():
        try:
            verify_checkpoint(output, stages[0])
            checkpoint_ok = True
        except (OSError, ValueError, TypeError, KeyError) as exc:
            checkpoint_ok, checkpoint_error = False, str(exc)
            formal['collection_ok'] = False
            formal['errors'].append('Frozen checkpoint evidence failed: '+str(exc))
    groups = formal.get('arms', {})
    baseline = {(row['seed'], row['episode']): row for row in groups.get(CG_ARM, {}).get('episodes', [])}
    learned = {(row['seed'], row['episode']): row for row in groups.get(eval_arm, {}).get('episodes', [])}
    fields = ('seconds', 'entry_wait_s', 'non_goal_stop_events', 'non_goal_stop_s',
        'guard_override_rows', 'minimum_predicted_guard_gap', 'measured_acceleration_rms',
        'measured_jerk_rms', 'background_harsh_braking_actor_s_per_100_actor_s',
        'minimum_front_clearance_m', 'minimum_rear_clearance_m', 'minimum_witnessed_pair_gap_m')
    pairs = []
    for key in sorted(set(baseline) & set(learned)):
        before, after = baseline[key], learned[key]
        pair = dict(seed=key[0], episode=key[1], baseline_outcome=before['outcome'], treatment_outcome=after['outcome'])
        pair.update(baseline_insertion=before.get('insertion_classification'),
                    treatment_insertion=after.get('insertion_classification'))
        for field in fields:
            a, b = after.get(field), before.get(field)
            pair[field+'_delta'] = a-b if a is not None and b is not None else None
        pairs.append(pair)
    frozen = groups.get(eval_arm, {}).get('rolling', {})
    report = dict(revision=experiment_revision(learner), planned_episodes=sum(stage['episodes_total'] for stage in stages),
        actual_episodes=sum(group['n'] for stage in reports for group in stage['arms'].values()),
        stages=reports, collection_ok=all(stage['collection_ok'] for stage in reports),
        continuous_traffic_runs=traffic_runs, runtime_audits=runtime_runs, efe_enabled=False,
        checkpoint_evidence_ok=checkpoint_ok, checkpoint_evidence_error=checkpoint_error,
        independent_training_replicates=1, benefit_established=False,
        frozen_takeover_requests=frozen.get('counts', {}).get('takeovers', 0),
        frozen_nonzero_action_frames=sum(count for action, count in frozen.get('actual_actions', {}).items()
                                         if str(action) != '0'),
        comparison=dict(baseline=CG_ARM, treatment=eval_arm, paired_episodes=len(pairs), pairs=pairs,
            baseline_unpaired=len(set(baseline)-set(learned)), treatment_unpaired=len(set(learned)-set(baseline)),
            mean_seconds_delta=statistics.mean(pair['seconds_delta'] for pair in pairs) if pairs else None),
        note='150 new training episodes precede 150 evaluation episodes per arm by default. '
             'Training and frozen evaluation are separate. Success/collision/stuck are primary; '
             'in-flow insertion, waiting, safety margins, comfort and background braking supplement them. '
             'Shared keyed exogenous randomness does not imply identical closed-loop traffic. '
             'Five evaluation seeds use one trained model, not five independent training replicas. '
             'No takeover or driving collision is itself a collection failure. Benefit is not presumed.')
    (output/'DENSE_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = [report['note'], 'CARLA episodes collected: %d/%d' % (report['actual_episodes'], report['planned_episodes'])]
    for stage in reports:
        for arm, group in stage['arms'].items():
            lines.append('%s/%s success=%d/%d collision=%d stuck=%d mean_s=%s insertion_events=%s task_successful_in_flow=%d' % (
                stage['name'], arm, group['success'], group['n'], group['collisions'], group['stuck'],
                group['mean_all_episode_s'], json.dumps(group['insertion_classifications']),
                group['task_successful_in_flow_merges']))
            lines.append('  wait_mean_s=%s stops_mean=%s guard_gap_min=%s acc_RMS=%s jerk_RMS=%s BG_harsh_per_100_actor_s=%s' % (
                group['mean_entry_wait_s'], group['mean_non_goal_stop_events'], group['minimum_predicted_guard_gap'],
                group['mean_measured_acceleration_rms'], group['mean_measured_jerk_rms'],
                group['background_braking']['harsh_braking_actor_s_per_100_actor_s']))
        lines.extend('ERROR %s: %s' % (stage['name'], error) for error in stage['errors'])
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n', encoding='utf8')
    return report


def _progress(stage_root,coverage_markers=None):
    try:
        running = [row for row in _json(stage_root/'manifest.json')['runs'] if row.get('status') == 'running']
        if not running:
            return 'waiting for the next run'
        row = running[-1]
        directory = stage_root/('%s_seed%d' % (row['arm'], row['seed']))
        completed = 0
        if (directory/'interaction_summary.csv').is_file():
            with (directory/'interaction_summary.csv').open(newline='', encoding='utf-8-sig') as stream:
                completed = sum(1 for _ in csv.DictReader(stream))
        path = directory/'interaction_ego.csv'
        size = path.stat().st_size if path.exists() else 0
        progress='%s seed=%s completed=%d ego_log_bytes=%d' % (row['arm'], row['seed'], completed, size)
        if coverage_markers is not None:
            due={n for n in (15,30,60,100,150) if n<=completed}-coverage_markers
            if due:
                from Tools.paired_coverage_v34 import paired_coverage
                try:
                    records=_json(directory/'rolling_model/rolling_model.json')['records']
                except (OSError,ValueError,KeyError):
                    return progress
                coverage_markers.update(due)
                progress+=' coverage='+json.dumps(paired_coverage(records),separators=(',',':'))
        return progress
    except (OSError, ValueError, KeyError, csv.Error):
        return 'waiting for readable run metadata'


def run_stage(stage, output, progress_seconds=30.):
    process = subprocess.Popen([sys.executable, '-u', str(ROOT/'Tools'/stage['tool'])]+stage['arguments'],
                               cwd=str(ROOT), start_new_session=os.name != 'nt')
    last_progress = time.monotonic()
    coverage_markers=set() if stage.get('learner') in (PAIRED,ENTRY,REWARD) and stage['name']=='01_train' else None
    try:
        while process.poll() is None:
            time.sleep(min(1., progress_seconds))
            now = time.monotonic()
            if now-last_progress >= progress_seconds:
                print('[progress %s] %s' % (stage['name'], _progress(Path(output)/stage['name'],coverage_markers)), flush=True)
                last_progress = now
        return process.returncode
    except BaseException:
        if process.poll() is None:
            if os.name != 'nt':
                os.killpg(process.pid, signal.SIGINT)
            else:
                process.terminate()
            try:
                process.wait(timeout=30.)
            except subprocess.TimeoutExpired:
                if os.name != 'nt':
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
                process.wait()
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-episodes', type=int, default=150)
    parser.add_argument('--train-seed', type=int)
    parser.add_argument('--eval-episodes', type=int, default=30, help='Per evaluation seed, per arm')
    parser.add_argument('--eval-seeds')
    parser.add_argument('--learner', choices=tuple(LEARNER_ARMS), default='cg_v29')
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--report-only', action='store_true', help='Recompute summaries of a returned result folder')
    args = parser.parse_args(argv)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    version={LONGITUDINAL:'v31',JOINT:'v32',SELECT_FIRST:'v33',PAIRED:'v34',ENTRY:'v35',REWARD:'v36'}.get(args.learner,'v30')
    output = (args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_dense_'+version+'_'+stamp)).resolve()
    try:
        seeds = None if args.eval_seeds is None else [int(value) for value in args.eval_seeds.split(',')]
        stages = build_plan(output, args.train_episodes, args.eval_episodes, seeds, args.train_seed,args.learner)
    except ValueError as exc:
        parser.error(str(exc))
    if args.dry_run:
        for stage in stages:
            print(json.dumps(stage, ensure_ascii=False))
        return 0
    if args.report_only:
        if args.output_root is None:
            parser.error('--report-only requires the existing --output-root')
        existing = _json(output/'WORKFLOW.json')
        report = collect_report(output, existing['stages'])
        print(json.dumps(dict(collection_ok=report['collection_ok'], actual_episodes=report['actual_episodes'])))
        return 0 if report['collection_ok'] else 11
    archive = Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():
        parser.error('Output/archive already exists; choose a new --output-root')
    output.mkdir(parents=True, exist_ok=False)
    state = output/'WORKFLOW.json'
    workflow = dict(revision=experiment_revision(args.learner), scenario=scenario_configuration(), stages=stages,
        planned_episodes=sum(stage['episodes_total'] for stage in stages),
        mode='new_scene_training_then_frozen_eval', efe_enabled=False, overall_success=None)
    status = 1
    try:
        for stage in stages:
            if stage['name'] == '02_eval':
                verify_checkpoint(output, stages[0])
            stage['status'] = 'running'
            state.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
            print('[%s] planned CARLA episodes=%d; total=%d' % (
                stage['name'], stage['episodes_total'], workflow['planned_episodes']), flush=True)
            stage['returncode'] = run_stage(stage, output)
            report = collect_report(output, stages)
            current = next(row for row in report['stages'] if row['name'] == stage['name'])
            if args.learner in (PAIRED,ENTRY,REWARD) and stage['name']=='01_train':
                counts=current['arms'].get(stage['arms'][0],{}).get('rolling',{}).get('counts',{})
                coverage={key:value for key,value in counts.items()
                          if key=='paired_support_max' or key.startswith(('paired_cells_ge_','entry_','reward_'))}
                if coverage: print('[training coverage] '+json.dumps(coverage),flush=True)
            status = stage['returncode'] or (11 if not current['collection_ok'] else 0)
            if not status:
                if stage['name'] == '01_train':
                    workflow['checkpoint_evidence'] = seal_checkpoint(output, stage)
                else:
                    verify_checkpoint(output, stages[0])
            stage['status'] = 'collected' if status == 0 else 'failed'
            if status:
                workflow['stop_reason'] = 'Collection/scenario/checkpoint evidence failed; partial logs retained'
                break
        if not status and not collect_report(output, stages)['collection_ok']:
            status = 11
    except KeyboardInterrupt:
        status = 130
        workflow['error'] = 'Interrupted; partial logs retained'
    except Exception as exc:
        status = 1
        workflow['error'] = '%s: %s' % (type(exc).__name__, exc)
    finally:
        workflow.update(exit_code=status, overall_success=status == 0,
                        finished_utc=datetime.now(timezone.utc).isoformat())
        state.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
        try:
            collect_report(output, stages)
        except Exception as exc:
            (output/'REPORT_ERROR.txt').write_text('%s: %s\n' % (type(exc).__name__, exc), encoding='utf8')
        with tarfile.open(str(archive), 'x:gz') as stream:
            stream.add(str(output), arcname=output.name)
        print('Result folder: '+str(output), flush=True)
        print('Return this archive, including failed runs: '+str(archive), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
