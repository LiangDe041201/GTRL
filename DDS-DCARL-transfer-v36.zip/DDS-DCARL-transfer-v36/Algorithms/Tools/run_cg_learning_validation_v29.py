#!/usr/bin/env python3
"""Compare unchanged CG with frozen GTRL; reuse real records or explicitly train."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile

if __package__:
    from .run_local_road_validation_v26 import inspect_runtime
    from .run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS
else:
    from run_local_road_validation_v26 import inspect_runtime
    from run_trajectory_validation_v21 import _stage_report, _rows, PHYSICAL_FIELDS

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REPLAY_SOURCE = ROOT.parent.parent / (
    'DDS-DCARL-results/relay_local_road_v26_20261105T104202_788603Z/'
    '02_train/T2_train_v24_seed73/rolling_model/rolling_model.json')
CG_ARM = 'M6_matrix_v18'
OBSERVE_ARM = 'U0_cg_observe_v29'
TRAIN_ARM = 'U1_cg_train_v29'
EVAL_ARM = 'U2_cg_eval_v29'


def build_plan(output, replay_source=None, fresh_train=False, train_episodes=100,
               eval_episodes=10, eval_seeds=None, smoke_episodes=2):
    """Episode counts describe CARLA runs; rebuilding old records adds zero."""
    output = Path(output)
    eval_seeds = [121, 122, 123] if eval_seeds is None else list(eval_seeds)
    if fresh_train and replay_source is not None:
        raise ValueError('Choose offline replay or fresh training, not both')
    common = ['--method', 'CG', '--game-mode', 'matrix_v18', '--traffic', 'on',
        '--traffic-interaction', 'v17', '--control-profile', 'paper_v11',
        '--completion-mode', 'strict', '--keep-going', '--road-audit', 'local_v26',
        '--rolling-learner', 'cg_v29']

    def carla_stage(name, episodes, seeds, arms, checkpoint=None):
        arguments = common + ['--episodes', str(episodes), '--seeds', ','.join(map(str, seeds)),
            '--arms', ','.join(arms), '--output-root', str(output/name)]
        if checkpoint is not None:
            arguments += ['--rolling-checkpoint', str(checkpoint)]
        return dict(name=name, kind='carla', tool='run_relay_validation.py',
            episodes_per_run=episodes, seeds=seeds, arms=arms,
            episodes_total=episodes*len(seeds)*len(arms), arguments=arguments)

    stages = [carla_stage('00_smoke', smoke_episodes, [110], [CG_ARM, OBSERVE_ARM])]
    if fresh_train:
        checkpoint = output/'01_train'/('%s_seed111' % TRAIN_ARM)/'rolling_model/rolling_model.json'
        stages.append(carla_stage('01_train', train_episodes, [111], [TRAIN_ARM]))
    else:
        source = DEFAULT_REPLAY_SOURCE if replay_source is None else Path(replay_source)
        checkpoint = output/'01_rebuild/rolling_model/rolling_model.json'
        audit = output/'01_rebuild/rebuild_audit.json'
        stages.append(dict(name='01_rebuild', kind='offline_rebuild', tool='rebuild_cg_learning_v29.py',
            episodes_per_run=0, seeds=[], arms=[], episodes_total=0,
            source=str(source), checkpoint=str(checkpoint), audit=str(audit),
            arguments=[str(source), '--output', str(checkpoint), '--audit', str(audit)]))
    stages.append(carla_stage('02_eval', eval_episodes, eval_seeds, [CG_ARM, EVAL_ARM], checkpoint))
    return stages


def identity(output, stage):
    """Use the configured observation arm/seed, never a historical pilot name."""
    try:
        comparisons = []
        for seed in stage['seeds']:
            data = [_rows(Path(output)/stage['name']/('%s_seed%d' % (arm, seed))/'interaction_ego.csv')
                    for arm in (CG_ARM, OBSERVE_ARM)]
            if any(not rows or any(any(row.get(key) in (None, '') for key in PHYSICAL_FIELDS)
                                   for row in rows) for rows in data):
                raise ValueError('Missing required physical signature')
            signatures = [[tuple(row[key] for key in PHYSICAL_FIELDS) for row in rows] for rows in data]
            comparisons.append(dict(seed=seed, ok=signatures[0] == signatures[1],
                baseline_rows=len(data[0]), observe_rows=len(data[1])))
        return dict(ok=bool(comparisons) and all(row['ok'] for row in comparisons),
            comparisons=comparisons, baseline=CG_ARM, observed=OBSERVE_ARM,
            reason='compare_identical_recorded_physical_fields')
    except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        return dict(ok=False, error=str(exc), baseline=CG_ARM, observed=OBSERVE_ARM)


def _offline_report(stage):
    result = dict(name=stage['name'], planned_episodes=0, collection_ok=False, arms={}, errors=[])
    try:
        value = json.loads(Path(stage['audit']).read_text(encoding='utf8'))
        if not isinstance(value, dict) or not value:
            raise ValueError('Rebuild audit must be a nonempty object')
        source_raw = Path(stage['source']).read_bytes()
        output_raw = Path(stage['checkpoint']).read_bytes()
        source, model = json.loads(source_raw.decode('utf8')), json.loads(output_raw.decode('utf8'))
        from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
        expected_signature = CGTrajectoryLearnerV29().signature()
        if (value['source_unchanged'] is not True
                or value['source_sha256'] != hashlib.sha256(source_raw).hexdigest()
                or value['output_sha256'] != hashlib.sha256(output_raw).hexdigest()
                or value['source_signature'] != source['signature']
                or value['output_signature'] != expected_signature
                or model['signature'] != expected_signature):
            raise ValueError('Rebuilt signature/source/output identity failed')
        records = source['records']
        count_expectations = dict(real_state_count=len(source['nodes']), real_transition_records=len(records),
            real_episode_count=len({record['episode'] for record in records}), synthetic_transition_records=0,
            new_CARLA_episodes=0, merged_state_count=0, minimum_independent_episodes=10)
        if any(type(value[key]) is not int or value[key] != expected
               for key, expected in count_expectations.items()):
            raise ValueError('Rebuild changed real coverage or introduced synthetic evidence')
        records_raw = json.dumps(records, ensure_ascii=False, allow_nan=False,
                                 separators=(',', ':')).encode('utf8')
        if (model['records'] != records or set(model['nodes']) != set(source['nodes'])
                or value['records_sha256'] != hashlib.sha256(records_raw).hexdigest()
                or value['old_q_discarded'] is not True or value['old_reference_discarded'] is not True):
            raise ValueError('Actual records/state partition/old-value discard audit failed')
        residual = value['bellman_residual']
        if (value['bellman_converged'] is not True or isinstance(residual, bool)
                or not isinstance(residual, (int, float)) or not math.isfinite(residual)
                or not 0. <= residual <= 1.e-7):
            raise ValueError('Rebuilt empirical Bellman values did not converge to residual <=1e-7')
        result['audit'] = value
        result['collection_ok'] = stage.get('returncode') == 0
        if not result['collection_ok']:
            result['errors'].append('Offline rebuild did not finish successfully')
    except (OSError, ValueError, TypeError, KeyError, OverflowError) as exc:
        result['errors'].append(str(exc))
    return result


def _number(row, key):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None


def _supplement(group, directories):
    """Supplement primary outcomes; absence stays missing rather than zero."""
    episodes = group['episodes']
    for episode in episodes:
        episode.update(measured_acceleration_rms=None, measured_jerk_rms=None,
            measured_motion_rows=0, measured_acceleration_missing_rows=None,
            background_sample_actor_s=None, background_commanded_braking_actor_s=None,
            background_commanded_harsh_braking_actor_s=None,
            background_harsh_braking_actor_time_ratio=None,
            background_harsh_braking_actor_s_per_100_actor_s=None)
    background, missing = [], 0
    for directory in directories:
        seed = int(directory.name.rsplit('_seed', 1)[-1])
        selected_episodes = [episode for episode in episodes if episode['seed'] == seed]
        try:
            rows = _rows(directory/'interaction_ego.csv')
            for episode in selected_episodes:
                selected = [row for row in rows if str(row['episode']) == str(episode['episode'])]
                values = [_number(row, 'ego_acc_measured') for row in selected]
                missing_values = sum(value is None for value in values)
                episode.update(measured_motion_rows=len(values),
                               measured_acceleration_missing_rows=missing_values)
                if values and not missing_values:
                    episode['measured_acceleration_rms'] = math.sqrt(statistics.mean(value**2 for value in values))
                    if len(values) > 1:
                        episode['measured_jerk_rms'] = math.sqrt(statistics.mean(
                            ((after-before)/.05)**2 for before, after in zip(values, values[1:])))
        except (OSError, ValueError, KeyError, csv.Error):
            pass
        try:
            rows = _rows(directory/'traffic_spacing_samples.csv')
            values = [_number(row, 'commanded_acceleration') for row in rows]
            if not rows or any(value is None for value in values):
                raise ValueError('Missing background command acceleration')
            background.extend(values)
            for episode in selected_episodes:
                samples = [_number(row, 'commanded_acceleration') for row in rows
                           if row.get('episode') == str(episode['episode'])]
                if samples:
                    harsh = sum(value < -3. for value in samples)
                    episode.update(background_sample_actor_s=.05*len(samples),
                        background_commanded_braking_actor_s=.05*sum(value < 0. for value in samples),
                        background_commanded_harsh_braking_actor_s=.05*harsh,
                        background_harsh_braking_actor_time_ratio=harsh/len(samples),
                        background_harsh_braking_actor_s_per_100_actor_s=100.*harsh/len(samples))
        except (OSError, ValueError, csv.Error):
            missing += 1
    for field in ('entry_wait_s', 'non_goal_stop_s', 'non_goal_stop_events',
                  'longest_non_goal_stop_s', 'severe_deceleration_rows',
                  'severe_acceleration_rows', 'tracking_over_half_m_rows',
                  'guard_override_rows', 'guard_prediction_unsafe_rows',
                  'measured_acceleration_rms', 'measured_jerk_rms'):
        values = [episode[field] for episode in episodes if episode.get(field) is not None]
        group['mean_'+field] = statistics.mean(values) if values else None
    group['measured_motion_missing_episodes'] = sum(episode['measured_acceleration_rms'] is None
        or episode['measured_jerk_rms'] is None for episode in episodes)
    group['measured_motion_note'] = ('Acceleration RMS uses every measured acceleration sample in its episode; '
        'jerk RMS uses adjacent acceleration differences /0.05s within that episode only. '
        'Any missing/nonfinite acceleration leaves both metrics missing; one sample leaves jerk missing. '
        'Group means use available episode metrics, with missing episodes reported.')
    gaps = [episode['minimum_predicted_guard_gap'] for episode in episodes
            if episode.get('minimum_predicted_guard_gap') is not None]
    group['minimum_predicted_guard_gap'] = min(gaps) if gaps else None
    group['background_braking'] = dict(samples=len(background), missing_runs=missing,
        sample_actor_s=.05*len(background) if background else None,
        commanded_braking_actor_s=.05*sum(value < 0. for value in background) if background else None,
        commanded_harsh_braking_actor_s=.05*sum(value < -3. for value in background) if background else None,
        harsh_braking_actor_time_ratio=sum(value < -3. for value in background)/len(background) if background else None,
        harsh_braking_actor_s_per_100_actor_s=100.*sum(value < -3. for value in background)/len(background)
            if background else None,
        minimum_commanded_acceleration=min(background) if background else None,
        note='Commanded acceleration over actor-frames, not measured deceleration or attributed ego causality.')


def collect_report(output, stages):
    """Collection success and observed learned benefit remain separate outcomes."""
    output = Path(output)
    reports, runtime_runs = [], []
    for planned in stages:
        current = (_offline_report(planned) if planned['kind'] == 'offline_rebuild'
                   else _stage_report(output, planned))
        reports.append(current)
        for arm, group in current['arms'].items():
            group.pop('probe', None)
            directories = [output/planned['name']/('%s_seed%d' % (arm, seed)) for seed in planned['seeds']]
            _supplement(group, directories)
            if not arm.startswith('U'):
                continue
            counts, actions, missing = Counter(), Counter(), 0
            for seed, directory in zip(planned['seeds'], directories):
                try:
                    value = json.loads((directory/'result.json').read_text(encoding='utf8'))
                    values = value['rolling_counts']
                    if not isinstance(values.get('rows'), int) or isinstance(values['rows'], bool):
                        raise ValueError('Missing rolling frame coverage')
                    counts.update(values)
                    actions.update(value['rolling_actual_actions'])
                except (OSError, ValueError, TypeError, KeyError):
                    missing += 1
                if directory.exists():
                    audit = inspect_runtime(directory)
                    runtime_runs.append(dict(stage=planned['name'], arm=arm, seed=seed, **audit))
                    if not audit['ok']:
                        current['collection_ok'] = False
                        current['errors'].append('%s seed%d: local-map/reference/timing evidence failed' % (arm, seed))
            group['rolling'] = dict(counts=dict(counts), actual_actions=dict(actions), missing_runs=missing)
            if missing:
                current['collection_ok'] = False
                current['errors'].append(arm+': missing rolling statistics')
    smoke = identity(output, next(stage for stage in stages if stage['name'] == '00_smoke'))
    formal = next((stage for stage in reports if stage['name'] == '02_eval'), {})
    groups = formal.get('arms', {})
    baseline = {(row['seed'], row['episode']): row for row in groups.get(CG_ARM, {}).get('episodes', [])}
    learned = {(row['seed'], row['episode']): row for row in groups.get(EVAL_ARM, {}).get('episodes', [])}
    pairs = []
    for key in sorted(set(baseline) & set(learned)):
        before, after = baseline[key], learned[key]
        pair = dict(seed=key[0], episode=key[1], baseline_outcome=before['outcome'],
                    treatment_outcome=after['outcome'])
        for field in ('seconds', 'entry_wait_s', 'non_goal_stop_s', 'non_goal_stop_events',
                      'severe_deceleration_rows', 'severe_acceleration_rows',
                      'guard_override_rows', 'minimum_predicted_guard_gap',
                      'measured_acceleration_rms', 'measured_jerk_rms',
                      'background_sample_actor_s', 'background_commanded_harsh_braking_actor_s',
                      'background_harsh_braking_actor_time_ratio',
                      'background_harsh_braking_actor_s_per_100_actor_s'):
            a, b = after.get(field), before.get(field)
            pair[field+'_delta'] = a-b if a is not None and b is not None else None
        pairs.append(pair)
    frozen_rolling = groups.get(EVAL_ARM, {}).get('rolling', {})
    takeovers = frozen_rolling.get('counts', {}).get('takeovers', 0)
    nonzero_frames = sum(count for action, count in frozen_rolling.get('actual_actions', {}).items()
                         if str(action) != '0')
    report = dict(revision='cg_learning_validation_v29', stages=reports, smoke_identity=smoke,
        planned_episodes=sum(stage['episodes_total'] for stage in stages),
        actual_episodes=sum(group['n'] for stage in reports for group in stage['arms'].values()),
        collection_ok=smoke['ok'] and all(stage['collection_ok'] for stage in reports),
        runtime_audits=runtime_runs, efe_enabled=False,
        frozen_learned_takeover_requests=takeovers, learned_takeover_requested=takeovers > 0,
        frozen_nonzero_action_frames=nonzero_frames, frozen_nonzero_action_executed=nonzero_frames > 0,
        takeover_note='Requests count decision source=takeover, including requests withdrawn by guards. '
            'Nonzero frames count logged actual_actions in frozen evaluation, which has no exploration; '
            'they are separate execution evidence, not proof of benefit or full-horizon tracking.',
        benefit_established=False,
        comparison=dict(baseline=CG_ARM, treatment=EVAL_ARM, paired_episodes=len(pairs),
            baseline_unpaired=len(set(baseline)-set(learned)),
            treatment_unpaired=len(set(learned)-set(baseline)), pairs=pairs,
            mean_seconds_delta=statistics.mean(pair['seconds_delta'] for pair in pairs) if pairs else None),
        note='Main comparison is unchanged CG versus frozen CG+GTRL. Primary metrics are success, collision '
             'and stuck; waiting, predicted safety margins, comfort and background braking supplement them. '
             'Zero learned takeover is a finding, not a collection failure. Collection success is not benefit. '
             'Offline replay is not new CARLA training. Paired seeds do not fix closed-loop traffic.')
    (output/'ROLLING_REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = [report['note'], 'CARLA episodes collected: %d/%d' %
             (report['actual_episodes'], report['planned_episodes']),
             'Observe-only CG identity: %s' % smoke['ok']]
    for stage in reports:
        for arm, group in stage['arms'].items():
            lines.append('%s/%s: success=%d/%d collision=%d stuck=%d mean_all_s=%s rolling=%s' % (
                stage['name'], arm, group['success'], group['n'], group['collisions'], group['stuck'],
                group['mean_all_episode_s'], json.dumps(group.get('rolling', {}))))
            lines.append('  guard_gap_min=%s entry_wait_mean_s=%s acc_RMS_mean=%s jerk_RMS_mean=%s '
                'motion_missing_episodes=%d BG_harsh_actor_s_per_100_actor_s=%s' % (
                    group['minimum_predicted_guard_gap'], group['mean_entry_wait_s'],
                    group['mean_measured_acceleration_rms'], group['mean_measured_jerk_rms'],
                    group['measured_motion_missing_episodes'],
                    group['background_braking']['harsh_braking_actor_s_per_100_actor_s']))
        lines.extend('ERROR: %s: %s' % (stage['name'], error) for error in stage['errors'])
    lines.append('Frozen learned requests=%d; logged nonzero actual-action frames=%d; benefit established=False' %
                 (takeovers, nonzero_frames))
    lines.append(report['takeover_note'])
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n', encoding='utf8')
    return report


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--replay-source', type=Path,
        help='Old rolling_model.json containing actual records; old Q is rebuilt offline')
    mode.add_argument('--fresh-train', action='store_true', help='Explicitly run new CARLA training')
    parser.add_argument('--train-episodes', type=int, default=100)
    parser.add_argument('--smoke-episodes', type=int, default=2)
    parser.add_argument('--eval-episodes', type=int, default=10)
    parser.add_argument('--eval-seeds', default='121,122,123')
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)
    try:
        seeds = [int(value) for value in args.eval_seeds.split(',')]
        if min(args.train_episodes, args.smoke_episodes, args.eval_episodes) < 1:
            raise ValueError('Episode counts must be positive')
        if not seeds or len(set(seeds)) != len(seeds) or any(seed in (73, 110, 111) for seed in seeds):
            raise ValueError('Unique evaluation seeds separate from historical/smoke/train seeds are required')
    except ValueError as exc:
        parser.error(str(exc))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output = (args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_cg_learning_v29_'+stamp)).resolve()
    source = None if args.fresh_train else (args.replay_source or DEFAULT_REPLAY_SOURCE).resolve()
    stages = build_plan(output, source, args.fresh_train, args.train_episodes,
                        args.eval_episodes, seeds, args.smoke_episodes)
    if args.dry_run:
        for stage in stages:
            print(json.dumps(stage, ensure_ascii=False))
        return 0
    if source is not None and not source.is_file():
        parser.error('Replay source not found: %s. Provide --replay-source PATH or explicitly choose '
                     '--fresh-train. No new training was started.' % source)
    archive = Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists():
        parser.error('Output/archive already exists; choose a new --output-root')
    output.mkdir(parents=True, exist_ok=False)
    checkpoint_args = stages[-1]['arguments']
    checkpoint = Path(checkpoint_args[checkpoint_args.index('--rolling-checkpoint')+1])
    workflow = dict(revision='cg_learning_validation_v29',
        mode='fresh_training_then_frozen_eval' if args.fresh_train else 'offline_rebuild_then_frozen_eval',
        planned_episodes=sum(stage['episodes_total'] for stage in stages), stages=stages,
        overall_success=None, efe_enabled=False, replay_source=str(source) if source is not None else None,
        replay_source_sha256_before=_hash(source) if source is not None else None,
        source_records_are_new_carla_training=False, fresh_train_episodes=args.train_episodes if args.fresh_train else 0,
        checkpoint=str(checkpoint))
    state = output/'WORKFLOW.json'
    status = 1
    try:
        for stage in stages:
            if stage['name'] == '02_eval':
                workflow['frozen_checkpoint_sha256_before'] = _hash(checkpoint)
            stage['status'] = 'running'
            state.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
            stage_root = output/stage['name']
            if stage['kind'] == 'offline_rebuild':
                stage_root.mkdir(parents=True, exist_ok=False)
                print('[%s] offline rebuild of real records; 0 new CARLA episodes' % stage['name'], flush=True)
            else:
                print('[%s] planned CARLA episodes=%d' % (stage['name'], stage['episodes_total']), flush=True)
            run = subprocess.run([sys.executable, '-u', str(ROOT/'Tools'/stage['tool'])]
                                 +stage['arguments'], cwd=str(ROOT))
            stage['returncode'] = run.returncode
            report = collect_report(output, stages)
            current = next(row for row in report['stages'] if row['name'] == stage['name'])
            status = run.returncode or (11 if not current['collection_ok'] else 0)
            if stage['name'] == '00_smoke' and not report['smoke_identity']['ok']:
                status = status or 12
            if stage['name'] == '02_eval':
                workflow['frozen_checkpoint_sha256_after'] = _hash(checkpoint)
                workflow['frozen_checkpoint_unchanged'] = (
                    workflow['frozen_checkpoint_sha256_before'] == workflow['frozen_checkpoint_sha256_after'])
                if not workflow['frozen_checkpoint_unchanged']:
                    status = status or 14
            stage['status'] = 'collected' if status == 0 else 'failed'
            if status:
                workflow['stop_reason'] = 'Stage collection/reference/checkpoint evidence failed; retain all partial logs'
                break
        if status == 0 and not collect_report(output, stages)['collection_ok']:
            status = 11
    except KeyboardInterrupt:
        status = 130
        workflow['error'] = 'Interrupted; partial results retained'
    except Exception as exc:
        status = 1
        workflow['error'] = '%s: %s' % (type(exc).__name__, exc)
    finally:
        if source is not None:
            try:
                workflow['replay_source_sha256_after'] = _hash(source)
                workflow['replay_source_unchanged'] = (
                    workflow['replay_source_sha256_before'] == workflow['replay_source_sha256_after'])
                if not workflow['replay_source_unchanged']:
                    status = status or 15
            except OSError as exc:
                workflow['replay_source_unchanged'] = False
                workflow['source_hash_error'] = str(exc)
                status = status or 15
        workflow.update(exit_code=status, overall_success=status == 0,
                        finished_utc=datetime.now(timezone.utc).isoformat())
        state.write_text(json.dumps(workflow, ensure_ascii=False, indent=2), encoding='utf8')
        try:
            collect_report(output, stages)
        except Exception as exc:
            (output/'REPORT_ERROR.txt').write_text('%s: %s\n' % (type(exc).__name__, exc), encoding='utf8')
        with tarfile.open(str(archive), 'x:gz') as stream:
            stream.add(str(output), arcname=output.name)
        print('Result folder: '+str(output), flush=True)
        print('Return this archive, including failed runs: '+str(archive), flush=True)
    return status


if __name__ == '__main__':
    raise SystemExit(main())
