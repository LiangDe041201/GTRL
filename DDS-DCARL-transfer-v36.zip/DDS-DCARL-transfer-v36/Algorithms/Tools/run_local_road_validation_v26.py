#!/usr/bin/env python3
"""Local-map engineering regression; optional full frozen-learning protocol."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import tarfile

if __package__:
    from . import run_rolling_validation_v25 as previous
    from .run_trajectory_validation_v21 import _stage_report
else:
    import run_rolling_validation_v25 as previous
    from run_trajectory_validation_v21 import _stage_report

ROOT=previous.ROOT
REVISION='analytic_local_road_v26'


def build_plan(output,probe_episodes=3,full_learning=False,train_episodes=20,eval_episodes=2,eval_seeds=None):
    stages=previous.build_plan(output,train_episodes,probe_episodes,eval_episodes,eval_seeds)
    if not full_learning: stages=stages[:2]
    for stage in stages: stage['arguments']+=['--road-audit','local_v26']
    return stages


def inspect_runtime(directory):
    """Check recorded local mode, source identity and zero runtime map API calls."""
    result=previous.inspect_runtime(directory)
    errors=Counter(result['errors']); local=Counter(); rows=0
    try:
        meta=json.loads((directory/'rolling_metadata_v24.json').read_text(encoding='utf8'))['corridor']
        snapshot=json.loads((directory/'local_road_region_v26.json').read_text(encoding='utf8'))
        if (meta!=snapshot or meta['revision']!=REVISION or meta['runtime_map_queries'] is not False
                or meta['geometry']!='line_arc_piecewise_cubic_lanes_2d'):
            errors['local_region_identity']+=1
        if hashlib.sha256((directory/'public_map_v24.xodr').read_bytes()).hexdigest()!=meta['opendrive_sha256']:
            errors['local_map_hash']+=1
        bounds=meta['bounds_xyxy']
        if (len(bounds)!=4 or any(not math.isfinite(v) for v in bounds)
                or bounds[0]>=bounds[2] or bounds[1]>=bounds[3]): errors['local_coverage']+=1
        if (meta['setup_map_queries']!=meta['route_samples'] or meta['route_samples']<=0
                or meta['setup_map_exports']!=1 or not math.isfinite(meta['setup_ms']) or meta['setup_ms']<0.):
            errors['setup_map_statistics']+=1
        with (directory/'matrix_decisions.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                p=json.loads(line)['rolling_trajectory']; rows+=1
                if p['road_revision']!=REVISION: errors['runtime_road_revision']+=1
                s=p['map_statistics']
                if any(s[k]!=0 for k in ('map_queries','map_cache_hits','map_query_ms')):
                    errors['runtime_map_api']+=1
                if (not isinstance(s['local_points'],int) or isinstance(s['local_points'],bool)
                        or s['local_points']<=0 or not math.isfinite(s['local_query_ms'])
                        or s['local_query_ms']<0. or s['audit_calls']<=0):
                    errors['local_query_statistics']+=1
                else:
                    local['local_points']+=s['local_points']; local['local_query_ms']+=s['local_query_ms']
        expected=json.loads((directory/'result.json').read_text(encoding='utf8'))['rolling_counts']['rows']
        if not rows or rows!=expected or rows!=result['rows']: errors['local_frame_coverage']+=1
    except (OSError,ValueError,KeyError,TypeError,OverflowError): errors['missing_or_invalid_local_evidence']+=1
    result.update(ok=not errors,errors=dict(errors),local_counters=dict(local))
    return result


def collect_report(output,stages):
    if len(stages)==4:
        report=previous.collect_report(output,stages)
    else:
        reports=[_stage_report(output,s) for s in stages]
        executed=transitions=0
        for planned,stage in zip(stages,reports):
            for arm,group in stage['arms'].items():
                group.pop('probe',None); counts=Counter(); actions=Counter(); missing=0
                for seed in planned['seeds']:
                    if not arm.startswith('T'): continue
                    try:
                        value=json.loads((output/stage['name']/('%s_seed%d'%(arm,seed))/'result.json').read_text(encoding='utf8'))
                        counts.update(value['rolling_counts']); actions.update(value['rolling_actual_actions'])
                    except (OSError,KeyError,ValueError,TypeError): missing+=1
                group['rolling']=dict(counts=dict(counts),actual_actions=dict(actions),missing_runs=missing)
                if missing:
                    stage['collection_ok']=False; stage['errors'].append(arm+': missing rolling statistics')
                if stage['name']=='01_probe':
                    executed+=sum(v for k,v in actions.items() if k!='0')
                    transitions+=counts.get('transition_records',0)
        report=dict(stages=reports,smoke_identity=previous.base.identity(output),
            planned_episodes=sum(s['episodes_total'] for s in stages),
            actual_episodes=sum(g['n'] for s in reports for g in s['arms'].values()),
            spatial_execution_observed=executed>0,training_transition_records=transitions,
            learning_chain_observed=executed>0 and transitions>0,efe_enabled=False,benefit_established=False)
    runs=[]; errors=Counter()
    for planned,current in zip(stages,report['stages']):
        for arm in planned['arms']:
            if not arm.startswith('T'): continue
            for seed in planned['seeds']:
                directory=output/planned['name']/('%s_seed%d'%(arm,seed))
                if not directory.exists(): continue
                audit=inspect_runtime(directory); errors.update(audit['errors'])
                runs.append(dict(stage=planned['name'],arm=arm,seed=seed,**audit))
                if not audit['ok']:
                    current['collection_ok']=False
                    current['errors'].append('%s seed%d: local road/reference/timing evidence failed'%(arm,seed))
    report.update(revision='local_road_regression_v26',v26_local_road=dict(ok=bool(runs) and not errors,errors=dict(errors),runs=runs),
        note='Engineering regression of startup OpenDRIVE/local body checks. Collection success is not driving success '
             'or a GTRL/EFE benefit. Line/arc lane union is not identical to CARLA nearest-lane selection at overlaps.',
        timing_note='Inclusive timers overlap; do not sum generation/execution/score with their child timers.')
    report['collection_ok']=report['smoke_identity']['ok'] and all(s['collection_ok'] for s in report['stages'])
    (output/'ROLLING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    lines=[report['note'],'Executed %d/%d; local evidence ok=%s'%(report['actual_episodes'],report['planned_episodes'],not errors)]
    for stage in report['stages']:
        for arm,g in stage['arms'].items():
            lines.append('%s/%s: n=%d success=%d collision=%d stuck=%d mean_sim_s=%s'%(stage['name'],arm,
                g['n'],g['success'],g['collisions'],g['stuck'],g['mean_all_episode_s']))
    for run in runs:
        lines.append('%s/%s seed%d: API=%s local=%s road_ms=%s'%(run['stage'],run['arm'],run['seed'],
            run['counters'].get('map_queries'),run['local_counters'],run['timing'].get('road_audit_ms')))
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
    return report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe-episodes',type=int,default=3)
    parser.add_argument('--full-learning',action='store_true',help='Explicitly add 20 train + 12 frozen evaluation episodes')
    parser.add_argument('--train-episodes',type=int,default=20)
    parser.add_argument('--eval-episodes',type=int,default=2)
    parser.add_argument('--eval-seeds',default='81,82')
    parser.add_argument('--output-root',type=Path)
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args(argv)
    try:
        seeds=[int(v) for v in args.eval_seeds.split(',')]
        if min(args.probe_episodes,args.train_episodes,args.eval_episodes)<1 or not seeds or len(set(seeds))!=len(seeds):
            raise ValueError('Positive counts and unique evaluation seeds are required')
        if any(seed in (70,71,72,73) for seed in seeds): raise ValueError('Evaluation seeds must be independent')
    except ValueError as exc: parser.error(str(exc))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_local_road_v26_'+stamp)).resolve()
    stages=build_plan(output,args.probe_episodes,args.full_learning,args.train_episodes,args.eval_episodes,seeds)
    if args.dry_run:
        for stage in stages: print(json.dumps(stage))
        return 0
    archive=Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists(): parser.error('Output/archive already exists; choose a new output-root')
    output.mkdir(parents=True)
    workflow=dict(revision='local_road_regression_v26',planned_episodes=sum(s['episodes_total'] for s in stages),
        stages=stages,full_learning=args.full_learning,road_audit='local_v26',overall_success=None,efe_enabled=False)
    file=output/'WORKFLOW.json'; status=1; checkpoint_hash=None
    checkpoint=output/'02_train/T2_train_v24_seed73/rolling_model/rolling_model.json'
    try:
        for stage in stages:
            if stage['name']=='03_eval': checkpoint_hash=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            stage['status']='running'; file.write_text(json.dumps(workflow,indent=2),encoding='utf8')
            print('[%s] planned episodes=%d'%(stage['name'],stage['episodes_total']),flush=True)
            run=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
            stage['returncode']=run.returncode
            report=collect_report(output,stages)
            current=next(s for s in report['stages'] if s['name']==stage['name'])
            status=run.returncode or (11 if not current['collection_ok'] else 0)
            if stage['name']=='00_smoke' and not report['smoke_identity']['ok']: status=status or 12
            if stage['name']=='01_probe' and not report['spatial_execution_observed']:
                status=status or 13; workflow['stop_reason']='No new spatial action was actually executed'
            if stage['name']=='03_eval':
                unchanged=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==checkpoint_hash
                report['frozen_checkpoint_unchanged']=unchanged
                (output/'ROLLING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
                if not unchanged: status=status or 14
            if status and 'stop_reason' not in workflow:
                workflow['stop_reason']='Stage collection/local-map/reference evidence failed; inspect result.json and ROLLING_REPORT.json'
            stage['status']='collected' if status==0 else 'failed'
            if status: break
    except KeyboardInterrupt: status=130; workflow['error']='Interrupted; partial results retained'
    except Exception as exc: status=1; workflow['error']='%s: %s'%(type(exc).__name__,exc)
    finally:
        workflow.update(exit_code=status,overall_success=status==0,finished_utc=datetime.now(timezone.utc).isoformat())
        file.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
        with tarfile.open(str(archive),'w:gz') as stream: stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__': raise SystemExit(main())
