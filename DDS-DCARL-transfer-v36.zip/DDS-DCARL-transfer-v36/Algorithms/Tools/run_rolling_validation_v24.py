#!/usr/bin/env python3
"""Staged rolling-action pilot: execution gate, short learning and frozen comparison."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tarfile

if __package__:
    from .run_trajectory_validation_v21 import _stage_report,_rows,PHYSICAL_FIELDS
else:
    from run_trajectory_validation_v21 import _stage_report,_rows,PHYSICAL_FIELDS

ROOT=Path(__file__).resolve().parents[1]


def build_plan(output,train_episodes=12,probe_episodes=2,eval_episodes=2,eval_seeds=None):
    eval_seeds=[81] if eval_seeds is None else list(eval_seeds)
    common=['--method','CG','--game-mode','matrix_v18','--traffic','on','--traffic-interaction','v17',
            '--control-profile','paper_v11','--completion-mode','strict','--keep-going']
    stages=[]
    for name,n,seeds,arms in [
        ('00_smoke',2,[70],['M6_matrix_v18','T0_observe_v24']),
        ('01_probe',probe_episodes,[71,72],['T1_fixed_v24','T2_train_v24']),
        ('02_train',train_episodes,[73],['T2_train_v24']),
        ('03_eval',eval_episodes,eval_seeds,['M6_matrix_v18','T1_fixed_v24','T3_eval_v24'])]:
        args=common+['--episodes',str(n),'--seeds',','.join(map(str,seeds)),
                     '--arms',','.join(arms),'--output-root',str(output/name)]
        if name=='03_eval':
            args+=['--rolling-checkpoint',str(output/'02_train/T2_train_v24_seed73/rolling_model/rolling_model.json')]
        stages.append(dict(name=name,episodes_per_run=n,seeds=seeds,arms=arms,
                           episodes_total=n*len(seeds)*len(arms),arguments=args))
    return stages


def identity(output):
    try:
        rows=[_rows(output/'00_smoke'/(a+'_seed70')/'interaction_ego.csv')
              for a in ('M6_matrix_v18','T0_observe_v24')]
        if any(not r or any(any(v.get(k) in (None,'') for k in PHYSICAL_FIELDS) for v in r) for r in rows):
            raise ValueError('Missing physical signature')
        signatures=[[tuple(v[k] for k in PHYSICAL_FIELDS) for v in r] for r in rows]
        return dict(ok=signatures[0]==signatures[1],rows=[len(r) for r in rows])
    except (OSError,KeyError,ValueError) as exc: return dict(ok=False,error=str(exc))


def collect_report(output,stages):
    reports=[_stage_report(output,s) for s in stages]
    executed=0; transitions=0
    for stage,planned in zip(reports,stages):
        for arm,group in stage['arms'].items():
            group.pop('probe',None)
            counts,actions=Counter(),Counter(); missing=0
            for seed in planned['seeds']:
                if not arm.startswith('T'): continue
                try:
                    result=json.loads((output/stage['name']/('%s_seed%d'%(arm,seed))/'result.json').read_text(encoding='utf8'))
                    values=result['rolling_counts']
                    if not isinstance(values.get('rows'),int): raise ValueError('No rolling frame coverage')
                    counts.update(values); actions.update(result['rolling_actual_actions'])
                except (OSError,KeyError,ValueError,TypeError): missing+=1
            group['rolling']=dict(counts=counts,actual_actions=actions,missing_runs=missing)
            if missing:
                stage['collection_ok']=False; stage['errors'].append(arm+': missing rolling statistics')
            if stage['name']=='01_probe': executed+=sum(v for k,v in actions.items() if k!='0')
            if stage['name']=='02_train': transitions+=counts.get('transition_records',0)
    report=dict(revision='rolling_learning_pilot_v24',stages=reports,smoke_identity=identity(output),
        planned_episodes=sum(s['episodes_total'] for s in stages),
        actual_episodes=sum(g['n'] for s in reports for g in s['arms'].values()),
        collection_ok=False,spatial_execution_observed=executed>0,
        training_transition_records=transitions,learning_chain_observed=executed>0 and transitions>0,
        efe_enabled=False,benefit_established=False,
        note='Short mechanism pilot. Fixed rule and learned policy share candidates and guards. '
             'Exploration is not trusted takeover. No positive driving benefit is inferred from collection success.')
    report['collection_ok']=report['smoke_identity']['ok'] and all(s['collection_ok'] for s in reports)
    formal=next(s for s in reports if s['name']=='03_eval')['arms']
    comparisons={}
    for treatment,baseline in [('T1_fixed_v24','M6_matrix_v18'),('T3_eval_v24','T1_fixed_v24'),
                               ('T3_eval_v24','M6_matrix_v18')]:
        a={(e['seed'],e['episode']):e for e in formal.get(treatment,{}).get('episodes',[])}
        b={(e['seed'],e['episode']):e for e in formal.get(baseline,{}).get('episodes',[])}
        pairs=[dict(seed=k[0],episode=k[1],treatment_outcome=a[k]['outcome'],baseline_outcome=b[k]['outcome'],
                    seconds_delta=a[k]['seconds']-b[k]['seconds']) for k in sorted(set(a)&set(b))]
        comparisons[treatment+'_vs_'+baseline]=dict(pairs=pairs,
            mean_seconds_delta=statistics.mean(p['seconds_delta'] for p in pairs) if pairs else None)
    report['comparisons']=comparisons
    file=output/'ROLLING_REPORT.json'
    file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    lines=[report['note'],'Executed %d/%d; spatial execution=%s; transitions=%d'%(
        report['actual_episodes'],report['planned_episodes'],report['spatial_execution_observed'],transitions)]
    for s in reports:
        for a,g in s['arms'].items():
            lines.append('%s/%s: n=%d success=%d collision=%d stuck=%d mean_sim_s=%s rolling=%s'%(
                s['name'],a,g['n'],g['success'],g['collisions'],g['stuck'],g['mean_all_episode_s'],json.dumps(g['rolling'])))
    (output/'COMPARISON.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train-episodes',type=int,default=12)
    p.add_argument('--probe-episodes',type=int,default=2)
    p.add_argument('--eval-episodes',type=int,default=2)
    p.add_argument('--eval-seeds',default='81')
    p.add_argument('--output-root',type=Path)
    p.add_argument('--dry-run',action='store_true')
    args=p.parse_args(argv)
    try:
        seeds=[int(s) for s in args.eval_seeds.split(',')]
        if min(args.train_episodes,args.probe_episodes,args.eval_episodes)<1 or len(set(seeds))!=len(seeds) or not seeds:
            raise ValueError('Positive episode counts and unique evaluation seeds are required')
        if any(s in (70,71,72,73) for s in seeds): raise ValueError('Evaluation seeds must be separate from pilot/train seeds')
    except ValueError as exc: p.error(str(exc))
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=(args.output_root or ROOT.parent.parent/'DDS-DCARL-results'/('relay_rolling_v24_'+stamp)).resolve()
    stages=build_plan(output,args.train_episodes,args.probe_episodes,args.eval_episodes,seeds)
    if args.dry_run:
        for stage in stages: print(json.dumps(stage))
        return 0
    archive=Path(str(output)+'.tar.gz')
    if output.exists() or archive.exists(): p.error('Output/archive already exists; choose a new output-root')
    output.mkdir(parents=True)
    workflow=dict(revision='rolling_learning_v24',planned_episodes=sum(s['episodes_total'] for s in stages),
                  stages=stages,overall_success=None,efe_enabled=False)
    file=output/'WORKFLOW.json'; status=1; checkpoint_hash=None
    checkpoint=output/'02_train/T2_train_v24_seed73/rolling_model/rolling_model.json'
    try:
        for stage in stages:
            if stage['name']=='03_eval': checkpoint_hash=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            stage['status']='running'; file.write_text(json.dumps(workflow,indent=2),encoding='utf8')
            print('[%s] planned episodes=%d'%(stage['name'],stage['episodes_total']),flush=True)
            run=subprocess.run([sys.executable,'-u',str(ROOT/'Tools/run_relay_validation.py')]+stage['arguments'],cwd=str(ROOT))
            stage['returncode']=run.returncode
            report=collect_report(output,stages)
            current=next(s for s in report['stages'] if s['name']==stage['name'])
            status=run.returncode or (11 if not current['collection_ok'] else 0)
            if stage['name']=='00_smoke' and not report['smoke_identity']['ok']: status=status or 12
            if stage['name']=='01_probe' and not report['spatial_execution_observed']:
                status=status or 13
                workflow['stop_reason']='No new spatial action was actually executed; do not expand training'
            if stage['name']=='03_eval':
                unchanged=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==checkpoint_hash
                report['frozen_checkpoint_unchanged']=unchanged
                (output/'ROLLING_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
                if not unchanged: status=status or 14
            stage['status']='collected' if status==0 else 'failed'
            if status: break
    except KeyboardInterrupt: status=130; workflow['error']='Interrupted; partial results retained'
    except Exception as exc: status=1; workflow['error']='%s: %s'%(type(exc).__name__,exc)
    finally:
        workflow.update(exit_code=status,overall_success=status==0,finished_utc=datetime.now(timezone.utc).isoformat())
        file.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
        with tarfile.open(str(archive),'w:gz') as stream: stream.add(str(output),arcname=output.name)
        print('Result folder: '+str(output),flush=True)
        print('Return this archive, including failed runs: '+str(archive),flush=True)
    return status


if __name__=='__main__': raise SystemExit(main())
