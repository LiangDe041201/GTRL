"""Independent per-frame authority checks for the explicitly configured probe."""
from collections import Counter
import hashlib
import math
import struct


def _numeric_vector(values):
    if not isinstance(values, list) or not values:
        raise ValueError('Expected a nonempty numeric vector')
    if any(isinstance(x, bool) or not isinstance(x, (int, float))
           or not math.isfinite(float(x)) for x in values):
        raise ValueError('Payload contains a nonfinite or nonnumeric value')
    return [float(x) for x in values]


def _numeric_matrix(values, rows=None, columns=None):
    if not isinstance(values, list) or not values or rows is not None and len(values) != rows:
        raise ValueError('Unexpected payload row count')
    matrix = [_numeric_vector(row) for row in values]
    width = len(matrix[0]) if columns is None else columns
    if any(len(row) != width for row in matrix):
        raise ValueError('Ragged or incorrectly shaped payload')
    return matrix


def _check_hash(matrix, saved):
    values = [x for row in matrix for x in row]
    # Independent of the NumPy serializer used by the producer.
    actual = hashlib.sha256(struct.pack('<%dd' % len(values), *values)).hexdigest()
    if saved != actual:
        raise ValueError('Raw payload differs from its recorded hash')


def _validate_payload(probe):
    path = _numeric_matrix(probe['path'], columns=2)
    if len(path) < 2:
        raise ValueError('Path needs at least two points')
    _check_hash(path, probe['path_hash'])
    for candidate in probe['candidates']:
        times = _numeric_vector(candidate['times'])
        if (len(times) < 2 or abs(times[0]) > 1e-10
                or any(b <= a for a, b in zip(times, times[1:]))
                or abs(times[-1]-2.3) > 1e-8):
            raise ValueError('Invalid frozen-profile prediction time axis')
        if not candidate['solve_ok'] and candidate.get('eligible', False):
            raise ValueError('Failed optimizer cannot be eligible')
        for name, count, width in (('plan', 2, len(times)-1),
                                    ('prediction', 7, len(times))):
            value, saved_hash = candidate[name], candidate[name+'_hash']
            if value is None:
                if candidate['solve_ok'] or saved_hash is not None:
                    raise ValueError('Successful optimizer needs its complete payload')
            else:
                _check_hash(_numeric_matrix(value, rows=count, columns=width), saved_hash)


def validate_probe_record(row, ego, mode, previous_control=None):
    errors = Counter()
    try:
        p = row['trajectory_probe']
        try:
            _validate_payload(p)
        except (KeyError, TypeError, ValueError, IndexError, OverflowError):
            errors['invalid_payload'] += 1
        baseline = int(row['selected'])
        names = ('defer', 'proceed')
        if (mode not in ('observe', 'defer', 'proceed') or p['mode'] != mode
                or p['revision'] != 'trajectory_probe_v21' or p['baseline_intent'] != baseline
                or p['baseline_id'] != names[baseline]+'_base' or p['active'] != row['active']
                or p['learning_enabled'] or p['efe_reward_enabled'] or p['spatial_path_changed']
                or p['beta'] != dict(status='unidentified', value=None) or p['scale'] != .75):
            errors['mode_or_baseline'] += 1
        candidates = p['candidates']
        by_id = dict((c['id'], c) for c in candidates)
        if (len(by_id) != len(candidates) or not 2 <= len(candidates) <= 4
                or set(by_id)-{'defer_base','proceed_base','defer_slow','proceed_slow'}):
            errors['candidate_set'] += 1
        for i, name in enumerate(names):
            base = by_id[name+'_base']
            if (base['intent'] != name or base['source'] != 'cg'
                    or base['solve_ok'] != row['candidate_solve_ok'][i]):
                errors['base_candidate'] += 1
            for field, values in (('a','candidate_a'),('delta','candidate_delta'),('target','candidate_targets')):
                if abs(float(base[field])-float(row[values][i])) > 1e-8:
                    errors['base_candidate'] += 1
            slow = by_id.get(name+'_slow')
            if slow is None:
                continue
            if (slow['intent'] != name or slow['source'] != 'parameterized_planner'
                    or abs(float(slow['target'])-.75*float(base['target'])) > 1e-8
                    or slow['target'] < .2 or base['target']-slow['target'] < .05):
                errors['variant_definition'] += 1
            audit = slow['execution']
            parts = slow['components']
            accepted = bool(audit['accepted'])
            gap = audit['proposed_gap']
            gap_ok = bool(audit['unbounded_gap']) if gap is None else math.isfinite(float(gap)) and gap >= .2
            if accepted and not (audit['solve_ok'] and audit['forecast_valid'] and audit['stop_feasible'] and gap_ok):
                errors['execution_acceptance'] += 1
            eligible = bool(slow['solve_ok'] and accepted and len(parts)==2
                            and all(c['admissible'] for c in parts))
            if slow['eligible'] != eligible:
                errors['eligibility'] += 1
            for field in ('a', 'delta', 'target'):
                if not math.isfinite(float(slow[field])):
                    errors['nonfinite_candidate'] += 1
        wanted = names[baseline]+'_slow'
        eligible = wanted in by_id and by_id[wanted]['eligible']
        expected_id = (wanted if p['active'] and p['skip_reason'] is None
                       and mode==names[baseline] and eligible else p['baseline_id'])
        if (p['request_id'] != expected_id or p['request_id'] not in by_id
                or p['request'] != by_id.get(p['request_id'])
                or p['changed_request'] != (p['request_id'] != p['baseline_id'])):
            errors['request_authority'] += 1
        for field, logged in (('a','pre_audit_a'),('delta','pre_audit_delta'),('target','pre_audit_target')):
            if abs(float(p['request'][field])-float(row[logged])) > 1e-8:
                errors['requested_control'] += 1
        for field, logged in (('a','a_prev'),('df','steer_prev')):
            actual, saved = float(p['previous'][field]), float(ego[logged])
            # interaction_logger._r writes these historical fields with nd=3.
            # Compare their declared representation, not a six-digit tolerance.
            if (not math.isfinite(actual) or not math.isfinite(saved)
                    or abs(round(actual, 3)-saved) > 1e-12):
                errors['applied_history'] += 1
            # Full-precision JSON closes the causal link that rounded CSV alone
            # cannot resolve. Episode-first rows have no previous submission.
            if previous_control is not None:
                expected = float(previous_control[field])
                if not math.isfinite(expected) or abs(actual-expected) > 1e-8:
                    errors['applied_history_exact'] += 1
        if not isinstance(p['path_hash'], str) or len(p['path_hash']) != 64:
            errors['path_identity'] += 1
        for field in ('extra_solve_ms','decision_ms'):
            if not math.isfinite(float(p[field])) or float(p[field]) < 0.:
                errors['timing'] += 1
        observation = p['observation']
        if observation['phase'] != row['phase']:
            errors['observation'] += 1
        for actor in [observation['ego']]+observation['others']:
            if any(not math.isfinite(float(actor[k])) for k in ('x','y','v','yaw')):
                errors['observation'] += 1
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        errors['invalid_probe_record'] += 1
    return dict(errors)
