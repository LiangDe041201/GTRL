#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【消融分析】读全部实验臂，出对比表 + 关键对比 + 决策来源分解。

设计背景（见 HANDOFF_2026-10-10.md §8）
------------------------------------------------------------------
6 臂 × 100 回合 × `DSH_SEED=1`（**每臂只跑 1 次**），故：

  ⚠️ **噪声 sd ≈ 4.9 pp（100 回合）⇒ 本脚本只能分辨 ≥10 pp 的差异。**
     所有 <10 pp 的差一律标 `[噪声内]`，**不得宣称有差异**。

  ⚠️ **探索帧会绕过②③**：`act_hybrid`（`dds_dcarl_turn.py:560-562`）里
     `explore_action is not None` 时，EFE 与 WCV/BCV **全被跳过**。
     实测 explore 占比可达 12.7%~46% ⇒ **必须同时报 `decision_src` 分解**，
     否则会把"机制没被调用"误读成"机制无效"。

用法
------------------------------------------------------------------
  # 全部 6 臂（默认）
  python Tools/analyze_ablation.py

  # 指定臂（目录名）
  python Tools/analyze_ablation.py --arms A0_rule_base,A6_full_gtrl

  # 写 markdown 报告
  python Tools/analyze_ablation.py --md /tmp/ablation_report.md

  # 换一个噪声底线（若以后补跑了重复，可用实测 sd）
  python Tools/analyze_ablation.py --noise 4.9
"""
from __future__ import annotations

import argparse
import collections
import csv
import math
import os
import statistics as st
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: 本实验的 6 个臂（顺序 = 报告顺序 = 从"什么都不开"到"最全"）
DEFAULT_ARMS = [
    'A0_rule_base',       # 纯规则基线
    'A2_rule_wcv',        # 规则 + ③
    'A3_rule_efe_only',   # 规则 + ②（③关 ⇒ 嵌套对照）
    'A4_rule_wcv_efe',    # 规则 + ②③
    'A6_full_gtrl',       # 全开（含 ④ 屏蔽）
    'A7_full_noshield',   # 全开 − ④ 屏蔽
]

#: 每个臂的配置说明（打印用；与 run_ablation_main.sh 对齐）
ARM_DESC = {
    'A0_rule_base':     '纯规则基线 CG / ③关 ②关 ①关 / ④开',
    'A2_rule_wcv':      '规则 + ③ WCV/BCV',
    'A3_rule_efe_only': '规则 + ② EFE（③关 ⇒ 预期≈0）',
    'A4_rule_wcv_efe':  '规则 + ②③',
    'A6_full_gtrl':     '全开 GTRL（①③ + ④屏蔽）',
    'A7_full_noshield': '全开 − ④屏蔽',
}

#: 噪声底线（pp）。100 回合下实测 sd ≈ 4.9 pp。
NOISE_PP_DEFAULT = 4.9
#: 判定门槛：2×sd（≈10 pp）——小于它一律不下结论
NOISE_K = 2.0


def _load_summary(arm):
    p = os.path.join(BASE, arm, 'interaction_summary.csv')
    if not os.path.exists(p):
        return None
    out = []
    with open(p) as f:
        for r in csv.DictReader(f):
            if r.get('episode'):
                out.append(r)
    return out


def _load_ego_col(arm, col, limit=None):
    """读 interaction_ego.csv 的某一列（内存友好：逐行读，不整表加载）。

    ⚠️ 注意：`interaction_ego.csv` 由 logger 缓冲写入（`flush_every`），
       训练进行中可能**只有表头、没有数据行** ⇒ 此时返回 []。
       这**不代表列不存在**，只代表还没 flush。表 2 会据此给出提示。
    """
    p = os.path.join(BASE, arm, 'interaction_ego.csv')
    if not os.path.exists(p):
        return []
    vals = []
    try:
        with open(p) as f:
            rd = csv.DictReader(f)
            if col not in (rd.fieldnames or []):
                return []
            for i, r in enumerate(rd):
                if limit is not None and i >= limit:
                    break
                vals.append(r.get(col))
    except Exception:
        return []
    return vals


def summarize_arm(arm, noise_pp=NOISE_PP_DEFAULT):
    rows = _load_summary(arm)
    if rows is None:
        return None
    n = len(rows)
    if n == 0:
        return None
    c = collections.Counter(r['outcome'] for r in rows)
    comp = 100.0 * c['complete'] / n
    coll = 100.0 * c['collision'] / n
    stuck = 100.0 * c['stuck'] / n
    # 二项标准误（单臂内，仅用于给出不确定度量级）
    se = 100.0 * math.sqrt((comp / 100.0) * (1 - comp / 100.0) / n)
    frames = []
    for r in rows:
        try:
            frames.append(float(r['frames']))
        except (KeyError, TypeError, ValueError):
            pass
    # ④屏蔽命中
    shield = []
    for r in rows:
        try:
            shield.append(float(r['shield_block']))
        except (KeyError, TypeError, ValueError):
            pass
    # decision_src 分解（②③是否真的被调用）
    src = collections.Counter(x for x in _load_ego_col(arm, 'decision_src') if x)
    src_tot = sum(src.values())
    takeover = _load_ego_col(arm, 'takeover')
    tk = sum(1 for x in takeover if x == '1')
    return {
        'arm': arm, 'desc': ARM_DESC.get(arm, ''), 'n': n,
        'complete': comp, 'collision': coll, 'stuck': stuck, 'se': se,
        'frames_med': (st.median(frames) if frames else float('nan')),
        'shield_block_med': (st.median(shield) if shield else float('nan')),
        'src': src, 'src_tot': src_tot,
        'takeover_pct': (100.0 * tk / len(takeover)) if takeover else float('nan'),
        'counts': dict(c),
    }


def _fmt_pct(x):
    return '  -  ' if x is None or (isinstance(x, float) and math.isnan(x)) else f'{x:5.1f}'


def print_main_table(arms, res):
    print('=' * 96)
    print('【表 1】各臂结局（每臂 1 次 × 100 回合，DSH_SEED=1）')
    print('=' * 96)
    print(f"{'臂':<20}{'n':<6}{'complete%':<11}{'collision%':<12}{'stuck%':<9}"
          f"{'±SE(pp)':<10}{'帧数中位':<10}{'屏蔽命中中位'}")
    for a in arms:
        r = res.get(a)
        if r is None:
            print(f'{a:<20}{"(无数据)":<6}')
            continue
        print(f"{a:<20}{r['n']:<6}{_fmt_pct(r['complete']):<11}{_fmt_pct(r['collision']):<12}"
              f"{_fmt_pct(r['stuck']):<9}{r['se']:<10.1f}{r['frames_med']:<10.0f}"
              f"{r['shield_block_med']}")
    print()
    print('  说明：±SE 是**单臂内**的二项标准误；臂之间的比较还要加上运行间噪声（见下方门槛）。')


def print_src_table(arms, res):
    print()
    print('=' * 96)
    print('【表 2】决策来源分解 ★为什么必须看：explore 帧会**绕过②③**（`dds_dcarl_turn.py:560-562`）')
    print('=' * 96)
    keys = ['rule', 'shield', 'takeover', 'explore']
    print(f"{'臂':<20}" + ''.join(f'{k:<12}' for k in keys) + f"{'takeover列%':<12}{'总帧数'}")
    for a in arms:
        r = res.get(a)
        if r is None:
            continue
        tot = r['src_tot'] or 1
        cells = ''
        for k in keys:
            v = r['src'].get(k, 0)
            cells += f"{100.0*v/tot:<12.1f}"
        print(f"{a:<20}{cells}{r['takeover_pct']:<12.1f}{r['src_tot']}")
    print()
    if all((res.get(a, {}).get('src_tot', 0) == 0) for a in arms if a in res):
        print('  ⏳ 各臂的 interaction_ego.csv 还没 flush（训练中只写了表头）⇒ 本表暂时为空。')
        print('     这不是错误：logger 按 flush_every 批量落盘，跑完或跨过阈值后才有数据。')
        print('     稍后重跑本脚本即可看到分解。')
    else:
        print('  ⚠️ 若某臂 `takeover` 占比很低，说明 RL 层的②③**很少被调用** ⇒')
        print('     该臂的"无差异"可能是"机制没跑到"，而不是"机制无效"。')


def print_comparisons(arms, res, noise_pp):
    thr = NOISE_K * noise_pp
    print()
    print('=' * 96)
    print(f'【表 3】关键对比（主指标 = complete%；判定门槛 = {NOISE_K:.0f}×sd = {thr:.1f} pp）')
    print('=' * 96)
    # (label, arm_lo, arm_hi, 问题)
    pairs = [
        ('① 方法总体提升',      'A0_rule_base', 'A6_full_gtrl',    '纯规则 → 全开'),
        ('② 创新点整体(②③)',   'A0_rule_base', 'A4_rule_wcv_efe', '纯规则 → 规则+②③'),
        ('③ 单独贡献',          'A0_rule_base', 'A2_rule_wcv',     '纯规则 → 规则+③'),
        ('② 在③开启下的贡献',  'A2_rule_wcv',  'A4_rule_wcv_efe', '规则+③ → 规则+②③'),
        ('嵌套验证(②单独关③)', 'A0_rule_base', 'A3_rule_efe_only', '预期 ≈0（证明消融可信）'),
        ('RL 层(GTRL)贡献',     'A4_rule_wcv_efe', 'A6_full_gtrl', '规则+②③ → 全开'),
        ('④ 屏蔽贡献',          'A7_full_noshield', 'A6_full_gtrl', '全开−④ → 全开'),
    ]
    print(f"{'对比':<22}{'从':<20}{'到':<20}{'Δcomplete':<12}{'判定'}")
    for label, a_lo, a_hi, note in pairs:
        r1, r2 = res.get(a_lo), res.get(a_hi)
        if r1 is None or r2 is None:
            print(f'{label:<22}{a_lo:<20}{a_hi:<20}{"(缺数据)":<12}')
            continue
        d = r2['complete'] - r1['complete']
        verdict = '✅ 可讨论' if abs(d) >= thr else '⚠️ 噪声内'
        print(f"{label:<22}{a_lo:<20}{a_hi:<20}{d:+6.1f} pp   {verdict}   ({note})")
    print()
    print(f'  ⚠️ 每臂只跑了 1 次。「⚠️ 噪声内」**不等于"没有效应"**，只表示')
    print(f'     本实验的分辨率不够（100 回合分辨 {thr:.0f} pp）。要下结论须补重复。')


def print_gates(arms, res):
    print()
    print('=' * 96)
    print('【表 4】自检：这个消融实验本身可信吗')
    print('=' * 96)
    a0, a3 = res.get('A0_rule_base'), res.get('A3_rule_efe_only')
    if a0 and a3:
        d = a3['complete'] - a0['complete']
        print(f'  · A3(只开②，③关) vs A0(纯规则): Δ={d:+.1f} pp')
        print('    预期 ≈0 —— 因为 `DSH_WCV_BCV=0` 会把 hybrid_action 直接设为 rule_action，')
        print('    EFE 连入口都没有。若这里出现大差异 ⇒ **说明我们的机制理解错了**，需复查。')
    for a in arms:
        r = res.get(a)
        if not r:
            continue
        tot = r['src_tot'] or 1
        exp = 100.0 * r['src'].get('explore', 0) / tot
        tk = 100.0 * r['src'].get('takeover', 0) / tot
        flag = ''
        if a.startswith('A2') or a.startswith('A4'):
            if tk < 5.0:
                flag = '  ← ⚠️ takeover 太低，③几乎没被调用'
        print(f'  · {a:<20} explore={exp:5.1f}%  takeover={tk:5.1f}%  rule={100.0*r["src"].get("rule",0)/tot:5.1f}%'
              f'  shield={100.0*r["src"].get("shield",0)/tot:5.1f}%{flag}')


def write_md(path, arms, res, noise_pp):
    thr = NOISE_K * noise_pp
    L = []
    L.append('# 消融实验结果（6 臂 × 100 回合 × DSH_SEED=1）\n')
    L.append(f'> 噪声底线：sd ≈ {noise_pp:.1f} pp（100 回合）；判定门槛 = {thr:.1f} pp。'
             f'每臂**只跑 1 次**，小于门槛的差异不下结论。\n')
    L.append('## 表 1 各臂结局\n')
    L.append('| 臂 | 配置 | n | complete% | collision% | stuck% | ±SE | 帧数中位 |')
    L.append('|---|---|---|---|---|---|---|---|')
    for a in arms:
        r = res.get(a)
        if not r:
            L.append(f'| `{a}` | {ARM_DESC.get(a,"")} | — | — | — | — | — | — |')
            continue
        L.append(f"| `{a}` | {r['desc']} | {r['n']} | {r['complete']:.1f} | {r['collision']:.1f} | "
                 f"{r['stuck']:.1f} | {r['se']:.1f} | {r['frames_med']:.0f} |")
    L.append('\n## 表 2 决策来源分解（explore 帧会绕过②③）\n')
    L.append('| 臂 | rule% | shield% | takeover% | explore% | 总帧数 |')
    L.append('|---|---|---|---|---|---|')
    for a in arms:
        r = res.get(a)
        if not r:
            continue
        tot = r['src_tot'] or 1
        L.append(f"| `{a}` | {100.0*r['src'].get('rule',0)/tot:.1f} | "
                 f"{100.0*r['src'].get('shield',0)/tot:.1f} | "
                 f"{100.0*r['src'].get('takeover',0)/tot:.1f} | "
                 f"{100.0*r['src'].get('explore',0)/tot:.1f} | {r['src_tot']} |")
    L.append('\n## 表 3 关键对比\n')
    L.append('| 对比 | 从 | 到 | Δcomplete | 判定 |')
    L.append('|---|---|---|---|---|')
    pairs = [
        ('① 方法总体提升', 'A0_rule_base', 'A6_full_gtrl'),
        ('② 创新点整体(②③)', 'A0_rule_base', 'A4_rule_wcv_efe'),
        ('③ 单独贡献', 'A0_rule_base', 'A2_rule_wcv'),
        ('② 在③开启下', 'A2_rule_wcv', 'A4_rule_wcv_efe'),
        ('嵌套验证', 'A0_rule_base', 'A3_rule_efe_only'),
        ('RL 层贡献', 'A4_rule_wcv_efe', 'A6_full_gtrl'),
        ('④ 屏蔽贡献', 'A7_full_noshield', 'A6_full_gtrl'),
    ]
    for label, lo, hi in pairs:
        r1, r2 = res.get(lo), res.get(hi)
        if not r1 or not r2:
            L.append(f'| {label} | `{lo}` | `{hi}` | — | 缺数据 |')
            continue
        d = r2['complete'] - r1['complete']
        v = '✅ 可讨论' if abs(d) >= thr else '⚠️ 噪声内'
        L.append(f'| {label} | `{lo}` | `{hi}` | {d:+.1f} pp | {v} |')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(L) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--arms', default=','.join(DEFAULT_ARMS))
    ap.add_argument('--noise', type=float, default=NOISE_PP_DEFAULT,
                    help='噪声 sd（pp）。100 回合 ≈ 4.9')
    ap.add_argument('--md', default=None, help='同时写 markdown 报告到该路径')
    args = ap.parse_args()

    arms = [a.strip() for a in args.arms.split(',') if a.strip()]
    res = {}
    missing = []
    for a in arms:
        r = summarize_arm(a, args.noise)
        if r is None:
            missing.append(a)
        else:
            res[a] = r

    if not res:
        print('❌ 没有任何臂有数据。先跑 run_ablation_main.sh，或检查 --arms。')
        print(f'   期望目录（在 {BASE} 下）:')
        for a in arms:
            print(f'     {a}/interaction_summary.csv')
        return 1

    print_main_table(arms, res)
    print_src_table(arms, res)
    print_comparisons(arms, res, args.noise)
    print_gates(arms, res)

    if missing:
        print()
        print(f'⚠️ 缺数据的臂（可能还没跑完）: {", ".join(missing)}')

    if args.md:
        write_md(args.md, arms, res, args.noise)
        print(f'\n已写 markdown 报告: {args.md}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
