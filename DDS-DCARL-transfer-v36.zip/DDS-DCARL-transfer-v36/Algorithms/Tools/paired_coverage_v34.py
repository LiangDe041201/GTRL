"""Report CG/alternative coverage by exact state and independent episode."""
from collections import defaultdict


def paired_coverage(records):
    groups=defaultdict(set)
    for record in records:
        groups[record['state'],record['action']].add(record['episode'])
    supports=[min(len(episodes),len(groups.get((state,0),())))
              for (state,action),episodes in groups.items() if action!=0]
    return dict(paired_support_max=max(supports,default=0),**{
        'paired_cells_ge_%d' % n:sum(support>=n for support in supports) for n in (1,3,5,10)})
