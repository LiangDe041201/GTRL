"""Independent raw trajectory, parameter, confidence and executed-feedback audit."""
from collections import Counter
import math

from Tools.validate_trajectory_probe_v21 import _validate_payload


def validate_evolution_record(row, ego, phase, previous_control=None):
    errors = Counter()
    try:
        p = row['trajectory_evolution']
        if (p['revision'] != 'trajectory_evolution_v22' or p['phase'] != phase
                or phase not in ('observe', 'train', 'eval')
                or p['efe_reward_enabled'] or p['spatial_path_changed']
                or p['learning_enabled'] != (phase == 'train')
                or p['baseline_intent'] != row['selected'] or p['active'] != row['active']):
            errors['mode'] += 1
        try:
            _validate_payload(p)
        except (KeyError, TypeError, ValueError, IndexError, OverflowError):
            errors['payload'] += 1
        names = ('defer', 'proceed')
        baseline = row['selected']
        candidates = {c['id']: c for c in p['candidates']}
        if len(candidates) != len(p['candidates']) or not 2 <= len(candidates) <= 3:
            errors['candidate_set'] += 1
        for i, name in enumerate(names):
            c = candidates[name+'_base']
            for field, recorded in [('target', 'candidate_targets'), ('a', 'candidate_a'), ('delta', 'candidate_delta')]:
                if abs(c[field]-row[recorded][i]) > 1e-8:
                    errors['original_candidate'] += 1
            if c['intent'] != name or c['source'] != 'cg':
                errors['original_candidate'] += 1
        for c in p['candidates'][2:]:
            ratio, audit = float(c['ratio']), c['execution']
            if (not math.isfinite(ratio) or not .5 <= ratio < 1.
                    or abs(ratio*20-round(ratio*20)) > 1e-8
                    or c['intent'] != names[baseline]
                    or abs(c['target']-ratio*row['candidate_targets'][baseline]) > 1e-8
                    or c['source'] != 'parameterized_planner'):
                errors['parameter'] += 1
            gap = audit['proposed_gap']
            gap_ok = audit['unbounded_gap'] if gap is None else math.isfinite(float(gap)) and gap >= .2
            if audit['accepted'] and not (audit['solve_ok'] and audit['forecast_valid'] and audit['stop_feasible'] and gap_ok):
                errors['candidate_guard'] += 1
            qualified = bool(c['solve_ok'] and audit['accepted'] and len(c['components']) == 2
                             and all(x['admissible'] for x in c['components']))
            if c['eligible'] != qualified:
                errors['qualification'] += 1
        request = candidates.get(p['request_id'])
        if request is None or request != p['request']:
            errors['request'] += 1
        else:
            changed = request['id'] != names[baseline]+'_base'
            if (p['changed_request'] != changed or request['intent'] != names[baseline]
                    or p['requested_ratio'] != request.get('ratio', 1.)
                    or changed and (not p['active'] or not request['eligible'])
                    or phase == 'observe' and changed):
                errors['request'] += 1
            for field, saved in [('a', 'pre_audit_a'), ('delta', 'pre_audit_delta'), ('target', 'pre_audit_target')]:
                if not math.isfinite(float(request[field])) or abs(request[field]-row[saved]) > 1e-8:
                    errors['control_authority'] += 1
        beta = p['beta']
        a, b = float(beta['alpha']), float(beta['beta'])
        if (not all(math.isfinite(x) and x >= 1. for x in (a, b))
                or abs(beta['mean']-a/(a+b)) > 1e-10
                or beta['observations'] != a+b-2.
                or beta['calibrated'] or beta['private_intent_identified']
                or beta['model'] != 'exposed_deceleration_probability_beta_v22'):
            errors['beta'] += 1
        for state in p['physical'].values():
            if state is not None:
                if state['beta_true'] is not None or len(state['motion']) != 5:
                    errors['physical_state'] += 1
                for i, value in enumerate(state['motion']):
                    if value is None and i != 3 or value is not None and not math.isfinite(float(value)):
                        errors['physical_state'] += 1
        learning = p['learning']
        source = learning['source']
        if source == 'explore' and phase != 'train':
            errors['exploration_in_frozen_phase'] += 1
        if source == 'takeover':
            base, alt = learning['baseline_bounds'], learning['candidate_bounds']
            if (not learning['certified'] or min(base['n'], alt['n']) < 10
                    or alt['wcv'] is None or base['bcv'] is None or alt['wcv'] <= base['bcv']):
                errors['unsupported_takeover'] += 1
        for field, display in [('a', 'a_prev'), ('df', 'steer_prev')]:
            value, saved = float(p['previous'][field]), float(ego[display])
            if not math.isfinite(value) or not math.isfinite(saved) or abs(round(value, 3)-saved) > 1e-12:
                errors['history'] += 1
            if previous_control is not None and abs(value-previous_control[field]) > 1e-8:
                errors['history_exact'] += 1
        f = p['feedback']
        if (f['requested_ratio'] != p['requested_ratio'] or f['episode'] != row['episode']
                or f['frame'] != row['frame'] or f['guard_action'] != row['guard_action']
                or f['intervention'] != bool(row['guard_override'] or ego.get('guard_unavoidable') == '1')):
            errors['feedback'] += 1
        for field, recorded in [('applied_a', 'applied_a'), ('applied_delta', 'applied_delta'), ('applied_target', 'applied_target')]:
            if abs(f[field]-row[recorded]) > 1e-8:
                errors['feedback'] += 1
        speed, acc = max(0., float(ego['ego_v_after'])), float(ego['a_cmd'])
        expected_reward = .05*(.1*min(speed/4., 1.)-.02-.01*min((acc/3.)**2, 1.)-.02*f['intervention'])
        expected_reward += {None: 0., 'complete': 5., 'collision': -10., 'stuck': -5.}[f['outcome']]
        if not math.isfinite(f['reward']) or abs(f['reward']-expected_reward) > 1e-7:
            errors['realized_reward'] += 1
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        errors['invalid_evolution_record'] += 1
    return dict(errors)
