"""Independent frame ownership and realized-option/checkpoint consistency audit."""
from collections import Counter,defaultdict
import hashlib
import json
import math
from pathlib import Path
from Tools.validate_trajectory_probe_v21 import _validate_payload


REWARD_LEARNER='reward_v36'
ENTRY_LEARNERS=('entry_v35',REWARD_LEARNER)
PAIRED_LEARNERS=('paired_v34',)+ENTRY_LEARNERS
SELECT_FIRST_LEARNERS=('select_first_v33',)+PAIRED_LEARNERS
JOINT_LEARNERS=('joint_v32',)+SELECT_FIRST_LEARNERS


def _road_ok(a):
    return bool(a['accepted'] and a['complete'] and a['checked_points']>0
                and len(a['witness_hash'])==64 and a['reason'] is None)


def _control_evidence(c):
    """Audit v28 provenance independently of the producing helper.

    Legacy records keep their original checks. A failed CG wrapper can remain
    selectable solely to reach the public guard, never as a successful solve.
    """
    e=c['control_evidence']; bounds=e['bounds']
    if (e['revision']!='rolling_control_evidence_v28' or e['optimizer_valid']!=c['solve_ok']
            or e['fallback_only']!=bool(c['action']==0 and not c['solve_ok'])
            or e['requested_first']!=[c['a'],c['delta']] or e['numerical_projection_limit']!=1.e-6
            or len(bounds)!=2 or bounds[0]!=[-3.,2.] or len(bounds[1])!=2
            or not 0.<bounds[1][1]<=1. or bounds[1][0]!=-bounds[1][1]):
        raise ValueError('Invalid control provenance')
    if not all(math.isfinite(v) for v in e['requested_first']+bounds[0]+bounds[1]):
        raise ValueError('Nonfinite control provenance')
    raw=None if c['plan'] is None else [c['plan'][0][0],c['plan'][1][0]]
    if e['raw_first']!=raw: raise ValueError('Raw control not from the hashed plan')
    if not c['solve_ok']:
        if raw is not None or c['prediction'] is not None: raise ValueError('Failed optimizer retained a solved payload')
        return True
    for value,requested,(low,high) in zip(raw,e['requested_first'],bounds):
        projected=min(high,max(low,value))
        if (not math.isfinite(value) or abs(requested-projected)>1.e-10
                or abs(value-requested)>1.e-6):
            return False
    return True


def _signature(expected_learner):
    if expected_learner=='legacy_v24':
        from Planning_library.rolling_learning_v24 import RollingLearner
        return RollingLearner().signature()
    if expected_learner=='cg_v29':
        from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
        return CGTrajectoryLearnerV29().signature()
    if expected_learner=='longitudinal_v31':
        from Planning_library.longitudinal_planner_v31 import LongitudinalLearnerV31
        return LongitudinalLearnerV31().signature()
    if expected_learner=='joint_v32':
        from Planning_library.joint_planner_v32 import JointLearnerV32
        return JointLearnerV32().signature()
    if expected_learner=='select_first_v33':
        from Planning_library.select_first_planner_v33 import SelectFirstLearnerV33
        return SelectFirstLearnerV33().signature()
    if expected_learner=='paired_v34':
        from Planning_library.paired_planner_v34 import PairedLearnerV34
        return PairedLearnerV34().signature()
    if expected_learner=='entry_v35':
        from Planning_library.entry_planner_v35 import EntryLearnerV35
        return EntryLearnerV35().signature()
    if expected_learner==REWARD_LEARNER:
        from Planning_library.reward_planner_v36 import RewardLearnerV36
        return RewardLearnerV36().signature()
    raise ValueError('Unknown expected rolling learner')


def _cg_reference(parts,prior,stratum,count=6):
    """The retained geometry stratum describes context, never the fallback."""
    allowed=parts[3]
    if (len(parts)!=4 or len(parts[0])!=16 or not allowed or 0 not in allowed
            or allowed!=sorted(set(allowed)) or any(a not in range(count) for a in allowed)
            or parts[2]!=stratum or stratum not in allowed or len(prior)!=count):
        return False
    return all(math.isfinite(v) and abs(v-(1./len(allowed) if a in allowed else 0.))<=1.e-12
               for a,v in enumerate(prior))


def select_first_audit_hold(p,previous_audit_hold):
    """Match held CG frames to a verified rejection in the same decision period."""
    return (previous_audit_hold is not None and not p['decision'] and not p['retracted']
            and not p['exact_audit_rejected'] and p['requested_action']==p['actual_action']==0
            and p['allowed']==[0] and p['learning']['requested']!=0
            and previous_audit_hold==(p['generation_id'],p['learning']))


def _validate_learner(p,phase,expected_learner,count,previous_audit_hold=None):
    if expected_learner=='legacy_v24':
        if (p.get('learner_revision','rolling_trajectory_learning_v24')!='rolling_trajectory_learning_v24'
                or 'baseline_action' in p or 'reference_policy' in p):
            raise ValueError('Unexpected learner revision')
        return
    revision={'cg_v29':'cg_trajectory_learning_v29','longitudinal_v31':'cg_longitudinal_learning_v31',
              'joint_v32':'cg_joint_trajectory_learning_v32','select_first_v33':'cg_joint_select_first_v33',
              'paired_v34':'cg_joint_paired_exploration_v34',
              'entry_v35':'cg_joint_reversible_entry_v35',
              REWARD_LEARNER:'cg_joint_task_time_reward_v36'}
    if (expected_learner not in revision or p['learner_revision']!=revision[expected_learner]
            or p['baseline_action']!=0 or p['reference_policy']!='uniform_admissible_v29'):
        raise ValueError('Expected explicit CG baseline learner')
    learning=p['learning'];source=learning['source']
    if source=='inactive':
        if p['actual_action']!=0 or p['requested_action']!=0:
            raise ValueError('Inactive learner cannot replace CG')
        return
    parts=json.loads(learning['state'])
    held_after_rejection=(expected_learner in SELECT_FIRST_LEARNERS and
                          select_first_audit_hold(p,previous_audit_hold))
    if (learning['default']!=0 or learning['baseline_action']!=0
            or learning['reference_policy']!='uniform_admissible_v29'
            or not _cg_reference(parts,learning['prior'],learning['proposal_geometry_stratum'],count)
            or source not in ('cg_default','observe_cg','takeover','explore')
            or (learning['requested']!=p['requested_action'] and not held_after_rejection)):
        raise ValueError('Invalid CG learning baseline/reference')
    if p['decision']:
        costs={c['action']:c['cost'] for c in p['candidates']}
        if (parts[3]!=p['allowed'] or parts[2]!=min(p['allowed'],key=lambda a:(costs[a],a))):
            raise ValueError('Proposal geometry stratum differs from observed candidates')
    if source in ('cg_default','observe_cg') and learning['requested']!=0:
        raise ValueError('Untrusted learning action replaced CG')
    if source=='explore' and (phase!='train' or not 0.<learning['epsilon']<=1.):
        raise ValueError('Exploration outside training')
    if source=='takeover':
        chosen=learning['bounds'][str(learning['requested'])];base=learning['bounds']['0']
        if (not learning['certified'] or learning['requested']==0
                or min(chosen['n'],base['n'])<10 or chosen['wcv'] is None or base['bcv'] is None
                or not chosen['wcv']>base['bcv']):
            raise ValueError('Takeover lacks empirical advantage over CG')


def _joint_origin(row,p,c,expected_learner):
    from Planning_library.joint_planner_v32 import JointLearnerV32, SPEEDS
    action=c['action']
    if expected_learner in ENTRY_LEARNERS:
        from Planning_library.entry_planner_v35 import CREEP_SPEED, EntryPlannerV35
        if action==EntryPlannerV35.CREEP_ACTION:
            return (row['selected']==0 and row['active'] and row['phase']=='approach'
                    and row['standoff']>0. and row['candidate_targets'][0]<=.01
                    and row['candidate_targets'][1]>=CREEP_SPEED
                    and c['id']==EntryPlannerV35.LEARNER_CLASS.ACTION_NAMES[action]
                    and c['path_hash']==p['baseline_path_hash'] and c['lateral_offset_m'] is None
                    and c['target']==c['speed_option_mps']==CREEP_SPEED and c['intent']=='defer'),False
    offset,speed=JointLearnerV32.ACTION_PAIRS[action]
    baseline_target=row['candidate_targets'][row['selected']]
    expected_target=baseline_target if speed is None else speed
    entering=row['selected']==0 and speed is not None
    expected_intent='proceed' if entering or row['selected']==1 else 'defer'
    valid=(row['active'] and row['phase']=='approach' and row['standoff']>0.
           and c['id']==JointLearnerV32.ACTION_NAMES[action] and c['lateral_offset_m']==offset
           and c['speed_option_mps']==speed and c['intent']==expected_intent
           and math.isclose(c['target'],expected_target,rel_tol=0.,abs_tol=1.e-8)
           and .2<=expected_target<=row['candidate_targets'][1]+1.e-8
           and (speed is None or abs(speed-baseline_target)>1.e-8))
    if offset is None:
        valid=valid and c['path_hash']==p['baseline_path_hash']
    else:
        proposal=next(item for item in p['proposals'] if item['action']==action//len(SPEEDS))
        valid=(valid and proposal['offset_m']==offset and proposal['path_hash']==c['path_hash']
               and proposal['status']=='ready' and _road_ok(proposal['path_road'])
               and proposal['max_curvature']<=proposal['curvature_limit'])
    return valid,entering


def _joint_candidate(row,p,c,eligible,expected_learner):
    valid,entering=_joint_origin(row,p,c,expected_learner)
    horizon=6.
    if expected_learner in ENTRY_LEARNERS:
        from Planning_library.entry_planner_v35 import MERGE_HORIZON, STOP_RESERVE, STOP_SPEED, EntryPlannerV35
        if c['action']==EntryPlannerV35.CREEP_ACTION:
            review=c['entry_review']
            traces=review['forecasts']
            stopped=len(traces)==2 and all(t['valid'] and t['entered_at'] is None
                and t['min_standoff']>=STOP_RESERVE and 0.<=t['end_speed']<=STOP_SPEED for t in traces)
            valid=valid and review['mode']=='creep' and review['prefix_s']==.5 and review['accepted']==stopped
            gaps_ok=len(c['components'])==2 and all(part['min_gap'] is None or part['min_gap']>=.2
                                                    for part in c['components'])
            return valid,bool(eligible and gaps_ok and stopped)
        if entering:
            review=c['entry_review']
            horizon=review['horizon_s']
            valid=valid and review['mode']=='merge' and horizon in (6.,MERGE_HORIZON)
            valid=valid and all(f['horizon']==horizon for part in c['components'] for f in part['forecasts'])
    if entering:
        eligible=(eligible and len(c['components'])==2 and all(
            part['min_gap'] is None or part['min_gap']>=.2 for part in c['components'])
            and len(c['crossings'])==2 and all(start is not None and end is not None
                and 0.<=start<=end<=horizon for start,end in c['crossings']))
    return valid,bool(eligible)


def _select_first_proof(row,p,by_action,errors,expected_learner):
    requested,actual=p['requested_action'],p['actual_action']
    proof=p['verified_candidate']
    reused=p['reused_cg_index']
    for action,option in by_action.items():
        if action and (not option['screened'] or not option['eligible'] or not _joint_origin(row,p,option,expected_learner)[0]):
            errors['joint_screen']+=1
    if p['extra_solve_count']!=int(bool(requested) and reused is None) or actual not in (0,requested):
        errors['select_first_solve_count']+=1
    if requested:
        screen=by_action[requested]
        if any(proof[field]!=screen[field] for field in ('action','target','path_hash','id','intent')):
            errors['select_first_proof']+=1
        if reused is not None:
            original=p['base_candidates'][1]
            if (reused!=1 or row['selected']!=0 or screen['lateral_offset_m'] is not None or not original['solve_ok']
                    or any(proof[field]!=original[field] for field in
                        ('target','path_hash','plan_hash','prediction_hash','times','a','delta'))):
                errors['select_first_reuse']+=1
        if p['exact_audit_rejected']!= (not proof['eligible']) or (not proof['eligible'] and actual):
            errors['select_first_proof']+=1
        if p['retracted']!=(actual==0): errors['select_first_proof']+=1
    elif proof is not None or reused is not None or p['exact_audit_rejected'] or p['retracted']:
        errors['select_first_proof']+=1
    return proof


def validate_rolling_record(row,ego,phase,previous_control=None,expected_learner='legacy_v24',previous_audit_hold=None):
    errors=Counter()
    longitudinal=expected_learner=='longitudinal_v31'
    joint=expected_learner in JOINT_LEARNERS
    select_first=expected_learner in SELECT_FIRST_LEARNERS
    count=2 if longitudinal else 6
    if joint:
        from Planning_library.joint_planner_v32 import JointLearnerV32
        count=len(JointLearnerV32.ACTION_PAIRS)+int(expected_learner in ENTRY_LEARNERS)
    try:
        p=row['rolling_trajectory']
        try:_validate_learner(p,phase,expected_learner,count,previous_audit_hold)
        except (KeyError,ValueError,TypeError,IndexError):errors['learner_contract']+=1
        if (p['revision']!='rolling_trajectory_v24' or p['phase']!=phase or p['efe_enabled']
                or p['learning_enabled']!=(phase=='train') or not p['final_reviewed']
                or p['baseline_intent']!=row['selected'] or p['active']!=row['active']): errors['mode']+=1
        if p.get('execution_revision') is not None:
            if (p['execution_revision']!='isolated_cg_v25' or len(p['cg_reference_hash'])!=64
                    or p['cg_reference_hash']!=p['baseline_path_hash']):
                errors['isolated_cg_reference']+=1
        if len(p['learning_context'])!=16 or any(not math.isfinite(v) for v in p['learning_context']):
            errors['learning_context']+=1
        cs=p['candidates']; by_action={c['action']:c for c in cs}
        if len(by_action)!=len(cs) or 0 not in by_action or any(a not in range(count) for a in by_action):
            errors['candidate_set']+=1
        proof=_select_first_proof(row,p,by_action,errors,expected_learner) if select_first else None
        audited=[by_action[0]]+([proof] if proof is not None else []) if select_first else cs
        for c in audited:
            payload_candidate=c; first_ok=None
            if 'control_evidence' in c:
                try:
                    first_ok=_control_evidence(c)
                    if c['control_evidence']['fallback_only']:
                        # eligible denotes ownership of the CG wrapper here;
                        # optimization evidence is explicitly invalid.
                        payload_candidate=dict(c,eligible=False)
                        if p['actual_action']==0 and (not row['guard_override'] or row['guard_action'] not in ('brake','clear')):
                            errors['fallback_execution']+=1
                except (KeyError,TypeError,ValueError,IndexError): errors['control_evidence']+=1
            try: _validate_payload(dict(path=c['path'],path_hash=c['path_hash'],candidates=[payload_candidate]))
            except (KeyError,TypeError,ValueError,IndexError): errors['path_plan_payload']+=1
            if c['solve_ok'] and (first_ok is False or first_ok is None and
                    (abs(c['plan'][0][0]-c['a'])>1e-8 or abs(c['plan'][1][0]-c['delta'])>1e-8)):
                errors['first_control']+=1
            reference=1 if longitudinal and c['action'] else row['selected']
            if (not joint or not c['action']) and abs(c['target']-row['candidate_targets'][reference])>1e-8:
                errors['intent_speed']+=1
            if c['action']:
                ex=c['execution']; gap=ex['proposed_gap']
                gap_ok=ex['unbounded_gap'] if gap is None else math.isfinite(gap) and gap>=.2
                if ex['accepted'] and not (ex['solve_ok'] and ex['forecast_valid'] and ex['stop_feasible'] and gap_ok):
                    errors['execution_acceptance']+=1
                eligible=bool(c['solve_ok'] and ex['accepted'] and len(c['road_predictions'])==3
                    and all(_road_ok(a) for a in c['road_predictions']) and all(a['admissible'] for a in c['components']))
                if joint:
                    origin,eligible=_joint_candidate(row,p,c,eligible,expected_learner)
                    if not origin: errors['joint_candidate_origin']+=1
                    if eligible!=c['eligible']: errors['candidate_qualification']+=1
                elif longitudinal:
                    original=p['base_candidates'][1]
                    same_plan=all(c[k]==original[k] for k in ('target','a','delta','path_hash','plan_hash',
                                                              'prediction_hash','times','solve_ok'))
                    if (not same_plan or not row['active'] or row['phase']!='approach' or row['standoff']<=0.
                            or row['selected']!=0 or c['intent']!='proceed' or c['id']!='enter_cg_speed'
                            or c['source']!='cg_proceed_reuse'):
                        errors['longitudinal_origin']+=1
                    eligible=bool(eligible and len(c['components'])==2 and all(
                        part['min_gap'] is None or part['min_gap']>=.2 for part in c['components'])
                        and len(c['crossings'])==2 and all(t[0] is not None and t[1] is not None
                            and 0.<=t[0]<=t[1]<=6. for t in c['crossings']))
                    if eligible!=c['eligible']: errors['candidate_qualification']+=1
                else:
                    proposal=next(a for a in p['proposals'] if a['action']==c['action'])
                    if (eligible!=c['eligible'] or proposal['status']!='ready' or not _road_ok(proposal['path_road'])
                            or proposal['max_curvature']>proposal['curvature_limit']): errors['candidate_qualification']+=1
        if p['allowed']!=sorted(c['action'] for c in cs if c['eligible']): errors['allowed']+=1
        for i,c in enumerate(p['base_candidates']):
            if c['path_hash']!=p['baseline_path_hash']: errors['cg_path']+=1
            for field,key in [('target','candidate_targets'),('a','candidate_a'),('delta','candidate_delta')]:
                if abs(c[field]-row[key][i])>1e-8: errors['cg_candidate']+=1
        request=proof if select_first and p['actual_action'] else by_action[p['actual_action']]
        if joint and p['actual_action'] and (row['guard_override'] or not row['guard_safe']
                or row['guard_action']!='mpc' or ego.get('feasibility_phase')!=
                ('entering' if request['intent']=='proceed' else 'waiting')):
            errors['joint_execution']+=1
        if longitudinal and p['actual_action']==1 and (row['guard_override'] or not row['guard_safe']
                or row['guard_action']!='mpc' or ego.get('feasibility_phase')!='entering'):
            errors['longitudinal_execution']+=1
        if (request!=p['request'] or request['id']!=p['request_id']
                or bool(p['actual_action'])!=p['changed_request']
                or p['actual_action'] not in p['allowed'] or phase=='observe' and p['actual_action']!=0):
            errors['request_owner']+=1
        for field,key in [('a','pre_audit_a'),('delta','pre_audit_delta'),('target','pre_audit_target')]:
            if abs(request[field]-row[key])>1e-8: errors['request_control']+=1
        for field,key in [('a','a_prev'),('df','steer_prev')]:
            value=float(p['previous'][field]); display=float(ego[key])
            if not math.isfinite(value) or abs(round(value,3)-display)>1e-12: errors['previous_control']+=1
            if previous_control is not None and abs(value-previous_control[field])>1e-8:
                errors['previous_control_exact']+=1
        f=p['feedback']
        if (f['episode']!=row['episode'] or f['frame']!=row['frame'] or f['actual_action']!=p['actual_action']
                or f['guard_action']!=row['guard_action']): errors['feedback_owner']+=1
        for key in ('applied_a','applied_delta','applied_target'):
            if abs(f[key]-row[key])>1e-8: errors['feedback_control']+=1
        if expected_learner in PAIRED_LEARNERS and phase=='train' and p['retracted']:
            if f['credited_state'] is None or json.loads(f['credited_state'])[3]!=[0]:
                errors['paired_fallback_credit']+=1
        acc=float(row['applied_a'])
        if expected_learner==REWARD_LEARNER:
            rate=-.06-.01*min((acc/3.)**2,1.)-.02*bool(f['intervention'])
        else:
            speed=max(0.,float(ego['ego_v_after']))
            rate=.1*min(speed/4.,1.)-.02-.01*min((acc/3.)**2,1.)-.02*bool(f['intervention'])
        reward=.05*rate+{None:0.,'complete':5.,'collision':-10.,'stuck':-5.}[f['outcome']]
        if not math.isfinite(reward) or not math.isfinite(f['reward']) or abs(reward-f['reward'])>1e-6:
            errors['measured_reward']+=1
    except (KeyError,ValueError,TypeError,IndexError,OverflowError,StopIteration): errors['invalid_record']+=1
    return dict(errors)


def validate_rolling_experience(directory,records,phase,expected_learner='legacy_v24'):
    """Match each saved option to chronological actual controls and rewards."""
    errors=Counter(); path=Path(directory)
    counts=Counter(); actions=Counter(); seen_states=set(); expected=[]; pending=None
    model=None; creep_episodes=set()
    if expected_learner in ENTRY_LEARNERS:
        from Planning_library.entry_planner_v35 import EntryPlannerV35, MERGE_HORIZON
        creep=EntryPlannerV35.CREEP_ACTION
    episode_scores=defaultdict(list)
    episode_score,episode_discount=0.,1.
    try:
        signature=_signature(expected_learner)
        gamma=signature['gamma']
        if expected_learner in ('cg_v29','longitudinal_v31')+JOINT_LEARNERS:
            meta=json.loads((path/'rolling_metadata_v24.json').read_text(encoding='utf8'))
            if (meta['signature']!=signature or meta['learner_revision']!=signature['schema']
                    or meta['baseline_action']!=0 or meta['reference_policy']!='uniform_admissible_v29'):
                errors['metadata_signature']+=1
        for row in records:
            p=row['rolling_trajectory']; f=p['feedback']
            counts['rows']+=1; counts['decisions']+=bool(p['decision'])
            counts['changed_requests']+=bool(p['changed_request']); counts['retracted_requests']+=bool(p['retracted'])
            counts['eligible_candidates']+=sum(c['action']!=0 and c['eligible'] for c in p['candidates'])
            if expected_learner=='longitudinal_v31':
                counts['eligible_entry_decisions']+=bool(p['decision'] and 1 in p['allowed'])
            if expected_learner in JOINT_LEARNERS:
                counts['eligible_joint_decisions']+=bool(p['decision'] and len(p['allowed'])>1)
            if expected_learner in SELECT_FIRST_LEARNERS:
                counts['extra_mpc_solves']+=p['extra_solve_count']
                counts['selected_exact_audit_rejections']+=bool(p['exact_audit_rejected'])
                counts['reused_cg_proceed']+=p['reused_cg_index'] is not None
            if expected_learner in ENTRY_LEARNERS:
                review=(p['verified_candidate'] or {}).get('entry_review',{})
                counts['entry_creep_screened_decisions']+=bool(p['decision'] and creep in p['allowed'])
                counts['entry_creep_requested_frames']+=p['requested_action']==creep
                counts['entry_creep_executed_frames']+=p['actual_action']==creep
                counts['entry_extended_merge_audits']+=review.get('horizon_s')==MERGE_HORIZON
                counts['entry_extended_merge_executed_frames']+=bool(review.get('horizon_s')==MERGE_HORIZON and p['actual_action'])
                if p['actual_action']==creep: creep_episodes.add(row['episode'])
            counts['takeovers']+=bool(p['decision'] and p['learning']['source']=='takeover')
            counts['explorations']+=bool(p['decision'] and p['learning']['source']=='explore')
            counts['beta_observations']+=bool(p['beta']['evidence_applied'])
            counts['observed_road_rejections']+=bool(f['observed_body'] is not None and not f['observed_body']['accepted'])
            actions[str(p['actual_action'])]+=1
            if expected_learner==REWARD_LEARNER:
                episode_score+=episode_discount*f['reward']; episode_discount*=gamma
                if f['outcome'] is not None:
                    episode_scores[f['outcome']].append(episode_score)
                    episode_score,episode_discount=0.,1.
            if f['credited_state'] is None: continue
            seen_states.add(f['credited_state'])
            if f['option_started']:
                if pending is not None:
                    # A newly sampled decision closes the previous option before MPC can retract it.
                    decided_then_retracted=(expected_learner in PAIRED_LEARNERS and phase=='train'
                                              and p['decision'] and p['retracted'])
                    next_state=p['learning']['state'] if decided_then_retracted else f['credited_state']
                    expected.append(dict(pending,next=next_state))
                pending=dict(state=f['credited_state'],action=f['actual_action'],episode=f['credited_episode'],
                             reward=0.,discount=1.,steps=0,interventions=0)
            if pending is None: errors['missing_option_start']+=1; continue
            if pending['action']!=f['actual_action']: errors['mixed_action_credit']+=1
            pending['reward']+=pending['discount']*f['reward']; pending['discount']*=gamma
            pending['steps']+=1; pending['interventions']+=int(bool(f['intervention']))
            if f['outcome'] is not None:
                expected.append(dict(pending,next=None)); pending=None
        if phase=='train':
            model=json.loads((path/'rolling_model/rolling_model.json').read_text(encoding='utf8'))
            if len(expected)!=len(model['records']): errors['transition_count']+=1
            for actual,saved in zip(expected,model['records']):
                for key in ('state','action','episode','next','steps','interventions'):
                    if actual[key]!=saved[key]: errors['transition_'+key]+=1
                for key in ('reward','discount'):
                    if not math.isclose(actual[key],saved[key],rel_tol=1e-10,abs_tol=1e-10):
                        errors['transition_'+key]+=1
            counts['transition_records']=len(model['records'])
            if pending is not None: errors['unfinished_option']+=1
        elif phase=='eval':
            frozen=path/'rolling_model/frozen_input.json'
            meta=json.loads((path/'rolling_metadata_v24.json').read_text(encoding='utf8'))
            if hashlib.sha256(frozen.read_bytes()).hexdigest()!=meta['checkpoint_sha256']:
                errors['frozen_input_hash']+=1
            if (path/'rolling_model/rolling_model.json').exists(): errors['eval_model_write']+=1
            model=json.loads(frozen.read_text(encoding='utf8'))
        if model is not None:
            if model['signature']!=signature: errors['model_signature']+=1
            if expected_learner in ('cg_v29','longitudinal_v31')+JOINT_LEARNERS:
                for key,node in model['nodes'].items():
                    parts=json.loads(key)
                    if (node['default']!=0 or node['allowed']!=parts[3]
                            or not _cg_reference(parts,node['prior'],node['proposal_geometry_stratum'],len(signature['actions']))):
                        errors['model_cg_reference']+=1
            if any(len(v)!=len(signature['actions']) or any(not math.isfinite(q) for q in v) for v in model['q'].values()):
                errors['model_values']+=1
            pair_episodes=defaultdict(set)
            for r in model['records']: pair_episodes[r['state'],r['action']].add(r['episode'])
            counts['trained_states']=len(model['nodes'])
            counts['covered_state_action_pairs']=sum(len(eps)>=10 for eps in pair_episodes.values())
            counts['max_state_action_episodes']=max(map(len,pair_episodes.values()),default=0)
            if expected_learner=='longitudinal_v31':
                counts['entry_training_records']=sum(r['action']==1 for r in model['records'])
                counts['paired_entry_states']=sum(min(len(pair_episodes.get((key,0),())),
                    len(pair_episodes.get((key,1),())))>=10 for key in model['nodes'])
            if expected_learner in JOINT_LEARNERS:
                counts['joint_training_records']=sum(r['action']!=0 for r in model['records'])
                states_with_alt={key for (key,action),eps in pair_episodes.items() if action!=0 and len(eps)>=10}
                counts['paired_joint_states']=sum(len(pair_episodes.get((key,0),()))>=10
                                                  for key in states_with_alt)
            if expected_learner in PAIRED_LEARNERS:
                from Tools.paired_coverage_v34 import paired_coverage
                counts.update(paired_coverage(model['records']))
            if expected_learner in ENTRY_LEARNERS:
                counts['entry_creep_execution_episodes']=len(creep_episodes)
                counts['entry_creep_training_records']=sum(r['action']==creep for r in model['records'])
                counts['entry_creep_paired_support_max']=max((min(len(eps),len(pair_episodes.get((state,0),())))
                    for (state,action),eps in pair_episodes.items() if action==creep),default=0)
        if expected_learner==REWARD_LEARNER:
            completed,stuck=episode_scores['complete'],episode_scores['stuck']
            counts['reward_complete_stuck_pairs']=len(completed)*len(stuck)
            counts['reward_complete_stuck_order_violations']=sum(
                successful<=stalled for successful in completed for stalled in stuck)
    except (OSError,KeyError,ValueError,TypeError,IndexError,OverflowError): errors['invalid_experience']+=1
    return dict(rolling_experience_contract_ok=not errors,rolling_experience_errors=dict(errors),
        rolling_counts=dict(counts),rolling_actual_actions=dict(actions),rolling_seen_states=len(seen_states),
        confidence_guarantee=False,learning_benefit_established=False)
