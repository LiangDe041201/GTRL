"""Validate v8 execution evidence, separately from task success or game gains."""
import math
from collections import Counter


def number(row, key):
    try:
        value = float(row.get(key, ''))
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def validate_control_health(rows, outcomes, traffic='on', require_probe=False, profile='paper_v8', probe_cruise_speed=None):
    revised = profile in ('paper_v9', 'paper_v10', 'paper_v11')
    violations = Counter()
    unsafe, unclassified, overrides = 0, 0, 0
    errors, max_stop = [], 0
    current_stop, last_episode = 0, None
    probes = {}
    moving_started = False
    for row in rows:
        if row.get('control_profile') != profile or row.get('actuator_mode') != (
                'feedback_pedal_'+profile[6:] if profile in ('paper_v10', 'paper_v11') else (
                'feedback_pedal_v9' if revised else 'ackermann')):
            violations['actuator_profile'] += 1
        dt = number(row, 'sim_dt')
        before, after = number(row, 'sim_frame_before'), number(row, 'sim_frame_after')
        if dt is None or abs(dt-.05) > .0001 or before is None or after is None or after-before != 1:
            violations['simulator_tick'] += 1
        v0, v1 = number(row, 'ego_v_before'), number(row, 'ego_v_after')
        actual, command = number(row, 'ego_acc_measured'), number(row, 'a_cmd')
        if any(v is None for v in (v0, v1, actual, command)):
            violations['missing_motion'] += 1
        elif dt is not None and dt > 0.:
            if abs((v1-v0)/dt-actual) > .001:
                violations['acceleration_alignment'] += 1
            errors.append(actual-command)
        target, limit = number(row, 'actuator_speed_target'), number(row, 'actuator_accel_limit')
        if target is None or target < 0. or limit is None or not .049 <= limit <= 3.001:
            violations['ackermann_request'] += 1
        if revised:
            if profile in ('paper_v10', 'paper_v11'):
                if row.get('control_transport') != 'batch_sync_pre_tick' or row.get('control_submit_ok') != '1':
                    violations['control_submission'] += 1
                if number(row, 'control_tick_frame') != after or number(row, 'control_feedback_frame') != after:
                    violations['control_frame_alignment'] += 1
                substep = number(row, 'physics_max_substep_dt')
                if substep is None or abs(substep-.005) > 1e-6:
                    violations['physics_substep'] += 1
            signed0, signed1 = number(row, 'ego_v_signed_before'), number(row, 'ego_v_signed_after')
            signed_acc = number(row, 'ego_acc_signed')
            if any(v is None for v in (signed0, signed1, signed_acc, number(row, 'ego_acc_sensor'))):
                violations['missing_signed_motion'] += 1
            elif dt is not None and dt > 0. and abs((signed1-signed0)/dt-signed_acc) > .001:
                violations['signed_acceleration_alignment'] += 1
            if signed1 is not None and signed1 < -.1:
                violations['backward_motion'] += 1
            pedals = {key: number(row, key) for key in ('throttle', 'brake', 'steer')}
            for key, value in pedals.items():
                requested = number(row, 'requested_'+key)
                if value is None or requested is None or abs(value-requested) > .00001:
                    violations['pedal_feedback_'+key] += 1
            throttle, brake = pedals['throttle'], pedals['brake']
            if throttle is not None and brake is not None:
                if throttle > .000001 and brake > .000001:
                    violations['pedal_overlap'] += 1
                if throttle > .000001 and (target is not None and target <= .01 or
                                           command is not None and command < -.02):
                    violations['throttle_during_braking'] += 1
            if row.get('reverse') != '0' or row.get('hand_brake') != '0' or row.get('manual_gear_shift') != '0':
                violations['drivetrain_flags'] += 1
            gear = number(row, 'gear')
            if gear is None or gear < 0.:
                violations['gear'] += 1
        safe, unavoidable = row.get('guard_safe'), row.get('guard_unavoidable')
        if safe not in ('0', '1') or unavoidable not in ('0', '1') or not row.get('guard_action'):
            violations['missing_audit'] += 1
        unsafe += safe == '0'
        unclassified += safe == '0' and unavoidable != '1'
        overrides += row.get('mpc_audit_override') == '1'
        if row.get('episode') != last_episode:
            current_stop, last_episode = 0, row.get('episode')
            moving_started = False
        moving_started = moving_started or (v1 is not None and v1 >= .1)
        remaining = number(row, 'goal_remaining')
        phase = row.get('control_probe_phase', '')
        probe = probes.setdefault(row.get('episode'), dict(stop_frames=0, stopped=False,
                                                          recovered=False, recovery_frames=0))
        if phase == 'stop':
            probe['stop_frames'] += 1
            probe['stopped'] = probe['stopped'] or (v1 is not None and v1 < .1)
        elif phase == 'recovery':
            probe['recovery_frames'] += 1
            probe['recovered'] = probe['recovered'] or (v1 is not None and v1 >= 1.)
        count_stall = (moving_started and phase not in ('startup', 'decelerate', 'hold', 'recovery', 'failed')) if revised else phase != 'stop'
        if count_stall and v1 is not None and v1 < .1 and remaining is not None and remaining > 5.:
            current_stop += 1
            max_stop = max(max_stop, current_stop)
        else:
            current_stop = 0
    contract = bool(rows) and not violations and unclassified == 0
    failures = sum(row.get('mpc_solve_ok') == '0' for row in rows)
    harsh = sum((number(row, 'ego_acc_measured') or 0.) < -6. for row in rows)
    surges = sum((number(row, 'ego_acc_measured') or 0.) > 6. for row in rows)
    result = dict(actuator_contract_ok=contract, actuator_contract_errors=dict(violations),
        guard_unsafe_rows=unsafe, guard_unclassified_unsafe_rows=unclassified,
        guard_override_rows=overrides, guard_actions=dict(Counter(r.get('guard_action', '') for r in rows)),
        measured_acceleration_rmse=math.sqrt(sum(e*e for e in errors)/len(errors)) if errors else None,
        severe_deceleration_rows=harsh, severe_acceleration_rows=surges,
        longest_non_goal_stop_s=max_stop*.05,
        task_success_episodes=int(outcomes.get('complete', 0)),
        task_collision_episodes=int(outcomes.get('collision', 0)), control_probes=probes)
    if traffic == 'off':
        # A gate may not be validated using traffic collisions. Require the
        # common control to first complete empty-road turns without stall loops.
        probe_ok = not require_probe or (bool(probes) and all(p['stop_frames'] == 40 and p['stopped'] and
            p['recovered'] for p in probes.values()))
        result['empty_road_health_ok'] = bool(contract and probe_ok and outcomes and
            set(outcomes) == {'complete'} and failures == 0 and unsafe == 0 and
            harsh == 0 and max_stop*.05 <= 1.)
    if revised:
        result['control_probes'] = _measured_probes(rows, probe_cruise_speed)
        if traffic == 'off':
            reasons = []
            if not contract:
                reasons.append('actuator_contract')
            if require_probe and (not result['control_probes'] or
                    any(not probe['ok'] for probe in result['control_probes'].values())):
                reasons.append('stop_restart_probe')
            if not outcomes or set(outcomes) != {'complete'}:
                reasons.append('task_outcome')
            if failures:
                reasons.append('mpc_failure')
            if unsafe:
                reasons.append('execution_unsafe')
            if harsh:
                reasons.append('severe_deceleration')
            if profile == 'paper_v11' and surges:
                reasons.append('severe_acceleration')
            if max_stop*.05 > 1.:
                reasons.append('unexpected_stop')
            result.update(empty_road_health_errors=reasons, empty_road_health_ok=not reasons)
    return result


def _measured_probes(rows, cruise_speed=None):
    """Reconstruct phase order, deadlines and stability from measured CSV rows.

    Recompute evidence independently of the controller's phase transitions;
    a printed phase name or an omitted failure flag cannot prove a stop.
    """
    groups = {}
    for row in rows:
        groups.setdefault(row.get('episode'), []).append(row)
    result = {}
    expected = ['startup', 'cruise', 'decelerate', 'hold', 'recovery', 'done']
    for episode, episode_rows in groups.items():
        phases, blocks, errors = [], {}, []
        for row in episode_rows:
            phase = row.get('control_probe_phase', '')
            if phase not in expected:
                if phase == 'failed' or row.get('control_probe_failure'):
                    errors.append(row.get('control_probe_failure') or 'failed')
                continue
            if not phases or phases[-1] != phase:
                phases.append(phase)
            blocks.setdefault(phase, []).append(row)
            if row.get('control_probe_failure'):
                errors.append(row['control_probe_failure'])
        if not phases:
            continue
        if phases != expected:
            errors.append('phase_order_or_incomplete')
        durations = {phase: sum(number(r, 'sim_dt') or 0. for r in block)
                     for phase, block in blocks.items()}
        for phase, deadline in [('startup', 5.), ('cruise', 5.), ('decelerate', 4.), ('recovery', 3.)]:
            if durations.get(phase, 0.) > deadline+.0001:
                errors.append(phase+'_timeout')
        for phase, threshold, high in [('startup', 1., True), ('decelerate', .1, False), ('recovery', 1., True)]:
            stable = 0.
            for row in reversed(blocks.get(phase, [])):
                speed = number(row, 'ego_v_after')
                if speed is None or not (speed >= threshold if high else speed < threshold):
                    break
                stable += number(row, 'sim_dt') or 0.
            if stable < .25-.0001:
                errors.append(phase+'_not_stable')
        if cruise_speed is not None:
            stable = 0.
            for row in reversed(blocks.get('cruise', [])):
                speed = number(row, 'ego_v_after')
                if speed is None or speed < .8*cruise_speed:
                    break
                stable += number(row, 'sim_dt') or 0.
            if stable < .5-.0001:
                errors.append('cruise_speed_not_reached')
            if any(number(row, 'actuator_speed_target') is None or
                   number(row, 'actuator_speed_target') > cruise_speed+.001 for row in episode_rows
                   if row.get('control_probe_phase') in ('startup', 'cruise', 'recovery')):
                errors.append('cruise_speed_cap')
        hold = blocks.get('hold', [])
        if durations.get('hold', 0.) < .5-.0001 or any(
                number(row, 'ego_v_after') is None or number(row, 'ego_v_after') >= .1 for row in hold):
            errors.append('hold_not_stationary')
        for phase in ('decelerate', 'hold'):
            if any(number(row, 'actuator_speed_target') is None or number(row, 'actuator_speed_target') > .01
                   for row in blocks.get(phase, [])):
                errors.append(phase+'_target_not_zero')
        for phase in ('startup', 'cruise', 'recovery'):
            if any(number(row, 'actuator_speed_target') is None or number(row, 'actuator_speed_target') <= .01
                   for row in blocks.get(phase, [])):
                errors.append(phase+'_target_not_positive')
        result[episode] = dict(ok=not errors, errors=sorted(set(errors)), phases=phases,
            requested_cruise_speed=cruise_speed,
            phase_seconds=durations, stopped='decelerate_not_stable' not in errors and bool(hold),
            recovered='recovery_not_stable' not in errors and 'done' in phases)
    return result
