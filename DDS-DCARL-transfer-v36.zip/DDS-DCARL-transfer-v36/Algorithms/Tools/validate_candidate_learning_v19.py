"""Independent stdlib audit of executed candidate learning, not benefit claims."""
from collections import Counter,defaultdict
import hashlib
import json
import math
from pathlib import Path


def distribution(p,n):
    if len(p)!=n or any(not math.isfinite(float(x)) or x<0. for x in p) or abs(sum(p)-1.)>1e-7:
        raise ValueError('Invalid probability distribution')
    return p


def entropy(p):
    return -sum(x*math.log(x) for x in p if x>0.)


def kl(p,p0):
    if any(x>0. and y<=0. for x,y in zip(p,p0)):
        raise ValueError('Policy outside reference support')
    return sum(x*math.log(x/y) for x,y in zip(p,p0) if x>0.)


def close(a,b,tolerance=3e-5):
    return math.isfinite(float(a)) and math.isfinite(float(b)) and abs(float(a)-float(b))<=tolerance


def validate_candidate_learning(directory,ego_rows):
    root=Path(directory)
    errors=Counter();seen=set();active=decisions=takeovers=explores=unseen=updates=interventions=0
    samples=[];rows=[];model={};state_count=transitions=0;recursive=False
    try:
        metadata=json.loads((root/'candidate_learning_metadata.json').read_text(encoding='utf8'))
        config,phase=metadata['config'],metadata['phase']
        signature=metadata['model_signature']
        version20=metadata['revision']=='candidate_learning_v20'
        schema='executable_candidate_soft_v20' if version20 else 'guarded_candidate_soft_v19'
        if (metadata['revision'] not in ('candidate_learning_v19','candidate_learning_v20') or phase not in ('train','eval')
                or metadata['confidence_guarantee'] is not False or metadata['calibrated'] is not False
                or signature['schema']!=schema
                or signature['filter_contract']!=config):
            raise ValueError('Incorrect declared learning scope/signature')
        pref=distribution(config['preference'],4)
        gamma,alpha=signature['gamma'],signature['alpha']
        if not close(gamma,2.**(-config['dt']/config['half_life_seconds']),1e-12):
            raise ValueError('Physical discount differs from checkpoint')
        model_path=root/'candidate_model'/('frozen_input.json' if phase=='eval' else 'belief_soft_model.json')
        if phase=='eval' and hashlib.sha256(model_path.read_bytes()).hexdigest()!=metadata['checkpoint_sha256']:
            raise ValueError('Frozen checkpoint changed')
        model=json.loads(model_path.read_text(encoding='utf8'))
        if model['signature']!=signature:raise ValueError('Model/metadata signature mismatch')
        nodes,values,records=model['nodes'],model['q'],model['records']
        state_count,transitions=len(nodes),len(records)
        for key,node in nodes.items():
            distribution(node['belief'],6);distribution(node['prior'],2)
            if len(node['context'])!=10 or len(values[key])!=2 or not all(math.isfinite(x) for x in values[key]):
                raise ValueError('Invalid state/value dimensions')
        for r in records:
            if (r['state'] not in nodes or r['action'] not in nodes[r['state']]['allowed'] or r['steps']<1
                    or not close(r['discount'],gamma**r['steps'],1e-10)
                    or not math.isfinite(r['reward']) or not math.isfinite(r['mc_behavior_return'])
                    or not 0<=r['intervention_steps']<=r['steps']
                    or r['next'] is not None and r['next'] not in nodes):
                raise ValueError('Invalid guarded request transition')
        recursive=any(r['next'] is not None for r in records)
        if phase=='train':
            logged=[json.loads(s) for s in (root/'candidate_model/belief_transitions.jsonl').read_text(encoding='utf8').splitlines()]
            if logged!=records or not records or not model['sweeps']:
                raise ValueError('Training did not save consistent learned transitions')
        expected={(int(r['episode']),int(r['frame'])):r for r in ego_rows}
        rows=[json.loads(s) for s in (root/'candidate_learning.jsonl').read_text(encoding='utf8').splitlines()]
        for row in rows:
            try:
                key=int(row['episode']),int(row['frame'])
                ego=expected[key]
                if key in seen:errors['duplicate_frame']+=1
                seen.add(key)
                if row['phase']!=phase or row['posterior_action_queue'] is not False:
                    errors['inference_or_phase']+=1
                for saved,csv_key in (('executed_a','a_cmd'),('executed_delta','delta_rad'),
                                      ('executed_target','actuator_speed_target')):
                    value=ego.get(csv_key)
                    if csv_key=='delta_rad' and value is None:
                        value=float(ego['steer'])*float(ego['physical_max_steer'])
                    if not close(row[saved],value):errors['execution_link_'+saved]+=1
                if ego.get('ego_v_after') not in (None,'') and not close(row['executed_speed'],ego['ego_v_after']):
                    errors['execution_speed_link']+=1
                if row['guard_action']!=ego['guard_action']:errors['guard_link']+=1
                b=distribution(row['belief'],6);predicted=distribution(row['predicted_belief'],6)
                active+=bool(row['active']);updates+=bool(row['observation_applied'])
                interventions+=bool(row['intervention'])
                efe=row['efe']
                if efe is not None:
                    if len(efe)!=2:raise ValueError('Missing candidate EFE')
                    for e in efe:
                        conditional=[distribution(z,4) for z in e['conditional']]
                        if len(conditional)!=6:raise ValueError('EFE hidden state mismatch')
                        marginal=[sum(predicted[i]*conditional[i][j] for i in range(6)) for j in range(4)]
                        risk=kl(marginal,pref)
                        ambiguity=sum(predicted[i]*entropy(conditional[i]) for i in range(6))
                        if (not close(risk,e['risk'],1e-8) or not close(ambiguity,e['ambiguity'],1e-8)
                                or not close(-risk-ambiguity,e['reward'],1e-8)):
                            errors['efe_formula']+=1
                if row['engaged']:
                    if (row['confidence_guarantee'] is not False
                            or row['range_mode']!=signature['confidence_range']
                            or row['selection_rule']!=signature['selection']):
                        errors['confidence_scope']+=1
                    for a,s in row['bounds'].items():
                        if s['n']!=row['samples'][a] or s['n']<0 or s['sigma']<0.:
                            errors['confidence_count']+=1
                        if s['n']:
                            delta=row['range_used']*math.sqrt(math.log(1./signature['significance'])/(2*s['n']))
                            if (not close(s['delta'],delta,1e-8) or not close(s['bcv'],s['mean']+delta,1e-8)
                                    or not close(s['wcv'],s['mean']-delta-4*s['sigma']/(s['n']+1),1e-8)):
                                errors['confidence_formula']+=1
                    pi=distribution(row['behavior_policy'],2);p0=distribution(row['baseline_policy'],2)
                    soft=distribution(row['soft_policy'],2)
                    if (not close(alpha*kl(pi,p0),row['information_cost'],1e-8)
                            or not close(alpha*kl(soft,p0),row['soft_information_cost'],1e-8)):
                        errors['policy_kl']+=1
                    if row['requested'] not in row['allowed'] or pi[row['requested']]<=0.:
                        errors['request_support']+=1
                    if version20:
                        if (signature['action_semantics']!='cg_default_or_guard_accepted_alternative_v20'
                                or row['eligibility']!='cg_default_or_guard_accepted_alternative_v20'
                                or row['cg'] not in row['allowed']):errors['executable_scope']+=1
                        net=row['regularized_bounds']
                        for a,s in row['bounds'].items():
                            cost=-alpha*math.log(p0[int(a)])
                            t=net[a]
                            if not close(t['information_cost'],cost,1e-10):errors['current_action_kl']+=1
                            for bound in ('wcv','bcv'):
                                if ((s[bound] is None)!=(t[bound] is None) or s[bound] is not None
                                        and not close(t[bound],s[bound]-cost,1e-8)):
                                    errors['regularized_bound']+=1
                        # Recompute the soft operator independently of logged costs.
                        peak=max(row['q'][i] for i in range(2) if p0[i]>0.)
                        weights=[p0[i]*math.exp((row['q'][i]-peak)/alpha) if p0[i] else 0. for i in range(2)]
                        z=sum(weights)
                        if (not close(row['soft_value'],peak+alpha*math.log(z),1e-8)
                                or any(not close(soft[i],weights[i]/z,1e-8) for i in range(2))):
                            errors['soft_operator']+=1
                        if phase=='eval' and row['unseen_state']!=(row['state_key'] not in nodes):
                            errors['checkpoint_state_coverage']+=1
                    if version20 and row['active']:
                        checks=row['candidate_execution']
                        if len(checks)!=2:raise ValueError('Missing two physical proposal checks')
                        for i,c in enumerate(checks):
                            gap_ok=c['unbounded_gap'] or c['proposed_gap'] is not None and c['proposed_gap']>=.2
                            accepted=bool(c['solve_ok'] and c['forecast_valid'] and c['stop_feasible'] and gap_ok)
                            if c['candidate']!=i or c['accepted']!=accepted:errors['proposal_acceptance']+=1
                            if i in row['allowed'] and i!=row['cg'] and not accepted:
                                errors['inexecutable_alternative']+=1
                        if row['requested']!=row['cg']:
                            c=checks[row['requested']]
                            if row['intervention'] or not c['accepted']:errors['alternative_execution_mismatch']+=1
                            for k,actual in (('a','executed_a'),('delta','executed_delta'),('target','executed_target')):
                                if not close(c[k],row[actual]):errors['proposal_execution_link']+=1
                    if signature['trust_enabled'] and row['source']=='takeover':
                        chosen,base=row['bounds'][str(row['requested'])],row['bounds'][str(row['cg'])]
                        chosen_value=(row['regularized_bounds'][str(row['requested'])] if version20 else chosen)
                        base_value=(row['regularized_bounds'][str(row['cg'])] if version20 else base)
                        if (chosen['n']<signature['min_episodes'] or base['n']<signature['min_episodes']
                                or chosen_value['wcv']<=base_value['bcv']):errors['uncertified_takeover']+=1
                    if phase=='eval' and (row['epsilon']!=0. or row['source']=='explore' or row['model_updated']):
                        errors['evaluation_updates_or_explores']+=1
                    if phase=='eval' and row['state_key'] in values and row['q']!=values[row['state_key']]:
                        errors['evaluation_value_changed']+=1
                    if row['decision']:
                        decisions+=1;explores+=row['source']=='explore'
                        takeovers+=row['requested']!=row['cg'] and row['source']=='takeover'
                        unseen+=bool(row['unseen_state']);samples.extend(int(v) for v in row['samples'].values())
                realized=0.
                if config['efe_enabled'] and efe is not None:
                    if row['intervention']:
                        p=distribution(row['executed_distribution'],4)
                        realized=kl(p,pref)+entropy(p)
                    else:realized=-efe[row['requested']]['reward']
                if not close(realized,row['realized_efe'],1e-8):errors['executed_efe']+=1
                outcome=row['outcome'];dt=row['dt']
                task=dt*(.1*min(max(0.,row['executed_speed'])/4.,1.)-.02
                    -.01*min((row['executed_a']/3.)**2,1.)-.02*bool(row['intervention']))
                task+={None:0.,'complete':5.,'collision':-10.,'stuck':-5.}[outcome]
                reward=task-config['efe_weight']*dt*realized
                if row['reward_mode']=='negative_efe':
                    reward=-dt*realized+(0. if outcome is None else math.log(pref[0 if outcome=='complete' else 3]))
                if not close(task,row['task_reward'],1e-8) or not close(reward,row['reward'],1e-8):
                    errors['reward_contract']+=1
            except (ValueError,KeyError,TypeError,IndexError,OverflowError):errors['invalid_frame']+=1
        if seen!=set(expected) or len(rows)!=len(expected):errors['full_frame_coverage']+=1
        if not active or not decisions:errors['no_interaction_decisions']+=1
    except (OSError,ValueError,KeyError,TypeError,IndexError,OverflowError) as exc:
        errors['missing_or_invalid_model']+=1
        errors['detail: '+str(exc)]+=1
    return dict(learning_mechanisms_ok=not errors,candidate_learning_errors=dict(errors),
        candidate_learning_rows=len(rows),candidate_active_rows=active,candidate_decisions=decisions,
        candidate_takeover_decisions=takeovers,candidate_exploration_decisions=explores,
        candidate_unseen_eval_decisions=unseen,candidate_belief_observations=updates,
        candidate_intervention_rows=interventions,candidate_states=state_count,
        candidate_transition_records=transitions,candidate_recursive_transitions_observed=recursive,
        candidate_max_local_episode_clusters=max(samples) if samples else 0,
        confidence_guarantee=False,learning_benefit_established=False)
