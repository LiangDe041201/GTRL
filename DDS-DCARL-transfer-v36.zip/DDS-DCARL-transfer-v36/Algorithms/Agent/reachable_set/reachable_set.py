"""这段代码设计了一个基于加速度采样的可达集计算函数，用于计算目标车道上车辆速度以及位置的不确定度"""

import numpy as np
from scipy import interpolate


def longitudinal_reach_area(current_x, current_v, sample_acc, acc_weight):
    """
    功能：用不同的加速度计算出车辆在一定时间内的可达位置
    FIXME：先做等权重的
    逻辑：
        1.输入要采样的加速度以及该加速度权重(先预处理成顺序)
        2.用纵向位移公式计算2s后每个加速度可到达的位置
        3.记录下可达位置【x1,x2,...】以及对应的累积权重【0.1,0.2，...1.0】(需要截断)
    输入：
        1.current_x 现在的纵向位置
        1.current_v 现在的纵向速度
        2.sample_acc 采样的加速度 （需要从数据集里提取先用+-0.5）FIXME:是否需要截断？
        3.acc_weight 加速度权重（需要另一个模块从数据集支持）先算作相同

    输出：
        1.reachable_x 纵向可达距离中心点
        2。accumulated_weight 纵向可能性的累积权重
    """
    # 视域为2s FIXME:改成1
    T = 1

    # 纵向的位置和权重对
    x_and_weight = []
    x = current_x + current_v*T

    for a_index, acc in enumerate(sample_acc):
        next_x = x + acc*T**2/2
        weight = acc_weight[a_index]
        x_and_weight.append((next_x, weight))

    return x_and_weight









