#!/usr/bin/env python3
"""
转弯场景 DCARL 核心算法（完整版）
基于原版 dds_dcarl.py 重构，保留全部框架，适配转弯场景

保留的框架:
  - Trustset + R-tree 置信度计算（完整）
  - 两层混合决策 lane_hybrid + act_hybrid（完整）
  - 完整数据持久化（activate/rewards/case/behavior）
  - 完整绘图功能（Savitzky-Golay 滤波 + 移动平均）
  - MPC 控制器集成
  - RSS 安全速度 + 可达集

适配转弯的改动:
  - evaluate() 主循环 → 使用 TurnPeriodManager 阶段管理
  - get_env_sign() → 6位转弯环境标志位
  - get_lane_sign() → 4x2 转弯车道标志位
  - get_road_right() → 转弯路权判断
  - 状态编码 → define_state_space_turn
"""
import os, matplotlib
os.environ["MPLBACKEND"] = "Agg"; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np, pickle, math, random, time
# 【§72 修复】模块级 seed(42) 会**覆盖** train_dcarl_turn.py 按 DSH_SEED 做的播种
#   （播种在 import **之前**执行）⇒ DSH_SEED 对 random 模块完全无效。
#   改为：仅当 DSH_SEED 未设置时才用默认 42。
if not os.environ.get('DSH_SEED'):
    random.seed(42)

# ===== 核心框架（保留原版全部依赖）=====
from Planning_library.trustset_dds import Trustset
from Agent.tools_dds.JunctionTrajectoryPlanner import JunctionTrajectoryPlanner
from Agent.tools_dds.LaneTrajectoryPlanner import *
from Agent.tools_dds.LanePlanner_trans import *
from Agent.tools_dds.controller import Controller
from Agent.tools_dds.dynamic_map import DynamicMap
from Agent.tools_dds.rectangle_tools import *
from Agent.tools_dds.tools import *

# 纵向安全 + 可达集
from Agent.longitudinal_RSS.rss_checker import RSS_checker
from Agent.reachable_set.reachable_set import longitudinal_reach_area

# MPC 博弈控制器
from Agent.game_theory.MPC import MPCController

# ===== 转弯专用模块 =====
from Planning_library.define_state_space_turn import (
    get_turn_rtree_obs, conflict_detection, crossing_gap_info,
    crossing_conflict_detail, _get_ref_path_array, _get_curvature, _get_lateral_error,
    # 【P2 博弈区间】角色划分口径与阈值（供 CONFIG 打印与审计）
    T_EGO_V_MIN, GAME_WINDOW_M)
#: 【P2-a】角色划分口径（'plan'=计划车速 / 'time'=旧瞬时口径），转发自 gap_analysis
from Planning_library.gap_analysis import ROLE_MODE_DEFAULT
from Agent.tools_dds.LaneTrajectoryPlanner import (TURN_SPEED_LEVELS, ACTION_MODE,
                                                 N_ACTIONS, TURN_LATERAL_OFFSETS,
                                                 ACTION_SPEEDS, action_speed, action_lateral,
                                                 BRAKE_ACTION, shield_fallback_action,
                                                 slowest_speed_actions,
                                                 # 【式(10)】2D 动作空间的分量定义
                                                 TURN_2D_SPEEDS, TURN_2D_LATERALS, _N_LAT)
# ===== Phase 1 ④：二维边界安全奖励组件（纯函数，离线可对拍）=====
from Planning_library.reward_components import boundary_safety_reward
from Planning_library.trajectory_guard import execution_speed, execution_acceleration
from Planning_library.execution_guard import TurnFeasibilityV8, select_execution
from Planning_library.matrix_turn_game import MatrixTurnGame, solve_candidates
from Planning_library.trajectory_probe_v21 import TrajectoryProbeV21
from Planning_library.trajectory_evolution_v22 import TrajectoryEvolutionV22
from Planning_library.spatial_probe_v23 import SpatialProbeV23
from Planning_library.road_corridor_v23 import RoadCorridor
from Planning_library.road_corridor_v24 import RoadCorridorV24
from Planning_library.local_corridor_v26 import LocalRoadCorridorV26
from Planning_library.rolling_planner_v24 import RollingPlannerV24
from Planning_library.rolling_shadow_v27 import RollingShadowPlannerV27
from Planning_library.cg_trajectory_planner_v29 import select_rolling_planner
from Planning_library.matrix_turn_game_v14 import MatrixTurnGameV14
from Planning_library.matrix_turn_game_v16 import MatrixTurnGameV16
from Planning_library.matrix_turn_game_v17 import MatrixTurnGameV17
from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
from Planning_library.matrix_turn_game_v19 import MatrixTurnGameV19
from Planning_library.matrix_turn_game_v20 import MatrixTurnGameV20
from Planning_library.forecast_v16 import prediction_geometry, ForecastRecorder
from Planning_library.control_path_v15 import ControlExperimentV15
from Planning_library.control_probe import StopRestartProbe
# 【创新点④】边界安全的"保守确定性策略"动作屏蔽（论文 §IV / §VI-A）
from Planning_library.boundary_safety import (
    boundary_shield_mask, boundary_shield_active, SHIELD_LCTTC_CRITICAL,
    entry_gap_is_safe, worst_case_arrival_time, worst_case_thw, band_occupancy,
    # 【④·P3】进入冲突区的清空时间与"能否安全插入"判据
    entry_clearance_time, can_clear_safely,
    CLEAR_BAND_DEFAULT, CLEAR_MARGIN_DEFAULT,
    GO_ACCEL_DEFAULT, GO_VMAX_DEFAULT, required_clearance,
    required_clearance_from_standoff, commit_risk, worst_case_arrival_time,
    # 【S7-②】几何反推的安全等待位（替代"碰撞弧长 + 2 m"）
    safe_wait_arc, BAND_HALF_DEFAULT, WAIT_MARGIN_DEFAULT,
    # 【S7-③】y 域净距（含横向偏移与航向）——位置硬钳制判据
    wait_standoff)
# ===== Phase 2 ①：Cournot 零和博弈 + RV 让行概率（纯函数，离线可对拍）=====
from Planning_library.cournot_game import cournot_decision
# 【式(24)】J_LCV/ψ_LCV 从候选轨迹推出（禁止传常数）
from Planning_library.comfort_metrics import trajectory_comfort
# 【§48 客观奖励】全部只依赖世界状态（对所有车取最坏值），不可被角色分类套利
from Planning_library.boundary_safety import BAND_HALF_DEFAULT as _BAND_HALF  # noqa: E402
from Planning_library.objective_reward import (
    worst_lcttc, worst_proximity, worst_boundary_thw, r_safe, r_pet,
    penalty_from_margin, occupancy_interval, pet_to_stream, pbrs, _veh_list)
# 【式(11)(12)(17)】信息集 / 历史路径 / 共同知识（用户验收 V5：必须有真实运行时消费者）
from Planning_library.information_set import (InformationSetTracker, with_beta,
                                              rv_action_entropy)
# 【④ 2D】横向屏蔽（与纵向屏蔽同源）
from Planning_library.boundary_safety import lateral_shield_mask
from Planning_library.rv_decision import (rv_yield_probability, time_to_cover,
                                          ego_intent)
# ===== Phase 5 ②/③：主动推理 EFE 奖励 + WCV/BCV 方差修正 + 接管规则（纯函数）=====
#   注：rv_intent_entropy / ambiguity_term 等旧口径标量函数保留在 active_inference 里
#   （供单测与 legacy 消融），此处不再直接使用。
from Planning_library.active_inference import (
    efe_reward,             # 旧口径标量 -EFE（仅 DSH_EFE_MODE=legacy 时使用）
    takeover_rule,          # 式46 接管规则
    reward_to_go,           # 式58/59 回合折扣回报（信用分配）
    reward_to_go_window,    # 【式(38)】有限时域动作值 Q̃_t（H 步窗口）
    efe_by_action,          # 【式56/57 论文原式】逐候选动作的 EFE(s,a) / R(s,a) = -EFE
    ambiguity_reward,       # 【2026-10-12 修复 D2】式56/57：−ambiguity 折进单步回报
    lateral_arc_correction,  # 【2026-10-13 修复 D2b】横向 offset 的一阶弧长修正
    preferred_observation,
)
# ===== 对手类型推断（论文式17 类型空间 + §IV-C 频率统计）=====
from Planning_library.type_inference import TypeInference
from Planning_library.belief_space import DrivingBelief, TYPES as BELIEF_TYPES
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration, motion_observation, following_acceleration)
from Planning_library.soft_bellman import BeliefSoftLearner, negative_efe_return_range
# ===== 交互行为诊断日志（RV 是否提前刹车使环境变简单）=====
from Planning_library.interaction_logger import get_logger as get_interaction_logger
# ===== 【0' 诊断】路径几何 dump（只写文件，不改行为）=====
from Planning_library.path_diag_dump import PathDiagDumper as get_path_diag_dumper
# ===== 训练可视化窗口（客户端相机 + pygame，DSH_VIEW=1）=====
from Planning_library.live_view import get_view
# ===== Phase 5 ④：论文奖赏合成（式62-68，纯函数）=====
from Planning_library.cournot_game import resolve_cournot_gate
from Planning_library.cournot_mpc import game_configuration
from Planning_library.paper_turn_control import TurnFeasibility, reset_driving_state, prediction_clearance
from Planning_library.game_reward import (
    game_reward, thw_reward, yaw_reward, lat_reward, total_reward,
    gap_dist_reward, gap_rate_reward, thw_safe_penalty,
    # 【2026-10-12】式66 的曲率加权（见 EVIDENCE_reward_literature.md L3）
    yaw_curve_weight
)

# ===== 统一保存路径（锚定到 Algorithms 目录，无论从哪启动数据都在固定位置）=====
try:
    from path_utils import get_model_dir, get_plot_dir, get_save_root
except ImportError:  # 兜底：相对当前目录（旧行为），避免任何环境下导入失败
    import os as _os
    def get_model_dir():
        return _os.path.join(_os.getcwd(), "Saved_DCARL_model")
    def get_plot_dir():
        return _os.path.join(_os.getcwd(), "training_polt")
    def get_save_root():
        return _os.getcwd()
MODEL_DIR = get_model_dir()   # ⑤ 统一走 get_model_dir()，已支持 DSH_SAVE_DIR 重定向（多配置 A/B 隔离）
PLOT_DIR = get_plot_dir()
from Agent.Lateral_Planner.Turn_Planner import TurnPeriodManager
from Agent.game_theory.leader_follower_game import LongitudinalGamePlanner


# ===== 全局速度上限（降低到10 m/s，更安全） =====
MAX_SPEED_LIMIT = 10.0  # m/s ≈ 36 km/h


class DCARL_Turn:
    """转弯场景 DCARL 完整版"""

    def __init__(self, env, batch_size=20):
        self.env = env
        self.TS = Trustset()
        self.junction_trajectory_planner = JunctionTrajectoryPlanner()
        self.lane_trajectory_planner = LaneTrajectoryPlanner()
        self.lane_planner = LanePlanner()
        self.controller = Controller()
        self.dynamic_map = DynamicMap()

        # 转弯相关状态（用于 road_right 路权判断）
        self.initial_yaw = None

        # ===== Phase 5 ②：主动推理 EFE 奖励（式56/57）配置（可用环境变量开关） =====
        self.use_efe_reward = os.environ.get('DSH_EFE', '1') == '1'   # 【式(56)(57)】默认打开（论文口径）   # 0=关, 1=开
        # 【默认值说明 2026-09-17】默认改为 '0'（关），与历史所有实验一致：
        #   历史基线一律显式 DSH_EFE=0；此前默认 '1' 导致漏写环境变量时跑出
        #   不可比曲线（实测：默认开会把 100 回合碰撞率从 77% 推到 ~90%）。
        # 【论文原式】EFE(s_t,a_t) = r_cognition + r_behavior（式57）
        #   r_cognition = D_KL[q(o_g'|a) ‖ p̃(o_g')]   「与博弈目标偏离」（式52/57 第一项）
        #   r_behavior  = E_{s'}[H(p(o'|s'))]          「观测不确定」（式55/57 第二项，ln）
        #   R(s,a) = -EFE(s,a)（式56）作为**逐候选动作**的动作价值项参与决策。
        #   观测模型：o_g 离散为 clear/tight/blocked 三类，见 active_inference.efe_by_action。
        # 【权重口径】R(s,a) ∈ [-EFE_max, 0]（nats，量级 ~0~3），而 TS 轨迹置信值是回报量级。
        #   efe_value_weight 是两者的**唯一换算系数**，需在开启 EFE 后单独标定；默认 1.0。
        self.efe_value_weight = float(os.environ.get('DSH_EFE_VALUE_W', '1.0'))
        self.efe_w_cognition = float(os.environ.get('DSH_EFE_W_COG', '1.0'))
        self.efe_w_behavior = float(os.environ.get('DSH_EFE_W_BEH', '1.0'))
        self.efe_sigma = float(os.environ.get('DSH_EFE_SIGMA', '0.35'))   # 裕度预测噪声 (s)
        # 候选动作的到达时间必须同时用于对手反应预测；0 保留旧口径作单因素对照。
        self.efe_action_coupling = os.environ.get('DSH_EFE_ACTION_COUPLING', '1') == '1'
        self._efe_last = {}          # 最近一次逐动作 EFE 诊断（供日志/可视化）
        # ===== 【2026-10-12 修复 D2】式56/57 的 **ambiguity 进单步回报** =====
        #   缺陷（实证）：`causal_r`（式62-68）只对应 EFE 的 **risk** 部分，
        #     **`−ambiguity` 从未进入回报** —— 进 `causal_r` 的 EFE 只剩旧口径的
        #     `efe_mode == 'legacy'` 分支（默认 `per_action` ⇒ 该分支**永不执行**）。
        #   后果（论文式60 的机制被切断）：
        #     式60 `WCV = Q̂ − Hoeffding − 4σ/(n+1)` 要求"**对手意图模糊 ⇒ 回报方差 σ² 增大**"
        #     ⇒ 方差修正项压低 WCV ⇒ 更保守。而 ambiguity 不进回报 ⇒ σ 与模糊**无关**
        #     ⇒ **② 对③ 的置信度没有任何影响**（②③ 之间没有信息耦合）。
        #   修法（严格按式56/57）：把式57 第二项 `r_behavior = E_τ[H(q(o'|a,τ))]`
        #     取负后加入单步回报：`r += −efe_r_w · r_behavior[a]`。
        #   ⚠️ 为什么**只加 ambiguity、不加整个 −EFE**：`causal_r` 已经承载了
        #     "博弈目标达成度"（式62-68 = EFE 的 risk 面向），再叠加 `−r_cognition`
        #     会把 risk **重复计数**（两套口径的 risk 定义不同：一个是已实现的
        #     后果奖励，一个是预测观测分布的 KL）。论文 §V 开头明确说的是
        #     "**combines** the reward function specifications with mechanistic theory"
        #     ⇒ 组合"行为奖励 + 认知模糊代价"，而不是用 EFE 替换行为奖励。
        #   ⚠️ 量级：`r_behavior` 用**自然对数**熵（式55），∈[0, ~1.4]（再加 info/act 熵项）；
        #     逐帧回报量级约 −6 ⇒ 本项是 ~20% 的扰动，**不影响主目标、但足以改变 σ**。
        #   消融：`DSH_EFE_R_W=0` ⇒ 完整复现修复前行为（ambiguity 不进回报）。
        self.efe_r_w = float(os.environ.get('DSH_EFE_R_W', '1.0'))
        self._last_efe_amb_used = None   # 诊断：本帧实际折进回报的 ambiguity 值
        # ===== 【2026-10-13 修复横向盲区 D2b】=====
        #   缺陷：`_efe_by_action` 只用 `action_speed(a)` ⇒ 同速度的 3 个横向动作
        #     EFE 完全相同 ⇒ `efe_best_action ∈ {0,3,6,9}` 恒成立（横向零区分度）。
        #   修法：横向 offset `d` 的一阶弧长修正 `Δarc = −d·Δψ`
        #     （严格依据 Frenet 关系 `κ = dψ/ds` ⇒ `∫κ ds = Δψ`；详见 `_efe_by_action` 内注释）。
        #   消融：`DSH_EFE_LATERAL=0` ⇒ 复现修复前的横向盲区行为。
        self.efe_lateral = os.environ.get('DSH_EFE_LATERAL', '1') == '1'
        self._last_efe_dpsi = None       # 诊断：本帧用到的 Δψ
        # 旧口径（状态级标量加成，非论文的 EFE(s,a)）——仅在显式指定时启用，用于消融对照
        self.efe_mode = os.environ.get('DSH_EFE_MODE', 'per_action')   # 【式(57)】论文逐动作 EFE
        self.efe_safe_target = 1.0       # 旧口径：安全裕度目标 (s)
        self._efe_reward_hist = []       # 旧口径：近期因果奖励历史（式60 回报方差 σ² 代理）
        self.efe_hist_len = 20
        self._takeover_num = 0           # ③ 本回合接管次数（式46）
        self._last_took_over = False

        # ===== Phase 5 ④：论文奖赏合成（式62-68）配置（可用环境变量开关） =====
        # 【默认值说明 2026-09-17】默认改为 '0'（旧 ad-hoc 奖励），与历史所有实验一致。
        #   论文奖励（式62-68）请显式 DSH_PAPER_REWARD=1。此前默认 '1' 会让漏写环境变量
        #   的运行静默切到论文奖励路径，与历史曲线不可比。
        self.use_paper_reward = os.environ.get('DSH_PAPER_REWARD', '1') == '1'   # 【式(62)-(68)】默认打开（论文口径）  # 0=旧ad-hoc奖励, 1=式62-68
        # 式66 的 ψ 口径：'turn'=左转专用(相对参考路径的航向误差) | 'abs'=论文字面(绝对横摆角)
        self.yaw_mode = os.environ.get('DSH_YAW_MODE', 'turn')
        # 【逐项消融开关】式68 的四项：game(式62/63/64) / thw(式65) / yaw(式66) / lat(式67)
        # 例: DSH_PAPER_TERMS=game,yaw   只保留这两项（其余置 0）
        _pt = os.environ.get('DSH_PAPER_TERMS', 'game,thw,yaw,lat')
        self.paper_terms = {t.strip().lower() for t in _pt.split(',') if t.strip()}

        # ===== 防卡死（stuck）配置 =====
        # 旧逻辑在判停时无条件 v_ref=0，ego 可在远离停止线处停死、永远到不了决策点 → 永久卡死。
        #   creep_speed      : 未到停止线时判停 → 以该速度蠕动接近（不侵入冲突区）
        #   wait_timeout_frames : 连续判停超过该帧数 → 强制 commit（无限等待代价高于一次可控风险）
        self.creep_speed = float(os.environ.get('DSH_CREEP_SPEED', '1.5'))
        self.wait_timeout_frames = int(os.environ.get('DSH_WAIT_TIMEOUT', '100'))
        self._stopped_frames = 0
        # 防卡死总开关：实测开启会大幅增加碰撞（见判停分支注释），默认关闭
        self.antistuck = os.environ.get('DSH_ANTISTUCK', '0') == '1'
        # 【P1 修复】"停止线外等待"奖励（默认 0.0；旧值 5.0 会造成奖励劫持 →
        #   ego 学会把车停在路口里，见 reward_components.boundary_safety_reward 注释）
        self.wait_bonus = float(os.environ.get('DSH_WAIT_BONUS', '0.0'))
        # 【P1-e】停滞的效率代价（默认 0.5/帧）：等待只作兜底，不作策略。
        #   等 20s(400帧) ≈ −200 ⇒ 与"完成 +150 / 碰撞 −300"一起算，
        #   插入成功率 > 56% 时插入优于等待（推导见 compute_causal_reward 内注释）。
        self.wait_cost = float(os.environ.get('DSH_WAIT_COST', '0.5'))
        # ===== 【2026-10-12 正奖励项】把"好好开"变成有回报，而不是只有惩罚 =====
        #   为什么需要（实测依据，见 HANDOFF §10/§11）：
        #     · 奖励核账显示**正项几乎不兑现**：完成奖励（+140）几乎不发生、
        #       `rew_game` 正帧仅 ~14%、式65 的 THW 安全分改成 penalty 形式后恒 ≤ 0；
        #     · 负向由 `rew_lat`(53.8%) + `rew_yaw`(22.6%) 等主导；
        #     · 结果：逐帧 reward 均值 −15.8、**正帧仅 11.6%** ⇒ "停着少挨罚"最优。
        #   ⚠️ 关键发现：ad-hoc 奖励路径里本来就有 `+0.5·min(v,8)`（效率）与
        #      `0.5·(2−|a|)`（舒适），但**论文奖励路径把这两项整个丢掉了**。
        #      本组参数把正项重新接回**两条路径共有**的位置。
        #   量级刻意取小（每帧 ≤3），避免重现历史上"正项可套利"的奖励劫持
        #      （§P1-f：无对手时 +20/帧 ⇒ 减速制造"无对手"白拿满分）。
        #   消融：`DSH_EFF_W=0` 关闭（注意：默认形状已是**双边指数**，见下）。
        self.w_eff_pos = float(os.environ.get('DSH_EFF_W', '2.0'))
        self.w_comfort_pos = float(os.environ.get('DSH_COMFORT_W', '0.5'))
        self.legacy_pos = os.environ.get('DSH_LEGACY_POS', '0') == '1'
        #: 【2026-10-12 双边速度奖励】目标速度（m/s）与陡峭度。
        #   依据：`arXiv:1907.05246` §4.3 式(10) 用 `h(v)=(v−v_d)²` **同时惩罚过慢与过快**；
        #   低速专文 `arXiv:2412.16248` 用 `exp(−α|v_actual−v_target|)`（双边、有界）。
        #   为什么必须双边：用户口径明确"**低速高密度**模型，速度不能一味的变快"
        #   （2026-10-12）。单边 `+w·min(v,6)` 等价于"越快越好"，与目标冲突。
        #   `v_target` **是场景参数**：车流加密后调小它即可，不必重写奖励结构。
        self.v_target = float(os.environ.get('DSH_V_TARGET', '3.0'))
        self.vel_alpha = float(os.environ.get('DSH_VEL_ALPHA', '1.0'))
        # 【P1-f 奖励劫持修复】无 RV（THW_boundary 非有限）时安全项的处理口径。
        #   'neutral'(默认) = 中性 0  |  'cap' = 旧口径（=+20/帧，会被"减速制造无对手"套利）
        #   机理与实测证据见 Planning_library/reward_components.py 的 P1-f 注释。
        self.missing_thw_neutral = os.environ.get('DSH_MISSING_THW', 'neutral') != 'cap'
        #   空路口（n_vehicles<=0）的奖励，默认 0.0（旧值 +2/帧 = "什么都不做也白拿"）
        self.empty_bonus = float(os.environ.get('DSH_EMPTY_BONUS', '0.0'))
        # ===== 【创新点④·P1-g】边界安全动作屏蔽（保守确定性策略）=====
        #   实测 expF_paper100（100 回合，碰撞 77%）：lcttc_rv<1.0s 的 1491 帧里
        #   1240 帧（83%）最终动作**不是刹车**，其中 241 帧是 ε-greedy 在
        #   lcttc_rv<0.5s 时选了非刹车档。说明 ④ 此前只进了奖励/WCV，没进动作空间。
        self.shield_enable = os.environ.get('DSH_SHIELD', '1') == '1'
        #   触发阈值（秒）：LCTTC_rv 低于它 ⇒ 只允许"不加速"的档位
        self.shield_lcttc = float(os.environ.get('DSH_SHIELD_LCTTC', '0.8'))
        #   THW_boundary_rv 阈值；<=0 表示不启用该条件（默认只按 LCTTC 判）
        # 【P4-⓪b】THW 档机制已实现，但**默认仍关闭**（0.0 = 只看 lcttc，已知 20%/80%）。
        #   实测 expZ_thw20：把触发量换成 worst_case_thw 且阈值 1.5 后成功率 20%→7.7%，
        #   因为 `worst_case_thw` 的缩放 `ego_v/(ego_v+v_rush)` 把 RV 全速都算作接近速度，
        #   使 THW 普遍缩到 ~0.4× ⇒ 几乎恒低于阈值 ⇒ 屏蔽"早但过频"，车一直爬行被撞。
        #   ⇒ 阈值必须按 thw_worst 的**实际分布**标定（需先记录该分布），在标定前默认关闭。
        self.shield_thw = float(os.environ.get('DSH_SHIELD_THW', '0.0'))
        self.shield_thw_critical = float(os.environ.get('DSH_SHIELD_THW_CRIT', '0.0'))
        # ===== 【S3】横向带占用早期预警档 =====
        #   标定（expCC+expDD，接近区常帧 2510 / 碰撞前10帧 310）：
        #     规则 `带被占用 且 0<车头距带北边≤2m` → 正常帧触发 13.9%、碰撞前 39.7%、分离 +25.8pp
        #     （裸 `band_occupied` 触发 36.1% 太频；`band_x_gap<2` 触发 53.6% 更频）
        #   召回率仅 ~40% ⇒ **只作"不许加速"一档**，刹车档仍由 lcttc 兜底。
        #   DSH_BAND_WARN=0 关闭；DSH_BAND_WARN=9 表示不看距离（退化成裸 band_occupied）。
        self.band_warn_dist = float(os.environ.get('DSH_BAND_WARN', '2.0'))
        self._band_warn_num = 0
        # ===== 【创新点④·P3】进入冲突区的"清空时间"判据 =====
        #   实测 expJ_paper_p100：碰撞全部发生在**进入阶段**（committed=0、arc≈10.2m）
        #   的侧刮——自车车头 y≈−137.02 正好压在交叉车体带 [−139,−137] 边界上。
        #   旧判据 `4.0/v_go + 0.5` 只算了自车车身长，漏掉交叉带宽度 ⇒ 把"插不进去"
        #   判成"能过"。现在 = (ego_len + band)/v_go + margin。
        self.clear_band = float(os.environ.get('DSH_CLEAR_BAND', str(CLEAR_BAND_DEFAULT)))
        self.clear_margin = float(os.environ.get('DSH_CLEAR_MARGIN', str(CLEAR_MARGIN_DEFAULT)))
        # 【§54 真实运动清空模型】转弯中的实际可行加速度与速度上限。
        #   旧判据把清空时间当成与位置/速度无关的常数 3.12 s（=8.5/4.0+1.0），
        #   实测转弯中 ego_v 中位仅 1.46 m/s ⇒ 低估 2~3 倍 ⇒ 把"插不进去"判成"能过"。
        self.go_accel = float(os.environ.get('DSH_GO_ACCEL', str(GO_ACCEL_DEFAULT)))
        self.go_vmax = float(os.environ.get('DSH_GO_VMAX', str(GO_VMAX_DEFAULT)))
        self.real_clearance = os.environ.get('DSH_REAL_CLEARANCE', '1') == '1'
        # 【§54b】用净空锚定占用窗（修"越慢越宽松"的反向激励）。默认开。
        self.standoff_clearance = os.environ.get('DSH_STANDOFF_CLEARANCE', '1') == '1'
        # 【§57】最坏情况判据是否覆盖**所有**接近车（1=是，默认）。0=只算被分类的 rv/fv（消融）
        self.worstcase_all = os.environ.get('DSH_WORSTCASE_ALL', '1') == '1'
        # 【§58】对**所有**接近车统一用最坏情况（恢复巡航）估算到达时间。默认开。
        self.full_worstcase = os.environ.get('DSH_FULL_WORSTCASE', '1') == '1'
        # ===== 【§60 三层统一：机会约束授权 + 屏蔽全覆盖 + 权限分离】 =====
        #  依据：offline_gap_validate.py（§59）—— 现状标量判据放行的决定 60% 是错的、
        #  拒绝的决定 38% 本来有窗口；机会约束在 VEH_CLEAR=1.5/p_yield=0.5/δ=0.30 下
        #  达到 **0 假放行**（139 次放行），而"一律最坏情况"虽降到 18% 但错失 87% 窗口。
        self.risk_commit = os.environ.get('DSH_RISK_COMMIT', '1') == '1'
        #: 授权阈值 δ：risk ≤ δ 才放行。等价于期望效用 `risk·C_coll < C_wait`
        #: 的 `δ = C_wait / C_coll`（§59.4 结论②：硬阈值在离散风险上有悬崖，
        #: 故这里保持可解释的比值口径）。默认 0.30 来自敏感性扫描的安全工作点。
        self.risk_max = float(os.environ.get('DSH_RISK_MAX', '0.30'))
        #: 【§61】风险门是否作为**唯一**授权通道（1=是，默认）。
        #:   置 0 则恢复旧的"Cournot 可无条件放行"旁路，用于消融对照。
        self.risk_only_gate = os.environ.get('DSH_RISK_ONLY_GATE', '1') == '1'
        # ===== 【2026-10-12 修复 D3'】① Cournot 的**授权口径**（显式、可消融）=====
        #   缺陷：修复前 `_risk_gate_ok = (not risk_only_gate) or bool(_gap_ok)` 位于
        #     `if _gap_ok:` 的 **else 分支内** ⇒ `_gap_ok` 恒为 False ⇒ 默认配置下
        #     `_risk_gate_ok` **恒 False** ⇒ 唯一能授权①的分支**不可达**
        #     ⇒ **①"零和 Cournot 博弈"对决策的影响为 0**（实证：`DSH_TAKE_COURNOT=0/1`
        #     的 `action` 列 5651/5651 帧完全相同）。
        #   修法：把它变成**显式的三种口径**（而不是残留一个死分支）：
        #     'gate'（**默认**，= 修复前的实际行为）：风险门是唯一授权通道，①仅"咨询"
        #     'risk'（**推荐用于启用①**）：①可在**风险值本身合格**时授权，即
        #            `commit_risk ≤ DSH_COURNOT_RISK_MAX`（默认取 `risk_max`）。
        #            语义：①**替代"稳定性要求"**，但**不得**越过风险值上限。
        #            ⚠️ 这是**安全**的启用方式：`_gap_ok=False` 有两种成因，本口径只放行
        #               "风险可接受、仅稳定帧数未满足"那一类（详见下方 `_risk_value_ok`）。
        #     'game' （论文字面口径）：①判走即可授权，安全仅由式24 的 `u_safety` 定价。
        #            ⚠️ 会越过风险值上限 ⇒ 实测风险模型校准良好（假放行率与 risk 吻合），
        #               故本口径**风险最高**，仅用于消融/敏感性分析。
        #   消融：`DSH_COURNOT_AUTHORITY=gate` ⇒ 完整复现修复前行为。
        self.cournot_authority = os.environ.get(
            'DSH_COURNOT_AUTHORITY', 'gate').strip().lower()
        #: 'risk' 口径下①的授权阈值（默认与 `risk_max` 相同 ⇒ 只放宽稳定性、不放宽风险值）
        self.cournot_risk_max = float(
            os.environ.get('DSH_COURNOT_RISK_MAX', str(self.risk_max)))
        #: 单车让行概率 p_yield。**安全关键参数**：§59.4 实测若假设 0.7 而实际 0.5，
        #: 假放行率会从 0% 飙到 42~52%。必须取保守值或在线估计，**绝不能乐观**。
        self.p_yield_commit = float(os.environ.get('DSH_P_YIELD_COMMIT', '0.5'))
        # 【§62 逐车 p_yield 推断】'model'（默认）= 用 rv_yield_probability(θ) + 逐车观测
        #   做贝塔-二项更新并取**下置信界**；'const' = 退回常数（消融对照）。
        self.p_yield_mode = os.environ.get('DSH_P_YIELD_MODE', 'model')
        self.p_yield_prior_k = float(os.environ.get('DSH_P_YIELD_K', '2.0'))
        # 【§64 B 方案】用**观测**到的"意图条件让行率"校准先验（不直接采用耦合假设，
        #   否则是"我假装要进 ⇒ 我假设别人让我 ⇒ 我进"的自证循环）。
        self.intent_bins = int(os.environ.get('DSH_INTENT_BINS', '5'))
        self.intent_min_obs = int(os.environ.get('DSH_INTENT_MIN_OBS', '5'))    # 先验强度
        self.p_yield_z = float(os.environ.get('DSH_P_YIELD_Z', '1.0'))          # 下置信界倍数
        #: 【§62】式(65) 的形式：'penalty'（默认，≤0）| 'paper'（原式，仅消融）
        self.thw_mode = os.environ.get('DSH_THW_MODE', 'penalty')
        #: 式(65) 的输入是否用**全车最坏值**（1=是，默认）
        self.thw_obj = os.environ.get('DSH_THW_OBJ', '1') == '1'
        self.thw_pen_th = float(os.environ.get('DSH_THW_PEN_TH', '2.0'))
        self.thw_pen_w = float(os.environ.get('DSH_THW_PEN_W', '10.0'))
        #: 车辆占用冲突区时长（s）。§59.4 敏感性：0.5→17.3% 假放行（不安全）、
        #: 1.0/1.5→0%、2.0→13.6% 但放行数掉到 44。默认取 1.5。
        self.veh_clear_safe = float(os.environ.get('DSH_VEH_CLEAR_SAFE', '1.5'))
        self.risk_max_veh = int(os.environ.get('DSH_RISK_MAX_VEH', '8'))
        #: 【§70】授权要求 `risk ≤ δ` 连续多少帧（0=关闭）。用于滤掉"瞬时低谷"授权。
        #  默认 10：§70 的 3-seed 配对 A/B 验证为**两个轴都改善**
        #  （成功 40.0%→**45.0%**、碰撞 46.7%→**40.0%**，方向在 3/3 种子一致）。
        #  `=0` 可回退到旧口径做消融。
        self.risk_stable_n = int(os.environ.get('DSH_RISK_STABLE_N', '10'))
        # ===== 【§71 消融开关】四个创新点的独立开关（论文贡献论证用）=====
        #   ① Cournot 博弈；② EFE（`DSH_EFE`）；③ WCV/BCV 接管规则；④ 边界屏蔽（`DSH_SHIELD`）
        #   RL 层本身：`DSH_METHOD=CG` 会把 `rl_active` 置 False（纯 Cournot 决策）⇒ RL 对照臂现成。
        self.use_cournot = os.environ.get('DSH_TAKE_COURNOT', '1') == '1'   # ①
        self.use_wcv_bcv = os.environ.get('DSH_WCV_BCV', '1') == '1'       # ③
        #: ④屏蔽是否覆盖**所有**车（不再只看被分类的 rv/fv）
        self.shield_all_vehicles = os.environ.get('DSH_SHIELD_ALL_VEH', '1') == '1'
        self.shield_lcttc_horizon = float(os.environ.get('DSH_SHIELD_LCTTC_H', '3.0'))
        #: 【权限分离】已承诺且已在带内时，④屏蔽**不得**中止穿越
        #:  （§51/§53：停在带内正是被撞的直接原因）
        self.shield_respect_commit = os.environ.get('DSH_SHIELD_RESPECT_COMMIT', '1') == '1'
        # ===== 【创新点④·P3b】安全回退位（停止线纪律）=====
        #   实测 expL_p3_20：自车停在 arc≈10.22 m 时车头 y≈−137.0，**正好压在交叉车体带
        #   [−139,−137] 边界上**（4 个采样 2 个已侵入）⇒ RV 擦过即撞。
        #   即"停在哪里"本身错了。hold_arc = 12.2 m ≈ 10.22 + 2 m 几何余量。
        #
        #   【S7-② 修正】上面那个"10.22"是 `arc_to_cross` **量化伪影**（旧式只有 2.045 m
        #   分辨率），所以"加 2 m 余量"落在同一个量化步长内 —— 名义 2 m、实际分辨力
        #   2.045 m，余量被吃掉（实测碰撞弧长中位正是 12.262 = 配置的等待点）。
        #   改为**由地图几何反推**：`boundary_safety.safe_wait_arc()` 求参考路径上
        #   "车头带 margin 裕量、整车在交叉带之外"的连续弧长。用 `DSH_WAIT_ARC_GEO=1` 启用
        #   （默认 0 保持历史行为，便于干净 A/B）；`DSH_HOLD_ARC` 仍可显式覆盖。
        self.hold_enable = os.environ.get('DSH_HOLD', '1') == '1'
        self.hold_arc = float(os.environ.get('DSH_HOLD_ARC', '12.2'))
        self.wait_arc_geo = os.environ.get('DSH_WAIT_ARC_GEO', '0') == '1'
        # 【§51.3 几何修复】等待线余量 1.5 → 2.0 m。
        #   为什么改：1.5 m 是**标称**值，实测停在 −0.21~−0.68 m（超调 1.7~2.2 m），
        #   于是"名义 2 m 净空"根本没有兑现过。取 2.0 m 与 §51 的目标口径一致。
        self.wait_margin = float(os.environ.get('DSH_WAIT_MARGIN', '2.0'))
        # 【§51.3】制动包络的两个真实物理量（旧式完全没有它们）
        #   act_delay : 感知+MPC求解+下发的**有效滞后**（s）。旧式隐含 dt_lag=0。
        #   brake_eff : **有效**减速度占 `_a_brake` 的比例。旧式隐含 brake_eff=1.0。
        # 【§51.4】授权是否当作"发车指令"（1=是，修死锁后默认）。置 0 可复现死锁做对照。
        self.commit_launch = os.environ.get('DSH_COMMIT_LAUNCH', '1') == '1'
        # 【§53 闩锁】承诺必须是**闩锁**，不能是逐帧谓词。
        #   实测 bug（expS84_commit）：`entry_granted=1` 265 帧，但碰撞帧
        #   `entry_granted=0`、`wait_standoff=-0.17/-0.77/-0.63`（在带内）
        #   ⇒ 因果链：授权→发车→进带途中授权被撤销→钳位急停在带内→被过路车撞。
        #   "能起步又被中途抛弃"正好落进本要避免的"半只脚在带里"，且比原来更糟。
        #   闩锁语义：一旦授权即锁定，直到 `committed`（沿路径越过冲突点 >1m）才解除。
        #   ⚠️ 闩锁必须与"清空路径要有间隙认证"一起改：否则闩锁会把车一路送到
        #      `_arc<=_stop_arc+0.5` 的**无条件强制清空**路径 ⇒ 回到 96.3% 碰撞。
        self.commit_latch = os.environ.get('DSH_COMMIT_LATCH', '1') == '1'
        # 【§53】"无条件强制清空"路径的 gate：只在车头**确实已在交叉带内**时才允许。
        #   `DSH_FORCE_CLEAR_GATE=0` 可回退到旧的"无条件"行为做消融对照。
        self.force_clear_gate = os.environ.get('DSH_FORCE_CLEAR_GATE', '1') == '1'
        # 【§53 闩锁 v2】锁定时长上限（帧）：超时强制解锁，避免"锁死到回合结束"
        self.latch_max_frames = int(os.environ.get('DSH_LATCH_MAX', '150'))
        #: 【§65】闩锁允许的距离（m）。旧值 = wait_margin+1.0（3.0 m）导致
        #:   授权（中位 6.68 m）与闩锁区**无交集** ⇒ 从不承诺。默认放到 12 m。
        self.latch_zone = float(os.environ.get('DSH_LATCH_ZONE', '12.0'))
        #: 【§66】带外是否允许"安全中止"（授权撤销 ⇒ 放弃承诺、交回等待纪律）。
        #:   1=允许（默认，修"在还能停的地方也不许停"）；0=旧行为（不可撤销）。
        self.commit_abort = os.environ.get('DSH_COMMIT_ABORT', '1') == '1'
        #: 【§66b】中止的风险阈值（滞回带上界）：承诺 ≤`risk_max`，中止 >该值。
        self.abort_risk = float(os.environ.get('DSH_COMMIT_ABORT_RISK', '0.55'))
        self._commit_latched = False
        self._latch_num = 0
        self.act_delay = float(os.environ.get('DSH_ACT_DELAY', '0.4'))
        self.brake_eff = float(os.environ.get('DSH_BRAKE_EFF', '0.4'))
        # 【3.1/C2】位置纪律的"承诺清空"速度门：已获准进入且速度≥此值 ⇒ 视为承诺清空，不再拦；
        #   否则一律不允许把车身放进冲突带（"要么清空、要么停在带外"）。
        self.clear_v_min = float(os.environ.get('DSH_CLEAR_V_MIN', '3.0'))
        #: 【P1-g】同一配对内、一步（0.05 s）允许的最大间隙变化（m）。
        #:   物理含义：|Δg| ≤ v_rel_max·dt。取 1.5 m ⇒ v_rel_max ≈ 30 m/s（远超本场景）。
        #:   超过它 ⇒ 视为测量毛刺，ġ 记 0（不给奖励）。
        self.GAP_DG_MAX = float(os.environ.get('DSH_GAP_DG_MAX', '1.5'))
        # ===== 【§48 客观奖励】=====
        #  全部只依赖世界状态、对**所有车**取最坏值 ⇒ 不可被"角色分类/配对切换"套利。
        self.obj_reward = os.environ.get('DSH_OBJ_REWARD', '1') == '1'
        self.w_obj_safe = float(os.environ.get('DSH_W_OBJ_SAFE', '1.0'))      # 最坏 LCTTC 余量
        self.w_obj_prox = float(os.environ.get('DSH_W_OBJ_PROX', '0.5'))      # 最坏边界距离
        self.w_obj_pet = float(os.environ.get('DSH_W_OBJ_PET', '1.0'))        # 汇入区 PET
        self.h_th_obj = float(os.environ.get('DSH_H_TH', '2.0'))              # LCTTC 阈值(s)
        self.d_th_obj = float(os.environ.get('DSH_D_TH', '8.0'))              # 边界距离阈值(m)
        self.pet_th_obj = float(os.environ.get('DSH_PET_TH', '3.0'))          # PET 阈值(s)
        self.clear_band_obj = float(os.environ.get('DSH_OBJ_BAND', '2.0'))    # 汇入区宽度(m)
        # 【P3】把论文式(63) 的 r_gap-rate 改成**势函数差分**（理论保证不改变最优策略）
        self.gap_rate_pbrs = os.environ.get('DSH_GAP_RATE_PBRS', '1') == '1'
        self.gap_phi_scale = float(os.environ.get('DSH_GAP_PHI_C', '0.5'))
        # 【S7-③】位置硬钳制：用自车矩形 y 向净距判停（含横向偏移/航向），替代弧长剖面
        self.wait_clamp = os.environ.get('DSH_WAIT_CLAMP', '1') == '1'   # 【3.1/C2】默认打开位置纪律
        # 【④ 2D】横向屏蔽开关（用户验收 V4：屏蔽必须纵向+横向都屏）
        self.lat_shield_enable = os.environ.get('DSH_LAT_SHIELD', '1') == '1'
        # 【V1】覆盖式探索（最少访问优先）。默认开：用户把"12 个动作都有样本"当落地判据。
        self.expl_coverage = os.environ.get('DSH_EXPL_COVERAGE', '1') == '1'
        # 【V1】并列时是否确定性取最小下标（默认是；见 _pick_exploration_action）
        self.expl_deterministic = os.environ.get('DSH_EXPL_DETERMINISTIC', '1') == '1'
        # 【V1】每回合预热轮转的探索次数（默认 = N_ACTIONS ⇒ 保证全动作空间被覆盖）
        self.expl_warmup = int(os.environ.get('DSH_EXPL_WARMUP', str(N_ACTIONS)))
        #: 【V1 构造性覆盖】全局"尚未被选中过"的动作集合（跨回合保持）
        self._unvisited = set(range(N_ACTIONS))
        self._last_shield_mask = None
        # 【式(64)】让论文的 140 完成奖励真正生效（不再是死代码）
        self.rgame_complete = os.environ.get('DSH_RGAME_COMPLETE', '1') == '1'
        # 【L1】式(24) 的舒适项阈值（论文 Table I 未给 ⇒ 自由参数）
        self.j_th = float(os.environ.get('DSH_J_TH', '0.5'))
        self.psi_th = float(os.environ.get('DSH_PSI_TH', '0.3'))
        # 【L2】式(20) `U_i(s,a)=Σ w_metric·U_metric(s,a)` 的权重：从硬编码默认值
        #   改为**可配参数**（至少不再是"埋在函数签名里的字面量"）。
        #   论文给出了"权重"这一形式但未给具体数值 ⇒ 属自由参数。
        #   真正的"可学"（作为 RL 参数）是后续工作，此处先做可配 + 可消融。
        self.w_eff = float(os.environ.get('DSH_W_EFF', '1.0'))
        self.w_safe = float(os.environ.get('DSH_W_SAFE', '2.0'))
        self.w_comf = float(os.environ.get('DSH_W_COMF', '0.3'))
        self.wait_penalty = float(os.environ.get('DSH_WAIT_PENALTY', '15.0'))
        self.thw_th = float(os.environ.get('DSH_THW_TH', '1.5'))
        # 【式(11)(12)(17)】信息集跟踪器（每帧真实填充；式(16) 的 |I| 喂进 EFE 模糊项）
        self.info_set_enable = os.environ.get('DSH_INFO_SET', '1') == '1'
        self.info_w = float(os.environ.get('DSH_INFO_W', '1.0'))
        # 【式(18)】对手动作频率熵的权重（历史路径的消费者；0 = 关闭）
        self.w_action_entropy = float(os.environ.get('DSH_W_ACT_ENTROPY', '1.0'))
        self.info_track = InformationSetTracker() if self.info_set_enable else None
        self._info_ep = None
        self._info_step = 0
        self._last_info_state = None
        self._info_err = None
        self._causal_err = None
        # 【§48】客观奖励项/异常/势函数历史（绝不静默：异常必须落到 _obj_err 与日志列）
        self._obj_err = None
        self._obj_err_num = 0
        self._clr_err = None
        self._last_commit_risk = None
        self._last_risk_veh = None
        self._risk_ok_streak = 0
        self._last_risk_streak = 0
        # 【§75 诊断】Cournot 的"意见"及是否被风险门挡住
        self._last_take_cournot = None
        self._last_risk_gate_ok = None
        # 【2026-10-12 修复 D3'】① 授权口径的可观测状态（供落盘/调试）
        self._last_cournot_gate_reason = None     # 'gate_only' | 'authority_risk_ok' | ...
        self._last_risk_value_ok = None           # 风险值本身是否合格（区分两种成因）
        self._last_commit_risk_fresh = False      # 本帧 commit_risk 是否**确实算过**（防陈旧）
        # 【§62】逐车让行概率的观测历史（vehicle_id -> (n_obs, n_yield)）
        self._yield_hist = {}
        self._yield_last = {}
        # 【§64】意图分箱的让行观测直方图：每箱 [n_obs, n_yield]
        self._intent_hist = [[0, 0] for _ in range(max(int(self.intent_bins), 1))]
        self._last_intent_ego = None
        self._last_intent_rate = None
        self._last_pyield_prior = None
        self._last_pyield_hat = None
        self._last_pyield_n = None
        self._last_thw_in = None
        self._obj_terms = None
        self._gap_phi_prev = None
        self._pbrs_shaping = 0.0
        self._act_visits = [0] * N_ACTIONS

        # ===== 对手类型推断（式17 类型空间 + §IV-C 频率统计；跨回合持续，因类型是固有属性）=====
        self.type_inf = TypeInference()
        self.type_obs_interval = int(os.environ.get('DSH_TYPE_OBS_INTERVAL', '40'))  # 每 2s 观测一次
        # ===== 【0''-b 修复】"让行/抢行"观测判据：绝对速度 → **相对巡航速度** =====
        #  bug：旧判据 `observed_yield = (rv_v < DSH_TYPE_YIELD_SPEED=6.0)`，而车流
        #       **巡航速度只有 4.41 m/s** ⇒ 该式**恒为真** ⇒ 每一辆 RV 都被标记成"让行"
        #       （与其真实行为无关）⇒ 后验必然塌到最保守类型。
        #       实测 expS_step0diag：θ 0.476 → 0.200，后验 conservative **0.9982**、
        #       aggressive 1.6e-11，ambiguity 0.014 —— 自信地错。
        #       这直接污染 ①Cournot 的 p_yield、③ 的 ambiguity、以及 ②EFE 的 r_cognition。
        #  修复：阈值 = ratio × RV 巡航速度（默认 0.75×4.41 ≈ 3.31 m/s）。
        #       抢行车维持 ~4.4 m/s，让行车降到 1.32 m/s ⇒ 3.31 能干净分开两者。
        #       `DSH_TYPE_YIELD_SPEED` 若显式给出，仍按绝对值（兼容旧实验/消融）。
        self.type_yield_ratio = float(os.environ.get('DSH_TYPE_YIELD_RATIO', '0.75'))
        _abs_env = os.environ.get('DSH_TYPE_YIELD_SPEED', None)
        self.type_yield_speed_abs = (float(_abs_env)
                                     if _abs_env not in (None, '') else None)
        self.type_yield_speed_th = 6.0      # 兜底：巡航速度取不到时用（旧默认值）
        self._type_obs_diag = {'n_obs': 0, 'n_yield': 0, 'th_last': None}
        # ===== 【P4-③】终局奖励缩放（默认 10）：让碰撞罚占整回合回报的 ~20~50% =====
        #   实测终局只占 2~5%（G 约 ±20000 vs 碰撞 −300）⇒ 智能体不在乎撞。
        self.terminal_scale = float(os.environ.get('DSH_TERMINAL_SCALE', '10.0'))
        # 【P4-①b】进入决策的"接近区"半径（m）：只在此距离内用最坏情况清空判据裁决，
        #   远处自由接近（否则连续车流会让自车在几十米外就冻死）。
        self.entry_zone = float(os.environ.get('DSH_ENTRY_ZONE', '15.0'))
        # ===== 【S2-①】ε-greedy 调度 =====
        #   实测 expEE_eps20：前 20 回合观测到的探索占比 37~46%，而 ε 名义末值只有 0.2725
        #   —— 因为观测到的是**时间平均值**（0.40 → 0.2725，均值 ≈0.34）。ε 实现没问题，
        #   是**衰减太慢**：我们的实验都是 20 回合，等于有 1/3 的动作是随机的。
        #   改：×0.98 → ×0.95（ep20 从 0.27 → ~0.14）；起点与下限也可调。
        self.eps0 = float(os.environ.get('DSH_EPS0', '0.4'))
        self.eps_decay = float(os.environ.get('DSH_EPS_DECAY', '0.95'))
        self.eps_min = float(os.environ.get('DSH_EPS_MIN', '0.05'))
        # 【P4-⓪ 修复】式24 安全项的模式。实测：调用方**从未设置** `u_safe_mode`，
        #   因此一直跑 cournot_game 的默认 `eq24` —— 而该形式把 TH_th 当目标值，
        #   **大安全裕度反而被重罚**：THW=6s 得 −81，THW=0.9s 只得 −1.44，
        #   THW=inf（无对手）反而得最优 0（与奖励里修掉的 P1-f 同病）。
        #   ⇒ 必须切成单调形式 `left_turn`（阈值以上饱和 +12、以下惩罚），
        #     否则"用最坏情况做安全惩罚"会变成"用最坏情况做鼓励"。
        # 【式(24) 权威口径】默认 = `eq24`（论文原式：对称平方偏差 `(THW−TH_TH)²` 求和）。
        #   历史上默认被切到自造 `left_turn` 阶梯（含饱和满分奖励），那是'放行判据偏松'的元凶。
        self.u_safe_mode = os.environ.get('DSH_U_SAFE_MODE', 'eq24')
        self._type_obs_counter = 0

        # ===== 交互行为诊断日志（RV 是否提前刹车把环境变简单）=====
        #   输出 interaction_rv.csv / interaction_ego.csv / interaction_summary.csv /
        #   interaction_report.txt 到运行目录；DSH_ILOG=0 关闭。
        self.ilog = get_interaction_logger()
        # ===== 【0' 诊断】路径几何 dump（只写文件，不改控制行为；DSH_PATH_DIAG=0 关）=====
        #   目的：一次运行落盘"冲突几何折线 / 规划器折线 / csp 样条采样 / 生成轨迹"，
        #   用来判定路口段 2~6 m 偏差属于①样条拟合误差 ②MPC跟踪误差 ③坐标系错配。
        self.path_diag = get_path_diag_dumper(out_dir=MODEL_DIR, max_records_per_ep=500)
        self._traj_id = 0            # 每次重取轨迹 +1，用于把 ego 逐帧位置关联到轨迹
        # ===== 训练可视化（前视 + 俯视相机窗口；DSH_VIEW=1 开启，ESC 退出）=====
        self.view = get_view()
        if self.view.enabled:
            print("[DCARL_Turn] DSH_VIEW=1：已开启可视化窗口（前视 + 俯视），仿真会变慢")

        # ===== Phase 5 ⑤：控制饱和率埋点（对齐论文 Table II/III / Fig.5）=====
        self._mpc_a_min = -3.0           # MPC 纵向加速度下界 (m/s²)
        self._mpc_a_max = 2.0            # MPC 纵向加速度上界 (m/s²)
        self._mpc_max_steer = 1.0        # 与当前执行端可接受范围一致
        self._long_sat_num = 0           # 本回合纵向控制饱和帧数
        self._lat_sat_num = 0            # 本回合横向控制饱和帧数
        self._ctl_frames = 0             # 本回合 MPC 控制帧数
        self._mpc_fail_num = 0           # 本回合 MPC 求解失败帧数（走 P1 回退）

        # ===== Phase 5 ⑤：三方法切换（对齐论文 §VI-B SG/CG/GTRL）=====
        self.method = os.environ.get('DSH_METHOD', 'GTRL').upper()
        self.cournot_mode = os.environ.get('DSH_COURNOT_MODE', 'mpc').lower()
        self.game_config = game_configuration(self.method, self.use_cournot, self.cournot_mode)
        self.candidate_learning = self.game_config.get('candidate_learning', False)
        self.control_profile = os.environ.get('DSH_CONTROL_PROFILE', 'paper_v11')
        if self.control_profile not in ('paper_v11', 'paper_v10', 'paper_v9', 'paper_v8', 'paper_v7', 'legacy'):
            raise ValueError('Unsupported DSH_CONTROL_PROFILE: '+self.control_profile)
        self.paper_control = self.control_profile in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11')
        self.revised_control = self.control_profile in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11')
        os.environ['DSH_CONTROL_PROFILE'] = self.control_profile
        if self.paper_control and (self.method == 'SG' or self.cournot_mode not in ('mpc', 'matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20')):
            raise ValueError('paper profiles require MPC tracking or matrix entry with MPC tracking')
        if self.game_config['matrix'] and self.control_profile != 'paper_v11':
            raise ValueError('The matrix experiment requires the frozen paper_v11 actuator')
        self.control_experiment = ControlExperimentV15(self.method, self.game_config['matrix'],
            self.control_profile, os.environ.get('DSH_CONTROL_PATH', 'legacy'),
            os.environ.get('DSH_ENTRY_POLICY', 'full'), MODEL_DIR,
            candidate_learning=self.candidate_learning)
        self.forecast_revision = os.environ.get('DSH_FORECAST_MODEL', 'legacy')
        if self.forecast_revision not in ('legacy', 'route_v16', 'route_v17', 'route_v18'):
            raise ValueError('Unsupported DSH_FORECAST_MODEL')
        if self.forecast_revision in ('route_v16', 'route_v17', 'route_v18') and (self.control_profile != 'paper_v11'
                or self.method not in ('RULE', 'CG') and not self.candidate_learning
                or not self.control_experiment.enabled):
            raise ValueError('route_v16 requires spatial_v15 RULE/CG with paper_v11')
        if self.game_config['matrix'] and self.forecast_revision != {
                'matrix_v16': 'route_v16', 'matrix_v17': 'route_v17', 'matrix_v18': 'route_v18',
                'matrix_v19': 'route_v18', 'matrix_v20': 'route_v18'}.get(self.cournot_mode, 'legacy'):
            raise ValueError('The new matrix and common forecast must be enabled together')
        self.turn_feasibility = TurnFeasibility()
        if self.method != 'GTRL':
            self.use_efe_reward = self.use_wcv_bcv = False
        self.cournot_mpc_safety = os.environ.get('DSH_COURNOT_MPC_SAFETY', 'deficit').lower()

        os.makedirs(MODEL_DIR, exist_ok=True)
        self.activate_data_file = os.path.join(MODEL_DIR, "turn_activate_data.pkl")
        self.episode_rewards_file = os.path.join(MODEL_DIR, "turn_episode_rewards.pkl")
        self.case_rewards_file = os.path.join(MODEL_DIR, "turn_case_rewards.pkl")
        self.behavior_data_file = os.path.join(MODEL_DIR, "turn_behavior_data.pkl")

        # ===== Phase 1：回合边界指标（LCTTC/THW_boundary）落盘 =====
        self.metrics_file = os.path.join(MODEL_DIR, "turn_metrics.pkl")
        self.episode_metrics_log = self.load_metrics()

        # Explicit IV-A/B learning path. Legacy geometry/MC remains an explicit
        # comparison mode, with a separate persistence format and value meaning.
        self.learning_mode = os.environ.get('DSH_LEARNING_MODE', 'soft_belief')
        if self.learning_mode not in ('soft_belief', 'mc_legacy'):
            raise ValueError('DSH_LEARNING_MODE must be soft_belief or mc_legacy')
        self.belief_tracker = self.belief_learner = None
        self.belief_reward_mode = os.environ.get('DSH_BELIEF_REWARD', 'task_ambiguity')
        if self.belief_reward_mode not in ('task_ambiguity', 'negative_efe'):
            raise ValueError('DSH_BELIEF_REWARD must be task_ambiguity or negative_efe')
        if self.learning_mode == 'soft_belief' and getattr(self, 'method', 'GTRL') == 'GTRL' and not self.candidate_learning:
            if self.belief_reward_mode == 'negative_efe' and (not self.use_efe_reward or self.efe_mode != 'per_action'):
                raise ValueError('negative_efe requires DSH_EFE=1 and DSH_EFE_MODE=per_action')
            self.belief_tracker = DrivingBelief(
                persistence=float(os.environ.get('DSH_BELIEF_PERSISTENCE', '.8')))
            self.belief_learner = BeliefSoftLearner(
                N_ACTIONS, gamma=float(os.environ.get('DSH_GAMMA', '.98')),
                alpha=float(os.environ.get('DSH_SOFT_ALPHA', '1.0')),
                support_mass=float(os.environ.get('DSH_BASELINE_SUPPORT', '.05')),
                belief_resolution=float(os.environ.get('DSH_BELIEF_RESOLUTION', '.2')),
                min_episodes=int(os.environ.get('DSH_BELIEF_MIN_EPISODES', '10')),
                range_fallback=(max(1e-9, negative_efe_return_range(
                    preferred_observation(), self.efe_w_cognition, self.efe_w_behavior,
                    float(os.environ.get('DSH_GAMMA', '.98'))))
                    if self.belief_reward_mode == 'negative_efe' else 3300.),
                out_dir=MODEL_DIR, reward_contract=self.belief_reward_mode,
                filter_contract=dict(persistence=self.belief_tracker.persistence,
                                     likelihood=self.belief_tracker.likelihood.tolist(),
                                     observation_interface='motion_only_v1',
                                     control_interface=('cournot_mpc_v11' if self.control_profile == 'paper_v11' else
                                                        'cournot_mpc_v10' if self.control_profile == 'paper_v10' else
                                                        'cournot_mpc_v9' if self.control_profile == 'paper_v9' else
                                                        'cournot_mpc_v8' if self.revised_control else
                                                        'cournot_mpc_v7' if self.paper_control else 'cournot_mpc_v6'),
                                     game_controller=self.game_config['controller'],
                                     game_safety=self.cournot_mpc_safety))
        print('[GTRL] learning_mode=%s belief_reward=%s' % (self.learning_mode, self.belief_reward_mode))
        print('[Game] controller=%s safety=%s entry gate remains independent' %
              (self.game_config['controller'], self.cournot_mpc_safety))

    # ============ 数据持久化 ============
    def add_traj_data(self, state, env_sign, action, reward, save=True):
        """将轨迹数据存入 R-tree（save=False 时批量写、不逐条落盘）"""
        if not (self.paper_control and not self.game_config['learning']):
            self.TS.add_traj_data(state, env_sign, action, reward, save=save)

    def add_lane_data(self, state, lane_sign, action, reward, save=True):
        """将车道数据存入 R-tree（save=False 时批量写、不逐条落盘）"""
        if not (self.paper_control and not self.game_config['learning']):
            self.TS.add_lane_data(state, lane_sign, action, reward, save=save)

    # ============ 两层混合决策 ============
    def lane_hybrid(self, state, lane_sign, rule_lane_act, TS, lane_num=20):
        """车道级混合决策（转弯简化版：速度选择）"""
        TS_indexes = []
        for act in range(lane_num):
            ts_confidence = TS.TS_lane_ConfidenceValue(state, lane_sign, act, rule_lane_act, lane_num)
            TS_indexes.append(ts_confidence)
        hybrid_lane_act = np.argmax(np.array(TS_indexes))
        return hybrid_lane_act, TS_indexes

    def act_hybrid(self, state, env_sign, rule_action, TS, action_num=N_ACTIONS - 1,
                   explore_action=None, efe_values=None):
        """轨迹级混合决策（支持 ε-greedy 探索：explore_action 不为 None 时强制选择该动作）

        【③ 式46 接管规则】非探索时，不再直接 argmax，而是：
          bcv_default = BCV(规则/默认动作)      （规则动作为 BCV，其余动作为 WCV）
          若 ∃a: WCV(a) > BCV(默认) → RL 接管，选 WCV 最大者；否则跟随默认策略。

        【② 式56/57 EFE(s,a)】efe_values 非空且 EFE 开启时，把逐候选动作的
          R(s,a) = -EFE(s,a)（nats，≤0）按 efe_value_weight 换算后并入动作价值。
          这是把论文的 EFE(s_t,a_t) 真正接到**动作选择**上的位置：EFE 必须在候选
          动作之间可比（同一状态内随 a 变化），而不是对所有动作相同的状态级奖励标量。
        """
        learner = getattr(self, 'belief_learner', None)
        if learner is not None:
            action, indices = learner.select(explore_action, trust_enabled=self.use_wcv_bcv)
            self._last_took_over = learner.last['source'] == 'takeover'
            if self._last_took_over:
                self._takeover_num += 1
            # EFE's uncertainty is already part of the instantaneous learning
            # reward. Do not add a second one-step EFE score to a recursive Q.
            return action, indices
        TS_indexes = []
        _use_efe = bool(efe_values) and self.use_efe_reward
        for act in range(0, action_num + 1):
            ts_confidence = TS.TS_traj_ConfidenceValue(state, env_sign, act, rule_action, action_num)
            if _use_efe:
                # 式56：R = -EFE（≤0）→ 加到动作价值上（越接近 0 越优 = EFE 越小越优）
                ts_confidence = ts_confidence + self.efe_value_weight * float(
                    efe_values.get(act, 0.0))
            TS_indexes.append(ts_confidence)
        if explore_action is not None:
            hybrid_action = int(explore_action)
            self._last_took_over = False
        else:
            bcv_default = TS_indexes[int(rule_action)]
            wcv_by_action = {a: TS_indexes[a] for a in range(action_num + 1)
                             if a != int(rule_action)}
            # 【§71 消融开关·创新点③ WCV/BCV】关闭接管规则 ⇒ 恒用规则动作。
            #   式46 的接管规则是"用方差校正置信界(WCV)与基线置信界(BCV)比较来决定是否接管"。
            #   关闭后 `took_over` 恒 False，RL 的动作不再经此过滤 ⇒ 用于隔离③的贡献。
            if self.use_wcv_bcv:
                hybrid_action, took_over = takeover_rule(wcv_by_action, bcv_default, int(rule_action))
            else:
                hybrid_action, took_over = int(rule_action), False
            self._last_took_over = took_over
            if took_over:
                self._takeover_num += 1
        return hybrid_action, TS_indexes

    def _belief_model_probabilities(self, conf, action):
        """Action-conditioned transition prior from observable kinematics only."""
        rv = conf.get('rv_veh')
        if rv is None:
            return {kind: .5 for kind in BELIEF_TYPES}
        ego = self.dynamic_map.ego_vehicle
        arc = max(float(conf.get('arc_to_cross', 0.)), 0.)
        if self.efe_lateral:
            arc = lateral_arc_correction(arc, action_lateral(action),
                                          self._heading_change_ego_to_conflict(conf))
        arrival = time_to_cover(arc, max(float(ego.v), 0.), action_speed(action),
                               self.EFE_A_ACC, self.EFE_A_DEC)
        return {kind: rv_yield_probability(
            {'x': float(ego.x), 'y': float(ego.y), 'v': max(float(ego.v), .1)},
            {'x': float(rv.x), 'y': float(rv.y), 'v': max(float(rv.v), .1)},
            float(conf['conflict_x']), conf.get('ttc_boundary'), theta=self.type_inf.types[kind],
            acc_current=float(conf.get('rv_acc') or 0.), acc_follow=conf.get('rv_acc_follow'),
            t_ego=arrival) for kind in BELIEF_TYPES}

    def _begin_belief_decision(self, state, env_sign, rule_action, conf, episode):
        rv = conf.get('rv_veh')
        actor = vehicle_id(rv)
        acc = float(longitudinal_acceleration(rv) or 0.)
        observation = motion_observation(rv, self._type_yield_threshold())
        belief = self.belief_tracker.observe(actor, observation)
        self.type_inf.posterior = self.belief_tracker.type_posterior()
        allowed = [a for a, valid in enumerate(self._shield_allowed_actions(self.dynamic_map, self.env)) if valid]
        standoff = getattr(self, '_last_wait_standoff', None)
        if (getattr(self, 'shield_respect_commit', False) and getattr(self, '_last_committing', False)
                and standoff is not None and float(standoff) <= self.wait_margin):
            # Match the established clearance commitment rule: do not add a new
            # planning-time stop inside the band that the execution shield skips.
            allowed = list(range(N_ACTIONS))
        if not allowed:
            allowed = [int(BRAKE_ACTION)]
        baseline = int(rule_action) if int(rule_action) in allowed else int(shield_fallback_action(rule_action, allowed))
        context = list(state) + list(env_sign) + [float(rv is not None)]
        ego = self.dynamic_map.ego_vehicle
        context += [float(ego.x), float(ego.y), float(ego.v), float(ego.yaw),
                    float(rv.x-ego.x) if rv is not None else 0.,
                    float(rv.y-ego.y) if rv is not None else 0.,
                    float(rv.v) if rv is not None else 0.,
                    float(getattr(rv, 'yaw', 0.)) if rv is not None else 0.,
                    acc, float(bool(conf.get('committed')))]
        self.belief_learner.begin(context, belief, baseline, allowed, episode)
        self._belief_actor = actor

    def _belief_learning_reward(self, task_reward, action):
        """Keep VI's realized task reward and V's analytic -EFE distinguishable.

        Neither path subtracts policy KL here: soft V already accounts for it.
        In negative_efe mode collisions/completion are measured separately;
        unannounced terminal bonuses would cease to be the literal eq.56 target.
        """
        if self.belief_reward_mode == 'task_ambiguity':
            return float(task_reward)
        efe = self._efe_last
        if efe.get('error'):
            raise RuntimeError('Cannot learn -EFE from a failed EFE prediction: ' + str(efe['error']))
        if not efe.get('active'):
            return 0.  # No active game observation, not a fabricated terminal reward.
        return float(efe['reward'][int(action)])

    # ============ 转弯环境感知 ============
    def get_turn_env_sign(self, dynamic_map, obj_rect_num=8):
        """
        转弯环境标志位（连续编码，8 维）:
          [0] 前方最近车辆距离 (m, 默认50)
          [1] 左前方最近车辆距离 (m, 默认50)
          [2] 右前方最近车辆距离 (m, 默认50)
          [3] 后方最近车辆距离 (m, 默认50)
          [4] 交叉冲突点时间差 (s, 越小越危险, 默认8)
          [5] 自车到冲突点距离 (m, 默认50)
          [6] 当前道路曲率 (1/m)
          [7] 路权标志 (0/1)
        """
        env_sign = np.array([50.0] * obj_rect_num, dtype=float)
        ego = dynamic_map.ego_vehicle
        ego_x, ego_y = ego.x, ego.y
        ego_yaw = ego.yaw  # 弧度制

        for vehicle in dynamic_map.objects[:20]:
            if not hasattr(vehicle, 'x'):
                continue
            dx = vehicle.x - ego_x
            dy = vehicle.y - ego_y
            dist = math.sqrt(dx**2 + dy**2)
            if dist > 60 or dist < 0.5:
                continue

            # 相对角度（相对于自车航向角）
            rel_angle = _nang(math.atan2(dy, dx) - ego_yaw)

            # 前方: |rel_angle| < 30°
            if abs(rel_angle) < 0.52:
                env_sign[0] = min(env_sign[0], dist)
            # 左前: 30° ~ 120°
            elif 0.52 < rel_angle < 2.09:
                env_sign[1] = min(env_sign[1], dist)
            # 右前: -120° ~ -30°
            elif -2.09 < rel_angle < -0.52:
                env_sign[2] = min(env_sign[2], dist)
            # 后方: |rel_angle| > 150°
            elif abs(rel_angle) > 2.62:
                env_sign[3] = min(env_sign[3], dist)

        # 交叉冲突信息（博弈关键量）
        cross_gap, dist_to_cross = crossing_gap_info(dynamic_map, env=getattr(self, 'env', None))
        env_sign[4] = min(cross_gap, 8.0)
        env_sign[5] = dist_to_cross

        # 曲率
        env_sign[6] = abs(_get_curvature(dynamic_map))

        # 路权（航向角变化 > 0.3 rad）
        env_sign[7] = 1.0 if self.get_turn_road_right(dynamic_map) else 0.0

        return env_sign

    def get_turn_lane_sign(self, dynamic_map, obj_rect_num=4):
        """
        转弯车道标志位（替代原版7x2 TTC矩阵）
        4x2矩阵: [自车道前车TTC, 自车道后车TTC, 交叉方向冲突TTC, 弯道曲率]
        """
        lane_sign = np.full((obj_rect_num, 2), -100.0)
        lane_sign[0] = np.array([0, 0])  # [在道路上, 在弯道中]

        # 交叉方向冲突时间差（冲突点时间差，替代失明的径向 TTC）
        cross_gap, _ = crossing_gap_info(dynamic_map, env=getattr(self, 'env', None))
        safe_ttc = min(10.0, round(cross_gap)) if cross_gap < 10.0 else -1.0
        lane_sign[2] = np.array([safe_ttc, 0.0])

        return lane_sign

    def get_turn_road_right(self, dynamic_map):
        """转弯路权判断：航向角变化超过阈值表示已进入目标方向"""
        if self.initial_yaw is None:
            self.initial_yaw = dynamic_map.ego_vehicle.yaw
        yaw_change = abs(_nang(dynamic_map.ego_vehicle.yaw - self.initial_yaw))
        return yaw_change > 0.3

    # ============ P0: 安全护栏（冲突预测）============
    def _action_would_conflict(self, dynamic_map, env, action):
        """
        预测: 如果以动作 action 的档位速度冲向冲突点，是否会与直行车流冲突。
        返回 True = 危险（应回退规则 / 从探索候选剔除）。

        判定条件（放宽版，避免"车流一直有车 → 永远拦死"）:
          - 仅当 ego 距冲突点 < 15m（真正进入冲突区域）才评估；
          - |dt| = |t_veh - t_ego(action)| < 清空时间 + 0.5s。
        """
        conf = crossing_conflict_detail(dynamic_map, env)
        if conf['committed'] or conf['n_vehicles'] == 0:
            return False
        if conf['dist_to_cross'] > 15.0:
            return False   # 远离冲突点：允许自由选择速度，接近后再判断
        # 该动作档位下的预期到达时间
        if action is None or action < 0 or action >= N_ACTIONS:
            action = 0
        # speed 模式：动作即速度档；lateral 模式：动作为横向 offset，速度取标称巡航
        if ACTION_MODE == 'lateral':
            from Agent.tools_dds.LaneTrajectoryPlanner import LATERAL_TARGET_SPEED
            v_cand = max(float(LATERAL_TARGET_SPEED), 0.5)
        else:
            v_cand = max(action_speed(action), 0.5)
        t_ego_cand = conf['arc_to_cross'] / v_cand
        # 【④·P3】清空时间同样要把交叉带宽度算进去（旧式只算 4m 车身 → 判据偏松）
        _ego_len = float(getattr(dynamic_map.ego_vehicle, 'length', 4.5) or 4.5)
        clearance = entry_clearance_time(v_cand, ego_len=_ego_len,
                                        band=self.clear_band, margin=self.clear_margin)
        dt = conf['t_veh'] - t_ego_cand
        # 无论 ego 先到还是后到，只要到达时间差过小就有冲突风险
        return abs(dt) < clearance

    def _speed_for_slack(self, slack, a_brake=3.0):
        """【§51.3】剩余净空 `slack`(m) 下允许的最大速度（m/s）。

        解 **v·dt_lag + v²/(2·a_eff) = slack**：
            v = -a_eff·dt_lag + sqrt((a_eff·dt_lag)² + 2·a_eff·slack)
        其中 `a_eff = brake_eff · a_brake`。

        为什么必须含 `v·dt_lag` 项：旧式 `v = sqrt(2·a_brake·slack)` 假设
        **瞬时、精确、无滞后**的减速。实测反证：标称等待线余量 1.5 m，而自车实际
        停在 `wait_standoff = −0.21 ~ −0.68 m`（3 seed × 20 回合，32/32 碰撞帧
        `clamp_stopped=1` 且 `wait_standoff ≤ 0`）⇒ **超调 1.7~2.2 m**。
        把滞后与有效减速度显式计入后，同样 2 m 净空下允许速度从
        `sqrt(2·3.0·2.0)=3.46 m/s` 降到 **1.76 m/s**，不再冲过等待线。
        """
        try:
            sl = float(slack)
        except (TypeError, ValueError):
            return 0.0
        if sl <= 0.0:
            return 0.0
        a_eff = max(float(a_brake) * max(self.brake_eff, 1e-3), 0.1)
        dt = max(self.act_delay, 0.0)
        return max(0.0, -a_eff * dt + math.sqrt((a_eff * dt) ** 2 + 2.0 * a_eff * sl))

    def _p_yield_safe(self, veh, conf, ttc_boundary):
        """【§62】逐车让行概率的**保守**估计，返回 (p_lcb, p_prior, p_hat, n_obs)。

        三层：
          1. **模型先验** `p_prior = rv_yield_probability(ego, rv, conflict_x, ttc, theta=θ)`
             —— 用当前类型后验 θ（论文 §IV-C / 式17–18 的推断结果），不再是常数 0.5。
          2. **逐车观测更新**：用相同运动观测分类得到的让行/抢行次数做
             贝塔-二项更新（先验强度 `p_yield_prior_k`），各方法权限一致。
          3. **下置信界** `p_lcb = p_hat − z·sqrt(p_hat(1−p_hat)/(n+k))`，再夹到 [0.05,0.95]。
        **为什么取"下界"**：`p_yield` 越小 ⇒ 抢行分支权重越大 ⇒ risk 越大 ⇒ 越保守。
        §59.4 的敏感性扫描已证明 p_yield 乐观是危险的（假设 0.7 而实际 0.5 ⇒ 假放行率 42%），
        所以任何不确定性都必须朝"更保守"的方向折算。
        """
        p_prior = 0.5
        try:
            _ev = self.dynamic_map.ego_vehicle
            ego_state = {'x': float(getattr(_ev, 'x', 0.0)),
                         'y': float(getattr(_ev, 'y', 0.0)), 'v': float(getattr(_ev, 'v', 0.0))}
            rv_state = {'x': float(veh.get('x', 0.0)), 'y': float(veh.get('y', 0.0)),
                        'v': float(veh.get('v', 0.0))}
            p_prior = float(rv_yield_probability(
                ego_state, rv_state, float(conf.get('conflict_x', 0.0)),
                ttc_boundary, theta=float(self.type_inf.theta()),
                acc_current=float(veh.get('acc') or 0.),
                acc_follow=following_acceleration(
                    veh, self.dynamic_map.objects,
                    v0=float(os.environ.get('DSH_TRAFFIC_V', '6.0'))),
                t_ego=conf.get('t_ego')))
        except Exception as _pe:
            self._clr_err = '%s: %s' % (type(_pe).__name__, _pe)
        _nb = max(len(self._intent_hist), 1)
        _bi = min(_nb - 1, max(0, int((self._last_intent_ego or 0.0) * _nb)))
        _ib_n, _ib_y = self._intent_hist[_bi]
        if _ib_n >= max(int(self.intent_min_obs), 1):
            _p_emp = float(_ib_y) / float(_ib_n)
            self._last_intent_rate = _p_emp
            _kc = max(float(self.p_yield_prior_k), 1e-6)
            p_prior = (_ib_n * _p_emp + _kc * p_prior) / (_ib_n + _kc)
        _vid = veh.get('id')
        _n, _ny = self._yield_hist.get(_vid, (0, 0)) if _vid is not None else (0, 0)
        _k = max(float(self.p_yield_prior_k), 1e-6)
        p_hat = (_ny + _k * p_prior) / (_n + _k)
        se = math.sqrt(max(p_hat * (1.0 - p_hat), 1e-6) / (_n + _k))
        p_lcb = p_hat - float(self.p_yield_z) * se
        return max(0.05, min(0.95, p_lcb)), p_prior, p_hat, _n

    def _update_yield_history(self, conf=None):
        """【§62】把交叉车流的让行/抢行**决策变化**累加成逐车观测计数。

        只统计**变化**（不是每帧），避免把同一决策的连续帧当成独立观测而虚增样本量。
        """
        try:
            _beh = {vehicle_id(v): self._observed_rv_action(v)
                    for v in self.dynamic_map.objects if vehicle_id(v) is not None}
            if not _beh:
                return
            _it = 0.0
            try:
                _it = float(ego_intent(
                    float(getattr(self.dynamic_map.ego_vehicle, 'y', 0.0)),
                    float((conf or {}).get('conflict_y', -138.0)), _BAND_HALF))
            except (TypeError, ValueError):
                _it = 0.0
            self._last_intent_ego = float(_it)
            _nb = max(len(self._intent_hist), 1)
            _bi = min(_nb - 1, max(0, int(_it * _nb)))
            for _vid, _b in list(_beh.items()):
                if self._yield_last.get(_vid) == _b:
                    continue
                self._yield_last[_vid] = _b
                _n, _ny = self._yield_hist.get(_vid, (0, 0))
                self._yield_hist[_vid] = (_n + 1, _ny + (1 if _b == 'yield' else 0))
                self._intent_hist[_bi][0] += 1
                if _b == 'yield':
                    self._intent_hist[_bi][1] += 1
        except Exception as _ue:
            self._clr_err = '%s: %s' % (type(_ue).__name__, _ue)

    def _approach_candidates(self, conf):
        """【§60】返回所有接近车的 `(t_yield, t_rush)` 候选，供 `commit_risk` 使用。

        · 覆盖**所有**车（`dynamic_map.objects`），不依赖 rv/fv 分类
          —— §57/§58 已证明"依赖可被影响的分类"是这套系统的通病。
        · 车流沿 **−x** 流动 ⇒ 只有 `x > conflict_x` 的车才是接近车。
        · `t_yield` = 维持当前速度到达；`t_rush` = 加速到巡航到达（IDM 最坏情况）。
        """
        out, plist = [], []
        try:
            from Planning_library.objective_reward import _veh_list as _vl
            from Planning_library.rv_decision import time_to_cover as _ttc
            _cx = float(conf.get('conflict_x', 0.0))
            _cy = float(conf.get('conflict_y', -138.0))
            _cr = self._rv_rush_speed() or 4.41
            self._update_yield_history(conf)
            for v in _vl(getattr(self.dynamic_map, 'objects', None)):
                if v['x'] <= _cx:
                    continue
                if abs(v['y'] - _cy) > 8.0:
                    continue
                d = float(v['x']) - _cx
                vn = max(float(v['v']), 0.1)
                t_y = d / vn
                w = worst_case_arrival_time(_ttc, d, vn, max(vn, float(_cr)), 2.0, 3.0)
                t_r = float(w) if (w is not None and math.isfinite(float(w))) else t_y
                if self.p_yield_mode == 'model':
                    _ttc_b = None
                    try:
                        _ttc_b = float(conf.get('lcttc_min'))
                    except (TypeError, ValueError):
                        _ttc_b = None
                    _p, _pp, _ph, _pn = self._p_yield_safe(v, conf, _ttc_b)
                    self._last_pyield_prior = float(_pp)
                    self._last_pyield_hat = float(_ph)
                    self._last_pyield_n = int(_pn)
                else:
                    _p = float(self.p_yield_commit)
                out.append((float(t_y), float(t_r)))
                plist.append(float(_p))
            _ord = sorted(range(len(out)), key=lambda i: min(out[i]))
            out = [out[i] for i in _ord]
            plist = [plist[i] for i in _ord]
        except Exception as _ae:
            self._clr_err = '%s: %s' % (type(_ae).__name__, _ae)
        return out, plist

    def _band_occ_now(self, conf):
        """【P5 测量版】本帧横向扫掠带占用（只记录，暂不影响任何决策）。"""
        try:
            _ego = self.dynamic_map.ego_vehicle
            _vs = []
            for _v in getattr(self.dynamic_map, 'objects', []) or []:
                if not hasattr(_v, 'x'):
                    continue
                _vs.append({'x': float(_v.x), 'y': float(_v.y),
                            'yaw': float(getattr(_v, 'yaw', 0.0)),
                            'v': float(getattr(_v, 'v', 0.0)),
                            'vx': float(getattr(_v, 'vx', 0.0)),
                            'length': float(getattr(_v, 'length', 4.0)),
                            'width': float(getattr(_v, 'width', 2.0))})
            return band_occupancy(float(_ego.x), float(_ego.y), float(getattr(_ego, 'yaw', 0.0)),
                                  float(getattr(_ego, 'v', 0.0)),
                                  float(getattr(_ego, 'length', 4.5) or 4.5),
                                  float(getattr(_ego, 'width', 2.0) or 2.0),
                                  float(conf.get('conflict_y', -138.0)), _vs)
        except Exception:
            return None

    def _rv_rush_speed(self):
        """RV 的"抢行目标速度"：巡航速度（取不到则 None → 退回当前速度）。"""
        try:
            _ctm = getattr(self.env, 'cross_traffic', None)
            _c = getattr(_ctm, 'rv_cruise_speed', None) or getattr(_ctm, 'desired_speed', None)
            return float(_c) if _c else None
        except Exception:
            return None

    def _worst_thw_rv(self, conf):
        """【P4-②】RV 的抢行最坏情况 THW（s）。无 RV 时原样返回（不参与裁决）。"""
        try:
            _thw = conf.get('thw_boundary_rv')
            _rv = conf.get('rv_veh')
            if _rv is None:
                return _thw
            _vr = self._rv_rush_speed()
            _v0 = max(float(getattr(_rv, 'v', 0.0)), 0.1)
            _v_rush = max(_v0, _vr) if _vr else _v0
            _ego_v = max(float(getattr(self.dynamic_map.ego_vehicle, 'v', 0.0)), 0.1)
            return worst_case_thw(_thw, _ego_v, _v_rush)
        except Exception:
            return conf.get('thw_boundary_rv')

    def _worst_case_t_veh_list(self, conf):
        """【P4-①】返回**最坏情况**下每辆接近车到达冲突点的时间列表（s）。

        与 `conf['t_veh_sorted']`（匀速假设）的区别：
          · 对每辆车用 `max(当前速度, 抢行目标=巡航)` 作为抢行目标，按 IDM 最大加速度
            由 `time_to_cover` 估算 ⇒ 一辆"正在让行、速度已降到 1.3 m/s"的 RV
            不再被当成 7 s 才到，而是 ~2.6 s（它随时可能重决策为抢行）。
          · 同时把 `t_veh_sorted` 里的值一并保留（取两者较小），避免漏掉慢速逼近车。
        取不到车辆对象时回退到 `t_veh_sorted`（退化为旧口径，不改变安全性下限）。
        """
        _base = list(conf.get('t_veh_sorted', []) or [])
        try:
            from Planning_library.rv_decision import time_to_cover
            _cx = float(conf.get('conflict_x', 0.0))
            _cruise = None
            try:
                _ctm = getattr(self.env, 'cross_traffic', None)
                _cruise = getattr(_ctm, 'rv_cruise_speed', None) or getattr(_ctm, 'desired_speed', None)
            except Exception:
                _cruise = None
            _v_rush_global = float(_cruise) if _cruise else None
            _worst = []
            for _key in ('rv_veh', 'fv_veh'):
                _o = conf.get(_key)
                if _o is None:
                    continue
                try:
                    _d = abs(float(getattr(_o, 'x', 0.0)) - _cx)
                    _v0 = max(float(getattr(_o, 'v', 0.0)), 0.1)
                    _vr = max(_v0, _v_rush_global) if _v_rush_global else _v0
                    _w = worst_case_arrival_time(time_to_cover, _d, _v0, _vr, 2.0, 3.0)
                    if math.isfinite(_w):
                        _worst.append(_w)
                except Exception:
                    continue
            if not _worst:
                return _base
            # 【§57 关键修复】把**所有接近车**一并纳入，而不只是被分类出的 rv/fv。
            #   P4-①b 当年为了压卡死率把它删掉了（注释理由：14 辆车全算进去 ⇒
            #   "占用窗不重叠"几乎永不满足 ⇒ 卡死 30%）。但那个理由是**用安全性换卡死率**，
            #   而且它引入的正是本会话反复出现的同一个模式：
            #   **安全判据依赖一个"可被影响的分类"** ⇒ 未分类的车对判据**不可见**。
            #   实测（expS89_FIX_CX4）：自车已能进带（`band_entry_x=4.05`、
            #   `arc_to_cross` 深到 4.14），但碰撞帧全部 `gap_ok=0` + `committing=1`
            #   ⇒ 判据在"当初批准进入"时漏掉了某辆未被分类为 rv/fv 的接近车。
            #   P4-①b 原来的"远离时冻住"问题**已由调用点的
            #   `_in_entry_zone (_arc <= 15)` 距离门解决**，不需要再靠"少看几辆车"来压卡死。
            #   `DSH_WORSTCASE_ALL=0` 可回退到只算 rv/fv 做消融对照。
            if not self.worstcase_all:
                return sorted(_worst)
            # 【§58 关键修复】把**最坏情况（恢复巡航）**应用到**所有**接近车，
            #   而不是只对被分类的 rv/fv。
            #   BUG 实测（expS90_WC_ALL）：授权帧 `n_vehicles=2`、`t_ego_go=0`、
            #   `clr_go=4.05`（占用窗 [0,4.05]）却 `gap_ok=1` ⇒ 判据认为"这 2 辆车都 ≥4.05 s 才到"。
            #   原因：判据里 `t_veh = 距离 / 车辆**当前速度**`，而车流为了避让我
            #   **正好降到让行速度 ~1.3 m/s** ⇒ 预测到达 7.7 s（远超我的 4.05 s 窗）
            #   ⇒ 判"安全" ⇒ 我进入 ⇒ 它**重决策恢复巡航** ⇒ 撞上。
            #   （§57 只对 rv/fv 用了最坏情况，t_veh_sorted 里的其它车仍是乐观的让行速度。）
            #   与之前同类根因一致：**安全判据被"对手暂时减速"骗过**，而对手减速
            #   恰恰是我接近造成的 ⇒ 一个方向相反的激励。
            #   修法：对**所有**接近车统一按 `max(v_now, 巡航)` + IDM 最大加速度
            #   估算到达时间（客观、与分类无关）。`DSH_FULL_WORSTCASE=0` 回退做消融。
            _allw = []
            for _t in (_worst + _base):
                # 【§60】用类型检查代替 try/except：不吞异常（反静默棘轮会拦），
                #   且语义更明确 —— 非数值项直接跳过，是契约而非异常。
                if isinstance(_t, bool) or not isinstance(_t, (int, float)):
                    continue
                _tf = float(_t)
                if math.isfinite(_tf):
                    _allw.append(_tf)
            if self.full_worstcase:
                try:
                    from Planning_library.rv_decision import time_to_cover as _ttc
                    from Planning_library.objective_reward import _veh_list as _vl
                    _cx2 = float(conf.get('conflict_x', 0.0))
                    _cy2 = float(conf.get('conflict_y', -138.0))
                    _cr2 = float(_v_rush_global) if _v_rush_global else 4.41
                    for _v2 in _vl(getattr(self.dynamic_map, 'objects', None)):
                        # 车流沿 −x 流动 ⇒ x > 冲突点 x 的车才是"接近车"
                        if _v2['x'] <= _cx2:
                            continue
                        if abs(_v2['y'] - _cy2) > 8.0:
                            continue
                        _d2 = float(_v2['x']) - _cx2
                        _w2 = worst_case_arrival_time(
                            _ttc, _d2, max(float(_v2['v']), 0.1),
                            max(float(_v2['v']), _cr2), 2.0, 3.0)
                        if math.isfinite(float(_w2)):
                            _allw.append(float(_w2))
                except Exception as _we:
                    # 【不静默】客观项算不出来必须显形
                    self._clr_err = '%s: %s' % (type(_we).__name__, _we)
            return sorted(set(_allw))
        except Exception:
            return _base

    def _type_yield_threshold(self):
        """【0''-b】"让行"判定阈值（m/s）：ratio × RV 巡航速度；取不到则回退绝对值。

        旧实现在此恒为 6.0 > 巡航 4.41 ⇒ 恒判"让行"。详见 __init__ 里的 P0-b 注释。
        返回 -1.0 表示实在取不到（调用方应视为无法观测，宁可不观测也不要喂错标签）。
        """
        if getattr(self, 'type_yield_speed_abs', None) is not None:
            return float(self.type_yield_speed_abs)      # 显式绝对值（消融/兼容）
        _cruise = None
        try:
            _ctm = getattr(self.env, 'cross_traffic', None)
            _cruise = getattr(_ctm, 'rv_cruise_speed', None)
            if _cruise is None:
                _cruise = getattr(_ctm, 'desired_speed', None)
        except Exception:
            _cruise = None
        try:
            if _cruise is not None and float(_cruise) > 0.1:
                return float(self.type_yield_ratio) * float(_cruise)
        except (TypeError, ValueError):
            pass
        return float(self.type_yield_speed_th)           # 兜底（旧默认 6.0）

    def _shield_allowed_actions(self, dynamic_map, env, conf=None):
        """【创新点④】边界安全的动作屏蔽：返回 N_ACTIONS 长的 bool 表（True=允许）。

        论文 ④ 定义了边界模型（d_AB / TTC_boundary / THW_boundary），论文 §IV 又明确
        对手意图不确定时会"提高触发**保守确定性策略**的概率"。此前该层只影响
        **奖励**与 WCV 方差，**从未约束动作空间** —— 实测（expF_paper100，100 回合）
        在 `lcttc_rv < 1.0 s` 的 1491 帧里有 **1240 帧（83%）最终动作不是刹车**，
        其中 241 帧是 ε-greedy 在 `lcttc_rv < 0.5 s` 时选了非刹车档 ⇒ 碰撞率 77%。
        本函数把 ④ 变成硬约束：边界已逼近时只允许"不加速"的档位。

        `committed=True`（已越过冲突点）不屏蔽 —— 此时加速驶离路口才是正确的保守动作。

        【为什么用 min(lcttc_rv, lcttc_fv) 而不是只看 rv】
        rv/fv 的**角色划分本身依赖 `t_ego = arc/v`**：自车减速 ⇒ `t_ego↑` ⇒ 所有交叉车
        被判成"已先通过"的 fv ⇒ **rv 角色为空 ⇒ lcttc_rv=inf**。若屏蔽只看 rv，自车就能
        靠减速把自己的屏蔽层"关掉"（这正是 P1-f 奖励劫持的同一机理）。
        改用**两个角色的最小边界 TTC**后，这一逃逸通道被堵死；而"路口真的没车"仍是 inf
        → 不屏蔽（不会因为没车就锁死自车）。
        """
        if not getattr(self, 'shield_enable', True):
            return [True] * N_ACTIONS
        try:
            if conf is None:
                conf = crossing_conflict_detail(dynamic_map, env,
                                                beta=self.type_inf.theta())
            _lc = _finite_min(conf.get('lcttc_rv'), conf.get('lcttc_fv'))
            # 【§60】④屏蔽也必须覆盖**所有**车，不能只看被分类的 rv/fv。
            #   与 §57/§58 同一根因：分类可被自车影响 ⇒ 未分类车对屏蔽层不可见。
            #   复用 §48 已落地的客观量 `worst_lcttc`（对**所有**车取最小 LCTTC）。
            if self.shield_all_vehicles:
                try:
                    from Planning_library.objective_reward import (
                        worst_lcttc as _wlc, _veh_list as _vl)
                    _ev = self.dynamic_map.ego_vehicle
                    _h_all, _ = _wlc(
                        float(_ev.x), float(_ev.y), float(getattr(_ev, 'yaw', 0.0)),
                        max(float(getattr(_ev, 'v', 0.0)), 0.0),
                        _vl(getattr(self.dynamic_map, 'objects', None)),
                        horizon=self.shield_lcttc_horizon)
                    _lc = _finite_min(_lc, _h_all)
                    self._last_shield_lc_all = float(_h_all)
                except Exception as _se:
                    # 【不静默】客观量算不出来必须显形
                    self._clr_err = '%s: %s' % (type(_se).__name__, _se)
            # 【P4-⓪b 触发量替换】用**抢行最坏情况 THW** 取代原始 THW 作触发量：
            #   原始 thw 只用自车速度 ⇒ 对手提速不反映；worst_case_thw 把"对手恢复巡航"
            #   算进接近速度 ⇒ 有秒级提前量，且只在真有近期冲突时触发。
            _ego_v_now = float(getattr(self.dynamic_map.ego_vehicle, 'v', 0.0))
            _vr = self._rv_rush_speed()
            _th_rv = worst_case_thw(conf.get('thw_boundary_rv'), _ego_v_now,
                                    max(float(getattr(conf.get('rv_veh'), 'v', 0.0) or 0.0), _vr or 0.0))
            _th_fv = worst_case_thw(conf.get('thw_boundary_fv'), _ego_v_now,
                                    max(float(getattr(conf.get('fv_veh'), 'v', 0.0) or 0.0), _vr or 0.0))
            _th = _finite_min(_th_rv, _th_fv)
            # 【可审计性】把"屏蔽自己判定的危险量"存下来供逐帧日志记录。
            #   否则无法区分"屏蔽失效"与"本帧在屏蔽阈值之上、本就不该拦"。
            self._last_shield_lcttc_min = _lc
            # ⚠ 这里**不能**传 shield_thw_critical：boundary_shield_active 没有该形参。
            #   实测教训：一次无 count 的 str.replace 把该 kwarg 也加到了本调用上 ⇒
            #   屏蔽**每帧抛 TypeError** ⇒ except 分支 fail-open ⇒ ④ 完全失效
            #   （`lcttc_min`/`shield_danger` 全空、`shield` 改写 0%），而我只看到
            #   一行 print，连续几轮都没发现。已加 `_shield_exc_num` 计数并打进 CONFIG。
            # 【④ 2D】临界档标志（供横向屏蔽判 danger_tier）
            try:
                _lc_c = float(_lc) if _lc is not None else float('inf')
                _th_c = float(_th) if _th is not None else float('inf')
                self._last_shield_crit = bool(
                    (math.isfinite(_lc_c) and _lc_c < SHIELD_LCTTC_CRITICAL)
                    or (float(self.shield_thw_critical) > 0.0 and math.isfinite(_th_c)
                        and _th_c < float(self.shield_thw_critical)))
            except Exception:
                self._last_shield_crit = False
            self._last_shield_danger = boundary_shield_active(
                _lc, _th, conf.get('committed', False),
                shield_lcttc=self.shield_lcttc, shield_thw=self.shield_thw)
            # 【S3】横向带占用早期预警：命中则只允许"不加速"（不改刹车档）
            _band = self._band_occ_now(conf)
            _warn = False
            try:
                _fc = float((_band or {}).get('front_clearance'))
                _warn = bool((_band or {}).get('occupied')) and \
                    (0.0 < _fc <= self.band_warn_dist) and \
                    (not conf.get('committed', False))
            except (TypeError, ValueError):
                _warn = False
            _mask = boundary_shield_mask(
                ACTION_SPEEDS,
                _lc, _th,
                conf.get('committed', False),
                float(getattr(dynamic_map.ego_vehicle, 'v', 0.0)),
                shield_lcttc=self.shield_lcttc, shield_thw=self.shield_thw,
                shield_thw_critical=self.shield_thw_critical)
            if _warn:
                _v_now = max(float(getattr(dynamic_map.ego_vehicle, 'v', 0.0)), 0.0)
                _merged = [bool(_mask[i]) and (float(ACTION_SPEEDS[i]) <= _v_now + 0.5)
                           for i in range(len(_mask))]
                if not any(_merged):
                    # 兜底：至少保留**最慢速度层**（不能只留 index 0 —— 2d 空间下
                    # index 0 是 (v=0, di=-1.5)，会把横向也一起改掉）
                    _slow = set(slowest_speed_actions())
                    _merged = [a in _slow for a in range(N_ACTIONS)]
                _mask = _merged
                self._band_warn_num = getattr(self, '_band_warn_num', 0) + 1
            # ===== 【④ 二维屏蔽·横向分量】=====
            #   用户验收 V4：屏蔽必须**纵向与横向都屏**。纵向由上面的 `boundary_shield_mask`
            #   负责（它只吃 ACTION_SPEEDS）；这里按候选轨迹的额外 y 向投影筛横向档。
            self._last_lateral_mask = [True] * len(TURN_2D_LATERALS)
            self._last_lat_screened = 0
            if ACTION_MODE == '2d' and self.lat_shield_enable:
                try:
                    _tier = 2 if bool(getattr(self, '_last_shield_crit', False)) else (
                        1 if bool(self._last_shield_danger) else 0)
                    _lm = lateral_shield_mask(
                        TURN_2D_LATERALS, _tier,
                        float(getattr(dynamic_map.ego_vehicle, 'yaw', 0.0)),
                        float(conf.get('arc_to_cross', 0.0)),
                        ego_len=float(getattr(dynamic_map.ego_vehicle, 'length', 4.5) or 4.5),
                        ego_wid=float(getattr(dynamic_map.ego_vehicle, 'width', 2.0) or 2.0),
                        standoff=getattr(self, '_last_wait_standoff', None),
                        margin=self.wait_margin)
                    self._last_lateral_mask = list(_lm)
                    if not all(_lm):
                        self._last_lat_screened = sum(1 for x in _lm if not x)
                        for _a in range(N_ACTIONS):
                            if not _lm[_a % len(TURN_2D_LATERALS)]:
                                _mask[_a] = False
                        if not any(_mask):
                            _mask[0] = True
                except Exception:
                    self._last_lateral_mask = [True] * len(TURN_2D_LATERALS)
            self._last_band_warn = bool(_warn)
            return _mask
        except Exception as _e:
            # 屏蔽层异常时**不锁死**自车（fail-open），但要留下痕迹
            self._shield_exc_num = getattr(self, '_shield_exc_num', 0) + 1
            if self._shield_exc_num <= 3:      # 只打前 3 次，但**始终计数**
                print(f"[TurnEnv][④Shield] 屏蔽计算异常（第{self._shield_exc_num}次）"
                      f"本次不屏蔽: {type(_e).__name__}: {_e}")
            self._last_shield_lcttc_min = None
            self._last_shield_danger = None
            return [True] * N_ACTIONS

    def _rv_action_entropy(self):
        """【式(18)】从**历史路径**统计对手动作频率并求熵（log2，与论文一致）。"""
        t = self.info_track
        if t is None:
            return None
        try:
            pid = getattr(self, '_info_rv_pid', None)
            return rv_action_entropy(t.history.actions_of(pid)) if pid is not None else None
        except Exception:
            return None

    def _info_cardinality(self):
        """式(16)：`|I_{i,t}|`（与 ego 观测相容的历史条数）。取不到时返回 None。"""
        st = getattr(self, '_last_info_state', None)
        if not st:
            return None
        try:
            return max(1, int(st['cardinality'].get(0, 1)))
        except Exception:
            return None

    def _observed_rv_action(self, rv):
        """Motion-derived action proxy; it is an estimate, never a hidden label."""
        return 'yield' if motion_observation(rv, self._type_yield_threshold()) == 0 else 'rush'

    def _update_information_set(self, episode, step, conf, ego, action, reward):
        """【式(11)(12)(17)】每帧真实填充信息集/历史路径。

        · 式(11)：把 ego 与 RV 的 `(s_j, a_j, U_j)` 记进 `I_i`
        · 式(12)：把联合动作并入历史路径 `p_t`
        · 式(17)：类型**空间**是共同知识；ego 对 RV 的**私有类型**维持后验
        · 式(9) ：`with_beta()` 把隐藏类型 β 接到状态第 6 维
        `self._last_info_state` 随后被 (§ 式16) `_info_cardinality()` 消费并写入日志。
        """
        t = self.info_track
        if t is None:
            return
        if self._info_ep != episode:
            self._info_ep = episode
            self._info_step = 0
            t.reset(episode, participants=(0,))
        try:
            beta_ego = 0.  # Ego's declared type is independent of RV's inferred mean.
            beta_rv = float(self.type_inf.theta())
            _es = with_beta((float(ego.x), float(ego.y), float(ego.v),
                             float(getattr(ego, 'acc', 0.0) or 0.0),
                             float(getattr(ego, 'yaw', 0.0) or 0.0)), beta_ego)
            t.observe(self._info_step, 0, _es, action, float(reward))
            rv = conf.get('rv_veh')
            # All methods use a motion estimate with the actual actor identity.
            # Missing identity never aliases an unrelated opponent or old action.
            _rv_pid = vehicle_id(rv)
            _rv_act = self._observed_rv_action(rv) if rv is not None else None
            self._info_rv_pid = _rv_pid
            self._last_rv_action = _rv_act
            if rv is not None and _rv_pid is not None:
                _rs = with_beta((float(rv.x), float(rv.y), float(getattr(rv, 'v', 0.0) or 0.0),
                                 float(longitudinal_acceleration(rv) or 0.),
                                 float(getattr(rv, 'yaw', 0.0) or 0.0)), beta_rv)
                _u_rv = -float(reward)          # 零和：U_rv = −U_ego（式24）
                t.observe(self._info_step, _rv_pid, _rs, _rv_act, _u_rv)
                try:
                    t.set_posterior(_rv_pid, dict(self.type_inf.posterior))
                except Exception:
                    pass
            joint = {0: action}
            if rv is not None and _rv_pid is not None:
                joint[_rv_pid] = _rv_act
            t.append_joint_action(self._info_step, joint)
            self._info_step += 1
            self._last_info_state = t.info_state()
            self._info_err = None
        except Exception as _ie:
            # 【不再静默】本会话已三次栽在 `except: pass` 吞异常上（④屏蔽 TypeError、
            # window_causal 只 print、信息集填充全空）。异常必须显形并进日志。
            self._info_err = '%s: %s' % (type(_ie).__name__, _ie)

    def _pick_exploration_action(self, candidates):
        """【V1】覆盖式探索：在候选集里挑**访问次数最少**的动作（并列则均匀随机）。

        为什么不用纯 `random.choice`：实测 v≥2 的动作只在 ~7% 的帧里可进，
        而可进 ≠ 会被选中；`di=+1.5` 档在 680 个可进帧里零命中。
        最少访问优先从构造上保证 12 个动作都会被访问到（V1），
        同时让"零样本动作"不再被哨兵永久排除。
        """
        try:
            cs = [int(a) for a in (candidates or [])]
        except Exception:
            cs = []
        if not cs:
            return random.randrange(N_ACTIONS)
        if not getattr(self, 'expl_coverage', True):
            return random.choice(cs)
        # ===== 【V1 构造性保证】"未访问动作"优先，且**等它被屏蔽允许**再选 =====
        #   实测（3 种子 × 20 回合）两版都失败，根因是 ④ 屏蔽第一档只放行
        #   `speed <= v_now + 0.5`，而自车 91% 的帧是慢速 ⇒ **v≥2 整行几乎永不被允许**；
        #   逐回合轮转会在指针经过它们时被跳过 ⇒ 仍然零样本。
        #   修法：维护**全局未访问集合** `_unvisited`；每次探索事件里，只要"未访问 ∩ 屏蔽允许"
        #   非空就选其中下标最小的那个，并把它从未访问集合移除。
        #   ⇒ 一旦某动作在**任何**时刻被屏蔽允许，它就必然被选中 ⇒ V1 成为**构造性判据**；
        #     而"被屏蔽永远不允许"的动作**不会**被强行执行（安全层不被绕过）。
        try:
            # ⚠️ 必须用**最终候选集** `cs`（已过 ④屏蔽 + 冲突预测 + 进入区约束），
            #   而不能只用 ④ 屏蔽掩码：后者选出的动作会被下游"预测冲突 → 回退规则"的
            #   安全覆盖改掉（实测 3 种子仍有 2 个缺动作，就是这个原因）。
            _cs_set = set(cs)
            _uv = getattr(self, '_unvisited', None)
            if _uv is None:
                _uv = set(range(N_ACTIONS))
                self._unvisited = _uv
            _pickable = sorted(a for a in _uv if a in _cs_set)
            if _pickable:
                _a = _pickable[0]
                # ⚠️ **不在这里移除**：下游"预测冲突 → 回退规则"的安全覆盖可能把这个
                #   动作改掉 ⇒ 若此刻就标记"已访问"，该动作会被消费却从未执行
                #   （实测 seed3：动作 11 进入候选集 421 帧仍零样本）。
                #   改为在**真正执行后**移除，见 ep_frames 记录处。
                _v = getattr(self, '_act_visits', None)
                if _v is None or len(_v) != N_ACTIONS:
                    _v = [0] * N_ACTIONS
                    self._act_visits = _v
                _v[_a] += 1
                self._coverage_left = max(0, len(_uv))
                return _a
        except Exception:
            pass
        visits = getattr(self, '_act_visits', None)
        if visits is None or len(visits) != N_ACTIONS:
            visits = [0] * N_ACTIONS
            self._act_visits = visits
        m = min(visits[a] for a in cs)
        least = [a for a in cs if visits[a] == m]
        # 【V1 稳定化】并列时取**最小下标**（确定性），而不是随机。
        #   原因：v≥2 的动作只有 ~7% 的帧可进，随机并列会让"零访问动作"错过窗口；
        #   确定性选择保证"一旦某动作可进且访问最少(通常是 0)，就必然被选中"
        #   ⇒ V1（12 个动作都有样本）由**概率判据**变成**构造性判据**。
        pick = min(least) if getattr(self, 'expl_deterministic', True) else random.choice(least)
        self._act_visits[pick] = visits[pick] + 1
        return pick

    def _safe_exploration_candidates(self, dynamic_map, env, rule_action):
        """
        在规则档位 ±3 范围内筛掉"预测会冲突"的档位，并始终保留刹车（`BRAKE_ACTION`）与规则动作。

        【创新点④】再与边界安全屏蔽取交集：危险时连"规则动作"也不能违反屏蔽
        （旧注释假设"规则经受过验证"，但实测规则档位自己也会在 lcttc<1s 时选中速档）。
        """
        # 【缺陷修复】探索候选集：
        #   旧式 `range(rule_action−3, rule_action+3)` 是**为一维 8 档速度空间写的**。
        #   在 12 动作 2D 空间（`a = i_sp*3 + i_lat`）里，±3 只跨 **1 个速度档**，
        #   且横向只覆盖到窗口边界碰巧包含的那几档 ⇒ 实测动作 3/6/9（di=−1.5 且 v≥2）
        #   零样本、V1 验收失败。
        #   改为 **(i_sp, i_lat) 上的 Chebyshev 球**（半径 `DSH_EXPL_RADIUS`，默认 1）：
        #   纵向 ±1 档 × 横向 ±1 档，共至多 9 个候选，两个维度都被真正探索。
        if ACTION_MODE == '2d':
            _r = int(os.environ.get('DSH_EXPL_RADIUS', '1'))
            _i_sp0 = int(rule_action) // _N_LAT
            _i_lat0 = int(rule_action) % _N_LAT
            candidates = []
            for _ds in range(-_r, _r + 1):
                for _dl in range(-_r, _r + 1):
                    _isp, _il = _i_sp0 + _ds, _i_lat0 + _dl
                    if 0 <= _isp < len(TURN_2D_SPEEDS) and 0 <= _il < _N_LAT:
                        candidates.append(_isp * _N_LAT + _il)
            candidates = sorted(set(candidates))
        else:
            low = max(0, int(rule_action) - 3)
            high = min(N_ACTIONS - 1, int(rule_action) + 3)
            candidates = list(range(low, high + 1))
        if getattr(self, 'paper_control', False):
            # Geometrically valid actions; the same deterministic feasibility
            # layer validates the selected trajectory for all driving methods.
            self._last_shield_mask = [True]*N_ACTIONS
            return candidates
        safe = [a for a in candidates if not self._action_would_conflict(dynamic_map, env, a)]
        # 【④】与边界安全屏蔽取交集
        shield = self._shield_allowed_actions(dynamic_map, env)
        # 【V1 构造性保证】把 ④ 屏蔽掩码存下来：预热轮转只能从"屏蔽允许"的动作里选，
        #   从而在**不绕过安全层**的前提下保证 12 个动作都被执行到。
        self._last_shield_mask = list(shield)
        safe = [a for a in safe if shield[a]]
        # 【S2-②】未获准进入时，探索**不得选加速档**。
        #   依据：进入决策（预测清空/最坏情况）是有提前量的判据，而 ④ 屏蔽用的是
        #   lcttc（无提前量）。让随机动作也不能突破进入判据，可避免"探索直接把车送进去"。
        #   用上一帧的 `_entry_granted`（本帧的进入决策在探索之后才算，差 1 帧≈0.05s）。
        if not bool(getattr(self, '_last_entry_granted', True)):
            try:
                _v_now = float(getattr(dynamic_map.ego_vehicle, 'v', 0.0))
                _keep = [a for a in safe if float(ACTION_SPEEDS[a]) <= _v_now + 0.5]
                # 【S6-③】死锁逃逸（DSH_EXPL_ESCAPE=1，默认 0）。
                #  实测 expOO_vref_20（纵向通道接通后）：explore 帧 **77% 走 v=0**，
                #  卡死率 0%→25%。成因是一个**自锁**：
                #    `_v_now + 0.5` 小于下一档(2.0)时，`_keep` 只剩 v=0 的动作
                #    ⇒ 未获准进入时探索**只能选刹车** ⇒ 车永远不前进 ⇒ 永远拿不到
                #      "其实能走"的样本 ⇒ 永远未获准。一旦车速掉到 1.5 m/s 以下就出不来。
                #  注意：S2-② 当初加这条约束的目的是"别让随机动作把车送进路口"，
                #  这个目的由**限速**即可达成，不需要把候选集压成单一 v=0。
                #  修法：若"不加速"只剩 v=0，则额外放行**上一档**，让车能重新起步。
                # 【V1 落地】默认打开逃逸：自车 91% 的帧是慢速 ⇒ `v_now+0.5 < 2` ⇒ 整个 v≥2 区
                #   被排除出候选集 ⇒ 12 个动作永远无法全部落地（V1 失败）。
                #   S2-② 当初加这条的目的是"别让随机动作把车送进路口"，
                #   而该目的已由 ④ 屏蔽承担（**现已扩到纵向+横向**）⇒ 此处放开不损失安全护栏。
                if os.environ.get('DSH_EXPL_ESCAPE', '1') == '1' and _keep:
                    _vmax = max(float(ACTION_SPEEDS[a]) for a in _keep)
                    if _vmax <= _v_now + 1e-9:
                        _nxt = [float(s) for s in ACTION_SPEEDS if float(s) > _v_now + 1e-9]
                        if _nxt:
                            _up = min(_nxt)
                            _keep = [a for a in safe if float(ACTION_SPEEDS[a]) <= _up + 1e-9]
                safe = _keep if _keep else list(slowest_speed_actions())
            except Exception:
                pass
        # 刹车永远安全（刹车只会让行）
        #   ⚠ 必须用 BRAKE_ACTION（最低速档 + **中性横向**），不能写死 0：
        #     2d 空间里 index 0 = (v=0, di=-1.5)，"保底刹车"会变成"刹车 + 向左切 1.5 m"。
        if BRAKE_ACTION not in safe:
            safe.append(BRAKE_ACTION)
        # 【V1 诊断】把探索候选集打成 12 位掩码，用于区分"从未进入候选集"与"可进但未被选中"
        try:
            _cs = set(int(a) for a in safe)
            self._last_cand_mask = ''.join('1' if a in _cs else '0' for a in range(N_ACTIONS))
        except Exception:
            self._last_cand_mask = None
        if not safe:
            safe = list(slowest_speed_actions()) or [BRAKE_ACTION]
        return safe

    # ============ ② 主动推理 EFE(s_t, a_t)：逐候选动作的博弈观测预测（式52/55/56/57）============
    #: 自车加/减速度限幅（与 MPCController 的 a_max / a_min 一致，保证预测用同一套运动学）
    EFE_A_ACC = 2.0
    EFE_A_DEC = 3.0
    #: RV 行为的两种假设（对应 rv_decision 的行为空间）
    #:   yield: 减速趋向让行目标速度 3.0 m/s（与 CrossTrafficManager.rv_yield_target 一致）
    #:   rush : 维持当前速度通过
    EFE_RV_YIELD_SPEED = 3.0
    EFE_RV_IDM_ACC = 2.0
    EFE_RV_DECEL = 2.5
    #: 预测时域 (s)：自车到达冲突点的预测时间超过它 → 判为 stalled（效率损失）
    EFE_HORIZON = 6.0

    def _heading_change_ego_to_conflict(self, conf):
        """【D2b】自车 → 冲突点，沿参考路径的**航向变化量** |Δψ|（rad）。

        为什么是它（**严格依据，不是拟合**）：
          横向 offset `d` 对路径弧长的一阶影响为 `Δarc = −d·∫κ(s)ds`；
          而 Frenet 基本关系 `κ = dψ/ds` ⇒ `∫κ(s)ds ≡ Δψ`（两端航向差）。
          ⇒ 只需两端航向，**无需逐点曲率**。

        为什么比"局部曲率 × 弧长"更好：
          实测参考路径前 40% 是直线（κ=0），转弯发生在中段
          ⇒ 自车在接近段时局部 κ≈0，但到冲突点仍可能有很大 Δψ
          ⇒ 局部近似会**严重低估**横向灵敏度。

        健壮性：任何异常/数据不足 ⇒ 返回 0.0（等价于退化为修复前的横向盲区），绝不抛异常。
        """
        try:
            path = _get_ref_path_array(self.dynamic_map)
            if path is None or len(path) < 2:
                return 0.0
            ego = self.dynamic_map.ego_vehicle
            _ex, _ey = float(ego.x), float(ego.y)
            _cx = float(conf.get('conflict_x', 0.0))
            _cy = float(conf.get('conflict_y', 0.0))
            _d_ego = np.hypot(path[:, 0] - _ex, path[:, 1] - _ey)
            _d_cx = np.hypot(path[:, 0] - _cx, path[:, 1] - _cy)
            i = int(np.argmin(_d_ego))
            j = int(np.argmin(_d_cx))
            if i == j:
                return 0.0
            def _yaw(k):
                k2 = min(max(k, 0), len(path) - 2)
                return math.atan2(path[k2 + 1, 1] - path[k2, 1],
                                  path[k2 + 1, 0] - path[k2, 0])
            return abs(float(_nang(_yaw(j) - _yaw(i))))
        except Exception:
            return 0.0

    def _efe_by_action(self, conf, action_num=None):
        """【式56/57】逐候选动作计算 EFE(s,a) 与 R(s,a) = −EFE(s,a)。

        对每个候选动作 a：
          1) 用运动学预测自车到达冲突点的时间 t_ego(a)（限幅 = MPC 的 a_max/a_min）；
          2) 分别在 RV 让行 / 抢行两种**行为假设**下预测 RV 到达时间，得到
             时间裕度 margin(a, ·) = |t_RV − t_ego|；
          3) 对每个对手**隐类型** τ（aggressiveness 档位）用 `rv_yield_probability` 得到
             P(yield|τ)，组合出该类型下的观测分布 q(o'|a,τ)（行为混合）；
          4) 交给纯函数 `efe_by_action`：r_cognition = D_KL[q(o'|a)‖p̃]（式57 第一项）、
             r_behavior = Σ_τ b(τ)·H(q(o'|a,τ))（式55/57 第二项），EFE = 两者加权和。

        返回 {a: R(s,a)}（R ≤ 0；R 越大越好）。无交互（无 RV / 已越过冲突点）→ 全 0。
        诊断信息写入 self._efe_last，供日志/可视化使用。
        """
        n = (N_ACTIONS - 1) if action_num is None else int(action_num)
        rewards = {a: 0.0 for a in range(n + 1)}
        self._last_efe_dpsi = None
        _rv = conf.get('rv_veh')
        if conf.get('committed') or conf.get('n_vehicles', 0) <= 0 or _rv is None:
            self._efe_last = {'active': False}
            return rewards
        try:
            arc = max(float(conf.get('arc_to_cross', 0.0)), 0.0)
            ego = self.dynamic_map.ego_vehicle
            ego_v = max(float(getattr(ego, 'v', 0.0)), 0.0)
            cx = float(conf.get('conflict_x', 0.0))
            cy = float(conf.get('conflict_y', 0.0))
            rv_x = float(getattr(_rv, 'x', cx))
            rv_v = max(float(getattr(_rv, 'v', 0.0)), 0.0)
            d_rv = abs(rv_x - cx)
            _ttc_b = conf.get('ttc_boundary')
            _rv_acc = float(conf.get('rv_acc') or 0.0)
            _rv_acc_f = conf.get('rv_acc_follow')
            ego_sd = {'x': float(ego.x), 'y': float(ego.y), 'v': max(ego_v, 0.1)}
            rv_sd = {'x': rv_x, 'y': cy, 'v': max(rv_v, 0.1), 'vx': -max(rv_v, 0.1)}

            # RV 两种行为假设下的到达冲突点时间
            t_rv_yield = time_to_cover(d_rv, rv_v, self.EFE_RV_YIELD_SPEED,
                                       self.EFE_RV_IDM_ACC, self.EFE_RV_DECEL)
            t_rv_rush = time_to_cover(d_rv, rv_v, rv_v,
                                      self.EFE_RV_IDM_ACC, self.EFE_RV_DECEL)

            margins, clearances, t_egos, yprobs = {}, {}, {}, {}
            # ===== 【2026-10-13 修复横向盲区 D2b】=====
            #   缺陷（实证）：本函数原只用 `action_speed(a)`，**从不看 `action_lateral(a)`**
            #     ⇒ 同一速度档的 3 个横向动作得到**完全相同**的 margins/clearances
            #     ⇒ EFE 对横向维度**零区分度**。
            #     实测：`efe_best_action ∈ {0,3,6,9}` 恒成立（全 ≡0 mod 3）
            #     ⇒ EFE 的"建议"退化为「横向恒 −1.5 m + 选速度」，无法为横向决策提供信息。
            #
            #   修法（**严格一阶几何，不是拟合**）：
            #     横向 offset `d` 使路径的实际弧长变化为
            #         Δarc = ∫ (κ(s) 引起的一阶修正) ds = −d · ∫κ(s)ds = **−d · Δψ**
            #     其中 `Δψ` 是"自车 → 冲突点"沿参考路径的**航向变化量**
            #     （Frenet 基本关系 `κ = dψ/ds` ⇒ `∫κ ds = Δψ`）。
            #     符号：`action_lateral` 是 Frenet 横向 offset，**正 = 左**
            #       （依据 `LaneTrajectoryPlanner.calc_global_paths`：
            #        `fx = ix + di·cos(iyaw + π/2)` ⇒ +d 为航向左转 90° 方向）。
            #       左转的曲率中心在左侧 ⇒ +d 使半径变小 ⇒ **弧长变短** ⇒ `arc − d·Δψ`。
            #
            #   ⚠️ 用 Δψ（两端航向差）而不是"局部 κ × arc"：
            #     自车在直线接近段时局部 κ≈0（实测前 40% 路径 κ=0），
            #     但到冲突点仍有很大 Δψ（转弯发生在其间）⇒ 局部近似会**严重低估**。
            #     实测参考路径：转弯段 κ 峰值 0.097（R≈10.3m），冲突点附近 κ=0.0783（R≈12.8m）
            #     ⇒ d=±1.5m 时弧长一阶变化量级 **~12%**（可测、非可忽略）。
            #
            #   消融：`DSH_EFE_LATERAL=0` ⇒ 复现修复前的横向盲区行为。
            #   ⚠️ 未建模的部分（**必须声明**）：横向 offset 还会把"与横向车流线的交点"
            #     沿该线平移（一阶 ≈ d/sin θ，θ 为路径与车流线夹角）⇒ 会改变与各 RV 的
            #     距离。该效应**未纳入**：它改动的是**系统级的安全几何**
            #     （`crossing_conflict_detail` / `_gap_ok` / `commit_risk` 全部基于参考路径），
            #     只改 EFE 会让 EFE 与安全判据**口径不一致** ⇒ 属于更大的设计决策，需单独评估。
            _dpsi = self._heading_change_ego_to_conflict(conf) if self.efe_lateral else 0.0
            self._last_efe_dpsi = float(_dpsi)
            for a in range(n + 1):
                if ACTION_MODE == 'lateral':
                    from Agent.tools_dds.LaneTrajectoryPlanner import LATERAL_TARGET_SPEED
                    v_cand = max(float(LATERAL_TARGET_SPEED), 0.0)
                else:
                    v_cand = max(float(action_speed(a)), 0.0)
                # 【D2b】横向 offset ⇒ 一阶弧长修正（∫κ ds = Δψ）
                #   纯函数 `lateral_arc_correction`（可单测符号/量级/边界）
                _arc_a = arc
                if self.efe_lateral:
                    _arc_a = lateral_arc_correction(
                        arc, action_lateral(a), _dpsi)
                t_ego = time_to_cover(_arc_a, ego_v, v_cand, self.EFE_A_ACC, self.EFE_A_DEC)
                # 任一时刻到不了（inf）→ 无法构成到达时间差；stalled 由 t_ego 判定
                m_y = float('inf') if (math.isinf(t_ego) or math.isinf(t_rv_yield)) \
                    else abs(t_rv_yield - t_ego)
                m_r = float('inf') if (math.isinf(t_ego) or math.isinf(t_rv_rush)) \
                    else abs(t_rv_rush - t_ego)
                margins[a] = {'yield': m_y, 'rush': m_r}
                clearances[a] = 4.0 / max(v_cand, 0.5)     # 清空时间（4m 车身 / 车速）
                t_egos[a] = t_ego
                yprobs[a] = {
                    tau: rv_yield_probability(ego_sd, rv_sd, cx, _ttc_b, theta=th,
                                              acc_current=_rv_acc, acc_follow=_rv_acc_f,
                                              t_ego=(t_ego if self.efe_action_coupling
                                                     else conf.get('t_ego')))
                    for tau, th in self.type_inf.types.items()}
                if getattr(self, 'belief_tracker', None) is not None:
                    # EFE and Bellman use the same joint belief. The type-
                    # conditional intent probabilities retain its correlations.
                    yprobs[a] = self.belief_tracker.predicted_yield(self._belief_actor, yprobs[a])

            res = efe_by_action(margins, yprobs, dict(self.type_inf.posterior),
                                info_cardinality=self._info_cardinality(),
                                w_info=(0. if getattr(self, 'belief_learner', None) is not None else self.info_w),
                                # 【式(18)】对手**动作频率**熵（历史路径的真实消费者）
                                action_entropy=self._rv_action_entropy(),
                                w_action_entropy=(0. if getattr(self, 'belief_learner', None) is not None
                                                  else self.w_action_entropy),
                                clearance_by_action=clearances,
                                t_ego_by_action=t_egos, horizon=self.EFE_HORIZON,
                                sigma=self.efe_sigma,
                                w_cognition=self.efe_w_cognition,
                                w_behavior=self.efe_w_behavior)
            for a, d in res.items():
                rewards[a] = float(d['reward'])
            _amax = max(rewards, key=lambda k: rewards[k]) if rewards else None
            self._efe_last = {
                'active': True, 'arc': arc, 't_ego': t_egos, 'margin': margins,
                'clearance': clearances, 'yield_prob': yprobs,
                'efe': {a: res[a]['efe'] for a in res},
                'r_cognition': {a: res[a]['r_cognition'] for a in res},
                'r_behavior': {a: res[a]['r_behavior'] for a in res},
                'reward': rewards, 'argmin_efe_action': _amax,
                'belief': dict(self.type_inf.posterior)}
        except Exception as _e:            # 预测失败不得影响主决策
            self._efe_last = {'active': False, 'error': repr(_e)}
        return rewards

    # ============ 论文式62/63 的 g_d（FV–RV 间隙）与 ġ ============
    #: 博弈不在进行中（FV/RV 缺一）时用的 g_d：取式62 的上界 GAP_MAX，使 r_gap-dist = 0
    GAP_IDLE = 7.0
    #: g_d 单帧跳变上限（m）：FV/RV 配对切换时 g_d 会跳变，避免造出假的 ġ 尖峰
    GAP_JUMP_MAX = 20.0

    def _paper_gap_and_rate(self, conf):
        """返回 (g_d, ġ)，严格按论文式62/63 的口径。

        DSH_GAP_MODE=spatial（默认，论文口径）：
            g_d = conf['gap_spatial'] = FV–RV 空间净间隙（米，由 gap_analysis.fv_rv_spatial_gap 给出）
                  FV/RV 缺一（博弈未进行）→ GAP_IDLE，且 ġ 归零
            ġ   = Δg_d / 0.05s；配对切换（|Δg_d| > GAP_JUMP_MAX）→ 本帧 ġ 归零
        DSH_GAP_MODE=time（旧口径，仅用于复现旧实验）：
            g_d = thw_boundary_rv（时间代理，单位 s，与式62 的米制断点不匹配）
        """
        mode = os.environ.get('DSH_GAP_MODE', 'spatial')
        _dt = 0.05
        if mode == 'time':
            gd = conf.get('thw_boundary_rv', conf.get('gap', 0.0))
            try:
                gd = float(gd)
            except (TypeError, ValueError):
                gd = 0.0
            if not math.isfinite(gd):
                gd = 0.0
            previous_gap = getattr(self, '_last_gap_for_rate', None)
            rate = 0.0 if previous_gap is None else (gd - previous_gap) / _dt
            self._last_gap_for_rate = gd
            return gd, rate

        # ---- 论文口径：米制空间间隙 ----
        # 【P2-b】先用**显式**的"博弈进行中"判定（不含自车速度项，不可被减速套利），
        #   再退回 `gap_spatial is None`。两者一致时不影响结果，但显式 gate 让
        #   "博弈结束 => r_game 不再计分"这件事在代码里可见，而不是靠 g_d 恰好为 None。
        raw = conf.get('gap_spatial', None)
        if not bool(conf.get('game_active', raw is not None)):
            self._last_gap_for_rate = None      # 博弈未进行：清掉记忆，避免下次误算 ġ
            return float(self.GAP_IDLE), 0.0
        if raw is None:
            self._last_gap_for_rate = None      # 博弈未进行：清掉记忆，避免下次误算 ġ
            return float(self.GAP_IDLE), 0.0
        try:
            gd = float(raw)
        except (TypeError, ValueError):
            return float(self.GAP_IDLE), 0.0
        if not math.isfinite(gd):
            return float(self.GAP_IDLE), 0.0
        # ===== 【P1-g 奖励劫持修复（第二处）】ġ 必须只在"**同一个测量对象**"上算 =====
        #  实测定位（expAN_seed1，ep9 f309→312）：
        #    f309: rv_id=4509, rv_x=3.675, reward  +56.3
        #    f310: rv_id=**4511**（换车）, rv_x=16.199（跳 +12.5 m）, reward **+10102.3**
        #    f312: rv_id=**4509**（又换回）, rv_x=3.475（跳 −12.6 m）, reward **−14931.5**
        #  反推完全吻合：+10102/40×0.05 = 12.63 m；−14931/60×0.05 = −12.44 m。
        #  ⇒ **奖励尖峰来自"对手换车"，不是间隙真的变了。**
        #  旧防跳变用 `abs(Δg) > GAP_JUMP_MAX(20 m)`：既拦不住 12.6 m 的跳变，
        #  原理上也错 —— 12.6 m 的**真实**间隙变化与"换了对手"在 Δg 上无法区分。
        #  ⇒ 正确做法：**按 (rv_id, fv_id) 判"测量对象身份是否变化"**；
        #     再给同配对内的 Δg 加**物理上界** `v_rel_max·dt`（一步内间隙不可能变更多）。
        #  自车停在 arc=12.262 时车流不断驶过 ⇒ 配对不断切换 ⇒ 旧实现下"站着不动"就能刷 ±10⁴。
        _rv_id = getattr(conf.get('rv_veh'), 'veh_id', None)
        _fv_id = getattr(conf.get('fv_veh'), 'veh_id', None)
        _pair = (_rv_id, _fv_id)
        _last_pair = getattr(self, '_last_gap_pair', None)
        last = getattr(self, '_last_gap_for_rate', None)
        _dg = None if last is None else (gd - last)
        if last is None:
            rate = 0.0                                  # 首次：无历史
            self._gap_switch_num = getattr(self, '_gap_switch_num', 0)
        elif _pair != _last_pair:
            rate = 0.0                                  # **配对切换**：测量对象变了
            self._gap_switch_num = getattr(self, '_gap_switch_num', 0) + 1
        elif _dg is not None and abs(_dg) > float(self.GAP_DG_MAX):
            rate = 0.0                                  # 同配对但 Δg 超物理上界 ⇒ 测量毛刺
            self._gap_glitch_num = getattr(self, '_gap_glitch_num', 0) + 1
        else:
            rate = _dg / _dt
        self._last_gap_for_rate = gd
        self._last_gap_pair = _pair
        return gd, rate

    # ============ 论文式66 输入 ψ（横摆角）的取值口径 ============
    def _yaw_for_reward(self, ego):
        """返回式66 的 ψ（横摆角，rad）。两种口径（DSH_YAW_MODE 切换）：

          'turn'（默认，左转专用）：|自车航向 − 参考转弯路径切线航向|
                 —— 左转必经 ~90° 转角，若用绝对横摆角会把"转弯本身"也罚掉；
                    改用"航向跟踪误差"后，r_yaw 只惩罚偏离期望转弯轨迹的横摆。
          'abs' （论文字面）      ：|自车绝对横摆角|
                 —— 适合直道换道（理想 ψ=0）；本场景会随转弯进度持续扣分，仅供对照。
        """
        if getattr(self, 'yaw_mode', 'turn') == 'abs':
            return abs(float(ego.yaw))
        try:
            path = _get_ref_path_array(self.dynamic_map)
            if path is not None and len(path) >= 2:
                ex, ey = float(ego.x), float(ego.y)
                d = np.hypot(path[:, 0] - ex, path[:, 1] - ey)
                i = int(np.argmin(d))
                j = min(i + 1, len(path) - 1)
                if j > i:
                    ref_heading = math.atan2(path[j, 1] - path[i, 1], path[j, 0] - path[i, 0])
                    return abs(float(_nang(ego.yaw - ref_heading)))
        except Exception:
            pass
        return 0.0

    # ============ P0: RL 动作因果奖励 ============
    def compute_causal_reward(self, dynamic_map, env, hybrid_action, used_trajectory,
                              last_rl_action=None, terminal_reward=0.0,
                              turn_completed=False, efe_ambiguity=None):
        """
        计算 RL 动作的因果奖励（标量）—— 只反映"当前动作"带来的后果，与规则/MFC 解耦。

        关键修正（对应 100 回合数据分析）:
          旧版对"冲突点时间差<1.5s"一律 -50，导致成功过弯也拿 -680，奖励完全失准。
          新版改为【清空窗口判定】:
            - ego 已越过冲突点(committed) → 安全项 = 0（过了就不再罚）
            - 无交叉车辆            → +2
            - dt = t_veh - t_ego ≥ 清空时间+0.5s → 安全穿越，+5
            - dt ∈ [清空时间, 清空时间+0.5) → 临界，0
            - dt < 清空时间         → 会撞，按缺口线性 -5 ~ -60
          这样: 安全过弯整回合为正，真实会撞整回合为大负，RL 才有区分度。

        分量:
          1. 冲突安全（清空窗口判定）
          2. 过弯效率: 0.3 * min(v, 8)
          3. 路口犹豫惩罚: 距冲突点<15m 且 v<1 → -2/帧
          4. 舒适度:   -0.1 * max(|acc| - 2, 0)
          5. 平滑性:   -0.3 * |action - last_action|
          6. 转弯进度: +2.0 * Δ(航向角变化)
          7. 终局:     碰撞 -300 / 完成 +150 / 卡死 -100（由调用方传入）
        """
        r = 0.0
        # 【2026-10-12 奖励核账】把每一项单独记下来，供离线归因。
        #   为什么必须做：实测 A6 逐帧 reward 均值 **−31.33**、正帧仅 10%，
        #   但逐个核账只找到 ≈ −2.3/帧（safe+prox+pet −1.48，thw −0.30，wait −0.5）
        #   ⇒ **剩下 ≈ −29/帧来源不明**。在重标定之前必须先知道"谁在支配"，
        #   否则就是盲改（本项目已因"盲改+无法观测"浪费过多轮）。
        #   `_rew` 记录每一项；函数末尾用 `_rew_residual = r − sum(已记项)`
        #   把**没被记到的部分**显形（若残差大 ⇒ 说明还有未识别的项）。
        _rew = {}
        _rew_residual = 0.0
        self._complete_fired = False
        self._last_efe_amb_used = None
        ego = dynamic_map.ego_vehicle
        v = max(float(getattr(ego, 'v', 0.0)), 0.0)
        conf = crossing_conflict_detail(dynamic_map, env, beta=self.type_inf.theta())
        self._last_conf = conf          # 供可视化窗口显示 arc/committed/LCTTC 等

        if self.use_paper_reward:
            # ===== ④ 论文奖励（严格按式62-68）：r_total = r_game + r_thw + r_yaw + r_lat =====
            #   式64 r_game = r_gap-rate + 0.5·r_gap-dist（博弈进行中）；完成时 140（此处由 terminal 处理）
            #   场景映射（与论文量纲的差异已在各处标注）：
            #     g_d     ← **FV–RV 空间净间隙（米）**，论文式62 的 g_d（断点 2.5/3.5/5.0/7.0 m）
            #               DSH_GAP_MODE=spatial(默认) | time(旧口径：thw_boundary_rv 时间代理)
            #     ġ       ← d(g_d)/dt，dt=0.05s（论文式63 的 "rate of change at 0.05s interval"）
            #     ψ       ← 横摆角（口径见 _yaw_for_reward：turn=航向跟踪误差 / abs=绝对横摆角）
            #     Δy      ← 自车到参考路径的横向偏差 _get_lateral_error
            #   逐项消融：DSH_PAPER_TERMS 的任意子集（game/thw/yaw/lat），未启用的项置 0
            _terms = getattr(self, 'paper_terms', {'game', 'thw', 'yaw', 'lat'})
            try:
                _dt = 0.05
                _gd, _grate = self._paper_gap_and_rate(conf)
                # 【式(64)】`I_complete` 的 `140` 分支此前是**死代码**。
                #  ⚠️ 第一次修复我用的是 `conf['committed']` 的上升沿 —— 实测 **0/8580 帧**
                #     为 committed=1（自车几乎从不越过冲突点）⇒ 140 **仍然事实上从不触发**，
                #     属"接线了但没落地"。
                #  真正的完成信号是场景层的 **`env._turn_complete()`**
                #  （航向变化 > 1.4 rad 且到目标点 < 4 m），由 `evaluate()` 在终局帧判定并传入。
                #  `DSH_RGAME_COMPLETE=0` 可回退到旧的 ad-hoc +150。
                #  ⚠️ 变量名必须是本方法的 `conf`（不是 evaluate() 里的 `_conf`）：
                #     我第一版写成 `_conf` ⇒ NameError ⇒ 整个 try 失败 ⇒ 式(62-68)
                #     整段静默失效（1117/1117 帧）。
                _complete_now = bool(turn_completed) and bool(getattr(self, 'rgame_complete', True))
                self._complete_fired = bool(_complete_now)
                # 【P3/P1-g】式(63) r_gap-rate = 40·ġ 有两个问题：
                #   (1) 它是"瞬时速率奖励"，叠加在每帧上 ⇒ 与势函数不同，会**改变最优策略**；
                #   (2) ġ = Δg_d/0.05 在**配对对象切换**时爆炸（P1-g：rv_id 4509→4511，
                #       Δg_d=12.6m ⇒ +10102/帧）。
                #   ⇒ 默认改为 **PBRS**：r̃ = γΦ(s') − Φ(s)，Φ = c·g_d（Ng et al. 1999）。
                #     势函数差分的折扣和 **望远镜求和** 为 γ^T Φ(s_T) − Φ(s_0)，
                #     与策略无关 ⇒ **不改变最优策略**，而配对切换时 Φ 的跳变也被
                #     `GAP_DG_MAX` 钳制（见 `_paper_gap_and_rate`）。
                #   式(62) r_gap-dist **原样保留**（论文原式，且已是状态函数）。
                if 'game' in _terms:
                    if _complete_now:
                        r_game = game_reward(_grate, _gd, complete=True)                  # 式64 完成分支
                    elif self.gap_rate_pbrs:
                        _phi = self.gap_phi_scale * max(-5.0, min(10.0, float(_gd)))
                        _phi_prev = getattr(self, '_gap_phi_prev', None)
                        _shaping = 0.0 if _phi_prev is None else pbrs(
                            _phi, _phi_prev, float(os.environ.get('DSH_GAMMA', '0.98')))
                        self._gap_phi_prev = _phi
                        r_game = 0.5 * gap_dist_reward(_gd) + _shaping                      # 式62 + PBRS(式63')
                        self._pbrs_shaping = float(_shaping)
                    else:
                        r_game = game_reward(_grate, _gd, complete=False)                 # 旧口径（消融对照）
                else:
                    r_game = 0.0
                # 式65；【P1-f】无 RV(THW 非有限) ⇒ 中性 0（旧口径 DSH_MISSING_THW=cap = +20）
                # 【§62】式(65)：默认改成 **≤0 形式**（论文原式对 THW 单调递增并饱和在 2s
                #   ⇒ 停在停止线每帧白拿 +20，实测等待帧 99.4% 拿满额 ⇒ 等 15 倍赚）。
                _thw_in = conf.get('thw_boundary_rv')
                if self.thw_obj:
                    try:
                        _ex_t = float(ego.x); _ey_t = float(ego.y)
                        _w_thw = worst_boundary_thw(
                            _ex_t, _ey_t, float(getattr(ego, 'yaw', 0.0) or 0.0), v,
                            _veh_list(getattr(self.dynamic_map, 'objects', None)))
                        if math.isfinite(_w_thw):
                            _thw_in = _w_thw
                    except Exception as _te:
                        self._clr_err = '%s: %s' % (type(_te).__name__, _te)
                if 'thw' not in _terms:
                    r_thw = 0.0
                elif self.thw_mode == 'paper':
                    r_thw = thw_reward(_thw_in, missing_thw_neutral=self.missing_thw_neutral)
                else:
                    r_thw = thw_safe_penalty(_thw_in, self.thw_pen_th, self.thw_pen_w)
                self._last_thw_in = _thw_in
                # 【2026-10-12 曲率加权（式66）】传入**参考路径在自车处**的曲率，
                #   让转弯段的"必要转向"少受罚。
                #   依据 arXiv:2412.16248 §3.3：大转向惩罚会 "discourage necessary
                #   adjustments" / 导致 "overly cautious behavior"，尤其在急弯；
                #   其解法 w_curve = κ/(κ+γ) + 乘 (1−w_curve)。
                #   `DSH_YAW_CURVE_GAMMA=0` ⇒ 复现论文原式（消融对照）。
                if 'yaw' in _terms:
                    _psi = self._yaw_for_reward(ego)
                    _curv = 0.0
                    try:
                        _curv = abs(float(self._calc_curvature_at(dynamic_map=self.dynamic_map)))
                    except Exception:
                        _curv = 0.0
                    _wc = yaw_curve_weight(_curv)
                    r_yaw = yaw_reward(_psi, w_curve=_wc)
                    self._last_yaw_curve = (_curv, _wc)
                else:
                    r_yaw = 0.0
                if 'lat' in _terms:
                    try:
                        _lat_err = float(_get_lateral_error(self.dynamic_map))
                    except Exception:
                        _lat_err = 0.0
                    r_lat = lat_reward(_lat_err, 0.0)                                            # 式67
                else:
                    r_lat = 0.0
                r = total_reward(r_game, r_thw, r_yaw, r_lat)                                    # 式68
                _rew['game'], _rew['thw'] = float(r_game), float(r_thw)
                _rew['yaw'], _rew['lat'] = float(r_yaw), float(r_lat)
                # ===== 【§48 客观奖励项】只依赖世界状态，且对**所有车**取最坏值 =====
                #  动机：式(62)/(63)/(65) 的对手都来自"分类出的 rv/FV"，而分类依据
                #  `t_ego = arc/v` **含自车可控的 v** ⇒ 减速可把对手"移出分类"从而
                #  在**不改善世界**的前提下改善奖励（P1-f/P1-g 实测劫持）。
                #  这里三项全部 `min over all vehicles`，且 `d_AB` 恒有限 ⇒ 不可套利。
                #    r_safe : 最坏 LCTTC 余量（"多久会撞"，恒 ≤ 0）
                #    r_prox : 最坏边界距离（"有多近"，恒 ≤ 0，弥补 LCTTC 大多数帧为 inf）
                #    r_pet  : 汇入区 PET 冲突（交叉口专用指标，见 CN110488802B）
                if self.obj_reward:
                    try:
                        _ex, _ey = float(ego.x), float(ego.y)
                        _eyaw = float(getattr(ego, 'yaw', 0.0) or 0.0)
                        _vs = _veh_list(getattr(self.dynamic_map, 'objects', None))
                        _lcttc, _lcttc_v = worst_lcttc(_ex, _ey, _eyaw, v, _vs,
                                                       horizon=float(os.environ.get('DSH_LCTTC_H', '1.0')))
                        _dmin = worst_proximity(_ex, _ey, _eyaw, v, _vs)
                        _h_in = _lcttc if math.isfinite(_lcttc) else self.h_th_obj
                        _r_safe_obj = r_safe(_h_in, self.h_th_obj, self.w_obj_safe)
                        _r_prox_obj = 0.0 if not math.isfinite(_dmin) else \
                            penalty_from_margin(_dmin, self.d_th_obj, self.w_obj_prox)
                        # PET：自车进入/清空"目标车流横向带"的时间区间 vs 每辆交叉车
                        _arc = float(conf.get('arc_to_cross', 0.0) or 0.0)
                        _ve = max(v, 0.5)
                        _ic_x = float(getattr(self.env, 'INTERSECTION_CENTER',
                                              (6.00, -138.00))[0])
                        _ego_iv = occupancy_interval(t_enter=_arc / _ve, v=_ve,
                                                     length=4.5, band_width=self.clear_band_obj)
                        _ivs = []
                        for _w in _vs:
                            _vw = max(_w['v'], 0.5)
                            _ivs.append(occupancy_interval(
                                t_enter=abs(_w['x'] - _ic_x) / _vw,
                                v=_vw, length=_w['length'], band_width=self.clear_band_obj))
                        _pet = pet_to_stream(_ego_iv, _ivs)
                        _r_pet_obj = 0.0 if not math.isfinite(_pet) else r_pet(_pet, self.pet_th_obj, self.w_obj_pet)
                        r += (_r_safe_obj + _r_prox_obj + _r_pet_obj)
                        _rew['safe'], _rew['prox'] = float(_r_safe_obj), float(_r_prox_obj)
                        _rew['pet'] = float(_r_pet_obj)
                        self._obj_terms = (_r_safe_obj, _r_prox_obj, _r_pet_obj,
                                           _lcttc, _dmin, _pet)
                        self._obj_err = None      # 本帧算成 ⇒ 清掉上一帧的异常
                    except Exception as _oe:
                        # 【不静默】记录异常 + 归零项，绝不"悄悄跳过"
                        self._obj_err = '%s: %s' % (type(_oe).__name__, _oe)
                        self._obj_err_num = getattr(self, '_obj_err_num', 0) + 1
                        self._obj_terms = None
                        _r_safe_obj = _r_prox_obj = _r_pet_obj = 0.0
                        _lcttc = _dmin = _pet = float('inf')
                else:
                    _r_safe_obj = _r_prox_obj = _r_pet_obj = 0.0
                    _lcttc = _dmin = _pet = float('inf')
                # 【式(11)(12)(17)】信息集/历史路径真实填充（每帧）
                self._update_information_set(
                    int(getattr(self.ilog, 'episode', 0) or 0),
                    int(getattr(self.ilog, 'frame', 0) or 0), conf,
                    self.dynamic_map.ego_vehicle, hybrid_action, r)
                self._causal_err = None
            except Exception as _ce:
                # 【不再静默】外层 try 覆盖式62-68 的整段计算；若它抛了，
                # `_update_information_set` 根本不会被执行（这正是式25 四列全空的可能原因）。
                self._causal_err = '%s: %s' % (type(_ce).__name__, _ce)
            # 工程附加项（非论文式）：动作平滑性，抑制相邻帧动作抖动
            if last_rl_action is not None and hybrid_action is not None:
                r += -0.3 * abs(float(hybrid_action) - float(last_rl_action))
                _rew['smooth'] = -0.3 * abs(float(hybrid_action) - float(last_rl_action))
            # 【P1-e/f 一致化】停滞的效率代价在**两条奖励路径**上都要生效。
            #   旧代码只在 ad-hoc 分支加 -wait_cost，于是 DSH_PAPER_REWARD=1 时
            #   "停在停止线"零成本（再叠加旧口径 +20/帧的 THW 安全分就变成稳赚），
            #   与"等待只作兜底、鼓励安全高效插入"的口径矛盾。
            if v < 0.5 and conf['arc_to_cross'] > 1.0 and not conf['committed']:
                r += -self.wait_cost
                _rew['wait_paper'] = -float(self.wait_cost)
        else:
            # ===== 旧 ad-hoc 因果奖励（向后兼容：DSH_PAPER_REWARD=0 时启用）=====
            yield_wait = (v < 0.5 and conf['arc_to_cross'] > 1.0 and not conf['committed'])
            r += boundary_safety_reward(
                lcttc_rv=conf.get('lcttc_rv', float('inf')),
                lcttc_fv=conf.get('lcttc_fv', float('inf')),
                thw_boundary_rv=conf.get('thw_boundary_rv', float('inf')),
                committed=conf['committed'], n_vehicles=conf['n_vehicles'],
                yield_wait=yield_wait,
                # 【P1 修复·奖励劫持】等待补偿默认 5.0 → 0.0。
                #   证据（expE_p0_100, 100 回合）：爬行（v≈0.001 m/s）的回合 G 范围出现
                #   +944 / +1293 / +1018（正常回合是 -2000~-300），R-tree 里低速动作的
                #   WCV 变成**正**（+385~+485）→ 接管规则正确地选了"刹车" → ego 车停在
                #   路口里被撞。根因就是"停止线外等待 +5/帧"是**无风险的稳赚**：
                #   200 帧 = +1000，而正常行驶要承担 -39/帧 的冲突惩罚。
                #   等待本身不是错，但不能比"过弯"更赚 → 默认改为中性 0（可用
                #   DSH_WAIT_BONUS 恢复旧值做对照）。
                yield_wait_bonus=self.wait_bonus,
                # 【P1-f】无 RV(THW 非有限) ⇒ 中性 0（旧口径 +20/帧 = 奖励劫持源）
                no_vehicle_bonus=self.empty_bonus,
                missing_thw_neutral=self.missing_thw_neutral)
            if self.legacy_pos:
                r += 0.5 * min(v, 8.0)
                _rew['eff'] = 0.5 * min(v, 8.0)
            if conf['arc_to_cross'] < 1.0 and not conf['committed'] and v < 1.0:
                r += -2.0
                _rew['hesitate'] = -2.0
            # 【P1-e / 用户口径】等待不是被鼓励的策略，只是"博弈判定无法插入"时的兜底。
            #   要鼓励的是"保证绝对安全的前提下尽量高效地插入" → 给停滞加**效率代价**：
            #     等 20s(400帧) ≈ −200 ⇒ "等到车流走完再走"= −200+150 = −50；
            #     而"尝试插入"= 150p − 300(1−p)。
            #     −50 < 150p − 300(1−p) ⇔ p > 0.56
            #   ⇒ 只要 ego 判断插入成功率过半，插入就是更优选择；等待只在确实插不进去时
            #     才成为兜底（这正是导师的意思）。DSH_WAIT_COST=0 可关掉做对照。
            if yield_wait:
                r += -self.wait_cost
                _rew['wait_adhoc'] = -float(self.wait_cost)
            try:
                acc = env.ego_vehicle.get_acceleration()
                acc_mag = math.sqrt(acc.x ** 2 + acc.y ** 2 + acc.z ** 2)
                r += -0.1 * max(0.0, acc_mag - 2.0)
                _rew['comfort'] = -0.1 * max(0.0, acc_mag - 2.0)
            except Exception:
                pass
            if last_rl_action is not None and hybrid_action is not None:
                r += -0.3 * abs(float(hybrid_action) - float(last_rl_action))
                _rew['smooth'] = -0.3 * abs(float(hybrid_action) - float(last_rl_action))
            if self.initial_yaw is not None:
                yaw_change = abs(_nang(ego.yaw - self.initial_yaw))
                last_yc = getattr(self, '_last_yaw_change', None)
                if last_yc is not None:
                    r += 2.0 * max(0.0, yaw_change - last_yc)
                self._last_yaw_change = yaw_change
            else:
                self._last_yaw_change = 0.0

        # ===== 【2026-10-12 正奖励项】效率 + 平稳：让"好好开"有正回报 =====
        #   放在**两条奖励路径之外**（缩进与 if/else 同级）⇒ 论文与 ad-hoc 路径都生效。
        #   为什么需要：见 `self.w_eff_pos` 处的注释（正项几乎不兑现、正帧仅 11.6%）。
        #   两项都**有界且不可套利**：
        #     · 效率用 v 本身（不是"与对手的间隙"），减速只会少拿分，不会制造白拿分；
        #     · 平稳用实测加速度幅值，且**未取到传感器读数时给中性值**，不会误奖励。
        if self.w_eff_pos > 0.0:
            # 【双边速度奖励】r = w·exp(−α·|v − v_target|) ∈ (0, w]
            #   偏离目标速度（**无论快慢**）都衰减 ⇒ 不会"越快越好"。
            #   依据见 `self.v_target` 处注释；`DSH_V_TARGET` 是场景参数。
            try:
                _r_eff = self.w_eff_pos * math.exp(
                    -max(float(self.vel_alpha), 0.0) * abs(float(v) - float(self.v_target)))
            except Exception:
                _r_eff = 0.0
            r += _r_eff
            _rew['eff'] = float(_r_eff)
        if self.w_comfort_pos > 0.0:
            try:
                _acc = env.ego_vehicle.get_acceleration()
                _am = math.sqrt(_acc.x ** 2 + _acc.y ** 2 + _acc.z ** 2)
                if math.isfinite(_am):
                    # a=0 → +1.0；a≥2 → 0（与既有 "−0.1·max(|a|−2,0)" 惩罚互补）
                    _r_cf = self.w_comfort_pos * max(0.0, 2.0 - _am)
                    r += _r_cf
                    _rew['comfort_pos'] = float(_r_cf)
                    self._last_acc_mag = float(_am)
            except Exception:
                pass

        # ===== ② 主动推理 EFE（式56/57）=====
        # 【已修正】EFE 不再作为"状态级奖励标量"加在 r_total 之上，原因有二：
        #   1) 论文式56/57 的自变量是 (s_t, a_t)：EFE 必须在**候选动作**之间可比。
        #      旧实现的三个输入（safe_margin / 意图熵 / 回报方差）在同一状态内对所有
        #      动作取值相同 → 对 argmax_a Q(s,a) 没有任何作用，只是平移状态价值。
        #   2) 旧实现把 r_cognition 用 (偏离)² 重复计入了式62-68 已表达的"偏离博弈目标"。
        # 现在 EFE 的唯一入口是 `_efe_by_action()` → `act_hybrid(efe_values=...)`，
        # 即逐动作的 R(s,a) = -EFE(s,a)（式56）参与动作价值比较。
        # 论文同时指出（§V-C）：ambiguity 在实现上"直接体现为蒙特卡洛回报的离散波动 σ²"，
        # 故 r_behavior 还通过式60 的方差修正进入 WCV 下界（见 trustset_dds / active_inference）。
        #
        # 【legacy 开关】DSH_EFE_MODE=legacy 时保留旧的状态级标量加成，仅用于复现旧实验：
        if self.use_efe_reward and getattr(self, 'efe_mode', 'per_action') == 'legacy':
            try:
                margin = float(min(conf.get('lcttc_rv', float('inf')),
                                   conf.get('thw_boundary_rv', float('inf'))))
                _rv = conf.get('rv_veh')
                no_interaction = conf['committed'] or conf['n_vehicles'] <= 0 or _rv is None
                if no_interaction:
                    _dev, _intent_entropy, _amb_var = 0.0, 0.0, 0.0
                else:
                    _dev = max(0.0, self.efe_safe_target - margin) if math.isfinite(margin) else 0.0
                    _intent_entropy = self.type_inf.ambiguity()
                    _hist = self._efe_reward_hist
                    _amb_var = min(1.0, float(np.std(_hist)) / 20.0) if len(_hist) >= 2 else 0.0
                r += self.efe_w_behavior * efe_reward(_dev, _intent_entropy, _amb_var)
                self._efe_reward_hist.append(float(r))
                self._efe_reward_hist = self._efe_reward_hist[-self.efe_hist_len:]
            except Exception:
                pass

        # ===== 【2026-10-12 修复 D2】式56/57：把 **−ambiguity** 折进单步回报 =====
        #   为什么必须做：见 `self.efe_r_w` 处的完整说明。一句话——
        #   式60 的方差修正要求"对手意图模糊 ⇒ 回报方差 σ² 增大"，
        #   而 ambiguity 不进回报 ⇒ σ 与模糊无关 ⇒ **② 对③ 无影响**。
        #   口径：只加 ambiguity（`r_behavior[a]`），**不加**整个 −EFE
        #     （`causal_r` 已承载 risk 面向，叠加会重复计数）。
        #   本项与旧口径 `legacy` 互斥：`legacy` 是把状态级标量 EFE 直接加到 r 上
        #     （已注明非论文的 EFE(s,a)），本项是论文原式的逐动作 ambiguity。
        #   消融：`DSH_EFE_R_W=0` ⇒ 复现修复前行为。
        if (self.efe_r_w != 0.0) and (efe_ambiguity is not None):
            # 纯函数（`active_inference.ambiguity_reward`）：term = −w·ambiguity[a]
            _r_amb, _amb_used = ambiguity_reward(efe_ambiguity, hybrid_action,
                                                 w=self.efe_r_w)
            if _amb_used is not None:
                r += _r_amb
                _rew['efe_amb'] = float(_r_amb)
                self._last_efe_amb_used = _amb_used

        r += terminal_reward
        _rew['terminal'] = float(terminal_reward)
        # 【2026-10-12 奖励核账】把"没被记到的部分"显形。
        #   若残差很大 ⇒ 说明还存在未识别的奖励项（实测均值 −31 而只找到 −2.3）。
        #   这是**一次运行就能定位支配项**的关键：不需要再猜。
        try:
            _rew_residual = float(r) - float(sum(_rew.values()))
        except Exception:
            _rew_residual = 0.0
        self._last_rew_parts = dict(_rew)
        self._last_rew_residual = float(_rew_residual)
        # 【交互诊断】逐帧记录 ego 侧动作/接管/安全量（与车流侧 RV 行按 (episode,frame) 对齐）
        try:
            # 【标定】本帧抢行最坏情况 THW（只记录，供离线按分位数选阈值）
            try:
                _thw_w = self._worst_thw_rv(conf)
            except Exception:
                _thw_w = None
            # 【P5 测量版】横向扫掠带占用（只记录，不改行为）
            try:
                _band = self._band_occ_now(conf)
            except Exception:
                _band = None
            # 【2026-10-10 新增】离线判据分析埋点（纯观测，绝不影响行为）。
            #   `t_veh_worst` = 机会约束用的"最坏情况到达时间"列表；
            #   `n_cand`      = `_approach_candidates` 实际看了几辆车（机会约束的分母）。
            #   有了这两列 + `t_veh_sorted` + `conflict_x`，就能在**不启动 CARLA** 的情况下
            #   重算任意判据口径（例如把冲突点从 -7.109 改到 4.187 之后 `gap_ok` 会怎样）。
            _log_tveh_worst = None
            _log_n_cand = None
            try:
                _log_tveh_worst = self._worst_case_t_veh_list(conf)
            except Exception:
                pass
            try:
                _log_n_cand = len(self._approach_candidates(conf)[0])
            except Exception:
                pass
            self.ilog.ego_row(conf=conf, ego=ego, action=hybrid_action,
                              rule_action=getattr(self, '_cur_rule_action', None),
                              takeover=self._last_took_over, reward=r,
                              efe_last=getattr(self, '_efe_last', None),
                              shield_danger=getattr(self, '_last_shield_danger', None),
                              shield_lcttc_min=getattr(self, '_last_shield_lcttc_min', None),
                              traj_id=getattr(self, '_traj_id', None),
                              decision_src=getattr(self, '_last_decision_src', None),
                              thw_worst=_thw_w, band=_band,
                              epsilon_now=getattr(self, '_last_epsilon', None),
                              eps_triggered=getattr(self, '_last_eps_triggered', None),
                              # 【S6-① 观测】纵向指令链路（动作要求的速度 vs 实际下发 v_ref）
                              v_ref=getattr(self, '_last_v_ref', None),
                              v_ref_before_floor=getattr(self, '_last_v_ref_pre_floor', None),
                              action_speed=getattr(self, '_last_action_speed', None),
                              rl_speed_cap=getattr(self, '_last_rl_speed_cap', None),
                              # 【式(24)】舒适项（验收 V3：必须随动作变化）
                              comfort_j=(getattr(self, '_last_comfort', None) or (None, None))[0],
                              comfort_s=(getattr(self, '_last_comfort', None) or (None, None))[1],
                              # 【④ 2D】横向屏蔽（验收 V4：必须真的屏横向）
                              lat_mask=getattr(self, '_last_lateral_mask', None),
                              lat_screened=getattr(self, '_last_lat_screened', 0),
                              cand_mask=getattr(self, '_last_cand_mask', None),
                              # 【式(11)(12)(16)(17)】信息集落地证据
                              info_card=self._info_cardinality(),
                              info_hlen=(getattr(self, '_last_info_state', None) or {}).get('history_len'),
                              info_perfect=(getattr(self, '_last_info_state', None) or {}).get('perfect'),
                              info_npart=(getattr(self, '_last_info_state', None) or {}).get('n_participants'),
                              info_err=getattr(self, '_info_err', None),
                              complete_fired=getattr(self, '_complete_fired', None),
                              rv_action_entropy=self._rv_action_entropy(),
                              wait_standoff=getattr(self, '_last_wait_standoff', None),
                              gap_switch_num=getattr(self, '_gap_switch_num', 0),
                              gap_glitch_num=getattr(self, '_gap_glitch_num', 0),
                              clamp_stopped=(None if getattr(self, '_last_clamp_stopped', None) is None
                                             else int(bool(self._last_clamp_stopped))),
                              clamp_stop_num=getattr(self, '_clamp_stop_num', 0),
                              clamp_err=getattr(self, '_clamp_err', None),
                              # 【§48】客观奖励三项 + 客观输入 + PBRS 势函数差分
                              r_safe_obj=getattr(self, '_obj_terms', None) and self._obj_terms[0],
                              r_prox_obj=getattr(self, '_obj_terms', None) and self._obj_terms[1],
                              r_pet_obj=getattr(self, '_obj_terms', None) and self._obj_terms[2],
                              h_lcttc_min=getattr(self, '_obj_terms', None) and self._obj_terms[3],
                              d_ab_min=getattr(self, '_obj_terms', None) and self._obj_terms[4],
                              pet_min=getattr(self, '_obj_terms', None) and self._obj_terms[5],
                              pbrs_shaping=getattr(self, '_pbrs_shaping', 0.0),
                              obj_err=getattr(self, '_obj_err', None),
                              wait_overshoot_num=getattr(self, '_wait_overshoot_num', 0),
                              entry_granted=getattr(self, '_last_entry_granted', None),
                              committing=getattr(self, '_last_committing', None),
                              commit_latched=getattr(self, '_last_commit_latched', None),
                              gap_ok=getattr(self, '_last_gap_ok', None),
                              force_clear_num=getattr(self, '_force_clear_num', 0),
                              force_clear_blocked_num=getattr(self, '_force_clear_blocked_num', 0),
                              t_ego_go=getattr(self, '_last_t_ego_go', None),
                              clr_go=getattr(self, '_last_clr_go', None),
                              band_entry_x=getattr(self, '_last_band_entry_x', None),
                              commit_risk=getattr(self, '_last_commit_risk', None),
                              risk_veh=getattr(self, '_last_risk_veh', None),
                              pyield_prior=getattr(self, '_last_pyield_prior', None),
                              pyield_hat=getattr(self, '_last_pyield_hat', None),
                              pyield_n=getattr(self, '_last_pyield_n', None),
                              thw_in=getattr(self, '_last_thw_in', None),
                              ego_intent=getattr(self, '_last_intent_ego', None),
                              intent_rate=getattr(self, '_last_intent_rate', None),
                              take_cournot=getattr(self, '_last_take_cournot', None),
                              risk_gate_ok=getattr(self, '_last_risk_gate_ok', None),
                              # 【2026-10-10 新增】离线判据分析埋点 —— 见
                              # `interaction_logger.EGO_COLUMNS` 末尾的说明。
                              # 为什么在这里算：`t_veh_sorted` / `t_veh_worst` /
                              # `n_cand` 是占用窗判据与机会约束的**唯一输入**，此前从未落盘
                              # ⇒ 无法离线重算 `gap_ok` / `commit_risk`，只能反复实跑试错。
                              # 全部包在 try 内：埋点**绝不能**影响主流程。
                              t_veh_sorted=(conf or {}).get('t_veh_sorted'),
                              t_veh_worst=_log_tveh_worst,
                              n_cand=_log_n_cand,
                              conflict_x=(conf or {}).get('conflict_x'),
                              # 【2026-10-12 奖励核账】各分量 + 残差探针（见 EGO_COLUMNS 说明）
                              rew_parts=getattr(self, '_last_rew_parts', None),
                              rew_resid=getattr(self, '_last_rew_residual', None),
                              # 【2026-10-12 修复 D3'】① 授权口径（区分"风险值挡"vs"稳定性挡"）
                              cournot_gate_reason=getattr(self, '_last_cournot_gate_reason', None),
                              risk_value_ok=getattr(self, '_last_risk_value_ok', None),
                              # 【2026-10-13 修复 D2b】横向耦合用到的 Δψ
                              efe_dpsi=getattr(self, '_last_efe_dpsi', None),
                              rl_active=getattr(self, '_last_rl_active', None),
                              control=getattr(self, '_last_control_diag', None),
                              completion=getattr(env, 'completion_diag', None),
                              causal_err=getattr(self, '_causal_err', None))
        except Exception:
            pass
        return r

    def get_rule_lane_act_turn(self, rule_lane_offset):
        """转弯规则动作映射"""
        if rule_lane_offset <= -1:
            return 0  # 减速
        elif rule_lane_offset >= 1:
            return 2  # 加速
        return 1  # 保持

    def dist_lane_ego(self, target_lane_index):
        dist = dist_from_point_to_polyline2d(
            self.dynamic_map.ego_vehicle.x,
            self.dynamic_map.ego_vehicle.y,
            self.dynamic_map.lanes[target_lane_index].central_path_array,
            return_end_distance=True
        )
        return dist[0]

    def print_env_vehicles_msg(self, dynamic_map):
        for i in range(len(dynamic_map.lanes)):
            lane = dynamic_map.lanes[i]
            for fv in lane.front_vehicles:
                print(f"[DCARL_Turn]: Lane {i} Front Vehicle ({fv.x:.2f},{fv.y:.2f}) speed={fv.v:.2f}")
            for rv in lane.rear_vehicles:
                print(f"[DCARL_Turn]: Lane {i} Rear Vehicle ({rv.x:.2f},{rv.y:.2f}) speed={rv.v:.2f}")

    def warm_up(self, target_v, lk_id, lk_ref_d):
        return target_v, lk_id, lk_ref_d

    # ============ 主评估循环 ============
    def evaluate(self, max_episodes=None):
        print("=" * 80)
        print("[DCARL_Turn]: START TURN EVALUATION")
        print("=" * 80)
        # ===== 打印本次运行的实验配置（便于对照实验在日志中确认跑了哪一组）=====
        print(f"[CONFIG] method={getattr(self, 'method', 'GTRL')} | "
              f"use_paper_reward={self.use_paper_reward} | "
              f"paper_terms={sorted(getattr(self, 'paper_terms', []))} | "
              f"yaw_mode={getattr(self, 'yaw_mode', 'turn')} | "
              f"use_efe_reward={self.use_efe_reward} (mode={self.efe_mode}, "
              f"w_value={self.efe_value_weight}, sigma={self.efe_sigma}, "
              f"action_coupling={self.efe_action_coupling}) | "
              f"gamma={os.environ.get('DSH_GAMMA', '0.98')} | "
              # 【2026-10-12 修复 D1】显示式44 的 (R_max−R_min) 的**设置值与生效值/来源**。
              #   修复前是硬编码 80（与实测范围差 1~2 个量级）⇒ 必须能一眼看出用了多少。
              f"reward_range={getattr(self.TS, 'reward_range_env', '?')}"
              f"(eff={self.TS.effective_reward_range():.0f},"
              f"{getattr(self.TS, '_rr_last_source', '?')}) | "
              f"creep={self.creep_speed}/wait_to={self.wait_timeout_frames} | "
              f"type_inf=on(obs_int={self.type_obs_interval}) | "
              f"action_mode={ACTION_MODE}(N={N_ACTIONS}) | "
              f"zone_a_R={getattr(getattr(self.env, 'cross_traffic', None), 'zone_a_radius', None)} | "
              f"shield={'on' if self.shield_enable else 'off'}"
              f"(exc={getattr(self, '_shield_exc_num', 0)})"
              f"(lcttc<{self.shield_lcttc},critical<{SHIELD_LCTTC_CRITICAL}"
              + (f",thw<{self.shield_thw}" if self.shield_thw > 0 else "") + ") | "
              f"game_interval(role={ROLE_MODE_DEFAULT},v_min={T_EGO_V_MIN},"
              f"window={GAME_WINDOW_M}m) | "
              f"clear(band={self.clear_band},margin={self.clear_margin}) | "
              f"hold={'on' if self.hold_enable else 'off'}(arc={self.hold_arc}) | "
              f"terminal_x{self.terminal_scale:g} | "
              f"u_safe={self.u_safe_mode} | "
              f"eps={self.eps0}x{self.eps_decay}/ep | "
              f"band_warn={self.band_warn_dist:g}(n={getattr(self,'_band_warn_num',0)}) | "
              f"ilog={'on' if getattr(self.ilog, 'enabled', False) else 'off'} | "
              f"view={'on' if getattr(self.view, 'enabled', False) else 'off'} | "
              f"save_dir={MODEL_DIR}")

        # ===== 确保保存/绘图目录存在（锚定到 Algorithms，与启动目录无关）=====
        try:
            os.makedirs(MODEL_DIR, exist_ok=True)
            os.makedirs(PLOT_DIR, exist_ok=True)
            print(f"[DCARL_Turn]: 数据目录 = {MODEL_DIR}")
            print(f"[DCARL_Turn]: 绘图目录 = {PLOT_DIR}")
        except Exception as e:
            print(f"[DCARL_Turn]: 创建保存目录失败: {e}")

        # 加载历史数据
        activate_data = self.load_activate_data()
        episode_rewards = self.load_episode_rewards()
        case_rewards = self.load_case_rewards()
        behavior_data = self.load_behavior_data()

        # MPC 初始化（N=10 恢复原版验证过的时域；N=20 在部分机器上求解器每帧失败导致卡死）
        # 【P0 修复】enable_lead_follow_cost=False：转弯场景关闭 x 方向前后车交互代价
        # （垂直直行车流的 x 约束无意义，只会给错指令 + MaxIter；安全由 agent 层兜底）
        # 【④ 边界约束接通】enable_boundary_thw=True（默认）：x 代价关闭但侧向边界
        # THW_boundary 代价仍对交叉车 RV 生效——边界模型真正影响 MPC 控制。
        obs, obs_ori = self.env.reset(False)
        _prediction_geometry = prediction_geometry(self.env.control_geometry,
            getattr(self.env, 'ref_path_array', None),
            'legacy' if self.forecast_revision in ('route_v17','route_v18') else self.forecast_revision) if self.revised_control else {}
        if self.forecast_revision in ('route_v17','route_v18'):
            from Planning_library.forecast_v17 import prediction_geometry as prediction_geometry_v17
            if self.forecast_revision == 'route_v18':
                from Planning_library.forecast_v18 import prediction_geometry as prediction_geometry_v17
            _prediction_geometry = prediction_geometry_v17(self.env.control_geometry,
                self.env.forecast_ref_path_array, self.env.ref_path_array)
            _prediction_geometry['opponent_cruise'] = float(os.environ.get('DSH_RV_CRUISE_SPEED', '4.412022451715821'))
        _forecast_recorder = (ForecastRecorder(MODEL_DIR, _prediction_geometry)
                              if self.forecast_revision in ('route_v16', 'route_v17', 'route_v18') else None)
        if self.revised_control:
            self.turn_feasibility = TurnFeasibilityV8(_prediction_geometry)
        self.dynamic_map.reset_motion_history()
        reset_driving_state(self)
        self._yield_last.clear()
        self._yield_hist.clear()

        mpc_controller = MPCController(N=16 if self.paper_control else 10, dt=0.05, d_safe=2.7, thw_min=0.5, max_speed=MAX_SPEED_LIMIT,
                                       enable_lead_follow_cost=False, enable_boundary_thw=not self.paper_control,
                                       enable_cournot_cost=self.game_config['mpc'],
                                       cournot_weights=(self.w_eff, self.w_safe, self.w_comf),
                                       cournot_thresholds=(self.thw_th, self.j_th, self.psi_th),
                                       cournot_safety_mode=self.cournot_mpc_safety,
                                       cost_profile=self.control_profile if self.paper_control else 'legacy',
                                       step_dts=([.05]*6+[.2]*10) if self.paper_control else None,
                                       vehicle_geometry=self.env.control_geometry if self.revised_control else None)
        matrix_peer, matrix_game = None, None
        if self.game_config['matrix']:
            matrix_peer = MPCController(N=16, dt=.05, d_safe=2.7, thw_min=.5, max_speed=MAX_SPEED_LIMIT,
                enable_lead_follow_cost=False, enable_boundary_thw=False, enable_cournot_cost=False,
                cournot_weights=(self.w_eff, self.w_safe, self.w_comf),
                cournot_thresholds=(self.thw_th, self.j_th, self.psi_th),
                cournot_safety_mode=self.cournot_mpc_safety, cost_profile=self.control_profile,
                step_dts=[.05]*6+[.2]*10, vehicle_geometry=self.env.control_geometry)
            matrix_class = MatrixTurnGameV14 if self.cournot_mode == 'matrix_v14' else MatrixTurnGame
            if self.cournot_mode == 'matrix_v16':
                matrix_class = MatrixTurnGameV16
            if self.cournot_mode == 'matrix_v17':
                matrix_class = MatrixTurnGameV17
            if self.cournot_mode == 'matrix_v18':
                matrix_class = MatrixTurnGameV18
            learning_class = MatrixTurnGameV20 if self.cournot_mode == 'matrix_v20' else MatrixTurnGameV19
            factory = learning_class.from_environment if self.candidate_learning else matrix_class
            matrix_game = factory(_prediction_geometry,
                cruise=float(os.environ.get('DSH_RV_CRUISE_SPEED', '4.412022451715821')),
                legacy=self.cournot_mode == 'matrix_legacy', directory=MODEL_DIR)
        self.trajectory_probe = None
        _probe_mode = os.environ.get('DSH_TRAJECTORY_PROBE', '')
        _evolution_phase = os.environ.get('DSH_TRAJECTORY_EVOLUTION', '')
        _spatial_mode = os.environ.get('DSH_SPATIAL_PROBE', '')
        _rolling_phase = os.environ.get('DSH_ROLLING_PHASE', '')
        if sum(bool(x) for x in (_probe_mode, _evolution_phase, _spatial_mode, _rolling_phase)) > 1:
            raise ValueError('Trajectory experiment owners cannot run together')
        if _probe_mode or _evolution_phase or _spatial_mode or _rolling_phase:
            if (self.method != 'CG' or self.cournot_mode != 'matrix_v18'
                    or self.control_profile != 'paper_v11' or self.forecast_revision != 'route_v18'):
                raise ValueError('Trajectory probes require frozen matrix_v18 CG and paper_v11/route_v18')
            _controller_count = 5 if _rolling_phase else 2
            if _rolling_phase and os.environ.get('DSH_ROLLING_LEARNER') == 'longitudinal_v31':
                _controller_count = 0
            if _rolling_phase and os.environ.get('DSH_ROLLING_LEARNER') == 'joint_v32':
                from Planning_library.joint_planner_v32 import JointPlannerV32
                _controller_count = JointPlannerV32.EXTRA_CONTROLLERS
            if _rolling_phase and os.environ.get('DSH_ROLLING_LEARNER') in ('select_first_v33','paired_v34','entry_v35','reward_v36'):
                from Planning_library.select_first_planner_v33 import SelectFirstPlannerV33
                _controller_count = SelectFirstPlannerV33.EXTRA_CONTROLLERS
            _probe_controllers = [MPCController(N=16, dt=.05, d_safe=2.7, thw_min=.5,
                max_speed=MAX_SPEED_LIMIT, enable_lead_follow_cost=False, enable_boundary_thw=False,
                enable_cournot_cost=False, cost_profile=self.control_profile,
                step_dts=[.05]*6+[.2]*10, vehicle_geometry=self.env.control_geometry)
                for _ in range(_controller_count)]
            if _rolling_phase:
                if os.environ.get('DSH_EFE', '0') != '0':
                    raise ValueError('v24 rolling mechanism validation requires EFE disabled')
                _rolling_efe_mode = os.environ.get('DSH_ROLLING_EFE_MODE', 'off')
                if _rolling_efe_mode not in ('off', 'shadow'):
                    raise ValueError('Unknown rolling EFE mode: ' + _rolling_efe_mode)
                _rolling_class = select_rolling_planner(
                    os.environ.get('DSH_ROLLING_LEARNER', 'legacy_v24'), _rolling_efe_mode)
                import carla
                _road_audit = os.environ.get('DSH_ROAD_AUDIT', 'carla_v25')
                if _road_audit not in ('carla_v25', 'local_v26'):
                    raise ValueError('Unknown rolling road-audit mode: ' + _road_audit)
                _corridor_type = LocalRoadCorridorV26 if _road_audit == 'local_v26' else RoadCorridorV24
                _corridor = _corridor_type.from_carla(self.env.map, carla.Location, carla.LaneType.Driving,
                    _prediction_geometry['forecast_route'], self.env.ego_vehicle.get_location().z, directory=MODEL_DIR)
                self.trajectory_probe = _rolling_class(_rolling_phase, _prediction_geometry,
                    _probe_controllers, _corridor, cruise=matrix_game.cruise, directory=MODEL_DIR,
                    checkpoint=os.environ.get('DSH_ROLLING_CHECKPOINT') or None,
                    seed=int(os.environ.get('DSH_SEED', '1')),
                    epsilon=float(os.environ.get('DSH_ROLLING_EPSILON', '.3')),
                    min_episodes=int(os.environ.get('DSH_BELIEF_MIN_EPISODES', '10')))
                self.trajectory_probe.pose_reader = lambda: self.env.ego_vehicle.get_transform()
            elif _spatial_mode:
                import carla
                _corridor = RoadCorridor.from_carla(self.env.map, carla.Location, carla.LaneType.Driving,
                    _prediction_geometry['forecast_route'], self.env.ego_vehicle.get_location().z)
                self.trajectory_probe = SpatialProbeV23(_spatial_mode, _prediction_geometry,
                    _probe_controllers, _corridor, cruise=matrix_game.cruise, directory=MODEL_DIR,
                    pose_reader=lambda: self.env.ego_vehicle.get_transform())
            elif _evolution_phase:
                if os.environ.get('DSH_EFE', '0') != '0':
                    raise ValueError('v22 trajectory evolution requires EFE disabled')
                self.trajectory_probe = TrajectoryEvolutionV22(_evolution_phase, _prediction_geometry,
                    _probe_controllers, cruise=matrix_game.cruise,
                    checkpoint=os.environ.get('DSH_EVOLUTION_CHECKPOINT') or None, directory=MODEL_DIR,
                    seed=int(os.environ.get('DSH_SEED', '1')),
                    epsilon=float(os.environ.get('DSH_EVOLUTION_EPSILON', '.5')),
                    min_episodes=int(os.environ.get('DSH_BELIEF_MIN_EPISODES', '10')))
            else:
                self.trajectory_probe = TrajectoryProbeV21(_probe_mode, _prediction_geometry,
                    _probe_controllers, cruise=matrix_game.cruise)
        # 纵向 Stackelberg 博弈规划器（leader-follower）
        game_planner = LongitudinalGamePlanner(dt_plan=0.1, N_plan=10)
        # 【博弈修复】接近段基准速度 5 m/s（原 2.22 = 8 km/h 太低，导致自车蠕动、
        # 车流全部通过后才到达，博弈不成立）。接近段另由曲率/距路口限速接管。
        base_ref_speed = min(5.0, MAX_SPEED_LIMIT)
        v_ref = base_ref_speed
        road_right = False

        # 转弯阶段管理器
        period_machine = TurnPeriodManager(approach_dist=20.0, exit_yaw=1.4)
        frame_id = 0
        control_probe = (StopRestartProbe(cruise_speed=float(os.environ['DSH_PROBE_CRUISE_SPEED'])
                         if 'DSH_PROBE_CRUISE_SPEED' in os.environ else None)
                         if self.control_profile in ('paper_v9', 'paper_v10', 'paper_v11') and
                         os.environ.get('DSH_CONTROL_PROBE') == '1' else None)

        # Environment was reset before reading its physical wheel geometry.

        # 初始化变量
        pass_thres = 20  # 每 1s 更新轨迹
        hybrid_action = None
        traj_passed_data = []
        lane_passed_data = []
        trajectory_buffer = []
        lane_buffer = []
        used_act_num = 0
        traj_activate_num = 0
        step_activate_data = []
        evaluate_number = 0
        sum_env_vehicle_dec = 0
        env_vehicle_dec_num = 0
        cut_in_num = 0
        lane_activate_num = 0
        real_reward = []
        # 【论文式58/59】回合级缓冲：整回合每帧 (traj_state, env_sign, lane_state, lane_sign,
        #   action, 即时奖励, 是否RL激活)。回合结束再按 reward-to-go 写库，替换原 20 帧滑动窗口。
        ep_frames = []
        # 回报折扣 γ：决定终局惩罚能回传多远（有效视野 ≈ 1/(1-γ) 帧）。
        # γ=0.98 → 约 50 帧；γ=0.995 → 约 200 帧（接近全回合信用分配）。可用 DSH_GAMMA 调。
        rl_gamma = float(os.environ.get('DSH_GAMMA', '0.98'))
        game_fall = False
        front_id = -1
        rear_id = -1

        # ===== P0: 因果奖励 + 探索 =====
        causal_rewards = []
        last_rl_action_in_window = None
        self._last_yaw_change = None
        epsilon_now = float(getattr(self, 'eps0', 0.4))   # 【S2-①】起点可配

        # ===== 轨迹记录（调试可视化）=====
        episode_rule_trajectory = np.empty((0, 2))
        last_traj_state = None
        accumulated_traj_len = 0
        single_trajectory_point = []
        all_traj_states = []
        record_vehicle_transform = []
        record_vehicle_bbox = []

        # ===== RL 过程动作统计 =====
        rl_process_lane_choice = []
        rl_lane_sign = []
        rl_process_traj_choice = []

        # ===== Phase 1：回合边界指标采样（注意：外层 while 每 20 帧窗口会重跑，
        # 所以 ep_metrics 必须在【回合级】初始化/重置，不能在窗口级）=====
        ep_metrics = []
        self._diag_ep = None          # 诊断打印用：记录已打印过的回合号
        # 【交互诊断】第 1 回合开始（后续每回合在回合末重置处调用 begin_episode，
        # 否则逐回合计数器会跨回合累积 → CSV 变成累计值、且周期报告永不触发）
        self.ilog.begin_episode(len(episode_rewards) + 1)

        epsilon = np.clip(np.random.normal(loc=1.6, scale=1.0), 1, 5)
        open_result = random.choices([0, 1], weights=[0.8, 0.2])[0]

        while True:
            hybrid_action = None
            rewards = []
            causal_rewards = []
            traj_passed_data = []
            lane_passed_data = []
            last_rl_action_in_window = None

            while True:
                # 更新动态地图
                self.dynamic_map.update_map(self.env)
                self.env.spectator_update()

                # A spatial candidate can own the active MPC between upper
                # planner updates. Every new frame must start CG on its own
                # saved reference, while retaining the actual applied control.
                _path_owner = getattr(self, 'trajectory_probe', None)
                if _path_owner is not None and hasattr(_path_owner, 'restore_cg_reference'):
                    _path_owner.restore_cg_reference(mpc_controller, self.dynamic_map)
                _new_trajectory = hybrid_action is None
                if _new_trajectory:
                    # 获取自车状态
                    current_ego_x = self.dynamic_map.ego_vehicle.x
                    current_ego_y = self.dynamic_map.ego_vehicle.y
                    current_ego_yaw = self.dynamic_map.ego_vehicle.yaw
                    current_ego_speed = self.dynamic_map.ego_vehicle.v
                    current_ego_lane = self.dynamic_map.ego_vehicle.lane_idx

                    # 裁剪已有规则轨迹记录
                    if episode_rule_trajectory.size > 0:
                        episode_rule_trajectory = self.truncate_trajectory_to_nearest_point(
                            episode_rule_trajectory, (current_ego_x, current_ego_y)
                        )
                        single_trajectory_len = len(self.truncate_trajectory_to_nearest_point(
                            used_trajectory.trajectory, (current_ego_x, current_ego_y)
                        ))
                        accumulated_traj_len += single_trajectory_len
                        single_trajectory_point.append(accumulated_traj_len)
                        all_traj_states.append(last_traj_state)

                    # ===== 【关键修改】车道级规划：强制使用车道0（参考路径），只取IDM速度 =====
                    # 转弯场景禁止换道，必须沿着参考路径（左转弧线）行驶
                    lane_action = self.lane_planner.run_step(self.dynamic_map, 1.6 if self.paper_control else epsilon)
                    rule_target_speed = min(lane_action.target_speed, MAX_SPEED_LIMIT)  # 限速
                    if self.paper_control:
                        rule_target_speed = 4.0
                    rule_target_lane = 0  # 强制使用参考路径（车道0），禁止换道！

                    # 转弯阶段判断
                    period_num, rl_active = period_machine.step(
                        self.dynamic_map, intersection_center=getattr(self.env, 'INTERSECTION_CENTER', (6.00, -138.00))
                    )
                    # ⑤ 三方法切换（对齐论文 §VI-B SG/CG/GTRL）：
                    #   GTRL = Cournot 博弈 + RL 闭环（默认）；CG = 纯 Cournot 博弈决策（关 RL 层）；
                    #   SG 需 leader-follower（leader_follower_game 后置接线）。
                    if not self.game_config['learning']:
                        rl_active = False

                    # 获取车道标志位
                    lane_sign = self.get_turn_lane_sign(self.dynamic_map)

                    # 获取车道动作（此时 rule_lane_offset 总是 0，因为 current_ego_lane 也会逐渐收敛到0）
                    rule_lane_offset = rule_target_lane - current_ego_lane
                    rule_lane_act = self.get_rule_lane_act_turn(rule_lane_offset)
                    rule_speed_diff = round((rule_target_speed - current_ego_speed) / 2)

                    # ===== 车道级混合决策（两层决策第一层：速度档位）=====
                    # P0 说明：轨迹级动作（速度档位）已能直接控制过弯速度（经 MPC v_ref 生效），
                    # 为避免"两层同时调速度"造成双重控制，此处只统计 lane_activate_num，不再修改 rule_target_speed。
                    _icx, _icy = getattr(self.env, 'INTERSECTION_CENTER', (6.00, -138.00))
                    _egx, _egy = self.dynamic_map.ego_vehicle.x, self.dynamic_map.ego_vehicle.y
                    _dist_inter = math.sqrt((_egx - _icx)**2 + (_egy - _icy)**2)
                    lane_rtree_obs = (current_ego_speed, current_ego_yaw, _dist_inter)
                    lane_num = 3
                    if self.paper_control and not rl_active:
                        hybrid_speed_level, lane_conf_values = rule_lane_act, []
                    else:
                        hybrid_speed_level, lane_conf_values = self.lane_hybrid(
                            lane_rtree_obs, lane_sign, rule_lane_act, self.TS, lane_num=lane_num)
                    if rl_active:
                        lane_activate_num += 1

                    # R-tree 查询坐标（5 维转弯编码：曲率/横向偏差/速度比/冲突时间差/距冲突点）
                    traj_rtree_obs = get_turn_rtree_obs(self.dynamic_map, env=self.env)

                    # 获取环境标志位
                    env_sign = self.get_turn_env_sign(self.dynamic_map)

                    # 空间级规划：目标车道固定为0
                    rule_trajectory, rule_action = self.lane_trajectory_planner.run_step(
                        self.dynamic_map, 0, rule_target_speed, self.env, ref_d=0, open_result=0
                    )

                    # ===== DCARL 混合决策（含 ε-greedy 安全探索 + 冲突安全覆盖）=====
                    # 【§71 修复】`act_confidence_values` 只在 `if rl_active:` 块里被赋值，
                    #   但后面（`activate_data.append`，约 2265 行）**无条件使用**它。
                    #   于是 `DSH_METHOD=CG`（rl_active=False）时抛
                    #   `UnboundLocalError: act_confidence_values referenced before assignment`
                    #   ⇒ **CG 臂一跑就崩** ⇒ 我之前"CG 已实现"的说法不成立（分支在，但跑不通）。
                    #   先初始化；CG/规则路径下为空列表（下游只做记录）。
                    act_confidence_values = []
                    _efe_amb = None
                    if self.belief_learner is not None:
                        _belief_conf = crossing_conflict_detail(self.dynamic_map, self.env)
                        self._begin_belief_decision(traj_rtree_obs, env_sign, rule_action,
                                                    _belief_conf, len(episode_rewards) + 1)
                    if rl_active:
                        explore_action = None
                        self._last_epsilon = float(epsilon_now)
                        _eps_hit = bool(random.random() < epsilon_now)
                        self._last_eps_triggered = _eps_hit
                        if _eps_hit:
                            # 在规则档位 ±2 内探索，但先过滤"预测会冲突"的档位，并始终允许刹车动作0
                            safe_candidates = self._safe_exploration_candidates(
                                self.dynamic_map, self.env, rule_action)
                            # 【V1 落地】探索选择：**最少访问优先**（覆盖式），替代纯均匀 random.choice。
                            #   实测 expAE_land20c：v≥2 的动作只在 6.4~7.8% 的帧里可进，
                            #   其中 `di=+1.5` 档（动作 5、8）**可进 680/579 帧却一次没被选中**
                            #   ⇒ 纯均匀随机无法保证 12 个动作都被访问，V1 验收失败。
                            #   最少访问优先既能保证覆盖（V1），也正好对应论文 §V
                            #   "尝试低不确定性试探策略"的意图，并顺带解决历史上
                            #   "部分动作零样本 ⇒ 哨兵 ±1e9 永久排除"的死锁（PLAN §17）。
                            explore_action = self._pick_exploration_action(safe_candidates)
                        # ② 式56/57：逐候选动作的 EFE(s,a) → R(s,a) = -EFE(s,a)
                        #   仅在 EFE 开启时计算（关闭时不额外做冲突预测，零开销）
                        _efe_rewards = None
                        # 【2026-10-12 修复 D2】本帧逐动作 ambiguity（式57 第二项）。
                        #   用**同帧局部变量**传给 `compute_causal_reward`，而不是让它去读
                        #   实例状态 `self._efe_last` —— 后者只在 `use_efe_reward` 时刷新，
                        #   读取它有**陈旧风险**（本会话已因此栽过两次）。局部变量在同帧内
                        #   传递 ⇒ **结构上不可能陈旧**。
                        if self.use_efe_reward:
                            _efe_rewards = self._efe_by_action(
                                crossing_conflict_detail(self.dynamic_map, self.env,
                                                         beta=self.type_inf.theta()),
                                action_num=N_ACTIONS - 1)
                            # 仅在论文逐动作口径下取用（`legacy` 口径有自己的一条路径，
                            # 两者保持互斥，便于消融归因）
                            if self.efe_mode == 'per_action':
                                _rb = (getattr(self, '_efe_last', None) or {}).get('r_behavior')
                                if isinstance(_rb, dict):
                                    try:
                                        _efe_amb = {int(k): float(v) for k, v in _rb.items()}
                                    except (TypeError, ValueError):
                                        _efe_amb = None
                        hybrid_action, act_confidence_values = self.act_hybrid(
                            traj_rtree_obs, env_sign, rule_action, self.TS, action_num=N_ACTIONS - 1,
                            explore_action=explore_action, efe_values=_efe_rewards
                        )
                        # 【B1 归因】本帧动作的来源（只记录，不改行为）：
                        #   实测 action!=rule 且未接管的帧占 58~67%，但 ε 只有 ~0.27~0.39,
                        #   差额需要归因（ε 探索 vs ④ 屏蔽改写）。没有这列就无法判断
                        #   "动作到底由谁决定"，也就无法解释"奖励改了却没反应"。
                        if self.belief_learner is not None:
                            self._last_decision_src = self.belief_learner.last['source']
                        elif explore_action is not None:
                            self._last_decision_src = 'explore'
                        elif self._last_took_over:
                            self._last_decision_src = 'takeover'
                        else:
                            self._last_decision_src = 'rule'
                        # ===== 安全覆盖：若所选动作预测会与直行车流冲突，回退到规则动作 =====
                        if (not self.paper_control) and self._action_would_conflict(self.dynamic_map, self.env, hybrid_action):
                            if hybrid_action != rule_action:
                                print(f"[DCARL_Turn]: 安全覆盖: action {hybrid_action} 预测冲突，回退规则 {rule_action}")
                            hybrid_action = int(rule_action)
                        used_trajectory = self.lane_trajectory_planner.get_UBP_trajectory(
                            self.dynamic_map, hybrid_action, target_lane=0
                        )
                        last_rl_action_in_window = hybrid_action
                        cut_in_num += 1
                    else:
                        hybrid_action = rule_action
                        used_trajectory = rule_trajectory
                        last_rl_action_in_window = None
                        self._last_decision_src = 'rule_noRL'
                        self._last_took_over = False
                        self._efe_last = {'active': False}
                        self._last_efe_dpsi = None
                        if self.belief_learner is not None and self.use_efe_reward:
                            self._efe_by_action(_belief_conf, action_num=N_ACTIONS - 1)
                            _efe_amb = self._efe_last.get('r_behavior')
                        self._last_epsilon = None
                        self._last_eps_triggered = None

                    # ===== 【创新点④】边界安全硬屏蔽：对**所有**动作来源生效 =====
                    #   必须放在 if rl_active / else 之**外**。此前它放在 rl_active 分支内，
                    #   于是 `rl_active=False` 的帧（hybrid_action = rule_action）完全不受
                    #   屏蔽保护 —— 实测 expG_shield10 里 `lcttc<0.3s` 仍有 22% 的帧没刹车，
                    #   根因就是这些帧走了 else 分支（规则档位自己也会选中速档通过）。
                    _shield = ([True]*N_ACTIONS if self.paper_control else
                               self._shield_allowed_actions(self.dynamic_map, self.env))
                    _shield_override = False
                    # 【§60 权限分离】只有"占用窗/机会约束"判据能**授权**进入；
                    #   ④屏蔽只是**反应式否决**层。一旦窗口判据已授权（闩锁）且自车
                    #   已到/进带内，屏蔽**不得**再把车停住 —— §51/§53 已实测：
                    #   "停在带内"正是被过路车侧刮的直接原因（32/32 碰撞帧）。
                    #   语义即"要么不承诺，要么走完"。
                    _sd_prev = getattr(self, '_last_wait_standoff', None)
                    _skip_shield = bool(
                        self.shield_respect_commit
                        and getattr(self, '_last_committing', False)
                        and (_sd_prev is not None)
                        and (float(_sd_prev) <= self.wait_margin))
                    if _skip_shield:
                        self._shield_skipped_num = getattr(self, '_shield_skipped_num', 0) + 1
                    if (not _shield[int(hybrid_action)]) and (not _skip_shield):
                        _allowed = [a for a in range(N_ACTIONS) if _shield[a]]
                        # ④ 屏蔽只约束**纵向**：取允许集合里最慢的速度档，但**保留**
                        #   策略/规则原本的横向分量。旧式 `min(_allowed, key=ACTION_SPEEDS)`
                        #   在 2d 空间里恒等于 index 0 = (v=0, di=-1.5)，等于屏蔽层
                        #   每帧偷偷下发一条"向左切 1.5 m"——实测 shield 帧 100% 是 action 0。
                        _fb = int(shield_fallback_action(hybrid_action, _allowed))
                        if getattr(self.ilog, 'enabled', False):
                            self.ilog.shield_block(blocked=int(hybrid_action), fallback=_fb)
                        hybrid_action = _fb
                        _shield_override = True
                        self._last_decision_src = 'shield'
                    if _shield_override:
                        # 按屏蔽后的档位重取轨迹（原轨迹是按被拦下的档位生成的）
                        used_trajectory = self.lane_trajectory_planner.get_UBP_trajectory(
                            self.dynamic_map, hybrid_action, target_lane=0
                        )

                    # MPC 路径重置
                    # All new RULE/matrix arms share the identical bounded-error
                    # spatial geometry, including precheck, scoring and final audit.
                    self.control_experiment.condition(used_trajectory)
                    mpc_controller.reset_global_path(used_trajectory.trajectory, dynamic_map=self.dynamic_map)
                    if _path_owner is not None and hasattr(_path_owner, 'remember_cg_reference'):
                        _path_owner.remember_cg_reference(mpc_controller)
                    if self.belief_learner is not None:
                        self.belief_learner.start_action(hybrid_action, forced=_shield_override)
                        self.belief_tracker.execute(self._belief_actor,
                            self._belief_model_probabilities(_belief_conf, hybrid_action))

                    # 记录是否激活
                    if hybrid_action != rule_action:
                        last_traj_state = 0
                        traj_activate_num += 1

                        activate_data.append((
                            current_ego_x, current_ego_y, traj_rtree_obs, lane_sign,
                            rule_lane_act, hybrid_action, current_ego_lane, 0,
                            rule_target_lane, rule_target_speed, rule_target_speed,
                            [], traj_rtree_obs, env_sign, hybrid_action, rule_action,
                            act_confidence_values
                        ))
                        self.save_activate_data(activate_data)
                    else:
                        last_traj_state = 1

                    used_act_num += 1

                    # 记录规则轨迹
                    episode_rule_trajectory = np.append(
                        episode_rule_trajectory, rule_trajectory.trajectory, axis=0
                    )

                    # 记录车辆位姿
                    env_instate_vehicle = self.env.vehicles_with_bbox
                    env_ego_vehicle = self.env.ego_vehicle
                    action_frame_vehicle_loc = [env_ego_vehicle.get_transform()]
                    action_frame_vehicle_bbox = [env_ego_vehicle.bounding_box]
                    for v in env_instate_vehicle:
                        action_frame_vehicle_loc.append(v.get_transform())
                        action_frame_vehicle_bbox.append(v.bounding_box)
                    record_vehicle_transform.append(action_frame_vehicle_loc)
                    record_vehicle_bbox.append(action_frame_vehicle_bbox)

                    rl_process_lane_choice.append((0, rule_speed_diff))
                    rl_lane_sign.append(lane_sign[0][1])

                # ===== MPC 求解 + 环境交互 =====
                road_right = self.get_turn_road_right(self.dynamic_map)

                # ===== 【关键修改】动态速度调整：强制限速并提前减速 =====
                path = _get_ref_path_array(self.dynamic_map)
                if path is not None and len(path) > 20:
                    curv = abs(self._calc_curvature_at(dynamic_map=self.dynamic_map))
                    # 根据曲率计算安全速度，但限制最大 8 m/s
                    if curv > 0.01:
                        v_ref = np.clip(math.sqrt(0.7 * 9.8 / curv), 1.5, 8.0)
                    else:
                        v_ref = 8.0
                else:
                    v_ref = base_ref_speed

                # 距路口距离，进一步减速（接近段 25m 起，最低 4 m/s，避免进弯蠕动）
                _icx, _icy = getattr(self.env, 'INTERSECTION_CENTER', (6.00, -138.00))
                _egx, _egy = self.dynamic_map.ego_vehicle.x, self.dynamic_map.ego_vehicle.y
                dist_to_inter = math.sqrt((_egx - _icx)**2 + (_egy - _icy)**2)
                _speed_limit_ramp = 8.0   # 无接近减速时的默认限速（让行恢复用）
                if dist_to_inter < 25.0:
                    # 25m→6m/s, 5m→4m/s 线性
                    speed_limit = np.clip(4.0 + (dist_to_inter - 5.0) * 2.0 / 20.0, 4.0, 6.0)
                    _speed_limit_ramp = float(speed_limit)
                    v_ref = min(v_ref, speed_limit)

                # The longitudinal leader/follower model belongs only to SG.
                # CG/GTRL must not inherit a second, x-axis speed game silently.
                _stackelberg_active = False
                if self.game_config['stackelberg'] and len(self.dynamic_map.lanes[0].rear_vehicles) > 0:
                    v_ref = game_planner.plan(self.dynamic_map, v_ref, v_ref)
                    _stackelberg_active = True

                # 最终限速
                v_ref = min(v_ref, MAX_SPEED_LIMIT)
                # 【S6-① 观测】记录抬升前的值，用于离线量化"3.0 下限"吃掉了多少制动意图
                _v_ref_pre_floor = float(v_ref)
                # 【博弈修复】接近段速度下限 3 m/s：防止 IDM/规则把自车压到蠕动
                # （RL 档位与让行决策仍可在后续覆盖/清零）。原版 2.2 m/s 基准让
                # 车流在自车到达前全部通过，博弈不成立。
                v_ref = max(v_ref, 0.0 if self.paper_control else 3.0)
                if self.paper_control:
                    v_ref = min(v_ref, float(rule_target_speed))
                _rl_speed_cap = None

                # ===== P0: RL 速度档位生效（仅当 RL 明确偏离规则动作时才限制 v_ref）=====
                # 关键修正: 规则动作的轨迹速度不参与 v_ref（否则 IDM 把交叉车流当排队前车、
                # rule_target_speed 降到 2~3 会直接把 MPC 目标速度压到蠕动/停车）。
                # 只有 RL 选择了与规则不同的档位时才 cap，且设下限 1.5 m/s 避免停车。
                if rl_active and used_trajectory is not None and hybrid_action is not None \
                        and int(hybrid_action) != int(rule_action) \
                        and hasattr(used_trajectory, 'desired_speed'):
                    _dsp = used_trajectory.desired_speed
                    if hasattr(_dsp, '__len__'):
                        rl_speed_cap = float(np.mean(_dsp))
                    else:
                        rl_speed_cap = float(_dsp)
                    v_ref = min(v_ref, max(rl_speed_cap, 1.5))   # 下限 1.5 m/s
                    _rl_speed_cap = float(rl_speed_cap)
                if self.paper_control and rl_active and hybrid_action is not None:
                    # Preserve explicit stop actions; legacy's 1.5 m/s floor is
                    # inappropriate for a selected zero-speed trajectory.
                    v_ref = min(v_ref, max(0., float(action_speed(hybrid_action))))

                # ===== 【P0 修复】冲突点二元决策：能清空就按 v_ref 通过，不能就停在停止线外等间隙（绝不蠕动）=====
                # 根因：旧"压到 2 m/s 让行"让自车以极低速滞留在冲突区内，被直行车流追尾
                #      （数据铁证：两起碰撞均发生在 ego 1.0~1.5 m/s 蠕动、d_rear≈0 时）。
                # 修复：还能安全停车 → 到达时间差不足就完全停在停止线外；已进入冲突区 → 保持 v_ref 尽快清空。
                _conf = crossing_conflict_detail(self.dynamic_map, self.env,
                                                 beta=None if self.paper_control else self.type_inf.theta())
                _conf['observed_vehicles'] = list(self.dynamic_map.objects)
                # ===== Phase 1：回合边界指标采样（每帧，无副作用，供离线分析）=====
                # 元组: (lcttc_rv, lcttc_fv, thw_boundary_rv, n_vehicles, n_objects, gap)
                # n_vehicles = 冲突筛选后参与评估的交叉车辆数；n_objects = 动态地图对象总数
                # （诊断用：若 n_objects=0 说明地图没拿到车，若 n_vehicles=0 说明筛选没匹配上）
                ep_metrics.append((
                    _conf.get('lcttc_rv', float('inf')),
                    _conf.get('lcttc_fv', float('inf')),
                    _conf.get('thw_boundary_rv', float('inf')),
                    int(_conf.get('n_vehicles', 0)),
                    int(len(getattr(self.dynamic_map, 'objects', []))),
                    float(_conf.get('gap', 30.0)),
                ))
                # 【诊断】每回合首次出现"地图有车但冲突筛选=0"时打印真实几何
                # （定位冲突点/车流坐标不匹配；确认修复后可删除本块）
                _ep_num = len(episode_rewards) + 1
                if _conf.get('n_vehicles', 0) == 0 and len(getattr(self.dynamic_map, 'objects', [])) > 0 \
                        and self._diag_ep != _ep_num:
                    self._diag_ep = _ep_num
                    _eg = self.dynamic_map.ego_vehicle
                    _objs = list(getattr(self.dynamic_map, 'objects', []))[:3]
                    _veh_str = '; '.join(
                        f'({o.x:.1f},{o.y:.1f},yaw={getattr(o, "yaw", 0.0):.2f},v={getattr(o, "v", 0.0):.1f},vx={getattr(o, "vx", 0.0):.1f})'
                        for o in _objs)
                    print(f"[诊断#{_ep_num}] ego=({_eg.x:.1f},{_eg.y:.1f},v={_eg.v:.1f}) "
                          f"conflict=({_conf.get('conflict_x', 0):.1f},{_conf.get('conflict_y', 0):.1f}) "
                          f"t_ego={_conf.get('t_ego', 0):.1f}s arc={_conf.get('arc_to_cross', 0):.1f}m "
                          f"n_obj={len(getattr(self.dynamic_map, 'objects', []))} "
                          f"vehs=[{_veh_str}]")
                _stop_arc = 5.0                       # 停止线：冲突点前 5m（车头不侵入直行车道）
                _a_brake = 3.0                        # 最大制动减速度 (m/s²)
                # ===== 【顺序修复】这几个开关必须在**入口决策之前**定义 =====
                #  bug：S13 补丁把"逐速度档证明"的**使用**插进了入口决策（约 1946 行），
                #       而 `_per_speed` 的**定义**却留在了后面的 S6/S8 块（约 2175 行）
                #       ⇒ `UnboundLocalError: _per_speed`（3 个种子全部崩溃）。
                #  ⇒ 所有在入口决策里被用到的开关一律提到这里定义。
                _per_speed = os.environ.get('DSH_GAP_PER_SPEED', '0') == '1'
                _in_entry_regime = (not _conf['committed']) and _conf.get('n_vehicles', 0) > 0
                _entry_auth = (os.environ.get('DSH_ENTRY_AUTH', '0') == '1') or _per_speed
                # 过弯目标速度（所有分支共用，提前定义）
                _go_speed = max(4.0, _speed_limit_ramp)
                # 到冲突点弧长：必须在 if/else 之前定义（else 分支第747行也用到 _arc；
                # 用 get 兜底，防 committed / 无车时 arc_to_cross 缺键）
                _arc = max(float(_conf.get('arc_to_cross', 0.0)), 0.0)
                # ===== 【P4 诊断修复】路径/轨迹 dump 钩子 =====
                #  ⚠ 教训：原先把本钩子放在 `used_trajectory` 生成处（约 1110 行），而
                #    `_conf = crossing_conflict_detail(...)` 在约 1250 行才计算 ⇒ 钩子读到的是
                #    **上一帧的 _conf**。稳态下只差一帧，但跨回合时"上一帧"= 上回合末帧，
                #    于是每回合首帧的 arc/lat_dev 全是残留值（实测 6.135/3.558 等），
                #    我据此误判成"回合首帧几何错/MPC 跟踪误差 3.5 m"，浪费了两轮。
                #    现在移到 _conf 之后，保证 arc/lat_dev 与 ego 是同一帧。
                self._traj_id = getattr(self, '_traj_id', 0) + int(_new_trajectory)
                try:
                    if not getattr(self.path_diag, '_static', None):
                        _fl = (getattr(self.lane_trajectory_planner, 'frenet_lanes', None) or [None])[0]
                        try:
                            _refarr = _get_ref_path_array(self.dynamic_map)
                        except Exception:
                            _refarr = None
                        try:
                            _rraw = self.dynamic_map.lanes[0].central_path_array
                        except Exception:
                            _rraw = None
                        self.path_diag.sample_static(
                            ref_path_array=_refarr,
                            frenet_ref_path=getattr(_fl, 'ref_path', None),
                            route_raw=_rraw,
                            csp=getattr(_fl, 'csp', None))
                    _traj_xy = getattr(used_trajectory, 'trajectory', None)
                    if _new_trajectory or not getattr(mpc_controller, '_solve_ok', True):
                        self.path_diag.decision(
                            frame=frame_id, target_speed=v_ref, traj_xy=_traj_xy,
                            ego=getattr(self.dynamic_map, 'ego_vehicle', None),
                            arc_to_cross=_conf.get('arc_to_cross'),
                            lat_dev=_conf.get('lat_dev'),
                            traj_id=self._traj_id,
                            extra={'hybrid_action': int(hybrid_action),
                                   'rule_action': int(rule_action),
                                   'rl_active': bool(rl_active),
                                   'planning_status': getattr(used_trajectory, 'planning_status', 'normal')})
                except Exception:
                    pass
                # 【④·P3b】本帧是否"获准进入冲突区"（由下面的判据置 True）。
                #   未获准时受"安全回退位 hold_arc"硬约束（见本块之后的 clamp）。
                if self.paper_control:
                    _advance_entry_called = False
                    _ev = self.dynamic_map.ego_vehicle
                    _sd = wait_standoff(_ev.x, _ev.y, _ev.yaw,
                        vehicle_size(_ev, 'length', 4.5) if self.revised_control else float(getattr(_ev, 'length', 4.5) or 4.5),
                        vehicle_size(_ev, 'width', 2.) if self.revised_control else float(getattr(_ev, 'width', 2.) or 2.),
                        float(_conf.get('conflict_y', -138.)), BAND_HALF_DEFAULT)
                    if matrix_game is not None:
                        # Entry timing belongs to the matrix below, after both
                        # common MPC candidates have actually been solved.
                        # The same final execution audit remains mandatory.
                        self.turn_feasibility.last = dict(profile=matrix_game.revision, phase='approach',
                            safe=True, min_gap=None, conflict_id=None, body_clear=False)
                    elif not self.control_experiment.advance_enabled:
                        # Explicit RULE ablation: no advance occupancy gate.
                        # safe=True only opens this gate, not a safety verdict;
                        # the common select_execution audit still runs below.
                        self.turn_feasibility.last = dict(profile='minimal_rule_v15', phase='approach',
                            safe=True, min_gap=None, conflict_id=None, body_clear=False)
                    else:
                        _advance_entry_called = True
                        v_ref = self.turn_feasibility.target(_ev, self.dynamic_map.objects,
                            used_trajectory.trajectory, v_ref, _sd, mpc_controller.last_u['a'],
                            committed=bool(_conf.get('committed')))
                    _entry_granted = self.turn_feasibility.last['safe'] or (not self.revised_control and _sd <= 0.)
                    self._last_entry_granted = bool(_entry_granted)
                    self._last_wait_standoff = float(_sd)
                    self._last_gap_ok = self.turn_feasibility.last['safe']
                    self._last_commit_latched = self._commit_latched = bool(
                        self.turn_feasibility.launched and _sd <= 12.)
                    self._last_committing = bool(_sd <= 0. and not self.turn_feasibility.last.get('body_clear', False))
                    self._last_commit_risk = None
                    self._last_commit_risk_fresh = False
                    self._last_cournot_gate_reason = 'deterministic_cv_'+self.turn_feasibility.last['phase']
                    self._last_take_cournot = bool(self.game_config['mpc'] or self.game_config['matrix'])
                    self._last_risk_gate_ok = bool(_entry_granted)
                    self._last_control_gate = dict(self.turn_feasibility.last)
                    self._last_clamp_stopped = v_ref <= .01
                else:
                    _entry_granted = False
                    if not _conf['committed'] and _conf['n_vehicles'] > 0:
                        _ego_v = max(float(self.dynamic_map.ego_vehicle.v), 0.1)
                        _brake_dist = _ego_v ** 2 / (2.0 * _a_brake)
                        # 【§53 诊断】`_gap_ok` 只在下面的 `elif` 分支内被赋值 ⇒ 必须先初始化，
                        #   否则其它分支会让诊断语句 `UnboundLocalError`（实测已崩 3/3 臂）。
                        _gap_ok = None
                        # 【2026-10-12 修复 D3'】`_last_commit_risk` 必须**逐帧重置**。
                        #   缺陷：它只在 `__init__` 初始化 + 在 `risk_commit and _in_entry_zone`
                        #     块内赋值 ⇒ **进入区外不会被更新**，于是保留上一帧（甚至上一回合）
                        #     的旧值。后果有二：
                        #       (1) D3' 的 'risk' 口径可能用**陈旧的低风险值**授权进入 —— 危险；
                        #       (2) 落盘的 `commit_risk` 列在进入区外是**陈旧值**
                        #           ⇒ 任何基于该列的离线分析都会被污染。
                        #   重置为 None ⇒ 未在本帧计算时，下游只会看到"未知"（不会被误用）。
                        self._last_commit_risk = None
                        self._last_commit_risk_fresh = False
                        # 【2026-10-12 修复 D3'·陈旧性】同类的**诊断列**也必须逐帧重置。
                        #   缺陷（实测捕获）：`_last_cournot_gate_reason` / `_last_risk_value_ok`
                        #     只在"间隙不足 ⇒ 博弈分支"里被赋值 ⇒ 走 `if _gap_ok:` 分支的帧
                        #     会保留**上一帧**的值。实测冒烟跑出现 26/896 帧
                        #     `authority_risk_blocked` 却 `entry_granted=1` —— 正是本陈旧性造成
                        #     （该帧其实走了 `if _gap_ok:` 主通道，reason 是上一帧残留）。
                        #   ⇒ 不重置就无法用这两列定位"①到底有没有授权"。
                        self._last_cournot_gate_reason = None
                        self._last_risk_value_ok = None
                        # 【§53】就地算一次车头净空（本块在 C2 之前，拿不到 C2 的 _sd2）
                        try:
                            _ev3 = self.dynamic_map.ego_vehicle
                            _sd3 = wait_standoff(
                                float(_ev3.x), float(_ev3.y), float(getattr(_ev3, 'yaw', 0.0)),
                                float(getattr(_ev3, 'length', 4.5) or 4.5),
                                float(getattr(_ev3, 'width', 2.0) or 2.0),
                                float(_conf.get('conflict_y', -138.0)), BAND_HALF_DEFAULT)
                            self._inside_band_now = bool(_sd3 is not None and _sd3 <= 0.0)
                            self._standoff_now = _sd3
                            # 【§55 自校准】车头刚跨过带北边缘的那一刻，记下 ego_x
                            #   —— 这才是"自车左转路径进入车流带的 x"的真值，
                            #   用来核对/替换硬编码的 conflict_x（见 §55）。
                            #   ⚠️ 必须**按回合**记录：旧写法 `is None` 只在整轮第一次锁一次，
                            #      且跨回合不复位 ⇒ 记录的 x 来自第一个进入的回合，会误导 §55 的校准。
                            _ep_now = int(getattr(self.ilog, 'episode', 0) or 0)
                            if _sd3 is not None and _sd3 <= 0.0 \
                                    and getattr(self, '_band_entry_ep', None) != _ep_now:
                                self._band_entry_ep = _ep_now
                                self._band_entry_x = float(_ev3.x)
                                self._band_entry_num = getattr(self, '_band_entry_num', 0) + 1
                            self._last_band_entry_x = getattr(self, '_band_entry_x', None)
                            self._last_band_entry_num = getattr(self, '_band_entry_num', 0)
                        except Exception as _e3:
                            self._inside_band_now = False
                            self._clamp_err = '%s: %s' % (type(_e3).__name__, _e3)
                        if _arc <= _stop_arc + 0.5:
                            # 已进入冲突区（无法在停止线前停住）→ 【强制提速清空】：
                            # 绝不停在/蠕动在冲突区内（否则成为车流的活靶子——碰撞根因）。
                            # ⚠️【§53】此路径**不检查间隙**。历史实测（本文件下方注释）：
                            #   开启"蠕动到停止线"会让 ego 进入本区 ⇒ 碰撞率 33.7%→96.3%
                            #   ⇒ 本路径必须只在"确实已在带内"时才允许触发（见下方 gate）。
                            if (not self.force_clear_gate) or self._inside_band_now:
                                v_ref = max(v_ref, _go_speed)
                                self._yield_was_stopped = False
                                _entry_granted = True
                                self._force_clear_num = getattr(self, '_force_clear_num', 0) + 1
                            else:
                                self._force_clear_blocked_num = getattr(self, '_force_clear_blocked_num', 0) + 1
                        elif _brake_dist < (_arc - _stop_arc):
                            # 能在停止线前停住 → 判定能否安全清空：能则走，不能则停
                            # 【间隙判定（核心修复）】不能只看"最近车"：密集车流里最近车
                            # 永远在 1~2s 内 → 永远判"不能过" → 永久让行 → 卡死。
                            # 正确逻辑（论文 FV/RV 语义）：自车以目标速度出发，到达冲突点
                            # 的时间为 t_ego_go；它"跟随前车 FV（先到者）、切入后车 RV
                            # （第一个晚于自车到达者）前方"。只需 RV 足够远即可走——
                            # 若 RV 让行（减速），其 t_veh 变大 → 间隙打开 → 自车出发。
                            # 【§54】到达时间与清空时长：改用**真实运动模型**
                            #   （从当前速度匀加速到 go_vmax，含执行滞后），
                            #   而不是 `_arc / _go_speed` 的恒定速度假设。
                            #   `_ego_v` 是本帧实际车速（见上方 `_ego_v = max(..., 0.1)`）。
                            _ego_len_ref_here = float(
                                getattr(self.dynamic_map.ego_vehicle, 'length', 4.5) or 4.5)
                            if self.standoff_clearance:
                                # 【§54b】用**车头到带边缘的净空**锚定占用窗（关键）
                                _t_ego_go, _clr_real = required_clearance_from_standoff(
                                    self._standoff_now if self._standoff_now is not None else _arc,
                                    _ego_v, ego_len=_ego_len_ref_here,
                                    band=self.clear_band, v_max=self.go_vmax,
                                    a_go=self.go_accel, margin=self.clear_margin,
                                    dt_lag=self.act_delay)
                            elif self.real_clearance:
                                _t_ego_go, _clr_real = required_clearance(
                                    _arc, _ego_v, ego_len=_ego_len_ref_here,
                                    band=self.clear_band, v_max=self.go_vmax,
                                    a_go=self.go_accel, margin=self.clear_margin,
                                    dt_lag=self.act_delay)
                            else:
                                _t_ego_go = _arc / max(_go_speed, 0.5)   # 旧口径（消融对照）
                                _clr_real = None
                            # 【④·P3 修复】清空时间要算**整个车身穿过交叉带**，不是只算车头到达：
                            #   旧式 `4.0/v_go + 0.5` 漏掉了交叉车流带宽度，把"其实插不进去"
                            #   判成"能过"。实测 expJ 碰撞全是进入阶段（committed=0、arc≈10.2m）
                            #   的侧刮。新式 = (ego_len + band)/v_go + margin，见
                            #   boundary_safety.entry_clearance_time。
                            _ego_len = float(getattr(self.dynamic_map.ego_vehicle, 'length', 4.5) or 4.5)
                            if self.real_clearance and _clr_real is not None:
                                _clr_go = float(_clr_real)     # 【§54】真实运动占用窗
                            else:
                                _clr_go = entry_clearance_time(   # 旧口径（消融对照）
                                    _go_speed, ego_len=_ego_len,
                                    band=self.clear_band, margin=self.clear_margin)
                            self._last_t_ego_go = float(_t_ego_go)
                            self._last_clr_go = float(_clr_go)
                            # 【P4-①】把"匀速 t_veh"换成"最坏情况(恢复巡航)到达时间"，
                            #   并对**所有**接近车做"占用窗口不重叠"检验（不再是只看第一辆晚到车）。
                            _t_veh_worst = self._worst_case_t_veh_list(_conf)
                            _gap_ok_raw = entry_gap_is_safe(_t_ego_go, _t_veh_worst, _clr_go)
                            # 【P4-①b 距离门】只在**接近区**内用最坏情况判据裁决进入。
                            #   实测 expU_p4_20：判据在任意距离都裁决 ⇒ 14 辆连续车流下
                            #   "占用窗不重叠"几乎永不满足 ⇒ 自车在 arc=26.6 m（距冲突点 26 m、
                            #   lcttc 39~200 完全无危险）就冻住，碰撞率 0% 但卡死率 30%。
                            #   正确做法是两段式：远处自由接近（由规则控速），进入接近区后
                            #   才用"最坏情况清空"裁决是否进路口。这与 `_action_would_conflict`
                            #   的 15 m 门保持一致。
                            _in_entry_zone = _arc <= float(getattr(self, 'entry_zone', 15.0))
                            _gap_ok = bool(_gap_ok_raw) if _in_entry_zone else True
                            # 仍保留"第一个晚于自车到达的车"作为 RV 位置的兜底估计
                            # （下游 `_rv_veh is None` 的极端分支用它估 RV 位置）
                            _t_veh_after = [t for t in (_t_veh_worst or []) if t > _t_ego_go]
                            _rv_t = min(_t_veh_after) if _t_veh_after else float('inf')
                            # 【S13】逐速度档证明（证明速度 == 执行速度）
                            _per_speed_v = None
                            if _per_speed:
                                _cands = sorted({float(_v) for _v in ACTION_SPEEDS if float(_v) > 0.5},
                                                reverse=True)          # 快 → 慢
                                for _vc in _cands:
                                    _cl = entry_clearance_time(
                                        _vc, ego_len=_ego_len,
                                        band=self.clear_band, margin=self.clear_margin)
                                    if entry_gap_is_safe(_arc / max(_vc, 0.5), _t_veh_worst, _cl):
                                        _per_speed_v = float(_vc)
                                        break
                                _gap_ok = _per_speed_v is not None
                                if not _gap_ok:
                                    v_ref = 0.0

                            # ===== 【§60】机会约束授权（覆盖上面的标量口径）=====
                            #   在接近区内用 risk ≤ δ 决定是否进；区外自由接近（保留 P4-①b 距离门）。
                            if self.risk_commit and _in_entry_zone:
                                _cands, _plist = self._approach_candidates(_conf)
                                _risk, _krisk = commit_risk(
                                    _cands, _t_ego_go, _t_ego_go + _clr_go,
                                    p_yield=(_plist if self.p_yield_mode == 'model'
                                             else self.p_yield_commit),
                                    veh_clear_time=self.veh_clear_safe,
                                    max_veh=self.risk_max_veh)
                                self._last_commit_risk = float(_risk)
                                # 【2026-10-12 修复 D3'】标记"本帧的风险值**确实算过**"。
                                #   ① 的 'risk' 授权口径必须要求该标志，否则会用到陈旧值。
                                self._last_commit_risk_fresh = True
                                self._last_risk_veh = int(_krisk)
                                # 【§70 间隙稳定性】要求 `risk ≤ δ` **连续 N 帧**才授权。
                                #   原理：48.3% 的碰撞全部是"用 risk ≤0.30 批准进入 ⇒ 穿越途中
                                #   risk 升到 1.0 ⇒ 承诺不可中止 ⇒ 撞" —— 即**授权踩在风险的
                                #   瞬时低谷上**。要求连续性后，只有**持续清空**的间隙才会被
                                #   批准，那种"刚批完就恶化"的时机被自然滤掉。
                                #   与"安全中止"的区别：中止是在**承诺后**补救（已实测失败，
                                #   因为中止⇒交回等待纪律⇒卡死）；稳定性是在**承诺前**筛选。
                                #   `DSH_RISK_STABLE_N=0` = 关闭（保持已 3-seed 验证的基线不变）。
                                if _risk <= self.risk_max:
                                    self._risk_ok_streak = getattr(self, '_risk_ok_streak', 0) + 1
                                else:
                                    self._risk_ok_streak = 0
                                _stable_n = max(int(self.risk_stable_n), 0)
                                _gap_ok = bool(_risk <= self.risk_max) and (
                                    _stable_n == 0 or self._risk_ok_streak >= _stable_n)
                                self._last_risk_streak = int(self._risk_ok_streak)
                                self._risk_gate_num = getattr(self, '_risk_gate_num', 0) + 1
                            # 【§53 诊断】此处 `_gap_ok` 已定值（含 per_speed 覆写与 §60 风险门）
                            self._last_gap_ok = _gap_ok
                            if _gap_ok:
                                # 间隙足够（任何车抢行也不会撞）→ 出发
                                # 【S13】per_speed：执行速度必须**等于证明用的速度**，
                                #   否则占用窗的前提被作废（S8 的 80% 碰撞就是这么来的）。
                                v_ref = float(_per_speed_v) if _per_speed else max(v_ref, _go_speed)
                                self._yield_was_stopped = False
                                _entry_granted = True
                                # 【2026-10-12 修复 D3'·陈旧性】本帧**未咨询**博弈
                                #   （占用窗/机会约束判据直接通过）⇒ 显式标记，
                                #   避免诊断列保留上一帧的博弈结论。
                                self._last_cournot_gate_reason = 'gap_ok'
                            else:
                                # 【① Cournot 零和博弈】间隙不足 → 用"ego vs RV"同步博弈
                                # 的期望支付决策：p_yield = RV 让行概率（rv_decision 同模型，
                                # 车流侧按同一概率采样让/抢）→ 让行概率高 ego 才出发（博弈耦合）。
                                _rv_veh = _conf.get('rv_veh')
                                if _rv_veh is not None:
                                    _rv_x = float(_rv_veh.x)
                                    _rv_v = max(float(getattr(_rv_veh, 'v', 10.0)), 0.1)
                                else:
                                    # 极端排序无 RV 对象：按"晚于目标到达时间的最近车"估算
                                    _rv_x = float(_conf['conflict_x']) + _rv_t * 10.0
                                    _rv_v = 10.0
                                _ego_st = self.dynamic_map.ego_vehicle
                                _ego_sd = {'x': float(_ego_st.x), 'y': float(_ego_st.y), 'v': _ego_v}
                                _rv_sd = {'x': _rv_x, 'y': float(_conf['conflict_y']),
                                          'v': _rv_v, 'vx': -_rv_v}
                                _ttc_b = _conf.get('ttc_boundary')
                                _rv_acc = float(_conf.get('rv_acc') or 0.0)
                                _rv_acc_f = _conf.get('rv_acc_follow')
                                # 【对手类型推断·式17 + §IV-C】ego 只观测对手"运动"：
                                #   RV 明显低于自由流速度 → 判为"让行"，否则"抢行"；按固定节奏观测
                                #   并更新类型后验，用推断出的 θ（而非写死 0.5）计算让行概率。
                                if _rv_veh is not None and self.belief_tracker is None:
                                    self._type_obs_counter = getattr(self, '_type_obs_counter', 0) + 1
                                    if self._type_obs_counter >= self.type_obs_interval:
                                        self._type_obs_counter = 0
                                        # 【0''-b】让行/抢行判据 = ratio × RV 巡航速度
                                        _thr = self._type_yield_threshold()
                                        _oy = self._observed_rv_action(_rv_veh) == 'yield'
                                        self.type_inf.observe(
                                            _ego_sd, _rv_sd, float(_conf['conflict_x']),
                                            observed_yield=_oy,
                                            ttc_boundary=_ttc_b,
                                            acc_current=_rv_acc, acc_follow=_rv_acc_f)
                                        _d = self._type_obs_diag
                                        _d['n_obs'] = _d.get('n_obs', 0) + 1
                                        if _oy:
                                            _d['n_yield'] = _d.get('n_yield', 0) + 1
                                        _d['th_last'] = float(_thr)
                                        _d.setdefault('samples', [])
                                        if len(_d['samples']) < 40:
                                            _d['samples'].append((round(float(_thr), 3),
                                                                  round(float(_rv_v), 3), int(_oy)))
                                _p_yield = rv_yield_probability(
                                    _ego_sd, _rv_sd,
                                    float(_conf['conflict_x']), _ttc_b,
                                    theta=self.type_inf.theta(),
                                    acc_current=_rv_acc, acc_follow=_rv_acc_f,
                                    t_ego=_conf.get('t_ego'))
                                # 【式(24)】从**候选轨迹**（本帧实际要执行的那条）推 J_LCV/ψ_LCV
                                try:
                                    _comfort_j, _comfort_s = trajectory_comfort(
                                        frenet=getattr(used_trajectory, 'frenet', None),
                                        traj_xy=getattr(used_trajectory, 'trajectory', None),
                                        desired_speed=getattr(used_trajectory, 'desired_speed', None))
                                except Exception:
                                    _comfort_j, _comfort_s = 0.0, 0.0
                                self._last_comfort = (_comfort_j, _comfort_s)
                                _cd = cournot_decision(
                                    _arc, abs(_rv_x - float(_conf['conflict_x'])),
                                    v_go=_go_speed, p_yield=_p_yield,
                                    # 【P4-②】THW 用**抢行假设下的最坏值**：对手恢复巡航时
                                    #   接近速度更大 ⇒ THW 更小 ⇒ "走"这一行的 U_safe 更低。
                                    #   在 left_turn（单调）模式下这才是正确的软惩罚。
                                    thw_rv=self._worst_thw_rv(_conf),
                                    thw_fv=_conf.get('thw_boundary_fv'),
                                    u_safe_mode=self.u_safe_mode,
                                    # 【式24 三组件】U_speed 用 (v-v_ref)²；U_comfort 用真实 jerk/转向角速率
                                    # 【式(20)】权重经参数传入（原来全用 build_payoff_matrix 的硬编码默认值）
                                    w_eff=self.w_eff, w_safe=self.w_safe, w_comf=self.w_comf,
                                    wait_penalty=self.wait_penalty, thw_th=self.thw_th,
                                    v_ref=_speed_limit_ramp,
                                    # 【式(24)】jerk/steer **由候选轨迹推出**（原来是常数 1.0/0.4）。
                                    #   常数会让 12 个动作的 U_comfort 完全相同 ⇒ 二维动作的
                                    #   区分度丢一半（见 PLAN §37.5）。阈值沿用代码既有 0.5/0.3。
                                    jerk=_comfort_j, steer=_comfort_s,
                                    # 【L1】式(24) 的 J_TH/ψ_TH：**论文 Table I 未给该值**
                                    #   （那两行是 `−`）⇒ 自由参数，必须可配且不得声称来自论文。
                                    jerk_th=self.j_th, steer_th=self.psi_th)
                                # 【S12】硬否决开关（DSH_GAP_HARD_VETO=1，默认 0）：
                                #  实测教训：`expU_p4_20` 用"到处硬否决"拿到
                                #  **70% 成功 / 0% 碰撞 / 30% 卡死** —— 按"安全优先、等待合法"
                                #  的口径这是全项目最好的结果，我当初却以"靠不进入换来"否掉了它。
                                #  它的问题只是"冻在 arc=26.57 m"（进入区之外也否决），
                                #  而这已由 P4-①b 的 `_in_entry_zone`(15 m) 门修好。
                                #  ⇒ **"硬否决 + 15 m 进入区"这个组合从未被测过**，本次补测。
                                #  语义：进入区内若"占用窗不重叠"不成立，则**不停留在博弈赌一把**，
                                #  直接停到带外等下一个间隙（等待是允许的；赌错才是碰撞来源）。
                                # 【§71 消融开关·创新点① Cournot】关闭时恒不走"博弈判走"分支，
                                #   即退化为"间隙不足就停"的规则式处理 ⇒ 用于隔离①的贡献。
                                if (not self.game_config['discrete']) or os.environ.get('DSH_GAP_HARD_VETO', '0') == '1':
                                    v_ref = 0.0
                                    _take_cournot = False
                                else:
                                    _take_cournot = True
                                # ===== 【§61 关键修复】风险门必须是**唯一**的授权通道 =====
                                #   BUG 实测（expS60_NEW_GAP11_seed1/2）：承诺起点共 43 次，
                                #   其 `commit_risk` 中位 = **0.500**，而授权阈值 δ = 0.30
                                #   ⇒ 判据本该拒绝，却仍然承诺。实际失败率 0.476 / 0.591，
                                #   与"risk≈0.5 的掷硬币"完全吻合 ⇒ **风险模型是准的，
                                #   是有一个旁路绕过了它**。
                                #   旁路就是本分支：旧代码在此**无条件** `_entry_granted = True`。
                                #   ⚠ 旧注释写着"【P4-①】额外 gate：必须对最坏情况也安全"，
                                #     但代码里**从来没有这个 gate** —— 注释描述的是一个
                                #     从未实现的意图。这类"注释承诺了、代码没做"的地方
                                #     是最危险的，已按实际行为改正。
                                #
                                # ===== 【2026-10-12 修复 D3'】① 的授权 = 显式三态 =====
                                #   修复前的实现 `(not risk_only_gate) or bool(_gap_ok)` 位于
                                #   `if _gap_ok:` 的 **else 分支内** ⇒ `_gap_ok` 恒为 False
                                #   ⇒ 默认配置下 `_risk_gate_ok` **恒 False**
                                #   ⇒ 唯一能授权①的分支**不可达** ⇒ **① 对决策影响为 0**
                                #     （实证：`DSH_TAKE_COURNOT=0/1` 的 `action` 列完全相同）。
                                #   解析逻辑抽成**纯函数** `resolve_cournot_gate`（可单测）：
                                #   它区分 `_gap_ok=False` 的两种成因（风险值超限 vs 仅稳定性未达），
                                #   口径用 `DSH_COURNOT_AUTHORITY` 切换（gate/risk/game）。
                                _risk_gate_ok, _cg_reason, _risk_value_ok = resolve_cournot_gate(
                                    self.risk_only_gate, self.cournot_authority,
                                    self._last_commit_risk,
                                    getattr(self, '_last_commit_risk_fresh', False),
                                    self.cournot_risk_max)
                                if self.game_config['mpc']:
                                    # Continuous utility acts in the optimizer; it does
                                    # not bypass the shared entry-risk authorization.
                                    _risk_gate_ok, _cg_reason = False, 'mpc_entry_gate'
                                self._last_cournot_gate_reason = _cg_reason
                                self._last_risk_value_ok = _risk_value_ok
                                # 【§75 诊断】记录 Cournot 的意见与被风险门挡住与否
                                self._last_take_cournot = bool(_take_cournot)
                                self._last_risk_gate_ok = bool(_risk_gate_ok)
                                if _take_cournot and _cd['ego_go'] and _risk_gate_ok:
                                    # 博弈判走，但**必须同时通过占用窗/机会约束风险门**
                                    v_ref = max(v_ref, _go_speed)
                                    self._yield_was_stopped = False
                                    _entry_granted = True
                                elif _take_cournot and _cd['ego_go'] and (not _risk_gate_ok):
                                    # 博弈想走但风险不许 ⇒ 停在带外等（并显形计数）
                                    self._yield_was_stopped = True
                                    self._risk_blocked_num = getattr(self, '_risk_blocked_num', 0) + 1
                                    v_ref = 0.0
                                else:
                                    # 博弈判停（RV 抢行风险 > 等待代价）
                                    self._yield_was_stopped = True
                                    # ===== 【防卡死】默认关闭（DSH_ANTISTUCK=0）=====
                                    # 实测：开启"蠕动到停止线"会让 ego 进入 arc<=stop_arc+0.5 的
                                    # "强制提速清空"区 → 直接冲进车流 → 碰撞率 33.7%→96.3%。
                                    # 即：卡死其实是当前"强制清空"设计的**保护伞**。保留为实验开关。
                                    # 【§61】防卡死的超时放行也必须过风险门，否则它又是一个旁路
                                    if self.antistuck and self._stopped_frames >= self.wait_timeout_frames \
                                            and _risk_gate_ok:
                                        v_ref = max(v_ref, _go_speed)
                                        self._yield_was_stopped = False
                                        _entry_granted = True
                                    elif self.antistuck and _arc > _stop_arc + 1.0:
                                        v_ref = max(v_ref, self.creep_speed)
                                    else:
                                        v_ref = 0.0
                        else:
                            # 刹不住且未到停止线 → 尽快通过清空（避免停在冲突区内，与后车拉开）
                            v_ref = max(v_ref, _go_speed)
                            self._yield_was_stopped = False
                            _entry_granted = True
                    else:
                        # 间隙已打开 / 已越过冲突点
                        # 【碰撞修复】仍在冲突区附近（arc 尚小）→ 强制提速清空：
                        # 否则 RL 学到低速档后，自车过点后蠕动穿过交叉口被撞。
                        if _arc <= _stop_arc + 3.0:
                            v_ref = max(v_ref, _go_speed)
                        elif getattr(self, '_yield_was_stopped', False):
                            v_ref = max(v_ref, _speed_limit_ramp)
                            self._yield_was_stopped = False

                    # ===== 【创新点④·P3b】停止线纪律：安全回退位（速度剖面，不是硬 clamp）=====
                    #  实测（expL_p3_20）：自车停在 `arc≈10.22 m` 时车头 y≈−137.0 ——
                    #  **正好压在交叉车体带 [−139,−137] 边界上**（4 个采样 2 个已侵入），
                    #  RV 擦过去就撞。即"停在哪里"本身错了，不是"停不停"的问题。
                    #
                    #  ⚠ 关键教训：第一版我写的是 `v_ref = 0.0` 硬 clamp，结果 **expM 与 expL
                    #  的逐帧统计完全一样（低速帧 1246、侵入 1080、碰撞机制分布一致）** ——
                    #  因为那些帧本来就已经被判停、v_ref 已是 0，clamp 只是重复赋值。
                    #  **clamp 只能阻止继续前进，不能把车"退回来"**：车停在 10.22 是因为
                    #  判停发生得太晚。正确做法是给一条**提前减速的速度剖面**，让自车在
                    #  hold_arc 处自然停住：v_max = sqrt(2·a·(arc − hold_arc))。
                    #  `arc → hold_arc` 时 v_max → 0，于是自车停稳在回退位而不是滚到车道边。
                    self._hold_frames = 0
                    # ===== 【S4-probe】验证 di≠0 的轨迹几何（只测量、不改行为，每回合最多一次）=====
                    #   动机：S4 要把横向偏移 di 接成动作维度，但此前只验证过 di=0（几何 5cm 良好）。
                    #   若 di≠0 生成的路口段轨迹本身就畸形/自交/跑到路外，S4 就是建在坏路径上。
                    #   探测点必须落在**路口段**（首次决策在 arc≈43m 的直线段，测不到转弯几何），
                    #   故加条件 arc <= DSH_S4_PROBE_ARC（默认 12 m）。
                    if os.environ.get('DSH_S4_PROBE', '1') == '1' \
                            and float(_conf.get('arc_to_cross', 99.0)) <= float(os.environ.get('DSH_S4_PROBE_ARC', '12.0')) \
                            and getattr(self, '_s4_probed_ep', None) != evaluate_number:
                        try:
                            _fl0 = (getattr(self.lane_trajectory_planner, 'frenet_lanes', None) or [None])[0]
                            if _fl0 is not None:
                                _probe = {'episode': evaluate_number,
                                          'v_ref': float(v_ref),
                                          'arc': float(_conf.get('arc_to_cross', 0.0)),
                                          'di': {}}
                                for _d in (-1.5, 0.0, 1.5):
                                    try:
                                        _fp = _fl0._generate_speed_trajectory(
                                            self.dynamic_map, float(v_ref), di=float(_d))
                                        if _fp is None or not getattr(_fp, 'x', None):
                                            _probe['di'][str(_d)] = None
                                        else:
                                            _probe['di'][str(_d)] = np.stack(
                                                [np.asarray(_fp.x, dtype=float),
                                                 np.asarray(_fp.y, dtype=float)], axis=1)
                                    except Exception as _ee:
                                        _probe['di'][str(_d)] = {'error': f'{type(_ee).__name__}: {_ee}'}
                                self._s4_probed_ep = evaluate_number
                                with open(os.path.join(MODEL_DIR, 's4_probe.pkl'), 'wb') as _f:
                                    pickle.dump(_probe, _f)
                                print(f"[S4-probe] ep{evaluate_number} 已生成 di=-1.5/0/+1.5 三条轨迹"
                                      f"（v_ref={float(v_ref):.2f}, arc={_probe['arc']:.2f}）")
                        except Exception as _e:
                            print(f'[S4-probe] 失败（不影响训练）: {type(_e).__name__}: {_e}')
                    self._last_entry_granted = bool(_entry_granted)

                    # ===== 【S6-②】把动作的**纵向**语义接回控制器（默认关，DSH_ACTION_VREF=1 开）=====
                    #  实测（expNN_vref3，315 帧，纯观测）：
                    #    · 动作明确要求停车（action_speed==0）的帧占 **232/315 = 74%**
                    #    · 这些帧实际下发的 v_ref 中位 = **4.15 m/s**（最小 4.00）
                    #    · 对**每一个**动作速度档，`|v_ref − action_speed| ≤ 0.01` 的帧占比 = **0.0%**
                    #    · v_ref **从未**低于 4.00 m/s（也从未低于 1.5 / 0.5）
                    #    · `v_ref_before_floor < 3.0` 的帧 = **0/315**（说明上游就已抬高，
                    #      `max(v_ref,3.0)` 根本不是约束边界）
                    #  ⇒ 纵向通道与动作空间**断路**：{0,1,2}(v=0) 与 {3,4,5}(v=2) 在控制上
                    #    与 v=4 无区别。成因是 6 处以 `v_ref = max(v_ref, _go_speed)` 施加"放行"，
                    #    而 `_go_speed = max(4.0, _speed_limit_ramp)` ≥ 4.0 —— `max` 只能抬高，
                    #    于是 ④ 屏蔽、action_speed、let-ego-brake 全部被静默覆盖。
                    #  这解释了为什么 12 动作只在 100 回合上从 23%→28%：新增的纵向分辨率是死的；
                    #  也解释了为什么**每一次**碰撞都发生在 ego_v≈2.8 m/s 且动作要求 0。
                    #
                    #  设计：**动作是纵向权威**，场景逻辑只能让它更慢、不能更快（入口逻辑的
                    #  "抬高"被丢弃）。唯一例外是"已在冲突区内"（arc ≤ stop_arc+0.5）——
                    #  停在路口中央是被实测证明的碰撞根因，那时仍强制清空。
                    #  默认 0 = 保持历史行为，便于干净 A/B。
                    # （`_in_entry_regime` / `_entry_auth` 已在入口决策之前定义，见顺序修复）
                    # 【S13】逐速度档证明间隙：对每个候选速度档分别用该档的占用窗检验，
                    #   取**能塞进间隙的最快档**，并让执行速度 == 证明速度。
                    #   动机：`expZZ` 用单一 `_go_speed` 硬判据拿到碰撞 5% 但卡死 85% ——
                    #   因为"占用窗与任何来车都不重叠"在密集车流下几乎永不成立。
                    #   而自车的占用窗**取决于它自己的速度**（走快 → 窗短）⇒ 逐档检验
                    #   才能既保持"未证明安全就不进入"的不变量，又找到快速穿过的机会。
                    # （`_per_speed` 已提前定义）
                    if os.environ.get('DSH_ACTION_VREF', '0') == '1' \
                            and not (_entry_auth and _in_entry_regime) \
                            and hybrid_action is not None and ACTION_MODE in ('2d', 'speed'):
                        try:
                            _v_cmd = float(action_speed(hybrid_action))
                            _in_zone = bool(_conf['committed']) or \
                                (float(_conf.get('arc_to_cross', 99.0)) <= _stop_arc + 0.5)
                            if not _in_zone and _v_cmd < v_ref:
                                v_ref = _v_cmd
                        except Exception:
                            pass

                    # 【S7-②】等待位：几何反推（每回合缓存一次；失败则回退 hold_arc）
                    _hold_arc_now = self.hold_arc
                    if self.wait_arc_geo:
                        if getattr(self, '_wait_arc_ep', None) != evaluate_number:
                            self._wait_arc_ep = evaluate_number
                            self._wait_arc_val = None
                            try:
                                _rp = _get_ref_path_array(self.dynamic_map)
                                _cy = float(_conf.get('conflict_y', -138.0))
                                _el = float(getattr(self.dynamic_map.ego_vehicle, 'length', 4.5) or 4.5)
                                self._wait_arc_val = safe_wait_arc(
                                    _rp, _cy, ego_len=_el,
                                    band_half=BAND_HALF_DEFAULT,
                                    margin=self.wait_margin)
                            except Exception:
                                self._wait_arc_val = None
                        if self._wait_arc_val:
                            _hold_arc_now = float(self._wait_arc_val)

                    # 【S7-③】位置硬钳制：用自车矩形在 y 向的**净距**判停（含横向偏移与航向），
                    #   而不是"参考路径投影弧长 + 车长/2"。
                    #   动机（实测）：26 次碰撞里撞自车的车**恒在 y=−138.00**（交叉车流中心线），
                    #   自车 ego_y≈−134.70 ⇒ 车头 −136.95，交叉车半宽 1.0 ⇒ 带近边 −137.00，
                    #   侵入仅 0.05 m —— 车是"停在带边线上、车头贴着过路车"，不是停错宏观位置。
                    #   旧式两个漏洞：(a) 忽略 lat_dev≈1.5 m ⇒ 角点比"投影+车长/2"更靠前；
                    #   (b) 只限速不钳位 ⇒ 允许蠕动着越过等待位。
                    _sd = None
                    if self.wait_clamp:
                        try:
                            _ev = self.dynamic_map.ego_vehicle
                            _sd = wait_standoff(
                                float(_ev.x), float(_ev.y), float(getattr(_ev, 'yaw', 0.0)),
                                float(getattr(_ev, 'length', 4.5) or 4.5),
                                float(getattr(_ev, 'width', 2.0) or 2.0),
                                float(_conf.get('conflict_y', -138.0)), BAND_HALF_DEFAULT)
                        except Exception:
                            _sd = None
                    self._last_wait_standoff = _sd

                    # ===== 【S8】纵向权威归并（DSH_ENTRY_AUTH=1，默认 0）=====
                    #  实测定位（expTT_clamp20）：位置硬钳制没用（净距中位 −0.048 → −0.142 m），
                    #  因为 `_entry_granted=True` 时整个 hold 块被跳过。而 VREF=1 之后动作会把
                    #  速度压到 0.1~2 m/s ⇒ 致命组合：
                    #    **入口判据按 `_go_speed(≥4 m/s)` 算出"间隙安全、获准通过"，
                    #      但执行时动作只给 0.1 m/s** ⇒ 12 m 的穿越从 3 s 变成 120 s，
                    #      判据前提被作废，车滞留在交叉带边线上被刮。
                    #  ⇒ 根本问题是存在两个纵向权威（入口判据 vs 动作/IDM）。归并规则：
                    #    · 入口窗口内 + 获准 → **必须真的按 `_go_speed` 通过**（动作不得压低）
                    #    · 入口窗口内 + 未获准 → `v_ref=0`，并由 S7-③ 的净距钳制保证停在带外
                    #    · 窗口外（已 committed / 无车）→ 仍由动作主导（S6-② 生效）
                    #  这正是论文 §IV "conservative deterministic strategy" 的形态：
                    #  要么承诺清空、要么停在带外，不允许"半只脚踩在带里"。
                    if _entry_auth and (not _per_speed) and _in_entry_regime and ACTION_MODE in ('2d', 'speed'):
                        if _entry_granted:
                            v_ref = max(v_ref, _go_speed)
                        else:
                            v_ref = 0.0

                    # ===== 【3.1 / C2】等待位置纪律：**无条件**的"带外"不变量 =====
                    #  实测（PLAN §6/§43.5）：碰撞与卡死**同源** —— 自车都停在 arc≈12.26 m
                    #  （= 冲突带边缘），停住不动→卡死，过路车擦过→碰撞；
                    #  88%（37/42）的碰撞由 ④ 屏蔽主导、committed=0、lcttc≈0.01
                    #  ⇒ 碰撞不是"冲进车流"，而是"**在等待位置上被撞**"。
                    #
                    #  为什么之前的 `hold` 块治不了：它的条件是 `not _entry_granted`，
                    #  而实测这些帧 `_entry_granted=True`（入口判据放行了）⇒ hold 被跳过，
                    #  ④ 屏蔽把 v_ref 压到 0，车就**停在哪儿算哪儿**，没有任何位置纪律。
                    #
                    #  这里的纪律是论文 §IV「保守确定性策略」的形态：
                    #    **要么以足够速度承诺清空，要么整车停在冲突带之外** —— 不允许"半只脚在带里"。
                    #  用 **y 域净距**（`wait_standoff`，含横向偏移与航向的真实位姿）而不是弧长域：
                    #  实测等待时 lat_dev≈1.5–2 m，弧长投影会把车头算乐观（PLAN §24/§42）。
                    _clamp_stopped = False
                    # 【§56】`_committing` 必须在 C2 块**之前**初始化：C2 在
                    # `wait_clamp=0` 或 `_sd2 is None` 时不会给它赋值，而下面的
                    # `hold` 块要用它做条件 ⇒ 不初始化会 `UnboundLocalError`。
                    _committing = False
                    _ego_len_ref = float(getattr(self.dynamic_map.ego_vehicle, 'length', 4.5) or 4.5)
                    if self.wait_clamp and (not _conf['committed']):
                        try:
                            _ev2 = self.dynamic_map.ego_vehicle
                            _sd2 = wait_standoff(
                                float(_ev2.x), float(_ev2.y), float(getattr(_ev2, 'yaw', 0.0)),
                                float(getattr(_ev2, 'length', 4.5) or 4.5),
                                float(getattr(_ev2, 'width', 2.0) or 2.0),
                                float(_conf.get('conflict_y', -138.0)), BAND_HALF_DEFAULT)
                        except Exception as _ce2:
                            _sd2 = None
                            self._clamp_err = '%s: %s' % (type(_ce2).__name__, _ce2)
                        self._last_wait_standoff = _sd2
                        if _sd2 is not None:
                            _v_now2 = max(float(getattr(self.dynamic_map.ego_vehicle, 'v', 0.0)), 0.0)
                            # 【§51.4 死锁修复】授权 ⇒ 必须是**发车指令**，不能只是"不拦"。
                            #   旧式：`_committing = grant and v_now >= clear_v_min`
                            #   死锁证明（实测 expS83_geo 两 seed）：
                            #     等待位 standoff≈2.2 m ⇒ 本包络只允许 ≤1.1 m/s；
                            #     而 `_committing` 需要 ≥3.0 m/s；前进只会**减少** standoff
                            #     ⇒ 永远达不到 3.0 ⇒ 永远不承诺 ⇒ 永远停着。
                            #   实测后果：82% 的帧冻在 standoff<2.5 m，该区间 ego_v_max=0.51 m/s；
                            #     `ego_v>=3.0` 只出现在 standoff>8 m 的远处（2.88% 帧）；
                            #     `committed=1` 仍为 0 帧，每回合撞满 935 帧超时。
                            #   修法：授权即"入口判据已按 clear_v_min 认证过以该速度可清空"
                            #     ⇒ 直接**命令** v_ref 抬到 clear_v_min 并提交。
                            #   为什么这样做是安全的：授权本身已由 `entry_clearance_time`/
                            #     `can_clear_safely` 认证（间隙足以清空），且 ④ 边界屏蔽仍在守。
                            # 【§53 闩锁 v2】修掉 v1 的两个缺陷：
                            #   缺陷1【锁得太早】v1 只要 `entry_granted` 就锁 ⇒ 实测
                            #     `committing=1` 占 **100% 帧**（从第 1 帧锁到回合结束），
                            #     等于一上来就把等待纪律**永久关闭** ⇒ LATCH_ON 与
                            #     GATE_OFF 结果逐帧相同。
                            #     ⇒ 只在**决策区**内（车头接近到禁令线附近）才允许锁定。
                            #   缺陷2【永不解锁】v1 只在 `conf['committed']` 时释放，而它
                            #     实测恒为 0 ⇒ 永不释放。
                            #     ⇒ 增加两个真能触发的释放条件：
                            #        (a) 车头**已完全越过**交叉带（车尾也过）⇒ 本次进入结束；
                            #        (b) 锁定时长超限（卡死）⇒ 强制解锁并交回等待纪律。
                            if self.commit_latch:
                                # 【§65 关键修复】闩锁区默认放到 12 m。
                                #   BUG 实测（expS64_B_ON）：授权帧 1689 帧，其 `wait_standoff`
                                #   全在 **3.68~13.93 m**（中位 6.68），而旧闩锁区要求
                                #   `standoff ≤ wait_margin+1.0 = 3.0` ⇒ **交集为空**
                                #   ⇒ `commit_latched=1` 出现 **0 帧** ⇒ 引擎从不启动 ⇒ 卡死。
                                #   为什么"远处授权"是**自洽**的：授权时判据已用
                                #   `t_ego_go`（**从当前位置**到带边缘的时间）算了完整占用窗
                                #   `[t_ego_go, t_ego_go+clr_go]`，即它已经认证了
                                #   "从 6.7 m 处出发也能安全穿越"。旧的距离条件等于
                                #   把判据自己的结论作废 ⇒ 逻辑矛盾。
                                #   防"锁死不放"由下面的三个释放条件负责（越过冲突点 /
                                #   完全穿出 / 超时 `latch_max_frames`），不需要距离条件。
                                _latch_zone = self.latch_zone
                                if (not self._commit_latched) and _entry_granted \
                                        and _sd2 is not None and _sd2 <= _latch_zone:
                                    self._commit_latched = True
                                    self._latch_age = 0
                                    self._latch_num = getattr(self, '_latch_num', 0) + 1
                                if self._commit_latched:
                                    self._latch_age = getattr(self, '_latch_age', 0) + 1
                                _cleared = (_sd2 is not None
                                            and _sd2 < -(_ego_len_ref + 2.0 * BAND_HALF_DEFAULT))
                                # 【§66 安全中止】授权已被撤销、而自车**仍在带外**
                                #   （`standoff > wait_margin`）⇒ 允许放弃本次承诺、交回等待纪律。
                                #   为什么必须这样（实测 expS65_LATCH12）：
                                #     9 次碰撞**全部**是"承诺后开进带内、风险升到 1.0、但闩锁
                                #     禁止中止"（碰撞帧 standoff −0.05~−1.27、risk=1.000、
                                #     committing=1）。而 §65 把闩锁区放到 12 m 后，自车会在
                                #     12 m 外就锁死 ⇒ **在还能安全停下的地方也不许停**。
                                #   原则：承诺只在"**无法安全中止**"的位置（带内/禁止线内）
                                #     才应不可撤销；带外应当可中止。
                                _abort_ok = (_sd2 is not None) and (_sd2 > self.wait_margin)
                                # 【§66b 滞回】中止必须**只在风险明显恶化**时触发，不能跟着抖动走。
                                #   实测 expS66_ABORT_ON（无滞回）：卡死 94%、成功 **0%**
                                #   —— 授权在 0.30 附近上下抖动 ⇒ 自车反复"承诺→中止→被钳位停住"
                                #   ⇒ 永远走不完。滞回带：承诺在 risk ≤ `risk_max`(0.30) 触发，
                                #   中止只在 risk > `abort_risk`(0.55) 时触发 ⇒ 小幅波动不中止。
                                _rk_now = (self._last_commit_risk
                                           if self._last_commit_risk is not None else 0.0)
                                _aborted = bool(self.commit_abort and self._commit_latched
                                                and (not _entry_granted) and _abort_ok
                                                and (float(_rk_now) > self.abort_risk))
                                if _aborted:
                                    self._abort_num = getattr(self, '_abort_num', 0) + 1
                                if _conf.get('committed') or _cleared or _aborted \
                                        or getattr(self, '_latch_age', 0) > self.latch_max_frames:
                                    if self._commit_latched:
                                        self._latch_release_num = getattr(self, '_latch_release_num', 0) + 1
                                    self._commit_latched = False
                                    self._latch_age = 0
                                _commit_now = bool(self._commit_latched)
                            else:
                                _commit_now = bool(_entry_granted)
                            self._last_commit_latched = bool(self._commit_latched)
                            _committing = _commit_now and bool(self.commit_launch)
                            if _committing:
                                v_ref = max(float(v_ref), float(self.clear_v_min))
                            self._last_committing = bool(_committing)
                            if _sd2 <= self.wait_margin and not _committing:
                                # 已在禁令区且未承诺清空 ⇒ 强制停（至少不再继续前进）
                                v_ref = 0.0
                                _clamp_stopped = True
                                self._clamp_stop_num = getattr(self, '_clamp_stop_num', 0) + 1
                            if _sd2 <= 0.0:
                                # 【§51.3】车头**已进入**交叉带 ⇒ 计数显形（不再静默）
                                self._wait_overshoot_num = getattr(self, '_wait_overshoot_num', 0) + 1
                            if _sd2 > self.wait_margin and not _committing:
                                # 尚未到禁令线 ⇒ 给速度剖面，保证能在禁令线前停住。
                                # 【§51.4】必须加 `not _committing`：否则已承诺清空时
                                #   仍被压到 ≤1.76 m/s（standoff=2 m），发车指令被自己撤销。
                                # 【§51.3】改用**滞后感知**包络（含 v·dt_lag），
                                #   旧式 sqrt(2·a·slack) 低估制动距离 ⇒ 超调 1.7~2.2 m。
                                _v_stop2 = self._speed_for_slack(_sd2 - self.wait_margin, _a_brake)
                                if v_ref > _v_stop2:
                                    v_ref = _v_stop2
                    self._last_clamp_stopped = bool(_clamp_stopped)

                    # 【§56 关键修复】`hold` 块必须尊重"承诺"状态。
                    #   BUG 实测（expS88_CX4，conflict_x 已修正）：
                    #     授权 15.9% / 承诺 42.2% / **承诺帧内 `v_ref_before_floor`=4.04
                    #     但 `v_ref`=0.15、`ego_v` 中位 0.00、`band_entry_x` 无记录**。
                    #   因果链：
                    #     ① 授权 ⇒ 闩锁置位 ⇒ C2 把 v_ref 抬到 clear_v_min(3.0)；
                    #     ② 下一帧授权被撤销 ⇒ 闩锁让 `_committing=1`（C2 跳过钳位）；
                    #     ③ 但本块条件是 `not _entry_granted` ⇒ **变真** ⇒ 触发
                    #        ⇒ `_sd <= wait_margin` ⇒ **v_ref = 0**
                    #        ⇒ **发车指令被本块撤销** ⇒ 自车"承诺着却永远不走"
                    #        ⇒ 碰撞 0%、卡死 100%。
                    #   这解释了为什么"碰撞归零"其实是又一次退化解：
                    #     不是"安全地等待"，而是"被两个互不知情的机制锁死在原地"。
                    if (self.hold_enable and (not _conf['committed'])
                            and (not _entry_granted)
                            and (not _committing)
                            and _conf.get('n_vehicles', 0) > 0
                            and _arc > _stop_arc + 0.5):
                        if _sd is not None:
                            # ---- y 域净距钳制（S7-③）----
                            _m = self.wait_margin
                            if _sd <= _m:
                                if v_ref > 0.0:
                                    v_ref = 0.0
                                self._yield_was_stopped = True
                                self._hold_frames = getattr(self, '_hold_frames', 0) + 1
                                if _sd < 0.0:
                                    self._wait_overshoot_num = getattr(self, '_wait_overshoot_num', 0) + 1
                            else:
                                # 【§51.3】同样换成滞后感知包络，两处口径必须一致
                                _v_stop = self._speed_for_slack(_sd - _m, _a_brake)
                                if v_ref > _v_stop:
                                    v_ref = _v_stop
                                    self._hold_frames = getattr(self, '_hold_frames', 0) + 1
                                    if v_ref <= 0.01:
                                        self._yield_was_stopped = True
                        elif _arc <= _hold_arc_now:
                            # 已到/越过回退位且未获准 → 必须停住
                            if v_ref > 0.0:
                                v_ref = 0.0
                            self._yield_was_stopped = True
                            self._hold_frames = getattr(self, '_hold_frames', 0) + 1
                        else:
                            # 尚未到回退位 → 限制速度，保证能在回退位前刹停
                            _v_stop = self._speed_for_slack(_arc - _hold_arc_now, _a_brake)
                            if v_ref > _v_stop:
                                v_ref = _v_stop
                                self._hold_frames = getattr(self, '_hold_frames', 0) + 1
                                if v_ref <= 0.01:
                                    self._yield_was_stopped = True

                    # 所有策略/博弈速度抬升之后，落实规划器的停车、恢复限速与目标终点。
                _v_ref_before_guard = float(v_ref)
                v_ref, _execution_reason, _goal_remaining = execution_speed(
                    v_ref, used_trajectory, float(self.dynamic_map.ego_vehicle.x),
                    float(self.dynamic_map.ego_vehicle.y), getattr(self.env, 'goal_pose', None))
                _mpc_recovery = mpc_controller.geometry_source in ('road_recovery', 'cached')
                if _mpc_recovery and v_ref > 2.:
                    v_ref = 2.
                    _execution_reason = (_execution_reason + ';mpc_geometry_limit').strip(';')
                if mpc_controller.geometry_force_stop:
                    v_ref = 0.
                    _execution_reason = (_execution_reason + ';mpc_geometry_stop').strip(';')
                _planner_forced = _mpc_recovery or bool(mpc_controller.geometry_force_stop) or bool(
                    getattr(used_trajectory, 'force_stop', False)) or (
                    getattr(used_trajectory, 'planning_status', 'normal') == 'road_recovery')
                if self.paper_control and not self.turn_feasibility.last.get('safe', False):
                    _planner_forced = True
                _probe_phase = ''
                if control_probe is not None:
                    _probe_phase = control_probe.phase
                    v_ref = control_probe.target(v_ref)
                    if v_ref <= .01:
                        _planner_forced = True
                        _execution_reason = (_execution_reason+';control_probe_'+_probe_phase).strip(';')
                elif self.control_profile == 'paper_v8' and os.environ.get('DSH_CONTROL_PROBE') == '1':
                    _probe_phase = 'cruise'
                    if 100 <= frame_id < 140:
                        _probe_phase, v_ref, _planner_forced = 'stop', 0., True
                        _execution_reason = (_execution_reason+';control_probe_stop').strip(';')
                    elif 140 <= frame_id < 200:
                        _probe_phase = 'recovery'

                # 【防卡死】等待计数器：本帧最终判停 → 累计；判走 → 清零
                if v_ref <= 0.01:
                    self._stopped_frames += 1
                else:
                    self._stopped_frames = 0

                # 【S6-① 观测】最终下发给 MPC 的纵向目标速度（含所有 floor/hold 之后）
                self._last_v_ref = float(v_ref)
                self._last_v_ref_pre_floor = float(_v_ref_pre_floor)
                self._last_rl_speed_cap = _rl_speed_cap
                self._last_action_speed = float(action_speed(hybrid_action)) \
                    if hybrid_action is not None else None

                _previous_control = dict(mpc_controller.last_u)
                _previous_observed_speed = getattr(mpc_controller, '_previous_observed_speed', None)
                if matrix_game is not None:
                    _matrix_rv, _matrix_targets = matrix_game.prepare(self.dynamic_map.ego_vehicle,
                        self.dynamic_map.objects, _conf, v_ref, _sd, self.env.goal_pose)
                    _probe = getattr(self, 'trajectory_probe', None)
                    _probe_seed = _probe.capture(mpc_controller) if _probe is not None else None
                    _matrix_candidates = solve_candidates(mpc_controller, matrix_peer, self.dynamic_map,
                        _matrix_targets[1], _matrix_targets[0], road_right,
                        getattr(self.env, 'INTERSECTION_CENTER', (6., -138.)), matrix_game.last['active'])
                    _matrix_selected = matrix_game.choose(self.dynamic_map.ego_vehicle,
                        self.dynamic_map.objects, _matrix_rv, _conf, _matrix_candidates,
                        mpc_controller.last_pathway, _previous_control)
                    _matrix_solve_ms = sum(c['controller'].last_solve_ms for c in _matrix_candidates) \
                        if matrix_game.last['active'] else mpc_controller.last_solve_ms
                    if _probe is not None:
                        _matrix_candidates = _probe.propose(self.dynamic_map, _matrix_candidates,
                            _matrix_selected, matrix_game.last, _probe_seed, road_right,
                            getattr(self.env, 'INTERSECTION_CENTER', (6., -138.)))
                        _trajectory_owner = ('rolling_trajectory' if _probe.last['revision'] == 'rolling_trajectory_v24' else
                            'spatial_probe' if _probe.last['revision'] == 'spatial_probe_v23' else
                            'trajectory_evolution' if _probe.last['revision'] == 'trajectory_evolution_v22' else 'trajectory_probe')
                        matrix_game.last[_trajectory_owner] = _probe.last
                        _matrix_solve_ms += _probe.last['extra_solve_ms']
                        matrix_game.last['decision_ms'] += max(0.,
                            _probe.last['decision_ms']-_probe.last['extra_solve_ms'])
                    _choice = _matrix_candidates[_matrix_selected]
                    _matrix_entry_intent = _choice.get('entry_intent', _matrix_selected)
                    if _choice['controller'] is matrix_peer:
                        mpc_controller, matrix_peer = matrix_peer, mpc_controller
                    elif _probe is not None and _choice['controller'] is not mpc_controller:
                        mpc_controller = _probe.activate(mpc_controller, _choice['controller'])
                    a_opt, delta_opt, v_ref = _choice['a'], _choice['delta'], _choice['target']
                    mpc_controller.last_solve_ms = _matrix_solve_ms
                    _matrix_target = float(v_ref)
                    _matrix_phase = matrix_game.last['phase']
                    if matrix_game.last['active']:
                        _matrix_phase = 'entering' if _matrix_entry_intent == 1 else 'waiting'
                    self.turn_feasibility.last = dict(profile=matrix_game.revision, phase=_matrix_phase,
                        safe=True, min_gap=None, conflict_id=matrix_game.last['rv_id'],
                        body_clear=matrix_game.last['phase'] == 'merged')
                    self._last_control_gate = dict(self.turn_feasibility.last)
                    self._last_entry_granted = bool(v_ref > .01 and (
                        not matrix_game.last['active'] or _matrix_entry_intent == 1))
                    self._last_clamp_stopped = v_ref <= .01
                    self._last_committing = matrix_game.last['phase'] == 'merging'
                    self._last_commit_latched = self._commit_latched = bool(
                        self._last_entry_granted and _sd <= 12.)
                    self._last_cournot_gate_reason = 'matrix_'+_matrix_phase
                    self._last_v_ref = float(v_ref)
                else:
                    mpc_controller.set_game_context(_conf, self.dynamic_map.ego_vehicle,
                                                    entry_zone=getattr(self, 'entry_zone', 15.))
                    a_opt, delta_opt = mpc_controller.solve(self.dynamic_map, v_ref, road_right,
                                                          intersection_center=getattr(self.env, "INTERSECTION_CENTER", (6.00, -138.00)))
                _raw_mpc_a, _raw_mpc_delta = float(a_opt), float(delta_opt)
                _audit_gap, _audit_actor, _audit_override = None, None, False
                _execution_audit = None
                if self.revised_control:
                    _ego = self.dynamic_map.ego_vehicle
                    a_opt = execution_acceleration(a_opt, max(float(_ego.v), 0.), v_ref)
                    _selected, _execution_audit = select_execution(
                        _ego, self.dynamic_map.objects, mpc_controller.last_pathway,
                        v_ref, a_opt, delta_opt, _previous_control, _prediction_geometry,
                        prediction=mpc_controller.last_prediction,
                        prediction_times=mpc_controller.prediction_times,
                        plan=mpc_controller.last_control_plan, solve_ok=mpc_controller._solve_ok,
                        stop_after=(_choice.get('creep_stop_after') if matrix_game is not None else None),
                        alternative=(_matrix_candidates[1] if self.forecast_revision=='route_v18'
                            and matrix_game is not None and _matrix_entry_intent==0
                            and not (getattr(self, 'trajectory_probe', None) is not None
                                     and self.trajectory_probe.last.get('disable_foreign_clear_backup', False)) else None),
                        allow_clear=not (mpc_controller.geometry_force_stop or
                                        getattr(used_trajectory, 'force_stop', False)))
                    _path_probe = getattr(self, 'trajectory_probe', None)
                    if _path_probe is not None and hasattr(_path_probe, 'review_execution'):
                        _restored = _path_probe.review_execution(mpc_controller, _ego,
                            self.dynamic_map.objects, _previous_control, _execution_audit)
                        if _restored is not None:
                            if _restored['controller'] is matrix_peer:
                                mpc_controller, matrix_peer = matrix_peer, mpc_controller
                            else:
                                mpc_controller = _restored['controller']
                            _matrix_candidates[_matrix_selected] = _restored['candidate']
                            _raw_mpc_a = float(_restored['candidate']['a'])
                            _raw_mpc_delta = float(_restored['candidate']['delta'])
                            _matrix_target = float(_restored['candidate']['target'])
                            _selected, _execution_audit = _restored['selected'], _restored['audit']
                            if _matrix_entry_intent != _matrix_selected:
                                _matrix_entry_intent = _matrix_selected
                                self.turn_feasibility.last['phase'] = 'waiting'
                                self._last_control_gate['phase'] = 'waiting'
                                self._last_cournot_gate_reason = 'matrix_waiting'
                                self._last_entry_granted = self._last_commit_latched = self._commit_latched = False
                                self._last_clamp_stopped = _selected['target'] <= .01
                    _audit_gap, _audit_actor = _execution_audit['proposed_gap'], _selected['actor']
                    _audit_override = _execution_audit['override']
                    a_opt, delta_opt, v_ref = _selected['a'], _selected['delta'], _selected['target']
                    self._last_v_ref = float(v_ref)
                    if _audit_override or _execution_audit['unavoidable']:
                        _planner_forced = True
                        _execution_reason = (_execution_reason+';execution_'+_execution_audit['action']).strip(';')
                        self._last_control_gate.update(safe=_execution_audit['safe'],
                            min_gap=None if math.isinf(_selected['gap']) else _selected['gap'],
                            conflict_id=_selected['actor'])
                        self._last_entry_granted = bool(_execution_audit['safe'] and v_ref > .01)
                elif self.paper_control:
                    _prediction = mpc_controller.last_prediction
                    if _prediction is not None:
                        _audit_gap, _audit_actor = prediction_clearance(
                            _prediction, mpc_controller.prediction_times,
                            self.dynamic_map.objects, self.dynamic_map.ego_vehicle)
                        if not math.isfinite(_audit_gap):
                            _audit_gap = None
                    _outside = (self._last_wait_standoff > 0. and not _conf.get('committed'))
                    _unsafe_plan = _audit_gap is not None and _audit_gap < .15
                    if _outside and (_unsafe_plan or not mpc_controller._solve_ok):
                        _audit_override = True
                        _planner_forced = True
                        v_ref = self._last_v_ref = 0.
                        self._last_entry_granted = self._commit_latched = False
                        self._last_commit_latched = False
                        self.turn_feasibility.launched = False
                        self._last_control_gate.update(phase='waiting_mpc', safe=False,
                            min_gap=_audit_gap, conflict_id=_audit_actor)
                        _execution_reason = (_execution_reason+';mpc_prediction_stop').strip(';')
                        if mpc_controller._solve_ok:
                            _first_ms = mpc_controller.last_solve_ms
                            mpc_controller.last_u = dict(_previous_control)
                            mpc_controller._previous_observed_speed = _previous_observed_speed
                            a_opt, delta_opt = mpc_controller.solve(self.dynamic_map, 0., road_right,
                                intersection_center=getattr(self.env, 'INTERSECTION_CENTER', (6., -138.)))
                            mpc_controller.last_solve_ms += _first_ms
                _tracking = mpc_controller.last_tracking_state or {}
                self._last_control_diag = dict(
                    a_mpc=_raw_mpc_a, delta_mpc_rad=_raw_mpc_delta,
                    mpc_l=_tracking.get('l'), mpc_epsi=_tracking.get('epsi'),
                    mpc_solve_ok=bool(getattr(mpc_controller, '_solve_ok', False)),
                    planning_status=getattr(used_trajectory, 'planning_status', 'normal'),
                    trajectory_force_stop=bool(getattr(used_trajectory, 'force_stop', False)),
                    trajectory_speed_limit=getattr(used_trajectory, 'speed_limit', None),
                    execution_reason=_execution_reason, v_ref_before_guard=_v_ref_before_guard,
                    goal_remaining=_goal_remaining, geometry_source=mpc_controller.geometry_source,
                    a_prev=_previous_control['a'], steer_prev=_previous_control['df'],
                    game_controller=self.game_config['controller'],
                    mpc_game=dict(mpc_controller.last_game_diag),
                    stackelberg_active=_stackelberg_active,
                    control_profile=self.control_profile,
                    control_probe_phase=_probe_phase,
                    feasibility=getattr(self, '_last_control_gate', {}),
                    prediction_horizon=float(mpc_controller.prediction_times[-1]))
                self._last_control_diag['mpc_solve_ms'] = getattr(mpc_controller, 'last_solve_ms', None)
                self._last_control_diag.update(mpc_audit_gap=_audit_gap,
                    mpc_audit_actor=_audit_actor, mpc_audit_override=_audit_override,
                    execution_audit=_execution_audit,
                    mpc_solver_status=mpc_controller.last_solver_status,
                    mpc_failure_snapshot=mpc_controller.last_failure_snapshot)

                # ===== 控制饱和率埋点（对齐论文 Table II/III / Fig.5）=====
                # solve() 返回带符号加速度 (m/s²) 和前轮转角 (rad)。
                _a_cmd = float(getattr(mpc_controller, 'last_a_cmd', 0.0))
                _d_cmd = float(getattr(mpc_controller, 'last_delta_cmd', delta_opt))
                if _a_cmd <= self._mpc_a_min or _a_cmd >= self._mpc_a_max:
                    self._long_sat_num += 1
                if abs(_d_cmd) >= self._mpc_max_steer:
                    self._lat_sat_num += 1
                self._ctl_frames += 1
                # MPC 求解失败统计（失败时走 P1 回退；用于量化控制器健康度）
                if not getattr(mpc_controller, '_solve_ok', True):
                    self._mpc_fail_num += 1

                # ===== 【P0 修复】速度反馈限速器：MPC 加速度(m/s²)被 env 直接当 throttle/brake 用（单位不匹配），
                # 真实车响应远超 MPC 模型 → 车速冲到 11~12 m/s（>v_ref 且 >v_max=10）→ 进弯必然约束不可行。
                # 此处强制：超 v_ref 禁止再加速，严重超速强制制动，保证真实车速贴着 v_ref 走。
                _cur_v = max(float(self.dynamic_map.ego_vehicle.v), 0.0)
                a_opt = execution_acceleration(a_opt, _cur_v, v_ref)

                action = [a_opt, delta_opt]

                if self.revised_control:
                    new_obs, reward, done, new_obs_ori = self.env.step(action, game_fall=game_fall,
                                                                     target_speed=v_ref)
                else:
                    new_obs, reward, done, new_obs_ori = self.env.step(action, game_fall=game_fall)
                frame_id += 1
                self._last_control_diag.update(getattr(self.env, 'last_control', {}))
                if control_probe is not None:
                    _phase_seconds = control_probe.phase_elapsed+control_probe.dt
                    control_probe.observe(float(self.env.last_control['ego_v_after']))
                    self._last_control_diag.update(control_probe_phase_seconds=_phase_seconds,
                        control_probe_failure=control_probe.failure)
                _applied = self.env.last_control
                if _forecast_recorder is not None:
                    _forecast_recorder.record(self.ilog.episode, self.ilog.frame, _execution_audit, _applied)
                self.control_experiment.record(self.ilog.episode, self.ilog.frame,
                    mpc_controller, _execution_audit, _applied, self.dynamic_map.ego_vehicle,
                    _advance_entry_called if self.paper_control else False,
                    selected=_matrix_selected if matrix_game is not None else None,
                    active=matrix_game.last['active'] if matrix_game is not None else False)
                mpc_controller.acknowledge_applied_control(_applied['a_cmd'],
                    _applied['delta_rad'] if self.revised_control else _applied['steer'])
                if matrix_peer is not None:
                    matrix_peer.acknowledge_applied_control(_applied['a_cmd'], _applied['delta_rad'])
                    if getattr(self, 'trajectory_probe', None) is not None:
                        self.trajectory_probe.acknowledge(_applied['a_cmd'], _applied['delta_rad'])
                        if hasattr(self.trajectory_probe, 'feedback'):
                            _evolution_outcome = (('collision' if self.env.ego_vehicle_collision_sign else
                                'complete' if self.env._turn_complete() else 'stuck') if done else None)
                            self.trajectory_probe.feedback(self.ilog.episode, self.ilog.frame,
                                _execution_audit, _applied, _evolution_outcome)
                    if self.candidate_learning:
                        _candidate_outcome = (('collision' if self.env.ego_vehicle_collision_sign else
                            'complete' if self.env._turn_complete() else 'stuck') if done else None)
                        matrix_game.feedback(self.ilog.episode, self.ilog.frame,
                            _execution_audit, _applied, outcome=_candidate_outcome)
                    matrix_game.record(self.ilog.episode, self.ilog.frame,
                        _raw_mpc_a, _raw_mpc_delta, _matrix_target, _execution_audit, _applied)
                if self.belief_learner is not None:
                    self._last_control_diag['learning'] = dict(self.belief_learner.last,
                        belief_rv_id=self._belief_actor, belief_entropy=self.belief_tracker.entropy(),
                        belief_evidence=self.belief_tracker.last_evidence,
                        learning_reward_mode=self.belief_reward_mode,
                        efe_learning_reward=(self._belief_learning_reward(0., hybrid_action)
                            if self.belief_reward_mode == 'negative_efe' else None),
                        learning_decision=bool(_new_trajectory),
                        behavior_model_valid=bool(not (_planner_forced or _shield_override or
                            self.belief_learner.pending['forced']) and
                            self.belief_learner.last.get('behavior_model_valid', False)))
                    if not self._last_control_diag['learning']['behavior_model_valid']:
                        self._last_control_diag['learning']['information_cost'] = None
                        self._last_control_diag['learning']['behavior_policy'] = None

                # ===== P0: 因果奖励（RL 动作的真实回报，与 MPC/规则解耦）=====
                terminal_reward = 0.0
                if done:
                    # 【P4-③ 修复】终局项 × DSH_TERMINAL_SCALE（默认 10）。
                    #   bug：实测 reward-to-go 的 G 范围约 ±20000（稠密项积分），而碰撞罚只有
                    #        −300 ⇒ **碰撞代价仅占整回合回报的 2~5%**，智能体几乎没有避撞动机。
                    #        结构原因：论文式68 本身没有碰撞罚项，只有式64 的完成奖励 140；
                    #        换道场景回合短、量级小，搬到"200 帧 + 频繁冲突"后终局信号被淹没。
                    #   修法：只放大终局项（保持 −300:150:−100 = −3:1.5:−1 比例不变），
                    #        使终局占信号 ~20~50%。DSH_TERMINAL_SCALE=1.0 回退做消融。
                    if getattr(self.env, 'ego_vehicle_collision_sign', False):
                        terminal_reward = -300.0
                    elif self.env._turn_complete():
                        # 【式(64)】完成奖励改由论文的 `game_reward(complete=True)=140` 承担，
                        #   此处置 0 以免双重计数（旧行为 +150×terminal_scale 与论文 140 不符）。
                        #   `DSH_RGAME_COMPLETE=0` 时回退到旧的 +150。
                        terminal_reward = 0.0 if bool(getattr(self, 'rgame_complete', True)) else 150.0
                    else:
                        terminal_reward = -100.0   # 卡死/超时
                    terminal_reward *= float(getattr(self, 'terminal_scale', 1.0))
                # RL 激活只决定选动作与写库资格，不能改变整回合的奖励定义。
                # 原 else 使用环境奖励，并跳过 ego 日志/完成奖励，导致比较口径随阶段切换。
                self._last_rl_active = bool(rl_active)
                self._cur_rule_action = int(rule_action)
                _turn_done = bool(self.env.ego_vehicle_collision_sign is False
                                  and getattr(self.env, '_turn_complete', lambda: False)())
                if os.environ.get('DSH_FORCE_COMPLETE', '0') == '1' and done:
                    _turn_done = True
                causal_r = self.compute_causal_reward(
                    self.dynamic_map, self.env, hybrid_action, used_trajectory,
                    last_rl_action=last_rl_action_in_window, terminal_reward=terminal_reward,
                    turn_completed=_turn_done,
                    efe_ambiguity=_efe_amb if (rl_active or self.belief_learner is not None) else None)
                if self.belief_learner is not None:
                    _learning_r = self._belief_learning_reward(causal_r, hybrid_action)
                    self.belief_learner.record_reward(_learning_r,
                                                     forced=_planner_forced or _shield_override)

                traj_passed_data.append([traj_rtree_obs, env_sign, causal_r])
                lane_passed_data.append([lane_rtree_obs, lane_sign, causal_r])
                rewards.append(reward)
                causal_rewards.append(causal_r)
                # 【论文式58/59】回合级缓冲（不再逐 20 帧写库）：回合末统一按 reward-to-go 写
                # 【S5-①】多存一个"本帧动作是否被 ④ 屏蔽强制改写"的标志。
                #   实测 expKK_2d_100：12 动作里 `action 0` 占 55% 的样本，而 ④ 屏蔽在
                #   46% 的帧里**强制** action 0 ⇒ 这些帧被当成"策略选择了 action 0"写进
                #   价值数据集，**污染 Q(s,0) 并挤掉其它 11 个动作的样本**（动作 2/5 零样本）。
                #   屏蔽强制的动作**不是策略的决策**，其 (s,a,r) 对学习策略价值无效。
                _shield_forced = bool(locals().get('_shield_override', False)) or \
                    (getattr(self, '_last_decision_src', None) == 'shield') or _planner_forced
                # 【V1 构造性覆盖】**实际执行**的动作才从未访问集合里移除
                #   （见 _pick_exploration_action 的说明：选中 ≠ 执行）
                try:
                    _uv0 = getattr(self, '_unvisited', None)
                    if _uv0 and hybrid_action is not None and not _planner_forced:
                        _uv0.discard(int(hybrid_action))
                except Exception:
                    pass
                ep_frames.append([traj_rtree_obs, env_sign, lane_rtree_obs, lane_sign,
                                  (int(hybrid_action) if rl_active else None),
                                  float(causal_r), bool(rl_active), _shield_forced])
                real_reward.append(float(causal_r))

                # ===== 训练可视化刷新（DSH_VIEW=1；ESC 会抛 KeyboardInterrupt 由入口清理）=====
                if self.view.enabled:
                    _c = getattr(self, '_last_conf', None) or {}
                    _rv = _c.get('rv_veh')
                    _ef = getattr(self, '_efe_last', None) or {}
                    _efe = _ef.get('efe') or {}
                    self.view.update(
                        {'episode': len(episode_rewards) + 1, 'frame': frame_id,
                         'v': self.dynamic_map.ego_vehicle.v,
                         'action': (int(hybrid_action) if hybrid_action is not None else None),
                         'rule': getattr(self, '_cur_rule_action', None),
                         'takeover': self._last_took_over, 'reward': causal_r,
                         'rv_v': getattr(_rv, 'v', None), 'rv_x': getattr(_rv, 'x', None),
                         'arc': _c.get('arc_to_cross'), 'committed': _c.get('committed'),
                         'lcttc_rv': _c.get('lcttc_rv'), 'thw': _c.get('thw_boundary_rv'),
                         'efe_active': bool(_ef.get('active')),
                         'efe_best': _ef.get('argmin_efe_action'),
                         'efe_min': (min(_efe.values()) if _efe else None),
                         'efe_max': (max(_efe.values()) if _efe else None)},
                        world=self.env.world, ego=self.env.ego_vehicle)

                if len(traj_passed_data) >= pass_thres or done:
                    mean_reward = np.mean(rewards, axis=0)
                    gamma = 0.98
                    window_causal = sum((gamma ** t) * item[2] for t, item in enumerate(traj_passed_data))
                    print(f"[DCARL_Turn]: mean_env_reward={mean_reward}, frame_window_sum={window_causal:.2f}")
                    print("=" * 80)
                    break

            # 更新 R-tree
            if len(lane_buffer) >= 20 or done:
                while len(lane_buffer) > 0:
                    num_lane_data = min(5, len(lane_buffer))
                    current_lane_data = lane_buffer[:num_lane_data]
                    lane_data_unit = (
                        current_lane_data[0][0],
                        current_lane_data[0][1],
                        current_lane_data[0][2],
                        np.mean([lane_item[3] for lane_item in current_lane_data], axis=0)
                    )
                    self.add_lane_data(*lane_data_unit)
                    behavior_data.append(lane_data_unit)
                    self.save_behavior_data(behavior_data)
                    del lane_buffer[0]

            if len(trajectory_buffer) >= 20 or done:
                while len(trajectory_buffer) > 0:
                    num_traj_data = min(10, len(trajectory_buffer))
                    current_traj_data = trajectory_buffer[:num_traj_data]
                    traj_data_unit = (
                        current_traj_data[0][0],
                        current_traj_data[0][1],
                        current_traj_data[0][2],
                        np.mean([traj_item[3] for traj_item in current_traj_data], axis=0)
                    )
                    self.add_traj_data(*traj_data_unit)
                    del trajectory_buffer[0]

            if done:
                if self.belief_learner is not None:
                    self.belief_learner.finish()
                    self.belief_tracker.reset()
                # ===== 【论文式41/58/59】回合级蒙特卡洛回报写库 =====
                # Q̂(b,a) 的样本 = 该 (b,a) 之后「到轨迹结束」的折扣回报：
                #     G_t = Σ_{k>=t} γ^{k-t} · r_k   （含终局 碰撞-300 / 完成+150 / 卡死-100）
                # 这样终局惩罚经 γ^{k-t} 回传到轨迹上每一个时刻，修复"加速帧只拿正效率奖励、
                # 碰撞代价到不了致因动作"的信用分配断裂（对比原 20 帧滑动窗口）。
                try:
                    if len(ep_frames) > 0 and self.belief_learner is None:
                        Gs = reward_to_go([f[5] for f in ep_frames], gamma=rl_gamma)
                        # 【式(38)】有限时域动作值 Q̃_t（H 步窗口）。改造前 window_causal 只 print
                        #   不写库、无消费者 ⇒ 式(38) 是"打印级空壳"（PLAN §34.2）。
                        #   `DSH_TS_VALUE_MODE`：full(式58) | window(式38) | both(默认，两者并存)
                        _ts_vmode = os.environ.get('DSH_TS_VALUE_MODE', 'both')
                        _H = int(os.environ.get('DSH_TS_WINDOW_H', '20'))
                        if _ts_vmode in ('window', 'both'):
                            Gs_win = reward_to_go_window([f[5] for f in ep_frames],
                                                         gamma=rl_gamma, horizon=_H)
                        else:
                            Gs_win = None
                        _skip_shield = os.environ.get('DSH_TS_SKIP_SHIELD', '1') == '1'
                        _n_skipped = 0
                        for _fi, (_f, _G) in enumerate(zip(ep_frames, Gs)):
                            _traj_st, _env_sg, _lane_st, _lane_sg, _act, _r, _rl = _f[:7]
                            _forced = bool(_f[7]) if len(_f) > 7 else False
                            # 【S5-①】屏蔽强制的帧不写库：其动作非策略所选，(s,a,r) 无效
                            if _skip_shield and _forced:
                                _n_skipped += 1
                                continue
                            _a = int(_act) if _act is not None else 0
                            # 批量写：save=False（否则每条都全量 pickle 存盘 → O(N²) I/O，跑得极慢）
                            if _ts_vmode in ('full', 'both'):
                                _G_write = float(_G)
                            else:
                                _G_write = float(Gs_win[_fi])       # 式(38) 有限时域
                            self.add_lane_data(_lane_st, _lane_sg, _a, _G_write, save=False)
                            behavior_data.append((_lane_st, _lane_sg, _a, _G_write))
                            if _ts_vmode == 'both':
                                # 式(38) 的窗口值作为**独立样本**一并入库（不覆盖式58）
                                self.add_lane_data(_lane_st, _lane_sg, _a,
                                                   float(Gs_win[_fi]), save=False)
                            if _rl and _act is not None:
                                self.add_traj_data(_traj_st, _env_sg, int(_act),
                                                   _G_write, save=False)
                        # 每回合只落盘一次
                        try:
                            self.TS.Rtree_env.save_data()
                            self.TS.Rtree_lane.save_state_info()
                            self.TS.Rtree_lane.save_data()
                        except Exception:
                            pass
                        self.save_behavior_data(behavior_data)
                        print(f"[DCARL_Turn]: reward-to-go 写库 {len(ep_frames)-_n_skipped} 帧 "
                              f"(跳过屏蔽强制 {_n_skipped} 帧) "
                              f"(G范围 {min(Gs):.1f}~{max(Gs):.1f})")
                except Exception as _e:
                    print(f"[DCARL_Turn]: reward-to-go 写库异常: {_e}")

                current_ego_x = self.dynamic_map.ego_vehicle.x
                current_ego_y = self.dynamic_map.ego_vehicle.y
                episode_rule_trajectory = self.truncate_trajectory_to_nearest_point(
                    episode_rule_trajectory, (current_ego_x, current_ego_y)
                )
                single_trajectory_len = len(self.truncate_trajectory_to_nearest_point(
                    used_trajectory.trajectory, (current_ego_x, current_ego_y)
                ))
                accumulated_traj_len += single_trajectory_len
                single_trajectory_point.append(accumulated_traj_len)
                all_traj_states.append(last_traj_state)

                traj_activation_rate = traj_activate_num / max(cut_in_num, 1)
                takeover_rate = self._takeover_num / max(cut_in_num, 1)
                episode_reward = sum(real_reward) / max(len(real_reward), 1)
                evaluate_number = len(episode_rewards) + 1
                # 第4元 = 接管率（③ 式46，对齐论文 Fig.11 接管频率）
                episode_rewards.append((evaluate_number, episode_reward, traj_activation_rate, takeover_rate))

                print(f"[DCARL_Turn]: Episode {evaluate_number}, Avg Reward: {episode_reward:.2f}, "
                      f"Activate Rate: {traj_activation_rate:.2f}, Takeover Rate: {takeover_rate:.2f}")

                self.save_episode_rewards(episode_rewards)
                self.save_case_rewards(case_rewards)

                # ===== Phase 1：回合边界指标落盘（供离线分析 LCTTC/THW 分布）=====
                _terminal = ('collision' if getattr(self.env, 'ego_vehicle_collision_sign', False)
                             else ('complete' if self.env._turn_complete() else 'stuck'))
                self._record_episode_metrics(evaluate_number, ep_metrics, _terminal)
                # 【交互诊断】回合汇总行 + 每 N 回合人读报告（RV 提前刹车/让行原因分布）
                try:
                    self.ilog.end_episode(outcome=_terminal,
                                          collision=(_terminal == 'collision'),
                                          stuck=(_terminal == 'stuck'),
                                          frames=frame_id,
                                          # 【诊断埋点】CARLA 碰撞传感器的真实对方
                                          collision_event=getattr(
                                              self.env, 'ego_collision_event', None))
                except Exception as _e:
                    print(f"[InteractionLog]: 回合汇总写入失败: {_e!r}")

                # 【0' 诊断】回合结束：把本回合路径几何记录落盘（只写文件）
                try:
                    self.path_diag.end_episode(evaluate_number)
                except Exception as _e:
                    print(f"[PathDiag]: 落盘失败（不影响训练）: {_e!r}")
                # 【0' 诊断·D4/D5】哨兵率 + 逐动作全局样本数 + 对手类型后验
                try:
                    _snap = None
                    if hasattr(self.TS, 'diag_snapshot'):
                        _snap = self.TS.diag_snapshot()
                    _theta = float(self.type_inf.theta())
                    _amb = float(self.type_inf.ambiguity())
                    _post = getattr(self.type_inf, 'posterior', None)
                    if isinstance(_post, dict):
                        _post = {str(k): float(v) for k, v in _post.items()}
                    elif _post is not None:
                        try:
                            _post = [float(v) for v in _post]
                        except Exception:
                            _post = None
                    _path = os.path.join(MODEL_DIR, 'ts_diag.pkl')
                    _all = []
                    if os.path.exists(_path):
                        try:
                            with open(_path, 'rb') as _f:
                                _all = pickle.load(_f)
                        except Exception:
                            _all = []
                    _all = [r for r in _all if r.get('episode') != evaluate_number]
                    _all.append({'episode': evaluate_number, 'ts': _snap,
                                 'theta': _theta, 'ambiguity': _amb,
                                 'posterior': _post,
                                 # 【0''-b】让行观测诊断：阈值 + 观测量 + 分类
                                 'type_obs': dict(getattr(self, '_type_obs_diag', {}) or {})})
                    _all.sort(key=lambda r: r.get('episode', 0))
                    with open(_path, 'wb') as _f:
                        pickle.dump(_all, _f)
                    if evaluate_number % 5 == 0:
                        _tod = getattr(self, '_type_obs_diag', {}) or {}
                        print(f"[0'D4] ep{evaluate_number} 哨兵: 空邻域={( _snap or {}).get('sentinel_empty_neighborhood')}"
                              f" 样本不足={(_snap or {}).get('sentinel_thin_data')} / 调用={(_snap or {}).get('calls')}"
                              f" | 逐动作样本={(_snap or {}).get('per_action_counts')}"
                              f" | theta={_theta:.3f} amb={_amb:.3f}"
                              f" | 让行观测 {_tod.get('n_yield')}/{_tod.get('n_obs')} 阈值={_tod.get('th_last')}")
                except Exception as _e:
                    print(f"[0'D4/D5]: 写入失败（不影响训练）: {_e!r}")

                if evaluate_number % 50 == 0 and evaluate_number != 0:
                    self.plot_episode_rewards(episode_rewards, evaluate_number)
                    self.plot_traj_activate_rate(episode_rewards, evaluate_number)
                    self.TS.Rtree_env.save_checkpoint_by_epoch(evaluate_number)

                if evaluate_number < 100 and evaluate_number != 0 and evaluate_number % 10 == 0:
                    self.plot_episode_rewards(episode_rewards, evaluate_number)
                    self.plot_traj_activate_rate(episode_rewards, evaluate_number)

                if 0 in all_traj_states:
                    self.polt_record_traj(record_vehicle_transform, record_vehicle_bbox,
                                          evaluate_number, episode_rule_trajectory,
                                          single_trajectory_point, all_traj_states)

                obs, obs_ori = self.env.reset(False)
                self.dynamic_map.reset_motion_history()
                reset_driving_state(self)
                self._yield_last.clear()
                self._yield_hist.clear()
                mpc_controller.reset_controller()
                if matrix_peer is not None:
                    matrix_peer.reset_controller()
                    matrix_game.reset()
                    if getattr(self, 'trajectory_probe', None) is not None:
                        self.trajectory_probe.reset()
                period_machine.reset()
                road_right = False
                self.initial_yaw = None
                self._last_yaw_change = None
                self._gap_phi_prev = None
                self._last_gap_for_rate = None
                self._pbrs_shaping = 0.0
                frame_id = 0
                control_probe = (StopRestartProbe(cruise_speed=float(os.environ['DSH_PROBE_CRUISE_SPEED'])
                                 if 'DSH_PROBE_CRUISE_SPEED' in os.environ else None)
                                 if self.control_profile in ('paper_v9', 'paper_v10', 'paper_v11') and
                                 os.environ.get('DSH_CONTROL_PROBE') == '1' else None)

                rl_process_lane_choice = []
                rl_lane_sign = []
                rl_process_traj_choice = []
                # Phase 1: 回合级指标在回合结束时重置（外层 while 每窗口重跑，不能放那里）
                ep_metrics = []
                self._diag_ep = None
                episode_rule_trajectory = np.empty((0, 2))
                record_vehicle_transform = []
                record_vehicle_bbox = []
                last_traj_state = None
                accumulated_traj_len = 0
                single_trajectory_point = []
                all_traj_states = []
                step_activate_data = []
                used_act_num = 0
                traj_activate_num = 0
                cut_in_num = 0
                lane_activate_num = 0
                self._takeover_num = 0
                self._last_took_over = False
                self._efe_reward_hist = []
                self._long_sat_num = 0
                self._lat_sat_num = 0
                self._ctl_frames = 0
                self._mpc_fail_num = 0
                self._stopped_frames = 0
                self._type_obs_counter = 0
                real_reward = []
                ep_frames = []
                # 【交互诊断】新回合开始：重置逐回合计数器/帧缓冲（必须在 end_episode 之后）
                self.ilog.begin_episode(evaluate_number + 1)
                # 【0' 诊断】回合开始：重置路径几何 dump，并采样一次静态几何
                try:
                    self.path_diag.begin_episode(evaluate_number + 1)
                except Exception as _e:
                    print(f'[PathDiag] begin_episode 失败（不影响训练）: {type(_e).__name__}: {_e}')
                game_fall = False
                front_id = -1
                rear_id = -1
                epsilon = np.clip(np.random.normal(loc=1.6, scale=1.0), 1, 5)
                open_result = random.choices([0, 1], weights=[0.8, 0.2])[0]
                # P0: ε-greedy 探索率衰减（0.4 → 0.05）
                # 【S2-①】衰减率可配（默认 0.95，比原 0.98 快一倍）
                epsilon_now = max(float(getattr(self, 'eps_min', 0.05)),
                                  epsilon_now * float(getattr(self, 'eps_decay', 0.95)))
                if max_episodes is not None and evaluate_number >= max_episodes:
                    print(f"[DCARL_Turn]: 达到最大回合数 {max_episodes}，训练结束")
                    self.TS.Rtree_env.save_checkpoint_by_epoch(evaluate_number)
                    return

    # ============ 工具函数 ============
    def _calc_curvature_at(self, dynamic_map):
        path = _get_ref_path_array(dynamic_map)
        if path is not None and len(path) > 3:
            ego_x, ego_y = dynamic_map.ego_vehicle.x, dynamic_map.ego_vehicle.y
            distances = np.sqrt((path[:, 0] - ego_x)**2 + (path[:, 1] - ego_y)**2)
            idx = np.argmin(distances)
            i1, i2, i3 = max(0, idx-5), idx, min(len(path)-1, idx+5)
            if i3 - i1 > 3:
                a = math.sqrt((path[i2][0]-path[i1][0])**2 + (path[i2][1]-path[i1][1])**2)
                b = math.sqrt((path[i3][0]-path[i2][0])**2 + (path[i3][1]-path[i2][1])**2)
                c = math.sqrt((path[i3][0]-path[i1][0])**2 + (path[i3][1]-path[i1][1])**2)
                if a*b*c > 1e-10:
                    s = (a+b+c)/2.0
                    area = math.sqrt(max(0, s*(s-a)*(s-b)*(s-c)))
                    if area > 1e-10:
                        return 1.0 / ((a*b*c)/(4.0*area))
        return 0.0

    def truncate_trajectory_to_nearest_point(self, trajectory, point):
        x, y = point
        if len(trajectory) == 0:
            return trajectory
        distances = np.sqrt((trajectory[:, 0] - x)**2 + (trajectory[:, 1] - y)**2)
        idx = np.argmin(distances)
        return trajectory[idx:]

    # ============ 数据持久化 ============
    def load_activate_data(self):
        try:
            with open(self.activate_data_file, 'rb') as f:
                print("激活数据已加载"); return pickle.load(f)
        except: print("激活数据加载失败"); return []

    # ===== 日志列表上限（防长训练内存/落盘膨胀：原版无界增长 + 每次全量 pickle）=====
    _LOG_CAP = 10000

    def save_activate_data(self, data):
        # 保留最近 _LOG_CAP 条：激活日志只用于事后分析
        if len(data) > self._LOG_CAP:
            del data[:-self._LOG_CAP]
        with open(self.activate_data_file, 'wb') as f: pickle.dump(data, f)

    def load_episode_rewards(self):
        try:
            with open(self.episode_rewards_file, 'rb') as f:
                print("回合奖励数据已加载"); return pickle.load(f)
        except: print("回合奖励数据加载失败"); return []

    def save_episode_rewards(self, data):
        with open(self.episode_rewards_file, 'wb') as f: pickle.dump(data, f)

    def load_case_rewards(self):
        try:
            with open(self.case_rewards_file, 'rb') as f:
                print("case数据已加载"); return pickle.load(f)
        except: print("case数据加载失败"); return []

    def save_case_rewards(self, data):
        with open(self.case_rewards_file, 'wb') as f: pickle.dump(data, f)

    def load_behavior_data(self):
        try:
            with open(self.behavior_data_file, 'rb') as f:
                print("行为数据已加载"); return pickle.load(f)
        except: print("行为数据加载失败"); return []

    def save_behavior_data(self, data):
        # 保留最近 _LOG_CAP 条（同 activate_data，防无界增长）
        if len(data) > self._LOG_CAP:
            del data[:-self._LOG_CAP]
        with open(self.behavior_data_file, 'wb') as f: pickle.dump(data, f)

    # ============ Phase 1: 回合边界指标（LCTTC/THW_boundary）============
    def load_metrics(self):
        try:
            with open(self.metrics_file, 'rb') as f:
                data = pickle.load(f)
                print("回合指标已加载")
                return data if isinstance(data, list) else []
        except Exception:
            print("回合指标加载失败（首次运行或文件损坏）")
            return []

    def save_metrics(self):
        with open(self.metrics_file, 'wb') as f:
            pickle.dump(self.episode_metrics_log, f)

    def _record_episode_metrics(self, episode, ep_metrics, terminal):
        """回合结束：把本回合边界安全裕度均值 + 控制饱和率 + MPC失败率追加到 turn_metrics.pkl。"""
        lat_sat_rate = self._lat_sat_num / max(self._ctl_frames, 1)
        long_sat_rate = self._long_sat_num / max(self._ctl_frames, 1)
        mpc_fail_rate = self._mpc_fail_num / max(self._ctl_frames, 1)
        rec = build_episode_metrics_record(episode, ep_metrics, terminal,
                                           lat_sat_rate, long_sat_rate, mpc_fail_rate)
        self.episode_metrics_log.append(rec)
        self.save_metrics()

    # ============ 绘图功能 ============
    def plot_episode_rewards(self, episode_rewards, evaluate_number):
        try:
            cleaned = [(float(item[0]), float(item[1])) for item in episode_rewards
                       if len(item)>=2 and not (np.isnan(float(item[0])) or np.isnan(float(item[1])))]
            if not cleaned: return
            x = [item[0] for item in cleaned]; y = [item[1] for item in cleaned]
            plt.figure(figsize=(12, 7))
            if len(y) >= 5:
                from scipy.signal import savgol_filter
                window_size = min(31, len(y)//2)
                window_size = window_size if window_size % 2 == 1 else max(3, window_size-1)
                if window_size > 3:
                    try:
                        y_smooth = savgol_filter(y, window_size, 3)
                        plt.plot(x, y_smooth, 'r-', linewidth=3, label=f'S-G (win={window_size})')
                    except: pass
            if len(y) > 10:
                w = min(15, len(y)//3)
                ys = np.convolve(y, np.ones(w)/w, 'valid')
                plt.plot(x[(w-1)//2:][:len(ys)], ys, 'g-', linewidth=3, label=f'MA (win={w})')
            plt.scatter(x, y, color='blue', alpha=0.3, s=30, label='Raw')
            plt.xlabel('Episode'); plt.ylabel('Average Reward'); plt.title(f'Turn Episode Rewards (n={evaluate_number})')
            plt.grid(True, alpha=0.3); plt.legend()
            os.makedirs(PLOT_DIR, exist_ok=True)
            plt.savefig(os.path.join(PLOT_DIR, f"turn_rewards_{evaluate_number}.png"), dpi=300, bbox_inches='tight')
            plt.close()
            print(f"保存图表至 {os.path.join(PLOT_DIR, f'turn_rewards_{evaluate_number}.png')}")
        except Exception as e: print(f"绘图失败: {e}")

    def plot_traj_activate_rate(self, episode_rewards, evaluate_number):
        try:
            cleaned = [(float(item[0]), float(item[2])) for item in episode_rewards
                       if len(item)>=3 and not (np.isnan(float(item[0])) or np.isnan(float(item[2])))]
            if not cleaned: return
            x = [item[0] for item in cleaned]; y = [item[1] for item in cleaned]
            plt.figure(figsize=(12, 7))
            plt.plot(x, y, 'b-', alpha=0.5)
            if len(y) > 10:
                w = min(15, len(y)//3)
                ys = np.convolve(y, np.ones(w)/w, 'valid')
                plt.plot(x[(w-1)//2:][:len(ys)], ys, 'r-', linewidth=2, label='Trend')
            plt.xlabel('Episode'); plt.ylabel('Activation Rate'); plt.title(f'Turn Trajectory Activation Rate (n={evaluate_number})')
            plt.grid(True, alpha=0.3); plt.legend()
            os.makedirs(PLOT_DIR, exist_ok=True)
            plt.savefig(os.path.join(PLOT_DIR, f"turn_activate_{evaluate_number}.png"), dpi=300, bbox_inches='tight')
            plt.close()
        except Exception as e: print(f"绘图失败: {e}")

    def polt_record_traj(self, record_vehicle_transform, record_vehicle_bbox, evaluate_number,
                         episode_rule_trajectory, single_trajectory_point, all_traj_states):
        try:
            os.makedirs(os.path.join(PLOT_DIR, "traj_log"), exist_ok=True)
            # ===== 【修复】carla.Transform / BoundingBox 无法 pickle，转成浮点元组再存 =====
            trans_xy = []
            for frame in record_vehicle_transform:
                trans_xy.append([
                    (float(t.location.x), float(t.location.y), float(t.rotation.yaw))
                    for t in frame
                ])
            bbox_xy = []
            for frame in record_vehicle_bbox:
                bbox_xy.append([
                    (float(b.location.x), float(b.location.y),
                     float(b.extent.x), float(b.extent.y), float(b.extent.z))
                    for b in frame
                ])
            data = {
                'vehicle_transforms': trans_xy,
                'vehicle_bboxes': bbox_xy,
                'rule_trajectory': episode_rule_trajectory.tolist() if len(episode_rule_trajectory)>0 else [],
                'traj_points': single_trajectory_point,
                'traj_states': all_traj_states
            }
            with open(os.path.join(PLOT_DIR, "traj_log", f"traj_{evaluate_number}.pkl"), 'wb') as f:
                pickle.dump(data, f)
        except Exception as e: print(f"轨迹记录失败: {e}")


def _nang(angle):
    while angle > math.pi: angle -= 2 * math.pi
    while angle < -math.pi: angle += 2 * math.pi
    return angle


def _finite_min(*vals):
    """取多个量中的**有限**最小值；全非有限（inf/nan/None/不可解析）时返回 inf。

    用于 ④ 边界安全屏蔽：rv/fv 任一角色为 inf 表示"该角色无车"，不应参与比较；
    只有真正存在且有限的边界 TTC 才代表危险。
    """
    best = float('inf')
    for v in vals:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isfinite(f) and f < best:
            best = f
    return best


def build_episode_metrics_record(episode, ep_metrics, terminal,
                                 lat_sat_rate=None, long_sat_rate=None,
                                 mpc_fail_rate=None):
    """
    构建单回合边界指标记录（纯函数，可离线单测）。

    输入 ep_metrics: [(lcttc_rv, lcttc_fv, thw_boundary_rv, n_vehicles, n_objects, gap), ...]
      - lcttc*/thw_boundary 为 inf 表示无对应车辆
      - n_vehicles / n_objects 为每帧计数（诊断字段）
    可选: lat_sat_rate / long_sat_rate —— 横向/纵向 MPC 控制饱和率（对齐论文 Table II/III / Fig.5）
    输出: {'episode', 'n_frames', 'lcttc_rv_mean', 'lcttc_fv_mean',
           'thw_boundary_rv_mean', 'n_vehicles_mean', 'n_objects_mean',
           'gap_mean', 'terminal', 'lat_sat_rate', 'long_sat_rate'}
    均值只统计有限值（全 inf 则为 None）。
    """
    def _mean_finite(vals):
        fs = [float(v) for v in vals if v is not None and math.isfinite(float(v))]
        return float(np.mean(fs)) if fs else None

    def _mean_all(vals):
        return float(np.mean([float(v) for v in vals])) if vals else None

    return {
        'episode': int(episode),
        'n_frames': len(ep_metrics),
        'lcttc_rv_mean': _mean_finite([m[0] for m in ep_metrics]),
        'lcttc_fv_mean': _mean_finite([m[1] for m in ep_metrics]),
        'thw_boundary_rv_mean': _mean_finite([m[2] for m in ep_metrics]),
        'n_vehicles_mean': _mean_all([m[3] for m in ep_metrics]),
        'n_objects_mean': _mean_all([m[4] for m in ep_metrics]),
        'gap_mean': _mean_finite([m[5] for m in ep_metrics]),
        'terminal': terminal,
        'lat_sat_rate': (None if lat_sat_rate is None else float(lat_sat_rate)),
        'long_sat_rate': (None if long_sat_rate is None else float(long_sat_rate)),
        'mpc_fail_rate': (None if mpc_fail_rate is None else float(mpc_fail_rate)),
    }
