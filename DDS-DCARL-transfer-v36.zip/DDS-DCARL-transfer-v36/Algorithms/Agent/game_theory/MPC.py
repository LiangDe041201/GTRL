"""这个文件搭配同文件夹下的博弈论使用，对给定轨道下的自车进行建模"""
from Agent.reachable_set.reachable_set import longitudinal_reach_area

"""
    该文件实现参考：https://github.com/MPC-Berkeley/Implicit-Game-Theoretic-MPC/tree/main
"""

# TODO(4.30):今天先调一个自车控制的
import numpy as np
import casadi as ca
import math
import os
import time
import json
from pathlib import Path

from Agent.game_theory.game_predict import predict
from Planning_library.mpc_boundary import boundary_thw
from Planning_library.trajectory_guard import clean_path, road_geometry
from Planning_library.cournot_mpc import (
    stage_cost, validate_cost_parameters, observed_game_vehicles, vehicle_forecast)
from Planning_library.vehicle_observation import vehicle_id, vehicle_size



# 自己设定基本参考速度，比如 8 m/s，可做成类成员变量 self.v_ref（速度可以放得快一点）
V_REF = 10/3.6


class frenetConvertor:
    def __init__(self, path):
        self.path = path

        self.x_y_theta_kappa = []

        """
            现阶段实现功能：
            1.笛卡尔坐标点找到frennet的匹配点
            2.笛卡尔坐标点转到s的序号
            3.把输入的x，y路径转成frenet(初始化global_path使用)
            4.把每一个点的s算好(初始化使用)
        """

    def match_projection_points(self, xy_list: list, frenet_path_node_list: list):
        """
        # note:把输入的第一个的点转成frenet匹配的id点
        同 find_match_points(), 只不过仅用于第一次寻找投影点, 适用于计算SL之类
        计算笛卡尔坐标系（直角坐标系）下的位置(x,y)，在参考线上的匹配点索引和投影点位置信息
        即输入若干个坐标，返回他们的匹配点索引值和在frenet曲线上的投影点
        由于匹配点是frenet曲线（离散的点构成）中已知的点，所以返回索引即可，投影点一般不在frenet曲线上
        param:  xy_list: 笛卡尔坐标西下一系列的点的坐标xy_list = [(x0, y0), (x1, y1), ...)
                frenet_path_node_list: frenet坐标系下路径点信息,指的是全局路径点
                frenet_path_node_list = [(x0, y0, heading0, kappa0), ...],（x, y, 切线与x轴夹角， 曲率）
        return: match_point_index_list 匹配点的索引
                project_node_list 投影点的位置信息， project_node_list = [(x_p0, y_p0, heading_p0, kappa_p0), ...]
        """

        input_xy_length = len(xy_list)
        frenet_path_length = len(frenet_path_node_list)

        match_point_index_list = np.zeros(input_xy_length, dtype="int32")
        project_node_list = []  # 最终长度和input_xy_length应该相同

        for index_xy in range(input_xy_length):  # 为每一个点寻找匹配点
            x, y = xy_list[index_xy][0], xy_list[index_xy][1]
            start_index = 0
            # 用increase_count记录distance连续增大的次数，避免多个局部最小值的干扰
            increase_count = 0
            min_distance = float("inf")
            # 确定匹配点
            for i in range(start_index, frenet_path_length):
                frenet_node_x, frenet_node_y, _, _ = frenet_path_node_list[i]
                # 计算（x,y) 与 （frenet_node_x, frenet_node_y） 之间的距离
                distance = math.sqrt((frenet_node_x - x) ** 2 + (frenet_node_y - y) ** 2)
                if distance < min_distance:
                    min_distance = distance  # 保留最小值
                    match_point_index_list[index_xy] = i
                    increase_count = 0
                else:
                    increase_count += 1
                    if increase_count >= 50:  # 向后50个点还没找到的话，说明当前最小值点及时最优的
                        # 第一次运行阈值较大，是为了保证起始点匹配的精确性
                        break
            # 通过匹配点确定投影点
            """
            (x, y)'表示向量转置
            d_v是匹配点（x_m, y_m）指向待投影点（x,y）的向量（x-x_m, y-y_m）
            tou_v是匹配点的单位切向量(cos(theta_m), sin(theta_m))'
            (x_r, y_r)' 约等于 (x_m, y_m)' + (d_v . tou_v)*tou_v
            k_r 约等于 k_m， 投影点曲率
            theta_r 约等于 theta_m + k_m*(d_v . tou_v)， 投影点切线与坐标轴夹角
            具体原理看笔记分析
            """
            match_point_index = match_point_index_list[0]
            x_m, y_m, theta_m, k_m = frenet_path_node_list[match_point_index]
            d_v = np.array([x - x_m, y - y_m])
            tou_v = np.array([np.cos(theta_m), np.sin(theta_m)])
            ds = np.dot(d_v, tou_v)
            r_m_v = np.array([x_m, y_m])
            # 根据公式计算投影点的位置信息
            x_r, y_r = r_m_v + ds * tou_v  # 计算投影点坐标
            theta_r = theta_m + k_m * ds  # 计算投影点在frenet曲线上切线与X轴的夹角
            k_r = k_m  # 投影点在frenet曲线处的曲率
            # 将结果打包放入缓存区
            project_node_list.append((x_r, y_r, theta_r, k_r))

        return list(match_point_index_list), project_node_list

    def cal_projection_s_fun(self, local_path_opt: list, match_index_list: list, xy_list: list, s_map: list):
        """已验证
        计算若干点的投影对应的s
        param:  local_path_opt: 优化后的参考线[(x, y, theta, kappa), ...]
                match_index_list: 给定点在参考线上点的索引列表
                xy_list:  给定点的坐标[(x, y), ...]
                s_map: 参考s_map
        return: 投影点对应的s
        """
        projection_s_list = []
        for i in range(len(match_index_list)):
            x, y, theta, kappa = local_path_opt[match_index_list[i]]
            d_v = np.array([xy_list[i][0] - x, xy_list[i][1] - y])  # 匹配点指向给定点的向量
            tou_v = np.array([math.cos(theta), math.sin(theta)])  # 切线方向单位向量
            projection_s_list.append(s_map[match_index_list[i]] + np.dot(d_v, tou_v))  # np.dot(d_v, tou_v)即ds大小,有正负号的

        return projection_s_list

    def waypoint_list_2_target_path(self):
        """
        note: 这只用在初始化全局路径，计算出对应的theta和kappa
        将由路点构成的路径转化为(x, y, theta, k)的形式
        param: pathway: [waypoint0, waypoint1, ...]
        return: [(x0, y0, theta0, k0), ...]

        初始化使用：把路径转成便于规划的形式
        """
        # ===== 【关键修改】如果路径为空，返回空结果 =====
        if self.path is None or len(self.path) == 0:
            print("[MPC] 警告：waypoint_list_2_target_path 收到空路径")
            return [], [], [], [], []
        
        target_path = []

        pathway = self.path

        x_list = []
        y_list = []

        xy_list_ori = []
        for w in pathway:
            x = w[0]
            y = w[1]

            x_list.append(x)
            y_list.append(y)

            xy_list_ori.append((x, y))

        # ===== 【关键修改】如果路径点少于2个，返回空结果 =====
        if len(xy_list_ori) < 2:
            print("[MPC] 警告：路径点少于2个，无法计算曲率")
            return [], [], [], [], []

        def cal_heading_kappa(frenet_path_xy_list: list):
            """

            计算frenet曲线上每个点的切向角theta（与直角坐标轴之间的角度）和曲率k
            param: frenet_path_xy_list: 包含frenet曲线上每一点的坐标[(x0,y0), (x1, y1), ...]
            return: list类型， theta = [theta0, theta1,...], k = [k0, k1, k2, ...]
            原理:
            theta = arctan(d_y/d_x)
            kappa = d_theta / d_s
            d_s = (d_x^2 + d_y^2)^0.5
            采用中点欧拉法来计算每个点处的斜率,当前点前一个线段斜率和后一个线段斜率求平均值

            注意，角度的多值性会带来很大的麻烦，需要慎重处理
            例，x 与 x + 2pi往往代表同一个角度，这种多值性在计算曲率会带来麻烦
            比如 原本是(0.1 - (-0.1))/ds，但如果计算出的-0.1多了一个2pi
            kappa就等于(0.1 - (-0.1 + 2*pi))/ds，曲率会变得非常大
            还有若采用中点欧拉法计算heading时，(即使用(y2 - y1)/(x2 - x1)的反正切计算一个角度 ，用(y1 - y0)/(x1-x0)的反正切又计算一个角度，
            然后加起来除以2,如果精确值是 (a1 + a2)/2,但最终计算的结果可能是(a1 + a2 + 2pi)/2
            还有 tan(x) = tan(x + pi) 所以arctan(tan(x))可能等于x，也可能等于x + pi
            角度的处理非常麻烦，而且角度处理不当往往是许多奇怪错误的源头
            """
            dx_ = []
            dy_ = []
            for i in range(len(frenet_path_xy_list) - 1):
                dx_.append(frenet_path_xy_list[i + 1][0] - frenet_path_xy_list[i][0])
                dy_.append(frenet_path_xy_list[i + 1][1] - frenet_path_xy_list[i][1])
            # 计算theta,切线方向角
            # 由于n个点差分得到的只有n-1个差分结果，所以要在首尾添加重复单元来近似求每个节点的dx,dy
            dx_pre = [dx_[0]] + dx_  # 向前补dx_的第一位
            dx_aft = dx_ + [dx_[-1]]  # 向后补dx_的最后一位
            dx = (np.array(dx_pre) + np.array(dx_aft)) / 2

            dy_pre = [dy_[0]] + dy_
            dy_aft = dy_ + [dy_[-1]]
            dy = (np.array(dy_pre) + np.array(dy_aft)) / 2
            theta = np.arctan2(dy, dx)  # np.arctan2会将角度限制在（-pi, pi）之间
            # 计算曲率
            d_theta_ = np.diff(np.unwrap(theta))  # 在跨越 ±π 时保持连续曲率
            d_theta_pre = np.insert(d_theta_, 0, d_theta_[0])
            d_theta_aft = np.append(d_theta_, d_theta_[-1])
            d_theta = (d_theta_pre + d_theta_aft) / 2
            ds = np.sqrt(dx ** 2 + dy ** 2)
            k = d_theta / ds

            return list(theta), list(k)

        theta_list, kappa_list = cal_heading_kappa(xy_list_ori)
        for i in range(len(theta_list)):
            target_path.append((xy_list_ori[i][0], xy_list_ori[i][1], theta_list[i], kappa_list[i]))

        # note：这一步调用吧
        self.x_y_theta_kappa = target_path

        return x_list, y_list, theta_list, kappa_list, target_path

    def cal_s_map_fun(self, origin_xy: tuple):
        """
        # note：初始化模块
        即index2s
        计算参考线上每个节点与s的映射关系,用于算出sl图的s坐标，以车辆当前投影点为原点，不是以参考线的起点。 s就是位矢，用折线来拟合
        param:  local_path_opt: 优化后的frenet参考线[(x, y, theta, kappa), ...]
                origin_xy: 车辆当前的位置
        return: s_map: list类型 和输入的参考线长度相同
        """
        local_path_opt = self.x_y_theta_kappa

        # 计算以车辆当前位置投影点为起点的s_map
        origin_match_index, _ = self.match_projection_points([origin_xy], local_path_opt)
        # 通过车辆定位位置，计算其在参考线上的匹配点索引和投影点信息，match_projection_points处理的是一系列点的列表，
        # 因此输入要为列表形式，输出也是列表形式，但是里面只有一个元素(当前位置)，因此索引第一位就行了
        origin_match_index = origin_match_index[0]
        ref_s_map = [0]
        # 先计算以参考线起点为起点的ref_s_map（note：累积位移差）
        for i in range(1, len(local_path_opt)):
            s = math.sqrt((local_path_opt[i][0] - local_path_opt[i - 1][0]) ** 2
                          + (local_path_opt[i][1] - local_path_opt[i - 1][1]) ** 2) + ref_s_map[-1]
            ref_s_map.append(s)
        # print("ref_s_map", ref_s_map)
        # 然后算出在车辆当前位置投影点相对于参考线起点的s, 记为s0（note：就是自车现在在s图的哪个地方）
        s0 = self.cal_projection_s_fun(local_path_opt, [origin_match_index], [origin_xy], ref_s_map)
        # ref_s_map 每一项都减去s0，这样就得到了所有匹配点相对于车辆投影点的s映射（note：自车为原点）
        s_map = np.array(ref_s_map) - s0[0]
        return list(s_map)


    def cal_s_l_fun(self, obs_xy_list: list, s_map: list):
        """
        # note:通用模块
        这是坐标转换的通用模块
        坐标转换第一部分，计算S,L
        将坐标转化为S-L坐标,可以使任何要坐标转化的对象
        基本步骤是
        0.确定车辆当前位置的投影作为坐标原点
        1.确定每个点的在参考线上的匹配点和投影点；
        2.计算S,S是投影点距离规划起点的位矢，就是连接这些离散点的折线长度；
        3.计算L,即障碍物与投影点的距离
        param:  obs_xy_list: 给定一些待投影到SL图的对应点点的坐标
                local_path_opt: 优化后的参考线[(x_opt0, y_opt0, theta_0, kappa_0), ... ]
                s_map
        return: s_list 和 l_list
        """

        local_path_opt = self.x_y_theta_kappa

        # 计算这些障碍物点在当前参考线中匹配点的索引和投影点信息
        match_index_list, projection_list = self.match_projection_points(obs_xy_list, local_path_opt)

        s_list = self.cal_projection_s_fun(local_path_opt, match_index_list, obs_xy_list, s_map)  # 得到障碍点的s

        # 下面是计算l, 这里计算l和下面一个计算导数的函数有重复，以后可以考虑删除
        l_list = []

        for i in range(len(obs_xy_list)):
            pro_x, pro_y, theta, kappa = projection_list[i]  # 投影点的信息,坐标轴上的点
            n_r = np.array([-math.sin(theta), math.cos(theta)])  # 投影点的单位法向量（note：和单位向量乘为0）
            x, y = obs_xy_list[i][0], obs_xy_list[i][1]  # 待投影的位置
            r_h = np.array([x, y])  # 车辆实际位置的位矢
            r_r = np.array([pro_x, pro_y])  # 投影点的位矢
            # 核心公式: l*n_r = r_h - r_r
            # TODO 将左手系改为右手系，使得SL图为常见方向
            l_list.append(np.dot(r_h - r_r, n_r))  # *UE4定义的是左手系，所以在车辆左侧的为负值(SL图是反的)*

        return s_list, l_list


    def Cartesian2frent(self, x, y, psi):
        """
            输入：x，y，yaw
            输出：frenet下的s，l，epsi
        """
        pass


    def frenet2Cartesian(self, s, l):
        """
            输入：frenet下的s,l
            输出：对应点的x，y，yaw
        """
        pass

    def get_kappa(self, x, y):
        """返回s处的kappa"""
        _, match_point = self.match_projection_points([(x, y)], self.x_y_theta_kappa)

        kappa = match_point[0][-1]

        return kappa


class GlobalPath:
    """
        这个类用于储存全局坐标系下的道路信息
    """

    def __init__(self, pathway):
        # 输入的是[(x,y),(x,y)]
        self.frenet_convertor = frenetConvertor(pathway)  # 初始化转换者

        self.s = []  # 路径长度坐标
        self.x = []
        self.y = []
        self.psi = []  # 航向角
        self.kappa = []  # 曲率

    def set_frenet_path(self, current_x, current_y):
        x, y, theta, kappa, target_path = self.frenet_convertor.waypoint_list_2_target_path()

        self.x = x
        self.y = y
        self.psi = theta
        self.kappa = kappa

        self.s = self.frenet_convertor.cal_s_map_fun((current_x, current_y))


class VehicleModel:
    """
        这个类别实现frenet下的车辆动力学模型
    """
    def __init__(self):
        # note:这部分是参数
        self.l_r = 2.910
        self.l_f = 1.015
        self.width = 1.8
        self.delta_t = 0.1

        self.length = 4.9
        self.width = 1.8

    def dynamics_step(self, z, u):
        """
        功能：把当前状态、控制量、路径曲率输入，输出下一个时间步的状态
        输入：z=状态字典，u=控制字典
        note:这里的整个动力学系统都是弧度制的
        """
        # ========== 状态读取（已修复） ==========
        s = z['s']
        l = z['l']
        epsi = z['epsi']
        v = z['v']
        x = z['x']
        y = z['y']
        heading = z['heading']
        K = z['K']  # 直接是数字！

        # ========== 控制量读取（已修复） ==========
        a = u['a']
        delta_f = u['df']

        # ========== 自行车模型计算 ==========
        beta = ca.atan((self.l_r / (self.l_f + self.l_r)) * ca.tan(delta_f))


        dsdt = v * ca.cos(beta + epsi) / (1 - K * l)
        dyawdt = v * ca.sin(beta) / self.l_r

        # Frenet 状态更新
        s_new = s + self.delta_t * dsdt
        ey_new = l + self.delta_t * v * ca.sin(beta + epsi)
        epsi_new = epsi + self.delta_t * (dyawdt - dsdt * K)
        # 制动到零后保持静止；刹车不能让 CARLA 车辆自动倒车。
        # 否则接入速度下界后，静止 + 上一帧仍在制动会与 jerk 约束冲突。
        v_new = ca.fmax(0., v + self.delta_t * a)

        # 世界坐标系更新
        x_new = x + self.delta_t * v * ca.cos(heading + beta)
        y_new = y + self.delta_t * v * ca.sin(heading + beta)
        psi_new = heading + self.delta_t * dyawdt

        # 返回下一时刻状态
        return {
            's': s_new,
            'l': ey_new,
            'epsi': epsi_new,
            'v': v_new,
            'x': x_new,
            'y': y_new,
            'heading': psi_new,
            'K': K
        }


class obstacleManager:
    """--------------------------这部分先做后车匀减速--------------------------------"""
    def set_leader_trajectory(self, traj_s):
        self.s_lead = traj_s

    def set_follower_trajectory(self, traj_s):
        self.s_follow = traj_s

    def get_leader_s_sequence(self, N, dt):
        # 返回 MPC 未来 N 步 前车 s[0...N-1]
        pass

    def get_follower_s_sequence(self, N, dt):
        # 返回后车未来 N 步 s
        pass


class MPCController:
    """
        MPC控制类：

    """
    def __init__(self, N, dt, d_safe, thw_min, max_speed=10.0, enable_lead_follow_cost=True,
                 enable_boundary_thw=True, enable_cournot_cost=False,
                 cournot_weights=(1., 2., .3), cournot_thresholds=(1.5, .5, .3),
                 cournot_safety_mode='deficit', cost_profile='legacy', step_dts=None, vehicle_geometry=None):
        # fixme：做两个求解器短时间的跟踪控制(短时间就是做近端控制跟踪)，中长时间的做博弈(环境建模)
        self.N = N                                  # 实际上我现在做的是预测0.1s间隔一秒控制一次,但是效果还行？
        self.dt = dt
        self.cost_profile = str(cost_profile)
        self.paper_control = self.cost_profile in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11')
        self.revised_control = self.cost_profile in ('paper_v8', 'paper_v9', 'paper_v10', 'paper_v11')
        if self.cost_profile not in ('legacy', 'paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
            raise ValueError('Unknown MPC cost profile')
        self.step_dts = list(step_dts) if step_dts is not None else [float(dt)]*N
        if len(self.step_dts) != N or any(not math.isfinite(t) or t <= 0. for t in self.step_dts):
            raise ValueError('MPC step durations must be finite and positive')
        if abs(self.step_dts[0]-dt) > 1e-9:
            raise ValueError('First prediction step must equal the execution period')
        self.rate_dts = [float(dt)] + self.step_dts[:-1]
        self.prediction_times = np.r_[0., np.cumsum(self.step_dts)]
        self._previous_observed_speed = None
        self.last_prediction = None
        self.model = VehicleModel()
        if self.revised_control:
            if vehicle_geometry is None:
                raise ValueError('paper_v8/v9 requires measured ego wheel geometry')
            self.model.l_f = float(vehicle_geometry['l_f'])
            self.model.l_r = float(vehicle_geometry['l_r'])
        self._warm_controls = None
        self.last_control_plan = None
        self.last_solver_status = 'not_run'
        self.last_failure_snapshot = None
        self._failure_count = 0
        # ===== 【P0 修复】统一 dt：模型动力学步长 = 控制周期（原模型写死 0.1，
        # 而 jerk/转向率约束用 0.05，规划步长≠控制周期导致制动响应被错误限制）=====
        self.model.delta_t = self.dt
        # ===== 【P0 修复】转弯场景关闭 x 方向前后车交互代价 =====
        # lane0 的 front/rear_vehicles 可能混入垂直直行车流，x 坐标约束对垂直车流无意义，
        # 只会给错误制动/加速指令与转弯轨迹打架 → MaxIter。安全改由 agent 层兜底。
        self.enable_lead_follow_cost = enable_lead_follow_cost
        # ===== 【④ 边界约束接通】独立开关：即使关闭 x 方向前后车代价，
        # 仍启用侧向边界 THW_boundary 代价（矩形车身 vs 交叉车 RV）——
        # 让边界模型真正影响 MPC 控制，而非只在奖励里。 =====
        self.enable_boundary_thw = enable_boundary_thw
        self.enable_cournot_cost = bool(enable_cournot_cost)
        self.cournot_safety_mode = str(cournot_safety_mode)
        self.cournot_weights, self.cournot_thresholds = validate_cost_parameters(
            cournot_weights, *cournot_thresholds, safety_mode=self.cournot_safety_mode)
        # legacy 的预计算 THW 是常数项，不能改变求解结果；保留它用于单因素对照。
        self.boundary_mode = os.environ.get('DSH_MPC_BOUNDARY_MODE', 'symbolic').strip().lower()
        if self.boundary_mode not in ('symbolic', 'legacy'):
            raise ValueError('DSH_MPC_BOUNDARY_MODE must be symbolic or legacy')
        print('[MPC] boundary_mode=%s' % self.boundary_mode)
        self.d_safe = d_safe
        self.thw_min = thw_min
        self.opti = ca.Opti()

        # 预测器
        self.predictor = predict(self.N, self.dt)

        # 上层选项
        p_opts = {
            'expand': True,
            'print_time': 0,
            'verbose': False,
            'error_on_fail': 0  # 求解失败不崩
        }

        # IPOPT 核心选项（软约束化后问题更平滑：放宽迭代上限 + 可接受精度提前收敛，减少 MaxIter）
        s_opts = {
            'print_level': 0,
            'tol': 1e-3,                # 原版 1e-3
            'constr_viol_tol': 1e-3,    # 原版 1e-3
            'max_iter': 400,            # 200→400：给足迭代，避免 Maximum_Iterations_Exceeded
            'acceptable_tol': 1e-2,     # 达到可接受精度即提前收敛（省耗时）
            'acceptable_iter': 5,
            'start_with_resto': 'no' if self.revised_control else 'yes',  # 可行性恢复：约束接近不可行时自动求解恢复问题
        }

        # 最终设置求解器
        self.opti.solver('ipopt', p_opts, s_opts)

        self.nx = 7                         # 状态数量
        self.nu = 2                         # 控制数量   fixme：这里的加速度不等于carla里面的油门量，可能有问题

        self.reference_path = None
        self.last_pathway = None  # ===== 【新增】保存上一次有效路径 =====
        self.last_pathway_max_stale_dist = 15.0  # 【R18a】last_pathway 距自车超过该距离(m)视为过期，禁止使用

        # System limitations（放宽控制速率，缓解急弯+急刹场景约束不可行）
        self.steering_rate_limit = 0.9                 # 0.7 → 0.9 rad/s
        self.jerk_limit = 2.0  # m/s^3                # 1.5 → 2.0
        self.v_min = 0
        # ===== 【P0 修复】v_max 改为软约束上限，并提到 13 m/s（真实车到不了，保证 k=0 永不违反）=====
        self.v_max = max(float(max_speed), 13.0)
        self.a_min = -3
        self.a_max = 2
        self.ey_lim = .5 if self.paper_control else 3.0
        # 现有环境将同一转向数值裁剪到 [-1,1]，优化器不得越过可执行范围。
        # 保留现有转向映射；物理转角增益仍需由 CARLA 响应单独标定。
        self.max_steering = min(1., float(vehicle_geometry['max_steer'])) if self.revised_control else 1.0
        # ===== 【P1 修复】求解失败回退（P1）的安全边界 =====
        #   旧回退在"剩余参考路径不足前视距离"时会把 Pure Pursuit 前视点退化成最近点
        #   → Ld≈0 → atan2 爆掉 → 被 clip 到 ±max_steering（满舵）；实测日志里成片的
        #   `fallback(P1): delta=±1.200` 即为此。且慢速爬行时仍给 a=1.00 正加速度。
        #   现在：①前视点找不到就沿用上次转向；②回退转向单独限幅；
        #        ③车速低于 fallback_slow_speed 时回退只允许 ≤0 的加速度。
        self.fallback_steer_max = float(os.environ.get('DSH_MPC_FB_STEER_MAX', '0.6'))
        self.fallback_slow_speed = float(os.environ.get('DSH_MPC_FB_SLOW_V', '1.0'))

        self.last_u = {'a':0.1, 'df':0}                # 初始化控制量
        # 最近一次的【真实加速度指令】(m/s²) 与转向角(rad)——供控制饱和率埋点使用
        # solve() 的第一个返回值与 last_a_cmd 一致，单位都是 m/s²。
        self.last_a_cmd = 0.0
        self.last_delta_cmd = 0.0
        self.last_tracking_state = None
        self.geometry_force_stop = False
        self.geometry_source = 'unset'

        self.build_optimization()           # 初始化优化问题
        self.set_game_context(None)

        # 日志缓存（每次求解后存入，仿真结束统一写出）
        self.log_buffer = []

    def add_decision_variables(self):
        """
            这里在定义我的优化变量，和已知
            variable：优化器要求解的东西
            parameter：外部传进去的已知数据（不求解）
        """
        # 优化变量
        self.x = self.opti.variable(self.nx, self.N + 1)            # [x,y,s,ey,epsi,v, psi]
        self.u = self.opti.variable(self.nu, self.N)

        # 外部参数（极简版）
        self.x0 = self.opti.parameter(self.nx)
        self.u_prev = self.opti.parameter(self.nu)
        # TODO：这个要看需不需要后车
        # 前车 N+1 个时刻的 x 坐标 → 全部做成参数
        self.lead_x_traj = self.opti.parameter(1, self.N + 1)
        # temp:前车交互开关
        self.activate_avoid_collision = self.opti.parameter(1, self.N + 1)  # 0 或 1
        # 后车 N+1 时刻的 x 坐标
        self.follow_x_traj = self.opti.parameter(1, self.N + 1)
        self.follow_y_traj = self.opti.parameter(1, self.N + 1)
        # 后车的速度
        self.follow_v = self.opti.parameter(1, self.N + 1)
        # 换道交互项开关
        self.activate_thw = self.opti.parameter(1, self.N + 1)  # 0 或 1
        # 【Phase 1 ④】数值预计算的边界 THW（THW_boundary，矩形车身），替代质点侧向距离
        self.thw_boundary_traj = self.opti.parameter(1, self.N + 1)
        # 只预计算对手的匀速运动；自车的姿态和速度保留为决策变量。
        self.boundary_vehicle_traj = self.opti.parameter(3, self.N + 1)
        self._set_boundary_vehicle(None)

        # 动态参考速度
        self.dynamic_ref_speed = self.opti.parameter(1, self.N + 1)
        # FV/RV use the same identified conflict snapshot as the game observer.
        # Each forecast row block is x/y/yaw/length/width, not an optimized action.
        self.game_vehicle_traj = self.opti.parameter(10, self.N + 1)
        self.game_vehicle_present = self.opti.parameter(2)
        self.game_ego_size = self.opti.parameter(2)
        self.observed_acceleration = self.opti.parameter()
        self.opti.set_value(self.observed_acceleration, 0.)
        if self.paper_control:
            self.threat_trajectories = self.opti.parameter(42, self.N+1)
            self.threat_masks = self.opti.parameter(6)
        # ====================== 新加 ======================
        self.kappa = self.opti.parameter()  # 曲率作为参数！每次变


        """
            # 约束
            for k in range(self.N+1):
                s_self = self.x[2, k]          # 你的状态里 s 在第2位
                s_lead_k = self.s_lead_traj[0, k]
                self.opti.subject_to(s_self <= s_lead_k - self.d_safe)
        """

    def add_dynamic_constraints(self, kappa):
        """
        直接输入路径匹配点下的 kappa（一个浮点数）
        """
        K = kappa  # 直接用数字，不再是函数！

        # 遍历每一步预测，添加动力学约束
        for k in range(self.N):
            self.model.delta_t = self.step_dts[k]
            # 构造当前状态字典
            z = {
                's': self.x[2, k],
                'l': self.x[3, k],
                'epsi': self.x[4, k],
                'v': self.x[5, k],
                'x': self.x[0, k],
                'y': self.x[1, k],
                'heading': self.x[6, k],
                'K': K
            }

            # 构造当前控制量字典
            u = {
                'a': self.u[0, k],
                'df': self.u[1, k]
            }

            # 调用模型，递推下一时刻状态
            state_kp1 = self.model.dynamics_step(z, u)

            # 约束：下一时刻状态必须等于模型计算结果
            self.opti.subject_to(self.x[0, k + 1] == state_kp1['x'])
            self.opti.subject_to(self.x[1, k + 1] == state_kp1['y'])
            self.opti.subject_to(self.x[2, k + 1] == state_kp1['s'])
            self.opti.subject_to(self.x[3, k + 1] == state_kp1['l'])
            self.opti.subject_to(self.x[4, k + 1] == state_kp1['epsi'])
            self.opti.subject_to(self.x[5, k + 1] == state_kp1['v'])
            self.opti.subject_to(self.x[6, k + 1] == state_kp1['heading'])
        self.model.delta_t = self.dt


    def add_initial_constraints(self):
        # ====================== 初始化约束核心规则 ======================
        # MPC预测的第 0 步（k=0，就是“当前时刻”）
        # 必须严格等于 车辆当前的实际状态 x0
        # =================================================================
        # 1. 初始x坐标（世界坐标系）
        self.opti.subject_to(self.x[0, 0] == self.x0[0])
        # 2. 初始y坐标（世界坐标系）
        self.opti.subject_to(self.x[1, 0] == self.x0[1])
        # 3. 航向角（特殊处理：某些路段取绝对值）
        self.opti.subject_to(self.x[6, 0] == self.x0[6])

        # 4. 初始纵向位置 s (Frenet)
        self.opti.subject_to(self.x[2, 0] == self.x0[2])
        # 5. 初始横向误差 ey (Frenet)
        self.opti.subject_to(self.x[3, 0] == self.x0[3])
        # 6. 初始航向误差 epsi (Frenet)
        self.opti.subject_to(self.x[4, 0] == self.x0[4])
        # 7. 初始速度 v
        self.opti.subject_to(self.x[5, 0] == self.x0[5])

    def update_initial_condition(self, current_x, u_prev):
        """
            TODO:这里如何更新需要再好好做
            每次使用都要刷新状态
            就用字典的形式传进来
            输入：
        """
        self.opti.set_value(self.x0[6], current_x['heading'])
        self.opti.set_value(self.u_prev, [u_prev['a'], u_prev['df']])
        self.opti.set_value(self.x0[0], current_x['x'])
        self.opti.set_value(self.x0[1], current_x['y'])
        self.opti.set_value(self.x0[2], current_x['s'])
        self.opti.set_value(self.x0[3], current_x['l'])
        self.opti.set_value(self.x0[4], current_x['epsi'])
        self.opti.set_value(self.x0[5], current_x['v'])


    def add_ey_constraints(self):
        """轨迹跟踪误差（【P0 修复】改为软约束：ey 越界进 AV_utility 代价函数。

        旧硬约束 `|ey| <= ey_lim` 会因真实车切弯/模型误差（单一 kappa、dt 不一致）
        导致 Infeasible_Problem_Detected —— 这是 78 次求解失败的主因之一。
        """
        pass


    def add_input_rate_constraints(self):
        """输入控制变化率约束"""
        for k in range(self.N):
            rate_dt = self.rate_dts[k]
            if k == 0:
                self.opti.subject_to((self.u[0, k] - self.u_prev[0]) >= -rate_dt * self.jerk_limit)
                self.opti.subject_to((self.u[0, k] - self.u_prev[0]) <= rate_dt * self.jerk_limit)
                self.opti.subject_to((self.u[1, k] - self.u_prev[1]) >= -rate_dt * self.steering_rate_limit)
                self.opti.subject_to((self.u[1, k] - self.u_prev[1]) <= rate_dt * self.steering_rate_limit)
            else:
                self.opti.subject_to((self.u[0, k] - self.u[0, k - 1]) >= -rate_dt * self.jerk_limit)
                self.opti.subject_to((self.u[0, k] - self.u[0, k - 1]) <= rate_dt * self.jerk_limit)
                self.opti.subject_to((self.u[1, k] - self.u[1, k - 1]) >= -rate_dt * self.steering_rate_limit)
                self.opti.subject_to((self.u[1, k] - self.u[1, k - 1]) <= rate_dt * self.steering_rate_limit)

    def add_state_and_input_constraints(self):
        """状态量约束（【P0 修复】v_max 由硬约束改为软惩罚，根除超速场景的 Infeasible）"""
        for k in range(self.N + 1):
            self.opti.subject_to(self.x[5, k] >= self.v_min)
        for k in range(self.N):
            # 【P0 修复】v <= v_max 不再是硬约束，改由 AV_utility 中 100·max(0,v-v_max)² 软惩罚
            self.opti.subject_to(self.u[0, k] >= self.a_min)
            self.opti.subject_to(self.u[0, k] <= self.a_max)
            self.opti.subject_to(self.u[1, k] >= -self.max_steering)
            self.opti.subject_to(self.u[1, k] <= self.max_steering)

    # def add_collision_avoidance_constraints(self):
    #     # fixme:考虑和gt一起使用
    #     """这里要考虑前后s方位的约束"""
    #     for k in range(self.N + 1):
    #         s_self = self.x[2, k]
    #         s_lead_k = self.s_lead_traj[0, k]
    #         self.opti.subject_to(s_self <= s_lead_k - self.d_safe)


    def add_lead_interaction_cost(self, dangerous_points):
        """
            功能：添加博弈的软约束(L0的碰撞约束)
            输入：
                博弈后车2秒的预测矩形路径
            逻辑：
                1.处理矩形和global_path的关系(一次性投影四个矩形点到路径上，l最小的作为预测时间危险点)
                2.用得到的危险点作为约束
        """
        # temp:直接做全约束(先是前车)，在x方向约束,注意这里限定的是carla的x方向
        # ===== 【防 NaN】预测点为空 → 设远点默认值，避免 reshape(1,0) 与参数(1,N+1)不匹配 =====
        if not dangerous_points or len(dangerous_points) == 0:
            self.opti.set_value(self.lead_x_traj, np.full((1, self.N + 1), 1e6))
            return
        longitudinal_x = []
        for point in dangerous_points:
            longitudinal_x.append(point[0])
        longitudinal_x_np = np.array(longitudinal_x, dtype=float)
        # 【防 NaN】非空但含 NaN/非有限值 → 同样按空处理
        if longitudinal_x_np.size == 0 or not np.all(np.isfinite(longitudinal_x_np)):
            self.opti.set_value(self.lead_x_traj, np.full((1, self.N + 1), 1e6))
            return
        self.opti.set_value(self.lead_x_traj, longitudinal_x_np.reshape(1, -1))


    def add_follow_interaction_cost(self, dangerous_points, speed):
        """
            后车交互项目，输入危险的角点以及速度
        """
        # ===== 【防 NaN】预测点为空 → 设远点默认值，避免 reshape(1,0) 与参数(1,N+1)不匹配 =====
        if not dangerous_points or len(dangerous_points) == 0:
            self.opti.set_value(self.follow_x_traj, np.full((1, self.N + 1), -1e6))
            self.opti.set_value(self.follow_y_traj, np.zeros((1, self.N + 1)))
            self.opti.set_value(self.follow_v, np.zeros((1, self.N + 1)))
            return
        x = []
        y = []
        for point in dangerous_points:
            x.append(point[0])
            y.append(point[1])

        if speed < 1e-1:
            speed = 1e-1

        x_np = np.array(x, dtype=float)
        y_np = np.array(y, dtype=float)
        # 【防 NaN】非空但含 NaN/非有限值 → 同样按空处理
        if x_np.size == 0 or not np.all(np.isfinite(x_np)) or not np.all(np.isfinite(y_np)):
            self.opti.set_value(self.follow_x_traj, np.full((1, self.N + 1), -1e6))
            self.opti.set_value(self.follow_y_traj, np.zeros((1, self.N + 1)))
            self.opti.set_value(self.follow_v, np.zeros((1, self.N + 1)))
            return

        v = [speed] * len(x)

        v_np = np.array(v).reshape(1, -1)
        self.opti.set_value(self.follow_x_traj, x_np.reshape(1, -1))
        self.opti.set_value(self.follow_y_traj, y_np.reshape(1, -1))
        self.opti.set_value(self.follow_v, v_np)


    def add_dynamic_velocity_cost(self, dynamic_speed):
        speed_list = [dynamic_speed] * (self.N + 1)
        ref_speed = np.array(speed_list).reshape(1, -1)
        self.opti.set_value(self.dynamic_ref_speed, ref_speed)

    def _compute_thw_boundary_sequence(self, ego_x, ego_y, ego_yaw, ego_v, rv):
        """
        【Phase 1 ④】沿自车匀速预测轨迹，逐时步计算与 rv 的 THW_boundary。
        两车均按当前航向/速度匀速外推（与 boundary_metrics 预测约定一致）。
        rv: dynamic_map 后车对象（含 x/y/yaw/v）。返回 (1, N+1) numpy 数组。
        """
        from Planning_library.boundary_safety import boundary_metrics
        rv_x, rv_y, rv_yaw = float(rv.x), float(rv.y), float(getattr(rv, 'yaw', 0.0))
        rv_v = max(float(rv.v), 0.0)
        seq = []
        for k in range(self.N + 1):
            t = k * self.dt
            ex = ego_x + ego_v * math.cos(ego_yaw) * t
            ey = ego_y + ego_v * math.sin(ego_yaw) * t
            vx = rv_x + rv_v * math.cos(rv_yaw) * t
            vy = rv_y + rv_v * math.sin(rv_yaw) * t
            m = boundary_metrics(ex, ey, ego_yaw, max(float(ego_v), 0.0),
                                 vx, vy, rv_yaw, rv_v, dt=self.dt)
            seq.append(m['thw_boundary'])
        return np.array(seq, dtype=float).reshape(1, -1)

    def _set_boundary_vehicle(self, rv):
        """Refresh all opponent-pose parameters, including when the RV disappears."""
        if rv is None:
            trajectory = np.tile([[1000.0], [1000.0], [0.0]], (1, self.N + 1))
        else:
            yaw = float(getattr(rv, 'yaw', 0.0))
            speed = max(float(rv.v), 0.0)
            times = np.arange(self.N + 1) * self.dt
            trajectory = np.vstack((float(rv.x) + speed * math.cos(yaw) * times,
                                    float(rv.y) + speed * math.sin(yaw) * times,
                                    np.full(self.N + 1, yaw)))
        self.opti.set_value(self.boundary_vehicle_traj, trajectory)

    def boundary_cost(self, k):
        """Boundary penalty with the existing geometry, activation and weight."""
        if self.boundary_mode == 'legacy':
            thw = self.thw_boundary_traj[0, k]
        else:
            rv = self.boundary_vehicle_traj[:, k]
            thw = boundary_thw(self.x[0, k], self.x[1, k], self.x[6, k], self.x[5, k],
                               rv[0], rv[1], rv[2])
        return self.activate_thw[0, k] * 10 * ca.fmax(self.thw_min - thw, 0) ** 2


    def set_game_context(self, conf, ego=None, entry_zone=15.):
        if self.paper_control:
            from Planning_library.paper_turn_control import nearby_vehicles, motion_forecast
            vehicles = nearby_vehicles((conf or {}).get('observed_vehicles', []), ego) \
                if self.enable_cournot_cost and ego is not None else []
            forecasts = [motion_forecast(vehicles[i] if i < len(vehicles) else None,
                                        self.prediction_times) for i in range(6)]
            self.opti.set_value(self.threat_trajectories,
                                np.vstack([np.asarray(f).T for f in forecasts]))
            self.opti.set_value(self.threat_masks, [float(i < len(vehicles)) for i in range(6)])
            self.opti.set_value(self.game_ego_size,
                [vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.)])
            ids = [vehicle_id(v) for v in vehicles]
            rv_id = vehicle_id((conf or {}).get('rv_veh'))
            fv_id = vehicle_id((conf or {}).get('fv_veh'))
            self.last_game_diag = dict(enabled=self.enable_cournot_cost, active=bool(vehicles),
                safety_mode='relative_clearance', rv_id=rv_id if rv_id in ids else None,
                fv_id=fv_id if fv_id in ids else None, participant_ids=ids,
                speed=0., safety=0., comfort=0., total=0.)
            return
        participants = observed_game_vehicles(conf, entry_zone) if self.enable_cournot_cost else (None, None)
        forecasts = [vehicle_forecast(v, self.N+1, self.dt) for v in participants]
        values = np.vstack([np.asarray(forecast, dtype=float).T for forecast in forecasts])
        masks = [float(v is not None) for v in participants]
        self.opti.set_value(self.game_vehicle_traj, values)
        self.opti.set_value(self.game_vehicle_present, masks)
        self.opti.set_value(self.game_ego_size,
                            [vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.)])
        self.last_game_diag = dict(enabled=self.enable_cournot_cost, active=bool(any(masks)),
            safety_mode=self.cournot_safety_mode, rv_id=vehicle_id(participants[0]),
            fv_id=vehicle_id(participants[1]),
            **{key: (None if any(masks) else 0.) for key in ('speed', 'safety', 'comfort', 'total')})

    def cournot_cost_terms(self, k):
        if not self.enable_cournot_cost:
            return dict(speed=0., safety=0., comfort=0., total=0.)
        if self.paper_control:
            from Planning_library.paper_turn_control import symbolic_interaction_cost, smooth_interaction_cost
            interaction = smooth_interaction_cost if self.revised_control else symbolic_interaction_cost
            safety = 0.
            for i in range(6):
                safety += self.threat_masks[i]*interaction(
                    self.x[0, k], self.x[1, k], self.x[6, k], self.x[5, k],
                    ca.vertsplit(self.threat_trajectories[7*i:7*i+7, k]),
                    ca.vertsplit(self.game_ego_size))
            safety *= self.cournot_weights[1]
            return dict(speed=0., safety=safety, comfort=0., total=safety)
        headways = []
        for i in range(2):
            rv = self.game_vehicle_traj[5*i:5*i+5, k]
            thw = boundary_thw(self.x[0, k], self.x[1, k], self.x[6, k], self.x[5, k],
                               rv[0], rv[1], rv[2], self.game_ego_size[0], self.game_ego_size[1],
                               rv[3], rv[4])
            headways.append((thw, self.game_vehicle_present[i]))
        if k < self.N:
            previous = self.u_prev if k == 0 else self.u[:, k-1]
            jerk = (self.u[0, k]-previous[0])/self.dt
            steering_rate = (self.u[1, k]-previous[1])/self.dt
        else:
            jerk = steering_rate = 0.
        return stage_cost(self.x[5, k], self.dynamic_ref_speed[0, k], headways,
                          jerk, steering_rate, weights=self.cournot_weights,
                          thw_threshold=self.cournot_thresholds[0],
                          jerk_threshold=self.cournot_thresholds[1],
                          steering_threshold=self.cournot_thresholds[2],
                          safety_mode=self.cournot_safety_mode, terminal=k == self.N)

    def AV_utility(self):

        # TODO(5.23)：进行横向博弈和纵向博弈设计  1.纵向博弈为调整速度  2.横向博弈为边界模型算
        """
            初步设计成：1.纵向博弈优化的是质点距离(速度博弈思路idm交互)  2.横向博弈优化的是边界距离
        """

        sum_cost = 0
        self._game_horizon_terms = dict(speed=0., safety=0., comfort=0., total=0.)

        # 遍历整个预测时域 N+1 步
        for k in range(self.N + 1):
            stage = 0.
            weight = (self.step_dts[min(k, self.N-1)]/self.dt
                      if self.paper_control else 1.)
            # 1. 控制量代价：惩罚加速度、转角过大
            if k < self.N:
                stage += 0.05 * (self.u[0, k] ** 2 + self.u[1, k] ** 2)

            # 2. 横向跟踪代价：ey 尽量为0、epsi尽量为0
            # note：是否博弈的时候不需要这个
            stage += 1.0 * self.x[3, k] ** 2  # ey 横向偏差
            stage += 1.0 * self.x[4, k] ** 2  # epsi 航向偏差

            # ===== 【P0 修复】软约束（替代硬约束，根除 Infeasible）=====
            # ey 越界 / 超速 不再导致求解失败，而是付出大代价平滑回归。
            # 100 权重 >> 跟踪权重(1.0)，正常工况下与硬约束等价，但绝不报不可行。
            stage += 100.0 * ca.fmax(ca.fabs(self.x[3, k]) - self.ey_lim, 0) ** 2
            stage += 100.0 * ca.fmax(self.x[5, k] - self.v_max, 0) ** 2

            # 3. 速度跟踪代价 → 贴近你设定的参考速度
            # TODO(5.8)：应该修改参考速度避免横向的超调
            # TODO（5.23）：实验修改成对后车的交互博弈生成出参考速度
            stage += 1.5 * (self.x[5, k] - self.dynamic_ref_speed[0, k]) ** 2   # 0.5→1.0→1.5 加强速度控制（配合初速钳制）

            # ======================
            # 前车碰撞软约束（用参数！）
            # ======================

            # 开关型前车避碰
            ac_activate = self.activate_avoid_collision[0, k]

            x_self = self.x[0, k]
            x_lead = self.lead_x_traj[0, k]
            safe_dist = x_lead - self.d_safe
            violation = ca.fmax(0, x_self - safe_dist)
            stage += 10 * ac_activate * violation ** 2

            # 4.边界软约束必须依赖求解中的自车状态，而非给总代价加一个常数。
            if not self.paper_control:
                stage += self.boundary_cost(k)
            elif k < self.N:
                # Realized acceleration includes the standstill saturation.
                # Negative brake commands on a stopped car do not mean -3 m/s2
                # body acceleration; releasing them is not a fictitious jerk.
                if self.revised_control:
                    # Command slew must not track the discrepancy between an
                    # uncalibrated plant and its kinematic prediction.
                    previous = self.u_prev[0] if k == 0 else self.u[0, k-1]
                    jerk = (self.u[0, k]-previous)/self.rate_dts[k]
                else:
                    actual = (self.x[5, k+1]-self.x[5, k])/self.step_dts[k]
                    previous = self.observed_acceleration if k == 0 else \
                        (self.x[5, k]-self.x[5, k-1])/self.step_dts[k-1]
                    jerk = (actual-previous)/self.rate_dts[k]
                steer_prev = self.u_prev[1] if k == 0 else self.u[1, k-1]
                steer_rate = (self.u[1, k]-steer_prev)/self.rate_dts[k]
                stage += self.cournot_weights[2]*(ca.fmax(ca.fabs(jerk)-self.cournot_thresholds[1], 0.)**2
                            + ca.fmax(ca.fabs(steer_rate)-self.cournot_thresholds[2], 0.)**2)
            terms = self.cournot_cost_terms(k)
            for key in self._game_horizon_terms:
                self._game_horizon_terms[key] += weight*terms[key]
            stage += terms['total']
            sum_cost += weight*stage

        return sum_cost


    def reset_global_path(self, pathway, dynamic_map):
        """
            功能：把需要跟踪的路径更新
            输入：
                路径规划的路点
            输出：
                把控制器里的轨迹更新
        """
        # ===== 【R18a】检查轨迹是否有效 =====
        # 兜底优先级：① 道路参考路径（从自车最近点起算，永远贴着道路中心线）
        #            ② 上一次有效路径（带距离过期检查，防止旧路径把 MPC 带跑偏出道路）
        #            ③ 紧急直线路径（补齐 MPC 前瞻长度）
        ego = dynamic_map.ego_vehicle
        pathway = clean_path(pathway)
        if pathway is not None and float(ego.v) <= .1:
            heading = np.array([math.cos(ego.yaw), math.sin(ego.yaw)])
            if np.ptp((pathway - pathway[0]).dot(heading)) < .25:
                pathway = None  # 静止时纯横移不能作为车辆可行驶路径。
        self.geometry_force_stop = False
        self.geometry_source = 'planned'
        if pathway is None:
            print("[MPC] 无效/退化路径，尝试道路几何")
            ref_path = self._get_lane_reference_path(dynamic_map)
            if ref_path is not None:
                pathway = self._trim_reference_from_ego(ref_path, ego)
                self.geometry_source = 'road_recovery'
            if pathway is None and not self._is_last_pathway_stale(ego):
                pathway = clean_path(self.last_pathway)
                self.geometry_source = 'cached'
            if pathway is None:
                min_len = max(3, self.N + 2)
                dists_line = np.linspace(0.0, 1.0 + (min_len - 3) * 0.5, min_len)
                pathway = np.c_[ego.x + dists_line * math.cos(ego.yaw),
                                ego.y + dists_line * math.sin(ego.yaw)]
                self.geometry_source = 'heading_hold'
                self.geometry_force_stop = True
        
        # 保存当前路径供下次使用
        self.last_pathway = pathway

        current_x = dynamic_map.ego_vehicle.x
        current_y = dynamic_map.ego_vehicle.y

        self.reference_path = GlobalPath(pathway)
        self.reference_path.set_frenet_path(current_x, current_y)

    def _get_lane_reference_path(self, dynamic_map):
        """【R18a】取自车所在车道的道路中心线点数组（转弯场景仅一个车道时退化为 lanes[0]）"""
        lanes = getattr(dynamic_map, 'lanes', None)
        if not lanes:
            return None
        try:
            lane_idx = int(round(float(dynamic_map.ego_vehicle.lane_idx)))
        except Exception:
            lane_idx = 0
        if lane_idx < 0 or lane_idx >= len(lanes):
            lane_idx = 0
        ref = getattr(lanes[lane_idx], 'central_path_array', None)
        if ref is None or len(ref) < 3:
            ref = getattr(lanes[0], 'central_path_array', None)
        if ref is None or len(ref) < 3:
            return None
        return np.asarray(ref, dtype=float)

    def _trim_reference_from_ego(self, ref_arr, ego):
        """道路几何不依赖车速，也不使用重复的末端点填充。"""
        return road_geometry(ref_arr, ego.x, ego.y)

    def _is_last_pathway_stale(self, ego):
        """【R18a】上一次有效路径是否已过期（自车距离它超过阈值）"""
        if self.last_pathway is None or len(self.last_pathway) < 3:
            return True
        try:
            lp = np.asarray(self.last_pathway, dtype=float)
            d_min = float(np.hypot(lp[:, 0] - ego.x, lp[:, 1] - ego.y).min())
            return d_min > self.last_pathway_max_stale_dist
        except Exception:
            return True

    def ego_info_convert(self, dynamic_map):
        """
            把自车信息转成需要的形式，更新初始状态
        """
        ego_vehicle = dynamic_map.ego_vehicle

        x0 = ego_vehicle.x
        y0 = ego_vehicle.y

        s, l = self.reference_path.frenet_convertor.cal_s_l_fun([(x0, y0)], self.reference_path.s)
        s0 = s[0]
        l0 = l[0]
        v0 = ego_vehicle.v
        heading0 = ego_vehicle.yaw      # 这是弧度制的
        _, projection = self.reference_path.frenet_convertor.match_projection_points(
            [(x0, y0)], self.reference_path.frenet_convertor.x_y_theta_kappa)
        reference_heading = projection[0][2]
        # Frenet 动力学与世界坐标动力学必须使用同一个实际航向。
        # 每帧清零 epsi 会让控制器忽略已发生的偏航，且预测 l 与 x/y 不一致。
        heading_error = heading0 - reference_heading
        epsi0 = math.atan2(math.sin(heading_error), math.cos(heading_error))

        z0 = {
            's': s0,
            'l': l0,
            'epsi': epsi0,
            'v': v0,
            'x': x0,
            'y': y0,
            'heading': heading0,
        }
        return z0


    def reset_controller(self):
        self._previous_observed_speed = None
        self._warm_controls = self.last_control_plan = self.last_prediction = None
        self.last_solver_status = 'not_run'
        """
            环境重置后对控制器的更新
        """
        self.last_u = {'a': 0.1, 'df': 0}
        self.log_buffer = []
        self.last_tracking_state = None
        self.geometry_force_stop = False
        self.geometry_source = 'unset'
        self.last_pathway = None  # ===== 【新增】重置时清空缓存 =====


    def build_optimization(self):
        # 1. 定义变量 x, u
        # note:原先有个终端约束
        # 2. 定义动力学约束
        # 3. 定义代价函数
        # 4. 定义输入约束

        self.add_decision_variables()
        self.add_dynamic_constraints(self.kappa)
        self.add_initial_constraints()
        self.add_input_rate_constraints()
        self.add_state_and_input_constraints()
        # note：近端短时控制需要开
        self.add_ey_constraints()


        self.opti.minimize(self.AV_utility())

        # self.add_collision_avoidance_constraints()

    def solve(self, dynamic_map, dynamic_ref_speed, road_right, intersection_center=(6.00, -138.00)):
        started = time.perf_counter()
        # 1.给参数赋值

        # 2.求解

        # 是否更新我的自车道路，这个在agent里面做
        # fixme:转换这个可以和更新合并
        x0 = self.ego_info_convert(dynamic_map)
        if self.paper_control:
            speed = max(float(x0['v']), 0.)
            previous_speed = self._previous_observed_speed
            observed = 0. if previous_speed is None or speed < .05 else (speed-previous_speed)/self.dt
            self.opti.set_value(self.observed_acceleration, float(np.clip(observed, -3., 2.)))
            self._previous_observed_speed = speed
        # u_prev['a'], u_prev['df']
        u_prev = dict(a=float(np.clip(self.last_u['a'], self.a_min, self.a_max)),
                      df=float(np.clip(self.last_u['df'], -self.max_steering, self.max_steering)))

        if self.revised_control and x0['v'] < .1 and u_prev['a'] < 0.:
            u_prev['a'] = 0.  # Releasing held brakes at zero speed is not body jerk.

        kappa = self.reference_path.frenet_convertor.get_kappa(x0['x'], x0['y'])

        # ===== 【防 NaN】数值守卫：路径退化/投影异常时用安全默认值，避免 IPOPT Unrecoverable_Exception =====
        if kappa is None or not np.isfinite(kappa):
            kappa = 0.0
        for _k, _dflt in (('s', 0.0), ('l', 0.0), ('epsi', 0.0), ('v', 5.0),
                          ('x', 0.0), ('y', 0.0), ('heading', 0.0)):
            _v = x0.get(_k)
            if _v is None or not np.isfinite(float(_v)):
                x0[_k] = _dflt
        self.last_tracking_state = dict(x0)
        if dynamic_ref_speed is None or not np.isfinite(float(dynamic_ref_speed)):
            dynamic_ref_speed = 5.0

        # ===== 【P0 修复】记录真实速度供回退使用（v_max 已软约束化 + 提到 13 m/s，
        # 无需初速钳制，不再对优化器说谎，保证状态一致性）=====
        self._solve_v_true = max(float(x0.get('v', 0.0)), 0.0)

        # ===== 【防 NaN】上次求解失败 → 重置初值（casadi Opti 默认用上次解当初始猜测，失败解可能是 NaN）=====
        if getattr(self, '_solve_ok', True) is False:
            try:
                self.opti.set_initial(self.u, np.zeros((self.nu, self.N)))
                self.opti.set_initial(self.x, 0.0)
            except Exception:
                pass

        # 给参数赋值
        # self.opti.set_value(self.x0, x0)
        # self.opti.set_value(self.u_prev, u_prev)

        self.update_initial_condition(x0, u_prev)
        # self.opti.set_value(self.s_lead_traj, s_lead_seq)
        self.opti.set_value(self.kappa, kappa)  # 每次传当前曲率
        if self.revised_control:
            self._seed_feasible_trajectory(x0, u_prev, float(kappa))

        """===============================预测器调试=================================="""
        # 前车软约束
        # TODO(5.31):这个约束也要换成开关性的
        target_lane = dynamic_map.lanes[0]

        # if len(target_lane.front_vehicles) > 0:
        #     # note：直接把第一个当成前车会崩掉
        #     # TODO: 需要做一个gap识别器进行环境建模
        #     if road_right:
        #         fv = target_lane.front_vehicles[0]
        #
        #     else:
        #         fv = target_lane.front_vehicles[1]
        #     front_dangerous_points = self.predictor.run_step(fv, 'front_vehicle')
        #     self.add_lead_interaction_cost(front_dangerous_points)
        # else:
        #     fv = None

        if self.enable_lead_follow_cost and len(target_lane.front_vehicles) > 0:
            fv = target_lane.front_vehicles[0]
            front_dangerous_points = self.predictor.run_step(fv, 'front_vehicle')
            self.add_lead_interaction_cost(front_dangerous_points)
            # ===== 【修改】前车约束：距交叉口 5-20 米渐进激活 =====
            ego_ix, ego_iy = x0['x'], x0['y']
            dist_to_inter = math.sqrt((ego_ix - intersection_center[0])**2 + (ego_iy - intersection_center[1])**2)
            if 5.0 < dist_to_inter < 20.0:
                self.opti.set_value(self.activate_avoid_collision, np.ones((1, self.N + 1)))
            else:
                self.opti.set_value(self.activate_avoid_collision, np.zeros((1, self.N + 1)))
        else:
            # 【P0 修复】转弯场景默认关闭：x 坐标的"前车"约束对垂直直行车流无意义
            fv = None
            # 无前车：给参数设默认值避免 casadi 未赋值报错，activate=0 约束不生效
            self.opti.set_value(self.lead_x_traj, np.full((1, self.N + 1), x0['x'] + 100.0))
            self.opti.set_value(self.activate_avoid_collision, np.zeros((1, self.N + 1)))

        # 后车软约束（先看看自车越过中线与否,交互的判断）
        # 【④ 边界约束接通】enable_boundary_thw=True 时，即使 x 方向前后车代价关闭，
        # 只要有交叉车 RV（rear_vehicles），就激活侧向边界 THW_boundary 代价——
        # 让边界模型真正约束 MPC 控制（矩形车身 vs 交叉车的接近防护）。
        if len(target_lane.rear_vehicles) > 0 and (self.enable_lead_follow_cost or self.enable_boundary_thw):
            rv = target_lane.rear_vehicles[0]
            if self.enable_lead_follow_cost:
                rear_dangerous_points = self.predictor.run_step(rv, 'rear_vehicle')
                self.add_follow_interaction_cost(rear_dangerous_points, rv.v)
            else:
                # 仅边界 THW：跟随参数给默认值（不启用 x 方向代价）
                self.opti.set_value(self.follow_x_traj, np.full((1, self.N + 1), x0['x'] - 100.0))
                self.opti.set_value(self.follow_y_traj, np.full((1, self.N + 1), x0['y']))
                self.opti.set_value(self.follow_v, np.full((1, self.N + 1), 0.0))
            # ===== 【修改】后车约束：距交叉口 5-20 米渐进激活 =====
            ego_jx, ego_jy = x0['x'], x0['y']
            dist_to_inter_j = math.sqrt((ego_jx - intersection_center[0])**2 + (ego_jy - intersection_center[1])**2)
            if 5.0 < dist_to_inter_j < 20.0:
                self.opti.set_value(self.activate_thw, np.ones((1, self.N + 1)))
            else:
                self.opti.set_value(self.activate_thw, np.zeros((1, self.N + 1)))
            self._set_boundary_vehicle(rv)
            if self.boundary_mode == 'legacy':
                self.opti.set_value(self.thw_boundary_traj,
                                    self._compute_thw_boundary_sequence(
                                        x0['x'], x0['y'], x0['heading'], x0['v'], rv))
        else:
            # 无交叉车 RV / 边界约束关闭：参数给默认值，代价不生效
            rv = None
            self._set_boundary_vehicle(None)
            self.opti.set_value(self.follow_x_traj, np.full((1, self.N + 1), x0['x'] - 100.0))
            self.opti.set_value(self.follow_y_traj, np.full((1, self.N + 1), x0['y']))
            self.opti.set_value(self.follow_v, np.full((1, self.N + 1), 0.0))
            self.opti.set_value(self.activate_thw, np.zeros((1, self.N + 1)))
            # 【Phase 1 ④】rv 缺失：注入大值（thw_min - 1000 < 0 -> 代价 0）
            self.opti.set_value(self.thw_boundary_traj, np.full((1, self.N + 1), 1000.0))

        # 多加一个动态速度的规划
        self.add_dynamic_velocity_cost(dynamic_ref_speed)



        """========================================================================="""
        try:
            sol = self.opti.solve()
            self._solve_ok = True
            self.last_solver_status = str(self.opti.stats().get('return_status', 'success'))
            self.last_failure_snapshot = None
            if self.revised_control:
                self._warm_controls = np.asarray(sol.value(self.u), dtype=float)
                self.last_control_plan = self._warm_controls.copy()
            if self.enable_cournot_cost:
                self.last_game_diag.update({key: float(sol.value(value))
                                           for key, value in self._game_horizon_terms.items()})
            if self.paper_control:
                self.last_prediction = np.asarray(sol.value(self.x), dtype=float)
            # temp:求解记录log
            self.append_to_log_buffer()
            a_opt = sol.value(self.u[0, 0])
            delta_opt = sol.value(self.u[1, 0])
        except Exception as _mpce:
            self.last_prediction = None
            self._solve_ok = False
            self.last_control_plan = self._warm_controls = None
            try:
                self.last_solver_status = str(self.opti.stats().get('return_status', type(_mpce).__name__))
            except RuntimeError:
                self.last_solver_status = type(_mpce).__name__ + ':stats_unavailable'
            if self.revised_control:
                self.last_failure_snapshot = self._save_failure(x0, u_prev, dynamic_ref_speed, kappa, dynamic_map, _mpce)
            # ===== 【P0 修复】平滑回退：按"真实速度-参考速度"偏差调节 + Pure Pursuit 转向 =====
            # 旧回退(上次控制量衰减)在已超速时仍可能输出正加速度 → 持续加速失控（速度冲到 12 m/s 进弯）。
            # 新回退是速度调节器：超参考就刹、低于参考就温和加速（绝不超参考）。
            sol = self.last_u

            v_true_fb = max(float(getattr(self, '_solve_v_true', x0.get('v', 0.0))), 0.0)
            v_tgt_fb = max(float(dynamic_ref_speed), 0.0)
            if v_true_fb > v_tgt_fb + 0.5:
                a_opt = -min(3.0, (v_true_fb - v_tgt_fb) * 1.5)
            else:
                a_opt = min(1.0, max(0.0, (v_tgt_fb - v_true_fb) * 0.8))
            a_opt = float(np.clip(a_opt, -3.0, 1.0))
            # 【P1 修复·回退安全】求解失败时若车几乎停住，绝不能再给正加速度：
            #   实测 expE_p0_100 中"爬行(v≈0.001 m/s) + 求解失败 → a=1.00 + 满舵"
            #   直接把车推着满舵转出去撞掉。慢速时回退只允许滑行/轻刹。
            if v_true_fb < self.fallback_slow_speed:
                a_opt = min(a_opt, 0.0)

            # 2. 转向：沿参考路径 Pure Pursuit（前视 ~8m），替代 2.5 倍曲率增益
            delta_opt = self.last_u['df']
            try:
                rp = self.reference_path
                if rp is not None and getattr(rp, 'x', None) is not None and len(rp.x) > 2:
                    px = np.asarray(rp.x, dtype=float)
                    py = np.asarray(rp.y, dtype=float)
                    ego_x, ego_y = x0['x'], x0['y']
                    dists = (px - ego_x) ** 2 + (py - ego_y) ** 2
                    nearest = int(np.argmin(dists))
                    # 沿路径累计前视 ~8m
                    target_idx = nearest
                    found = False
                    acc = 0.0
                    step = 1 if nearest < len(px) - 1 else -1
                    for j in range(nearest, len(px) - 1 if step > 0 else 0, step):
                        acc += math.hypot(px[j + step] - px[j], py[j + step] - py[j])
                        if acc >= 8.0:
                            target_idx = j + step
                            found = True
                            break
                    # 【P1 修复】前视点找不到（剩余路径不足 8m）时必须**沿用上一次转向**，
                    #   否则 target_idx 退化成 nearest、Ld≈0 → atan2 爆掉 → 被 clip 到
                    #   ±max_steering(=1.2 rad，满舵)。实测日志里成片的
                    #   `fallback(P1): delta=±1.200` 就是这么来的。
                    if not found:
                        raise ValueError('lookahead-not-found')
                    tx, ty = px[target_idx], py[target_idx]
                    L = self.model.l_r + self.model.l_f
                    alpha = math.atan2(ty - ego_y, tx - ego_x) - x0['heading']
                    Ld = math.hypot(tx - ego_x, ty - ego_y)
                    if Ld > 1e-3:
                        delta_opt = math.atan2(2.0 * L * math.sin(alpha), Ld)
                        # 回退转向另设一个更保守的上限（满舵回退本身就是危险动作）
                        _dmax = min(self.max_steering, self.fallback_steer_max)
                        delta_opt = float(np.clip(delta_opt, -_dmax, _dmax))
            except Exception:
                delta_opt = self.last_u['df']
                _dmax = min(self.max_steering, self.fallback_steer_max)
                delta_opt = float(np.clip(delta_opt, -_dmax, _dmax))

            print(f"[MPC] 求解失败 fallback(P1): a={a_opt:.2f}, delta={delta_opt:.3f} | 异常: {type(_mpce).__name__}: {_mpce}")

        # 更新下一次使用
        a_opt = float(np.clip(a_opt, self.a_min, self.a_max))
        delta_opt = float(np.clip(delta_opt, -self.max_steering, self.max_steering))
        self.last_u = {'a': a_opt, 'df': delta_opt}
        self.last_a_cmd = float(a_opt)          # 真实加速度指令（饱和率埋点用）
        self.last_delta_cmd = float(delta_opt)  # 真实转向角指令

        # env.step 接收带符号的加速度，并负责唯一一次油门/刹车转换。
        # 此处若返回正的刹车开度，环境会把减速请求解释成加速。
        self.last_solve_ms = (time.perf_counter()-started)*1000.
        return float(a_opt), float(delta_opt)

    def _seed_feasible_trajectory(self, x0, previous, kappa):
        """Roll the warm controls from the new observed pose, never all-zero x/y."""
        self._warm_previous = None if self._warm_controls is None else self._warm_controls.copy()
        controls = np.zeros((2, self.N))
        states = np.zeros((self.nx, self.N+1))
        names = ('x', 'y', 's', 'l', 'epsi', 'v', 'heading')
        state = dict(x0, K=kappa)
        states[:, 0] = [state[key] for key in names]
        before = np.array([previous['a'], previous['df']])
        for k, duration in enumerate(self.step_dts):
            if self._warm_controls is None:
                desired = before.copy()
            else:
                j = min(self.N-1, int(np.searchsorted(self.prediction_times[1:],
                        self.prediction_times[k]+self.dt, side='right')))
                desired = self._warm_controls[:, j]
            rate = self.rate_dts[k]*np.array([self.jerk_limit, self.steering_rate_limit])
            control = np.clip(desired, before-rate, before+rate)
            control = np.clip(control, [self.a_min, -self.max_steering], [self.a_max, self.max_steering])
            controls[:, k], before = control, control
            self.model.delta_t = duration
            result = self.model.dynamics_step(state, dict(a=control[0], df=control[1]))
            state = dict((key, float(value)) for key, value in result.items())
            state['K'] = kappa
            states[:, k+1] = [state[key] for key in names]
        self.model.delta_t = self.dt
        self.opti.set_initial(self.u, controls)
        self.opti.set_initial(self.x, states)

    def _save_failure(self, x0, previous, target, kappa, dynamic_map, error):
        """Bounded, JSON-only snapshots of observable solver inputs for replay."""
        destination = os.environ.get('DSH_SAVE_DIR')
        self._failure_count += 1
        if not destination or self._failure_count > 16:
            return None
        actors = []
        for vehicle in getattr(dynamic_map, 'objects', []):
            actors.append(dict((key, getattr(vehicle, key, None)) for key in
                ('x', 'y', 'yaw', 'v', 'vx', 'vy', 'length', 'width', 'boxx', 'boxy', 'veh_id', 'carla_id', 'acc')))
        data = dict(format='mpc_v8_failure_v1', status=self.last_solver_status,
            casadi_version=ca.__version__, cost_profile=self.cost_profile,
            error=str(error), N=self.N, dt=self.dt, step_dts=self.step_dts,
            x0=x0, previous=previous, target=float(target), kappa=float(kappa),
            geometry=dict(l_f=self.model.l_f, l_r=self.model.l_r,
                          wheelbase=self.model.l_f+self.model.l_r, max_steer=self.max_steering),
            game_enabled=self.enable_cournot_cost, game_diag=self.last_game_diag,
            game_weights=list(self.cournot_weights), game_thresholds=list(self.cournot_thresholds),
            path=np.asarray(self.last_pathway).tolist(), observed_vehicles=actors,
            ego_size=np.asarray(self.opti.value(self.game_ego_size)).reshape(-1).tolist(),
            warm_previous=None if self._warm_previous is None else self._warm_previous.tolist())
        try:
            folder = Path(destination)/'mpc_failures'
            folder.mkdir(parents=True, exist_ok=True)
            path = folder/('failure_%04d.json' % self._failure_count)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=float), encoding='utf8')
            return str(path.relative_to(Path(destination)))
        except (OSError, TypeError, ValueError) as exc:
            print('[MPC] failure snapshot could not be written: %s' % exc)
            return None

    def acknowledge_applied_control(self, acceleration, steering):
        """The next slew constraint starts from the final command actually sent."""
        self.last_u = dict(a=float(np.clip(acceleration, self.a_min, self.a_max)),
                          df=float(np.clip(steering, -self.max_steering, self.max_steering)))


    def append_to_log_buffer(self):
        """
        每次MPC求解后调用
        记录：x y v yaw a delta gap_lead jerk  + 控制饱和标记
        """
        try:
            # 读取预测时域轨迹
            x_traj = self.opti.debug.value(self.x)  # (nx, N+1)
            u_traj = self.opti.debug.value(self.u)  # (nu, N)
            lead_x = self.opti.debug.value(self.lead_x_traj).flatten()

            N = self.N
            dt = self.dt  # 你的MPC离散时间步长

            frame_data = []

            # 先把整条时域a拿出来
            a_seq = []
            for k in range(N):
                a_seq.append(u_traj[0, k])
            # 最后一个时刻补最后一个a，方便算末尾jerk
            a_seq.append(a_seq[-1])

            df_seq = []
            for k in range(N):
                df_seq.append(u_traj[1, k])
            # 最后一个时刻补最后一个a，方便算末尾jerk
            df_seq.append(df_seq[-1])

            for k in range(N + 1):
                # 状态量
                x = x_traj[0, k]
                y = x_traj[1, k]
                v = x_traj[2, k]
                yaw = x_traj[3, k]

                # 控制量
                a = u_traj[0, k] if k < N else 0.0
                delta = u_traj[1, k] if (k < N and self.nu >= 2) else 0.0

                # 车间纵向距离
                gap = lead_x[k] - x

                # 计算 Jerk (da/dt)
                if k < N:
                    jerk = (a_seq[k + 1] - a_seq[k]) / dt
                else:
                    jerk = 0.0

                # 计算steering率
                if k < N:
                    steering_rate = (df_seq[k + 1] - df_seq[k]) / dt
                else:
                    steering_rate = 0.0

                # 控制饱和判断
                a_sat = False
                d_sat = False
                if k < N:
                    a_sat = (a <= -5.0 + 1e-2) or (a >= 3.0 - 1e-2)
                    if self.nu >= 2:
                        d_sat = (delta <= -1.00 + 1e-2) or (delta >= 1.00 - 1e-2)

                # 加加速度和转角率饱和判断
                jerk_sat = False
                steering_rate_sat = False
                if k < N:
                    jerk_sat = (jerk <= -0.9 + 1e-2) or (jerk >= 0.9 - 1e-2)
                    steering_rate_sat = (steering_rate <= -0.7 + 1e-2) or (steering_rate >= 0.7 - 1e-2)

                frame_data.append({
                    "k": k,
                    "x": x,
                    "y": y,
                    "v": v,
                    "yaw": yaw,
                    "a": a,
                    "delta": delta,
                    "gap_lead": gap,
                    "jerk": jerk,
                    "steering_rate": steering_rate,
                    "a_sat": a_sat,
                    "d_sat": d_sat,
                    "jerk_sat": jerk_sat,
                    "steering_rate_sat": steering_rate_sat,
                })

            self.log_buffer.append(frame_data)

        except Exception as e:
            print("⚠️ 日志缓存记录失败:", e)

    def save_full_log_to_file(self, root_log_folder=None):
        import os

        if root_log_folder is None:
            # 默认相对本文件位置（可移植，换机器无需改路径）
            root_log_folder = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "game_mpc_log", "lateral_game_log")

        if not self.log_buffer:  # 空列表 = 没有MPC数据
            # 碰撞数据不计入
            return

        # 根文件夹
        if not os.path.exists(root_log_folder):
            os.makedirs(root_log_folder)

        # ===================== 核心修改：自动计算实验序号 =====================
        # 获取根目录下所有 文件夹 数量（只统计文件夹，排除文件）
        existing_experiments = []
        for item in os.listdir(root_log_folder):
            item_path = os.path.join(root_log_folder, item)
            if os.path.isdir(item_path):
                existing_experiments.append(item)

        # 实验编号 = 已有文件夹数量 + 1
        exp_num = len(existing_experiments) + 1
        simu_folder = os.path.join(root_log_folder, f"experiment_{exp_num}")
        os.makedirs(simu_folder, exist_ok=True)
        # ====================================================================

        # 日志文件放在这个文件夹里
        log_path = os.path.join(simu_folder, "simulation_log.txt")

        with open(log_path, "w", encoding="utf-8") as f:
            f.write("=" * 140 + "\n")
            f.write("MPC 完整仿真日志（含Jerk、转向率、饱和标记）\n")
            f.write("=" * 140 + "\n\n")

            for frame_idx, frame_data in enumerate(self.log_buffer):
                f.write(f"\n===== MPC 第 {frame_idx + 1} 次求解 =====\n")
                f.write("k\tx\ty\tv\tyaw\ta\tdelta\tgap\tjerk\tsteer_rate\tsat\n")
                f.write("-" * 140 + "\n")

                for data in frame_data:
                    sat = []
                    if data["a_sat"]: sat.append("A")
                    if data["d_sat"]: sat.append("D")
                    if data["jerk_sat"]: sat.append("J")
                    if data["steering_rate_sat"]: sat.append("S")
                    sat_str = " ".join(sat)

                    line = (f"{data['k']}\t"
                            f"{data['x']:6.2f}\t"
                            f"{data['y']:6.2f}\t"
                            f"{data['v']:5.2f}\t"
                            f"{data['yaw']:6.3f}\t"
                            f"{data['a']:5.2f}\t"
                            f"{data['delta']:6.3f}\t"
                            f"{data['gap_lead']:6.2f}\t"
                            f"{data['jerk']:7.2f}\t"
                            f"{data['steering_rate']:7.2f}\t"
                            f"{sat_str}")
                    f.write(line + "\n")

            f.write("\n✅ 日志写入完成！\n")

        print(f"\n✅ 本次仿真日志已保存至文件夹：\n{simu_folder}")


"""==================================对carla油门和加速度转换进行离散化标定拟合(速度只到25m/s)==============================================="""
def a_from_v_throttle(v, T):
    # fixme：用油门转换的加速度（这个需要看实际效果）
    # a = f(v, throttle)
    T = max(0.0, min(1.0, T))
    term_v = -0.012*v - 0.00015*v*v
    term_T = 5.2*T - 1.8*T*T
    term_cross = -0.12*T*v - 0.004*T*v*v
    a = term_v + term_T + term_cross
    return a

def throttle_from_v_a(v, a):
    # T = f(v, a) 逆映射
    # fixme：用加速度转化油门（这个也需要看实际效果）
    numerator = a + 0.012*v + 0.00015*v*v
    T0 = max(0.0, min(1.0, numerator / 5.2))
    denom = 5.2 - 1.8*T0 - 0.12*v - 0.004*v*v
    T = max(0.0, min(1.0, numerator / denom))
    return T


def decel_from_v_brake(v, B):
    # 边界约束：刹车开度0~1，速度0~25m/s
    B = max(0.0, min(1.0, B))
    v = max(0.0, min(25.0, v))

    # 拟合公式（二次多项式，含交叉项）
    term1 = -0.032 * v - 0.00021 * v ** 2  # 速度基础项
    term2 = -12.8 * B + 4.5 * B ** 2  # 刹车基础项
    term3 = -0.35 * B * v - 0.008 * B * v ** 2  # 速度-刹车交叉项

    decel = term1 + term2 + term3
    return decel


def brake_from_v_decel(v, decel_target):
    # 边界约束：速度0~25m/s，目标减速度≤0（减速）
    v = max(0.0, min(25.0, v))
    decel_target = min(0.0, decel_target)  # 确保是减速需求

    # 第1步：初始估计（忽略二次项和交叉项）
    numerator = decel_target + 0.032 * v + 0.00021 * v ** 2
    B0 = max(0.0, min(1.0, numerator / (-12.8)))  # 初始刹车开度

    # 第2步：1步迭代修正（提高精度）
    denom = -12.8 + 9.0 * B0 - 0.35 * v - 0.008 * v ** 2
    B = max(0.0, min(1.0, numerator / denom))  # 最终刹车开度

    return B
