"""这个文件用于实现博弈论的部分，对给定轨迹下的自车进行速度博弈规划"""

"""
    这里实现纵向速度博弈的部分，内嵌于mpc的时候为了避碰撞会出现推头的现象
"""
import numpy as np


class IDM(object):
    """你的原始 IDM（保持不变）"""

    def __init__(self):
        self.T = 1.6
        self.g0 = 5
        self.a = 1.6
        self.b = 1.65
        self.delta = 4
        self.decision_dt = 0.75

    def IDM_speed_in_lane(self, test_vehicle, front_vehicle, front_vehicles):
        test_vehicle_location = np.array([test_vehicle.x, test_vehicle.y])
        v = test_vehicle.v
        v0 = 10 / 3.6  # FIXME: 低速场景 10km/h

        if v0 <= 0.0:
            return 0.0

        # 低速增扭
        if v < 5:
            a = self.a + (5 - v) / 5 * 2
        else:
            a = self.a

        b = self.b
        g0 = self.g0
        T = self.T
        delta = self.delta

        if front_vehicles:
            f_v_location = np.array([front_vehicle.x, front_vehicle.y])
            v_f = front_vehicle.v
            dv = v - v_f
            g = np.linalg.norm(f_v_location - test_vehicle_location)

            if g <= 0:
                return 0

            g1 = g0 + T * v + v * dv / (2 * np.sqrt(a * b))
            acc = a * (1 - pow(v / v0, delta) - (g1 / g) * ((g1 / g)))
        else:
            acc = a * (1 - pow(v / v0, delta))

        return acc


class IDMFollowerPredictor:
    """
    用 IDM 预测后车轨迹（作为 Stackelberg 博弈中的跟随者）
    """

    def __init__(self, idm_params=None):
        # 后车 IDM 参数（可与自车不同，模拟人类驾驶风格）
        self.T = 1.6
        self.g0 = 5
        self.a = 1.6
        self.b = 1.65
        self.delta = 4
        self.vehicle_length = 4.5  # 车身长度

    def predict_trajectory(self, ego_traj_x, ego_traj_v, fv_state, dt, N):
        """
        给定自车轨迹，预测后车的 IDM 响应轨迹

        Args:
            ego_traj_x: 自车位置轨迹 [N+1]
            ego_traj_v: 自车速度轨迹 [N+1]
            fv_state: (x, v) 后车当前状态
            dt: 积分步长
            N: 预测步数

        Returns:
            x_fv, v_fv: 后车预测轨迹 [N+1]
        """
        x_fv = np.zeros(N + 1)
        v_fv = np.zeros(N + 1)
        x_fv[0] = fv_state[0]
        v_fv[0] = fv_state[1]

        for k in range(N):
            # 车头间距
            gap = ego_traj_x[k] - x_fv[k] - self.vehicle_length
            # 速度差（自车 - 后车，正值表示后车需减速）
            dv = ego_traj_v[k] - v_fv[k]

            # IDM 加速度计算
            v = v_fv[k]
            v0 = 10 / 3.6  # 后车期望速度

            if gap > 0:
                g1 = self.g0 + self.T * v + v * dv / (2 * np.sqrt(self.a * self.b))
                acc = self.a * (1 - (v / v0) ** self.delta - (g1 / gap) ** 2)
            else:
                acc = -self.b * 2  # 紧急制动

            # 约束
            acc = np.clip(acc, -5.0, self.a)

            # 积分
            v_fv[k + 1] = max(0, v_fv[k] + dt * acc)
            x_fv[k + 1] = x_fv[k] + dt * v_fv[k + 1]  # 半隐式

        return x_fv, v_fv


class LongitudinalGamePlanner:
    """
    上层纵向 Stackelberg 博弈规划器
    自车(EV)领导，后车(FV)用 IDM 跟随
    """

    def __init__(self, dt_plan=0.1, N_plan=10):
        self.dt = dt_plan
        self.N = N_plan
        self.fv_predictor = IDMFollowerPredictor()


    def map_info_convert(self, dynamic_map):
        """
            作用：实现对动态地图里的信息进行转换
        """
        ego_vehicle = dynamic_map.ego_vehicle
        follow_vehicle = dynamic_map.lanes[0].rear_vehicles[0]

        ego_x = ego_vehicle.x
        ego_v = ego_vehicle.v

        fv_x = follow_vehicle.x
        fv_v = follow_vehicle.v

        return ego_x, ego_v, fv_x, fv_v


    def plan(self, dynamic_map, v_desired, dynamic_v):
        """
        主入口：生成博弈参考速度 + 前车截断

        Args:
            ego_state: dict {'x':, 'y':, 'v':, 'a':} 或对象
            fv_state:  dict {'x':, 'v':} 后车
            lead_state: dict {'x':, 'y':, 'v':, 'a':} 前车，None 表示无
            v_desired: float 期望速度 (m/s)
        """
        # TODO:做一个动态地图转格式的函数

        # 提取状态
        ego_x, ego_v, fv_x, fv_v = self.map_info_convert(dynamic_map=dynamic_map)

        # Step 1: Stackelberg 博弈求解均衡速度
        # note：有一个速度的上限需要考虑(直接把推头速度放进这个渴望速度看看)
        v_game = self._solve_stackelberg(ego_x, ego_v, fv_x, fv_v, dynamic_v)

        # Step 2: 前车安全截断
        v_ref = self._lead_cutoff(v_game, dynamic_v)

        # Step 3: 平滑过渡
        # v_ref = self._smooth(v_ref, ego_v)

        return v_ref

    def _solve_stackelberg(self, ego_x, ego_v, fv_x, fv_v, v_desired):
        """
        Stackelberg 博弈：自车选速度，预测后车 IDM 响应，评估效用
        """
        # 候选速度空间（围绕当前速度和期望速度）
        v_candidates = np.linspace(
            max(1.0, min(ego_v, v_desired) - 2),
            min(v_desired, 5.0),  # 低速场景上限
            15
        )

        best_score = -np.inf
        best_v = ego_v

        for v_const in v_candidates:
            # 构造自车轨迹（假设匀速 v_const）
            # 最后的速度是采样速度
            # t = np.arange(self.N + 1) * self.dt
            # x_ego_traj = ego_x + v_const * t
            # v_ego_traj = np.ones(self.N + 1) * v_const

            # 1. 计算匀加速度 a（从当前速度 v_ego 匀加速到 v_const，总时间 T = N*dt）
            t = np.arange(self.N + 1) * self.dt
            x_ego_traj = ego_x + ego_v * t + 0.5 * ((v_const - ego_v) / (self.N * self.dt)) * t ** 2
            v_ego_traj = ego_v + ((v_const - ego_v) / (self.N * self.dt)) * t
            a = (v_const - ego_v)/(self.N * self.dt)

            # 预测后车 IDM 响应
            x_fv_traj, v_fv_traj = self.fv_predictor.predict_trajectory(
                x_ego_traj, v_ego_traj, (fv_x, fv_v), self.dt, self.N
            )

            # 评估自车效用
            score = self._evaluate_stackelberg(
                v_const, x_ego_traj, v_ego_traj,
                x_fv_traj, v_fv_traj, a
            )

            if score > best_score:
                best_score = score
                best_v = v_const

        return best_v

    def _evaluate_stackelberg(self, v, x_ego, v_ego, x_fv, v_fv, a):
        """
        自车领导者效用函数
        最后一个是加速度
        """
        score = 0

        for k in range(self.N + 1):
            # 1. 效率收益：速度本身（低速场景权重高）
            score += 1.0 * v

            # 加速度惩罚
            score -= 0.5 * abs(a)

            # 2. 后向安全：避免被追尾
            gap_rear = x_ego[k] - x_fv[k] - self.fv_predictor.vehicle_length
            if gap_rear > 0:
                # TTC 计算
                v_rel = v_fv[k] - v  # 后车相对速度
                if v_rel > 0.5:  # 后车更快
                    ttc_rear = gap_rear / v_rel
                    # note：这个权重需要考虑
                    if ttc_rear < 1.0:
                        score -= 80 * (3.0 - ttc_rear) ** 2
            else:
                score -= 1000  # 碰撞惩罚

            # # 3. 速度协调：减少相对速度（降低追尾风险）
            # v_rel = abs(v - v_fv[k])
            # score -= 0.3 * v_rel ** 2

            # 4. 舒适：速度变化小（相对于当前）
            if k > 0:
                score -= 0.5 * abs(v - v_ego[k - 1])

        return score

    def _lead_cutoff(self, v_game, v_ref):
        """
        前车安全截断：无论博弈出多快，不能撞上前车
        外层算出不推头的安全速度进来
        """

        v_clip = min(v_game, v_ref)

        return v_clip

    def _smooth(self, v_ref, v_current):
        """
        一阶低通平滑，避免跳变
        """
        alpha = 0.25

        v_smooth = (1 - alpha) * v_current + alpha * v_ref

        return v_smooth


# ========== 使用示例 ==========

if __name__ == "__main__":
    # 初始化
    planner = LongitudinalGamePlanner(dt_plan=0.2, N_plan=25)

    # 场景：低速高密度
    ego = {'x': 0, 'y': 0, 'v': 2.5, 'a': 0}  # 自车 2.5 m/s
    fv = {'x': -8, 'v': 3.0}  # 后车 8m 后，3.0 m/s（更快，逼近）
    lead = {'x': 15, 'y': 0, 'v': 2.0, 'a': 0}  # 前车 15m 前，2.0 m/s

    v_desired = 10 / 3.6  # 10 km/h = 2.78 m/s

    # 生成参考速度
    v_ref = planner.plan(ego, fv, lead, v_desired)

    print("博弈参考速度轨迹 (m/s):", v_ref[0])
    print("初始:", v_ref[0, 0])
    print("稳态:", v_ref[0, -1])

    # 对比：无前车截断
    v_ref_no_lead = planner.plan(ego, fv, None, v_desired)
    print("\n无前车截断:", v_ref_no_lead[0, :5])
