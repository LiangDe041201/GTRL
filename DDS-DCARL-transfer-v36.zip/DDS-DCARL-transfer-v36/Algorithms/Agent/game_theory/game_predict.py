"""这个文件实现对交互对象的预测（初步设想对L0和L2进行），提取每个时间步长的危险角点（先不分时间点）"""

"""
    目标：返回预测的矩形的一个时间段内的角点
"""

import numpy as np
import math

N = 2
DT = 0.05


class predict():
    def __init__(self, t_num, dt):
        """
            初始化属性:
            maxt:预测的最大时间
            dt：时间间隔
            dynamic_map:动态地图
        """
        self.maxt = t_num*dt
        self.dt = dt

        # try:
        #     # TODO：改成强制换道的硬约束
        #     # interested_vehicles = self.found_interested_vehicles(considered_obs_num)
        #     interested_vehicles = [self.predict_item]
        #     self.predict_paths = self.prediction_obstacle(interested_vehicles, self.maxt, self.dt)
        # except:
        #     self.predict_paths = []


    def run_step(self, predict_item, item_type):
        """
            功能：对需要预测的物体进行操作
            逻辑：
                1.把输入的对象进行轨迹预测
                2.TODO：把预测器设计成两个，一个假设他就是匀速运动，一个假设自车纵向匀速运动预测物体用idm预测轨迹（一系列path）
                3.把轨迹转化路径矩形危险角点
        """
        # TODO(5.8):这里写预测转换接口
        predict_path = self.prediction_obstacle(predict_item, self.maxt, self.dt)
        future_rectangle_points = self.path2rectangle(predict_path, item_type)

        return future_rectangle_points


    def path2rectangle(self, predict_path, item_type):
        """
            功能：把预测出来的质点轨迹矩形化
            输入：质点轨迹,预测的物体是前车还是后车
            输出：矩形轨迹
        """

        rectangle_path = []

        for t in range(len(predict_path.x)):
            predict_rect = Rectangle(
                Point(predict_path.x[t], predict_path.y[t]),
                predict_path.boxx[t],
                predict_path.boxy[t],
                self.carla_yaw_to_math(predict_path.yaw[t])
            )

            corners = predict_rect.corners

            # 先测前车危险角点
            if item_type == 'front_vehicle':
                target_point = min(corners, key=lambda p: (p[0], -p[1]))
                rectangle_path.append(target_point)

            # 后车的危险角点
            # fixme:这里代码有关边界角点的模型都是在这个世界坐标系下的
            elif item_type == 'rear_vehicle':
                target_point = corners[2]
                rectangle_path.append(target_point)

        return rectangle_path


    # def check_collision(self, fp):
    #     """
    #     用途:检查给定的自车轨迹是否与预测路径发生碰撞
    #     输入:
    #         fp:当前轨迹
    #     输出:
    #         True:未发生碰撞
    #         False:发生碰撞
    #     """
    #     if len(self.predict_paths) == 0 or len(fp.t) < 3:
    #         return True
    #
    #     for path in self.predict_paths:
    #         # 计算需要检查的时间步长，取预测路径和当前路径的最小长度减1
    #         len_predict_t = min(len(fp.x) - 1, len(path.t) - 1)
    #         predict_step = 2  # 每隔2个点检查一次
    #         start_predict = 2  # 从第3个点开始检查
    #         for t in range(start_predict, len_predict_t, predict_step):
    #             # # 创建ego车辆瞬时矩形
    #             # ego_rect1 = Rectangle_MBR(Point(fp.x[t-1], fp.y[t-1]), self.dynamic_map.ego_vehicle.boxx, self.dynamic_map.ego_vehicle.boxy, fp.yaw[t-1])
    #             # ego_rect2 = Rectangle_MBR(Point(fp.x[t+1], fp.y[t+1]), self.dynamic_map.ego_vehicle.boxx, self.dynamic_map.ego_vehicle.boxy, fp.yaw[t+1])
    #             ego_rect1 = Rectangle_MBR(
    #                 Point(fp.x[t - 1], fp.y[t - 1]),
    #                 self.dynamic_map.ego_vehicle.boxx,
    #                 self.dynamic_map.ego_vehicle.boxy,
    #                 self.carla_yaw_to_math(fp.yaw[t - 1])
    #             )
    #             ego_rect2 = Rectangle_MBR(
    #                 Point(fp.x[t + 1], fp.y[t + 1]),
    #                 self.dynamic_map.ego_vehicle.boxx,
    #                 self.dynamic_map.ego_vehicle.boxy,
    #                 self.carla_yaw_to_math(fp.yaw[t + 1])
    #             )
    #
    #             # 创建ego车辆周期矩形
    #             mbr_center_x, mbr_center_y, mbr_width, mbr_height, mbr_angle = Rectangle_MBR.get_min_bounding_rectangle(
    #                 ego_rect1, ego_rect2)
    #             ego_rect = Rectangle_SAT(Point(mbr_center_x, mbr_center_y), mbr_width, mbr_height, mbr_angle)
    #
    #             # 创建环境车辆瞬时矩形
    #             # env_rect = Rectangle_SAT(Point(path.x[t], path.y[t]), path.boxx[t], path.boxy[t], path.yaw[t])
    #             env_rect = Rectangle_SAT(
    #                 Point(path.x[t], path.y[t]),
    #                 path.boxx[t],
    #                 path.boxy[t],
    #                 self.carla_yaw_to_math(path.yaw[t])
    #             )
    #
    #             # 检查自车矩形是否与环境车辆矩形相交
    #             if Rectangle_SAT.rectangles_intersect(ego_rect, env_rect):
    #                 return False
    #
    #     # 所有检查都通过，返回True表示没有碰撞
    #     return True

    def carla_yaw_to_math(self, yaw):
        """
        用途:将CARLA的yaw转换为数学坐标系的yaw
        输入:
            yaw:CARLA的yaw
        输出:
            -yaw  # 取负是因为CARLA是顺时针方向
        """
        return -yaw  # 取负是因为CARLA是顺时针方向


    def prediction_obstacle(self, predict_item, max_prediction_time, delta_t):
        """
        用途:预测环境车辆的行车轨迹
        输入:
            vehicles:环境车辆列表
            max_prediction_time:最大预测时间
            delta_t:时间步长
            predict_item:预测的车辆
        输出:
            predict_path:预测轨迹
        """
        # 创建前后两个预测路径对象（用于表示车辆前后两个点）
        predict_path = Frenet_path()

        # 设置预测路径的时间点，从0到max_prediction_time，间隔为delta_t
        predict_path.t = [t for t in np.arange(0.0, max_prediction_time+delta_t, delta_t)]

        # print("vehicle information",vehicle.x, vehicle.y, vehicle.vx, vehicle.vy, vehicle.yaw, vehicle.boxx, vehicle.boxy)

        # 预测x和y方向的速度（假设速度恒定)
        # TODO(5.8):这里需要实现一个idm的预测
        vx_predict = predict_item.vx * np.ones(len(predict_path.t))
        vy_predict = predict_item.vy * np.ones(len(predict_path.t))

        # 预测x和y坐标（匀速直线运动模型） 当前位置 + 时间步长 × 速度
        predict_path.x = predict_item.x + np.arange(len(predict_path.t)) * delta_t * vx_predict
        predict_path.y = predict_item.y + np.arange(len(predict_path.t)) * delta_t * vy_predict

        # 将单值扩展为与 x_predict 相同长度的数组，方便后续二次开发
        predict_path.yaw = np.full_like(predict_path.x, predict_item.yaw)
        predict_path.boxx = np.full_like(predict_path.x, predict_item.boxx)
        predict_path.boxy = np.full_like(predict_path.x, predict_item.boxy)

        return predict_path


class Frenet_path:
    def __init__(self):
        self.t = []  # time
        self.d = []
        self.d_d = []
        self.d_dd = []
        self.d_ddd = []
        self.s = []
        self.s_d = []
        self.s_dd = []
        self.s_ddd = []
        self.cd = 0.0
        self.cv = 0.0
        self.cf = 0.0

        """------------------------kappa_setting----------------------------"""
        self.c_k = 0.0  # 单个曲率花销
        self.c_k_d = 0.0  # 曲率突变花销
        self.c_k_dd = 0.0  # 曲率变化率（steering强相关）

        self.c_kappa = 0.0  # 总和

        self.x = []
        self.y = []
        self.yaw = []
        self.ds = []
        self.c = []

        self.boxx = []
        self.boxy = []


class Frenet_state:

    def __init__(self):
        # 时间与Frenet坐标系下的状态
        self.t = 0.0  # 时间(单位:秒)
        self.d = 0.0  # 横向位移(距离参考线的偏移量,单位:米)
        self.d_d = 0.0  # 横向速度(d方向的一阶导数,单位:米/秒)
        self.d_dd = 0.0  # 横向加速度(d方向的二阶导数,单位:米/秒²)
        self.d_ddd = 0.0  # 横向加加速度(d方向的三阶导数,单位:米/秒³)
        self.s = 0.0  # 纵向位移(沿参考线的累积距离,单位:米)
        self.s_d = 0.0  # 纵向速度(s方向的一阶导数,单位:米/秒)
        self.s_dd = 0.0  # 纵向加速度(s方向的二阶导数,单位:米/秒²)
        self.s_ddd = 0.0  # 纵向加加速度(s方向的三阶导数,单位:米/秒³)

        # 运动学状态
        self.psi = 0.0  # 车辆航向角(相对于参考线切线的偏角,单位:弧度)
        self.vs = 0.0  # 沿参考线切向的速度分量(单位:米/秒)
        self.vd = 0.0  # 沿参考线法向的速度分量(单位:米/秒)
        self.omega = 0.0  # 车辆的角速度(绕垂直轴的转向速率,单位:弧度/秒)

        # 全局坐标系下的状态
        self.x = 0.0  # 全局坐标系下的X坐标(单位:米)
        self.y = 0.0  # 全局坐标系下的Y坐标(单位:米)
        self.yaw = 0.0  # 全局航向角(车辆朝向,单位:弧度)
        self.ds = 0.0  # 沿参考线的微小位移增量(单位:米)
        self.c = 0.0  # 路径的曲率(单位:1/米,反映路径弯曲程度)


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Rectangle:
    # fixme：这玩意可能有问题，但是现在好用不管他
    def __init__(self, center, width, height, angle):
        """
        center: Point - center of the rectangle
        width: float - width of the rectangle
        height: float - height of the rectangle
        angle: float - rotation angle in radians
        """
        self.center = center
        self.width = width
        self.height = height
        self.angle = angle
        self.corners = self._calculate_corners()

    def _calculate_corners(self):
        """Calculate the four corners of the rectangle"""
        # Half dimensions
        hw = self.width / 2
        hh = self.height / 2

        # Corners before rotation (centered at origin)
        corners = [
            Point(-hw, -hh),
            Point(hw, -hh),
            Point(hw, hh),
            Point(-hw, hh)
        ]

        # Rotate and translate corners
        cos_a = np.cos(self.angle)
        sin_a = np.sin(self.angle)

        rotated_corners = []
        for p in corners:
            # Rotate
            x = p.x * cos_a - p.y * sin_a
            y = p.x * sin_a + p.y * cos_a
            # Translate
            x += self.center.x
            y += self.center.y
            # 改了不要point出来
            rotated_corners.append((x, y))

        return rotated_corners

    def get_axes(self):
        """Get the normal vectors of the edges (the axes to project onto)"""
        axes = []
        corners = self.corners
        # For each edge, get the normal vector
        for i in range(len(corners)):
            p1 = corners[i]
            p2 = corners[(i + 1) % len(corners)]
            # Edge vector
            edge = Point(p2.x - p1.x, p2.y - p1.y)
            # Normalize the normal vector
            length = np.sqrt(edge.x ** 2 + edge.y ** 2)
            if length > 0:
                # Normal vector (perpendicular to the edge)
                normal = Point(-edge.y / length, edge.x / length)
                axes.append(normal)
        return axes

    def project(self, axis):
        """Project all corners onto the given axis and return the min and max projections"""
        min_proj = float('inf')
        max_proj = -float('inf')

        for p in self.corners:
            # Project point onto axis
            proj = p.x * axis.x + p.y * axis.y

            if proj < min_proj:
                min_proj = proj
            if proj > max_proj:
                max_proj = proj

        return (min_proj, max_proj)

    def rectangles_intersect(rect1, rect2):
        """
        Check if two rectangles intersect using the Separating Axis Theorem (SAT)
        """
        # Get all axes to test (normals of both rectangles' edges)
        axes = rect1.get_axes() + rect2.get_axes()

        for axis in axes:
            # Skip zero-length axes (can happen with duplicate points)
            if axis.x == 0 and axis.y == 0:
                continue

            # Project both rectangles onto the current axis
            proj1 = rect1.project(axis)
            proj2 = rect2.project(axis)

            # Check if projections overlap
            if proj1[1] < proj2[0] or proj2[1] < proj1[0]:
                # Found a separating axis - rectangles don't intersect
                return False

        # No separating axis found - rectangles intersect
        return True

