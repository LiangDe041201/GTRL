#!/usr/bin/env python3
"""
转弯场景的横向规划状态机
替代原版的 Lane_Planner_d.py（换道 FSM）

四阶段状态转移:
  APPROACH → TURN_PREP → TURNING → EXIT
  (接近路口) (减速观察)  (过弯执行) (驶出恢复)

状态转移条件:
  A(APPROACH → TURN_PREP): 自车到交叉口距离 < approach_distance
  B(TURN_PREP → TURNING): 速度降低到安全过弯速度，且无冲突车辆
  C(TURNING → EXIT): 航向角变化 > exit_yaw_threshold 且已通过交叉口
  D(EXIT → APPROACH): 恢复直行（新一轮）
"""

import math
import numpy as np

try:
    import carla
except ImportError:
    pass


class TurnFSM:
    """转弯有限状态机，管理转弯任务的四个阶段"""

    STATE_APPROACH = "APPROACH"
    STATE_TURN_PREP = "TURN_PREP"
    STATE_TURNING = "TURNING"
    STATE_EXIT = "EXIT"

    def __init__(self):
        self.current_state = self.STATE_APPROACH
        self.initial_yaw = None
        self.turn_start_x = None
        self.turn_start_y = None
        self.intersection_center = None
        self.intersection_radius = 15.0
        self.safe_turn_speed = 8.0       # m/s ≈ 29 km/h
        self.approach_distance = 20.0    # m
        self.exit_yaw_threshold = 1.4    # rad ≈ 80°
        self.decision_finish = False

        # 超时保护：防止卡死在 TURN_PREP 状态
        self._prep_frame_count = 0
        self.max_prep_frames = 100  # 100 * 0.05s = 5s 超时

        self.transitions = {
            self.STATE_APPROACH: [self.STATE_TURN_PREP],
            self.STATE_TURN_PREP: [self.STATE_TURNING, self.STATE_TURN_PREP],
            self.STATE_TURNING: [self.STATE_EXIT, self.STATE_TURNING],
            self.STATE_EXIT: [self.STATE_APPROACH],
        }

    def reset(self):
        self.current_state = self.STATE_APPROACH
        self.initial_yaw = None
        self.turn_start_x = None
        self.turn_start_y = None
        self.intersection_center = None
        self.decision_finish = False
        self._prep_frame_count = 0

    def step(self, dynamic_map, intersection_center=None):
        """
        状态机步进

        返回: dict
            {
                'state':     当前状态编号 (1=APPROACH, 2=TURN_PREP, 3=TURNING, 4=EXIT),
                'lane_id':   目标车道索引（0 表示跟随 ref_path）,
                'rl_active': 是否激活 RL (True 仅在 TURNING 阶段),
                'ref_speed': 参考速度 (m/s)
            }
        """
        ego = dynamic_map.ego_vehicle
        ego_x, ego_y = ego.x, ego.y
        ego_yaw = ego.yaw
        ego_speed = ego.v

        if intersection_center is not None:
            self.intersection_center = intersection_center
        if self.initial_yaw is None:
            self.initial_yaw = ego_yaw

        dist = self._dist_to_intersection(ego_x, ego_y)
        yaw_change = abs(_normalize_angle(ego_yaw - self.initial_yaw))

        self._do_transition(ego_x, ego_y, ego_yaw, ego_speed, dist, yaw_change)

        return {
            'state': self._state_num(),
            'lane_id': 0,
            'rl_active': (self.current_state == self.STATE_TURNING),
            'ref_speed': self._ref_speed(ego_speed, dist, yaw_change),
        }

    def _do_transition(self, ego_x, ego_y, ego_yaw, ego_speed, dist, yaw_change):
        prev = self.current_state
        if self.current_state == self.STATE_APPROACH:
            if dist < self.approach_distance:
                self.current_state = self.STATE_TURN_PREP
                self.turn_start_x = ego_x
                self.turn_start_y = ego_y
        elif self.current_state == self.STATE_TURN_PREP:
            self._prep_frame_count += 1
            if ego_speed <= self.safe_turn_speed * 1.2 and dist < 10.0:
                self.current_state = self.STATE_TURNING
            elif dist >= self.approach_distance:
                self.current_state = self.STATE_APPROACH
            elif self._prep_frame_count >= self.max_prep_frames:
                # 超时强制进入转弯状态
                self.current_state = self.STATE_TURNING
        elif self.current_state == self.STATE_TURNING:
            if yaw_change > self.exit_yaw_threshold:
                self.current_state = self.STATE_EXIT
                self.decision_finish = True
            elif dist > self.intersection_radius * 2:
                self.current_state = self.STATE_EXIT
        elif self.current_state == self.STATE_EXIT:
            if yaw_change > 1.5 and dist > self.approach_distance * 2:
                self.current_state = self.STATE_APPROACH
                self.initial_yaw = ego_yaw
                self.decision_finish = False

        if prev != self.current_state:
            print(f"[TurnFSM]: {prev} → {self.current_state} (dist={dist:.1f}, yaw={math.degrees(yaw_change):.0f}°)")

    def _dist_to_intersection(self, ego_x, ego_y):
        if self.intersection_center is None:
            return max(0, 30 - (ego_x - (self.turn_start_x or ego_x)))
        cx, cy = self.intersection_center
        return math.sqrt((ego_x - cx)**2 + (ego_y - cy)**2)

    def _ref_speed(self, ego_speed, dist, yaw_change):
        if self.current_state == self.STATE_TURN_PREP:
            return self.safe_turn_speed
        elif self.current_state == self.STATE_TURNING:
            return self.safe_turn_speed
        elif self.current_state == self.STATE_EXIT:
            return min(ego_speed + 0.5, 12.0)
        return 12.0

    def _state_num(self):
        return {"APPROACH": 1, "TURN_PREP": 2, "TURNING": 3, "EXIT": 4}.get(self.current_state, 1)


class TurnPeriodManager:
    """转弯周期管理器，控制 RL 数据收集窗口"""

    PERIOD_APPROACHING = 1
    PERIOD_TURNING = 2
    PERIOD_EXIT = 3

    def __init__(self, approach_dist=20.0, exit_yaw=1.4):
        self.current_period = self.PERIOD_APPROACHING
        self.approach_dist = approach_dist
        self.exit_yaw = exit_yaw
        self.initial_yaw = None
        self.center = None

        # 超时保护：防止卡死在 TURNING 状态
        self._turning_frame_count = 0
        self.max_turning_frames = 300  # 300 * 0.05s = 15s 超时

    def reset(self):
        self.current_period = self.PERIOD_APPROACHING
        self.initial_yaw = None
        self.center = None
        self._turning_frame_count = 0

    def step(self, dynamic_map, intersection_center=None):
        ego = dynamic_map.ego_vehicle
        if intersection_center is not None:
            self.center = intersection_center
        if self.initial_yaw is None:
            self.initial_yaw = ego.yaw

        if self.center:
            cx, cy = self.center
            dist = math.sqrt((ego.x - cx)**2 + (ego.y - cy)**2)
        else:
            dist = 50

        yaw_change = abs(_normalize_angle(ego.yaw - self.initial_yaw))

        if dist > self.approach_dist:
            self.current_period = self.PERIOD_APPROACHING
            self._turning_frame_count = 0
        elif yaw_change < self.exit_yaw:
            self.current_period = self.PERIOD_TURNING
            self._turning_frame_count += 1
        else:
            self.current_period = self.PERIOD_EXIT
            self._turning_frame_count = 0

        # 超时强制退出 TURNING，防止卡死
        if (self.current_period == self.PERIOD_TURNING and
                self._turning_frame_count >= self.max_turning_frames):
            self.current_period = self.PERIOD_EXIT
            print(f"[TurnPeriodManager]: 转弯超时，强制进入 EXIT 状态")

        return self.current_period, (self.current_period == self.PERIOD_TURNING)


def _normalize_angle(angle):
    while angle > math.pi:
        angle -= 2 * math.pi
    while angle < -math.pi:
        angle += 2 * math.pi
    return angle