"""这是一个关于路径规划的文件，参考阿波罗的emplanner对局部路径进行SL图规划，简单的二维撒点规划，规划的纵向范围是自车位置到前车位置+前车两秒后的路程（note:可能出现规划过短的情况）"""

import numpy as np
import math

from Agent.motion_planning import DP_utils

# 针对换道里的动态地图的目标道路编号
TARGET_LANE_INDEX = 0



"""---------------------------------------笛卡尔坐标系对frenet的转换-----------------------------------------------"""
def match_projection_points(xy_list: list, frenet_path_node_list: list):
    """
    同 find_match_points(), 只不过仅用于第一次寻找投影点, 适用于计算SL之类
    计算笛卡尔坐标系（直角坐标系）下的位置(x,y)，在参考线上的匹配点索引和投影点位置信息
    即输入若干个坐标，返回他们的匹配点索引值和在frenet曲线上的投影点
    由于匹配点是frenet曲线（离散的点构成）中已知的点，所以返回索引即可，投影点一般不在frenet曲线上
    param:  xy_list: 笛卡尔坐标西下一系列的点的坐标xy_list = [(x0, y0), (x1, y1), ...)
            frenet_path_node_list: frenet坐标系下路径点信息,指的是全局路径点
            frenet_path_node_list = [(x0, y0, heading0, kappa0), ...],（x, y, 切线与x轴夹角， 曲率）
    return: match_point_index_list 匹配点的索引
            project_node_list 投影点的位置信息， project_node_list = [(x_p0, y_p0, heading_p0, kappa_p0), ...]
    """

    input_xy_length = len(xy_list)
    frenet_path_length = len(frenet_path_node_list)

    match_point_index_list = np.zeros(input_xy_length, dtype="int32")
    project_node_list = []  # 最终长度和input_xy_length应该相同

    for index_xy in range(input_xy_length):  # 为每一个点寻找匹配点
        x, y = xy_list[index_xy][0], xy_list[index_xy][1]
        start_index = 0
        # 用increase_count记录distance连续增大的次数，避免多个局部最小值的干扰
        increase_count = 0
        min_distance = float("inf")
        # 确定匹配点
        for i in range(start_index, frenet_path_length):
            frenet_node_x, frenet_node_y, _, _ = frenet_path_node_list[i]
            # 计算（x,y) 与 （frenet_node_x, frenet_node_y） 之间的距离
            distance = math.sqrt((frenet_node_x - x) ** 2 + (frenet_node_y - y) ** 2)
            if distance < min_distance:
                min_distance = distance  # 保留最小值
                match_point_index_list[index_xy] = i
                increase_count = 0
            else:
                increase_count += 1
                if increase_count >= 50:  # 向后50个点还没找到的话，说明当前最小值点及时最优的
                    # 第一次运行阈值较大，是为了保证起始点匹配的精确性
                    break
        # 通过匹配点确定投影点
        """
        (x, y)'表示向量转置
        d_v是匹配点（x_m, y_m）指向待投影点（x,y）的向量（x-x_m, y-y_m）
        tou_v是匹配点的单位切向量(cos(theta_m), sin(theta_m))'
        (x_r, y_r)' 约等于 (x_m, y_m)' + (d_v . tou_v)*tou_v
        k_r 约等于 k_m， 投影点曲率
        theta_r 约等于 theta_m + k_m*(d_v . tou_v)， 投影点切线与坐标轴夹角
        具体原理看笔记分析
        """
        match_point_index = match_point_index_list[0]
        x_m, y_m, theta_m, k_m = frenet_path_node_list[match_point_index]
        d_v = np.array([x - x_m, y - y_m])
        tou_v = np.array([np.cos(theta_m), np.sin(theta_m)])
        ds = np.dot(d_v, tou_v)
        r_m_v = np.array([x_m, y_m])
        # 根据公式计算投影点的位置信息
        x_r, y_r = r_m_v + ds * tou_v  # 计算投影点坐标
        theta_r = theta_m + k_m * ds  # 计算投影点在frenet曲线上切线与X轴的夹角
        k_r = k_m  # 投影点在frenet曲线处的曲率
        # 将结果打包放入缓存区
        project_node_list.append((x_r, y_r, theta_r, k_r))

    return list(match_point_index_list), project_node_list


def cal_projection_s_fun(local_path_opt: list, match_index_list: list, xy_list: list, s_map: list):
    """已验证
    计算若干点的投影对应的s
    param:  local_path_opt: 优化后的参考线[(x, y, theta, kappa), ...]
            match_index_list: 给定点在参考线上点的索引列表
            xy_list:  给定点的坐标[(x, y), ...]
            s_map: 参考s_map
    return: 投影点对应的s
    """
    projection_s_list = []
    for i in range(len(match_index_list)):
        x, y, theta, kappa = local_path_opt[match_index_list[i]]
        d_v = np.array([xy_list[i][0] - x, xy_list[i][1] - y])  # 匹配点指向给定点的向量
        tou_v = np.array([math.cos(theta), math.sin(theta)])  # 切线方向单位向量
        projection_s_list.append(s_map[match_index_list[i]] + np.dot(d_v, tou_v))  # np.dot(d_v, tou_v)即ds大小,有正负号的

    return projection_s_list

"""----------------------------------------------------------------------------------------------------------------"""


class PathSlPlanner(object):
    """
    这个路径规划类通过撒点进行细精度的路径规划
    """
    def __init__(self, env):
        self.env = env                              # carla世界

        self.sampling_res = 2                       # 用五次多项式拟合最终曲线的采样间隔
        self.w_smooth_cost = [300,1000,5000]        # dl,ddl,dddl的平滑代价
        self.w_reference_l_cost = 20                # 目前来看是用一个横向偏离目标车道的作为效率代价
        # temp(4.26):先尝试固定的栅格(间隔确定)
        self.row = -1                               # 横向采样的个数
        self.col = -1                               # 纵向采样的个数
        self.sample_s = 5                           # 纵向采样的间隔
        self.sample_l = 0.5                         # 横向采样的间隔

        self.global_x_y_theta_kappa = None          # 初始化出来的全局路径

        self.last_s_path = None                     # 上一次规划出来的s
        self.last_l_path = None                     # 上一次规划出来的l
        self.last_match_point_index = 0             # 上一次在全局路径下的对应点序号
        self.x_y_theta_kappa = None                 # 上一次规划出来的路径的坐标、位姿、曲率


    def waypoint_list_2_target_path(self, pathway):
        """
        将由路点构成的路径转化为(x, y, theta, k)的形式
        param: pathway: [waypoint0, waypoint1, ...]
        return: [(x0, y0, theta0, k0), ...]

        初始化使用：把路径转成便于规划的形式
        """

        target_path = []
        w = None  # type: np.array
        xy_list_ori = []
        for w in pathway:
            x = w[0]
            y = w[1]
            xy_list_ori.append((x, y))

        def cal_heading_kappa(frenet_path_xy_list: list):
            """
            note: 这只用在初始化全局路径，计算出对应的theta和kappa
            计算frenet曲线上每个点的切向角theta（与直角坐标轴之间的角度）和曲率k
            param: frenet_path_xy_list: 包含frenet曲线上每一点的坐标[(x0,y0), (x1, y1), ...]
            return: list类型， theta = [theta0, theta1,...], k = [k0, k1, k2, ...]
            原理:
            theta = arctan(d_y/d_x)
            kappa = d_theta / d_s
            d_s = (d_x^2 + d_y^2)^0.5
            采用中点欧拉法来计算每个点处的斜率,当前点前一个线段斜率和后一个线段斜率求平均值

            注意，角度的多值性会带来很大的麻烦，需要慎重处理
            例，x 与 x + 2pi往往代表同一个角度，这种多值性在计算曲率会带来麻烦
            比如 原本是(0.1 - (-0.1))/ds，但如果计算出的-0.1多了一个2pi
            kappa就等于(0.1 - (-0.1 + 2*pi))/ds，曲率会变得非常大
            还有若采用中点欧拉法计算heading时，(即使用(y2 - y1)/(x2 - x1)的反正切计算一个角度 ，用(y1 - y0)/(x1-x0)的反正切又计算一个角度，
            然后加起来除以2,如果精确值是 (a1 + a2)/2,但最终计算的结果可能是(a1 + a2 + 2pi)/2
            还有 tan(x) = tan(x + pi) 所以arctan(tan(x))可能等于x，也可能等于x + pi
            角度的处理非常麻烦，而且角度处理不当往往是许多奇怪错误的源头
            """
            dx_ = []
            dy_ = []
            for i in range(len(frenet_path_xy_list) - 1):
                dx_.append(frenet_path_xy_list[i + 1][0] - frenet_path_xy_list[i][0])
                dy_.append(frenet_path_xy_list[i + 1][1] - frenet_path_xy_list[i][1])
            # 计算theta,切线方向角
            # 由于n个点差分得到的只有n-1个差分结果，所以要在首尾添加重复单元来近似求每个节点的dx,dy
            dx_pre = [dx_[0]] + dx_  # 向前补dx_的第一位
            dx_aft = dx_ + [dx_[-1]]  # 向后补dx_的最后一位
            dx = (np.array(dx_pre) + np.array(dx_aft)) / 2

            dy_pre = [dy_[0]] + dy_
            dy_aft = dy_ + [dy_[-1]]
            dy = (np.array(dy_pre) + np.array(dy_aft)) / 2
            theta = np.arctan2(dy, dx)  # np.arctan2会将角度限制在（-pi, pi）之间
            # 计算曲率
            d_theta_ = np.diff(theta)  # 差分计算
            d_theta_pre = np.insert(d_theta_, 0, d_theta_[0])
            d_theta_aft = np.insert(d_theta_, -1, d_theta_[-1])
            d_theta = np.sin((d_theta_pre + d_theta_aft) / 2)  # 认为d_theta是个小量，用sin(d_theta)代替d_theta,避免多值性
            ds = np.sqrt(dx ** 2 + dy ** 2)
            k = d_theta / ds

            return list(theta), list(k)

        theta_list, kappa_list = cal_heading_kappa(xy_list_ori)
        for i in range(len(theta_list)):
            target_path.append((xy_list_ori[i][0], xy_list_ori[i][1], theta_list[i], kappa_list[i]))

        # 这是做动态规划的时候使用的
        # self.global_x_y_theta_kappa = target_path

        return target_path


    def find_match_points(self, xy_list: list, frenet_path_node_list: list, is_first_run: bool, pre_match_index: int):
        """
        计算笛卡尔坐标系（直角坐标系）下的位置(x,y)，在frenet（自然坐标系）路径上的匹配点索引和投影点位置信息
        即输入若干个坐标，返回他们的匹配点索引值和在frenet曲线上的投影点
        注：老王在这里考虑的比较多，考虑了后面有多个点需要投影的情况，在平滑阶段，每次是只有一个需要投影的
        由于匹配点是frenet曲线（离散的点构成）中已知的点，所以返回索引即可，投影点一般不在frenet曲线上
        param:  pre_match_index: 上个匹配点的索引
                is_first_run: 标志是否是第一次运行匹配点算法，如果是就从起点搜索，如果不是就从上个周期的匹配点搜索
                xy_list: 笛卡尔坐标系下一系列的点的坐标xy_list = [(x0, y0), (x1, y1), ...)
                frenet_path_node_list: frenet坐标系下路径点信息,指的是全局路径点
                frenet_path_node_list = [(x0, y0, heading0, kappa0), ...],(x, y, 切线与x轴夹角， 曲率)
        return:
                match_point_index_list 匹配点在frenet_path下的编号的集合(即从全局路径第一个点开始数，第几个点是匹配点)
                project_node_list 投影点的信息， project_node_list = [(x_p0, y_p0, heading_p0, kappa_p0), ...]
        """
        i = -1  # 提前定义一个变量用于遍历曲线上的点
        input_xy_length = len(xy_list)
        frenet_path_length = len(frenet_path_node_list)

        match_point_index_list = np.zeros(input_xy_length, dtype="int32")
        project_node_list = []  # 最终长度和input_xy_length应该相同

        if is_first_run is True:
            for index_xy in range(input_xy_length):  # 为每一个点寻找匹配点
                x, y = xy_list[index_xy]
                start_index = 0
                # 用increase_count记录distance连续增大的次数，避免多个局部最小值的干扰
                increase_count = 0
                min_distance = float("inf")
                # 确定匹配点
                for i in range(start_index, frenet_path_length):
                    frenet_node_x, frenet_node_y, _, _ = frenet_path_node_list[i]
                    # 计算(x,y)与(frenet_node_x, frenet_node_y)之间的距离
                    distance = math.sqrt((frenet_node_x - x) ** 2 + (frenet_node_y - y) ** 2)
                    if distance < min_distance:
                        min_distance = distance  # 保留最小值
                        match_point_index_list[index_xy] = i
                        increase_count = 0
                    else:
                        increase_count += 1
                        if increase_count >= 50:  # 向后50个点还没找到的话，说明当前最小值点及时最优的
                            # 第一次运行阈值较大，是为了保证起始点匹配的精确性
                            break
                # 通过匹配点确定投影点
                """
                (x, y)'表示向量转置
                d_v是匹配点（x_m, y_m）指向待投影点（x,y）的向量（x-x_m, y-y_m）
                tou_v是匹配点的单位切向量(cos(theta_m), sin(theta_m))'
                (x_r, y_r)' 约等于 (x_m, y_m)' + (d_v . tou_v)*tou_v
                k_r 约等于 k_m， 投影点曲率
                theta_r 约等于 theta_m + k_m*(d_v . tou_v)， 投影点切线与坐标轴夹角
                具体原理看老王《自动驾驶决策规划算法》第一章第三节
                """
                match_point_index = match_point_index_list[0]
                x_m, y_m, theta_m, k_m = frenet_path_node_list[match_point_index]
                d_v = np.array([x - x_m, y - y_m])
                tou_v = np.array([np.cos(theta_m), np.sin(theta_m)])
                ds = np.dot(d_v, tou_v)
                r_m_v = np.array([x_m, y_m])
                # 根据公式计算投影点的位置信息
                x_r, y_r = r_m_v + ds * tou_v  # 计算投影点坐标
                theta_r = theta_m + k_m * ds  # 计算投影点在frenet曲线上切线与X轴的夹角
                k_r = k_m  # 投影点在frenet曲线处的曲率
                # 将结果打包放入缓存区
                project_node_list.append((x_r, y_r, theta_r, k_r))

        else:
            for index_xy in range(input_xy_length):  # 为每一个点寻找匹配点
                x, y = xy_list[index_xy]
                """
                这里有一个疑问，如果在某个周期内做执行匹配算法时有多个目标点对应多个匹配点，那下一个周期要使用的上个周期的匹配点应该选哪一个比较合适
                这里直接选取的是pre_match_index[index_xy]，index_xy还是新的
                """
                start_index = pre_match_index

                # TODO 判断帧与帧之间的障碍物是否为同一个

                # 用increase_count记录distance连续增大的次数，避免多个局部最小值的干扰
                # TODO 判断是否有上个周期的index结果，没有的话start_index=1, increase_count_limit=50
                increase_count_limit = 5
                increase_count = 0
                # 上个周期匹配点坐标
                pre_match_point_xy = [frenet_path_node_list[start_index][0], frenet_path_node_list[start_index][1]]
                pre_match_point_theta_m = frenet_path_node_list[start_index][2]
                # 上个匹配点在曲线上的切向向量
                pre_match_point_direction = np.array([np.cos(pre_match_point_theta_m), np.sin(pre_match_point_theta_m)])
                # 计算上个匹配点指向当前(x, y）的向量
                pre_match_to_xy_v = np.array([x - pre_match_point_xy[0], y - pre_match_point_xy[1]])
                # 计算pre_match_to_xy_v在pre_match_point_direction上的投影，用于判断遍历方向
                flag = np.dot(pre_match_to_xy_v, pre_match_point_direction)  # 大于零正反向遍历，反之，反方向遍历

                min_distance = float("inf")
                if flag > 0:  # 正向遍历
                    for i in range(start_index, frenet_path_length):
                        frenet_node_x, frenet_node_y, _, _ = frenet_path_node_list[i]
                        # 计算（x,y) 与 （frenet_node_x, frenet_node_y） 之间的距离
                        distance = math.sqrt((frenet_node_x - x) ** 2 + (frenet_node_y - y) ** 2)
                        if distance < min_distance:
                            min_distance = distance  # 保留最小值
                            match_point_index_list[index_xy] = i
                            increase_count = 0
                        else:
                            increase_count += 1
                            if increase_count >= increase_count_limit:  # 为了加快速度，这里阈值为5，第一个周期是不同的，向后5个点还没找到的话，说明当前最小值点及时最优的
                                break
                else:  # 反向遍历
                    for i in range(start_index, -1, -1):  # range(start,end,step)，其中start为闭，end为开，-1为步长
                        frenet_node_x, frenet_node_y, _, _ = frenet_path_node_list[i]
                        # 计算（x,y) 与 （frenet_node_x, frenet_node_y） 之间的距离
                        distance = math.sqrt((frenet_node_x - x) ** 2 + (frenet_node_y - y) ** 2)
                        if distance < min_distance:
                            min_distance = distance  # 保留最小值
                            match_point_index_list[index_xy] = i
                            increase_count = 0
                        else:
                            increase_count += 1
                            if increase_count >= increase_count_limit:
                                break
                # 通过匹配点确定投影点
                match_point_index = match_point_index_list[0]
                x_m, y_m, theta_m, k_m = frenet_path_node_list[match_point_index]
                d_v = np.array([x - x_m, y - y_m])
                tou_v = np.array([np.cos(theta_m), np.sin(theta_m)])
                ds = np.dot(d_v, tou_v)
                r_m_v = np.array([x_m, y_m])
                # 根据公式计算投影点的坐标信息
                x_r, y_r = r_m_v + ds * tou_v
                theta_r = theta_m + k_m * ds
                k_r = k_m
                # 将结果打包放入缓存区
                project_node_list.append((x_r, y_r, theta_r, k_r))

        return list(match_point_index_list), project_node_list



    def get_local_frenet(self, match_point_index: int, frenet_path_node_list: list, back_length=10, forward_length=50):
        """
        根据匹配点确定局部参考线，用于后平滑和局部规划使用
        param:  match_point_index: 当前匹配点(自车位置)在frenet曲线(局离散路径)中的索引
                frenet_path_node_list: 全局路径数据
                back_length: 投影点向后采样点数
                forward_length: 投影点向前采样点数

        return: list类型， local_frenet_path = [node0, node1, node2, ...], node0 = (x0, y0, heading0, kappa0)
        如果前向不够，则向后增加点；如果后向不够，则向前增加点。
        """
        local_frenet_path = []
        length_sum = back_length + forward_length
        if match_point_index < back_length:
            back_length = match_point_index
            forward_length = length_sum - back_length

        if (len(frenet_path_node_list) - match_point_index) - 1 < forward_length:
            forward_length = len(frenet_path_node_list) - match_point_index - 1
            back_length = length_sum - forward_length

        # 返回这个区间的node
        local_frenet_path = frenet_path_node_list[match_point_index - back_length: match_point_index] \
                            + frenet_path_node_list[match_point_index: match_point_index + forward_length + 1]

        return local_frenet_path


    def cal_s_map_fun(self, local_path_opt: list, origin_xy: tuple):
        """
        即index2s
        计算参考线上每个节点与s的映射关系,用于算出sl图的s坐标，以车辆当前投影点为原点，不是以参考线的起点。 s就是位矢，用折线来拟合
        param:  local_path_opt: 优化后的frenet参考线[(x, y, theta, kappa), ...]
                origin_xy: 车辆当前的位置
        return: s_map: list类型 和输入的参考线长度相同
        """
        # 计算以车辆当前位置投影点为起点的s_map
        origin_match_index, _ = match_projection_points([origin_xy], local_path_opt)
        # 通过车辆定位位置，计算其在参考线上的匹配点索引和投影点信息，match_projection_points处理的是一系列点的列表，
        # 因此输入要为列表形式，输出也是列表形式，但是里面只有一个元素(当前位置)，因此索引第一位就行了
        origin_match_index = origin_match_index[0]
        ref_s_map = [0]
        # 先计算以参考线起点为起点的ref_s_map（note：累积位移差）
        for i in range(1, len(local_path_opt)):
            s = math.sqrt((local_path_opt[i][0] - local_path_opt[i - 1][0]) ** 2
                          + (local_path_opt[i][1] - local_path_opt[i - 1][1]) ** 2) + ref_s_map[-1]
            ref_s_map.append(s)
        # print("ref_s_map", ref_s_map)
        # 然后算出在车辆当前位置投影点相对于参考线起点的s, 记为s0（note：就是自车现在在s图的哪个地方）
        s0 = cal_projection_s_fun(local_path_opt, [origin_match_index], [origin_xy], ref_s_map)
        # ref_s_map 每一项都减去s0，这样就得到了所有匹配点相对于车辆投影点的s映射（note：自车为原点）
        s_map = np.array(ref_s_map) - s0[0]
        return list(s_map)

    def cal_s_l_fun(self, obs_xy_list: list, local_path_opt: list, s_map: list):
        """
        这是坐标转换的通用模块
        坐标转换第一部分，计算S,L
        将坐标转化为S-L坐标,可以使任何要坐标转化的对象
        基本步骤是
        0.确定车辆当前位置的投影作为坐标原点
        1.确定每个点的在参考线上的匹配点和投影点；
        2.计算S,S是投影点距离规划起点的位矢，就是连接这些离散点的折线长度；
        3.计算L,即障碍物与投影点的距离
        param:  obs_xy_list: 给定一些待投影到SL图的对应点点的坐标
                local_path_opt: 优化后的参考线[(x_opt0, y_opt0, theta_0, kappa_0), ... ]
                s_map
        return: s_list 和 l_list
        """

        # 计算这些障碍物点在当前参考线中匹配点的索引和投影点信息
        match_index_list, projection_list = match_projection_points(obs_xy_list, local_path_opt)

        s_list = cal_projection_s_fun(local_path_opt, match_index_list, obs_xy_list, s_map)  # 得到障碍点的s

        # 下面是计算l, 这里计算l和下面一个计算导数的函数有重复，以后可以考虑删除
        l_list = []

        for i in range(len(obs_xy_list)):
            pro_x, pro_y, theta, kappa = projection_list[i]  # 投影点的信息,坐标轴上的点
            n_r = np.array([-math.sin(theta), math.cos(theta)])  # 投影点的单位法向量（note：和单位向量乘为0）
            x, y = obs_xy_list[i][0], obs_xy_list[i][1]  # 待投影的位置
            r_h = np.array([x, y])  # 车辆实际位置的位矢
            r_r = np.array([pro_x, pro_y])  # 投影点的位矢
            # 核心公式: l*n_r = r_h - r_r
            # TODO 将左手系改为右手系，使得SL图为常见方向
            l_list.append(np.dot(r_h - r_r, n_r))  # *UE4定义的是左手系，所以在车辆左侧的为负值(SL图是反的)*

        return s_list, l_list


    def get_start_state(self, xy_list: list, V_xy_list: list, a_xy_list: list, local_path_xy_opt: list, origin_xy: tuple):
        """
        功能：获取赏上一次规划的初始值（dl、ddl、dddl）
        """

        # note：注意这里计算的是目标参考线上的状态量，只能使用在参考线上的规划

        # 计算这些障碍物点在当期参考线中匹配点的索引和投影点信息
        match_index_list, projection_list = match_projection_points(xy_list, local_path_xy_opt)

        l_list = []  # store l
        dl_list = []  # store the derivative of l, dl/dt
        ds_list = []  # store the derivative of s, ds/dt
        ddl_list = []  # store the  second order derivative of l, d(dl/dt)/dt
        l_ds_list = []  # store the arc differential of l, dl/ds
        dds_list = []  # store the second order derivative of s, d(ds/dt)/dt
        l_dds_list = []  # store the second order arc differential of l, d(dl/ds)/ds
        for i in range(len(xy_list)):
            x, y, theta, kappa = projection_list[i]  # 投影点的信息
            nor_r = np.array([-math.sin(theta), math.cos(theta)])  # 投影点的单位法向量  **************************************
            tou_r = np.array([math.cos(theta), math.sin(theta)])  # 投影点的单位切向量
            r_h = np.array([origin_xy[0], origin_xy[1]])  # 车辆实际位置的位矢
            r_r = np.array([x, y])  # 投影点的位置矢

            """1.calculate l"""
            l = np.dot(r_h - r_r, nor_r)
            l_list.append(l)

            """2.calculate dl"""
            # 速度投影到法向量处（横向的速度）
            Vx, Vy = V_xy_list[i]
            V_h = np.array([Vx, Vy])  # 速度矢量
            dl = np.dot(V_h, nor_r)
            dl_list.append(dl)  # l对时间的导数

            """3.计算s对时间的导数"""
            # note：除数是横向偏移的比例，偏移l就少走了（R-l）/R -> （1-kappa*l）
            # 把切向速度移动到参考线上
            ds = np.dot(V_h, tou_r) / (1 - kappa * l_list[i])
            ds_list.append(ds)

            """4.计算l对时间的二阶导数"""
            # note：有一个几何曲率推导
            ax, ay = a_xy_list[i]
            a_h = np.array([ax, ay])
            ddl = np.dot(a_h, nor_r) - kappa * (1 - kappa * l) * (ds ** 2)
            ddl_list.append(ddl)

            """5.calculate the arc differential of l"""
            # note：l/ds (切向)     需要
            #  向量法做cartesian与frenet的转换要更简单，但是也有缺点，向量法必须依赖速度加速度
            #  l' = l_dot/s_dot 但是如果s_dot = 0 此方法就失效了
            if abs(ds) < 1e-6:
                l_ds = 0
            else:
                l_ds = dl_list[i] / ds
            l_ds_list.append(l_ds)

            """6.calculate the second order derivative of s"""
            # note：几何推导
            ax, ay = a_xy_list[i]
            a_h = np.array([ax, ay])
            kappa_ds = 0  # dk/ds, for simplicity, make it to be zero
            dds = (np.dot(a_h, tou_r) + 2 * (ds ** 2 * kappa * l_ds) + ds ** 2 * kappa_ds * l) / (1 - kappa * l)
            dds_list.append(dds)

            """7.the second order derivative of s"""
            # note:l/dds (弯曲程度、平滑度)   需要
            if abs(ds) < 1e-6:
                l_dds = 0
            else:
                l_dds = (ddl - l_ds * dds) / (ds ** 2)
            l_dds_list.append(l_dds)

        return l_list, dl_list, ds_list, ddl_list, l_ds_list, dds_list, l_dds_list



    def frenet_2_x_y_theta_kappa(self):
        """
        首先进行必要的坐标转换
        将增加采样点后动态规划得到的s-l路径转换为直角坐标系下路径信息x, y, theta, kappa
        param:  plan_start_s: 规划起点的s,l
                plan_start_l:
                enriched_s_list: 增加采样点后的s,l
                enriched_l_list:
                frenet_path_opt: 优化后的参考线[(x, y, theta, kappa), ... ]
                s_map: 参考线对应的s_map
        return: 直角坐标系下的路径列表，list类型[(x, y, theta, kappa), ...]
        """
        # note:存下路径信息等待下次使用
        pass


    def set_sampling_range(self):
        """
        功能：现在先确定间隔的情况下去计算纵向和横向的范围
            note:这是针对现在的换道研究的函数
        输入：
            dynamic_map: 动态地图
            start_l: 距离参考线的横向位置（最大的横向规划范围 0～start_l）最大取3.5
            flow_speed: 交通流的速度（用于确定最大的纵向距离）
        """
        # 横向距离
        # temp:先这样采样，后续有问题再调整（50m是够用的）
        l_samples = np.arange(0, 3.5 + 1e-6, self.sample_l)
        s_samples = np.arange(0, 50 + 1e-6, self.sample_s)

        return l_samples, s_samples



    def DP_algorithm(self,plan_start_s, plan_start_l, plan_start_dl, plan_start_ddl, s_samples, l_samples, sampling_res=2,
                 w_collision_cost=1e12, w_smooth_cost=[300, 1000, 5000], w_reference_cost=20,
                 row=12, col=6, sample_s=15, sample_l=1.5):
        """
        功能：栅格式动态规划，注意这里可以进行轨迹决策
        TODO（4.25）：不考虑交互的情况应该是分成两个状态
            1.获得路权前：与后车的速度强交互   路径规划按照避开后车障碍的规划就行（可达集合膨胀）
            2.获得路权后：速度规划依附于前车（ST？RSS？）   路径规划需要进行位姿级别的后车防撞（或者工程简化？）

            速度规划先简化成RSS确定避免碰撞

        TODO：
            使用dcarl的情况应该是记录下在这个规划过程的几个？（s、l）对   越接近的越要选   暂时规定就是轨迹的中点和最后一个点
        """
        # 格式性占位
        obs_s_list = []
        obs_l_list = []

        """-----------------添加的固定性栅格-------------------------"""
        candidate_s = s_samples
        candidate_l = l_samples

        row = len(candidate_l)
        col = len(candidate_s)
        """-------------------------------------------------------"""

        # 声明一个二维数组记录每个采样点的cost,初始化为无穷大
        cost = np.ones(shape=(row, col)) * np.inf
        # 声明另一个二维数组，记录规划起点距离当前位置的最短路径的前一个位置
        # ori: pre_node_index = (row >> 1) ** np.ones(shape=(row, col), dtype="int32")     # row >> 1相当于row除2并向下取整
        pre_node_index = np.ones(shape=(row, col), dtype="int32")  # 初始化，所有节点的上个最优节点的行号都是0，也就是起点
        # 计算起点到第一列的cost
        for i in range(row):
            # note:改成直接给的l
            cost[i][0] = DP_utils.cal_start_cost(obs_s_list, obs_l_list,
                                        begin_s=plan_start_s, begin_l=plan_start_l,
                                        begin_dl=plan_start_dl, begin_ddl=plan_start_ddl,
                                        cur_node_row=candidate_l[i], row=row, sample_s=sample_s, sample_l=sample_l,
                                        w_cost_collision=w_collision_cost,
                                        w_cost_smooth=w_smooth_cost,
                                        w_cost_ref=w_reference_cost)
        # 计算后面几列的cost
        for j in range(1, col):
            # print("current col: %d" % j)
            for i in range(row):
                # print("current row: %d" % i)
                # 计算当前node的sl
                # cur_node_s = plan_start_s + (j + 1) * sample_s
                # cur_node_l = ((row + 1) / 2 - 1 - i) * sample_l
                cur_node_s = candidate_s[j]
                cur_node_l = candidate_l[i]
                # 在carla的坐标环境下建立的frenet坐标，前进方向的左侧l是负的，所以row/2 ~ row之间的行号代表左转，0~row/2代表右转
                # 遍历前一列的节点
                for k in range(row):
                    # pre_node_s = plan_start_s + j * sample_s
                    # pre_node_l = ((row + 1) / 2 - 1 - k) * sample_l
                    pre_node_s = candidate_s[j-1]
                    pre_node_l = candidate_l[k]
                    cost_neighbor = DP_utils.cal_neighbor_cost(obs_s_list, obs_l_list, pre_node_s, pre_node_l,
                                                      cur_node_s=cur_node_s, cur_node_l=cur_node_l, sample_s=sample_s,
                                                      w_cost_collision=w_collision_cost,
                                                      w_cost_smooth=w_smooth_cost,
                                                      w_cost_ref=w_reference_cost)
                    # 起点到上一个节点的最小代价为cost[k][j - 1]
                    pre_min_cost = cost[k][j - 1]
                    # 再加上node[k][j-1]到node[i][j]的代价(k=1,2,3,...)中最小的
                    cost_temp = pre_min_cost + cost_neighbor
                    # print(cost_temp)
                    # note：遍历前序节点下得到当下最小开销（前序开销加相邻开销），同时记录前序最小的序号
                    if cost_temp < cost[i][j]:
                        cost[i][j] = cost_temp
                        pre_node_index[i][j] = k
        # 确定最优路径
        DP_row_index_list = []
        min_index = cost[:, -1].argmin()  # 选择最后一列中最小元素的索引
        # print(min_index)
        if cost[:, -1].min() > w_collision_cost:  # 找不到无碰撞路径，提示运行错误
            print("********************     can't find a feasible path      ********************")
            # raise RuntimeError("********************can't find a feasible path*********************************")
        DP_row_index_list.append(min_index)
        for i in range(col - 1, 0, -1):  # 倒数第二列col-1遍历到第一列,别把索引提取错了，
            # DP_row_index_list中第一列记录的是起点的相对位置，是车辆已经通过的位置，不在路径考虑的范围内
            # print(min_index)
            min_index = pre_node_index[min_index][i]  # 通过后一列的min_index行更新当前列的min_index行
            DP_row_index_list.append(min_index)
        # DP_row_index_list中的第一位是规划起点后的采样的第一列的某个节点，这里没有加入规划起点，规划起点在enrich_DP_s_l中再考虑
        DP_row_index_list.reverse()

        # 将数组中的索引转化为s-l
        # print("DP_row_index_list: ", DP_row_index_list)
        DP_s_list = []
        DP_l_list = []
        for i in range(len(DP_row_index_list)):
            # 改成候选采样的形式
            # DP_s_list.append(plan_start_s + (i + 1) * sample_s)
            # DP_l_list.append(((row + 1) / 2 - 1 - DP_row_index_list[i]) * sample_l)
            DP_s_list.append(candidate_s[i])
            DP_l_list.append(candidate_l[DP_row_index_list[i]])
        # 初步的动态规划密度不够，相邻点之间在五次多项式的基础上间隔sampling_res米进行采样
        enriched_dp_s, enriched_dp_l = DP_utils.enrich_DP_s_l(DP_s_list, DP_l_list,
                                                     plan_start_s, plan_start_l, plan_start_dl, plan_start_ddl,
                                                     resolution=sampling_res)

        return enriched_dp_s, enriched_dp_l


    def run_step(self, dynamic_map, is_first_plan):
        # fixme：这段废弃
        """
        功能：对输入的动态地图做处理，进行路径规划
        逻辑：
            1.获取目标道路的全局路径
            2.对路径进行处理变成x_y_theta_kappa
            3.找到全局路径下的自车的match——point，向前后采30个点
            4.以自车为原点建立SL坐标
            5.找到起始的状态进行路径规划（对后车的避碰？）
            6.速度规划（博弈加与否、或者直接强化学习尝试）
        """
        # 1.获取全局路径(针对当前换道研究的目标道路)
        global_path = dynamic_map.lanes[TARGET_LANE_INDEX]

        # 2.第一次规划把全局路径转化
        if is_first_plan:
            target_path =  self.waypoint_list_2_target_path(global_path.central_path_array)

        # 3.寻找match_point
        current_ego_x = dynamic_map.ego_vehicle.x
        current_ego_y = dynamic_map.ego_vehicle.y
        current_ego_vx = dynamic_map.ego_vehicle.vx
        current_ego_vy = dynamic_map.ego_vehicle.vy
        current_ego_ax = dynamic_map.ego_vehicle.ax
        current_ego_ay = dynamic_map.ego_vehicle.ay

        # fixme:结束后记得把上次的match_point编号给到
        match_point_list, _ = self.find_match_points(xy_list=[(current_ego_x, current_ego_y)],
                                                               frenet_path_node_list=self.global_x_y_theta_kappa,
                                                               is_first_run=is_first_plan,  # 寻找车辆起点的匹配点就属于第一次运行，
                                                               pre_match_index=self.last_match_point_index)  # 没有上一次运行得到的索引，索引自然是全局路径的起点

        # 4.建立局部的坐标系，根据匹配点的索引在全局路径上采样一定数量的点（note:返回局部路径点）
        # note:可能会采样范围不够
        local_frenet_path = self.get_local_frenet(match_point_list[0], self.global_x_y_theta_kappa,
                                                     back_length=10, forward_length=20)

        """=======相较于原先的这里没有做参考线的平滑，但是不会影响========"""

        # 5.建立局部坐标系的s坐标（路点对走过距离s的映射）note:这一步转成自车为s坐标原点
        s_map = self.cal_s_map_fun(local_frenet_path, (current_ego_x, current_ego_y))

        # 计算规划起点的s, l
        begin_s_list, begin_l_list = self.cal_s_l_fun([(current_ego_x, current_ego_y)], local_frenet_path, s_map)
        # 计算规划开始的l_ds、l_dds(theta、kappa)
        # fixme:最后一个传入参数是否多余？
        l_list, _, _, _, l_ds_list, _, l_dds_list = \
            self.get_start_state(xy_list=[(current_ego_x, current_ego_y)],
                                            V_xy_list=[(current_ego_vx, current_ego_vy)],
                                            a_xy_list=[(current_ego_ax, current_ego_ay)],
                                            local_path_xy_opt=local_frenet_path,
                                            origin_xy=(current_ego_x, current_ego_y))

        l_samples, s_samples = self.set_sampling_range()
        # 不需要去掉首位
        # l_samples = l_samples[1:]
        s_samples = s_samples[1:]

        # temp:后车的避障
        static_obs_xy = []
        if len(global_path.rear_vehicles) > 0:
            rear_vehicle = global_path.rear_vehicles[0]
            static_obs_xy.append((rear_vehicle.x, rear_vehicle.y))
        obs_s_list, obs_l_list = self.cal_s_l_fun(static_obs_xy, local_frenet_path, s_map)

        # note：需求初始横纵向偏移、初始曲率、初始曲率变化率（全局路径）
        dp_path_s, dp_path_l = self.DP_algorithm(plan_start_s=begin_s_list[0],
                                                 plan_start_l=l_list[0],
                                                 plan_start_dl=l_ds_list[0],
                                                 plan_start_ddl=l_dds_list[0],
                                                 s_samples=s_samples,
                                                 l_samples=l_samples)



        pass


    def get_front_st(self, dynamic_map, reference_trajectory):
        """
        功能：对五次多项式撒点得到的路径进行参考线建系，算出前车的ST图对齐，对后续博弈MPC规划进行约束
        输入：
            dynamic_map：动态地图
            reference_trajectory：五次多项式规划出来的参考轨迹
        逻辑：
            1.把参考路径转化成sl图
            2.TODO(4.27)：把前车的纵向运动（预测？）进行时间推移得到和后续速度规划的相同（s_list、t_list）
        输出：
            obs_st_in_list:前车障碍物对进入自车轨迹的S
            obs_st_sout_list:出去的S
            obs_st_tin_list:进入的时间
            obs_st_tout_list:出去的时间
        """
        # fixme：前车是否在规划的路径里以及规划出去怎么办
        # x_y_theta_kappa形式(这就是规划的local_frent_net)
        target_path = self.waypoint_list_2_target_path(reference_trajectory)

        # 建立局部坐标系的s坐标（路点对走过距离s的映射）note:这一步转成自车为s坐标原点
        current_ego_x = dynamic_map.ego_vehicle.x
        current_ego_y = dynamic_map.ego_vehicle.y
        s_map = self.cal_s_map_fun(target_path, (current_ego_x, current_ego_y))


        """---------------------------------把冲突点转到我的st图里---------------------------------------------"""
        # 获取前车
        target_lane = dynamic_map.lanes[TARGET_LANE_INDEX]
        if len(target_lane.front_vehicles):
            fv = target_lane.front_vehicles[0]
        else:
            fv = None
        # 匀速运动预测前车车屁股
        front_tail_set = self.predict_front_vehicle_st(front_vehicle=fv)

        front_tail_s, front_tail_l= self.cal_s_l_fun(obs_xy_list=front_tail_set,
                                         local_path_opt=target_path,
                                         s_map=s_map)

        # 获取后车
        if len(target_lane.rear_vehicles):
            rv = target_lane.rear_vehicles[0]
        else:
            rv = None
        # 对后车的加速度预测
        rear_head_set = self.predict_rear_vehicle_st(rear_vehicle=rv)
        rear_head_s, rear_head_l = self.cal_s_l_fun(obs_xy_list=rear_head_set,
                                                    local_path_opt=target_path,
                                                    s_map=s_map)
        """-----------------------------------------------------------------------------------------------"""

        # 计算自车角点距离
        ego_length = dynamic_map.ego_vehicle.boxx
        ego_width = dynamic_map.ego_vehicle.boxy
        pose_safe_dis = np.sqrt(ego_length**2 + ego_width**2)/4



        pass


        # return obs_st_sin_list, obs_st_sout_list, obs_st_tin_list, obs_st_tout_list


    def predict_front_vehicle_st(self, front_vehicle, predict_t = 2, predict_res = 0.1):
        """
        note:应该是近端后角点进行转换
        功能：对前车进行纵向位置离散化预测
        输入：前车（vehicle类别），可能是NONE
             预测的时间
             离散化时间 dt=0.1
        输出：一段离散时间内（21个点）的车屁股中心点
        """

        if front_vehicle is not None:
            vehicle_length = front_vehicle.boxx
            vehicle_width = front_vehicle.boxy

            current_x = front_vehicle.x
            # 近端角点
            current_y = front_vehicle.y + vehicle_width / 2
            current_veh_tail = current_x - vehicle_length / 2

            current_v = front_vehicle.v

            # 匀速运动
            # note:这里要考虑是不是会维度不对齐（21个位置）
            delta_x = predict_res * current_v
            future_tail_positions = np.arange(current_veh_tail, current_veh_tail+current_v*predict_t+delta_x, delta_x)

            future_tail_point = []
            for i in range(len(future_tail_positions)):
                # fixme:这只针对当下的换道研究
                future_tail_point.append((future_tail_positions[i], current_y))

        else:
            # 无前车，前向约束不起效
            future_tail_positions = np.full(21, 500)

            future_tail_point = []
            for i in range(len(future_tail_positions)):
                # fixme:这只针对当下的换道研究
                future_tail_point.append((future_tail_positions[i], 204))

        return future_tail_point


    def predict_rear_vehicle_st(self, rear_vehicle, acc = 0, predict_t = 2, predict_res = 0.1):
        """
        note:应该是近端前角点进行转换
        功能：对后车进行纵向位置离散化预测
        输入：后车（vehicle类别），可能是NONE
             预测时间内的加速度
             预测的时间
             离散化时间 dt=0.1
        输出：一段离散时间内（21个点）的车屁股中心点
        """

        if rear_vehicle is not None:
            vehicle_length = rear_vehicle.boxx
            vehicle_width = rear_vehicle.boxy

            current_x = rear_vehicle.x
            # 近端角点
            current_y = rear_vehicle.y + vehicle_width / 2
            current_veh_tail = current_x + vehicle_length / 2

            current_v = rear_vehicle.v

            # 这里改成加速度
            # note:这里要考虑是不是会维度不对齐（21个位置）
            delta_x = predict_res * current_v + (acc*predict_res**2)/2

            future_tail_positions = np.arange(current_veh_tail, current_veh_tail+current_v*predict_t+delta_x, delta_x)

            future_tail_point = []
            for i in range(len(future_tail_positions)):
                # fixme:这只针对当下的换道研究
                future_tail_point.append((future_tail_positions[i], current_y))

        else:
            # 无前车，前向约束不起效
            future_tail_positions = np.full(21, -500)

            future_tail_point = []
            for i in range(len(future_tail_positions)):
                # fixme:这只针对当下的换道研究
                future_tail_point.append((future_tail_positions[i], 204))

        return future_tail_point





