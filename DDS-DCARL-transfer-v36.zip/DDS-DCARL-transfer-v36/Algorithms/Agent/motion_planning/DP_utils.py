import numpy as np

def cal_quintic_coefficient(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s):
    """  已验证
    给定六个边界条件， 计算五次多项式的系数
    l = a0 + a1*s + a2*s^2 + a3*s^3 + a4*s^4 + a5*s^5
    dl = a1 + 2*a2*s + 3*a3*s^2 + 4*a4*s^3 + 5*a5*s^4
    ddl = 2*a2 + 6*a3*s + 12*a4*s^2 + 20*a5*s^3
    构建矩阵，通过矩阵运算求出系数
    B = A@coeffi    @矩阵乘法
    B.shape=(6,1)
    A.shape=(6,6)
    coeffi.shape=(6, 1)
    param:  start_l:
            start_dl:
            start_ddl:
            end_l:
            end_dl:
            end_ddl:
            start_s:
            end_s:
    return: 五次多项式的系数，列表类型
    """
    A = np.array(
        [[1, start_s, pow(start_s, 2), pow(start_s, 3), pow(start_s, 4), pow(start_s, 5)],
         [0, 1, 2 * start_s, 3 * pow(start_s, 2), 4 * pow(start_s, 3), 5 * pow(start_s, 4)],
         [0, 0, 2, 6 * start_s, 12 * pow(start_s, 2), 20 * pow(start_s, 3)],
         [1, end_s, pow(end_s, 2), pow(end_s, 3), pow(end_s, 4), pow(end_s, 5)],
         [0, 1, 2 * end_s, 3 * pow(end_s, 2), 4 * pow(end_s, 3), 5 * pow(end_s, 4)],
         [0, 0, 2, 6 * end_s, 12 * pow(end_s, 2), 20 * pow(end_s, 3)]]
    )
    B = np.array([start_l, start_dl, start_ddl, end_l, end_dl, end_ddl])
    B = B.reshape((6, 1))
    coeffi = np.linalg.inv(A) @ B
    return list(coeffi.squeeze())


def enrich_DP_s_l(DP_s_list, DP_l_list, plan_start_s, plan_start_l, plan_start_dl, plan_start_ddl, resolution=1):
    """  已验证
    由于采样点有时候比较稀疏，所以需要在相邻五次多项式曲线上进行采样，增加轨迹带点数（轨迹增密）
    param:  DP_s_list: 动态规划得到的s,l
            DP_l_list:
            plan_start_s: 规划起点的s, l, dl, ddl
            plan_start_l:
            plan_start_dl:
            plan_start_ddl:
            resolution:  在五次多项式上的采样间隔
    return: enriched_s_list, enriched_l_list 增密后的s_list l_list
    """
    enriched_s_list = []
    enriched_l_list = []
    start_s = plan_start_s
    start_l = plan_start_l
    start_dl = plan_start_dl
    start_ddl = plan_start_ddl

    end_s = DP_s_list[0]
    end_l = DP_l_list[0]
    end_dl = 0
    end_ddl = 0
    coeffi = cal_quintic_coefficient(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s)

    """ 采样间隔为resolution， 采样的个数就是终点和起点的差值取整，下面用矩阵运算，加快速度"""
    # 考虑规划起点
    s = start_s + np.arange(0, int(end_s - start_s), resolution)  # 采样间隔为resolution米时，采样的个数就是终点和起点的差值取整
    l0 = coeffi[0] + coeffi[1] * s + coeffi[2] * (s ** 2) + coeffi[3] * (s ** 3) + coeffi[4] * (s ** 4) + \
        coeffi[5] * (s ** 5)
    enriched_s_list = enriched_s_list + list(s)
    enriched_l_list = enriched_l_list + list(l0)
    # 规划起点后的其他点
    for i in range(1, len(DP_s_list)):
        start_s = DP_s_list[i - 1]
        start_l = DP_l_list[i - 1]
        start_dl = 0
        start_ddl = 0

        end_s = DP_s_list[i]
        end_l = DP_l_list[i]
        end_dl = 0
        end_ddl = 0
        coeffi = cal_quintic_coefficient(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s)

        s = start_s + np.arange(0, int(end_s - start_s), resolution)  # 采样间隔为一米时， 采样的个数就是终点和起点的差值取整
        li = coeffi[0] + coeffi[1] * s + coeffi[2] * (s ** 2) + coeffi[3] * (s ** 3) + coeffi[4] * (s ** 4) + \
            coeffi[5] * (s ** 5)
        enriched_s_list = enriched_s_list + list(s)
        enriched_l_list = enriched_l_list + list(li)

    enriched_s_list += [end_s]
    enriched_l_list += [end_l]

    return enriched_s_list, enriched_l_list




def cal_start_cost(obs_s_list, obs_l_list,
                   begin_s, begin_l, begin_dl, begin_ddl,
                   cur_node_row, row,
                   sample_s, sample_l,
                   w_cost_collision, w_cost_smooth, w_cost_ref
                   ):
    """  已验证
    计算当前位置的cost
    参数和DP_algorithm基本一致
    param:  obs_s_list: 障碍物的s-l信息
            obs_l_list:
            begin_s: 规划起点的s-l信息
            begin_l:
            begin_dl:
            begin_ddl:
            cur_node_row:当前节点所在行
            row: 动态规划采样点的行数
            sample_s: 沿着s方向的采样间隔和沿着l方向的采样间隔
            sample_l:
            w_cost_collision: 障碍物距离代价权重
            w_cost_smooth: 平滑代价权重，列表类型【w_dl_cost, w_ddl_cost, w_dddl_cost】考虑到s-l曲线的三阶导数
            w_cost_ref: 参考线代价权重
    return: 规划起点到当前位置的代价cost
    """
    """下面是动态规划的一个示意图，b代表规划起点,中间是参考线，总共有采样五行（参考线上的采的点没有标出来）
    sample_s, sample_l分别代表沿着s方向的采样间隔和沿着l方向的采样间隔
    将采样的点存入矩阵，然后进行动态规划
        . . . . .
        . . . . .
     b  ---------reference line
        . . . . .
        . . . . .
    """
    # 五次多项式起点的边界条件
    start_l = begin_l
    start_dl = begin_dl
    start_ddl = begin_ddl
    start_s = begin_s
    # 终点的边界条件
    # (row + 1) / 2 - 1 代表中间的行号,比如row=3,则:
    # . . .
    # . . .  中间的行号 = (row + 1) / 2 - 1 = 1
    # . . .
    # end_l = ((row + 1) / 2 - 1 - cur_node_row) * sample_l  # 动态规划是在参考线两边均匀采点，l是有正负之分的，这里矩阵的行列都是整的，所以对应上l要做转换
    end_l = cur_node_row
    end_dl = 0
    end_ddl = 0
    end_s = begin_s + sample_s

    # 计算五次多项式的系数
    coeffi = cal_quintic_coefficient(start_l, start_dl, start_ddl, end_l, end_dl, end_ddl, start_s, end_s)
    # 在五次多项式构成的曲线上采样十个点计算cost
    s = np.zeros(shape=(10, 1))
    # l = np.zeros(shape=(10, 1))  # reserve memory space
    # dl = np.zeros(shape=(10, 1))
    # ddl = np.zeros(shape=(10, 1))
    # dddl = np.zeros(shape=(10, 1))
    # 计算s
    for i in range(10):
        s[i][0] = start_s + i * sample_s / 10  # 先从起点离散采样s, 然后通过五次多项式计算每一点的l, dl, ddl, dddl
    l = coeffi[0] + coeffi[1] * s + coeffi[2] * (s ** 2) + coeffi[3] * (s ** 3) + coeffi[4] * (s ** 4) + \
        coeffi[5] * (s ** 5)
    dl = coeffi[1] + 2 * coeffi[2] * s + 3 * coeffi[3] * (s ** 2) + 4 * coeffi[4] * (s ** 3) + 5 * coeffi[5] * (s ** 4)
    ddl = 2 * coeffi[2] + 6 * coeffi[3] * s + 12 * coeffi[4] * (s ** 2) + 20 * coeffi[5] * (s ** 3)
    dddl = 6 * coeffi[3] + 24 * coeffi[4] * s + 60 * coeffi[5] * (s * 2)
    cost_smooth = w_cost_smooth[0] * (dl.T @ dl) + w_cost_smooth[1] * (ddl.T @ ddl) + w_cost_smooth[2] * (dddl.T @ dddl)  # 平滑代价
    cost_ref = w_cost_ref * (l.T @ l)  # 参考线代价
    # 计算障碍物代价
    # temp:障碍物先不实现先
    # cost_collision = 0
    # for i in range(len(obs_s_list)):  # 把每个障碍物都遍历一遍
    #     d_lon = obs_s_list[i] - s
    #     d_lat = obs_l_list[i] - l
    #     square_d = d_lon ** 2 + d_lat ** 2  # 这里直接在曲线上近似,实际上应该是计算两点之间的直线，在直角坐标系下进行（x1-x2)**2+(y1-y2)**2，
    #     # 但是考虑量采样点之间的五次多项式一般较平缓，我们就直接近似，简化计算
    #     # print(square_d)
    #     cost_collision += cal_obs_cost(w_cost_collision, square_d)
    #     # TODO 判断障碍物的左右
    #     if cost_collision > cost_collision:
    #         break

    return cost_smooth + cost_ref


def cal_neighbor_cost(obs_s_list, obs_l_list, pre_node_s, pre_node_l,
                      cur_node_s, cur_node_l, sample_s,
                      w_cost_collision, w_cost_smooth, w_cost_ref):
    """  已验证
    计算当前位置的cost
    参数和DP_algorithm基本一致
    param:  obs_s_list: 障碍物的s-l信息
            obs_l_list:
            pre_node_s: 的s-l信息
            pre_node_l:
            cur_node_s:当前节点s
            cur_node_l:当前节点l
            sample_s: 沿着s方向的采样间隔
            w_cost_collision: 障碍物距离代价权重
            w_cost_smooth: 平滑代价权重，列表类型[w_dl_cost, w_ddl_cost, w_dddl_cost]考虑到s-l曲线的三阶导数
            w_cost_ref: 参考线代价权重
    return: 规划起点到当前位置的代价cost
    """
    """下面是动态规划的一个示意图，b代表规划起点,中间是参考线，总共有采样五行（参考线上的采的点没有标出来）
    sample_s, sample_l分别代表沿着s方向的采样间隔和沿着l方向的采样间隔
    将采样的点存入矩阵，然后进行动态规划
        . . . . .
        . . . . .
     b  ---------reference line
        . . . . .
        . . . . .
    """
    # 五次多项式起点的边界条件
    start_l = pre_node_l
    start_dl = 0
    start_ddl = 0
    start_s = pre_node_s
    # 终点的边界条件
    end_l = cur_node_l  # 动态规划是在参考线两边均匀采点，l是有正负之分的，这里矩阵的行列都是整的，所以对应上l要做转换
    end_dl = 0
    end_ddl = 0
    end_s = cur_node_s

    # 计算五次多项式的系数
    coeffi = cal_quintic_coefficient(start_l, start_dl, start_ddl,
                                                    end_l, end_dl, end_ddl, start_s, end_s)
    # 在五次多项式构成的曲线上采样十个点计算cost
    s = np.zeros(shape=(10, 1))
    # l = np.zeros(shape=(10, 1))  # reserve memory space
    # dl = np.zeros(shape=(10, 1))
    # ddl = np.zeros(shape=(10, 1))
    # dddl = np.zeros(shape=(10, 1))
    # 计算s
    for i in range(10):
        s[i][0] = start_s + i * sample_s / 10
    l = coeffi[0] + coeffi[1] * s + coeffi[2] * (s ** 2) + coeffi[3] * (s ** 3) + coeffi[4] * (s ** 4) + coeffi[5] * (
            s ** 5)
    dl = coeffi[1] + 2 * coeffi[2] * s + 3 * coeffi[3] * (s ** 2) + 4 * coeffi[4] * (s ** 3) + 5 * coeffi[5] * (s ** 4)
    ddl = 2 * coeffi[2] + 6 * coeffi[3] * s + 12 * coeffi[4] * (s ** 2) + 20 * coeffi[5] * (s ** 3)
    dddl = 6 * coeffi[3] + 24 * coeffi[4] * s + 60 * coeffi[5] * (s * 2)
    cost_smooth = w_cost_smooth[0] * (dl.T @ dl) + w_cost_smooth[1] * (ddl.T @ ddl) + w_cost_smooth[2] * (dddl.T @ dddl)  # 平滑代价
    # print(l)
    cost_ref = w_cost_ref * (l.T @ l)  # 参考线代价
    # 计算障碍物代价
    # cost_collision = 0
    # for i in range(len(obs_s_list)):  # 把每个障碍物都遍历一遍
    #     d_lon = obs_s_list[i] - s
    #     d_lat = obs_l_list[i] - l
    #     square_d = d_lon ** 2 + d_lat ** 2  # 这里直接在曲线上近似,实际上应该是计算两点之间的直线，在直角坐标系下进行（x1-x2)**2+(y1-y2)**2，
    #     # 但是考虑量采样点之间的五次多项式一般较平缓，我们就直接近似，简化计算,
    #     # TODO 这里有时会出现问题，就是曲线扭曲时误差较大，导致无法找到无碰撞路径，后面要考虑把这部分优化掉
    #     cost_collision += cal_obs_cost(w_cost_collision, square_d)
    # print(cost_smooth, cost_collision, cost_ref)
    return cost_smooth + cost_ref