"""
    路口轨迹规划器: 专为路口场景设计，处理复杂的交叉口路径规划
    单一类实现所有功能
    搭配 dynamic_map.update_map_from_obs 使用
"""
import numpy as np
import bisect
import copy
import time

from Agent.tools_dds.tools import *
from Agent.tools_dds.predict import predict
from Agent.tools_dds.frenet import *
from Agent.tools_dds.actions import TrajectoryAction
from Agent.tools_dds.cubic_spline_planner import Spline2D 

# Parameter
MAX_SPEED = 50.0 / 3.6      # maximum speed [m/s]
MAX_ACCEL = 10.0            # maximum acceleration [m/ss]
MAX_CURVATURE = 500.0       # maximum curvature [1/m]
MAX_LEFT_WIDTH = -4
MAX_RIGHT_WIDTH = 4
D_ROAD_W = 2                # road width sampling length [m]
DT = 0.3                    # time tick [s]
MAXT = 4.2                  # max prediction time [m]
MINT = 4.0                  # min prediction time [m]
TARGET_SPEED = 30.0 / 3.6   # target speed [m/s]
D_T_S = 15 / 3.6            # target speed sampling length [m/s]
N_S_SAMPLE = 1              # sampling number of target speed

# Collision check
OBSTACLES_CONSIDERED = 4    # 考虑的障碍物数量
ROBOT_RADIUS = 1            # robot radius [m]     
RADIUS_SPEED_RATIO = 1      # higher speed, bigger circle
MOVE_GAP = 1
ONLY_SAMPLE_TO_LEFT = True

# Cost weights
KJ = 0.1
KT = 0.1
KD = 1.0
KLAT = 1.0
KLON = 1.0
KRLS = 1.0


class JunctionTrajectoryPlanner(object):

    def __init__(self, target_line = 0):
        self.last_trajectory_array = np.c_[0, 0]
        self.last_trajectory = Frenet_path()
        self.last_trajectory_array_rule = np.c_[0, 0]
        self.last_trajectory_rule = Frenet_path()
        self.reference_path = None

        self._dynamic_map = None
        self.ref_path = None
        self.ref_path_tangets = None
        self.ob = None
        self.csp = None
        self.dist_to_end = [0,0,0,0,0]
        self.target_line = target_line

        self.radius = ROBOT_RADIUS
        self.move_gap = MOVE_GAP
        self.target_speed = TARGET_SPEED
        self.dts = D_T_S
    
    def clear_buff(self, clean_csp=True):

        if self.csp is None:
            return

        self.last_trajectory_array = np.c_[0, 0]
        self.last_trajectory = Frenet_path()
        self.last_trajectory_array_rule = np.c_[0, 0]
        self.last_trajectory_rule = Frenet_path()
        self.reference_path = None
        if clean_csp:
            self.csp = None
            
    def build_frenet_path(self, dynamic_map, clean_current_csp = False):
        """
        函数功能:构建Frenet路径
        输入:
            dynamic_map: 动态地图
            clean_current_csp: 是否清空当前的csp
        输出:
            无
        """
        # 检查是否需要重新生成参考路径（csp为None或clean_current_csp为True时）
        if self.csp is None or clean_current_csp:
            # 从动态地图中获取第一条车道的中心线作为参考路径
            self.reference_path = dynamic_map.lanes[0].central_path # When dynamic map has one ref path in lane
            
            # 将参考路径转换为NumPy数组
            ref_path_ori = convert_path_to_ndarray(self.reference_path)
            
            # 使用dense_polyline2d函数生成密集的参考路径点
            self.ref_path = dense_polyline2d(ref_path_ori, 2)

            # 初始化路径上每个点的切线角度数组（初始值全为0)
            self.ref_path_tangets = np.zeros(len(self.ref_path))

            # 提取路径点的x,y坐标
            Frenetrefx = self.ref_path[:,0]
            Frenetrefy = self.ref_path[:,1]
            
            # 生成目标路径的样条曲线参数
            # 返回：tx, ty(插值后的x,y坐标), tyaw(航向角), tc(曲率), csp(三次样条插值对象)
            tx, ty, tyaw, tc, self.csp = self.generate_target_course(Frenetrefx,Frenetrefy)
    
    def trajectory_update(self, dynamic_map):
        """
        函数功能:轨迹更新
        输入:
            dynamic_map: 动态地图
        输出:
            无
        """
        self.all_trajectory = self.get_all_candidate_trajectories(dynamic_map)    # 根据动态地图生成所有候选轨迹
        
        if self.all_trajectory is None:    # 空检查:判断 self.all_trajectory 是否为 None.如果是 None,说明没有生成有效的候选轨迹.
            return None                    # 返回 None:在这种情况下,方法直接返回 None,表示无法更新轨迹.

        index = self.get_optimal_trajectory(self.all_trajectory)    # 从候选轨迹中挑选最优轨迹,并返回其索引 index.
        final_trajectory = self.get_trajectory_by_index(index, self.all_trajectory)    # 根据索引从候选轨迹中提取出具体的最优轨迹,存储在变量 final_trajectory 中.
        self.update_last_trajectory(final_trajectory)    # 保存本次更新的轨迹

        # 返回TrajectoryAction动作类,用于表示可以执行的轨迹动作,包含路径点和速度信息.还返回了索引
        # 转换TrajectoryAction动作类流程是路径规划算法与控制系统之间的桥梁,确保规划的轨迹可以被车辆或机器人正确执行.
        return self.convert_trajectory_to_TAction(final_trajectory), index

    def trajectory_safe_checks(self):
        #检查路径有效性,返回有效路径
        trajectories = self.check_paths(self.all_trajectory)    

         # 对所有候选轨迹进行安全检查
        safe_trajectories = []
        safe_index = []
        for i, (traj, cost, idx) in enumerate(trajectories):
            # 使用预测模块检查轨迹是否安全（True表示安全，False表示不安全）
            if self.obs_prediction.check_collision(traj):
                safe_trajectories.append((traj, cost, idx))
                safe_index.append(idx + 1)
        return safe_index

    #获取所有候选轨迹,包含其成本函数值    
    def get_all_candidate_trajectories(self, dynamic_map):
        # 尝试初始化规划器
        if not self.initialize(dynamic_map):    
            return None
        
        start_state = self.calculate_start_state(dynamic_map)
        csp = self.csp            # 可能是一个参考路径的插值对象(如 Cubic Spline 插值),用于生成平滑的参考路径.
        c_speed = self.c_speed    # 当前速度,可能是一个数值,表示当前时刻的速度.
        
        # 计算 Frenet 路径:该方法在 Frenet 坐标系下生成多条可能的路径,考虑不同的速度/加速度/曲率等因素,生成的路径列表存储在 fplist 中.
        fplist = self.calc_frenet_paths(c_speed, start_state)
        # 转换路径:将 Frenet 坐标系下的路径转换为全局坐标系下的路径,即以世界坐标系为参考的路径.转换后的路径列表仍存储在 fplist 中.
        fplist = self.calc_global_paths(fplist, csp)
        path_tuples = []    # 创建一个空列表 path_tuples,用于存储路径元组.
        i = 0
        for fp in fplist:    # 将构造好的 one_path 添加到 path_tuples 列表中.
            one_path = [fp, fp.cf, i]    
            # fp:路径对象本身.
            # fp.cf:路径的成本函数值,可能是一个数值,表示该路径的优劣程度.
            # i:路径的索引,用于标识路径的顺序.
            i = i + 1
            path_tuples.append(one_path)
        
        return path_tuples    # 返回全局路径下的路径元组
    

    def get_optimal_trajectory(self, path_tuples):
        """
        函数功能:从候选轨迹中选出"最优"轨迹.
        输入:
            path_tuples: 候选轨迹的元组列表,格式为 [(fp, score, index), ...],其中:
            fp: 轨迹对象(如 Frenet 路径).
            score: 轨迹评分(成本函数值越低表示越优).
            index: 轨迹索引(从 0 开始).
        """
        # 按照成本函数值升序排序
        sorted_fplist = sorted(path_tuples, key=lambda path_tuples: path_tuples[1])

        # 检查路径有效性,返回有效路径
        sorted_fplist = self.check_paths(sorted_fplist)    

        # 路径碰撞检查
        for fp, score, index in sorted_fplist:   
            if self.obs_prediction.check_collision(fp):
                return index + 1    # 0 for brake trajectory

        # 如果所有路径都发生碰撞,则返回 0,表示选择制动轨迹
        return 0    
    

    def get_trajectory_by_index(self, act_idx, all_trajectory):
            
        if act_idx == 0:    #检查动作索引是否为0.如果 act_idx 为0,调用 self.get_backup_trajectory(all_trajectory) 方法获取备用轨迹.
            backup_trajectory, backup_index = self.get_backup_trajectory(all_trajectory)    # 调用备用轨迹获取逻辑
            traj = backup_trajectory     
        else:
            traj = all_trajectory[int(act_idx - 1)][0]     # 索引减 1 后从 all_trajectory 中提取轨迹
            
        return traj
        
    def get_backup_trajectory(self, all_trajectory):
        # 判断是否复用上一次轨迹
        if len(self.last_trajectory_rule.s_d) > 5 and self.c_speed > 1:     
            backup_trajectory = self.last_trajectory_rule    # 满足条件时复用上次轨迹
            backup_trajectory.s_d = [0] * len(self.last_trajectory_rule.s_d)    # 重置轨迹的 s_d 参数为全零
        else:    # 不满足条件时从备选列表选择最优轨迹
            sorted_fplist = sorted(all_trajectory, key=lambda all_trajectory: all_trajectory[1])     # 按代价排序(假设 all_trajectory 元素为 (trajectory, cost))
            backup_trajectory =  sorted_fplist[0][0]     # 提取代价最低的轨迹
            backup_trajectory.s_d = [0] * len(backup_trajectory.s_d)    # 重置 s_d 参数为全零
 
        return backup_trajectory, 0    # 返回备用轨迹和默认索引 0
    
    def convert_trajectory_to_TAction(self, trajectory):
        """
        合并坐标数组:使用 np.c_ 将轨迹的 x 坐标数组 trajectory.x 和 y 坐标数组 trajectory.y 按列合并,生成一个二维数组,表示轨迹的所有点的坐标.
        创建动作对象:使用合并后的坐标数组和轨迹的速度数组 trajectory.s_d 创建一个 TrajectoryAction 对象.
        返回动作对象:将创建好的 TrajectoryAction 对象返回.
        """
        return TrajectoryAction(np.c_[trajectory.x, trajectory.y], trajectory.s_d)
    
    def update_last_trajectory(self, trajectory):
        
        self.last_trajectory_array_rule = np.c_[trajectory.x, trajectory.y]
        """
        数组合并:使用 np.c_ 将轨迹的 x 坐标数组 trajectory.x 和 y 坐标数组 trajectory.y 按列合并,生成一个二维数组.
        存储数组:将合并后的数组存储在实例变量 self.last_trajectory_array_rule 中,该数组包含了轨迹的所有点的坐标,可能用于后续的路径查找或可视化.
        """
        self.last_trajectory_rule = trajectory 
        """
        将传入的 trajectory 对象直接赋值给实例变量 self.last_trajectory_rule,以便在需要时可以直接访问轨迹的完整信息(如速度/加速度等).
        """

    def trajectory_update_CP(self, CP_action, rule_trajectory, update=True):
        
        #处理刹车指令
        if CP_action == 0:
            # print("[CP]:----> Brake") 
            generated_trajectory =  self.all_trajectory[0][0]    #提取刹车轨迹:从 self.all_trajectory 中提取索引为 0 的轨迹(假设这是预定义的紧急制动轨迹).
            trajectory_array = np.c_[generated_trajectory.x, generated_trajectory.y]    #使用 np.c_ 将轨迹的 x 和 y 坐标合并为一个二维数组.
            trajectory_action = TrajectoryAction(trajectory_array, [0] * len(trajectory_array))    #创建刹车动作:创建一个 TrajectoryAction 对象,其中速度数组设为全零,表示车辆应停止.
            return trajectory_action    #返回刹车动作:返回生成的 TrajectoryAction 对象.       
        """
        逻辑:
            选择刹车轨迹:从 self.all_trajectory 中提取索引为 0 的轨迹(预设的紧急制动轨迹).
            构建轨迹数组:将轨迹的 x 和 y 坐标合并为二维数组.
            生成刹车动作:速度数组设为全零(强制车辆停止).
        关键假设:
            self.all_trajectory[0] 是预定义的刹车轨迹.
            TrajectoryAction 的第二个参数为速度序列,刹车时速度强制归零.
        """

        #处理非刹车指令   
        fplist = self.all_trajectory
        bestpath = fplist[int(CP_action - 1)][0]
        """
        逻辑:
            获取候选轨迹列表:self.all_trajectory 包含所有候选轨迹(格式可能为 [[轨迹1, 评分1], [轨迹2, 评分2], ...]).
            选择目标轨迹:通过 CP_action - 1 计算索引(因 CP_action 从 1 开始计数).
        """
        bestpath.s_d    # 访问速度数据:bestpath.s_d 是轨迹的纵向速度数组.
        trajectory_array = np.c_[bestpath.x, bestpath.y]    # 提取轨迹数据:bestpath.x 和 bestpath.y 为全局坐标点,合并为轨迹数组.
        
        # next time when you calculate start state
        if update==True:
            self.last_trajectory_array_rule = trajectory_array    # 更新数组:将生成的轨迹数组存储在 self.last_trajectory_array_rule 中.
            self.last_trajectory_rule = bestpath    #更新轨迹对象:将选中的轨迹对象存储在 self.last_trajectory_rule 中.
            """
            self.last_trajectory_array_rule 是一个二维数组,用于快速访问轨迹点的坐标.
            self.last_trajectory_rule 是一个轨迹对象,包含完整的轨迹信息,包括速度/加速度等.
            """
        #使用轨迹数组和速度数据创建 TrajectoryAction 对象.
        trajectory_action = TrajectoryAction(trajectory_array, bestpath.s_d[:len(trajectory_array)])
        # print("[CP]: ------> CP Successful Planning")  
        """
        逻辑:
            速度数据对齐:截取 bestpath.s_d(纵向速度序列)的前 len(trajectory_array) 个值,确保与轨迹点数量一致.
            封装为动作对象:TrajectoryAction 包含轨迹点和对应的速度指令,供底层控制器执行.
        """   
        return trajectory_action

    def initialize(self, dynamic_map):
        """
        函数功能: 初始化轨迹规划器
        输入:
            dynamic_map: 动态地图
        输出:
            bool: 是否成功初始化
        """
        # 将传入的动态地图保存到实例变量中，供其他方法使用
        self._dynamic_map = dynamic_map

        try:
            # 参考路径存在则计算自车当前位置到参考路径终点的距离 calculate dist to the end of ref path 
            if self.ref_path is not None:
                self.dist_to_end = dist_from_point_to_polyline2d(dynamic_map.ego_vehicle.x, dynamic_map.ego_vehicle.y, self.ref_path, return_end_distance=True)

            # 检查是否需要重新建立Frenet坐标系 estabilish frenet frame
            if self.csp is None or dynamic_map.lanes_updated == True:   # or self.dist_to_end[4] < 10 or self.dist_to_end[0] > 20:
                self.last_trajectory_array_rule = np.c_[0, 0]
                self.build_frenet_path(dynamic_map, True)   
        
            # 初始化障碍物预测模块 initialize prediction module
            self.obs_prediction = predict(dynamic_map, OBSTACLES_CONSIDERED, MAXT, DT, self.radius, RADIUS_SPEED_RATIO, self.move_gap,
                                        dynamic_map.ego_vehicle.v)

            return True

        except:
            # print("[UBP]: ------> Initialize fail ")
            return False

    def ref_tail_speed(self, dynamic_map, desired_speed):

        velocity = []
        for i in range(len(desired_speed)):

            if self.ref_path is None:
                velocity.append(0)
                velocity.append(0)
                velocity.append(0)
                velocity.append(0)
                velocity.append(0)
                continue
                
            # if self.dist_to_end[4] <= 5:
            #     velocity.append(0)
            #     continue

            dec = 0.1

            available_speed = math.sqrt(2*dec*self.dist_to_end[4]) # m/s
            ego_v = dynamic_map.ego_vehicle.v

            if available_speed > ego_v:
                velocity.append(desired_speed[i])
                continue

            dt = 0.2
            vehicle_dec = (ego_v - available_speed)*10
            tail_speed = ego_v - vehicle_dec*dt
            if desired_speed[i] > tail_speed:
                velocity.append(max(0, tail_speed))

        return velocity

    def calculate_start_state(self, dynamic_map): 
        """
        函数功能:计算起始状态
        输入:
            dynamic_map: 动态地图
        输出:
            start_state: 起始状态
        """
        start_state = Frenet_state()    # 创建了一个 Frenet_state 类型的对象 start_state,用于存储当前的起始状态.
        # print("init",start_state.s0,start_state.c_d,self.c_speed)

        if len(self.last_trajectory_array_rule) > 5:
            # find closest point on the last trajectory
            mindist = float("inf")
            bestpoint = 0
            for t in range(len(self.last_trajectory_rule.x)):
                pointdist = (self.last_trajectory_rule.x[t] - dynamic_map.ego_vehicle.x) ** 2 + (self.last_trajectory_rule.y[t] - dynamic_map.ego_vehicle.y) ** 2
                if mindist >= pointdist:
                    mindist = pointdist
                    bestpoint = t
            start_state.s0 = self.last_trajectory_rule.s[bestpoint]
            start_state.c_d = self.last_trajectory_rule.d[bestpoint]
            start_state.c_d_d = self.last_trajectory_rule.d_d[bestpoint]
            start_state.c_d_dd = self.last_trajectory_rule.d_dd[bestpoint]
            self.c_speed = dynamic_map.ego_vehicle.v

        else:
            self.c_speed = dynamic_map.ego_vehicle.v    #从 dynamic_map 中的 ego_vehicle 对象获取当前车辆的速度 v,并赋值给 self.c_speed.

            ffstate = get_frenet_state(dynamic_map.ego_vehicle, self.ref_path, self.ref_path_tangets)
            """
            调用函数:调用 get_frenet_state 函数,传入当前车辆信息 dynamic_map.ego_vehicle/参考路径 self.ref_path 和参考路径的切线方向 self.ref_path_tangets.
            计算 Frenet 状态:该函数将车辆的全局位置转换为 Frenet 坐标系下的状态,返回一个包含 s(沿道路的弧长)/d(偏离道路中心线的距离)/vd(横向速度)等信息的对象 ffstate.
            """
            start_state.s0 = ffstate.s       # 当前车辆在参考路径上的弧长位置.
            start_state.c_d = -ffstate.d     # current lateral position [m] 当前车辆在横向(垂直于道路方向)上的位置,负号可能用于调整坐标系的方向.
            start_state.c_d_d = ffstate.vd   # current lateral speed [m/s] 表示当前车辆在横向上的速度.
            start_state.c_d_dd = 0           # current latral acceleration [m/s] 表示当前车辆在横向上的加速度

            
        return start_state
    

    def generate_target_course(self, x, y):
        csp = Spline2D(x, y)
        s = np.arange(0, csp.s[-1], 0.1)

        rx, ry, ryaw, rk = [], [], [], []
        for i_s in s:
            ix, iy = csp.calc_position(i_s)
            rx.append(ix)
            ry.append(iy)
            ryaw.append(csp.calc_yaw(i_s))
            rk.append(csp.calc_curvature(i_s))

        return rx, ry, ryaw, rk, csp

    def calc_frenet_paths(self, c_speed, start_state): # input state

        frenet_paths = []    # 创建一个空列表 frenet_paths,用于存储生成的候选路径.

        # 从 start_state 对象中提取当前的 Frenet 坐标系下的状态信息:
        s0 = start_state.s0            # 当前沿道路的弧长位置.
        c_d = start_state.c_d          # 当前横向位置(偏离道路中心线的距离).
        c_d_d = start_state.c_d_d      # 当前横向速度.
        c_d_dd = start_state.c_d_dd    # 当前横向加速度.

        # generate path to each offset goal
        # left_sample_bound = 4 * MAX_ROAD_WIDTH 
        # 遍历横向偏移:使用 np.arange 生成从 MAX_LEFT_WIDTH 到 MAX_RIGHT_WIDTH(包含)的横向偏移量 di,步长为 D_ROAD_W.这表示在横向(左右方向)上生成多个目标偏移量,用于生成不同的路径.
        for di in np.arange(MAX_LEFT_WIDTH, MAX_RIGHT_WIDTH+1, D_ROAD_W):

            # Lateral motion planning 横向运动规划
            for Ti in np.arange(MINT, MAXT, DT):    # 对于每个横向偏移量 di,遍历时间 Ti,从 MINT 到 MAXT,步长为 DT.
                
                # 为每个时间 Ti 创建一个 Frenet_path 对象 fp.
                fp = Frenet_path()                  
                
                # 横向五次多项式:创建一个五次多项式 lat_qp,用于描述横向运动.五次多项式由起始和结束的横向位置/速度/加速度以及时间决定.
                lat_qp = quintic_polynomial(c_d, c_d_d, c_d_dd, di, 0.0, 0.0, Ti) 

                # [t for t in np.arange(0.0, Ti, DT)] 生成从 0 到 Ti 的时间序列 fp.t,步长为 DT.
                fp.t = np.arange(0.0, Ti, DT).tolist() 

                # 计算轨迹点:使用五次多项式 lat_qp 计算每个时间点的横向位置 d/速度 d_d/加速度 d_dd 和三阶导数 d_ddd,并存储在 fp 对象中.
                fp.d = [lat_qp.calc_point(t) for t in fp.t]                        
                fp.d_d = [lat_qp.calc_first_derivative(t) for t in fp.t]
                fp.d_dd = [lat_qp.calc_second_derivative(t) for t in fp.t]
                fp.d_ddd = [lat_qp.calc_third_derivative(t) for t in fp.t]

                # Loongitudinal motion planning (Velocity keeping)    纵向运动规划(速度保持)
                for tv in np.arange(self.target_speed - self.dts * N_S_SAMPLE, self.target_speed + self.dts * N_S_SAMPLE, self.dts):
                    # print("werling_sample",tv, Ti, di)

                    # 每个目标速度 tv 复制一个 Frenet_path 对象 tfp.
                    tfp = copy.deepcopy(fp)  

                    # 纵向四次多项式:创建一个四次多项式 lon_qp,用于描述纵向运动.四次多项式由起始和结束的纵向位置/速度/加速度以及时间决定.
                    lon_qp = quartic_polynomial(s0, c_speed, 0.0, tv, 0.0, Ti)
                    
                    tfp.s = [lon_qp.calc_point(t) for t in fp.t]
                    tfp.s_d = [lon_qp.calc_first_derivative(t) for t in fp.t]
                    tfp.s_dd = [lon_qp.calc_second_derivative(t) for t in fp.t]
                    tfp.s_ddd = [lon_qp.calc_third_derivative(t) for t in fp.t]

                    #计算成本函数
                    Jp = sum(np.power(tfp.d_ddd, 2))  # square of jerk 计算横向抖动成本:Jp 是横向三阶导数(抖动)的平方和.
                    Js = sum(np.power(tfp.s_ddd, 2))  # square of jerk 计算纵向抖动成本:Js 是纵向三阶导数(抖动)的平方和.

                    # square of diff from target speed 计算速度差异成本: ds是目标速度与最终速度差异的平方.
                    ds = (self.target_speed - tfp.s_d[-1])**2 

                    tfp.cd = KJ * Jp + KT * Ti + KD * tfp.d[-1]**2    # 横向综合成本,包括抖动/时间/横向偏移.
                    tfp.cv = KJ * Js + KT * Ti + KD * ds              # 纵向综合成本,包括抖动/时间/速度差异.
                    tfp.cf = KLAT * tfp.cd + KLON * tfp.cv            # 最终综合成本,结合横向和纵向成本.

                    frenet_paths.append(tfp)    # 将生成的路径 tfp 添加到 frenet_paths 列表中.

        return frenet_paths

    def calc_global_paths(self, fplist, csp):

        for fp in fplist:    #遍历 fplist 中的每一条路径 fp,将其从 Frenet 坐标系转换为全局坐标系.
            # calc global positions
            for i in range(len(fp.s)):
                ix, iy = csp.calc_position(fp.s[i])
                if ix is None:
                    break
                iyaw = csp.calc_yaw(fp.s[i])
                di = fp.d[i]
                fx = ix + di * math.cos(iyaw + math.pi / 2.0)
                fy = iy + di * math.sin(iyaw + math.pi / 2.0)
                fp.x.append(fx)
                fp.y.append(fy)

            # calc yaw and ds
            dx = np.diff(np.array(fp.x))
            dy = np.diff(np.array(fp.y))
            fp.yaw = np.arctan2(dy,dx).tolist()
            fp.ds = np.sqrt(dx**2+dy**2).tolist()
            
            try:
                fp.yaw.append(fp.yaw[-1])
                fp.ds.append(fp.ds[-1])
            except:
                fp.yaw.append(0.1)
                fp.ds.append(0.1)

            # calc curvature
            # fp.c = (np.diff(fp.yaw) / np.array(fp.ds)).tolist()

            for i in range(len(fp.yaw) - 1):
                # carla simulation bug
                if fp.ds[i]<0.00001:
                    fp.ds[i] = 0.1
                fp.c.append((fp.yaw[i + 1] - fp.yaw[i]) / fp.ds[i])

        return fplist    #将转换为全局坐标系下的路径列表 fplist 返回.

    def check_paths(self, fplist):
        okind = []    #创建一个空列表 okind,用于存储符合所有条件的路径的索引.
        for i, _ in enumerate(fplist):    #遍历每条路径
            #速度检查:对于路径 fplist[i],检查其纵向速度数组 s_d 中是否有任一速度值超过 MAX_SPEED.
            if any([v > MAX_SPEED for v in fplist[i][0].s_d]):  # Max speed check
                continue
            #加速度检查:对于路径 fplist[i],检查其纵向加速度数组 s_dd 中是否有任一加速度值的绝对值超过 MAX_ACCEL.
            elif any([abs(a) > MAX_ACCEL for a in fplist[i][0].s_dd]):  # Max accel check
                continue
            #曲率检查:对于路径 fplist[i],检查其曲率数组 c 中是否有任一曲率值的绝对值超过 MAX_CURVATURE.
            elif any([abs(c) > MAX_CURVATURE for c in fplist[i][0].c]):  # Max curvature check
                continue

            okind.append(i)    #如果路径通过了速度/加速度和曲率的所有检查,则将其索引 i 添加到 okind 列表中.

        #生成新列表:使用列表推导式,根据 okind 中的索引从 fplist 中提取对应的路径,生成一个新的列表.
        #返回结果:返回包含所有符合速度/加速度和曲率限制的路径的列表.
        return [fplist[i] for i in okind]


class quintic_polynomial:

    def __init__(self, xs, vxs, axs, xe, vxe, axe, T): # s=start  e=end

        # calc coefficient of quintic polynomial
        self.xs = xs
        self.vxs = vxs
        self.axs = axs
        self.xe = xe
        self.vxe = vxe
        self.axe = axe

        self.a0 = xs
        self.a1 = vxs
        self.a2 = axs / 2.0

        A = np.array([[T**3, T**4, T**5],
                      [3 * T ** 2, 4 * T ** 3, 5 * T ** 4],
                      [6 * T, 12 * T ** 2, 20 * T ** 3]])
        b = np.array([xe - self.a0 - self.a1 * T - self.a2 * T**2,
                      vxe - self.a1 - 2 * self.a2 * T,
                      axe - 2 * self.a2])
        x = np.linalg.solve(A, b)

        self.a3 = x[0]
        self.a4 = x[1]
        self.a5 = x[2]

    def calc_point(self, t):
        xt = self.a0 + self.a1 * t + self.a2 * t**2 + \
            self.a3 * t**3 + self.a4 * t**4 + self.a5 * t**5

        return xt

    def calc_first_derivative(self, t):
        xt = self.a1 + 2 * self.a2 * t + \
            3 * self.a3 * t**2 + 4 * self.a4 * t**3 + 5 * self.a5 * t**4

        return xt

    def calc_second_derivative(self, t):
        xt = 2 * self.a2 + 6 * self.a3 * t + 12 * self.a4 * t**2 + 20 * self.a5 * t**3

        return xt

    def calc_third_derivative(self, t):
        xt = 6 * self.a3 + 24 * self.a4 * t + 60 * self.a5 * t**2

        return xt


class quartic_polynomial:
    def __init__(self, xs, vxs, axs, vxe, axe, T):

        # calc coefficient of quintic polynomial
        self.xs = xs
        self.vxs = vxs
        self.axs = axs
        self.vxe = vxe
        self.axe = axe

        self.a0 = xs
        self.a1 = vxs
        self.a2 = axs / 2.0

        A = np.array([[3 * T ** 2, 4 * T ** 3],
                      [6 * T, 12 * T ** 2]])
        b = np.array([vxe - self.a1 - 2 * self.a2 * T,
                      axe - 2 * self.a2])
        x = np.linalg.solve(A, b)

        self.a3 = x[0]
        self.a4 = x[1]

    def calc_point(self, t):
        xt = self.a0 + self.a1 * t + self.a2 * t**2 + \
            self.a3 * t**3 + self.a4 * t**4

        return xt

    def calc_first_derivative(self, t):
        xt = self.a1 + 2 * self.a2 * t + \
            3 * self.a3 * t**2 + 4 * self.a4 * t**3

        return xt

    def calc_second_derivative(self, t):
        xt = 2 * self.a2 + 6 * self.a3 * t + 12 * self.a4 * t**2

        return xt

    def calc_third_derivative(self, t):
        xt = 6 * self.a3 + 24 * self.a4 * t

        return xt


class Frenet_path:

    def __init__(self):
        self.t = [] # time
        self.d = []
        self.d_d = []
        self.d_dd = []
        self.d_ddd = []
        self.s = []
        self.s_d = []
        self.s_dd = []
        self.s_ddd = []
        self.cd = 0.0
        self.cv = 0.0
        self.cf = 0.0

        self.x = []
        self.y = []
        self.yaw = []
        self.ds = []
        self.c = []

class Frenet_state:

    def __init__(self):
        self.t = 0.0
        self.d = 0.0
        self.d_d = 0.0
        self.d_dd = 0.0
        self.d_ddd = 0.0
        self.s = 0.0
        self.s_d = 0.0
        self.s_dd = 0.0
        self.s_ddd = 0.0

        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.ds = 0.0
        self.c = 0.0
