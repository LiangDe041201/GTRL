"""
    实现了一些矩形工具类：
    1. 使用分离轴定理 (SAT) 检查两个任意方向的矩形是否相交
    2. 获取包围两个矩形的最小外接矩形 (Minimum Bounding Rectangle, MBR)
"""
import numpy as np
import math

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Rectangle_SAT:
    def __init__(self, center, width, height, angle):
        """
        center: Point - center of the rectangle
        width: float - width of the rectangle
        height: float - height of the rectangle
        angle: float - rotation angle in radians
        """
        self.center = center
        self.width = width
        self.height = height
        self.angle = angle
        self.corners = self._calculate_corners()
    
    def _calculate_corners(self):
        """Calculate the four corners of the rectangle"""
        # Half dimensions
        hw = self.width / 2
        hh = self.height / 2
        
        # Corners before rotation (centered at origin)
        corners = [
            Point(-hw, -hh),
            Point( hw, -hh),
            Point( hw,  hh),
            Point(-hw,  hh)
        ]
        
        # Rotate and translate corners
        cos_a = np.cos(self.angle)
        sin_a = np.sin(self.angle)
        
        rotated_corners = []
        for p in corners:
            # Rotate
            x = p.x * cos_a - p.y * sin_a
            y = p.x * sin_a + p.y * cos_a
            # Translate
            x += self.center.x
            y += self.center.y
            rotated_corners.append(Point(x, y))
            
        return rotated_corners
    
    def get_axes(self):
        """Get the normal vectors of the edges (the axes to project onto)"""
        axes = []
        corners = self.corners
        # For each edge, get the normal vector
        for i in range(len(corners)):
            p1 = corners[i]
            p2 = corners[(i + 1) % len(corners)]
            # Edge vector
            edge = Point(p2.x - p1.x, p2.y - p1.y)
            # Normalize the normal vector
            length = np.sqrt(edge.x**2 + edge.y**2)
            if length > 0:
                # Normal vector (perpendicular to the edge)
                normal = Point(-edge.y/length, edge.x/length)
                axes.append(normal)
        return axes
    
    def project(self, axis):
        """Project all corners onto the given axis and return the min and max projections"""
        min_proj = float('inf')
        max_proj = -float('inf')
        
        for p in self.corners:
            # Project point onto axis
            proj = p.x * axis.x + p.y * axis.y
            
            if proj < min_proj:
                min_proj = proj
            if proj > max_proj:
                max_proj = proj
                
        return (min_proj, max_proj)

    def rectangles_intersect(rect1, rect2):
        """
        Check if two rectangles intersect using the Separating Axis Theorem (SAT)
        """
        # Get all axes to test (normals of both rectangles' edges)
        axes = rect1.get_axes() + rect2.get_axes()
        
        for axis in axes:
            # Skip zero-length axes (can happen with duplicate points)
            if axis.x == 0 and axis.y == 0:
                continue
                
            # Project both rectangles onto the current axis
            proj1 = rect1.project(axis)
            proj2 = rect2.project(axis)
            
            # Check if projections overlap
            if proj1[1] < proj2[0] or proj2[1] < proj1[0]:
                # Found a separating axis - rectangles don't intersect
                return False
        
        # No separating axis found - rectangles intersect
        return True


class Rectangle_MBR:
    def __init__(self, center, width, height, angle):
        self.center = center
        self.width = width
        self.height = height
        self.angle = angle

    @staticmethod
    def get_rotated_rectangle_corners(center, width, height, angle):
        """获取旋转后的矩形四个角点坐标"""
        # 计算半宽和半高
        hw = width / 2.0
        hh = height / 2.0
        
        # 未旋转时的四个角点（相对于中心点）
        corners = [
            Point(-hw, -hh),  # 左上
            Point( hw, -hh),  # 右上
            Point( hw,  hh),  # 右下
            Point(-hw,  hh)   # 左下
        ]
        
        # 旋转矩阵
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        
        # 旋转并平移角点
        rotated_corners = []
        for p in corners:
            # 旋转
            x_rot = p.x * cos_a - p.y * sin_a
            y_rot = p.x * sin_a + p.y * cos_a
            # 平移
            x_rot += center.x
            y_rot += center.y
            rotated_corners.append(Point(x_rot, y_rot))
        
        return rotated_corners

    @classmethod
    def get_min_bounding_rectangle(cls, rect1, rect2):
        """
        计算包围两个矩形的最小外接矩形
        
        参数:
        rect1, rect2: 包含中心点、宽、高和旋转角度的矩形对象
        
        返回:
        (center_x, center_y, width, height, angle) 最小外接矩形的参数
        """
        # 获取两个矩形的所有角点
        rect1_corners = cls.get_rotated_rectangle_corners(
            Point(rect1.center.x, rect1.center.y), 
            rect1.width, 
            rect1.height, 
            rect1.angle
        )
        
        rect2_corners = cls.get_rotated_rectangle_corners(
            Point(rect2.center.x, rect2.center.y), 
            rect2.width, 
            rect2.height, 
            rect2.angle
        )
        
        # 合并所有点
        all_points = rect1_corners + rect2_corners
        
        # 计算凸包（这里简化处理，直接使用所有点）
        # 在实际应用中，可能需要先计算凸包以提高效率
        points = all_points
        
        # 计算最小面积外接矩形
        min_area = float('inf')
        best_rect = None
        
        # 尝试所有可能的旋转角度（基于边的方向）
        for i in range(len(points)):
            # 当前边
            p1 = points[i]
            p2 = points[(i+1) % len(points)]
            
            # 计算边的角度
            dx = p2.x - p1.x
            dy = p2.y - p1.y
            angle = math.atan2(dy, dx)
            
            # 旋转所有点使当前边水平
            cos_a = math.cos(-angle)
            sin_a = math.sin(-angle)
            
            # 旋转后的点
            rotated_points = []
            for p in points:
                # 平移使p1为原点
                x = p.x - p1.x
                y = p.y - p1.y
                # 旋转
                x_rot = x * cos_a - y * sin_a
                y_rot = x * sin_a + y * cos_a
                rotated_points.append(Point(x_rot, y_rot))
            
            # 计算AABB（轴对齐边界框）
            min_x = min(p.x for p in rotated_points)
            max_x = max(p.x for p in rotated_points)
            min_y = min(p.y for p in rotated_points)
            max_y = max(p.y for p in rotated_points)
            
            # 计算面积
            width = max_x - min_x
            height = max_y - min_y
            area = width * height
            
            # 更新最小面积矩形
            if area < min_area:
                min_area = area
                # 计算中心点（在原始坐标系中）
                center_x = (min_x + max_x) / 2
                center_y = (min_y + max_y) / 2
                # 旋转回原始坐标系
                center_x_rot = center_x * math.cos(angle) - center_y * math.sin(angle)
                center_y_rot = center_x * math.sin(angle) + center_y * math.cos(angle)
                center_x = center_x_rot + p1.x
                center_y = center_y_rot + p1.y
                
                best_rect = (center_x, center_y, width, height, angle)
        
        return best_rect


# # SAT测试
# if __name__ == '__main__':
#     # 创建两个矩形
#     rect1 = Rectangle_SAT(Point(0, 0), 4, 2, 0)          # 中心在(0,0)，宽4高2，旋转45度
#     rect2 = Rectangle_SAT(Point(3.1, 0), 4, 2, 1.5708)   # 中心在(3,2)，宽4高2，旋转-30度

#     # 检查是否相交，边界相交也算相交
#     if Rectangle_SAT.rectangles_intersect(rect1, rect2):
#         print("Rectangles intersect!")
#     else:
#         print("Rectangles do not intersect.")


# # MBR测试
# if __name__ == '__main__':
#     # 创建两个矩形
#     rect1 = Rectangle_MBR(Point(0, 0), 4, 2, 0)      # 中心在(0,0)，宽4高2，不旋转
#     rect2 = Rectangle_MBR(Point(3, 2), 4, 2, 0)     # 中心在(3,2)，宽4高2，不旋转
    
#     # 计算最小外接矩形
#     mbr_center_x, mbr_center_y, mbr_width, mbr_height, mbr_angle = Rectangle_MBR.get_min_bounding_rectangle(rect1, rect2)
    
#     print(f"最小外接矩形:")
#     print(f"中心点: ({mbr_center_x:.2f}, {mbr_center_y:.2f})")
#     print(f"宽度: {mbr_width:.2f}")
#     print(f"高度: {mbr_height:.2f}")
#     print(f"旋转角度: {math.degrees(mbr_angle):.2f}°")