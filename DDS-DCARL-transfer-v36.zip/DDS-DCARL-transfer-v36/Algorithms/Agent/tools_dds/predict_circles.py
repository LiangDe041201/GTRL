"""
    这段代码实现了一个基于轨迹预测的车辆碰撞检测模块,使用两个圆来近似表示车辆. 
    要使用这个碰撞检测模块的话直接把文件名从 predict_circles 改成 predict
"""
import numpy as np
import copy
import math
from Agent.tools_dds.frenet import Frenet_path 

class predict():
    def __init__(self, dynamic_map, considered_obs_num, maxt, dt, robot_radius, radius_speed_ratio, move_gap, ego_speed):

        self.maxt = maxt
        self.dt = dt
        self.check_radius = robot_radius #  + radius_speed_ratio * ego_speed
        self.move_gap = move_gap
        self.dynamic_map = dynamic_map

        try:
            interested_vehicles = self.found_interested_vehicles(considered_obs_num)
            self.predict_paths = self.prediction_obstacle(interested_vehicles, self.maxt, self.dt)
        except:
            self.predict_paths = []

    def check_collision(self, fp):
        """
        用途:检查给定的自车轨迹是否与预测路径发生碰撞
        输入:
            fp:当前轨迹
        输出:
            True:未发生碰撞
            False:发生碰撞
        """

        if len(self.predict_paths) == 0 or len(fp.t) < 2 :
            return True
            
        # 车辆碰撞检查，使用两个圆来近似表示车辆 two circles for a vehicle -------------------
        fp_front = copy.deepcopy(fp)    # 创建前圆的深拷贝
        fp_back = copy.deepcopy(fp)     # 创建后圆的深拷贝
        
        # 计算前圆中心坐标
        # 在原始x坐标上加上cos(yaw)*move_gap，得到前圆x坐标
        fp_front.x = (np.array(fp.x)+np.cos(np.array(fp.yaw))*self.move_gap).tolist()
        # 在原始y坐标上加上sin(yaw)*move_gap，得到前圆y坐标
        fp_front.y = (np.array(fp.y)+np.sin(np.array(fp.yaw))*self.move_gap).tolist()
        # print("fp_front.x",fp_front.x)    # 打印前圆x坐标
        # print("fp_front.y",fp_front.y)    # 打印前圆y坐标

        # 计算后圆中心坐标
        # 在原始x坐标上减去cos(yaw)*move_gap，得到后圆x坐标
        fp_back.x = (np.array(fp.x)-np.cos(np.array(fp.yaw))*self.move_gap).tolist()
        # 在原始y坐标上减去sin(yaw)*move_gap，得到后圆y坐标
        fp_back.y = (np.array(fp.y)-np.sin(np.array(fp.yaw))*self.move_gap).tolist()

        # 检查前圆与预测路径的碰撞
        for path in self.predict_paths:
            # 计算需要检查的时间步长，取预测路径和当前路径的最小长度减1
            len_predict_t = min(len(fp.x)-1, len(path.t)-1)
            predict_step = 2     # 每隔2个点检查一次
            start_predict = 2    # 从第2个点开始检查
            for t in range(start_predict, len_predict_t, predict_step):
                # 检查前圆是否与路径点碰撞
                d = (path.x[t] - fp_front.x[t])**2 + (path.y[t] - fp_front.y[t])**2
                if d <= self.check_radius**2: 
                    return False    # 如果距离小于阈值，返回False表示碰撞
                
                # 检查后圆是否与路径点碰撞
                d = (path.x[t] - fp_back.x[t])**2 + (path.y[t] - fp_back.y[t])**2
                if d <= self.check_radius**2: 
                    return False    # 如果距离小于阈值，返回False表示碰撞
                
        # 行人碰撞检查 For Pedestrain --------------------------------------------------
        for path in self.predict_paths:
            # 计算需要检查的时间步长，取预测路径和当前路径的最小长度减1
            len_predict_t = min(len(fp.x)-1, len(path.t)-1)
            predict_step = 2     # 每隔2个点检查一次
            start_predict = 2    # 从第2个点开始检查
            for t in range(start_predict, len_predict_t, predict_step):
                # 计算两点之间的欧氏距离平方（避免开方运算提高效率）
                d = (path.x[t] - fp.x[t])**2 + (path.y[t] - fp.y[t])**2

                # 如果距离小于等于检查半径的平方，说明发生碰撞
                if d <= self.check_radius**2: 
                    return False

        # 所有检查都通过，返回True表示没有碰撞
        return True

    def found_interested_vehicles(self, interested_vehicles_num = 3):
        """
        用途:找距离自车最近的几辆感兴趣车辆
        输入:
            interested_vehicles_num:感兴趣的车辆数量
        输出:
            interested_vehicles:感兴趣的车辆列表
        """
        # 初始化感兴趣车辆列表
        interested_vehicles = []

        # 获取感兴趣的车辆（基于距离）
        distance_tuples = []    # 用于存储(距离, 车辆索引)元组

        # 获取自车位置，转换为numpy数组方便计算
        ego_loc = np.array([self.dynamic_map.ego_vehicle.x,self.dynamic_map.ego_vehicle.y])

        # 遍历所有车辆，计算与自车的距离
        for vehicle_idx, vehicle in enumerate(self.dynamic_map.vehicles): 
            # 获取车辆位置，转换为numpy数组
            vehicle_loc = np.array([vehicle.x, vehicle.y])

            # 计算与自车的距离
            d = np.linalg.norm(vehicle_loc - ego_loc)

            # 将距离和车辆索引存储到元组中
            distance_tuples.append((d, vehicle_idx))
            
        # 按照距离对车辆进行排序，从近到远
        sorted_vehicle = sorted(distance_tuples, key=lambda vehicle_dis: vehicle_dis[0])

        # 添加指定数量的最近车辆到感兴趣车辆列表，初始化预测模块的时候把 interested_vehicles_num 设为了4
        for _, vehicle_idx in sorted_vehicle:
            interested_vehicles.append(self.dynamic_map.vehicles[vehicle_idx])
            if len(interested_vehicles) >= interested_vehicles_num:
                break

        return interested_vehicles

    def prediction_obstacle(self, vehicles, max_prediction_time, delta_t): 
        """
        用途:预测环境车辆的行车轨迹
        输入:
            vehicles:环境车辆列表
            max_prediction_time:最大预测时间
            delta_t:时间步长
        输出:
            predict_paths:预测轨迹列表
        """
        # 初始化预测路径列表
        predict_paths = []

        # 遍历所有车辆，预测其行车轨迹
        for vehicle in vehicles:
            # 创建前后两个预测路径对象（用于表示车辆前后两个点）
            predict_path_front = Frenet_path()
            predict_path_back = Frenet_path()
            
            # 设置预测路径的时间点，从0到max_prediction_time，间隔为delta_t
            predict_path_front.t = [t for t in np.arange(0.0, max_prediction_time, delta_t)]
            predict_path_back.t = [t for t in np.arange(0.0, max_prediction_time, delta_t)]

            # 初始化加速度（当前未使用）
            ax = 0    # one_ob[9]    横向加速度
            ay = 0    # one_ob[10]   纵向加速度
            # print("vehicle information",vehicle.x, vehicle.y, vehicle.vx, vehicle.vy, vehicle.yaw)

            # 预测x和y方向的速度（假设速度恒定）
            vx_predict = vehicle.vx*np.ones(len(predict_path_front.t))
            vy_predict = vehicle.vy*np.ones(len(predict_path_front.t))

            # 预测x和y坐标（匀速直线运动模型） 当前位置 + 时间步长 × 速度
            x_predict = vehicle.x + np.arange(len(predict_path_front.t))*delta_t*vx_predict
            y_predict = vehicle.y + np.arange(len(predict_path_front.t))*delta_t*vy_predict
            
            # 计算前圆和后圆的x和y坐标
            predict_path_front.x = (x_predict + math.cos(vehicle.yaw)*np.ones(len(predict_path_front.t))*self.move_gap).tolist()
            predict_path_front.y = (y_predict + math.sin(vehicle.yaw)*np.ones(len(predict_path_front.t))*self.move_gap).tolist()
            predict_path_back.x = (x_predict - math.cos(vehicle.yaw)*np.ones(len(predict_path_back.t))*self.move_gap).tolist()
            predict_path_back.y = (y_predict - math.sin(vehicle.yaw)*np.ones(len(predict_path_back.t))*self.move_gap).tolist()
        
            predict_paths.append(predict_path_front)
            predict_paths.append(predict_path_back)

        return predict_paths

    

