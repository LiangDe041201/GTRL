"""
    车道轨迹规划器: 针对车道保持和变道场景优化，适合直行和简单变道
    采用组合模式，包含 Werling 类处理具体轨迹规划
    搭配 dynamic_map.update_map 使用
"""
import numpy as np
import bisect
import copy
import time
import carla
import random
import os as _os          # 【式(49)/L1/L5】参数化用（原来 `_os` 只在文件后半段才可用）
# 【§72】同上：只在未指定 DSH_SEED 时才用默认种子，避免覆盖外部播种。
if not _os.environ.get('DSH_SEED'):
    random.seed(42)

from Agent.tools_dds.tools import *
from Agent.tools_dds.predict import predict
from Agent.tools_dds.frenet import *
from Agent.tools_dds.actions import TrajectoryAction
from Planning_library.trajectory_guard import clean_path, road_geometry

# Parameter
MAX_SPEED = 50.0 / 3.6      # maximum speed [m/s]
MAX_ACCEL = 10.0            # maximum acceleration [m/ss]
MAX_CURVATURE = 500.0       # maximum curvature [1/m]      500
D_ROAD_W = 0.6              # road width sampling length [m]
DT = 0.3                    # time tick [s]
MAXT = 4.3                  # max prediction time [m]                
MINT = 4.0                  # min prediction time [m]
D_T_S = 5 / 3.6             # target speed sampling length [m/s]     
N_S_SAMPLE = 2              # sampling number of target speed

"""----------------------------kappa parameter--------------------------------"""
# 【式(49) 论文 Table I 核对】原始 docx 的 Table I 逐行值是：
#   Curvature κ 阈值 = −（论文**未给**）   ω_κ = 1
#   Change of Curvature Δκ 阈值 = −        ω_Δκ = 2
#   Rate of Change dκ/ds 阈值 = −          ω_{dκ/ds} = 5
#   Longitudinal jerk J_s 阈值 = −         Jerk Weight ω_j = 1
#   Lateral jerk J_d 阈值 = −              Hinge Penalty Weight ω_TH = 10
#   Hinge Penalty Threshold for Curvature κ_TH = 0.1
# ⇒ **权重 ω 论文给了（已对上）**；**五个阈值论文全写 `−`（即未指定）**
#   ⇒ 阈值是自由参数，必须可配、且不得声称"来自论文"。
#: 【式(49)】hinge 惩罚权重 ω_TH（论文 Table I = 10）
HINGE_W = float(_os.environ.get('DSH_HINGE_W', '10.0'))
MAX_ABS_K = float(_os.environ.get('DSH_MAX_ABS_K', '0.1'))      # κ_TH（论文 Table I = 0.1）
MAX_ABS_DK = float(_os.environ.get('DSH_MAX_ABS_DK', '0.02'))  # 论文未给
MAX_ABS_DKDS = float(_os.environ.get('DSH_MAX_ABS_DKDS', '0.01'))  # 论文未给

W_K          = float(_os.environ.get('DSH_W_K', '1.0'))      # ω_κ   （Table I = 1）
W_DK         = float(_os.environ.get('DSH_W_DK', '2.0'))     # ω_Δκ  （Table I = 2）
W_DKDS       = float(_os.environ.get('DSH_W_DKDS', '5.0'))   # ω_{dκ/ds}（Table I = 5）

# ===== 转弯场景 DCARL 动作速度档位 =====
# 动作0 = 沿参考路径刹停；动作1~7 = 过弯目标速度 (m/s)
# 与 dds_dcarl_turn.act_hybrid 的 action_num=7 对应（共8档）
TURN_SPEED_LEVELS = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0]

# ============================================================
# 【动作空间 · 论文式10/48-50 对齐开关】
#   speed  (默认) : 8 档速度（左转"切入时机"的适配；本场景既有最优）
#   lateral       : 论文原样 —— 6 个横向 offset(0~2.5m, 0.5m 步长)，见式48-49
# ============================================================
import os as _os
#: 【式(10) 权威口径】默认 = **二维联合** `A_i={(J,ψ)}`。
#: 用户明确：**不切 `lateral`** —— `lateral` 是 §IV-D 的一维 6 档横向口径，
#: 不是式(10) 的口径；左转里**纵向进入时机是核心博弈变量**，切 lateral 等于把它写死。
#: 起步实例化：4 纵向 × 3 横向 = 12，横向 di ∈ {−1.5, 0, +1.5}（**内负外正**）；
#: 式(48) 的 `d_e` 6 档保留为**横向分量的候选集**，将来按样本量扩。
ACTION_MODE = _os.environ.get('DSH_ACTION_MODE', '2d')             # 2d(论文式10) | lateral(式48) | speed(旧)
TURN_LATERAL_OFFSETS = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5]              # 论文 action1..action6
LATERAL_TARGET_SPEED = float(_os.environ.get('DSH_LATERAL_SPEED', '4.0'))  # 横向模式下的纵向目标速度

# ============================================================
# 【S4】二维动作（论文式10 `A_i={(J,psi)}` 的左转适配）
#   动机：此前动作是一维的（8 速度 或 6 横向），另一个维度写死 ⇒ 自车的**横向位置
#   没有任何一层在管**。实测（PLAN §14）路口段 `di=0` 的轨迹本身就偏离参考线
#   1.28~1.95 m，而交叉车体带半宽只有 1.0 m ⇒ 横向必须成为可控维度。
#   设计：4 纵向 x 3 横向 = 12，横向 offset 属于 {-1.5, 0, +1.5}（**内负外正**）。
#   编码：action = i_speed * 3 + i_lat（`%3` 取横向、`//3` 取纵向）。
#   前置已验证（PLAN §14）：di=±1.5 在路口段有限、无 NaN、不交叉、偏移精确 1.5 m。
# ============================================================
TURN_2D_SPEEDS = [0.0, 2.0, 4.0, 6.0]
#: 【L5】横向档位：默认 3 档（起步）；`DSH_LAT_LEVELS=6` 扩到 6 档（对称，仍满足"内负外正"）。
#:   论文式(48) 的 `d_e` 是**单侧** 6 档 {0,0.5,…,2.5}（换道语义）；
#:   左转需要**双侧**，故 6 档取对称 {-1.5,-0.9,-0.3,+0.3,+0.9,+1.5}。
#:   这样"式(48) 的 6 档候选集"在运行期**可达**，而不是只留一个常量。
#:   `6` = **论文式(48) 原样**的单侧 6 档 `{0,0.5,1.0,1.5,2.0,2.5}`（严格"保留"，
#:         且含 0 ⇒ `BRAKE_ACTION` 的中性档存在）；
#:   `7` = 左转用的**对称 7 档** `{-1.5,-1.0,-0.5,0,+0.5,+1.0,+1.5}`（含中性）。
#:   ⚠️ 6 档**不含负值** ⇒ 是**换道语义**（只向一侧偏移），不是左转的最优选择，
#:      仅用于"把论文候选集跑通"的对照。
_LAT_MODE = _os.environ.get('DSH_LAT_LEVELS', '3')
if _LAT_MODE == 'tight':
    TURN_2D_LATERALS = [-0.4, 0.0, 0.4]  # 3 m lane, 2 m body, 0.1 m nominal margin
elif _LAT_MODE == '6':
    TURN_2D_LATERALS = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5]          # 论文式(48) 原样
elif _LAT_MODE == '7':
    TURN_2D_LATERALS = [-1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5]  # 左转对称
else:
    TURN_2D_LATERALS = [-1.5, 0.0, 1.5]                        # 起步 3 档
_N_LAT = len(TURN_2D_LATERALS)


def _clip_action(a):
    try:
        a = int(a)
    except (TypeError, ValueError):
        return 0
    return max(0, min(N_ACTIONS - 1, a))


def action_speed(a):
    """动作 -> 目标速度（m/s）。对 speed / lateral / 2d 三种模式都有定义。

    为什么必须有它：改造前所有消费方（屏蔽掩码、探索候选、冲突预测、EFE）
    都直接写 `TURN_SPEED_LEVELS[action]`，那是"动作=速度档"的隐含假设。
    有了本函数，动作空间的语义只需在这一个地方定义。
    """
    a = _clip_action(a)
    if ACTION_MODE == '2d':
        return float(TURN_2D_SPEEDS[a // _N_LAT])
    if ACTION_MODE == 'lateral':
        return float(LATERAL_TARGET_SPEED)
    return float(TURN_SPEED_LEVELS[a])


def action_lateral(a):
    """动作 -> 横向 offset（m）。speed 模式恒为 0。"""
    a = _clip_action(a)
    if ACTION_MODE == '2d':
        return float(TURN_2D_LATERALS[a % _N_LAT])
    if ACTION_MODE == 'lateral':
        return float(TURN_LATERAL_OFFSETS[a])
    return 0.0


N_ACTIONS = (len(TURN_2D_SPEEDS) * _N_LAT if ACTION_MODE == '2d'
             else len(TURN_LATERAL_OFFSETS) if ACTION_MODE == 'lateral'
             else len(TURN_SPEED_LEVELS))
#: 每个动作对应的速度（供 boundary_shield_mask 等按"档位"工作的纯函数使用）
ACTION_SPEEDS = [action_speed(a) for a in range(N_ACTIONS)]


def action_lateral_index(a):
    """动作 -> **横向档序号**（不是米）。

    只对 `2d` 有意义（`speed`/`lateral` 模式恒 0）。存在的理由见 `BRAKE_ACTION`：
    判断"两个动作是否只有纵向不同"必须比较档序号，而不是比较 `a % _N_LAT`
    —— 后者在 speed 模式下会把 4 个无横向含义的动作错分成 3 组。
    """
    if ACTION_MODE == '2d':
        return int(_clip_action(a)) % _N_LAT
    return 0


# ============================================================
#  规范"让行/刹停"动作（单一真源）
# ------------------------------------------------------------
#  ⚠ 这里曾经有一个**跨动作空间的静默语义漂移**（S5-③ 定位）：
#    在 `speed` 模式里 index 0 就是"纯刹车"（横向固定 di=0），于是屏蔽层、
#    规则兜底、探索候选保底等 6 处都直接写死 `0` 当刹车用 —— 那时是对的。
#    引入 `2d` 空间后 index 0 变成 `(v=0, di=-1.5)` = **刹停 + 向左切 1.5 m**，
#    而这 6 处没跟着改。实测 expKK_2d_100 里 `decision_src=='shield'` 的
#    5669 帧**全部**是 action 0 ⇒ ④ 屏蔽层（本应只约束纵向）在每个屏蔽帧都
#    额外下发了一条"向左切 1.5 m"的横向指令。屏蔽帧占全部帧的 46%。
#    ⇒ `BRAKE_ACTION` 是"最低速度档 + 中性横向"的唯一来源，任何"保底刹车"
#      都必须用它，禁止再出现字面量 0。
BRAKE_ACTION = ((TURN_2D_SPEEDS.index(min(TURN_2D_SPEEDS)) * _N_LAT
                 + TURN_2D_LATERALS.index(0.0)) if ACTION_MODE == '2d' else 0)


def slowest_speed_actions():
    """所有"最慢档"动作的序号列表（2d 模式下是 3 个横向各一）。

    ④ 屏蔽只约束**纵向**，所以"只允许最慢档"应当是**一个速度层**，
    而不是单个动作；横向留给策略自己（见 `shield_fallback_action`）。
    """
    if not ACTION_SPEEDS:
        return []
    _vmin = min(ACTION_SPEEDS)
    return [a for a in range(N_ACTIONS) if ACTION_SPEEDS[a] <= _vmin + 1e-9]


def shield_fallback_action(action, allowed):
    """④ 屏蔽的兜底动作：**只换纵向档，保留策略原本的横向分量**。

    旧实现 `min(allowed, key=lambda a: ACTION_SPEEDS[a])` 在 2d 空间里恒等于
    index 0（最慢档里序号最小者）⇒ 屏蔽层强行把横向改成 -1.5 m。正确做法是
    在"允许集合里最慢的速度层"内，挑横向档序号与 `action` 最接近的那个。
    在 `speed`/`lateral` 模式下横向分量无意义，退化为纯取最慢档。
    """
    allowed = [int(a) for a in (allowed or []) if 0 <= int(a) < N_ACTIONS]
    if not allowed:
        return int(_clip_action(action))
    _vmin = min(ACTION_SPEEDS[a] for a in allowed)
    _cand = [a for a in allowed if ACTION_SPEEDS[a] <= _vmin + 1e-9]
    _i_lat = action_lateral_index(action)
    return int(min(_cand, key=lambda a: (abs(action_lateral_index(a) - _i_lat), a)))


def _adaptive_trajectory_horizon(target_speed):
    """
    自适应轨迹时长 Ti (s)：
      - 刹车档 (target<1)：保持 MINT=4s 减速停车（停止距离 ~12m，合理）
      - 慢速档 (1~4)：拉长 Ti，使路径覆盖约 12m 过弯弧线（上限 12s，避免轨迹末端顶到参考路径终点）
      - 快速档 (>=5)：保持 MINT=4s
    这样"规则想慢"时轨迹如实反映低速，同时路径长度足够 MPC 跟踪过弯。
    """
    ts = max(float(target_speed), 0.0)
    if ts < 1.0:
        return MINT
    return float(max(MINT, min(12.0, 12.0 / ts)))


# # JunctionTrajectoryPlanner Parameter
# MAX_SPEED = 50.0 / 3.6      # maximum speed [m/s]
# MAX_ACCEL = 10.0            # maximum acceleration [m/ss]
# MAX_CURVATURE = 500.0       # maximum curvature [1/m]
# MAX_LEFT_WIDTH  = -4        
# MAX_RIGHT_WIDTH = 4
# D_ROAD_W = 2                # road width sampling length [m]
# DT = 0.3                    # time tick [s]
# MAXT = 4.2                  # max prediction time [m]
# MINT = 4.0                  # min prediction time [m]
# TARGET_SPEED = 30.0 / 3.6   # target speed [m/s]
# D_T_S = 15 / 3.6            # target speed sampling length [m/s]
# N_S_SAMPLE = 1              # sampling number of target speed

# collision check
OBSTACLES_CONSIDERED = 20    # 考虑的障碍物数量
ROBOT_RADIUS = 2.5          # robot radius [m]    
RADIUS_SPEED_RATIO = 0.3    # higher speed, bigger circle
MOVE_GAP = 1.5

# Cost weights
# 【式(49)】ω_j：论文 Table I = **1**。原值 0.1 与论文不符（PLAN §42）。
KJ = float(_os.environ.get('DSH_KJ', '1.0'))
KT = 0.1 
KD = 1.0
KLAT = 1.0
KLON = 1.0


class Trajectory:
    def __init__(self, x_list, y_list):
        self.x = np.array(x_list)
        self.y = np.array(y_list)


class LaneTrajectoryPlanner(object):
    def __init__(self):
        self.frenet_lanes = []                 # 存储车道的Frenet路径
        self.last_target_lane_index = -10      # 上一次的目标车道索引

    def build_frenet_lane(self, dynamic_map, env):
        """
        函数功能: 为动态地图中的每个车道构建Frenet坐标表示
        输入:
            dynamic_map (DynamicMap): 包含车道信息的动态地图对象
        操作:
            1. 清空现有的frenet_lanes列表
            2. 为每个车道创建Werling轨迹规划器
            3. 将车道中心线路径传递给Werling规划器
        """
        lane_num = len(dynamic_map.lanes)
        for lane_idx, lane in enumerate(dynamic_map.lanes):

            """---------------------------------------------------------------------"""
            # 为每个车道创建一个 Werling 轨迹规划器，更新其参考路径
            # 把 lane.central_path_array 改成了 lane.central_path
            self.frenet_lanes.append(Werling(lane.central_path, lane_idx, lane_num, env))
            """---------------------------------------------------------------------"""

    def change_frenet(self, last_werling, new_werling):
        """
        功能：把规划的路径转到另一个frenet下，避免前一次的规划清除
        逻辑：把新的下面的last_trajectory_array_rule(ndarray)转换，清空旧的
        """

        new_werling.last_trajectory_array_rule = last_werling.last_trajectory_array_rule.copy()

        new_werling.last_trajectory_rule.x =last_werling.last_trajectory_rule.x.copy()
        new_werling.last_trajectory_rule.y = last_werling.last_trajectory_rule.y.copy()

        last_werling.lane_change_clean_buff()
        last_werling.all_trajectory = []


    def run_step(self, dynamic_map, target_lane_index, desired_speed, env, ref_d, open_result):
        """
        函数功能: 运行轨迹规划
        输入:
            dynamic_map (DynamicMap): 包含车道信息的动态地图对象
            target_lane_index (int): 目标车道索引
            desired_speed (float): 目标速度
            FIXME(4.9):ref_d: 这是一个调试横向假设的，一路会传递到五次多项式规划
            open_result:和原先逻辑一样做个随机动作,一路传到概率选择轨迹那块
        操作:
            1. 如果车道信息已更新,重新构建frenet_lanes
            2. 如果目标车道索引发生变化,重置frenet_lanes
            3. 返回目标车道的轨迹规划结果
        """
        # FIXME（4.16）:这里每次规划轨迹都会重新构建结构化的道路，导致werling类别的上一个轨迹被除掉
        # 如果不是需要更新结构化道路的任务这个地方的重置其实不需要
        # if dynamic_map.lanes_updated:
        # 初始化需要
        if self.last_target_lane_index == -10:
            # print("[Planning]: Updated frenets")

            # self.frenet_lanes = []                # 存储车道的Frenet路径
            # self.last_target_lane_index = -10     # 上一次的目标车道索引

            # 重新构建frenet_lanes,更新每个车道的参考路径
            self.build_frenet_lane(dynamic_map, env)

        # 如果目标车道索引发生变化,清空轨迹缓冲区,并更新上一次目标车道索引
        # FIXME(4.16):这里的逻辑不太对不应该是，全部清除的话路径上一次规划的信息全没了
        if target_lane_index != self.last_target_lane_index:
            # for lane in self.frenet_lanes:
            #     lane.lane_change_clean_buff()

            # 切换frenet,为了保存上一次规划的路径信息
            if self.last_target_lane_index != -10:
                last_frenet_lane = self.frenet_lanes[self.last_target_lane_index]
                new_frenet_lane = self.frenet_lanes[target_lane_index]
                self.change_frenet(last_frenet_lane, new_frenet_lane)

            self.last_target_lane_index = target_lane_index

        # 返回目标车道的轨迹规划结果
        # FIXME: 添加了换道方向选项，保证直行时不会乱选，速度将改成一个采样范围
        return self.frenet_lanes[int(target_lane_index)].trajectory_update(dynamic_map, desired_speed, ref_d, open_result)

    def get_UBP_trajectory(self, dynamic_map, UBP_action, target_lane):
        return self.frenet_lanes[int(target_lane)].trajectory_update_UBP(dynamic_map, UBP_action)


class Werling(object):
    def __init__(self, lane_path, lane_idx, lane_num, env, lane_width = 3):
        """
        函数功能: 初始化Werling轨迹规划器
        输入:
            lane_path: 车道路径
            lane_idx: 车道索引
            lane_num: 车道总数
            lane_width: 车道宽度(原来是3米)
        操作:
            1. 初始化轨迹数组和Frenet路径
            2. 设置参考路径和切线
            3. 构建Frenet路径
        """
        self.last_trajectory_array = np.c_[0, 0]         # 上一次的轨迹数组
        self.last_trajectory = Frenet_path()             # 上一次的Frenet路径
        self.last_trajectory_array_rule = np.c_[0, 0]    # 上一次的轨迹数组(规则)
        self.last_trajectory_rule = Frenet_path()        # 上一次的Frenet路径(规则)

        self.ref_path = None               # 参考路径
        self.ref_path_tangets = None       # 参考路径的切线
        self.ob = None                     # 障碍物
        self.csp = None                    # 样条曲线
        self.target_speed = 0              # 目标速度
        self.idm_target_speed = 0          # IDM目标速度

        self._lane_num = lane_num          # 车道总数
        self._lane_idx = lane_idx          # 目标车道索引
        self._lane_width = lane_width      # 车道宽度

        self.build_frenet_path(lane_path)  # 构建Frenet路径

        self.env = env
        self.draw_trajectory = []

        self.path_i = 0

    def build_frenet_path(self, lane_path):
        """
        函数功能: 构建Frenet路径
        输入:
            lane_path: 车道路径
        操作:
            1. 将车道路径转换为NumPy数组
            2. 使用dense_polyline2d函数生成密集的参考路径点
            3. 提取路径点的x,y坐标
            4. 生成目标路径的样条曲线参数
        """
        if self.csp is None:
            # 将输入的车道路径转换为(x,y)坐标对的列表
            lane_path = [(point.position.x, point.position.y) for point in lane_path]

            # 将列表转换为NumPy数组
            lane_path = np.array(lane_path)

            # 生成密集的参考路径点
            self.ref_path = dense_polyline2d(lane_path, 2)

            # 创建一个与参考路径长度相同的零数组，用于存储切线信息
            self.ref_path_tangets = np.zeros(len(self.ref_path))

            # 提取路径点的x,y坐标
            Frenetrefx = self.ref_path[:,0]
            Frenetrefy = self.ref_path[:,1]

            # 生成目标路径的样条曲线
            tx, ty, tyaw, tc, self.csp = self.generate_target_course(Frenetrefx,Frenetrefy)
            # 返回的变量：
            # - tx, ty: 样条曲线上的点坐标
            # - tyaw: 每个点的偏航角
            # - tc: 曲率
            # - self.csp: 样条曲线对象，用于后续的路径查询

            self.draw_csc_x = tx
            self.draw_csc_y = ty
            
    def lane_change_clean_buff(self):
        """
        函数功能: 清空轨迹缓冲区
        操作:
            1. 清空last_trajectory_array
            2. 清空last_trajectory
            3. 清空last_trajectory_array_rule
            4. 清空last_trajectory_rule
            5. 重置换道方向
        """
        self.last_trajectory_array = np.c_[0, 0]
        self.last_trajectory = Frenet_path()
        self.last_trajectory_array_rule = np.c_[0, 0]
        self.last_trajectory_rule = Frenet_path()

    def trajectory_update(self, dynamic_map, target_speed, ref_d, open_result):
        """
        函数功能: 轨迹更新
        输入:
            dynamic_map: 动态地图
            target_speed: 目标速度
            lc_direction: 换道的方向   0为直行，1为右lc，2为左lc
            speed_bound: 目标速度的范围
        操作:
            1. 初始化碰撞检测器
            2. 计算所有轨迹
            3. 计算起始状态
            4. 返回轨迹动作
        """
        # 初始化碰撞检测器
        self.initialize_obj_predict(dynamic_map)

        # 清空历史轨迹,为新的轨迹规划做准备
        self.all_trajectory = []

        # 获取当前车道索引
        self._ego_lane_index = int(round(dynamic_map.ego_vehicle.lane_idx))


        # 获取自车到目标车道的距离
        distance = dist_from_point_to_polyline2d(
                        dynamic_map.ego_vehicle.x,
                        dynamic_map.ego_vehicle.y,
                        dynamic_map.lanes[self._lane_idx].central_path_array, 
                        return_end_distance=True)
        lane_dist = distance[0]

        # 计算起始状态
        start_state = self.calculate_start_state(dynamic_map)
        # print("[Planning] : Start state",start_state.s0, start_state.c_d)

        # 计算最优轨迹, self.csp为目标车道参考路径, self.c_speed为当前车速, start_state为起始状态, target_speed为目标速度
        # P1: 轨迹时长改为自适应（见 _adaptive_trajectory_horizon），
        #     慢速目标如实生成（不强制 5 m/s），路径长度由拉长的 Ti 保证，刹车档仍生成减速停车轨迹
        generated_trajectory, local_desired_speed = None, 0.0
        if float(target_speed) <= .1 and float(dynamic_map.ego_vehicle.v) <= .1:
            generated_trajectory = self._create_reference_fallback(
                dynamic_map, 0., planning_status='stationary_geometry', speed_limit=None)
        if generated_trajectory is None:
            try:
                generated_trajectory, local_desired_speed, _ = self.frenet_optimal_planning(
                    self.csp, self.c_speed, start_state, float(target_speed),
                    lane_dist, dynamic_map, ref_d, open_result)
            except Exception as e:
                print(f"[Planning] frenet_optimal_planning 异常: {e}")
                generated_trajectory, local_desired_speed = None, 0.0

        # ===== 【R18a】空结果兜底：frenet 规划返回空轨迹时，改用道路参考路径（从自车最近点起算）=====
        #   参考路径永远贴着道路中心线，保证下游 MPC 不会因空轨迹/过期轨迹而跑偏出道路
        if (generated_trajectory is None or
                clean_path(np.c_[generated_trajectory.x, generated_trajectory.y]) is None):
            print("[Planning] 警告：frenet 规划返回空轨迹，使用道路参考路径兜底（从自车最近点起算）")
            generated_trajectory = self._create_reference_fallback(dynamic_map, target_speed)
            if generated_trajectory is None:
                print("[Planning] 参考路径兜底失败，使用刹车轨迹兜底")
                generated_trajectory = self._create_brake_trajectory(dynamic_map)
            local_desired_speed = generated_trajectory.s_d[-1]

        if getattr(generated_trajectory, 'force_stop', False):
            local_desired_speed = 0.0

        # 保存轨迹
        # fixme(6.1):这个使用混合的话这个记录上一次的轨迹会有问题
        trajectory_array = np.c_[generated_trajectory.x, generated_trajectory.y]
        self.last_trajectory_array_rule = trajectory_array
        self.last_trajectory_rule = generated_trajectory

        # ===== DCARL 规则动作 =====
        #   speed   模式：与规则目标速度最接近的速度档位 [0=刹停, 1..7 = 1/2/3/4/5/6/8 m/s]
        #   lateral 模式：默认跟随参考路径 = 横向 offset 0（论文基线动作）
        if ACTION_MODE == 'lateral':
            rule_index = int(np.argmin(np.abs(np.array(TURN_LATERAL_OFFSETS)
                             -float(generated_trajectory.d[-1]))))
        elif ACTION_MODE == '2d':
            # 规则动作 = 横向 offset 0（沿参考路径）、纵向取最接近目标速度的档
            _i_sp = int(np.argmin(np.abs(np.array(TURN_2D_SPEEDS) - max(0.0, float(target_speed)))))
            selected_offset = float(generated_trajectory.d[-1])
            rule_index = _i_sp * _N_LAT + int(np.argmin(
                np.abs(np.array(TURN_2D_LATERALS)-selected_offset)))
        else:
            rule_index = int(np.argmin(np.abs(np.array(TURN_SPEED_LEVELS) - max(0.0, float(target_speed)))))

        # 返回轨迹动作
        trajectory_action = self._as_action(generated_trajectory, local_desired_speed)
        # print("[Planning] : Trajectory",trajectory_array)

        return trajectory_action, rule_index

    # ============================================================
    # ========== 【P0 修复】trajectory_update_UBP 生成真实动作轨迹 ==========
    # ============================================================
    def trajectory_update_UBP(self, dynamic_map, UBP_action):
        """
        UBP 轨迹更新（转弯版：每个动作对应一条真实不同的轨迹）

        speed   模式（默认）：动作0 -> 沿参考路径减速刹停；动作1~7 -> 以 TURN_SPEED_LEVELS[i] 过弯
        lateral 模式（论文式48-49）：动作0~5 -> 横向 offset = TURN_LATERAL_OFFSETS[i] (0~2.5m)
        """
        # 1. 裁剪动作到有效档位
        idx = int(UBP_action)
        if idx < 0:
            idx = 0

        if ACTION_MODE == '2d':
            idx = _clip_action(idx)
            target_speed = action_speed(idx)
            bestpath = self._generate_speed_trajectory(dynamic_map, target_speed,
                                                       di=action_lateral(idx))
        elif ACTION_MODE == 'lateral':
            # 【论文原样】动作=横向 offset，纵向速度取标称巡航（论文基线由规划器给速度剖面）
            if idx >= len(TURN_LATERAL_OFFSETS):
                idx = len(TURN_LATERAL_OFFSETS) - 1
            di = float(TURN_LATERAL_OFFSETS[idx])
            target_speed = float(LATERAL_TARGET_SPEED)
            bestpath = self._generate_speed_trajectory(dynamic_map, target_speed, di=di)
        else:
            if idx >= len(TURN_SPEED_LEVELS):
                idx = len(TURN_SPEED_LEVELS) - 1
            target_speed = TURN_SPEED_LEVELS[idx]
            bestpath = self._generate_speed_trajectory(dynamic_map, target_speed)

        if bestpath is None:
            print("[Planning] _generate_speed_trajectory 失败，尝试道路几何恢复")
            bestpath = self._create_reference_fallback(dynamic_map, target_speed)
            if bestpath is None:
                bestpath = self._create_brake_trajectory(dynamic_map)

        trajectory_array = np.c_[bestpath.x, bestpath.y]
        local_desired_speed = bestpath.s_d[-1] if bestpath.s_d else target_speed

        # 更新上一次轨迹记录（用于后续平滑）
        self.last_trajectory_array_rule = trajectory_array
        self.last_trajectory_rule = bestpath

        # 【式(24)】把候选轨迹的 Frenet 剖面一并带出（供 jerk/steer 计算）
        return self._as_action(bestpath, local_desired_speed)

    def _as_action(self, path, desired_speed):
        """Keep explicit stop/limit semantics when crossing the planner interface."""
        stop = bool(getattr(path, 'force_stop', False))
        return TrajectoryAction(
            np.c_[path.x, path.y], 0. if stop else desired_speed, frenet=path,
            force_stop=stop, speed_limit=getattr(path, 'speed_limit', None),
            planning_status=getattr(path, 'planning_status', 'normal'))

    def _generate_speed_trajectory(self, dynamic_map, target_speed, di=0.0):
        """
        以指定目标速度生成一条 Werling 轨迹。
        di: 横向 offset（m）；speed 模式固定 0（沿参考路径），lateral 模式为论文的动作量。
        不同目标速度/横向offset -> 不同轨迹；每个动作对应真实不同的轨迹。
        返回: Frenet_path 或 None
        """
        if float(target_speed) <= .1 and float(dynamic_map.ego_vehicle.v) <= .1:
            return self._create_reference_fallback(
                dynamic_map, 0., planning_status='stationary_geometry', speed_limit=None)
        try:
            start_state = self.calculate_start_state(dynamic_map)
            preorder_point_set = self.get_last_final_point(dynamic_map)
            preorder_point_set.append((dynamic_map.ego_vehicle.x, dynamic_map.ego_vehicle.y))

            di_range = [float(di)]              # speed模式=0(沿参考路径)；lateral模式=论文的横向offset
            # 自适应轨迹时长：慢速档拉长 Ti 覆盖 ~20m 过弯弧线；刹车档保持 4s 减速停车
            Ti_range = np.array([_adaptive_trajectory_horizon(target_speed)])
            vi_range = np.array([max(0.0, float(target_speed))])

            fplist = self.calc_frenet_paths(self.c_speed, start_state, di_range, Ti_range, vi_range)
            fplist = self.calc_global_paths(fplist, self.csp)
            fplist = [path for path in fplist
                      if clean_path(np.c_[path.x, path.y]) is not None]

            # 拼接曲率代价
            for path in fplist:
                if len(path.x) < 3:
                    continue
                c_k, c_dk, c_ddk = self.cal_montage_curvature(
                    preorder_point_set, path.x[1:3], path.y[1:3])
                path.c_kappa = c_k + c_dk + c_ddk
                path.cf += path.c_kappa

            if len(fplist) == 0:
                return None
            fplist_sorted = sorted(fplist, key=lambda p: p.cf)
            return fplist_sorted[0]
        except Exception as e:
            print(f"[Planning] _generate_speed_trajectory 失败: {e}")
            return None


    def _create_brake_trajectory(self, dynamic_map):
        """Brake explicitly; preserve usable steering geometry even at zero speed."""
        ego = dynamic_map.ego_vehicle
        brake_traj = self._create_reference_fallback(
            dynamic_map, 0., planning_status='planner_stop', speed_limit=0.)
        if brake_traj is None:
            brake_traj = Frenet_path()
            distances = np.linspace(0., 4., 9)
            brake_traj.x = list(ego.x + distances * math.cos(ego.yaw))
            brake_traj.y = list(ego.y + distances * math.sin(ego.yaw))
            brake_traj.s = list(distances)
            brake_traj.d = [0.] * len(distances)
            brake_traj.s_d = [0.] * len(distances)
        brake_traj.force_stop = True
        brake_traj.speed_limit = 0.
        brake_traj.planning_status = 'planner_stop'
        brake_traj.cf = 1e6  # 高成本，避免被优先选择
        return brake_traj

    def _create_reference_fallback(self, dynamic_map, target_speed,
                                   planning_status='road_recovery', speed_limit=2.):
        """
        【R18a】用道路参考路径（从自车最近点起算）生成一条兜底轨迹。
        参考路径永远贴着道路中心线，保证 MPC 不会因空轨迹/过期轨迹跑偏出道路。
        返回 Frenet_path 或 None
        """
        try:
            lanes = getattr(dynamic_map, 'lanes', None)
            if not lanes:
                return None
            idx = int(getattr(self, '_lane_idx', 0))
            if idx < 0 or idx >= len(lanes):
                idx = 0
            ref = getattr(lanes[idx], 'central_path_array', None)
            if ref is None or len(ref) < 3:
                return None
            ego = dynamic_map.ego_vehicle
            pts = road_geometry(ref, ego.x, ego.y)
            if pts is None:
                return None
            fp = Frenet_path()
            fp.x = list(pts[:, 0])
            fp.y = list(pts[:, 1])
            fp.s = list(np.r_[0., np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))])
            fp.d = [0.0] * len(pts)
            speed = max(0., float(target_speed))
            if speed_limit is not None:
                speed = min(speed, float(speed_limit))
            fp.s_d = [speed] * len(pts)
            fp.speed_limit = speed_limit
            fp.planning_status = planning_status
            fp.cf = 1e5  # 高成本：只在兜底时使用
            return fp
        except Exception as e:
            print(f"[Planning] 参考路径兜底失败: {e}")
            return None

    # ============================================================
    # ========== 原有其他方法（未改动） ============================
    # ============================================================

    def initialize_obj_predict(self, dynamic_map):
        """
        函数功能: 初始化碰撞检测器
        输入:
            dynamic_map: 动态地图
        操作:
            1. 创建碰撞检测器
        """
        self.obs_prediction = predict(dynamic_map,OBSTACLES_CONSIDERED,MAXT,DT, 
                                        ROBOT_RADIUS,RADIUS_SPEED_RATIO,MOVE_GAP,
                                        dynamic_map.ego_vehicle.v)

    def calculate_start_state(self, dynamic_map):
        """
        函数功能: 计算起始状态
        输入:
            dynamic_map: 动态地图
        操作:
            1. 计算起始状态
        """
        start_state = Frenet_state()

        """---------------------------------------（算曲率）只把笛卡尔坐标系传过来了这一段先停了---------------------------------------------------------"""
        # if len(self.last_trajectory_array_rule) > 5:
        #     # find closest point on the last trajectory
        #     mindist = float("inf")
        #     bestpoint = 0
        #     for t in range(len(self.last_trajectory_rule.x)):
        #         pointdist = (self.last_trajectory_rule.x[t] - dynamic_map.ego_vehicle.x) ** 2 + (self.last_trajectory_rule.y[t] - dynamic_map.ego_vehicle.y) ** 2
        #         if mindist >= pointdist:
        #             mindist = pointdist
        #             bestpoint = t
        #     start_state.s0 = self.last_trajectory_rule.s[bestpoint]
        #     start_state.c_d = self.last_trajectory_rule.d[bestpoint]
        #     start_state.c_d_d = self.last_trajectory_rule.d_d[bestpoint]
        #     start_state.c_d_dd = self.last_trajectory_rule.d_dd[bestpoint]
        #     # self.c_speed = self.last_trajectory_rule.s_d[bestpoint]
        #     self.c_speed = dynamic_map.ego_vehicle.v
        # else:
        """________________________________________________________________________________________________"""
        self.c_speed = dynamic_map.ego_vehicle.v       # current speed [m/s]
        ffstate = get_frenet_state(dynamic_map.ego_vehicle, self.ref_path, self.ref_path_tangets)

        start_state.s0 = ffstate.s
        start_state.c_d = -ffstate.d           # current lateral position [m]
        start_state.c_d_d = ffstate.vd         # current lateral speed [m/s]
        start_state.c_d_dd = 0                 # current latral acceleration [m/s]  横向的加加速度
            
        return start_state

    def get_last_final_point(self, dynamic_map):
        """
        功能：获取前序轨迹的最近的前一点和再前一点
        逻辑：前序点之前还有一个就返回这两个点，前序点之前没有就返回一个前序点，不符合这个条件就返回空的,注意按顺序排放
        """

        point_set = []

        # 改的时候是把数组传过来
        if len(self.last_trajectory_array_rule) > 5:



            mindist = float("inf")
            sec_mindist = float("inf")
            bestpoint = 0
            sec_bestpoint = 0
            for t in range(len(self.last_trajectory_rule.x)):
                 pointdist = (self.last_trajectory_rule.x[t] - dynamic_map.ego_vehicle.x) ** 2 + (self.last_trajectory_rule.y[t] - dynamic_map.ego_vehicle.y) ** 2
                 if mindist >= pointdist:

                     sec_mindist = mindist
                     sec_bestpoint = bestpoint

                     mindist = pointdist
                     bestpoint = t

                 elif sec_mindist>= pointdist > mindist:
                     sec_mindist = pointdist
                     sec_bestpoint = t

            # 结构化道路下是在两个点之间
            point_before_id = min(bestpoint, sec_bestpoint)
            point_before_ego = (self.last_trajectory_rule.x[point_before_id], self.last_trajectory_rule.y[point_before_id])

            # 前序点之前还有点
            if point_before_ego != 0:
                sec_point_before_id = point_before_id - 1
                sec_point_before_ego = (self.last_trajectory_rule.x[sec_point_before_id], self.last_trajectory_rule.y[sec_point_before_id])
                point_set.append(sec_point_before_ego)

            point_set.append(point_before_ego)

        return point_set



    def frenet_optimal_planning(self, csp, c_speed, start_state, low_resolution_speed, lane_dist, dynamic_map, ref_d, open_result):
        """
        函数功能: Frenet最优规划
        输入:
            csp: 样条曲线
            c_speed: 当前速度
            start_state: 起始状态
            low_resolution_speed: 低分辨率速度
        操作:
            1. 计算路径
            2.计算前序路点进行曲率计算
        """
        if _os.environ.get('DSH_CONTROL_PROFILE', 'legacy') in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
            width = float(getattr(dynamic_map.ego_vehicle, 'width', 2.) or 2.)
            bound = max(0., (self._lane_width-width)/2.-.1)
            offsets = TURN_2D_LATERALS if ACTION_MODE == '2d' else TURN_LATERAL_OFFSETS
            offsets = [float(d) for d in offsets if abs(d) <= bound+1e-6]
            if not offsets:
                offsets = [0.]
            previous = self.get_last_final_point(dynamic_map)
            previous.append((dynamic_map.ego_vehicle.x, dynamic_map.ego_vehicle.y))
            path, valid, index = self.calculate_path_in_given_range(
                csp, c_speed, start_state, offsets,
                [_adaptive_trajectory_horizon(low_resolution_speed)],
                [max(0., float(low_resolution_speed))], True, previous, 0)
            return (path, path.s_d[-1], index) if valid else (None, 0., 0)
        # 绘制车道中心线csp参考线
        confidence_values = [1]
        x_list = []
        y_list = []
        for x, y in zip(self.draw_csc_x, self.draw_csc_y):
            x_list.append(x)
            y_list.append(y)
        traj = Trajectory(x_list, y_list)    # 创建轨迹对象      
        draw_csp_path = [(traj,)]            # 将轨迹对象包装成元组，并放入列表中
        # self.env.draw_traj_HRL(draw_csp_path, confidence_values, 0)
        self.env.draw_traj(draw_csp_path)

        # FIXME（4.2改速度范围）:多选速度
        self.idm_target_speed = low_resolution_speed

        # 前序路点
        preorder_point_set = self.get_last_final_point(dynamic_map)
        current_point = (dynamic_map.ego_vehicle.x, dynamic_map.ego_vehicle.y)
        preorder_point_set.append(current_point)


        # 第一次尝试：保持当前车道中心线 No adjustment --------------------------------------------------------------------
        # fixme:这里规划的轨迹永远用不到
        di_range = np.array([0])
        Ti_range = np.array([_adaptive_trajectory_horizon(low_resolution_speed)])
        vi_range = np.array([max(10/3.6, low_resolution_speed)])

        best_free_fp, first_fp_available, first_index = self.calculate_path_in_given_range(csp, c_speed, start_state, 
                                                                            di_range, Ti_range, vi_range, True, preorder_point_set, open_result)
        
        # if first_fp_available:
        #     print("[Planning]: First try success!")

        #     # 画出候选轨迹集
        #     confidence_values = [1]
        #     self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
        #     self.draw_trajectory = []

        #     return best_free_fp, best_free_fp.s_d[-1], first_index + 1

        # 第二次尝试：横向微调 Lateral_Planner slight adjustment -----------------------------------------------------------------
        # right_bound = - (max((self._lane_idx - self._ego_lane_index),0) * self._lane_width + 0.5 * self._lane_width)
        # left_bound = max(self._ego_lane_index - self._lane_idx, 0) * self._lane_width + 0.5 * self._lane_width
        # sample_width_d = 0.125 * self._lane_width

        # 锁定轨迹横向偏移范围，中心车道已直接对应目标车道中心线，现在这个范围刚好是单个车道宽度
        right_bound = -2
        left_bound = 2.5
        sample_width_d = 0.5
        # speed_low_bound = speed_bound[0]
        # speed_high_bound = speed_bound[1]
        # speed_sample_d = 1   # m/s
        # low_resolution_speed = 40 /3.6

        # note:这里做的选取规矩依据本质是曲率不同
        # di_range = np.arange(right_bound, left_bound + sample_width_d, sample_width_d)
        # di_range = [ref_d]
        # Ti_range = np.arange(MINT, MAXT, DT)
        # vi_range = np.arange(speed_low_bound, speed_high_bound + speed_sample_d, speed_sample_d)

        # 切入轨迹只用曲率完全不可行，中间会漏掉一段交互
        if ref_d == 0:
            di_range = [ref_d]
        else:
            di_range = np.arange(0, left_bound + sample_width_d, sample_width_d)
        # Ti_range = np.arange(3.0, 7.0, 0.3)
        Ti_range = np.array([_adaptive_trajectory_horizon(low_resolution_speed)])
        vi_range = np.array([max(10/3.6, low_resolution_speed)])

        second_generated_fp, second_fp_available, second_index = self.calculate_path_in_given_range(csp, c_speed, start_state, 
                                                                            di_range, Ti_range, vi_range, False, preorder_point_set, open_result)
        
        # 画出候选轨迹集
        confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
        self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
        self.draw_trajectory = []

        # if second_fp_available:
        #     print("[Planning]: Second try success!")

        #     # 画出候选轨迹集
        #     confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
        #     self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
        #     self.draw_trajectory = []

        #     return second_generated_fp, second_generated_fp.s_d[-1], second_index + 1

        # 第三次尝试：速度微调 Speed slight adjustment -------------------------------------------------------------------
        # speed_adjust_thres = 40/3.6
        # speed_low_bound = max(low_resolution_speed, 1/3.6)
        # speed_high_bound = max(low_resolution_speed, speed_adjust_thres)
        # speed_sample_d = 1/3.6    # m/s

        # # 根据自车速度锁定轨迹速度范围
        # speed_low_bound  = max(c_speed - 5 * MINT, 1/3.6)    # 最低速度小于0会自动拿掉低于0的轨迹导致数量不一
        # speed_high_bound = c_speed + 5 * MINT                # 以每秒最大加速度划定轨迹速度范围
        # speed_sample_d = 0.1*(speed_high_bound - speed_low_bound)
        # print("[Planning]: Third try range", c_speed*3.6, speed_low_bound*3.6, speed_high_bound*3.6, speed_sample_d*3.6)

        # # 锁定轨迹速度范围
        # speed_low_bound = 5/3.6
        # speed_high_bound = 40/3.6
        # speed_sample_d = 5/3.6

        # di_range = np.arange(right_bound, left_bound + sample_width_d, sample_width_d)
        # Ti_range = np.arange(MINT, MAXT, DT)
        # vi_range = np.arange(speed_low_bound, speed_high_bound + speed_sample_d, speed_sample_d)

        # # 如果vi_range长度超过10，取前10个数
        # if len(vi_range) > 11:
        #     vi_range = vi_range[:11]

        # third_generated_fp, third_fp_available, third_index = self.calculate_path_in_given_range(csp, c_speed, start_state, 
        #                                                                     di_range, Ti_range, vi_range, False)

        # # 画出候选轨迹集
        # confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
        # self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
        # self.draw_trajectory = []

        # if third_fp_available:
        #     print("[Planning]: Third try success!")

        #     # 画出候选轨迹集
        #     confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
        #     self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
        #     self.draw_trajectory = []

        #     return third_generated_fp, third_generated_fp.s_d[-1], third_index + 1

        # print("[Planning]: All try failed! BRAKE!")    
        # return best_free_fp, 0, 0

        """------------ 用于DCARL的轨迹选择,只使用规则轨迹可以采用上面的方案降低计算量 ------------"""
        first_fp_available  = False     # 不用第一次尝试策略
        # second_fp_available = False     # 不用第二次尝试策略
        third_fp_available  = False     # 不用第三次尝试策略

        if first_fp_available:
            print("[Planning]: First try success!")

            # # 画出候选轨迹集
            # confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
            # self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
            # self.draw_trajectory = []

            return best_free_fp, best_free_fp.s_d[-1], first_index + 1
        else:
            if second_fp_available:
                print("[Planning]: Second try success!")

                # # 画出候选轨迹集
                # confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
                # self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
                # self.draw_trajectory = []

                return second_generated_fp, second_generated_fp.s_d[-1], second_index + 1
            else:
                if third_fp_available:
                    print("[Planning]: Third try success!")

                    # # 画出候选轨迹集
                    # confidence_values = [1.0 + (i % 2) * 0.1 for i in range(len(self.draw_trajectory)+1)]
                    # self.env.draw_traj_HRL(self.draw_trajectory, confidence_values, 0)
                    # self.draw_trajectory = []

                    return third_generated_fp, third_generated_fp.s_d[-1], third_index + 1

        # ===== 【关键修改】如果没有可用轨迹，生成刹车轨迹兜底，防止MPC崩溃 =====
        print("[Planning]: No available path! Generating brake trajectory fallback...")
        
        # 生成一条安全的刹车轨迹（沿当前方向短距离刹停）
        brake_traj = self._create_brake_trajectory(dynamic_map)
        
        # 添加到all_trajectory中
        self.all_trajectory.append([brake_traj, brake_traj.cf, 0])
        
        return brake_traj, 0, 0

    def calculate_path_in_given_range(self, csp, c_speed, start_state, di_range, Ti_range, vi_range, call_sign, point_set, open_result):
        """
        函数功能: 计算路径
        NOTE:yaw角是用轨迹相邻两点计算的
        输入:
            csp: 样条曲线
            c_speed: 当前速度
            start_state: 起始状态
            di_range: 横向范围
            Ti_range: 时间范围
            vi_range: 速度范围
            point_set: 前序规划的点集合，用于计算拼接代价
        返回:
            best_fp: 最优轨迹
            bool: 是否找到无碰撞路径
        """
        fplist = self.calc_frenet_paths(c_speed, start_state, di_range, Ti_range, vi_range)
        fplist = self.calc_global_paths(fplist, csp)
        # fplist = self.check_paths(fplist)
        # print("fplist",len(fplist))

        # TODO(4.16为每条路径计算曲率开销)：
        for path in fplist:
            # 确保路径至少3个点再计算拼接曲率，防止路径过短样条越界崩溃
            if len(path.x) < 3:
                continue
            plan_path_x = path.x[1:3]
            plan_path_y = path.y[1:3]
            c_k, c_dk, c_ddk = self.cal_montage_curvature(point_set, plan_path_x, plan_path_y)

            path.c_k = c_k
            path.c_k_d = c_dk
            path.c_k_dd = c_ddk
            path.c_kappa = c_k + c_dk + c_ddk

            path.cf += path.c_kappa




        if len(fplist) == 0: 
            return None, False, 0

        # self.all_trajectory.extend(fplist)
        # print("[Planning] : All trajectory num",len(self.all_trajectory))

        if call_sign:
            self.path_i = 0

        path_tuples = []
        for fp in fplist:
            one_path = [fp, fp.cf, self.path_i]

            self.all_trajectory.append(one_path)
            path_tuples.append(one_path)
            self.draw_trajectory.append(one_path)

            self.path_i = self.path_i + 1
        
        # print("[Planning]: Path tuples num",len(path_tuples))
        # print("[Planning]: All trajectory num",len(self.all_trajectory))

        sorted_fplist = sorted(path_tuples, key=lambda path_tuples: path_tuples[1])
        if _os.environ.get('DSH_CONTROL_PROFILE', 'legacy') in ('paper_v7', 'paper_v8', 'paper_v9', 'paper_v10', 'paper_v11'):
            from Planning_library.paper_turn_control import baseline_geometry_cost
            path_tuples = [(fp, baseline_geometry_cost(fp), idx)
                           for fp, _, idx in path_tuples
                           if clean_path(np.c_[fp.x, fp.y]) is not None]
            path_tuples = [entry for entry in path_tuples if np.isfinite(entry[1])]
            if not path_tuples:
                return None, False, 0
            sorted_fplist = sorted(path_tuples, key=lambda entry: entry[1])
        best_fp, _, index = sorted_fplist[0]


        # for fp, score, index in sorted_fplist:
        #     if self.obs_prediction.check_collision(fp):
        #         return fp, True, index

        # TODO:改成概率选择(可能开概率也可能不开概率)
        """------------------------概率选择轨迹------------------------------------"""
        # if len(sorted_fplist) > 5 and open_result == 1:
        #     candidate_trajectory = sorted_fplist[:10]
        #     candidate_trajectory_cost = [cost[1] for cost in candidate_trajectory]
        #
        #     candidate_index = candidate_trajectory_cost.index(
        #         random.choices(candidate_trajectory_cost, weights=[1 / v for v in candidate_trajectory_cost], k=1)[0])
        #     best_fp, _, index = candidate_trajectory[candidate_index]
        """-----------------------------finish-----------------------------------"""

        return best_fp, True, index

        # return best_fp, False, index


    def cal_montage_curvature(self, preorder_point_set, plan_point_x, plan_point_y):
        """
        功能：计算轨迹连接处的曲率（低速时容易因为曲率跳跃而猛打方向盘或者直接不走了）
        逻辑：
            1.构建5个点的spline类别(需要判断传入的前序点个数)
            2.计算前序达到当下状态的三点的曲率
            3.计算包括前一条、拼接点、下一条轨迹三个点轨迹曲率（步进一个点）   拼接处曲率
            4.计算拼接点、下一条轨迹两个点的曲率（步进一个点）              后一个轨迹曲率
            5.计算两个曲率是否连续dk_ds = Δk / 步长 ds

            * 前序无点：算下一步的曲率，下一步曲率惩罚
              前序只有一个点：加上拼接惩罚                              k突变 > 0.015
              前序两个点：前后曲率跨度惩罚                              变化率 > 0.01
        输入：前序点列表(包括拼接点)、后一段轨迹分别的x和y列表
        输出：拼接惩罚、曲率突变惩罚
        """

        preorder_montage_line_x = [point[0] for point in preorder_point_set]
        preorder_montage_line_y = [point[1] for point in preorder_point_set]

        montage_line_x = preorder_montage_line_x + list(plan_point_x)
        montage_line_y = preorder_montage_line_y + list(plan_point_y)

        # 拼接点少于 3 个无法构建三次样条（Spline 需要 nx>=3），直接返回零惩罚
        if len(montage_line_x) < 3 or len(montage_line_y) < 3:
            return 0.0, 0.0, 0.0

        montage_spline = Spline2D(montage_line_x, montage_line_y)

        # 插值计算曲率（感觉没必要）
        # s = np.arange(0, montage_spline.s[-1], 0.1)
        s = montage_spline.s

        # 正常五点
        if len(s) == 5:
            kappa_s = s[1:4]
        elif len(s) == 4:
            kappa_s = s[1:3]
        else:
            kappa_s = [s[1]]

        kappa = []
        for i_s in kappa_s:
            kappa.append(montage_spline.calc_curvature(i_s))  # 计算路径点的曲率

        if len(kappa) == 3:
            delta_kappa = abs(kappa[0] - kappa[2])
            accumulate_s = sum(kappa_s)
            dk_ds = delta_kappa/accumulate_s
        elif len(kappa) == 2:
            delta_kappa = abs(kappa[0] - kappa[1])
            accumulate_s = sum(kappa_s)
            dk_ds = delta_kappa/accumulate_s
        # 只有后续的路点（应该不会有，无论如何都包括当前路点）
        else:
            delta_kappa = abs(kappa[0])
            dk_ds = delta_kappa/kappa_s[-1]

        """-------------------------------制定曲率惩罚---------------------------------------"""
        # hinge软约束
        def penalty(x, lim, w):
            a = np.abs(x)
            # 【式(49)】hinge(x) = |x|² + ω_TH·𝕀(|x|>x_TH)·|x|²；
            #   论文 Table I 的 ω_TH = **10**（原来是硬编码 1e6，**与论文不符**）。
            return np.sum(w * (a ** 2 + HINGE_W * (a > lim) * a ** 2))

        # 曲率
        cost_k = penalty(kappa[-1], MAX_ABS_K, W_K)
        # 曲率变化
        cost_dk = penalty(delta_kappa, MAX_ABS_DK, W_DK)
        # 曲率变化率
        cost_dkds = penalty(dk_ds, MAX_ABS_DKDS, W_DKDS)

        return cost_k, cost_dk, cost_dkds


    def generate_target_course(self, x, y):
        """
        函数功能: 生成目标路径
        输入:
            x: x坐标
            y: y坐标
        操作:
            1. 生成目标路径
        """
        # 生成1条平滑的目标路径
        csp = Spline2D(x, y)

        # 生成密集的参考路径点
        s = np.arange(0, csp.s[-1], 0.1)

        rx, ry, ryaw, rk = [], [], [], []
        for i_s in s:
            ix, iy = csp.calc_position(i_s)       # 计算路径点的x,y坐标
            rx.append(ix)
            ry.append(iy)
            ryaw.append(csp.calc_yaw(i_s))        # 计算路径点的航向角
            rk.append(csp.calc_curvature(i_s))    # 计算路径点的曲率

        return rx, ry, ryaw, rk, csp

    def calc_frenet_paths(self, c_speed, start_state, di_range, Ti_range, vi_range): # input state
        """
        函数功能: 计算Frenet路径
        输入:
            c_speed: 当前速度
            start_state: 起始状态
            di_range: 横向范围
            Ti_range: 时间范围
            vi_range: 速度范围
        操作:
            1. 计算Frenet路径
        """
        # 初始化路径列表
        frenet_paths = []

        # 获取起始状态
        s0 = start_state.s0            # 起始纵向位置
        c_d = start_state.c_d          # 起始横向位置
        c_d_d = start_state.c_d_d      # 起始横向速度
        c_d_dd = start_state.c_d_dd    # 起始横向加速度

        for di in di_range:
            # 横向运动规划 Lateral_Planner motion planning
            for Ti in Ti_range:
                fp = Frenet_path()

                # 使用五次多项式生成横向轨迹
                lat_qp = quintic_polynomial(c_d, c_d_d, c_d_dd, di, 0.0, 0.0, Ti) 

                # 计算时间序列
                fp.t = [t for t in np.arange(0.0, Ti, DT)]

                # 计算横向位置、速度、加速度、急动度
                fp.d = [lat_qp.calc_point(t) for t in fp.t]                        
                fp.d_d = [lat_qp.calc_first_derivative(t) for t in fp.t]
                fp.d_dd = [lat_qp.calc_second_derivative(t) for t in fp.t]
                fp.d_ddd = [lat_qp.calc_third_derivative(t) for t in fp.t]

                # 纵向运动规划 Longitudinal motion planning
                for tv in vi_range:

                    # 忽略负速度
                    if tv < 0:
                        continue
                
                    tfp = copy.deepcopy(fp)
                    lon_qp = quartic_polynomial(s0, c_speed, 0.0, tv, 0.0, Ti)

                    tfp.s = [lon_qp.calc_point(t) for t in fp.t]
                    tfp.s_d = [lon_qp.calc_first_derivative(t) for t in fp.t]
                    tfp.s_dd = [lon_qp.calc_second_derivative(t) for t in fp.t]
                    tfp.s_ddd = [lon_qp.calc_third_derivative(t) for t in fp.t]

                    Jp = sum(np.power(tfp.d_ddd, 2))  # square of jerk
                    Js = sum(np.power(tfp.s_ddd, 2))  # square of jerk

                    # # square of diff from target speed
                    # ds = (self.target_speed - tfp.s_d[-1])**2

                    # # 原作者成本函数
                    # tfp.cd = KJ * Jp + KT * Ti + KD * tfp.d[-1]**2    
                    # tfp.cv = KJ * Js + KT * Ti + KD * ds
                    # tfp.cf = KLAT * tfp.cd + KLON * tfp.cv

                    # 成本函数
                    # print("self.idm_target_speed",self.idm_target_speed)
                    # 横向的速度项先不要
                    # ds = abs(self.idm_target_speed - tfp.s_d[-1])**2
                    # 目标速度项：鼓励更快的末速度（防除零，刹车档 tv=0 时兜底）
                    ds = 1 / max(abs(tfp.s_d[-1]), 0.1) ** 2
                    tfp.cd = KJ * Jp + KT * Ti + 1 * tfp.d[-1]**2    
                    tfp.cv = KJ * Js + KT * Ti + 1 * ds
                    tfp.cf = KLAT * tfp.cd + KLON * tfp.cv
                    # print("di",di,"tv",tv,"cf",tfp.cf)
                    # print("Jp,Ti,tfp.d[-1]**2,tfp.cd",Jp,Ti,tfp.d[-1]**2,tfp.cd)
                    # print("Js,Ti,ds,tfp.cv",Js,Ti,ds,tfp.cv)

                    frenet_paths.append(tfp)

        return frenet_paths

    def calc_global_paths(self, fplist, csp):
        """
        函数功能: 计算全局路径
        输入:
            fplist: Frenet路径列表
            csp: 样条曲线
        操作:
            1. 计算全局路径
        """
        # 遍历Frenet路径列表中的每一条路径
        for fp in fplist:

            # calc global positions
            for i in range(len(fp.s)):
                ix, iy = csp.calc_position(fp.s[i])
                if ix is None:
                    break
                iyaw = csp.calc_yaw(fp.s[i])
                di = fp.d[i]
                fx = ix + di * math.cos(iyaw + math.pi / 2.0)
                fy = iy + di * math.sin(iyaw + math.pi / 2.0)
                fp.x.append(fx)
                fp.y.append(fy)
                # print(f"ix:{ix}, iy:{ix}, iyaw:{iyaw}, di:{di}, fx:{fx}, fy:{fy}")

            # calc yaw and ds
            for i in range(len(fp.x) - 1):
                dx = fp.x[i + 1] - fp.x[i]
                dy = fp.y[i + 1] - fp.y[i]
                fp.yaw.append(math.atan2(dy, dx))
                fp.ds.append(math.sqrt(dx**2 + dy**2))

            
            try:
                fp.yaw.append(fp.yaw[-1])
                fp.ds.append(fp.ds[-1])
            except:
                fp.yaw.append(0.1)
                fp.ds.append(0.1)

            # calc curvature
            for i in range(len(fp.yaw) - 1):
                fp.c.append((fp.yaw[i + 1] - fp.yaw[i]) / fp.ds[i])

        return fplist

    def check_paths(self, fplist):
        """
        函数功能: 检查路径
        输入:
            fplist: Frenet路径列表
        操作:
            1. 检查路径
        """
        okind = []
        for i, _ in enumerate(fplist):

            if any([v > MAX_SPEED for v in fplist[i].s_d]):           # Max speed check
                continue
            elif any([abs(a) > MAX_ACCEL for a in fplist[i].s_dd]):   # Max accel check
                continue
            elif any([abs(c) > MAX_CURVATURE for c in fplist[i].c]):  # Max curvature check
                continue

            okind.append(i)

        return [fplist[i] for i in okind]


class quintic_polynomial:
    def __init__(self, xs, vxs, axs, xe, vxe, axe, T): # s=start  e=end

        # calc coefficient of quintic polynomial
        self.xs = xs
        self.vxs = vxs
        self.axs = axs
        self.xe = xe
        self.vxe = vxe
        self.axe = axe

        self.a0 = xs
        self.a1 = vxs
        self.a2 = axs / 2.0

        A = np.array([[T**3, T**4, T**5],
                      [3 * T ** 2, 4 * T ** 3, 5 * T ** 4],
                      [6 * T, 12 * T ** 2, 20 * T ** 3]])
        b = np.array([xe - self.a0 - self.a1 * T - self.a2 * T**2,
                      vxe - self.a1 - 2 * self.a2 * T,
                      axe - 2 * self.a2])
        x = np.linalg.solve(A, b)

        self.a3 = x[0]
        self.a4 = x[1]
        self.a5 = x[2]

    def calc_point(self, t):
        xt = self.a0 + self.a1 * t + self.a2 * t**2 + \
            self.a3 * t**3 + self.a4 * t**4 + self.a5 * t**5

        return xt

    def calc_first_derivative(self, t):
        xt = self.a1 + 2 * self.a2 * t + \
            3 * self.a3 * t**2 + 4 * self.a4 * t**3 + 5 * self.a5 * t**4

        return xt

    def calc_second_derivative(self, t):
        xt = 2 * self.a2 + 6 * self.a3 * t + 12 * self.a4 * t**2 + 20 * self.a5 * t**3

        return xt

    def calc_third_derivative(self, t):
        xt = 6 * self.a3 + 24 * self.a4 * t + 60 * self.a5 * t**2

        return xt


class quartic_polynomial:
    def __init__(self, xs, vxs, axs, vxe, axe, T):

        # calc coefficient of quintic polynomial
        self.xs = xs
        self.vxs = vxs
        self.axs = axs
        self.vxe = vxe
        self.axe = axe

        self.a0 = xs
        self.a1 = vxs
        self.a2 = axs / 2.0

        A = np.array([[3 * T ** 2, 4 * T ** 3],
                      [6 * T, 12 * T ** 2]])
        b = np.array([vxe - self.a1 - 2 * self.a2 * T,
                      axe - 2 * self.a2])
        x = np.linalg.solve(A, b)

        self.a3 = x[0]
        self.a4 = x[1]

    def calc_point(self, t):
        xt = self.a0 + self.a1 * t + self.a2 * t**2 + \
            self.a3 * t**3 + self.a4 * t**4

        return xt

    def calc_first_derivative(self, t):
        xt = self.a1 + 2 * self.a2 * t + \
            3 * self.a3 * t**2 + 4 * self.a4 * t**3

        return xt

    def calc_second_derivative(self, t):
        xt = 2 * self.a2 + 6 * self.a3 * t + 12 * self.a4 * t**2

        return xt

    def calc_third_derivative(self, t):
        xt = 6 * self.a3 + 24 * self.a4 * t

        return xt


class Spline:
    """
    Cubic Spline class
    """
    def __init__(self, x, y):
        self.b, self.c, self.d, self.w = [], [], [], []

        self.x = x                  # 输入的一连串x
        self.y = y                  # 输入的一连串y

        self.nx = len(x)  # dimension of x
        h = np.diff(x)

        # calc coefficient c
        self.a = [iy for iy in y]

        # calc coefficient c
        A = self.__calc_A(h)
        B = self.__calc_B(h)
        self.c = np.linalg.solve(A, B)

        # calc spline coefficient b and d
        for i in range(self.nx - 1):
            self.d.append((self.c[i + 1] - self.c[i]) / (3.0 * h[i]))
            tb = (self.a[i + 1] - self.a[i]) / h[i] - h[i] * \
                (self.c[i + 1] + 2.0 * self.c[i]) / 3.0
            self.b.append(tb)

    def calc(self, t):
        """
        Calc position

        if t is outside of the input x, return None

        """        
        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None
        i = self.__search_index(t)
        dx = t - self.x[i]
        result = self.a[i] + self.b[i] * dx + self.c[i] * dx ** 2.0 + self.d[i] * dx ** 3.0
        
        return result

    def calcd(self, t):
        """
        Calc first derivative

        if t is outside of the input x, return None
        """
        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None
 
        i = self.__search_index(t)
        dx = t - self.x[i]
        result = self.b[i] + 2.0 * self.c[i] * dx + 3.0 * self.d[i] * dx ** 2.0
        return result

    def calcdd(self, t):
        """
        Calc second derivative
        """

        if t < self.x[0]:
            return None
        elif t > self.x[-1]:
            return None

        i = self.__search_index(t)
        dx = t - self.x[i]
        result = 2.0 * self.c[i] + 6.0 * self.d[i] * dx
        return result

    def __search_index(self, x):
        """
        search data segment index
        边界保护：x 等于路径终点时 bisect 返回 len-1，会越界访问 b/c/d（长度为 nx-1），
        这里归位到最后一个区间 [nx-2]；x 小于起点时归位到 [0]。
        """
        i = bisect.bisect(self.x, x) - 1
        if i >= self.nx - 1:
            i = self.nx - 2
        if i < 0:
            i = 0
        return i

    def __calc_A(self, h):
        """
        calc matrix A for spline coefficient c
        """
        A = np.zeros((self.nx, self.nx))
        A[0, 0] = 1.0
        for i in range(self.nx - 1):
            if i != (self.nx - 2):
                A[i + 1, i + 1] = 2.0 * (h[i] + h[i + 1])
            A[i + 1, i] = h[i]
            A[i, i + 1] = h[i]

        A[0, 1] = 0.0
        A[self.nx - 1, self.nx - 2] = 0.0
        A[self.nx - 1, self.nx - 1] = 1.0
        #  print(A)
        return A

    def __calc_B(self, h):
        """
        calc matrix B for spline coefficient c
        """
        B = np.zeros(self.nx)
        for i in range(self.nx - 2):
            B[i + 1] = 3.0 * (self.a[i + 2] - self.a[i + 1]) / \
                h[i + 1] - 3.0 * (self.a[i + 1] - self.a[i]) / h[i]
        #  print(B)

        return B


class Spline2D:
    """
    2D Cubic Spline class
    """
    def __init__(self, x, y):
        self.s = self.__calc_s(x, y)            # 累积弧长数组
        self.sx = Spline(self.s, x)             # 创建了一个「弧长 s → X 坐标」的映射函数
        self.sy = Spline(self.s, y)             # 弧长到y坐标的映射

    def __calc_s(self, x, y):
        dx = np.diff(x)
        dy = np.diff(y)

        # 2. 计算每一小段的直线长度
        self.ds = [math.sqrt(idx ** 2 + idy ** 2)
                   for (idx, idy) in zip(dx, dy)]
        s = [0]
        # 3. 生成累计弧长数组 s
        s.extend(np.cumsum(self.ds))
        return s

    def calc_position(self, s):
        """
        calc position
        """
        x = self.sx.calc(s)
        y = self.sy.calc(s)

        return x, y

    def calc_curvature(self, s):
        """
        calc curvature
        """
        dx = self.sx.calcd(s)
        ddx = self.sx.calcdd(s)
        dy = self.sy.calcd(s)
        ddy = self.sy.calcdd(s)
        # kappa计算应该下面是乘一个1.5
        k = (ddy * dx - ddx * dy) / (dx ** 2 + dy ** 2)**1.5
        return k

    def calc_yaw(self, s):
        """
        calc yaw
        """
        dx = self.sx.calcd(s)
        dy = self.sy.calcd(s)
        yaw = math.atan2(dy, dx)
        return yaw
