"""
这段代码实现了一个车道级别的路径规划器 LanePlanner,用于自动驾驶车辆的车道选择和速度控制.代码的核心功能包括：
    车道选择(MOBIL)：根据当前车道和目标车道的效用值，决定是否进行车道变换, 包含过渡车道决策
    速度控制 (IDM) ：使用智能驾驶模型(IDM)来计算目标车道的理想速度。
"""
import numpy as np
import math
import random
from Agent.tools_dds.actions import LaneAction

class LanePlanner(object):
    """
    车道级路径规划器 MOBIL (Minimizing Overall Braking Induced by Lane changes)
    负责选择目标车道和速度
    """
    def __init__(self):
        """ 初始化方法为空，因为初始化时不需要任何操作 """
        self.stay_trans_time = 0

        self.last_current_lane = None
        self.last_target_lane = None

        self.last_idm_a = None
        # pass    

    def _secure_lane(self, idx):
        """安全取车道：索引越界时 clamp 到有效范围，避免 IndexError
        turn 场景可用车道数可能少于换道原版的假设(如 lanes[3])，故做兜底。"""
        lanes = self.dynamic_map.lanes
        n = len(lanes)
        if n == 0:
            from types import SimpleNamespace
            return SimpleNamespace(rear_vehicles=[], front_vehicles=[], central_path_array=[])
        try:
            idx = int(idx)
        except Exception:
            idx = 0
        if idx < 0:
            idx = 0
        if idx >= n:
            idx = n - 1
        return lanes[idx]

    def run_step(self, dynamic_map, idm_a):
        """
        函数功能: 根据当前车道和目标车道的效用值，决定是否进行车道变换,使用智能驾驶模型(IDM)来计算目标车道的理想速度。
        输入：
            dynamic_map: 动态地图
        输出：
            LaneAction: 车道动作，包含目标车道索引和目标速度
        """
        # if self.last_idm_a != idm_a or self.last_idm_a is None:
        #     aggressive_rate = (idm_a -1) / (5 - 1)
        #
        #     self.d_front_thres = np.clip(np.random.normal(loc=3+(10-3)*(1-aggressive_rate), scale=1.0), 3, 10)
        #     self.t_front_thres = np.clip(np.random.normal(loc=3+(15-3)*(1-aggressive_rate), scale=1.0), 3, 15)
        #
        #     self.d_rear_trans_thres = np.clip(np.random.normal(loc=2+(10-2)*(1-aggressive_rate), scale=1.0), 2, 10)
        #     self.d_rear_thres = np.clip(np.random.normal(loc=self.d_rear_trans_thres+(15-self.d_rear_trans_thres)*(1-aggressive_rate), scale=1.0), self.d_rear_trans_thres, 15)
        #
        #     self.t_rear_trans_thres = np.clip(np.random.normal(loc=2+(10-2)*(1-aggressive_rate), scale=1.0), 2, 10)
        #     self.t_rear_thres = np.clip(np.random.normal(loc=self.t_rear_trans_thres+(15-self.t_rear_trans_thres)*(1-aggressive_rate), scale=1.0), self.t_rear_trans_thres, 15)

        # 固定阈值实验
        # idm_a = 1.6
        # aggressive_rate = (idm_a - 1) / (5 - 1)
        # self.d_front_thres = 3 + (10 - 3) * (1 - aggressive_rate)
        # self.t_front_thres = 3 + (15 - 3) * (1 - aggressive_rate)
        #
        # self.d_rear_trans_thres = 2 + (10 - 2) * (1 - aggressive_rate)
        # self.d_rear_thres = self.d_rear_trans_thres + (15 - self.d_rear_trans_thres) * (1 - aggressive_rate)
        #
        # self.t_rear_trans_thres = 2 + (10 - 2) * (1 - aggressive_rate)
        # self.t_rear_thres = self.t_rear_trans_thres + (15 - self.t_rear_trans_thres) * (1 - aggressive_rate)

        self.d_front_thres = 5
        self.t_front_thres = 2

        self.d_rear_trans_thres = 2
        self.d_rear_thres = 5

        self.t_rear_trans_thres = 1
        self.t_rear_thres = 2



        self.last_idm_a = idm_a

        print("[IDM + MOBIL]: IDM max acc = ", idm_a)

        # epsilon = np.clip(np.random.normal(loc=(idm_a-1)/4, scale=1.0), 0, 1)     # 正态分布
        # epsilon = random.random()          # 0-1 之间随机生成一个数
        # epsilon = random.randint(4, 15)    # 两个数之间随机生成一个整数
        # epsilon = random.uniform(4, 15)    # 4到15之间的随机浮点数

        # 创建IDM (Intelligent Driver Model) 实例，用于计算目标车道的理想速度
        self.longitudinal_model_instance = IDM(dynamic_map, idm_a)

        # 保存动态地图
        self.dynamic_map = dynamic_map

        # 生成目标车道索引
        target_index, target_speed = self.generate_lane_change_index()

        target_index = self._get_turn_preference_lane(target_index)

        # 调整行为
        target_index, target_speed = self.behavior_adjust(target_index, target_speed)

        # 打印车道索引和速度
        print(f"[IDM + MOBIL]---> ego_lane:{self.dynamic_map.ego_vehicle.lane_idx}, target_lane:{target_index}, lanes_num:{len(self.dynamic_map.lanes)}")
        print(f"[IDM + MOBIL]---> ego_speed:{self.dynamic_map.ego_vehicle.v}, target_speed:{target_speed}")
        
        return LaneAction(target_index, target_speed)

    def _get_turn_preference_lane(self, default_lane):
        """在左转场景中，靠近交叉口时优先选择左侧目标车道。"""
        try:
            ego_x = self.dynamic_map.ego_vehicle.x
            ego_y = self.dynamic_map.ego_vehicle.y
            center = getattr(self.dynamic_map.env, "INTERSECTION_CENTER", None)
            if center is not None:
                cx, cy = center
                dist = math.hypot(ego_x - cx, ego_y - cy)
                if dist <= 45.0:
                    return max(default_lane, 1)
        except Exception:
            pass
        return default_lane

    def behavior_adjust(self, rule_target_lane, rule_target_speed):
        """
        函数功能: 调整行为
        """
        current_ego_lane = self.dynamic_map.ego_vehicle.lane_idx

        if self.last_current_lane is not None and self.last_target_lane is not None:

            # 让自车行使在过渡车道上的时间长一点
            if (self.last_current_lane % 3 == 0 and ((self.last_target_lane - 1) % 3 == 0 or (self.last_target_lane - 2) % 3 == 0)) and ((current_ego_lane - 1) % 3 == 0 or (current_ego_lane - 2) % 3 == 0):
                ego_lane = self._secure_lane(self.last_current_lane)
                if len(ego_lane.front_vehicles) > 0:
                    ego_front_vehicle = ego_lane.front_vehicles[0]
                    if ego_front_vehicle.v >= self.dynamic_map.ego_vehicle.v:
                        rule_target_lane = self.last_target_lane
                        rule_target_speed = self.last_target_speed
                    else:
                        v_diff = self.dynamic_map.ego_vehicle.v - ego_front_vehicle.v
                        front_vehicle_location = np.array([ego_front_vehicle.x,ego_front_vehicle.y])
                        ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x,self.dynamic_map.ego_vehicle.y])
                        d_diff = np.linalg.norm(front_vehicle_location - ego_vehicle_location)
                        if d_diff/v_diff >= 5:
                            rule_target_lane = self.last_target_lane
                            rule_target_speed = self.last_target_speed
                else:
                    rule_target_lane = self.last_target_lane
                    rule_target_speed = self.last_target_speed
                        
            # 修复自车拿到路权后返回原车道的bug
            if (current_ego_lane - 1) % 3 == 0 and (self.last_current_lane == current_ego_lane + 1 or self.last_current_lane == current_ego_lane + 2):
                rule_target_lane = current_ego_lane - 1
                rule_target_speed = self.get_idm_speed(rule_target_lane)
            if (current_ego_lane - 2) % 3 == 0 and (self.last_current_lane == current_ego_lane - 1 or self.last_current_lane == current_ego_lane - 2):
                rule_target_lane = current_ego_lane + 1
                rule_target_speed = self.get_idm_speed(rule_target_lane)

            # 修复自车经过过渡车道打断直接换道行为的bug
            if abs(self.last_target_lane - self.last_current_lane) >= 2:
                rule_target_lane = self.last_target_lane
                rule_target_speed = self.get_idm_speed(rule_target_lane)

            # 修复自车在两车差距过小还要减速换道的bug
            target_lane = self._secure_lane(rule_target_lane)
            if len(target_lane.rear_vehicles) > 0:
                target_rear_vehicle = target_lane.rear_vehicles[0]
                if target_rear_vehicle.v >= self.dynamic_map.ego_vehicle.v:
                    d_rear_diff = self.dynamic_map.ego_vehicle.x - target_rear_vehicle.x - target_rear_vehicle.boxx/2 - self.dynamic_map.ego_vehicle.boxx/2
                    v_rear_diff = target_rear_vehicle.v - self.dynamic_map.ego_vehicle.v
                    if abs(current_ego_lane - rule_target_lane) == 3 and self.dynamic_map.ego_vehicle.v > rule_target_speed and d_rear_diff <=2 and v_rear_diff <= 1:
                        rule_target_lane = self.last_target_lane
                        rule_target_speed = self.get_idm_speed(rule_target_lane)

            # 修复自车漂移到过渡车道并且要直接换到目标车道的bug
            if ((current_ego_lane - 1) % 3 == 0 and self.last_target_lane == current_ego_lane - 1 and self.last_current_lane == current_ego_lane - 1) or ((current_ego_lane - 2) % 3 == 0 and self.last_target_lane == current_ego_lane + 1 and self.last_current_lane == current_ego_lane + 1):
                rule_target_lane = self.last_target_lane
                rule_target_speed = self.get_idm_speed(rule_target_lane)

            # 距离前车小于30m时，不换道   ----- 针对特定实验场景
            ego_lane = self._secure_lane(3)
            lane0 = self._secure_lane(0)
            if current_ego_lane == 3 and len(ego_lane.front_vehicles) > 0 and len(lane0.rear_vehicles) > 0:
                ego_front_vehicle = ego_lane.front_vehicles[0]
                if ego_front_vehicle.x - self.dynamic_map.ego_vehicle.x <= 30:
                    rule_target_lane = current_ego_lane
                    rule_target_speed = self.get_idm_speed(rule_target_lane)

        preferred_lane = self._get_turn_preference_lane(rule_target_lane)
        if preferred_lane != rule_target_lane:
            rule_target_lane = preferred_lane
            rule_target_speed = self.get_idm_speed(rule_target_lane)

        # 更新上一次的规则车道索引
        self.last_current_lane = current_ego_lane
        self.last_target_lane = rule_target_lane
        self.last_target_speed = rule_target_speed

        return rule_target_lane, rule_target_speed

    def get_idm_speed(self, lane_index):
        """
        函数功能: 使用智能驾驶模型(IDM)来计算目标车道的理想速度。
        输入:
            lane_index: 目标车道索引
        输出:
            target_speed: 目标车道的理想速度
        """
        # 计算目标车道的理想速度
        target_speed = self.longitudinal_model_instance.longitudinal_speed(lane_index)

        return target_speed

    def generate_lane_change_index(self, change_lane_thres=0.3):
        """
        函数功能: 根据当前车道和目标车道的效用值，决定是否进行车道变换。
        输入:
            change_lane_thres: 转换车道的阈值
        输出:
            目标车道索引
        """
        # 获取当前车道索引（四舍五入到最近的整数）
        ego_lane_index = int(round(self.dynamic_map.ego_vehicle.lane_idx))

        # 自车在正常车道时的处理 这里的左右是反过来的 按照以注释为准
        if ego_lane_index % 3 == 0:
            
            # 计算当前车道的效用值：当前车道的理想速度 + 转换车道的阈值
            current_lane_utility = self.lane_utility(ego_lane_index) + change_lane_thres
            ego_safe = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index)

            
            # 判断右车道是否安全，以及是否需要使用过渡车道，右车道编号 = 自车车道编号 + 2
            left_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index + 3) 
            if left_change == 0:
                left_lane_utility = -1    # 如果右车道不安全，效用值设为-1
            else:
                left_lane_utility = self.lane_utility(ego_lane_index + 3)    # 如果右车道安全，效用值为右车道的理想速度
            
            
            # 判断左车道是否安全，以及是否需要使用过渡车道，左车道编号 = 自车车道编号 - 2
            right_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index - 3)
            if right_change == 0:
                right_lane_utility = -1   # 如果左车道不安全，效用值设为-1， 不经过下面判断左车道是否更优的代码块
            else:
                right_lane_utility = self.lane_utility(ego_lane_index - 3)    # 如果左车道安全，效用值为左车道的理想速度
            
            # 判断左车道是否更优
            if right_lane_utility > current_lane_utility and right_lane_utility > left_lane_utility:
                if right_change == 1:
                    target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index - 1)
                    # FIXME：不知道这段代码在干什么
                    # if ego_safe != 2:
                    #     target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index)
                    return ego_lane_index - 1, target_speed    # 如果需要过渡，返回右过渡车道索引
                else:
                    target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index - 3)
                    # FIXME:不知道这段代码在干什么
                    # if ego_safe != 2:
                    #     target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index)
                    return ego_lane_index - 3, target_speed    # 如果左车道更优，返回左车道索引

            # 判断右车道是否更优
            if left_lane_utility > current_lane_utility and left_lane_utility > right_lane_utility:
                if left_change == 1:
                    target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index + 1)
                    if ego_safe != 2:
                        target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index)
                    return ego_lane_index + 1, target_speed    # 如果需要过渡，返回左过渡车道索引
                else:
                    target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index + 3)
                    if ego_safe != 2:
                        target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index)
                    return ego_lane_index + 3, target_speed    # 如果右车道更优，返回右车道索引

            # 如果当前车道更优，返回当前车道索引
            target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index)
            return ego_lane_index, target_speed   

        # 自车在向左过渡车道时的处理
        elif (ego_lane_index - 2) % 3 == 0:
            
            # 判断右车道是否安全，右车道编号 = 自车车道编号 + 1
            left_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index + 1) 
            if left_change == 0:
                left_lane_utility = -1    # 如果右车道不安全，效用值设为-1
            else:
                left_lane_utility = self.lane_utility(ego_lane_index + 1)    # 如果右车道安全，效用值为右车道的理想速度
            
            # 判断左车道是否安全，左车道编号 = 自车车道编号 - 2
            right_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index - 2)
            if right_change == 0:
                right_lane_utility = -1   # 如果左车道不安全，效用值设为-1
            else:
                right_lane_utility = self.lane_utility(ego_lane_index - 2)    # 如果左车道安全，效用值为左车道的理想速度

            # print("right_lane_utility",right_lane_utility,"left_lane_utility",left_lane_utility,"right_change",right_change,"left_change",left_change)
            
            # 判断左车道是否更优
            if right_lane_utility > left_lane_utility and right_change == 2:
                target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index - 2)
                return ego_lane_index - 2, target_speed    # 如果左车道更优且安全，返回左车道索引
            
            # 判断右车道是否更优
            if left_lane_utility > right_lane_utility and left_change == 2:
                target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index + 1)
                return ego_lane_index + 1, target_speed    # 如果右车道更优且安全，返回右车道索引

            # 如果当前车道更优，返回当前车道索引
            target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index + 1)
            return ego_lane_index, target_speed 

         # 自车在向右过渡车道时的处理
        elif (ego_lane_index - 1) % 3 == 0:
            
            # 判断右车道是否安全，右车道编号 = 自车车道编号 + 1
            left_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index + 2) 
            if left_change == 0:
                left_lane_utility = -1    # 如果右车道不安全，效用值设为-1
            else:
                left_lane_utility = self.lane_utility(ego_lane_index + 2)    # 如果右车道安全，效用值为右车道的理想速度
            
            # 判断左车道是否安全，左车道编号 = 自车车道编号 - 2
            right_change = self.lane_ttc_change_safe(ego_lane_index, ego_lane_index - 1)
            if right_change == 0:
                right_lane_utility = -1   # 如果左车道不安全，效用值设为-1
            else:
                right_lane_utility = self.lane_utility(ego_lane_index - 1)    # 如果左车道安全，效用值为左车道的理想速度
       
            # 判断左车道是否更优
            if right_lane_utility > left_lane_utility and right_change == 2:
                target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index - 1)
                return ego_lane_index - 1, target_speed    # 如果左车道更优且安全，返回左车道索引

            # 判断右车道是否更优
            if left_lane_utility > right_lane_utility and left_change == 2:
                target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index + 2)
                return ego_lane_index + 2, target_speed    # 如果右车道更优且安全，返回右车道索引

            # 如果当前车道更优，返回当前车道索引
            target_speed = self.longitudinal_model_instance.longitudinal_speed(ego_lane_index - 1)
            return ego_lane_index, target_speed 

    def lane_ttc_change_safe(self, ego_lane_index, target_index):
        """
        函数功能: 判断车道变换的安全性，考虑前车和后车的距离。
        输入:
            ego_lane_index: 当前车道索引
            target_index: 目标车道索引
        输出:
            0: 不允许换道
            1: 需要过渡
            2: 允许直接换道
        """
        # 检查目标车道索引是否有效
        if target_index < 0 or target_index > len(self.dynamic_map.lanes)-1:
            return 0
        
        # 初始化安全标志和车辆变量
        front_safe = 0     # 前车安全标志
        rear_safe  = 0     # 后车安全标志
        front_vehicle = None   # 前车对象
        rear_vehicle  = None   # 后车对象

        # 获取自车位置
        ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x,
                                         self.dynamic_map.ego_vehicle.y])

        # 获取目标车道对象
        target_lane = self._secure_lane(target_index)

        # 如果目标车道有前车，获取目标车道的前车对象
        if len(target_lane.front_vehicles) > 0:
            front_vehicle = target_lane.front_vehicles[0]
        
        # 如果目标车道有后车，获取目标车道的后车对象
        if len(target_lane.rear_vehicles) > 0:
            rear_vehicle = target_lane.rear_vehicles[0]
        
        # 获取自车速度
        ego_v = self.dynamic_map.ego_vehicle.v
        # print(f"[MOBIL]: ego: {self.dynamic_map.ego_vehicle.x:.2f}, {self.dynamic_map.ego_vehicle.y:.2f}, {ego_v:.2f}")

        # 检查与前车的安全距离
        if front_vehicle is None:    # 如果目标车道没有前车
            d_front = -1             # 两车距离设为-1
            front_safe = 2           # 前车安全标志为2，表示允许换道
        else:
            # 计算前车位置和距离
            front_vehicle_location = np.array([front_vehicle.x,front_vehicle.y])
            d_front = np.linalg.norm(front_vehicle_location - ego_vehicle_location) - front_vehicle.boxx/2 - self.dynamic_map.ego_vehicle.boxx/2
            if d_front < 0:
                d_front = 0

            # 获取前车速度
            front_v = front_vehicle.v
            # print(f"[MOBIL]: front vehicle: {front_vehicle.x:.2f}, {front_vehicle.y:.2f}, {front_v:.2f}")

            # 采用TTC模型判断是否安全
            if front_v >= ego_v:
                print(f"[MOBIL]: vehicle lane:{target_index}, d_front:{d_front:.2f}")
                if d_front >= self.d_front_thres:
                    front_safe = 2
                else:
                    front_safe = 0
            else:
                v_front = ego_v-front_v
                t_front = d_front/v_front
                print(f"[MOBIL]: vehicle lane:{target_index}, d_front:{d_front:.2f}, v_front:{v_front:.2f}, t_front:{t_front:.2f}")
                if t_front > self.t_front_thres:
                    front_safe = 2
                else:
                    front_safe = 0

        # 检查与后车的安全距离
        if rear_vehicle is None:
            d_rear = -1             # 如果目标车道没有后车
            rear_safe = 2           # 后车安全标志为2，表示允许直接换道
        else:
            rear_vehicle_location = np.array([rear_vehicle.x,rear_vehicle.y])
            d_rear = np.linalg.norm(rear_vehicle_location - ego_vehicle_location) - rear_vehicle.boxx/2 - self.dynamic_map.ego_vehicle.boxx/2
            if d_rear < 0:
                d_rear = 0
                
            rear_v = rear_vehicle.v
            # print(f"[MOBIL]: rear vehicle: {rear_vehicle.x:.2f}, {rear_vehicle.y:.2f}, {rear_v:.2f}")

            # 采用TTC模型判断是否安全
            if rear_v <= ego_v:
                print(f"[MOBIL]: vehicle lane:{target_index}, d_rear:{d_rear:.2f}")
                if d_rear > self.d_rear_thres:
                    rear_safe = 2
                elif d_rear > self.d_rear_trans_thres and d_rear <= self.d_rear_thres:
                    rear_safe = 1
                else:
                    rear_safe = 0
            else:
                v_rear = rear_v-ego_v
                t_rear = d_rear/v_rear
                print(f"[MOBIL]: vehicle lane:{target_index}, d_rear:{d_rear:.2f}, v_rear:{v_rear:.2f}, t_rear:{t_rear:.2f}")
                if t_rear >= self.t_rear_thres:
                    rear_safe = 2
                elif t_rear >= self.t_rear_trans_thres and t_rear < self.t_rear_thres:
                    rear_safe = 1
                else:
                    rear_safe = 0

        # print(f"[MOBIL]: lane: {target_index}, front_safe: {front_safe}, rear_safe: {rear_safe}")

        # 前车允许变道，后车允许直接变道，决策直接变道                        
        if front_safe == 2 and rear_safe == 2:
            return 2
        
        # 前车允许变道，后车需要过渡，决策过渡变道                        
        if front_safe == 2 and rear_safe == 1:
            return 1
            
        # 其他情况，决策不换道
        return 0

    def lane_utility(self, lane_index):
        """
        函数功能: 计算目标车道的效用值，包括可用速度和车道变换安全性。
        输入:
            lane_index: 目标车道索引
        输出:
            utility: 车道效用值
        """
        # 计算目标车道的理想速度
        available_speed = self.longitudinal_model_instance.longitudinal_speed(lane_index)

        # 将理想速度作为效用值
        utility = available_speed

        return utility

    # def generate_lane_change_index(self, change_lane_thres=0.3, transition_lane_thres=0.1):
    #     """
    #     函数功能: 根据当前车道和目标车道的效用值，决定是否进行车道变换。
    #     输入:
    #         change_lane_thres: 转换车道的阈值
    #         transition_lane_thres: 过渡车道的阈值
    #     输出:
    #         目标车道索引
    #     """
    #     # 获取当前车道索引（四舍五入到最近的整数）, 正常车道为偶数索引, 过渡车道为奇数索引
    #     ego_lane_index = int(round(self.dynamic_map.ego_vehicle.lane_idx))

    #     # 自车在正常车道时的处理
    #     if ego_lane_index % 2 == 0:
    #         # 计算当前车道的效用值：当前车道的理想速度 + 转换车道的阈值
    #         current_lane_utility = self.lane_utility(ego_lane_index) + change_lane_thres

    #         # 判断左车道是否安全，以及是否需要使用过渡车道，左车道编号 = 自车车道编号 + 2
    #         left_change = self.lane_change_safe(ego_lane_index, ego_lane_index + 2) 
    #         if left_change == 0:
    #             left_lane_utility = -1    # 如果左车道不安全，效用值设为-1
    #         else:
    #             left_lane_utility = self.lane_utility(ego_lane_index + 2)    # 如果左车道安全，效用值为左车道的理想速度

    #         # 判断右车道是否安全，以及是否需要使用过渡车道，右车道编号 = 自车车道编号 - 2
    #         right_change = self.lane_change_safe(ego_lane_index, ego_lane_index - 2)
    #         if right_change == 0:
    #             right_lane_utility = -1   # 如果右车道不安全，效用值设为-1
    #         else:
    #             right_lane_utility = self.lane_utility(ego_lane_index - 2)    # 如果右车道安全，效用值为右车道的理想速度

    #         # 回到正常车道，自车待在过渡车道计数器清零
    #         self.stay_trans_time = 0
            
    #         # 判断右车道是否更优
    #         if right_lane_utility > current_lane_utility and right_lane_utility >= left_lane_utility:
    #             if right_change == 1:
    #                 return ego_lane_index - 1    # 如果需要过渡，返回右过渡车道索引
    #             else:
    #                 return ego_lane_index - 2    # 如果右车道更优，返回右车道索引

    #         # 判断左车道是否更优
    #         if left_lane_utility > current_lane_utility and left_lane_utility > right_lane_utility:
    #             if left_change == 1:
    #                 return ego_lane_index + 1    # 如果需要过渡，返回左过渡车道索引
    #             else:
    #                 return ego_lane_index + 2    # 如果左车道更优，返回左车道索引

    #         # 如果当前车道更优，返回当前车道索引
    #         return ego_lane_index   

    #     # 自车在过渡车道时的处理
    #     else:
    #         # 如果自车在过渡车道停留过久，对过渡车道效用值进行惩罚
    #         if self.stay_trans_time > 2:
    #             transition_lane_thres = -0.5

    #         # 计算当前车道的效用值：当前车道的理想速度 + 转换车道的阈值
    #         current_lane_utility = self.lane_utility(ego_lane_index) + transition_lane_thres

    #         # 判断左车道是否安全，左车道编号 = 自车车道编号 + 1
    #         if not self.lane_trans_safe(ego_lane_index, ego_lane_index + 1):
    #             left_lane_utility = -1    # 如果左车道不安全，效用值设为-1
    #         else:
    #             left_lane_utility = self.lane_utility(ego_lane_index + 1)    # 如果左车道安全，效用值为左车道的理想速度

    #         # 判断右车道是否安全，右车道编号 = 自车车道编号 - 1
    #         if not self.lane_trans_safe(ego_lane_index, ego_lane_index - 1):
    #             right_lane_utility = -1   # 如果右车道不安全，效用值设为-1
    #         else:
    #             right_lane_utility = self.lane_utility(ego_lane_index - 1)    # 如果右车道安全，效用值为右车道的理想速度

    #         # 自车待在过渡车道计数器
    #         self.stay_trans_time += 1
            
    #         # 判断右车道是否更优
    #         if right_lane_utility > current_lane_utility and right_lane_utility >= left_lane_utility:
    #             return ego_lane_index - 1    # 如果右车道更优，返回右车道索引

    #         # 判断左车道是否更优
    #         if left_lane_utility > current_lane_utility and left_lane_utility > right_lane_utility:
    #             return ego_lane_index + 1    # 如果左车道更优，返回左车道索引

    #         # 如果当前车道更优，返回当前车道索引
    #         return ego_lane_index 

    # def lane_change_safe(self, ego_lane_index, target_index):
    #     """
    #     函数功能: 判断车道变换的安全性，考虑前车和后车的距离。
    #     输入:
    #         ego_lane_index: 当前车道索引
    #         target_index: 目标车道索引
    #     输出:
    #         0: 不允许换道
    #         1: 需要过渡
    #         2: 允许直接换道
    #     """
    #     # 检查目标车道索引是否有效
    #     if target_index < 0 or target_index > len(self.dynamic_map.lanes)-1:
    #         return 0
        
    #     # 初始化安全标志和车辆变量
    #     front_safe = 0     # 前车安全标志
    #     rear_safe  = 0     # 后车安全标志
    #     front_vehicle = None   # 前车对象
    #     rear_vehicle  = None   # 后车对象

    #     # 获取自车位置
    #     ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x,
    #                                      self.dynamic_map.ego_vehicle.y])

    #     # 获取目标车道对象
    #     target_lane = self._secure_lane(target_index)

    #     # 如果目标车道有前车，获取目标车道的前车对象
    #     if len(target_lane.front_vehicles) > 0:
    #         front_vehicle = target_lane.front_vehicles[0]
        
    #     # 如果目标车道有后车，获取目标车道的后车对象
    #     if len(target_lane.rear_vehicles) > 0:
    #         rear_vehicle = target_lane.rear_vehicles[0]
        
    #     # 获取自车速度
    #     ego_v = self.dynamic_map.ego_vehicle.v

    #     # 检查与前车的安全距离
    #     if front_vehicle is None:    # 如果目标车道没有前车
    #         d_front = -1             # 两车距离设为-1
    #         front_safe = 2           # 前车安全标志为2，表示允许换道
    #     else:
    #         # 计算前车位置和距离
    #         front_vehicle_location = np.array([
    #                     front_vehicle.x,front_vehicle.y])
    #         d_front = np.linalg.norm(front_vehicle_location - ego_vehicle_location)

    #         # 获取前车速度
    #         front_v = front_vehicle.v

    #         # 安全距离模型：基础距离10m + 相对速度项，最小保持2m, 对于前车只决策换不换道
    #         if d_front > max(10 + 3*(ego_v-front_v), 5):
    #             front_safe = 2    # 如果距离大于安全距离，则认为允许换道

    #     # 检查与后车的安全距离
    #     if rear_vehicle is None:
    #         d_rear = -1             # 如果目标车道没有后车
    #         rear_safe = 2           # 后车安全标志为2，表示允许直接换道
    #     else:
    #         rear_vehicle_location = np.array([rear_vehicle.x,rear_vehicle.y])
    #         d_rear = np.linalg.norm(rear_vehicle_location - ego_vehicle_location)
    #         rear_v = rear_vehicle.v

    #         if d_rear > max(10 + 3*(rear_v-ego_v), 2):
    #             rear_safe = 1

    #             if d_rear > max(10 + 3*(rear_v-ego_v), 20):
    #                 rear_safe = 2
        
    #     # 前车允许变道，后车允许直接变道，决策直接变道                        
    #     if front_safe == 2 and rear_safe == 2:
    #         return 2
        
    #     # 前车允许变道，后车需要过渡，决策过渡变道                        
    #     if front_safe == 2 and rear_safe == 1:
    #         return 1
            
    #     # 其他情况，决策不换道
    #     return 0

    # def lane_trans_safe(self, ego_lane_index, target_index):
    #     """
    #     函数功能: 判断车道变换的安全性，考虑前车和后车的距离。
    #     输入:
    #         ego_lane_index: 当前车道索引
    #         target_index: 目标车道索引
    #     输出:
    #         bool: 是否安全
    #     """
    #     # 检查目标车道索引是否有效
    #     if target_index < 0 or target_index > len(self.dynamic_map.lanes)-1:
    #         return False
        
    #     # 初始化安全标志和车辆变量
    #     front_safe = False     # 前车安全标志
    #     rear_safe  = False     # 后车安全标志
    #     front_vehicle = None   # 前车对象
    #     rear_vehicle  = None   # 后车对象

    #     # 获取自车位置
    #     ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x,
    #                                      self.dynamic_map.ego_vehicle.y])

    #     # 获取目标车道对象
    #     target_lane = self._secure_lane(target_index)

    #     # 如果目标车道有前车，获取目标车道的前车对象
    #     if len(target_lane.front_vehicles) > 0:
    #         front_vehicle = target_lane.front_vehicles[0]
        
    #     # 如果目标车道有后车，获取目标车道的后车对象
    #     if len(target_lane.rear_vehicles) > 0:
    #         rear_vehicle = target_lane.rear_vehicles[0]
        
    #     # 获取自车速度
    #     ego_v = self.dynamic_map.ego_vehicle.v

    #     # 检查与前车的安全距离
    #     if front_vehicle is None:    # 如果目标车道没有前车
    #         d_front = -1             # 两车距离设为-1
    #         front_safe = True        # 前车安全标志为True，表示前车安全
    #     else:
    #         # 计算前车位置和距离
    #         front_vehicle_location = np.array([
    #                     front_vehicle.x,front_vehicle.y])
    #         d_front = np.linalg.norm(front_vehicle_location - ego_vehicle_location)

    #         # 获取前车速度
    #         front_v = front_vehicle.v

    #         # 安全距离模型：基础距离10m + 相对速度项，最小保持2m
    #         if d_front > max(10 + 3*(ego_v-front_v), 2):
    #             front_safe = True    # 如果距离大于安全距离，则认为前车安全

    #     # 检查与后车的安全距离
    #     if rear_vehicle is None:
    #         rear_safe = True
    #         d_rear = -1
    #     else:
    #         rear_vehicle_location = np.array([rear_vehicle.x,rear_vehicle.y])
    #         d_rear = np.linalg.norm(rear_vehicle_location - ego_vehicle_location)
    #         rear_v = rear_vehicle.v

    #         if d_rear > max(10 + 3*(rear_v-ego_v), 2):
    #             rear_safe = True
        
    #     # 只有前后都安全才认为变道安全                        
    #     if front_safe and rear_safe:
    #         return True
            
    #     return False


class IDM(object):
    """
    智能驾驶模型(IDM)用于计算目标车道的理想速度。
    """
    def __init__(self, dynamic_map, idm_a):
        self.T = 1.6                       # 安全时间间隔（秒）     1.6
        self.g0 = 15                       # 基础安全距离（米）     7
        self.a = idm_a                     # 最大加速度（m/s^2）   2.73
        self.b = 2.0                       # 最大减速度（m/s^2）   1.65
        self.delta = 4                     # 加速度指数
        self.decision_dt = 0.75            # 决策时间步长（秒）
        self.dynamic_map = dynamic_map     # 动态地图对象
    def _secure_lane(self, idx):
        """安全取车道：索引越界时 clamp 到有效范围，避免 IndexError"""
        lanes = self.dynamic_map.lanes
        n = len(lanes)
        if n == 0:
            from types import SimpleNamespace
            return SimpleNamespace(rear_vehicles=[], front_vehicles=[], central_path_array=[])
        try:
            idx = int(idx)
        except Exception:
            idx = 0
        if idx < 0:
            idx = 0
        if idx >= n:
            idx = n - 1
        return lanes[idx]


    def longitudinal_speed(self, target_lane_index):
        """
        函数功能: 计算目标车道的理想速度。
        输入:
            target_lane_index: 目标车道索引
        输出:
            idm_speed: 目标车道的理想速度
        """
        # 根据车道索引获取目标车道对象
        target_lane = self._secure_lane(target_lane_index)

        # 计算目标车道的理想速度
        idm_speed = self.IDM_speed_in_lane(target_lane)

        return idm_speed

    def IDM_speed_in_lane(self, lane):
        """
        功能: 核心IDM模型实现,计算在指定车道上的理想速度
        输入:
            lane: 目标车道对象
        输出:
            理想速度(m/s)或 False(如果计算失败)
        """
        # 获取自车位置
        ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x, 
                                         self.dynamic_map.ego_vehicle.y])
        # 获取自车速度
        v = self.dynamic_map.ego_vehicle.v

        # 获取目标车道的速度限制
        v0 = lane.speed_limit
        v0 = 50/3.6

        # 检查限速是否有效，无效限速返回 0
        if v0 <= 0.0:
            return 0.0
        
        # 根据当前速度调整加速度
        if v < 10:
            a = self.a + (10 - v) / 10*2    # 低速时增加加速度
        else:
            a = self.a                    # 正常使用预设加速度

        # 设置IDM模型参数
        b = self.b           # 舒适减速度
        g0 = self.g0         # 最小安全距离
        T = self.T           # 安全时间间隔
        delta = self.delta   # 加速度指数

        # 打印前车信息
        # for vehicles in lane.front_vehicles:
            # print("[IDM] : vehicles dist:",vehicles.x, vehicles.y)

        # 当前方有车辆时
        if len(lane.front_vehicles) > 0:
            # 获取前车位置和速度
            f_v_location = np.array([lane.front_vehicles[0].x, lane.front_vehicles[0].y])
            v_f = lane.front_vehicles[0].v
            # print("[IDM] : lane.front_vehicles:",len(lane.front_vehicles),lane.front_vehicles[0].x,lane.front_vehicles[0].y,v_f)

            # 计算前车与自车的速度差和距离
            dv = v - v_f    # 相对速度 = 自车速度 - 前车速度
            g = np.linalg.norm(f_v_location - ego_vehicle_location)    # 前车与自车的距离
            
            # 安全检查：距离过近，返回0
            if g <= 0:
                return 0

            # 计算期望跟车距离：最小安全距离 + 安全时间间隔 * 自车速度 + 自车速度 * 相对速度 / (2 * sqrt(a * b))
            g1 = g0 + T * v + v * dv / (2 * np.sqrt(a * b))    
            
            # 计算加速度：加速度 = a * (1 - (v/v0)^delta - (g1/g) * (g1/g))
            acc = a * (1 - pow(v/v0, delta) - (g1/g) * ((g1/g)))
        
        else:
            # 前方无车时的处理，只有自由流加速度项
            acc = a * (1 - pow(v/v0, delta))
        
        # 计算新速度（当前速度 + 加速度 × 时间步长），确保不小于0
        return max(0, v + acc*self.decision_dt)



# 使用示例 -------------------------------------------------------------
# # 初始化
# lane_planner = LanePlanner()

# # 在循环中调用
# while True:
#     # 获取动态地图信息
#     dynamic_map = get_dynamic_map()  # 需要实现此函数
    
#     # 执行规划
#     lane_action = lane_planner.run_step(dynamic_map)
    
#     # 获取规划结果
#     target_lane_index = lane_action.target_index
#     target_speed = lane_action.target_speed
