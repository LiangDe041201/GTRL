"""
这段代码实现了一个车道级别的路径规划器 LanePlanner,用于自动驾驶车辆的车道选择和速度控制.代码的核心功能包括：
    车道选择(MOBIL)：根据当前车道和目标车道的效用值，决定是否进行车道变换。
    速度控制 (IDM) ：使用智能驾驶模型(IDM)来计算目标车道的理想速度。
"""
import numpy as np
import math
from Agent.tools_dds.actions import LaneAction

class LanePlanner(object):
    """
    车道级路径规划器 MOBIL (Minimizing Overall Braking Induced by Lane changes)
    负责选择目标车道和速度
    """
    def __init__(self):
        """ 初始化方法为空，因为初始化时不需要任何操作 """
        pass    

    def run_step(self, dynamic_map):
        """
        函数功能: 根据当前车道和目标车道的效用值，决定是否进行车道变换,使用智能驾驶模型(IDM)来计算目标车道的理想速度。
        输入：
            dynamic_map: 动态地图
        输出：
            LaneAction: 车道动作，包含目标车道索引和目标速度
        """
        # 创建IDM (Intelligent Driver Model) 实例，用于计算目标车道的理想速度
        self.longitudinal_model_instance = IDM(dynamic_map)

        # 保存动态地图
        self.dynamic_map = dynamic_map

        # 生成目标车道索引
        target_index = self.generate_lane_change_index()

        # # 锁定某一车道行驶
        # target_index = 1

        # 计算目标车道的理想速度
        target_speed = self.longitudinal_model_instance.longitudinal_speed(target_index)

        # 打印车道索引和速度
        print(f"[IDM + MOBIL]---> ego_lane:{self.dynamic_map.ego_vehicle.lane_idx}, target_lane:{target_index}, lanes_num:{len(self.dynamic_map.lanes)}")
        print(f"[IDM + MOBIL]---> ego_speed:{self.dynamic_map.ego_vehicle.v}, target_speed:{target_speed}")
        
        return LaneAction(target_index, target_speed)

    def generate_lane_change_index(self, change_lane_thres=0.5):
        """
        函数功能: 根据当前车道和目标车道的效用值，决定是否进行车道变换。
        输入:
            change_lane_thres: 转换车道的阈值
        输出:
            目标车道索引
        """
        # 获取当前车道索引（四舍五入到最近的整数）
        ego_lane_index = int(round(self.dynamic_map.ego_vehicle.lane_idx))
        
        # 计算当前车道的效用值：当前车道的理想速度 + 转换车道的阈值
        current_lane_utility = self.lane_utility(ego_lane_index) + change_lane_thres

        # 判断左车道是否安全，左车道编号 = 自车车道编号 + 1
        if not self.lane_change_safe(ego_lane_index, ego_lane_index + 1):
            left_lane_utility = -1    # 如果左车道不安全，效用值设为-1
        else:
            left_lane_utility = self.lane_utility(ego_lane_index + 1)    # 如果左车道安全，效用值为左车道的理想速度

        # 判断右车道是否安全，右车道编号 = 自车车道编号 - 1
        if not self.lane_change_safe(ego_lane_index, ego_lane_index - 1):
            right_lane_utility = -1   # 如果右车道不安全，效用值设为-1
        else:
            right_lane_utility = self.lane_utility(ego_lane_index - 1)    # 如果右车道安全，效用值为右车道的理想速度

        # 判断右车道是否更优
        if right_lane_utility > current_lane_utility and right_lane_utility >= left_lane_utility:
            return ego_lane_index - 1    # 如果右车道更优，返回右车道索引

        # 判断左车道是否更优
        if left_lane_utility > current_lane_utility and left_lane_utility > right_lane_utility:
            return ego_lane_index + 1    # 如果左车道更优，返回左车道索引

        # 如果当前车道更优，返回当前车道索引
        return ego_lane_index    

    def lane_utility(self, lane_index):
        """
        函数功能: 计算目标车道的效用值，包括可用速度和车道变换安全性。
        输入:
            lane_index: 目标车道索引
        输出:
            utility: 车道效用值
        """
        # 计算目标车道的理想速度
        available_speed = self.longitudinal_model_instance.longitudinal_speed(lane_index)

        # 将理想速度作为效用值
        utility = available_speed

        return utility

    def lane_change_safe(self, ego_lane_index, target_index):
        """
        函数功能: 判断车道变换的安全性，考虑前车和后车的距离。
        输入:
            ego_lane_index: 当前车道索引
            target_index: 目标车道索引
        输出:
            bool: 是否安全
        """
        # 检查目标车道索引是否有效
        if target_index < 0 or target_index > len(self.dynamic_map.lanes)-1:
            return False
        
        # 初始化安全标志和车辆变量
        front_safe = False     # 前车安全标志
        rear_safe  = False     # 后车安全标志
        front_vehicle = None   # 前车对象
        rear_vehicle  = None   # 后车对象

        # 获取自车位置
        ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x,
                                         self.dynamic_map.ego_vehicle.y])

        # 获取目标车道对象
        target_lane = self.dynamic_map.lanes[target_index]

        # 如果目标车道有前车，获取目标车道的前车对象
        if len(target_lane.front_vehicles) > 0:
            front_vehicle = target_lane.front_vehicles[0]
        
        # 如果目标车道有后车，获取目标车道的后车对象
        if len(target_lane.rear_vehicles) > 0:
            rear_vehicle = target_lane.rear_vehicles[0]
        
        # 获取自车速度
        ego_v = self.dynamic_map.ego_vehicle.v

        # 检查与前车的安全距离
        if front_vehicle is None:    # 如果目标车道没有前车
            d_front = -1             # 两车距离设为-1
            front_safe = True        # 前车安全标志为True，表示前车安全
        else:
            # 计算前车位置和距离
            front_vehicle_location = np.array([
                        front_vehicle.x,front_vehicle.y])
            d_front = np.linalg.norm(front_vehicle_location - ego_vehicle_location)

            # 获取前车速度
            front_v = front_vehicle.v

            # 安全距离模型：基础距离10m + 相对速度项，最小保持5m
            if d_front > max(10 + 3*(ego_v-front_v), 5):
                front_safe = True    # 如果距离大于安全距离，则认为前车安全

        # 检查与后车的安全距离
        if rear_vehicle is None:
            rear_safe = True
            d_rear = -1
        else:
            rear_vehicle_location = np.array([rear_vehicle.x,rear_vehicle.y])
            d_rear = np.linalg.norm(rear_vehicle_location - ego_vehicle_location)
            rear_v = rear_vehicle.v

            if d_rear > max(10 + 3*(rear_v-ego_v), 5):
                rear_safe = True
        
        # 只有前后都安全才认为变道安全                        
        if front_safe and rear_safe:
            return True
            
        return False


class IDM(object):
    """
    智能驾驶模型(IDM)用于计算目标车道的理想速度。
    """
    def __init__(self, dynamic_map):
        self.T = 1.6                       # 安全时间间隔（秒）
        self.g0 = 7                        # 基础安全距离（米）
        self.a = 2.73                      # 最大加速度（m/s^2）
        self.b = 1.65                      # 最大减速度（m/s^2）
        self.delta = 4                     # 加速度指数
        self.decision_dt = 0.75            # 决策时间步长（秒）
        self.dynamic_map = dynamic_map     # 动态地图对象

    def longitudinal_speed(self, target_lane_index):
        """
        函数功能: 计算目标车道的理想速度。
        输入:
            target_lane_index: 目标车道索引
        输出:
            idm_speed: 目标车道的理想速度
        """
        # 根据车道索引获取目标车道对象
        target_lane = self.dynamic_map.lanes[target_lane_index]

        # 计算目标车道的理想速度
        idm_speed = self.IDM_speed_in_lane(target_lane)

        return idm_speed

    def IDM_speed_in_lane(self, lane):
        """
        功能: 核心IDM模型实现,计算在指定车道上的理想速度
        输入:
            lane: 目标车道对象
        输出:
            理想速度(m/s)或 False(如果计算失败)
        """
        # 获取自车位置
        ego_vehicle_location = np.array([self.dynamic_map.ego_vehicle.x, 
                                         self.dynamic_map.ego_vehicle.y])
        # 获取自车速度
        v = self.dynamic_map.ego_vehicle.v

        # 获取目标车道的速度限制
        v0 = lane.speed_limit

        # 检查限速是否有效，无效限速返回 0
        if v0 <= 0.0:
            return 0.0
        
        # 根据当前速度调整加速度
        if v < 5:
            a = self.a + (5 - v) / 5*2    # 低速时增加加速度
        else:
            a = self.a                    # 正常使用预设加速度

        # 设置IDM模型参数
        b = self.b           # 舒适减速度
        g0 = self.g0         # 最小安全距离
        T = self.T           # 安全时间间隔
        delta = self.delta   # 加速度指数

        # 打印前车信息
        # for vehicles in lane.front_vehicles:
            # print("[IDM] : vehicles dist:",vehicles.x, vehicles.y)

        # 当前方有车辆时
        if len(lane.front_vehicles) > 0:
            # 获取前车位置和速度
            f_v_location = np.array([lane.front_vehicles[0].x, lane.front_vehicles[0].y])
            v_f = lane.front_vehicles[0].v
            # print("[IDM] : lane.front_vehicles:",len(lane.front_vehicles),lane.front_vehicles[0].x,lane.front_vehicles[0].y,v_f)

            # 计算前车与自车的速度差和距离
            dv = v - v_f    # 相对速度 = 自车速度 - 前车速度
            g = np.linalg.norm(f_v_location - ego_vehicle_location)    # 前车与自车的距离
            
            # 安全检查：距离过近，返回0
            if g <= 0:
                return 0

            # 计算期望跟车距离：最小安全距离 + 安全时间间隔 * 自车速度 + 自车速度 * 相对速度 / (2 * sqrt(a * b))
            g1 = g0 + T * v + v * dv / (2 * np.sqrt(a * b))    
            
            # 计算加速度：加速度 = a * (1 - (v/v0)^delta - (g1/g) * (g1/g))
            acc = a * (1 - pow(v/v0, delta) - (g1/g) * ((g1/g)))
        
        else:
            # 前方无车时的处理，只有自由流加速度项
            acc = a * (1 - pow(v/v0, delta))
        
        # 计算新速度（当前速度 + 加速度 × 时间步长），确保不小于0
        return max(0, v + acc*self.decision_dt)



# 使用示例 -------------------------------------------------------------
# # 初始化
# lane_planner = LanePlanner()

# # 在循环中调用
# while True:
#     # 获取动态地图信息
#     dynamic_map = get_dynamic_map()  # 需要实现此函数
    
#     # 执行规划
#     lane_action = lane_planner.run_step(dynamic_map)
    
#     # 获取规划结果
#     target_lane_index = lane_action.target_index
#     target_speed = lane_action.target_speed
