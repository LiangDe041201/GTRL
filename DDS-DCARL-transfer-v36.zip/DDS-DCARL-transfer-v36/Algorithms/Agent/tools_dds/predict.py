"""
    这段代码实现了一个基于轨迹预测的车辆碰撞检测模块,使用周期-瞬时矩形法近似表示车辆.并检查自车轨迹是否与预测路径发生碰撞.
    论文: System and Experiments of Model-Driven Motion Planning and Control for Autonomous Vehicles 约束检查(6)
    要使用这个碰撞检测模块的话直接把文件名从 predict_rectangles 改成 predict
"""
import numpy as np
import copy
import math
from Agent.tools_dds.frenet import Frenet_path 
from Agent.tools_dds.rectangle_tools import *

class predict():
    def __init__(self, dynamic_map, considered_obs_num, maxt, dt, robot_radius, radius_speed_ratio, move_gap, ego_speed):

        self.maxt = maxt
        self.dt = dt
        self.check_radius = robot_radius    #  + radius_speed_ratio * ego_speed
        self.move_gap = move_gap
        self.dynamic_map = dynamic_map

        try:
            # TODO：改成强制换道的硬约束
            interested_vehicles = self.found_interested_vehicles(considered_obs_num)
            self.predict_paths  = self.prediction_obstacle(interested_vehicles, self.maxt, self.dt)
        except:
            self.predict_paths = []

    def check_collision(self, fp):
        """
        用途:检查给定的自车轨迹是否与预测路径发生碰撞
        输入:
            fp:当前轨迹
        输出:
            True:未发生碰撞
            False:发生碰撞
        """
        if len(self.predict_paths) == 0 or len(fp.t) < 3 :
            return True

        for path in self.predict_paths:
            # 计算需要检查的时间步长，取预测路径和当前路径的最小长度减1
            len_predict_t = min(len(fp.x)-1, len(path.t)-1)
            predict_step = 2     # 每隔2个点检查一次
            start_predict = 2    # 从第3个点开始检查
            for t in range(start_predict, len_predict_t, predict_step):
                # # 创建ego车辆瞬时矩形
                # ego_rect1 = Rectangle_MBR(Point(fp.x[t-1], fp.y[t-1]), self.dynamic_map.ego_vehicle.boxx, self.dynamic_map.ego_vehicle.boxy, fp.yaw[t-1])
                # ego_rect2 = Rectangle_MBR(Point(fp.x[t+1], fp.y[t+1]), self.dynamic_map.ego_vehicle.boxx, self.dynamic_map.ego_vehicle.boxy, fp.yaw[t+1])
                ego_rect1 = Rectangle_MBR(
                    Point(fp.x[t-1], fp.y[t-1]), 
                    self.dynamic_map.ego_vehicle.boxx, 
                    self.dynamic_map.ego_vehicle.boxy, 
                    self.carla_yaw_to_math(fp.yaw[t-1])
                )
                ego_rect2 = Rectangle_MBR(
                    Point(fp.x[t+1], fp.y[t+1]), 
                    self.dynamic_map.ego_vehicle.boxx, 
                    self.dynamic_map.ego_vehicle.boxy, 
                    self.carla_yaw_to_math(fp.yaw[t+1])
                )

                # 创建ego车辆周期矩形
                mbr_center_x, mbr_center_y, mbr_width, mbr_height, mbr_angle = Rectangle_MBR.get_min_bounding_rectangle(ego_rect1, ego_rect2)
                ego_rect = Rectangle_SAT(Point(mbr_center_x, mbr_center_y), mbr_width, mbr_height, mbr_angle)
                
                # 创建环境车辆瞬时矩形
                # env_rect = Rectangle_SAT(Point(path.x[t], path.y[t]), path.boxx[t], path.boxy[t], path.yaw[t])
                env_rect = Rectangle_SAT(
                    Point(path.x[t], path.y[t]), 
                    path.boxx[t], 
                    path.boxy[t], 
                    self.carla_yaw_to_math(path.yaw[t])
                )

                # 检查自车矩形是否与环境车辆矩形相交
                if Rectangle_SAT.rectangles_intersect(ego_rect, env_rect):
                    return False

        # 所有检查都通过，返回True表示没有碰撞
        return True

    def carla_yaw_to_math(self, yaw):
        """
        用途:将CARLA的yaw转换为数学坐标系的yaw
        输入:
            yaw:CARLA的yaw
        输出:
            -yaw  # 取负是因为CARLA是顺时针方向
        """
        return -yaw  # 取负是因为CARLA是顺时针方向

    def found_interested_vehicles(self, interested_vehicles_num = 3):
        """
        用途:找距离自车最近的几辆感兴趣车辆
        输入:
            interested_vehicles_num:感兴趣的车辆数量
        输出:
            interested_vehicles:感兴趣的车辆列表
        """
        # 初始化感兴趣车辆列表
        interested_vehicles = []

        # 获取感兴趣的车辆（基于距离）
        distance_tuples = []    # 用于存储(距离, 车辆索引)元组

        # 获取自车位置，转换为numpy数组方便计算
        ego_loc = np.array([self.dynamic_map.ego_vehicle.x,self.dynamic_map.ego_vehicle.y])

        # 遍历所有障碍物，计算与自车的距离


        """-------------------------对匝道口的硬约束--------------------------------------------"""
        # FIXME：仅仅对闸道口车辆做碰撞检测
        ramp_lane = self.dynamic_map.lanes[0]

        if len(ramp_lane.front_vehicles) > 0:
            ramp_obstacle = ramp_lane.front_vehicles[0]
            # FIXME:指定障碍车辆为匝道口
            interested_vehicles.append(ramp_obstacle)

        """-------------------------------原先对全体车辆的硬约束---------------------------------"""
        # for vehicle_idx, vehicle in enumerate(self.dynamic_map.objects):
        #     # 获取车辆位置，转换为numpy数组
        #     vehicle_loc = np.array([vehicle.x, vehicle.y])
        #
        #     # 计算与自车的距离
        #     d = np.linalg.norm(vehicle_loc - ego_loc)
        #
        #     # 将距离和车辆索引存储到元组中
        #     distance_tuples.append((d, vehicle_idx))

        # 按照距离对车辆进行排序，从近到远
        # sorted_vehicle = sorted(distance_tuples, key=lambda vehicle_dis: vehicle_dis[0])

        # 添加指定数量的最近车辆到感兴趣车辆列表，初始化预测模块的时候把 interested_vehicles_num 设为了4
        # for _, vehicle_idx in sorted_vehicle:
        #     interested_vehicles.append(self.dynamic_map.objects[vehicle_idx])
        #     if len(interested_vehicles) >= interested_vehicles_num:
        #         break

        return interested_vehicles

    def prediction_obstacle(self, vehicles, max_prediction_time, delta_t): 
        """
        用途:预测环境车辆的行车轨迹
        输入:
            vehicles:环境车辆列表
            max_prediction_time:最大预测时间
            delta_t:时间步长
        输出:
            predict_paths:预测轨迹列表
        """
        # 初始化预测路径列表
        predict_paths = []

        # 遍历所有车辆，预测其行车轨迹
        for vehicle in vehicles:
            # 创建前后两个预测路径对象（用于表示车辆前后两个点）
            predict_path = Frenet_path()
            
            # 设置预测路径的时间点，从0到max_prediction_time，间隔为delta_t
            predict_path.t = [t for t in np.arange(0.0, max_prediction_time, delta_t)]

            # print("vehicle information",vehicle.x, vehicle.y, vehicle.vx, vehicle.vy, vehicle.yaw, vehicle.boxx, vehicle.boxy)

            # 预测x和y方向的速度（假设速度恒定）
            vx_predict = vehicle.vx*np.ones(len(predict_path.t))
            vy_predict = vehicle.vy*np.ones(len(predict_path.t))

            # 预测x和y坐标（匀速直线运动模型） 当前位置 + 时间步长 × 速度
            predict_path.x = vehicle.x + np.arange(len(predict_path.t))*delta_t*vx_predict
            predict_path.y = vehicle.y + np.arange(len(predict_path.t))*delta_t*vy_predict

            # 将单值扩展为与 x_predict 相同长度的数组，方便后续二次开发
            predict_path.yaw  = np.full_like(predict_path.x, vehicle.yaw)
            predict_path.boxx = np.full_like(predict_path.x, vehicle.boxx)
            predict_path.boxy = np.full_like(predict_path.x, vehicle.boxy)

            # 添加到predict_paths中
            predict_paths.append(predict_path)

        return predict_paths

    

