"""这两个类主要用于描述车辆在Frenet坐标系下的路径和状态信息。Frenet_path 类用于存储一条完整的路径信息，而 Frenet_state 类用于描述某一时刻的车辆状态。"""

class Frenet_path: 
    def __init__(self):
        self.t = [] # time
        self.d = []
        self.d_d = []
        self.d_dd = []
        self.d_ddd = []
        self.s = []
        self.s_d = []
        self.s_dd = []
        self.s_ddd = []
        self.cd = 0.0
        self.cv = 0.0
        self.cf = 0.0

        """------------------------kappa_setting----------------------------"""
        self.c_k = 0.0              # 单个曲率花销
        self.c_k_d = 0.0            # 曲率突变花销
        self.c_k_dd = 0.0           # 曲率变化率（steering强相关）

        self.c_kappa = 0.0          # 总和

        self.x = []
        self.y = []
        self.yaw = []
        self.ds = []
        self.c = []

        self.boxx = []
        self.boxy = []

class Frenet_state:

    def __init__(self):
        # 时间与Frenet坐标系下的状态
        self.t = 0.0    # 时间(单位:秒)
        self.d = 0.0    # 横向位移(距离参考线的偏移量,单位:米)
        self.d_d = 0.0    # 横向速度(d方向的一阶导数,单位:米/秒)
        self.d_dd = 0.0    # 横向加速度(d方向的二阶导数,单位:米/秒²)
        self.d_ddd = 0.0    # 横向加加速度(d方向的三阶导数,单位:米/秒³)
        self.s = 0.0    # 纵向位移(沿参考线的累积距离,单位:米)
        self.s_d = 0.0    # 纵向速度(s方向的一阶导数,单位:米/秒)
        self.s_dd = 0.0    # 纵向加速度(s方向的二阶导数,单位:米/秒²)
        self.s_ddd = 0.0    # 纵向加加速度(s方向的三阶导数,单位:米/秒³)
        
        # 运动学状态
        self.psi = 0.0    # 车辆航向角(相对于参考线切线的偏角,单位:弧度)
        self.vs = 0.0    # 沿参考线切向的速度分量(单位:米/秒)
        self.vd = 0.0    # 沿参考线法向的速度分量(单位:米/秒)
        self.omega = 0.0    # 车辆的角速度(绕垂直轴的转向速率,单位:弧度/秒)

        # 全局坐标系下的状态
        self.x = 0.0    # 全局坐标系下的X坐标(单位:米)
        self.y = 0.0    # 全局坐标系下的Y坐标(单位:米)
        self.yaw = 0.0    # 全局航向角(车辆朝向,单位:弧度)
        self.ds = 0.0    # 沿参考线的微小位移增量(单位:米)
        self.c = 0.0    # 路径的曲率(单位:1/米,反映路径弯曲程度)