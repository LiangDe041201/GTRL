"""
该代码实现了一个动态地图管理系统，能够从仿真环境或观测数据中实时更新车辆和车道信息，支持车辆定位、车道保持及周围车辆感知。
"""
import numpy as np 
import math
# import sumolib
import threading
import time
import carla
from Agent.tools_dds.tools import *
from Planning_library.vehicle_observation import MotionHistory


class Position():
    def __init__(self):
        self.x = 0
        self.y = 0


class Lanepoint(): 
    def __init__(self):
        self.position = Position()


class Lane():
    def __init__(self):
        self.speed_limit = 30/3.6      # 车道限速 m/s
        self.lane_index = None
        self.central_path = []         # 存储车道中心线点
        self.central_path_array = []   # 中心线点的numpy数组形式
        self.front_vehicles = []
        self.rear_vehicles = []

        self.central_path_points = []  # 存储中心线点
        self.lane_id = -1        # 车道ID


class Vehicle():
    def __init__(self):
        self.x = 0
        self.y = 0
        self.v = 0
        self.vx = 0
        self.vy = 0
        self.ax = 0
        self.ay = 0
        self.acc = None
        self.acc_source = 'unavailable'
        self.yaw = 0
        self.boxx = 0
        self.boxy = 0

        self.lane_idx = 0
        self.dis_to_lane_tail = 0
        self.dis_to_lane_head = 0

        self.carla_id = -1              # 车辆在carla内的唯一id


class DynamicMap():
    def __init__(self, target_speed = 10):
        # events
        self.collision = False
        self.reached_goal = False
        self.lanes_updated = False

        # vehicle state
        self.ego_vehicle = Vehicle()

        # # maps from opendrive
        # self.map = LocalMap()
        # self._map_trigger = threading.Event()

        # if self.map.setup_hdmap(file="", mtype='opendrive'):    # MAP_UNKNOWN = 0 MAP_OPENDRIVE = 1 MAP_SUMO = 2
        #     self._map_trigger.set()
        
        self.lanes = []
        self.lanes_id = []
        
        self.first_route_update  = False
        self.second_route_update = False

        self.frame_count = 0
        self.motion_history = MotionHistory()

    def reset_motion_history(self):
        """Episode boundaries must not create acceleration across a respawn."""
        self.motion_history.reset()

    def update_map(self, env):
        """
        函数功能: 更新动态地图，包括初始化、获取环境车辆信息、车道信息、自车信息。 考虑车道的时候用这个代码
        输入:
            env: CARLA仿真环境
        操作:
            初始化动态地图
            获取环境车辆信息
            获取车道信息
            获取自车信息
        """
        self.env = env
        carla_world = env.world

        self.init_dynamic_map()

        self.get_env_vehicle_information(carla_world)
        self.get_ego_vehicle_information(carla_world)

        # Use simulator time, not wall time or the number of planner reads.
        # All decision methods receive these same observable finite differences.
        try:
            motion_time = carla_world.get_snapshot().timestamp.elapsed_seconds
            self._motion_err = None
        except (AttributeError, RuntimeError) as exc:
            motion_time = None
            self._motion_err = '%s: %s' % (type(exc).__name__, exc)
        self.motion_history.update([self.ego_vehicle] + self.objects, motion_time)

        lane_nums = self.get_lane_information(carla_world)
        
        # print("[Dynamic_map] : ego pose",self.ego_vehicle.x, self.ego_vehicle.y)

        if lane_nums > 0:
            self.locate_ego_vehicle_in_lanes()
            self.locate_surrounding_objects_in_lanes(carla_world)
     
    def update_map_from_obs(self, obs, env):
        """
        函数功能: 更新动态地图，包括初始化、获取环境车辆信息、车道信息、自车信息。
        输入:
            obs: 观测信息
            env: 环境信息
        操作:
            初始化动态地图
            获取环境车辆信息
            获取车道信息
            获取自车信息
        """
        self.init_dynamic_map()

        # Ego information from obs
        self.ego_vehicle.x = obs[0]
        self.ego_vehicle.y = obs[1]      # obs[0] 和 obs[1]:自车的全局坐标(x, y).
        self.ego_vehicle.vx = obs[2]
        self.ego_vehicle.vy = obs[3]     # obs[2] 和 obs[3]:自车的横向(vx)和纵向(vy)速度.
        self.ego_vehicle.lane_idx = 0    # lane_idx = 0:假设自车在车道索引 0(可能需动态计算).
        self.ego_vehicle.boxx = obs[5]
        self.ego_vehicle.boxy = obs[6]

        self.ego_vehicle.v = math.sqrt(self.ego_vehicle.vx ** 2 + self.ego_vehicle.vy ** 2)    #计算自车的合成速度 v

        # The control module used yaw and yawdt 从环境中直接获取自车的偏航角(yaw),并将其转换为弧度.
        self.ego_vehicle.yaw = env.ego_vehicle.get_transform().rotation.yaw / 180.0 * math.pi # Transfer to rad
        # self.ego_vehicle.yawdt = env.ego_vehicle.get_angular_velocity() 
        
        # Env information from obs 处理其他车辆信息
        for i in range(int(len(obs)/7-1)):
            vehicle = Vehicle()
            vehicle.x = obs[0+7+7*i]
            vehicle.y = obs[1+7+7*i]
            vehicle.vx = obs[2+7+7*i]
            vehicle.vy = obs[3+7+7*i]
            vehicle.lane_idx = 0    # 所有车辆的 lane_idx 固定为 0,需动态计算真实车道.
            vehicle.v = math.sqrt(vehicle.vx ** 2 + vehicle.vy ** 2)
            vehicle.boxx = obs[5+7+7*i]
            vehicle.boxy = obs[6+7+7*i]

            self.vehicles.append(vehicle)
        # print("[Dynamic Map]: Add env vehicles num", len(self.vehicles))

        if len(self.lanes) == 0:               # 若车道列表为空
            self.lanes.append(env.ref_path)    # 将环境的参考路径 env.ref_path 添加到 self.lanes 中.
            self.lanes_id.append(0)
            self.lanes_updated = True          # 表示车道信息已更新.
            env.real_time_ref_path_array = env.ref_path_array    # 将环境中的参考路径数组env.ref_path_array赋值给env.real_time_ref_path_array,用于实时路径规划或渲染.

        # For round driving
        # ego_to_start = math.sqrt((self.ego_vehicle.x - env.start_point.location.x) **2 +(self.ego_vehicle.y - env.start_point.location.y) **2)
        # ego_to_end = math.sqrt((self.ego_vehicle.x - env.goal_point.location.x) **2 +(self.ego_vehicle.y - env.goal_point.location.y) **2)
        # if ego_to_start < 10 and self.first_route_update == False:
        #     self.lanes = []
        #     self.lanes_id = []
        #     self.lanes.append(env.ref_path)
        #     self.lanes_id.append(0)
        #     self.lanes_updated = True
        #     self.first_route_update = True
        #     self.second_route_update = False
        #     env.real_time_ref_path_array = env.ref_path_array
            
        # if ego_to_end < 10 and self.second_route_update == False:
        #     self.lanes = []
        #     self.lanes_id = []
        #     self.lanes.append(env.ref_path2)
        #     self.lanes_id.append(0)
        #     self.lanes_updated = True
        #     self.second_route_update = True
        #     self.first_route_update = False
        #     env.real_time_ref_path_array = env.ref_path_array2

    def init_dynamic_map(self):
        """
        函数功能: 初始化动态地图的相关属性和数据结构.
        输入:
            无
        操作:
            清空车辆列表
            重置车道更新标志
            清空车道前车列表
        """
        # 清空车辆列表
        self.vehicles = []

        self.objects = []

        # 重置车道更新标志
        self.lanes_updated = False    

        # 清空车道前车列表
        for lane_id in range(len(self.lanes)):
            self.lanes[lane_id].front_vehicles.clear()  
            self.lanes[lane_id].rear_vehicles.clear()  

    def get_ego_vehicle_information(self, carla_world):
        """
        函数功能: 获取自车信息.
        输入:
            carla_world: CARLA仿真环境
        操作:
            获取自车信息
        """
        actor_list = carla_world.get_actors()
        vehicle_list = actor_list.filter("*vehicle*")

        for vehicle in vehicle_list:
            if vehicle.attributes['role_name'] == "ego_vehicle":
                ego_vehicle = vehicle

                # ego vehicle
                self.ego_vehicle.x = ego_vehicle.get_location().x
                self.ego_vehicle.y = ego_vehicle.get_location().y
                ego_velocity = ego_vehicle.get_velocity()
                self.ego_vehicle.v = math.sqrt(ego_velocity.x ** 2 + ego_velocity.y ** 2 + ego_velocity.z ** 2)
                self.ego_vehicle.carla_id = ego_vehicle.id

                # print("[Dynamic_map] : ego_vehicle speed:", self.ego_vehicle.v)

                self.ego_vehicle.yaw = ego_vehicle.get_transform().rotation.yaw / 180.0 * math.pi # Transfer to rad
                self.ego_vehicle.yawdt = ego_vehicle.get_angular_velocity()

                # print(f"[Dynamic_map] : ego vehicle x: {self.ego_vehicle.x:.2f} ego vehicle y: {self.ego_vehicle.y:.2f} ego vehicle v: {self.ego_vehicle.v:.2f} ego vehicle yaw: {self.ego_vehicle.yaw:.2f}")

                self.ego_vehicle.vx = ego_velocity.x
                self.ego_vehicle.vy = ego_velocity.y

                self.ego_vehicle.boxx = 2*ego_vehicle.bounding_box.extent.x
                self.ego_vehicle.boxy = 2*ego_vehicle.bounding_box.extent.y

                # print(f"[Dynamic_map] : ego vehicle boxx: {self.ego_vehicle.boxx:.2f} ego vehicle boxy: {self.ego_vehicle.boxy:.2f}")

                # # 确定自车所在车道
                # if len(self.lanes) > 0:
                #     # 计算自车到每条车道的距离
                #     dist_list = np.array([dist_from_point_to_polyline2d(
                #                 self.ego_vehicle.x,
                #                 self.ego_vehicle.y,
                #                 lane.central_path_array, return_end_distance=True)
                #                 for lane in self.lanes])

                #     # 选择距离最近的车道作为自车所在车道
                #     self.ego_vehicle.lane_idx = np.argmin(np.abs(dist_list[:, 0]))

                # 初始化自车到车道起点和终点的距离        
                self.dis_to_lane_tail = 0
                self.dis_to_lane_head = 0

    def get_env_vehicle_information(self, carla_world):
        """
        函数功能: 获取环境车辆信息.
        输入:
            carla_world: CARLA仿真环境
        操作:
            获取环境车辆信息
        """
        # 清空车辆列表
        self.vehicles = []
        self.objects = []

        # 处理环境车辆信息 env vehicles
        actor_list = carla_world.get_actors()
        vehicle_list = actor_list.filter("*vehicle*")
        for nv in vehicle_list:
            if nv.attributes['role_name'] != "ego_vehicle":
                # 创建新的车辆对象
                vehicle = Vehicle()
                vehicle.x = nv.get_location().x
                vehicle.y = nv.get_location().y
                observed_velocity = nv.get_velocity()
                vehicle.v = math.sqrt(observed_velocity.x ** 2 + observed_velocity.y ** 2 + observed_velocity.z ** 2)

                vehicle.yaw = nv.get_transform().rotation.yaw / 180.0 * math.pi # Transfer to rad

                vehicle.vx = observed_velocity.x
                vehicle.vy = observed_velocity.y

                vehicle.boxx = 2*nv.bounding_box.extent.x
                vehicle.boxy = 2*nv.bounding_box.extent.y

                vehicle.carla_id = nv.id

                """------------------- 硬筛选，将路边停靠车辆从车道检测集过滤掉 -------------------"""
                # 原版硬编码 y=201~210 是针对直线场景的，转弯场景中 y≈-100~-150，需要自适应
                # 如果车辆在自车所在道路的合理范围内（距自车50m且不在参考路径附近），则纳入vehicles
                ego_y = self.ego_vehicle.y
                # 转弯场景：距自车 80m 内的车辆都纳入检测
                if abs(vehicle.y - ego_y) < 80 or abs(vehicle.x - self.ego_vehicle.x) < 80:
                    self.vehicles.append(vehicle)
                """------------------- 硬筛选，将路边停靠车辆从车道检测集过滤掉 -------------------"""

                # 碰撞观测对象
                self.objects.append(vehicle)
        
        # print("[Dynamic_map] : env vehicles number:", len(self.objects))
        # print("[Dynamic_map] : lane vehicles number:", len(self.vehicles))
        
        # 处理行人信息 env walkers
        walker_list = actor_list.filter("*walker*")
        for nw in walker_list:
            # 创建新的行人对象
            walker = Vehicle()
            walker.x = nw.get_location().x
            walker.y = nw.get_location().y
            walker.v = math.sqrt(nw.get_velocity().x ** 2 + nw.get_velocity().y ** 2 + nw.get_velocity().z ** 2)

            walker.yaw = nw.get_transform().rotation.yaw / 180.0 * math.pi # Transfer to rad

            walker.vx = walker.v * math.cos(walker.yaw)
            walker.vy = walker.v * math.sin(walker.yaw)

            walker.boxx = 2*nw.bounding_box.extent.x
            walker.boxy = 2*nw.bounding_box.extent.y   

            self.vehicles.append(walker)

            # 碰撞观测对象
            self.objects.append(walker)
        
        # 处理障碍物信息
        obstacle_list = actor_list.filter('static.*')
        for no in obstacle_list:
            # 创建新的障碍物对象
            obstacle = Vehicle()
            obstacle.x = no.get_location().x
            obstacle.y = no.get_location().y
            obstacle.v = math.sqrt(no.get_velocity().x ** 2 + no.get_velocity().y ** 2 + no.get_velocity().z ** 2)

            obstacle.yaw = no.get_transform().rotation.yaw / 180.0 * math.pi # Transfer to rad

            obstacle.vx = obstacle.v * math.cos(obstacle.yaw)
            obstacle.vy = obstacle.v * math.sin(obstacle.yaw)

            obstacle.boxx = 2*no.bounding_box.extent.x
            obstacle.boxy = 2*no.bounding_box.extent.y   

            # 碰撞观测对象
            self.objects.append(obstacle)
    
    def get_lane_information(self, carla_world, short_lane_thres=5):
        """
        函数功能: 获取车道信息.
        输入:
            carla_world: CARLA仿真环境
            short_lane_thres: 车道长度阈值
        操作:
            获取车道信息
        """
        # 初始化车道ID计数器，用于为每个车道分配唯一ID
        count_id = 0
        
        # # 更新静态地图并获取车道信息 Update new pose to map to read lanes
        # self.map.receive_new_pose(self.ego_vehicle.x, self.ego_vehicle.y)
        # new_static_map = self.map.update()

        # 获取筛选后的车道信息
        new_static_map = self.get_filtered_lanes(carla_world)

        # # 只使用参考路径作为唯一车道
        # new_static_map = None     # Used only reference path

        # 如果有新的车道信息，更新车道列表
        if new_static_map is not None:
            # print("[Dynamic_map] : Update_lanes num = ",len(new_static_map))
            self.lanes = []
            self.lanes_id = []
            self.lanes_updated = True

            # The lanes will be updated if there are new lanes in static map
            if len(new_static_map) > 0:
                for path in new_static_map:
                    one_lane = Lane()    # 创建新的车道对象
                    t_array = []         # 初始化路径点数组
                    
                    # # 扩展车道，避免自车在车道起点之外 Extend the lane to avoid ego vehicle outside the start of the lane
                    # # 计算车道起点的方向向量，使用前两个路径点确定车道的初始方向
                    # dx = path.central_path_points[1].position.x - path.central_path_points[0].position.x
                    # dy = path.central_path_points[1].position.y - path.central_path_points[0].position.y

                    # # 在车道起点前添加虚拟点，扩展车道，避免自车在车道起点之外，但加了这个路点密度不同，生成路径有问题
                    # for i in range(1,20,1):
                    #     lanepoint = Lanepoint()
                    #     lanepoint.position.x = path.central_path_points[0].position.x - (10 - i) * dx * 10
                    #     lanepoint.position.y = path.central_path_points[0].position.y - (10 - i) * dy * 10

                    #     one_lane.central_path.append(lanepoint)
                    #     waypoint_array = [lanepoint.position.x, lanepoint.position.y]
                    #     t_array.append(waypoint_array)
                    
                    # 添加原始的车道中心线点
                    for waypoint in path.central_path_points:
                        lanepoint = Lanepoint()
                        lanepoint.position.x = waypoint.position.x
                        lanepoint.position.y = waypoint.position.y

                        one_lane.central_path.append(lanepoint)
                        waypoint_array = [waypoint.position.x, waypoint.position.y]
                        t_array.append(waypoint_array)
                    
                    # 设置车道的中心线点
                    one_lane.central_path_array = np.array(t_array)
                    
                    # 计算车道长度，如果车道长度小于阈值，跳过该车道
                    road_len = polyline_length(np.array(one_lane.central_path_array))
                    if road_len <= short_lane_thres:
                        self.lanes_id.append(-1)    # 标记为无效车道
                        continue

                    # 设置车道的速度限制
                    one_lane.speed_limit = 60/3.6
                    
                    # 更新车道索引和列表
                    #FIXME: Calculate id like this might be wrong
                    one_lane.lane_index = count_id    # 更新车道索引
                    self.lanes.append(one_lane)       # 添加车道到列表
                    self.lanes_id.append(count_id)    # 添加车道ID
                    count_id = count_id + 1

        # If there is no lanes in dynamic map, use reference path as the only lane
        if len(self.lanes) == 0:
            one_lane = Lane()
            t_array = []
            for waypoint in self.env.ref_path_array:
                lanepoint = Lanepoint()
                lanepoint.position.x = waypoint[0]
                lanepoint.position.y = waypoint[1]

                one_lane.central_path.append(lanepoint)
                t_array.append(waypoint)

            one_lane.central_path_array = np.array(t_array)
            one_lane.speed_limit = 30/3.6

            one_lane.lane_index = 0
            self.lanes.append(one_lane)
            self.lanes_id.append(0)
            self.lanes_updated = True
        
        # 确定自车所在车道
        if len(self.lanes) > 0:
            # 计算自车到每条车道的距离
            dist_list = np.array([dist_from_point_to_polyline2d(
                        self.ego_vehicle.x,
                        self.ego_vehicle.y,
                        lane.central_path_array, return_end_distance=True)
                        for lane in self.lanes])

            # 选择距离最近的车道作为自车所在车道
            self.ego_vehicle.lane_idx = np.argmin(np.abs(dist_list[:, 0]))

        return len(self.lanes)

    def get_filtered_lanes(self, carla_world):
        """
        函数功能: 获取筛选后的车道信息.
        输入:
            carla_world: CARLA仿真环境
        操作:
            获取筛选后的车道信息
        """
        # ===== 【关键修改】转弯场景：直接使用参考路径，不再从地图提取大量车道 =====
        # 如果环境中有 ref_path_array，直接返回它作为唯一车道，避免混乱。
        if hasattr(self, "env") and getattr(self.env, "ref_path_array", None) is not None \
                and len(self.env.ref_path_array) > 3:
            ref = np.asarray(self.env.ref_path_array, dtype=float)
            ref_path = Lane()
            ref_path.central_path_array = ref
            pts = []
            for _px, _py in ref:
                lp = Lanepoint()
                lp.position.x = _px
                lp.position.y = _py
                pts.append(lp)
            ref_path.central_path_points = pts
            ref_path.central_path = pts
            ref_path.lane_id = 0
            ref_path.speed_limit = 60 / 3.6
            # 直接返回单条参考路径，禁止地图拓扑提取
            print("[DynamicMap] 转弯场景：仅使用参考路径作为唯一车道")
            return [ref_path]

        # ===== 以下为原版直道场景的车道提取逻辑（保留备用） =====
        # 初始化筛选后的车道列表
        filtered_lanes = []
        all_lanes = []
        processed_lanes = set()

        # 获取地图对象
        world = carla_world
        carla_map = world.get_map()

        # 获取自车位置和航向
        ego_location = carla.Location(x=self.ego_vehicle.x, y=self.ego_vehicle.y, z=0)
        ego_waypoint = carla_map.get_waypoint(
            ego_location,
            project_to_road=True,
            lane_type=carla.LaneType.Driving
        )
        ego_yaw = ego_waypoint.transform.rotation.yaw
        ego_boxx = self.ego_vehicle.boxx
        ego_boxy = self.ego_vehicle.boxy
        ego_lane_id = ego_waypoint.lane_id
        ego_road_id = ego_waypoint.road_id

        # 获取所有的车道信息
        all_segments = carla_map.get_topology()

        for segment in all_segments:
            start_wp, end_wp = segment[0], segment[1]

            # 如有重复的车道，跳过
            lane_key = (start_wp.road_id, start_wp.lane_id, 
                        round(start_wp.transform.location.x, 1), 
                        round(start_wp.transform.location.y, 1))
            if lane_key in processed_lanes:
                continue
            processed_lanes.add(lane_key)
            
            # 检查车道类型是否可行驶
            if start_wp.lane_type != carla.LaneType.Driving:
                continue

            # 距离过滤
            dist_to_ego = start_wp.transform.location.distance(ego_location)
            if dist_to_ego > 150.0:
                continue
            
            # 道路ID过滤：允许附近道路
            if start_wp.road_id != ego_road_id and dist_to_ego > 25.0:
                continue

            # 获取当前车道的左右相邻车道
            current_lane_id = start_wp.lane_id
            left_lane = start_wp.get_left_lane()
            right_lane = start_wp.get_right_lane()
            
            # 检查是否是同一车道或相邻车道
            is_same_or_adjacent = (
                current_lane_id == ego_lane_id or
                (left_lane and left_lane.lane_id == ego_lane_id) or
                (right_lane and right_lane.lane_id == ego_lane_id)
            )
            
            if is_same_or_adjacent:
                path = Lane()
                path_points = []
                
                # 获取车道中心线点
                current_wp = start_wp
                distance = 0
                max_distance = 200.0
                sample_distance = 1.0
                
                while distance < max_distance:
                    path_points.append(current_wp.transform.location)
                    next_wps = current_wp.next(sample_distance)
                    if not next_wps:
                        break
                    current_wp = next_wps[0]
                    distance += sample_distance
                    
                    if current_wp.road_id != start_wp.road_id:
                        current_lane_id = current_wp.lane_id
                        left_lane = current_wp.get_left_lane()
                        right_lane = current_wp.get_right_lane()
                        is_same_or_adjacent = (
                            current_lane_id == ego_lane_id or
                            (left_lane and left_lane.lane_id == ego_lane_id) or
                            (right_lane and right_lane.lane_id == ego_lane_id)
                        )
                        if not is_same_or_adjacent:
                            break
                
                if path_points:
                    one_central_path_points = []
                    for point in path_points:
                        pathpoint = Lanepoint()
                        pathpoint.position.x = point.x
                        pathpoint.position.y = point.y
                        one_central_path_points.append(pathpoint)
                    
                    central_path_ori = convert_path_to_ndarray(one_central_path_points)
                    dense_points = dense_polyline2d(central_path_ori, 2)

                    path.central_path_points = []
                    for point in dense_points:
                        lanepoint = Lanepoint()
                        lanepoint.position.x = point[0]
                        lanepoint.position.y = point[1]
                        path.central_path_points.append(lanepoint)

                    path.lane_id = start_wp.lane_id
                    filtered_lanes.append(path)
                    all_lanes.append(path)

        # 创建过渡车道
        transition_lanes = self.create_transition_lanes(filtered_lanes, ego_boxy)
        
        # 将每个过渡车道插入到对应的原始车道之间
        for transition_lane in transition_lanes:
            parts = transition_lane.lane_id.split('_')
            lane1_id = int(parts[1])
            lane2_id = int(parts[3])
            for i in range(len(all_lanes) - 1):
                current_id = all_lanes[i].lane_id
                if current_id == lane1_id and parts[5] == 'right':
                    all_lanes.insert(i + 1, transition_lane)
            for k in range(len(all_lanes)):
                next_id = all_lanes[k].lane_id
                if next_id == lane2_id and parts[5] == 'left':
                    all_lanes.insert(k, transition_lane)

        return all_lanes

    def create_transition_lanes(self, filtered_lanes, ego_boxy):
        """
        在相邻车道之间创建过渡车道
        
        参数:
            filtered_lanes: 筛选后的车道列表
            
        返回:
            list: 包含所有过渡车道的列表
        """
        transition_lanes = []
        
        # 按车道ID排序，确保相邻车道是连续的
        sorted_lanes = sorted(filtered_lanes, key=lambda lane: lane.lane_id)
        
        # 遍历相邻的车道对
        for i in range(len(sorted_lanes) - 1):
            lane1 = sorted_lanes[i]
            lane2 = sorted_lanes[i + 1]
            
            # 计算过渡车道的中心线（取两条车道中心线的平均值）
            points1 = np.array([(p.position.x, p.position.y) for p in lane1.central_path_points])
            points2 = np.array([(p.position.x, p.position.y) for p in lane2.central_path_points])
            
            # 确保两个点集长度相同
            min_len = min(len(points1), len(points2))
            points1 = points1[:min_len]
            points2 = points2[:min_len]
            
            # 计算方向向量（从lane2指向lane1）
            direction_vectors = points1 - points2

            # 归一化方向向量
            norms = np.linalg.norm(direction_vectors, axis=1, keepdims=True)

            # 避免除以零
            norms = np.where(norms == 0, 1, norms)
            direction_vectors = direction_vectors / norms
            
            # 计算偏移距离（使用ego_boxy宽度的一半）
            offset_distance = ego_boxy / 2.0 
            
            # 创建两条过渡车道：一条向lane1偏移，一条向lane2偏移
            for offset in [-offset_distance, offset_distance]:
                # 计算偏移后的点
                offset_points = (points1 + points2) / 2.0 + direction_vectors * offset
                
                # 创建新的过渡车道
                transition_lane = type(lane1)()
                transition_lane.lane_id = f"transition_{lane1.lane_id}_to_{lane2.lane_id}_offset_{'left' if offset < 0 else 'right'}"
                
                # 创建过渡车道的中心线点
                transition_lane.central_path_points = []
                for point in offset_points:
                    path_point = type(lane1.central_path_points[0])()
                    path_point.position.x = point[0]
                    path_point.position.y = point[1]
                    transition_lane.central_path_points.append(path_point)
            
                # 将过渡车道添加到结果列表
                transition_lanes.append(transition_lane)
        
        return transition_lanes

    def locate_ego_vehicle_in_lanes(self, lane_end_dist_thres=5, lane_dist_thres=5):
        """
        函数功能: 定位自车在车道中的位置.
        输入:
            lane_end_dist_thres: 车道末端距离阈值
            lane_dist_thres: 车道距离阈值
        操作:
            定位自车在车道中的位置
        """
        # 计算自车到每个车道中心线的距离
        dist_list = np.array([dist_from_point_to_polyline2d(
            self.ego_vehicle.x, self.ego_vehicle.y,
            lane.central_path_array, return_end_distance=True)
            for lane in self.lanes])

        # 定位自车所在车道
        ego_lane_index = self.locate_object_in_lane()
        ego_lane_index_rounded = int(round(ego_lane_index))

        # print("ego_lane_index=",ego_lane_index)

        # 更新自车到车道起点和终点的距离
        self.ego_vehicle.dis_to_lane_head = dist_list[:, 3]
        self.ego_vehicle.dis_to_lane_tail = dist_list[:, 4]

        # 检查自车所在车道是否有效；若无效，回退到最近车道，避免后续规划链路中断
        if ego_lane_index_rounded < 0 or ego_lane_index_rounded > len(self.lanes) - 1:
            if len(self.lanes) > 0:
                fallback_lane = int(np.argmin(np.abs(dist_list[:, 0]))) if len(dist_list) > 0 else 0
                fallback_lane = max(0, min(fallback_lane, len(self.lanes) - 1))
                self.ego_vehicle.lane_idx = fallback_lane
            else:
                self.ego_vehicle.lane_idx = 0
            return

        # print("[Dynamic_map]: Distance to end", ego_lane_index, self.ego_vehicle.dis_to_lane_tail[ego_lane_index_rounded])

    def locate_surrounding_objects_in_lanes(self, carla_world, lane_dist_thres=1):
        """
        函数功能: 定位周围车辆在车道中的位置.
        输入:
            carla_world: CARLA仿真环境
            lane_dist_thres: 车道距离阈值
        操作:
            定位周围车辆在车道中的位置
        """
        lane_front_vehicle_list = [[] for _ in self.lanes]
        lane_rear_vehicle_list = [[] for _ in self.lanes]

        # TODO: separate vehicle and other objects?
        # print("[Dynamic_map] : vehicles num:", len(self.vehicles))
        if self.vehicles is not None:
            for vehicle_idx, vehicle in enumerate(self.vehicles):
                dist_list = np.array([dist_from_point_to_polyline2d(
                    vehicle.x,
                    vehicle.y,
                    lane.central_path_array, return_end_distance=True)
                    for lane in self.lanes])
                closest_lane = np.argmin(np.abs(dist_list[:, 0]))

                # Determine if the vehicle is close to lane enough
                if abs(dist_list[closest_lane, 0]) > lane_dist_thres:
                    continue 
                if dist_list[closest_lane, 3] < self.ego_vehicle.dis_to_lane_head[closest_lane]:
                    # The vehicle is behind if its distance to lane start is smaller
                    lane_rear_vehicle_list[closest_lane].append((vehicle_idx, dist_list[closest_lane, 3]))
                if dist_list[closest_lane, 4] < self.ego_vehicle.dis_to_lane_tail[closest_lane]:
                    # The vehicle is ahead if its distance to lane end is smaller
                    lane_front_vehicle_list[closest_lane].append((vehicle_idx, dist_list[closest_lane, 4]))
                vehicle.lane_idx = closest_lane
        
        # Put the vehicles onto lanes
        for lane_id in range(len(self.lanes)):
            front_vehicles = np.array(lane_front_vehicle_list[lane_id])
            rear_vehicles = np.array(lane_rear_vehicle_list[lane_id])

            # print("[Dynamic_map] : front_vehicles num:", lane_id, len(front_vehicles))
            # print("[Dynamic_map] : rear_vehicles num:", lane_id, len(rear_vehicles))

            if len(front_vehicles) > 0:
                # Descending sort front objects by distance to lane end
                for vehicle_row in reversed(front_vehicles[:,1].argsort()):

                    front_vehicle_idx = int(front_vehicles[vehicle_row, 0])
                    front_vehicle = self.vehicles[front_vehicle_idx]
                    self.lanes[lane_id].front_vehicles.append(front_vehicle)

            if len(rear_vehicles) > 0:
                # Descending sort rear objects by distance to lane end
                for vehicle_row in reversed(rear_vehicles[:,1].argsort()):
                    rear_vehicle_idx = int(rear_vehicles[vehicle_row, 0])
                    rear_vehicle = self.vehicles[rear_vehicle_idx]
                    self.lanes[lane_id].rear_vehicles.append(rear_vehicle)
                
    def locate_object_in_lane(self, dist_list=None, lane_dist_thres=5):
        '''
        Calculate (continuous) lane index for a object.
        Parameters: dist_list is the distance buffer. If not provided, it will be calculated
        功能：计算物体在车道中的连续索引
        输入:
            dist_list: 距离列表
            lane_dist_thres: 车道距离阈值
        操作:
            计算物体在车道中的连续索引
        '''
        if not dist_list:
            dist_list = np.array([dist_from_point_to_polyline2d(
                self.ego_vehicle.x,
                self.ego_vehicle.y,
                lane.central_path_array) for lane in self.lanes])

        # print("[Dynamic_map] : ego_dist_list=",dist_list)
        
        # Check if there's only two lanes
        if len(self.lanes) < 2:
            closest_lane = second_closest_lane = 0
        else:
            closest_lane, second_closest_lane = np.abs(dist_list[:, 0]).argsort()[:2]

        # Signed distance from target to two closest lane
        closest_lane_dist, second_closest_lane_dist = dist_list[closest_lane, 0], dist_list[second_closest_lane, 0]

        if abs(closest_lane_dist) > lane_dist_thres:
            return float(closest_lane)

        # Judge whether the point is outside of lanes
        if closest_lane == second_closest_lane or closest_lane_dist * second_closest_lane_dist > 0:
            # The object is at left or right most
            return closest_lane
        else:
            # The object is between center line of lanes
            a, b = closest_lane, second_closest_lane
            la, lb = abs(closest_lane_dist), abs(second_closest_lane_dist)
            return (b*la + a*lb)/(lb + la)
