class LaneAction(object):
    
    def __init__(self,target_lane_index=None,target_speed=None):
        self.target_lane_index = target_lane_index
        self.target_speed = target_speed

class TrajectoryAction(object):

    def __init__(self, trajectory=None, desired_speed=None, frenet=None,
                 force_stop=False, speed_limit=None, planning_status='normal'):
        self.trajectory = trajectory    #存储轨迹信息,是一个二维数组,包含轨迹点的坐标.
        self.desired_speed = desired_speed    #存储每个轨迹点的期望速度,是一个一维数组.
        # 【式(24)】候选轨迹的完整 Frenet 剖面（含 s_ddd=纵向加加速度、yaw、c=曲率、t）。
        #   存在的理由：式(24) 的 U_comfort=(J_LCV−J_TH)²+(ψ_LCV−ψ_TH)² 里，
        #   J_LCV/ψ_LCV **必须由候选轨迹推出**，否则 12 个动作的舒适项完全相同，
        #   二维动作空间的一半区分度会丢在舒适项里。
        self.frenet = frenet
        # 几何路径可用于保持方向，但不代表允许继续前进。
        self.force_stop = bool(force_stop)
        self.speed_limit = speed_limit
        self.planning_status = str(planning_status)

class ControlAction(object):

    def __init__(self,acc=0,steering=0):
        self.acc = acc
        self.steering = steering
        
"""
这段代码定义了三个类，分别用于不同层次的车辆控制指令。以下是各部分的详细解释：
    LaneAction 类
        用途：处理车道级别的控制指令（如变道决策）
        参数：
            target_lane_index(目标车道索引):整数，表示车辆要切换到的车道编号(例如 0 表示当前车道,1 表示右侧车道)
            target_speed(目标速度）:变道完成后期望达到的速度值
        示例场景：自动驾驶车辆需要超越前车时，生成 target_lane_index=1 和 target_speed=30m/s 的指令

    TrajectoryAction 类
        用途：处理路径轨迹级别的控制指令
        参数：
            trajectory(轨迹):预期要跟随的路径数据（通常是包含时间-空间坐标的序列）
            desired_speed(期望速度):沿轨迹移动时要求保持的速度
        示例场景：在复杂路口转弯时，规划包含具体路径点的轨迹和对应的安全通过速度

    ControlAction 类
        用途：直接控制车辆底层执行器
        参数：
            acc(加速度):车辆加速度值（单位通常是 m/s²,正值为加速,负值为减速)
            steering(转向角):方向盘转向角度(单位可能是弧度或百分比，正值通常表示右转)
        示例场景：实时控制中直接设置 acc=0.5m/s² 和 steering=0.1rad 来调整车辆状态

类关系分析：
    这三个类呈现了典型的自动驾驶系统分层控制结构：
        高级决策层(LaneAction):制定战略级决策(如是否变道)
        路径规划层(TrajectoryAction):生成具体的行驶路径
        底层控制层(ControlAction):转换为直接控制信号
"""
