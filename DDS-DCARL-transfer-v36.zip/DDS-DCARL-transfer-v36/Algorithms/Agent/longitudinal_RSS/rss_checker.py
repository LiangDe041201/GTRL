"""这是一个责任敏感性的自动驾驶检测文件，主要功能是计算安全的纵向速度范围"""

import numpy as np


"""-----------初始化设置，包括一些物理参数设置-----------"""
RESPONSE_TIME = 0.5
LONGITUDINAL_ACC_MAX = 2.0
LONGITUDINAL_BRAKE_MIN = 4.0
LONGITUDINAL_BRAKE_MAX = 5.0
# 处理无法切入的时间步长
FUTURE_T = 1



class RSS_checker(object):
    def __init__(self):
        self.response_time = RESPONSE_TIME
        self.longitudinal_acc_max = LONGITUDINAL_ACC_MAX
        self.longitudinal_brake_min = LONGITUDINAL_BRAKE_MIN
        self.longitudinal_brake_max = LONGITUDINAL_BRAKE_MAX

    def get_safe_speed_bound(self, front_veh, rear_veh, ego_veh):
        """
        功能：根据责任安全模型的物理模型输出横向的安全速度范围
        输入：目标道上的前车和后车 (type:dynamic_map.vehicle)
        逻辑：分别计算范围取并集
            不可行时返回纵向的确定速度
        输出：纵向的速度规划范围
        """
        if front_veh and rear_veh:
            front_bound = self.get_front_veh_bound(front_veh, ego_veh)
            rear_bound = self.get_rear_veh_bound(rear_veh, ego_veh)
            final_bound = (max(front_bound[0], rear_bound[0]), min(front_bound[1], rear_bound[1]))

        elif front_veh and not rear_veh:
            final_bound = self.get_front_veh_bound(front_veh, ego_veh)

        elif rear_veh and not front_veh:
            final_bound = self.get_rear_veh_bound(rear_veh, ego_veh)

        else:
            final_bound = (ego_veh.v, ego_veh.v+0.01)

        bound_valid = True
        # TEMP(4.15):处理掉计算后范围失效的问题，此时的速度规划就算纵向必然碰撞
        if final_bound[0] >= final_bound[1]:
            bound_valid = False
            final_speed = self.deal_invalid(front_veh, rear_veh, ego_veh, FUTURE_T)
            # 输出格式修正
            final_bound = (final_speed, final_speed)


        # FIXME:速度规划必须要比自车现在速度多2,否则会卡死

        # TODO(4.15):多加一个有效与否的旗帜，用于下一步横向的控制
        return final_bound, bound_valid


    def get_front_veh_bound(self, veh, ego_veh):
        """
        功能：根据前车计算出合理速度范围
        输入处理：前车运动朝向（same_direction是否和自车同向）、与自车的距离dis_to_ego
        逻辑：子情况1：前车前进
                输出：最大速度
            子情况2：前车后退、反向
                输出：TODO（4.3反向情况保留）
                避免碰撞的最大速度
        """

        # 用yaw角计算朝向
        delta_yaw = abs(ego_veh.yaw - veh.yaw)
        if delta_yaw > 1.57:
            same_direction = 0
        else:
            same_direction = 1              # 判断和自车是否同向

        ego_location =  np.array((ego_veh.x, ego_veh.y))
        veh_location =  np.array((veh.x, veh.y))
        dis_to_ego = max(0, float(np.linalg.norm(ego_location - veh_location)) - veh.boxx/2 - ego_veh.boxx/2)

        ego_vel = ego_veh.v
        veh_vel = veh.v

        # 统一计算前车最坏情况的速度
        other_vel_at_response_time = abs(veh_vel) + self.response_time * self.longitudinal_acc_max

        # 子情况1前车与自车同向,防追尾
        if same_direction == 1:
            # 解二次方程
            other_distance_driven =(abs(veh_vel)*abs(veh_vel)) / (2 * self.longitudinal_brake_max)
            a = 1/(2*self.longitudinal_brake_min)
            b = self.response_time + (self.longitudinal_acc_max*self.response_time/self.longitudinal_brake_min)
            c = (0.5 *(self.longitudinal_acc_max +
                         pow(self.longitudinal_acc_max, 2) /
                             self.longitudinal_brake_min) *pow(self.response_time, 2) - other_distance_driven -
                 dis_to_ego)

            ego_vel_upp = max(0, (-b + np.sqrt(pow(b, 2) - 4 * a * c)) / (2 * a))
            ego_vel_low = 0

        # 子情况2自车和前车不同向
        # FIXME:占位，无返回逻辑
        else:
            # 他车最坏情况距离
            other_distance_driven = ((abs(veh_vel) + other_vel_at_response_time) * self.response_time / 2.0  +
                other_vel_at_response_time * other_vel_at_response_time / (2 * self.longitudinal_brake_min))

            # 必定碰撞
            if other_distance_driven > dis_to_ego:
                ego_vel_upp = 0
                ego_vel_low = 0

            else:
                a = 1 / (2 * self.longitudinal_brake_min)
                b = self.response_time + (self.longitudinal_acc_max * self.response_time / self.longitudinal_brake_min)
                c = (0.5 * (self.longitudinal_acc_max +
                            pow(self.longitudinal_acc_max, 2) /
                            self.longitudinal_brake_min) * pow(self.response_time, 2) + other_distance_driven -
                     dis_to_ego)

                ego_vel_upp = max(0, (-b + np.sqrt(pow(b, 2) - 4 * a * c)) / (2 * a))
                ego_vel_low = 0

        return ego_vel_low, ego_vel_upp


    def get_rear_veh_bound(self, veh, ego_veh):
        """
        功能:计算rss的后车安全速度约束
        输入：后车的速度，两车的距离
        """

        ego_location = np.array((ego_veh.x, ego_veh.y))
        veh_location = np.array((veh.x, veh.y))
        dis_to_ego = max(0, float(np.linalg.norm(ego_location - veh_location)) - veh.boxx / 2 - ego_veh.boxx / 2)

        veh_vel = veh.v
        other_vel_abs = abs(veh_vel)
        # 最坏情况加速
        other_vel_at_response_time = abs(veh_vel) + self.response_time * self.longitudinal_acc_max

        # 他车最坏情况驾驶距离
        other_distance_driven = ((other_vel_abs + other_vel_at_response_time) /
            (2.0 * self.response_time + other_vel_at_response_time * other_vel_at_response_time /
            (2 * self.longitudinal_brake_min)))

        # 最坏情况对自车无威胁
        if other_distance_driven < dis_to_ego:
            ego_vel_upp = 100
            # FIXME:修复卡死
            ego_vel_low = 0
        # 有威胁要算最小速度
        else:
            ego_vel_upp = 100
            ego_vel_low = max(0, np.sqrt(2 * self.longitudinal_brake_max *
                            (other_distance_driven - dis_to_ego)))

        return ego_vel_low, ego_vel_upp


    def deal_invalid(self, front_veh, rear_veh, ego_veh, future_t):
        """
        功能：处理原本rss在间隙很小时候的失效性，这个阶段需要进行的是姿态边界规划
        逻辑：
            1.间隙小可算出下一时间步（1s）的gap在何处，对车辆接近角点进行纵向规划
        输入：前车后车和自车 typy:dynamic.vehicle
            未来规划的步长
        """

        """
        规划思想：
            用于下一个切入阶段的横向位姿调整
        
         __________             __________
        |          |           |          |
        |          |           |          |
         ----------             ---------- 
        --------------------------------------------------------------------
                         |
                         |     <- 自车前边界
        """

        # fixme(4.15这是当下任务的前边界计算):自车前边界规划
        ego_current_front_edge = ego_veh.x + ego_veh.boxx/2
        ego_current_speed = ego_veh.vx

        # fixme:可能速度单位有区别
        # 计算出下一个时间步长下gap的边界位置
        future_back_edge = rear_veh.x + rear_veh.boxx/2 + rear_veh.vx*future_t
        future_front_edge = front_veh.x - front_veh.boxx/2 + front_veh.vx*future_t

        # NOTE:先简单的纵向规划到gap中点  可能也会有速度是负数规划错误
        ego_edge_target = (future_back_edge + future_front_edge)/2
        # 步进长度FIXME:应该先预热自车的
        step_dis = ego_edge_target - ego_current_front_edge
        v_target = max(0, 2*step_dis/future_t - ego_current_speed)

        return v_target





