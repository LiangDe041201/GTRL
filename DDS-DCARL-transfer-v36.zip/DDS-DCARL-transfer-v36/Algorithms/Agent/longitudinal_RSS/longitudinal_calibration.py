"""
CARLA 车辆动力学标定：
遍历 0~25 m/s，测量每个速度下的【最大加速度】和【最大减速度】
throttle=1.0, brake=1.0
可自定义保存路径！
"""
import sys
import os
import glob


def _setup_carla_paths():
    """可移植的 CARLA PythonAPI 定位（环境变量 -> 常见位置），找不到时打印警告"""
    _home = os.path.expanduser("~")
    _cands = [os.environ.get("CARLA_ROOT"),
              os.path.join(_home, "Carla"),
              os.path.join(_home, "carla"),
              os.path.expanduser("~/carla_0.9.15"),
              os.path.expanduser("~/Software/Carla0_9_15"),
              os.path.expanduser("~/Carla0_9_15")]
    # 大小写不敏感地补充主目录下的 carla* 目录（Linux 区分大小写）
    try:
        _cands += [os.path.join(_home, _n) for _n in sorted(os.listdir(_home))
                   if _n.lower().startswith("carla") and os.path.isdir(os.path.join(_home, _n))]
    except OSError:
        pass
    for _root in _cands:
        if not _root:
            continue
        _ms = sorted(glob.glob(os.path.join(_root, "PythonAPI/carla/dist/*.egg")))
        if _ms:
            # 优先挑选与当前 Python 版本匹配的 egg（dist 目录可能同时含 py2.7 / py3.7 多个）
            _ver = "py%d.%d" % (sys.version_info[0], sys.version_info[1])
            _match = [e for e in _ms if _ver in os.path.basename(e)]
            sys.path.append(_match[0] if _match else _ms[0])
            return _root
        if os.path.isdir(os.path.join(_root, "PythonAPI/carla")):
            sys.path.append(os.path.join(_root, "PythonAPI/carla"))
            return _root
    print("[Calibration] 警告: 未找到 CARLA PythonAPI，请设置环境变量 CARLA_ROOT")
    return None


_setup_carla_paths()

import carla
import math
import numpy as np

# ====================== 【你可以自由修改这里】 ======================
VEHICLE_TYPE = 'vehicle.lincoln.mkz_2020'

# 速度 0 ~ 25 m/s，每 1 m/s 一个点
VELOCITY_GRID = np.linspace(0, 30, num=31, dtype=float)

# 输出文件保存路径（相对本文件，换机器无需改）
SAVE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "calibration_results")
# ====================================================================

ACC_DURATION = 2
DEC_DURATION = 2
DT = 0.02
WAIT_TICK = 30


class Calibration:
    def __init__(self):
        self.client = carla.Client("localhost", 2000)
        self.client.set_timeout(15.0)
        self.world = self.client.load_world("Town04")
        self.world.set_weather(carla.WeatherParameters(
            cloudiness=0, precipitation=0, sun_altitude_angle=70.0))

        settings = self.world.get_settings()
        settings.synchronous_mode = True
        settings.fixed_delta_seconds = DT
        self.world.apply_settings(settings)
        print("CARLA 同步模式已启动")

        # 自动创建保存文件夹
        if not os.path.exists(SAVE_DIR):
            os.makedirs(SAVE_DIR)
            print(f"已创建文件夹：{SAVE_DIR}")

        self.ego_vehicle = None
        bp_lib = self.world.get_blueprint_library()
        self.ego_bp = bp_lib.find(VEHICLE_TYPE)

    def get_speed(self):
        v = self.ego_vehicle.get_velocity()
        return math.hypot(v.x, v.y, v.z)

    def max_accel_at_vel(self, target_vel):
        print(f"\n=== 最大加速测试 | 目标速度: {target_vel:.2f} m/s ===")
        spawn_point = carla.Transform(
            carla.Location(-9.6, -205.3, 0.5),
            carla.Rotation(0, 90, 0))
        self.ego_vehicle = self.world.spawn_actor(self.ego_bp, spawn_point)

        for _ in range(WAIT_TICK):
            self.ego_vehicle.set_target_velocity(carla.Vector3D(0, target_vel * 1.1, 0))
            self.world.tick()

        while True:
            current = self.get_speed()
            self.world.tick()
            if current <= target_vel + 0.1:
                break

        start_v = self.get_speed()
        t = 0
        for _ in range(int(ACC_DURATION / DT)):
            self.ego_vehicle.apply_control(carla.VehicleControl(throttle=1.0, brake=0))
            self.world.tick()
            t += DT
        end_v = self.get_speed()

        acc = (end_v - start_v) / t
        print(f"最大加速度: {acc:.3f} m/s²")

        self.clear()
        return acc

    def max_decel_at_vel(self, target_vel):
        print(f"\n=== 最大减速测试 | 目标速度: {target_vel:.2f} m/s ===")
        spawn_point = carla.Transform(
            carla.Location(-9.6, -205.3, 0.5),
            carla.Rotation(0, 90, 0))
        self.ego_vehicle = self.world.spawn_actor(self.ego_bp, spawn_point)

        for _ in range(WAIT_TICK):
            self.ego_vehicle.set_target_velocity(carla.Vector3D(0, target_vel * 1.1, 0))
            self.world.tick()

        while True:
            current = self.get_speed()
            self.world.tick()
            if current <= target_vel + 0.1:
                break

        start_v = self.get_speed()
        t = 0
        for _ in range(int(DEC_DURATION / DT)):
            self.ego_vehicle.apply_control(carla.VehicleControl(throttle=0, brake=1.0))
            self.world.tick()
            t += DT
            if self.get_speed() < 0.1:
                break

        end_v = self.get_speed()
        dec = (end_v - start_v) / t
        print(f"最大减速度: {dec:.3f} m/s²")

        self.clear()
        return dec

    def run_max_calib(self):
        max_acc = []
        max_dec = []
        for v in VELOCITY_GRID:
            a = self.max_accel_at_vel(v)
            d = self.max_decel_at_vel(v)
            max_acc.append([v, a])
            max_dec.append([v, d])


        # 保存到指定目录
        acc_file = os.path.join(SAVE_DIR, "max_acceleration_0_25.txt")
        dec_file = os.path.join(SAVE_DIR, "max_deceleration_0_25.txt")

        np.savetxt(acc_file, max_acc, fmt="%.3f,%.3f")
        np.savetxt(dec_file, max_dec, fmt="%.3f,%.3f")

        print("\n✅ 标定完成！文件已保存到：")
        print(f" - {acc_file}")
        print(f" - {dec_file}")

    def clear(self):
        if self.ego_vehicle is not None:
            self.ego_vehicle.destroy()
            self.ego_vehicle = None


if __name__ == "__main__":
    calib = Calibration()
    calib.run_max_calib()
