# -*- coding: utf-8 -*-
"""式(24) 的 `J_LCV` / `ψ_LCV`：从**候选轨迹**推出，禁止传常数。

论文 §III.C 式(24)（原文核对 `_ADVEI_docx_text.txt:241-244`）：
```
U_comfort = (J_LCV − J_TH)² + (ψ_LCV − ψ_TH)²
```
正文定义：`J_LCV` 是 LCV 的 **jerk（加加速度）**，`J_TH` 是 jerk 阈值；
`ψ_LCV` 是 LCV 的 **steering angle rate（转向角速率）**，`ψ_TH` 是转向角速率阈值。

## 为什么必须模块化（历史缺陷）
改造前 `dds_dcarl_turn.py:1712` 的调用是：
```python
cournot_decision(..., jerk=1.0, steer=0.4, jerk_th=0.5, steer_th=0.3)
```
而 `:1710` 的注释却写"U_comfort 用真实 jerk/转向角速率" ⇒ **注释与实现不符**。
后果：**12 个候选动作的 U_comfort 完全相同**，式(24) 对二维动作**零区分度**
—— 二维动作空间的一半信息量直接丢在舒适项里。

## 口径（用户明确要求）
- `J_LCV` = 候选轨迹的**实际纵向加加速度**：优先用 Frenet 纵向多项式的三阶导 `s_ddd`；
  退化时对 `desired_speed` 做二阶差分（= 加速度的一阶差分 = jerk）。
- `ψ_LCV` = 候选轨迹的**实际转向角速率**，**不是 ψ（航向角）本身**：
  优先用 `Δyaw/Δt`（航向角速率，与转向角速率经自行车模型单调相关）；
  退化时用曲率变率 `Δκ/Δt`。
  取 `max|·|` 作为该动作的"最激进时刻"，与论文把阈值当**边界**的语义一致。

本模块**不依赖 carla**，可离线对拍。
"""
import math


def _series(path, name):
    try:
        v = getattr(path, name, None)
    except Exception:
        return []
    if not v:
        return []
    out = []
    for x in v:
        try:
            fx = float(x)
        except (TypeError, ValueError):
            return []
        if not math.isfinite(fx):
            return []
        out.append(fx)
    return out


def _max_abs_diff_ratio(series, times):
    """`max |Δseries/Δt|`；样本不足时返回 None。"""
    if len(series) < 2:
        return None
    if times is not None and len(times) == len(series):
        best = 0.0
        hit = False
        for i in range(1, len(series)):
            dt = times[i] - times[i - 1]
            if dt <= 1e-9:
                continue
            r = abs(series[i] - series[i - 1]) / dt
            best = max(best, r)
            hit = True
        return best if hit else None
    return max(abs(series[i] - series[i - 1]) for i in range(1, len(series)))


def trajectory_comfort(frenet=None, traj_xy=None, desired_speed=None, dt=0.1):
    """从候选轨迹推出 `(jerk, steer)`，供式(24) 的 U_comfort 使用。

    参数
    ----
    frenet : 候选轨迹的 `Frenet_path`（首选）。含 `s_ddd`（纵向三阶导=jerk）、
             `yaw`、`c`（曲率）、`t`（时间）
    traj_xy : (N,2) 轨迹点，退化用（用相邻点方向差分近似航向）
    desired_speed : 期望速度序列或标量，退化时用二阶差分估 jerk
    dt : 退化差分的时间步（s）

    返回
    ----
    (jerk, steer)：两个**非负标量**。都是 `max|·|`（最激进时刻）。
    无法解析时返回 `(0.0, 0.0)` —— **中性**，不引入虚假区分度，也不冒充安全/舒适。
    """
    times = _series(frenet, 't') or None

    # ---------- J_LCV：纵向加加速度 ----------
    jerk = None
    s_ddd = _series(frenet, 's_ddd')
    if s_ddd:
        jerk = max(abs(x) for x in s_ddd)

    if jerk is None or jerk <= 0.0:
        # 退化：对期望速度做二阶差分（a 的一阶差分 = jerk）
        vs = []
        if desired_speed is not None:
            if hasattr(desired_speed, '__len__'):
                vs = [float(x) for x in desired_speed
                      if isinstance(x, (int, float)) and math.isfinite(float(x))]
            else:
                try:
                    vs = [float(desired_speed)]
                except (TypeError, ValueError):
                    vs = []
        if len(vs) >= 3:
            accs = [(vs[i] - vs[i - 1]) / dt for i in range(1, len(vs))]
            jerk = max(abs(accs[i] - accs[i - 1]) / dt for i in range(1, len(accs)))
        elif frenet is not None:
            s_dd = _series(frenet, 's_dd')
            r = _max_abs_diff_ratio(s_dd, times)
            if r is not None:
                jerk = r
    if jerk is None:
        jerk = 0.0

    # ---------- ψ_LCV：转向角速率（**不是航向角本身**） ----------
    steer = None
    yaw = _series(frenet, 'yaw')
    if len(yaw) >= 2:
        steer = _max_abs_diff_ratio(yaw, times)
        if steer is None and times is None:
            steer = max(abs(yaw[i] - yaw[i - 1]) for i in range(1, len(yaw))) / max(dt, 1e-6)
    if steer is None:
        c = _series(frenet, 'c')
        if len(c) >= 2:
            rc = _max_abs_diff_ratio(c, times)
            steer = rc if rc is not None else \
                max(abs(c[i] - c[i - 1]) for i in range(1, len(c))) / max(dt, 1e-6)
    if steer is None and traj_xy is not None:
        # 最终退化：用相邻轨迹点的方向差分近似航向，再求航向速率
        try:
            pts = [(float(a[0]), float(a[1])) for a in traj_xy]
        except Exception:
            pts = []
        if len(pts) >= 3:
            yaws = []
            for i in range(1, len(pts)):
                dx = pts[i][0] - pts[i - 1][0]
                dy = pts[i][1] - pts[i - 1][1]
                if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                    continue
                yaws.append(math.atan2(dy, dx))
            if len(yaws) >= 2:
                steer = max(abs(yaws[i] - yaws[i - 1]) for i in range(1, len(yaws))) \
                    / max(dt, 1e-6)
    if steer is None:
        steer = 0.0

    return float(jerk), float(steer)
