# -*- coding: utf-8 -*-
"""客观奖励项 —— 全部只依赖**世界状态**，不依赖任何角色分类/标志位。

## 为什么需要这个模块（PLAN §47/§48）
本会话实测两处"奖励劫持"，共同病因都是**奖励依赖了"由自车状态决定的分类"**：
1. **P1-f**：`r_thw = 10·min(2, THW_rv)`，而 `rv`（对手）由 `t_ego = arc/v` 决定
   ⇒ **减速就能把对手从分类里抹掉** ⇒ `THW=inf` ⇒ 旧代码给满分 **+20/帧**。
   （实测 `expE_p0_100`：`ep88` 连续 48 帧 +20.37 而 `rv_id` 全空、`n_vehicles=3~4`）
2. **P1-g（更严重）**：`r_gap-rate = 40·ġ`，`ġ = Δg/0.05`，而 `g_d` 取自已分类的 `(fv, rv)` 配对
   ⇒ **"对手换车"那一帧 Δg 跳 12.6 m ⇒ ġ=252 ⇒ +10102/帧**；自车停在等待位不动、
   车流不断驶过 ⇒ 配对不断切换 ⇒ **站着不动就刷分**（实测 reward 最大 +10102，P99 +3352）。

## 本模块的客观化原则（与外部文献一致）
P1 每项只依赖**可测世界量**（无角色/标志位）
P2 对世界**连续**（分类变更不跳变）
P3 **塑形项写成势函数差分** `γΦ(s')−Φ(s)`（Ng/Harada/Russell 1999：不改变最优策略）
P4 安全项**只能为负、上界 0**（安全时中性 ⇒ 不能被 farm）
P5 指标**匹配场景**：路口/汇入场景纳入 **PET**
   （专利 CN110488802B：直道跟车用 TTC、交叉口用 PET）
P6 **情境感知**（综述 Abouelazm et al. IV2024 指出的缺陷之一）
P7 量级可比 P8 奖励必须被验证（W6/W7/W8）

## 本场景口径（用户明确：**不是对向冲突，而是"左转后插入目标车流"的汇入博弈**）
因此"冲突区"= **目标车道上的汇入区（insertion zone）**，
`PET` = **自车占用汇入区的时间窗** 与 **目标车流各车占用该区的时间窗** 之间的时间间隙，
对**所有车**取最小值。**不涉及对向来车穿越。**
"""
import math
from Planning_library.vehicle_observation import vehicle_id, vehicle_size, longitudinal_acceleration

# ============================================================
# 一、客观的"最坏值"原语：对**所有车**取 min，不做任何角色分类
# ============================================================


def _veh_list(dynamic_objects):
    """把 dynamic_map.objects 归一化成 dict 列表（缺字段给安全默认）。"""
    out = []
    for v in (dynamic_objects or []):
        try:
            out.append({
                'id': vehicle_id(v),
                'x': float(v.x), 'y': float(v.y),
                'yaw': float(getattr(v, 'yaw', 0.0) or 0.0),
                'v': max(float(getattr(v, 'v', 0.0) or 0.0), 0.0),
                'vx': float(getattr(v, 'vx', 0.0) or 0.0),
                'vy': float(getattr(v, 'vy', 0.0) or 0.0),
                'acc': longitudinal_acceleration(v),
                'acc_source': getattr(v, 'acc_source', 'unavailable'),
                'length': vehicle_size(v, 'length', 4.0),
                'width': vehicle_size(v, 'width', 2.0),
            })
        except Exception:
            continue
    return out


def worst_lcttc(ego_x, ego_y, ego_yaw, ego_v, vehicles,
                horizon=2.0, dt=0.1, ego_len=4.5, ego_wid=2.0):
    """【P1 客观】`h = min_j LCTTC_j` —— 对**所有周边车**取最坏的边界碰撞时间。

    为什么必须 min over all：若只对"分类出的 rv"算，自车就能靠减速/变道把某辆车
    移出分类，从而改善奖励**而不改善世界**。对所有车取 min 后，车只要还在附近，
    它对 `h` 的贡献就还在 ⇒ **不可分类套利**。
    """
    if not vehicles:
        return float('inf'), None
    best, best_v = float('inf'), None
    for v in vehicles:
        try:
            if v['v'] <= 1e-6 and float(ego_v) <= 1e-6:
                # 两车都静止：用几何距离折算(距离/1m/s)以避免 inf/0
                d = math.hypot(v['x'] - ego_x, v['y'] - ego_y)
                lc = d
            else:
                from Planning_library.boundary_safety import lcttc_over_horizon
                lc = lcttc_over_horizon(
                    ego_x, ego_y, ego_yaw, float(ego_v),
                    v['x'], v['y'], v['yaw'], v['v'],
                    horizon=horizon, dt=dt,
                    ego_len=ego_len, ego_wid=ego_wid,
                    veh_len=v['length'], veh_wid=v['width'])['lcttc']
            if lc is not None and float(lc) < best:
                best, best_v = float(lc), v
        except Exception:
            continue
    return (best, best_v) if best_v is not None else (float('inf'), None)


def worst_proximity(ego_x, ego_y, ego_yaw, ego_v, vehicles,
                     ego_len=4.5, ego_wid=2.0):
    """【P1 客观】**恒有限**的最坏边界距离 `min_j d_AB_j`（式3 的矩形距离）。

    为什么还需要它：`LCTTC` 在两车**不接近**时按定义是 `inf`
    （`lcttc_over_horizon` 只在 `d_dot<0` 时给有限值）⇒ 单靠 LCTTC 做安全项会
    **大部分帧恒为 0**，失去区分度。而 `d_AB` 是纯几何量，**永远有限**，
    且对**所有车取 min** ⇒ 同样不可被分类套利。
    它与 LCTTC 互补：`d_AB` 管"有多近"，`LCTTC` 管"多久会撞"。
    """
    if not vehicles:
        return float('inf')
    from Planning_library.boundary_safety import boundary_metrics
    best = float('inf')
    for v in vehicles:
        try:
            d = boundary_metrics(
                ego_x, ego_y, ego_yaw, float(ego_v),
                v['x'], v['y'], v['yaw'], v['v'],
                ego_len=ego_len, ego_wid=ego_wid,
                veh_len=v['length'], veh_wid=v['width'])['d_ab']
            if d is not None and math.isfinite(float(d)) and float(d) < best:
                best = float(d)
        except Exception:
            continue
    return best


def worst_boundary_thw(ego_x, ego_y, ego_yaw, ego_v, vehicles,
                       ego_len=4.5, ego_wid=2.0):
    """【P1】`min_j THW_boundary_j` —— 用于把论文式(65) 的**输入**变成客观量。

    论文式(65) `r_thw = 10·min(2, THW_boundary_rv)` 的形式可以保留，
    但**输入**必须是对所有车取最坏值，而不是"分类出的 rv 的 THW"。
    """
    if not vehicles:
        return float('inf')
    from Planning_library.boundary_safety import boundary_metrics
    best = float('inf')
    for v in vehicles:
        try:
            thw = boundary_metrics(
                ego_x, ego_y, ego_yaw, float(ego_v),
                v['x'], v['y'], v['yaw'], v['v'],
                ego_len=ego_len, ego_wid=ego_wid,
                veh_len=v['length'], veh_wid=v['width'])['thw_boundary']
            if thw is not None and math.isfinite(float(thw)) and float(thw) < best:
                best = float(thw)
        except Exception:
            continue
    return best


# ============================================================
# 二、安全项：只能为负、上界 0（P4）
# ============================================================

def penalty_from_margin(value, th, w=1.0):
    """通用"余量型"惩罚：`value >= th ⇒ 0`；`value → 0 ⇒ −w`；**恒 ≤ 0**。

    形状：`−w·[max(0, 1 − value/th)]²`
      · 上界 **0**（安全时中性 ⇒ **不能被 farm**，这是 P1-f 的教训）
      · 下界 **−w**（`value → 0` 时），且随 `value` 单调
      · 在 `value` 上**连续**（P2），无跳变
    `value` 必须是非负的"余量/间隙"（LCTTC、PET、d_AB…），`th` 是阈值。
    """
    try:
        v = float(value)
        t = float(th)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(v):
        return 0.0                       # 无对手/无定义 ⇒ 中性，不给分也不罚
    if t <= 0.0 or v >= t:
        return 0.0
    r = 1.0 - v / t
    return -float(w) * r * r


def r_safe(h, h_th=2.0, w=1.0):
    """【P4/P5】安全项 = 对"最坏 LCTTC"的余量惩罚。只能为负、上界 0。"""
    return penalty_from_margin(h, h_th, w)


# ============================================================
# 三、汇入区的 PET（Post-Encroachment Time）—— 路口/汇入场景的正确指标
# ============================================================

def occupancy_interval(t_enter, v, length, band_width):
    """由"进入时刻 / 速度 / 车身长 / 区宽"给出占用时间窗 `[enter, leave]`。"""
    try:
        t0 = float(t_enter)
        vv = max(float(v), 0.5)
        span = (float(length) + float(band_width)) / vv
    except (TypeError, ValueError):
        return None
    if not math.isfinite(t0):
        return None
    return (t0, t0 + span)


def pet_to_stream(ego_interval, veh_intervals):
    """【P5 客观】汇入区 PET = 自车占用窗与**各车**占用窗之间的时间间隙，对**所有车取 min**。

    两窗不重叠时的间隙：`max(t_v_enter − t_ego_leave, t_ego_enter − t_v_leave)`
      · > 0 ⇒ 二者先后通过，余量即该值
      · ≤ 0 ⇒ **两窗重叠**（= 会同时占用汇入区）⇒ 冲突
    `min_j` ⇒ 任何一辆车构成冲突都会被反映，**不可靠分类抹掉**。
    """
    if ego_interval is None or not veh_intervals:
        return float('inf')
    e0, e1 = ego_interval
    best = float('inf')
    for iv in veh_intervals:
        if iv is None:
            continue
        v0, v1 = iv
        gap = max(v0 - e1, e0 - v1)
        if gap < best:
            best = gap
    return best


def r_pet(pet, pet_th=3.0, w=1.0):
    """PET 惩罚：`PET >= th ⇒ 0`；`PET → 0 或为负 ⇒ 越来越负`。恒 ≤ 0。

    为负（两窗重叠）时用**线性**延伸，避免平方在小负值处过早饱和：
    实际用 `penalty_from_margin`，并把负值按 0 处理后再叠加线性越界项。
    """
    try:
        p = float(pet)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(p):
        return 0.0
    if p >= 0.0:
        return penalty_from_margin(p, pet_th, w)
    # 重叠（p<0）：基底 −w 再按重叠深度线性加重，上界仍为 0
    return -float(w) * (1.0 + min(2.0, abs(p) / max(float(pet_th), 1e-6)))


# ============================================================
# 四、潜在函数塑形（P3）：γΦ(s') − Φ(s)
# ============================================================

def pbrs(phi_next, phi, gamma=0.99):
    """势函数差分塑形 `γΦ(s') − Φ(s)`。

    经典结论（Ng, Harada & Russell, 1999）：把它加到任意 MDP 的奖励上，
    **最优策略不变**（回合内求和望远镜化为 `γ^T Φ(s_T) − Φ(s_0)`，只依赖端点）。
    ⇒ **凡是"塑形"（引导探索）的项，都必须写成这个形式**，
      否则它**改变最优策略**，必然能造出人工最优（这正是 `r_gap-rate` 的病根）。
    """
    try:
        pn = float(phi_next)
        p = float(phi)
    except (TypeError, ValueError):
        return 0.0
    if not (math.isfinite(pn) and math.isfinite(p)):
        return 0.0
    return float(gamma) * pn - p
