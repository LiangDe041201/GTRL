"""Soft continuation values with a matching deterministic takeover objective."""
import math

import numpy as np

from Planning_library.candidate_learning_v19 import CandidateLearner
from Planning_library.soft_bellman import information_cost,soft_value_policy


def regularized_bounds(stats,prior,alpha):
    """Q excludes the current policy cost; V(next) already includes future costs.

    A deterministic request has KL(delta_a || prior) = -log(prior[a]).
    Shift both ends by this known cost. Do not subtract it from observed rewards
    or from Q backups: doing that would charge future costs twice.
    """
    return {a:dict(wcv=s['wcv']+alpha*math.log(prior[a]),
                   bcv=s['bcv']+alpha*math.log(prior[a]),
                   information_cost=-alpha*math.log(prior[a]))
            for a,s in stats.items()}


class CandidateLearnerV20(CandidateLearner):
    SCHEMA='executable_candidate_soft_v20'

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self._checkpoint_keys=frozenset(self.nodes)

    def signature(self):
        return dict(super().signature(),
            selection='regularized_wcv' if self.trust_enabled else 'soft_policy_argmax',
            action_semantics='cg_default_or_guard_accepted_alternative_v20',
            current_cost='onehot_KL_at_selection_only',
            candidate_eligibility='same_frame_common_guard_proposal_acceptance')

    def state(self,*args):
        key=super().state(*args)
        if self.phase=='eval':self._unseen=key not in self._checkpoint_keys
        return key

    def select(self,explore_action=None,trust_enabled=None,rng=None,epsilon=0.):
        if self.current is None or not 0.<=epsilon<=1.:
            raise ValueError('Begin decision and provide a valid exploration probability')
        rng=np.random if rng is None else rng
        node,q=self.nodes[self.current],self.q[self.current]
        rule,allowed,prior=node['rule'],node['allowed'],node['prior']
        value,optimum=soft_value_policy(q,prior,self.alpha)
        stats=self.confidence(self.current)
        net=regularized_bounds(stats,prior,self.alpha)
        enabled=self.trust_enabled if trust_enabled is None else bool(trust_enabled)
        certified=[a for a in allowed if a!=rule and stats[a]['n']>=self.min_episodes
            and stats[rule]['n']>=self.min_episodes and net[a]['wcv']>net[rule]['bcv']]
        greedy=max(certified,key=lambda a:net[a]['wcv']) if certified and enabled else rule
        if not enabled and not self._unseen:greedy=max(allowed,key=lambda a:optimum[a])
        if self.phase=='eval':epsilon=0.
        counts={a:len({r['episode'] for r in self.edges.get((self.current,a),[])}) for a in allowed}
        least=[a for a in allowed if counts[a]==min(counts.values())]
        if self.phase=='train' and epsilon>0. and len(allowed)>1 and min(counts.values())<self.min_episodes:
            epsilon=max(epsilon,.5)
        policy=np.zeros(2);policy[greedy]=1.-epsilon
        policy[least]+=epsilon/len(least)
        source='takeover' if greedy!=rule else 'cg'
        if explore_action is not None:
            if self.phase=='eval' or int(explore_action) not in allowed:
                raise ValueError('Exploration is forbidden in eval/outside executable alternatives')
            action=int(explore_action);policy[:]=0.;policy[action]=1.;source='explore'
        elif epsilon and rng.random_sample()<epsilon:
            action=int(rng.choice(least));source='explore'
        else:action=int(greedy)
        self.choice=action
        finite=lambda groups:{a:{k:(v if math.isfinite(v) else None) for k,v in s.items()}
                              for a,s in groups.items()}
        self.last=dict(source=source,selection_rule='regularized_wcv' if enabled else 'soft_policy_argmax',
            certified=certified,behavior_policy=policy.tolist(),baseline_policy=list(prior),
            soft_policy=optimum.tolist(),information_cost=information_cost(policy,prior,self.alpha),
            soft_information_cost=information_cost(optimum,prior,self.alpha),soft_value=float(value),
            q=q.tolist(),samples=counts,unseen_state=self._unseen,epsilon=epsilon,
            confidence_kind='episode_clustered_bootstrap_heuristic',range_mode=self.confidence_range,
            range_used=self._range_used,known_return_range=self.range_fallback,confidence_guarantee=False,
            bounds=finite(stats),regularized_bounds=finite(net))
        return action,[net[a]['bcv'] if a==rule else net[a]['wcv'] if a in net else -1e9
                       for a in range(2)]
