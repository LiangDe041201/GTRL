"""Public motion hypotheses, not access to the traffic manager's decisions.

CV/observed acceleration remain possible. Immediate and 1s-delayed recovery
cover an unobserved return to the declared cruise, bounded by 2 m/s^2. This
finite family is uncalibrated and is not a probabilistic safety guarantee.
"""
import math
import numpy as np

from Planning_library.vehicle_observation import longitudinal_acceleration
from Planning_library.paper_turn_control import motion


def tracks(vehicle, times, cruise=4.412022451715821, recovery=True):
    times = np.asarray(times, dtype=float)
    if times.ndim != 1 or not np.isfinite(times).all() or np.any(np.diff(times) < 0.) or np.any(times < 0.):
        raise ValueError('Invalid forecast times')
    vx, vy = motion(vehicle)
    speed = math.hypot(vx, vy)
    ux, uy = (vx/speed, vy/speed) if speed > .05 else (math.cos(vehicle.yaw), math.sin(vehicle.yaw))
    observed = longitudinal_acceleration(vehicle)
    observed = 0. if observed is None else max(-3., min(2., observed))
    family = []
    for acceleration, delay in [(0., None), (observed, None)] + ([(0., 0.), (observed, 1.)] if recovery else []):
        positions = []
        for t in times:
            active = min(float(t), 1. if delay is None else delay)
            if acceleration < 0.:
                active = min(active, speed/-acceleration)
            v = max(0., speed+acceleration*active)
            distance = speed*active+.5*acceleration*active**2
            remaining = float(t)-active
            if delay is not None and t >= delay:
                duration = min(max(0., remaining), max(0., cruise-v)/2.)
                distance += v*duration+duration**2
                distance += (v+2.*duration)*(remaining-duration)
            else:
                distance += v*remaining
            positions.append((vehicle.x+ux*distance, vehicle.y+uy*distance, vehicle.yaw))
        family.append(np.asarray(positions))
    return family
