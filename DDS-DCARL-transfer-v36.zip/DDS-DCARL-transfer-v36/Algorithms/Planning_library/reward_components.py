#!/usr/bin/env python3
"""
RL 奖励组件（纯函数，无 CARLA 依赖，离线可对拍）。

阶段 1 修订（④ 边界安全对齐论文式 65）：
  论文式 65：r_thw = 10·min(2.0, THW_boundary)
  —— 安全主体信号用 **THW_boundary**（边界时间间隔 d_AB/v），而非 LCTTC。
  （此前误用 LCTTC，经论文 Word 原稿核对后修正。）

保留旧判定的定性语义：
  - committed     已越过冲突点 -> 0（过了不再罚）
  - 无交叉车辆                  -> +2
  - 停止线外安全让行等待         -> +5
  - 主体：r = 10·min(2.0, THW_boundary_rv)（安全裕度，0..20，越足越安全）
  - 危险兜底：LCTTC = min(lcttc_rv, lcttc_fv) < 阈值 -> 线性负惩罚（引导避险）
"""
import math


#: 【P1-f 默认】无 RV（THW 非有限）时安全项是否中性(0)。False = 旧口径(=thw_cap，奖励劫持源)
MISSING_THW_NEUTRAL = True


def boundary_safety_reward(lcttc_rv, lcttc_fv, thw_boundary_rv,
                           committed, n_vehicles, yield_wait=False,
                           lcttc_danger=1.0, max_penalty=-60.0,
                           no_vehicle_bonus=0.0, yield_wait_bonus=0.0,
                           thw_scale=10.0, thw_cap=2.0,
                           missing_thw_neutral=MISSING_THW_NEUTRAL):
    """
    由二维边界度量计算安全奖励（标量）。

    判定顺序：
      1. committed     已越过冲突点        -> 0.0
      2. n_vehicles<=0 无交叉车辆          -> +no_vehicle_bonus（默认 0.0）
      3. 主体（论文式 65）：r = thw_scale·min(thw_cap, THW_boundary_rv)
      4. yield_wait    停止线外安全让行等待 -> **追加** +yield_wait_bonus
      5. 危险兜底：LCTTC=min(rv,fv) < lcttc_danger -> 再追加线性负惩罚
         （LCTTC 越接近 0 越危险，最大 max_penalty）

    ⚠【P1-f 奖励劫持修复，2026-09-17】两个"停下来就白拿奖励"的洞：
      (a) `THW_boundary_rv` 非有限（= 自车 `t_ego` 过大，所有交叉车都被判成
          "已先通过"的 FV，于是 rv 角色为空 → THW=inf）时，旧代码走
          `thw = thw_cap` → **+20/帧**，即"没有对手"被当成"最安全"给了满分。
          而自车**减速就能制造**这个状态（t_ego = arc/v → v↓ ⇒ t_ego↑）：
          实测（2026 重验 `expE_p0_100/interaction_ego.csv`，从原始日志复现）：
            · `ep78` **连续 30 帧** reward 中位 **+20.449**，`v 0.63~1.15 m/s`，`arc` 中位 14.30
            · `ep88` **连续 48 帧** reward 中位 **+20.374**，`v 0.53~1.36 m/s`，`arc` 中位 16.34，
              且该回合 `rv_id` 非空的帧数 = **0**、`thw_boundary_rv` 全空，而 **`n_vehicles`=3~4**
            · 全 100 回合：`thw` 为空 n=2471 reward 中位 **+5.03**；`thw` 有值 n=10223 中位 **−37.70**
              ⇒ "让对手消失"值 **+42.7 分**
          回归用例见 tests/test_reward_components.py::test_no_rv_farming_regression。
          ⚠️ 本注释早期版本写"第 4 回合、连续 150 帧、arc≈12.26、+20.41"，
             该组数字**无法从该 artifact 复现**，已作废（2026 重验）。
          修复：非有限 THW ⇒ **中性 0**（没有边界要维持，就不该给安全分）。
          旧口径可用 missing_thw_neutral=False 复现（DSH_MISSING_THW=cap）。
      (b) 旧的 `yield_wait` 是**提前 return**，会顺带跳过第 5 步的危险惩罚
          —— 即"只要我足够慢，逼近的危险就不罚"。改为追加项，危险惩罚不再被绕过。
      (c) `no_vehicle_bonus` 旧值 +2/帧（空路口也是正收益）→ 默认 0.0。
    """
    if committed:
        return 0.0
    if n_vehicles <= 0:
        return float(no_vehicle_bonus)

    # 主体：论文式 65（THW_boundary 是主要安全信号）
    thw = float('inf') if thw_boundary_rv is None else float(thw_boundary_rv)
    if math.isfinite(thw):
        r = thw_scale * min(thw_cap, max(0.0, thw))
    elif missing_thw_neutral:
        r = 0.0                                  # 【P1-f(a)】无 RV ⇒ 安全项中性
    else:
        r = thw_scale * thw_cap                  # 旧口径（+20/帧，奖励劫持源）

    # 【P1-f(b)】等待补偿改为追加项，不再短路掉下面的危险惩罚
    if yield_wait:
        r += float(yield_wait_bonus)

    # 危险兜底：LCTTC（rv/fv 最危险侧）极小 -> 线性负惩罚
    lcttc = min(float(lcttc_rv), float(lcttc_fv))
    if math.isfinite(lcttc) and lcttc < lcttc_danger:
        r += max_penalty * (1.0 - lcttc / max(lcttc_danger, 1e-6))
    return r
