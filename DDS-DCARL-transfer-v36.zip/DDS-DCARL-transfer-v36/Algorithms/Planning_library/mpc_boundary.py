"""CasADi form of boundary_metrics' rectangle THW for MPC decision states.

The geometry and 'conn' velocity projection follow boundary_safety.py. Opponent
motion is supplied by the caller; ego pose and speed remain symbolic so that
the boundary cost can influence the optimized trajectory. This does not add
an opponent action or a second game-equilibrium solver.
"""
import casadi as ca


def _corners(x, y, yaw, length, width):
    c, s = ca.cos(yaw), ca.sin(yaw)
    return [(x + dx * c - dy * s, y + dx * s + dy * c)
            for dx, dy in ((-length / 2, -width / 2),
                           (length / 2, -width / 2),
                           (length / 2, width / 2),
                           (-length / 2, width / 2))]


def _projection(point, start, end):
    vx, vy = end[0] - start[0], end[1] - start[1]
    t = ((point[0] - start[0]) * vx + (point[1] - start[1]) * vy)
    t = ca.fmin(1., ca.fmax(0., t / ca.fmax(vx * vx + vy * vy, 1e-12)))
    return start[0] + t * vx, start[1] + t * vy


def boundary_thw(ego_x, ego_y, ego_yaw, ego_v, veh_x, veh_y, veh_yaw,
                 ego_len=4.5, ego_wid=2., veh_len=4., veh_wid=2.):
    """Exact rectangle separation and nearest-point THW, piecewise differentiable.

    Overlap/contact gives THW=0, as in boundary_metrics. Away from contact,
    project ego velocity onto the nearest-point connection; nonpositive
    projections fall back to distance / ego speed. Small denominator guards
    keep inactive branches finite for automatic differentiation at standstill.
    """
    ego = _corners(ego_x, ego_y, ego_yaw, ego_len, ego_wid)
    veh = _corners(veh_x, veh_y, veh_yaw, veh_len, veh_wid)

    # A separating axis exists exactly when the rectangles do not intersect.
    separation = None
    for yaw in (ego_yaw, veh_yaw):
        for nx, ny in ((ca.cos(yaw), ca.sin(yaw)), (-ca.sin(yaw), ca.cos(yaw))):
            ea = [x * nx + y * ny for x, y in ego]
            va = [x * nx + y * ny for x, y in veh]
            emin, emax, vmin, vmax = ea[0], ea[0], va[0], va[0]
            for i in range(1, 4):
                emin, emax = ca.fmin(emin, ea[i]), ca.fmax(emax, ea[i])
                vmin, vmax = ca.fmin(vmin, va[i]), ca.fmax(vmax, va[i])
            gap = ca.fmax(vmin - emax, emin - vmax)
            separation = gap if separation is None else ca.fmax(separation, gap)

    # Preserve the numerical helper's traversal and tie-breaking order.
    best_sq = best_dx = best_dy = None
    for edges, points, direction in ((ego, veh, 1.), (veh, ego, -1.)):
        for i in range(4):
            for point in points:
                nearest = _projection(point, edges[i], edges[(i + 1) % 4])
                dx, dy = direction * (point[0] - nearest[0]), direction * (point[1] - nearest[1])
                sq = dx * dx + dy * dy
                if best_sq is None:
                    best_sq, best_dx, best_dy = sq, dx, dy
                else:
                    closer = sq < best_sq
                    best_dx = ca.if_else(closer, dx, best_dx)
                    best_dy = ca.if_else(closer, dy, best_dy)
                    best_sq = ca.fmin(best_sq, sq)

    distance = ca.sqrt(ca.fmax(best_sq, 1e-12))
    closing_speed = ego_v * (ca.cos(ego_yaw) * best_dx + ca.sin(ego_yaw) * best_dy) / distance
    denominator = ca.if_else(closing_speed > 1e-6,
                             ca.fmax(closing_speed, 1e-6), ca.fmax(ego_v, 1e-3))
    return ca.if_else(separation > 0., distance / denominator, 0.)
