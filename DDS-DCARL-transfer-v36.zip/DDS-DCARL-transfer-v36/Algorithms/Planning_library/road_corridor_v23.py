"""Sampled body membership in public map driving lanes of the task route.

This is an additional proposal constraint, not a road-mesh safety proof.
Membership never projects offroad points onto nearby roads. Unknown map data
rejects the new proposal; the frozen CG baseline is not rewritten.
"""
from collections import OrderedDict
import hashlib
import math
import struct
import numpy as np

from Planning_library.control_path_v15 import path_hash
from Planning_library.forecast_v16 import clean_points


class RoadCorridor:
    def __init__(self, lookup, allowed_lanes, metadata=None):
        self.lookup = lookup
        self.allowed = frozenset(tuple(int(i) for i in lane) for lane in allowed_lanes)
        if not self.allowed:
            raise ValueError('No public task-route driving lanes were observed')
        self.cache = OrderedDict()
        self.metadata = dict(metadata or {}, revision='public_road_corridor_v23',
            allowed_lanes=[list(x) for x in sorted(self.allowed)], project_to_road=False,
            margin_m=.15, body_sample_spacing_m=.75, pose_spacing_m=.3,
            heading_spacing_rad=.08, guarantee=False)

    @classmethod
    def from_carla(cls, road_map, location_factory, driving_type, reference, z):
        def lookup(x, y):
            wp = road_map.get_waypoint(location_factory(x=float(x), y=float(y), z=float(z)),
                                      project_to_road=False, lane_type=driving_type)
            return None if wp is None else (int(wp.road_id), int(wp.section_id), int(wp.lane_id))
        points = clean_points(reference)
        arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
        samples = np.linspace(0., arc[-1], int(math.ceil(arc[-1]/.5))+1)
        allowed = set()
        missing = 0
        for s in samples:
            lane = lookup(np.interp(s, arc, points[:, 0]), np.interp(s, arc, points[:, 1]))
            if lane is None:
                missing += 1
            else:
                allowed.add(lane)
        return cls(lookup, allowed, dict(source='carla_map_get_waypoint', reference_hash=path_hash(points),
                   route_samples=len(samples), missing_route_samples=missing, map_query_z=float(z)))

    def _query(self, x, y):
        key = (float(x), float(y))
        if key in self.cache:
            result = self.cache.pop(key)
            self.cache[key] = result
            return result
        try:
            lane = self.lookup(*key)
            result = (lane, None)
        except Exception:
            result = (None, 'map_query_error')
        self.cache[key] = result
        if len(self.cache) > 30000:
            self.cache.popitem(last=False)
        return result

    @staticmethod
    def dense(poses):
        p = np.asarray(poses, dtype=float)
        if p.ndim != 2 or p.shape[1] != 3 or not len(p) or not np.isfinite(p).all():
            raise ValueError('Finite x/y/yaw poses are required')
        result = [p[0]]
        for a, b in zip(p, p[1:]):
            angle = math.atan2(math.sin(b[2]-a[2]), math.cos(b[2]-a[2]))
            n = max(1, int(math.ceil(np.linalg.norm(b[:2]-a[:2])/.3)), int(math.ceil(abs(angle)/.08)))
            if n > 200:
                raise ValueError('Discontinuous or implausibly sparse path')
            for t in np.linspace(0., 1., n+1)[1:]:
                result.append([a[0]+t*(b[0]-a[0]), a[1]+t*(b[1]-a[1]), a[2]+t*angle])
        return np.asarray(result)

    def audit(self, poses, length, width):
        count, digest = 0, hashlib.sha256()
        result = dict(accepted=False, complete=False, checked_points=0,
                      witness_hash=None, reason=None, first_rejection=None)
        try:
            if not all(math.isfinite(v) and v > 0. for v in (length, width)):
                raise ValueError('Invalid vehicle box')
            poses = self.dense(poses)
            half_length, half_width = length/2.+.15, width/2.+.15
            u = np.linspace(-half_length, half_length, int(math.ceil(2*half_length/.75))+1)
            v = np.linspace(-half_width, half_width, int(math.ceil(2*half_width/.75))+1)
            box = np.array([(x, y) for x in u for y in v]+[(0., 0.)])
            for x, y, yaw in poses:
                c, s = math.cos(yaw), math.sin(yaw)
                world = box.dot(np.array([[c, s], [-s, c]]))+[x, y]
                for px, py in world:
                    lane, error = self._query(px, py)
                    count += 1
                    reason = error or ('outside_driving_surface' if lane is None else
                                       'outside_task_route_lanes' if tuple(lane) not in self.allowed else None)
                    digest.update(struct.pack('<dd?', px, py, reason is None))
                    if reason is not None:
                        result.update(reason=reason, first_rejection=dict(x=float(px), y=float(py),
                            lane=None if lane is None else list(lane)))
                        return dict(result, checked_points=count, witness_hash=digest.hexdigest())
            result.update(accepted=True, complete=True)
        except (TypeError, ValueError, OverflowError):
            result['reason'] = 'invalid_geometry'
        result.update(checked_points=count, witness_hash=digest.hexdigest())
        return result
