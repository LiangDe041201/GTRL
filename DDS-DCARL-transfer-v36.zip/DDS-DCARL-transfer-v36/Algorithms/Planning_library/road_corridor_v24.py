"""Public route lanes outside junctions, connected junction driving surface inside.

No nearest-road projection, hard-coded Town03 lane IDs, or collision immunity.
Only junction IDs actually traversed by the public route are admissible.
This sampled map constraint is not a continuous road-mesh safety guarantee.
"""
from collections import OrderedDict
import hashlib
import math
from pathlib import Path
import struct
import time
import numpy as np
from Planning_library.control_path_v15 import path_hash
from Planning_library.forecast_v16 import clean_points
from Planning_library.road_corridor_v23 import RoadCorridor


class RoadCorridorV24:
    def __init__(self,lookup,lanes,junctions,metadata=None):
        self.lookup=lookup
        self.allowed=frozenset(tuple(map(int,v)) for v in lanes)
        self.junctions=frozenset(int(v) for v in junctions)
        if not self.allowed: raise ValueError('No observed route driving lanes')
        self.cache=OrderedDict()
        self.statistics=dict(map_queries=0,map_cache_hits=0,map_query_ms=0.,audit_calls=0)
        self.metadata=dict(metadata or {},revision='route_junction_corridor_v24',
            route_lanes=[list(v) for v in sorted(self.allowed)],route_junctions=sorted(self.junctions),
            project_to_road=False,margin_m=.15,body_sample_spacing_m=.75,
            pose_spacing_m=.3,heading_spacing_rad=.08,guarantee=False)

    @classmethod
    def from_carla(cls,road_map,location_factory,driving_type,reference,z,directory=None):
        def lookup(x,y):
            wp=road_map.get_waypoint(location_factory(x=float(x),y=float(y),z=float(z)),
                                     project_to_road=False,lane_type=driving_type)
            if wp is None: return None
            junction=wp.get_junction() if wp.is_junction else None
            return dict(lane=[int(wp.road_id),int(wp.section_id),int(wp.lane_id)],
                junction=None if junction is None else int(junction.id),
                is_junction=bool(wp.is_junction),width=float(wp.lane_width))
        points=clean_points(reference)
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
        samples=np.linspace(0.,arc[-1],int(math.ceil(arc[-1]/.5))+1)
        lanes,junctions,missing=set(),set(),0
        for s in samples:
            value=lookup(np.interp(s,arc,points[:,0]),np.interp(s,arc,points[:,1]))
            if value is None: missing+=1; continue
            lanes.add(tuple(value['lane']))
            if value['junction'] is not None: junctions.add(value['junction'])
        meta=dict(source='carla_public_route_and_junction',map_name=str(getattr(road_map,'name','unknown')),
            reference_hash=path_hash(points),route_samples=len(samples),missing_route_samples=missing,map_query_z=float(z))
        if directory is not None:
            target=Path(directory)/'public_map_v24.xodr'
            target.parent.mkdir(parents=True,exist_ok=True)
            data=road_map.to_opendrive().encode('utf8')
            target.write_bytes(data)
            meta['opendrive_sha256']=hashlib.sha256(data).hexdigest()
        return cls(lookup,lanes,junctions,meta)

    def _query(self,x,y):
        key=(float(x),float(y))
        if key in self.cache:
            self.statistics['map_cache_hits']+=1
            value=self.cache.pop(key); self.cache[key]=value
            return value
        started=time.perf_counter()
        try: value=(self.lookup(*key),None)
        except Exception: value=(None,'map_query_error')
        self.statistics['map_queries']+=1
        self.statistics['map_query_ms']+=(time.perf_counter()-started)*1000.
        self.cache[key]=value
        if len(self.cache)>30000: self.cache.popitem(last=False)
        return value

    def audit(self,poses,length,width):
        self.statistics['audit_calls']+=1
        result=dict(accepted=False,complete=False,checked_points=0,witness_hash=None,
                    reason=None,first_rejection=None,accepted_junction_points=0)
        digest,count,junction_points=hashlib.sha256(),0,0
        try:
            if not all(math.isfinite(v) and v>0. for v in (length,width)): raise ValueError('Invalid body')
            poses=RoadCorridor.dense(poses)
            hl,hw=length/2.+.15,width/2.+.15
            u=np.linspace(-hl,hl,int(math.ceil(2*hl/.75))+1)
            v=np.linspace(-hw,hw,int(math.ceil(2*hw/.75))+1)
            box=np.array([(x,y) for x in u for y in v]+[(0.,0.)])
            for x,y,yaw in poses:
                c,s=math.cos(yaw),math.sin(yaw)
                for px,py in box.dot(np.array([[c,s],[-s,c]]))+[x,y]:
                    point,error=self._query(px,py)
                    on_route=point is not None and tuple(point['lane']) in self.allowed
                    in_junction=bool(point is not None and point['is_junction']
                                     and point['junction'] in self.junctions)
                    reason=error or ('outside_driving_surface' if point is None else
                                    'outside_task_corridor' if not (on_route or in_junction) else None)
                    count+=1; junction_points+=int(in_junction and not on_route and reason is None)
                    digest.update(struct.pack('<dd?',px,py,reason is None))
                    if reason:
                        result.update(reason=reason,first_rejection=dict(x=float(px),y=float(py),
                            lane=None if point is None else point['lane'],
                            junction=None if point is None else point['junction'],
                            is_junction=False if point is None else point['is_junction'],
                            lane_width=None if point is None else point['width']))
                        return dict(result,checked_points=count,witness_hash=digest.hexdigest(),
                                    accepted_junction_points=junction_points)
            result.update(accepted=True,complete=True)
        except (TypeError,ValueError,OverflowError,KeyError): result['reason']='invalid_geometry'
        return dict(result,checked_points=count,witness_hash=digest.hexdigest(),accepted_junction_points=junction_points)
