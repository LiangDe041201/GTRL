"""Opt-in CG-baseline learning over the unchanged six rolling trajectories."""
from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
from Planning_library.rolling_planner_v24 import RollingPlannerV24


class CGTrajectoryPlannerV29(RollingPlannerV24):
    LEARNER_CLASS=CGTrajectoryLearnerV29
    LEARNER_METADATA=dict(learner_revision='cg_trajectory_learning_v29',
        baseline_action=0,reference_policy='uniform_admissible_v29')

    @staticmethod
    def default_action(allowed,costs):
        if 0 not in allowed:raise ValueError('CG action 0 must remain the comparison baseline')
        return 0

    def propose(self,*args,**kwargs):
        output=super().propose(*args,**kwargs)
        self.last.update(self.LEARNER_METADATA)
        return output


def select_rolling_planner(learner_revision,efe_mode='off'):
    if learner_revision not in ('legacy_v24','cg_v29','longitudinal_v31','joint_v32','select_first_v33',
                                'paired_v34','entry_v35','reward_v36') or efe_mode not in ('off','shadow'):
        raise ValueError('Unknown rolling learner or EFE mode')
    if learner_revision=='reward_v36':
        if efe_mode!='off': raise ValueError('v36 reward comparison requires EFE disabled')
        from Planning_library.reward_planner_v36 import RewardPlannerV36
        return RewardPlannerV36
    if learner_revision=='entry_v35':
        if efe_mode!='off': raise ValueError('v35 entry comparison requires EFE disabled')
        from Planning_library.entry_planner_v35 import EntryPlannerV35
        return EntryPlannerV35
    if learner_revision=='paired_v34':
        if efe_mode!='off': raise ValueError('v34 paired exploration requires EFE disabled')
        from Planning_library.paired_planner_v34 import PairedPlannerV34
        return PairedPlannerV34
    if learner_revision=='select_first_v33':
        if efe_mode!='off': raise ValueError('v33 select-first comparison requires EFE disabled')
        from Planning_library.select_first_planner_v33 import SelectFirstPlannerV33
        return SelectFirstPlannerV33
    if learner_revision=='joint_v32':
        if efe_mode!='off': raise ValueError('v32 joint comparison requires EFE disabled')
        from Planning_library.joint_planner_v32 import JointPlannerV32
        return JointPlannerV32
    if learner_revision=='longitudinal_v31':
        if efe_mode!='off':raise ValueError('v31 longitudinal comparison requires EFE disabled')
        from Planning_library.longitudinal_planner_v31 import LongitudinalPlannerV31
        return LongitudinalPlannerV31
    if learner_revision=='cg_v29':
        if efe_mode!='off':raise ValueError('v29 CG/GTRL comparison requires EFE disabled')
        return CGTrajectoryPlannerV29
    if efe_mode=='shadow':
        from Planning_library.rolling_shadow_v27 import RollingShadowPlannerV27
        return RollingShadowPlannerV27
    return RollingPlannerV24
