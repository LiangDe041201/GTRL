"""Separate a reversible approach step from a complete merge."""
from Planning_library.longitudinal_planner_v31 import entry_times
from Planning_library.paired_planner_v34 import PairedLearnerV34, PairedPlannerV34
from Planning_library.vehicle_observation import vehicle_size


MERGE_HORIZON = 8.
CREEP_SPEED = .5
STOP_RESERVE = .15
STOP_SPEED = .05


def _gap_ok(parts):
    return len(parts) == 2 and all(p['admissible'] and
                                  (p['min_gap'] is None or p['min_gap'] >= .2) for p in parts)


def merge_qualified(forecasts, parts, length, width, band_half):
    crossings = [list(entry_times(states, times, length, width, band_half))
                 for states, times, _ in forecasts]
    return (len(crossings) == 2 and _gap_ok(parts) and
            all(enter is not None and clear is not None for enter, clear in crossings)), crossings


def creep_witness(forecasts, length, width, band_half):
    traces = []
    for states, times, diag in forecasts:
        enter, _ = entry_times(states, times, length, width, band_half)
        traces.append(dict(entered_at=enter, valid=diag['valid'],
                           min_standoff=diag['min_standoff'], end_speed=diag['end_speed']))
    accepted = len(traces) == 2 and all(t['entered_at'] is None and t['valid']
        and t['min_standoff'] >= STOP_RESERVE and t['end_speed'] <= STOP_SPEED for t in traces)
    return dict(accepted=accepted, forecasts=traces)


class EntryLearnerV35(PairedLearnerV34):
    SCHEMA = 'cg_joint_reversible_entry_v35'
    ACTION_PAIRS = PairedLearnerV34.ACTION_PAIRS + ((None, CREEP_SPEED),)
    ACTION_NAMES = PairedLearnerV34.ACTION_NAMES + ('path_cg_creep_then_stop',)


class EntryPlannerV35(PairedPlannerV34):
    LEARNER_CLASS = EntryLearnerV35
    CREEP_ACTION = len(EntryLearnerV35.ACTION_NAMES) - 1
    LEARNER_METADATA = dict(PairedPlannerV34.LEARNER_METADATA,
        learner_revision=EntryLearnerV35.SCHEMA,
        joint_action_pairs=[list(pair) for pair in EntryLearnerV35.ACTION_PAIRS],
        entry_audit='reversible_prefix_or_clearance_v35')

    def _generate(self,ego,seed,target):
        super()._generate(ego,seed,target)
        self.profiles[self.CREEP_ACTION] = dict(path=self._joint_path)

    def _candidate_target(self,action,cg_target):
        if action == self.CREEP_ACTION:
            if self.intent == 0 and cg_target <= .01 and self._speed_cap >= CREEP_SPEED:
                return CREEP_SPEED
            return None
        return super()._candidate_target(action,cg_target)

    def _screen_intent(self,speed,action):
        if action == self.CREEP_ACTION:
            return 'defer'
        return super()._screen_intent(speed,action)

    def _qualify(self,candidate,description,action,ego,objects,forecasts):
        offset, speed = self.LEARNER_CLASS.ACTION_PAIRS[action]
        description.update(lateral_offset_m=offset, speed_option_mps=speed)
        half_width = max([vehicle_size(v,'width',1.97) for v in objects] or [1.97])/2.
        if action == self.CREEP_ACTION:
            witness = creep_witness(forecasts,self.length,self.width,half_width)
            description['entry_review'] = dict(mode='creep', prefix_s=self.period, **witness)
            description['eligible'] = bool(description['eligible'] and
                _gap_ok(description['components']) and witness['accepted'])
            candidate.update(entry_intent=0, creep_stop_after=self.period)
            return
        if self.intent != 0 or speed is None:
            return
        candidate['entry_intent'] = 1
        qualifies, crossings = merge_qualified(forecasts,description['components'],
                                              self.length,self.width,half_width)
        description.update(intent='proceed', crossings=crossings,
                           eligible=bool(description['eligible'] and qualifies))

    def _audit_candidate(self,c,action,dynamic,seed,cg):
        if action == self.CREEP_ACTION:
            return super()._audit_candidate(c,action,dynamic,seed,cg,stop_after=self.period)
        result = super()._audit_candidate(c,action,dynamic,seed,cg)
        if 'crossings' in result:
            # An already unsafe forecast cannot be rescued by looking further.
            crossings = result['crossings']
            common_ok = (result['execution']['accepted'] and _gap_ok(result['components'])
                         and all(r['accepted'] for r in result['road_predictions']))
            extend = (not result['eligible'] and common_ok
                      and any(enter is not None for enter, _ in crossings))
            if extend:
                result = super()._audit_candidate(c,action,dynamic,seed,cg,horizon=MERGE_HORIZON)
            result['entry_review'] = dict(mode='merge', horizon_s=MERGE_HORIZON if extend else 6.)
        return result
