#!/usr/bin/env python3
"""
左转场景保留的离散 Cournot 效用接口（无需 CARLA）。

v6 默认控制路径为 cournot_mpc.py 的连续效用，直接进入 MPC。
本文件的 wait/go × rush/yield 支付表用于 discrete 对照模式及历史诊断，
不是默认连续 MPC 的目标函数或双车均衡求解器。

U_rv=-U_ego 是形式上的零和解释；真实 RV 由独立交通模型执行。
离散调用传 p_yield，按其预测分布比较 wait/go 的期望支付，不求纳什均衡，
返回的 rv_action 是预测标签。p_yield=None 才采用纯策略鞍点/maximin，
没有混合策略均衡求解器。论文 §III.C 本身允许基于当前状态的单侧优化。

默认 eq24 使用负平方速度、安全与舒适偏差；等待代价、让行 THW 修正
属于项目适配。10/3 m/s 仅是缺失双侧 THW 时回退模型的默认速度。
本模块只提出建议；最终通行权限由调用方的授权层决定。
"""
import math
import os
from typing import List, Tuple

#: 【S10】缺失侧 THW 的处理：
#:   0（默认，历史行为）= 缺失侧代入 `thw_th`（"恰好等于阈值"）；在 left_turn 的
#:      `min()` 短板口径下这会让 m 恒等于阈值，再叠加 RV 让行给的 +0.5 ⇒ m_eff 稳过线
#:      ⇒ **给满额安全奖励 +w_safe*6**。实测后果：识别不到 RV / 缺一侧 THW 时，
#:      "走"被判为最安全，判据系统性偏向走（与 P1-f 的"无车=满分安全"同源病理）。
#:   1 = 中性：缺失侧**不参与**；两侧皆缺 → 返回 0.0（不给安全奖励，也不惩罚）。
USAFE_NEUTRAL_MISSING = os.environ.get('DSH_USAFE_NEUTRAL_MISSING', '0') == '1'

#: 动作空间定义
EGO_ACTIONS: List[str] = ['wait', 'go']      # 0=等, 1=走
RV_ACTIONS: List[str] = ['rush', 'yield']    # 0=抢, 1=让


def expected_payoff_response(matrix, p_yield):
    """Best response to an observed opponent distribution, not a Nash solver.

    Both rows are evaluated against both columns. In the rollout model even
    waiting can have different outcomes under different opponent behaviours.
    Keep the historical builder/solver below unchanged for the legacy arm.
    """
    if len(matrix) != 2 or any(len(row) != 2 for row in matrix):
        raise ValueError('Expected a 2x2 payoff matrix')
    values = [[float(v) for v in row] for row in matrix]
    probability = float(p_yield)
    if not all(math.isfinite(v) for row in values for v in row):
        raise ValueError('Nonfinite payoff')
    if not math.isfinite(probability) or not 0. <= probability <= 1.:
        raise ValueError('Invalid yield probability')
    utilities = [(1.-probability)*row[0]+probability*row[1] for row in values]
    selected = 1 if utilities[1] > utilities[0]+1e-9 else 0
    return dict(ego_action=selected, value=utilities[selected],
                u_wait=utilities[0], u_go=utilities[1], payoff_matrix=values,
                rv_payoff_matrix=[[-v for v in row] for row in values],
                p_yield=probability, decision_mode='expected_response', pure_nash=None)


# ==================== 【2026-10-12 修复 D3】式24 的对手耦合通道 ====================
#: Optional engineering hypothesis: yielding improves RV THW toward its target.
#: This constant bonus is not prescribed by paper eq.24. Equal columns are
#: legitimate for its current-state, single-sided model; they only mean that
#: changing p_yield cannot change the expected utility in this implementation.
#: DSH_U_SAFE_EQ24_RV=0 disables this hypothesis for comparison.
RV_YIELD_THW_BONUS = float(os.environ.get('DSH_RV_YIELD_THW_BONUS', '0.5'))
EQ24_RV_COUPLING = os.environ.get('DSH_U_SAFE_EQ24_RV', '1') == '1'


def _rv_thw_eff(thw_rv: float, rv_action: int, thw_th: float = None) -> float:
    """把 RV 侧 THW 按 `rv_action` 修正：让行 ⇒ 向阈值方向改善；抢行 ⇒ 不变。

    这是式24 `u_safety` 的**对手耦合通道**（见 `RV_YIELD_THW_BONUS` 注释）。
    `DSH_U_SAFE_EQ24_RV=0` ⇒ 直接返回原值 ⇒ 复现修复前的秩1行为（消融）。

    ⚠️ **物理约束（关键，勿删）**：让行只把 RV 侧 THW **抬高到阈值为止**，不得抬过阈值
    （`eff = max(v, min(v + bonus, thw_th))`）。
    理由：论文式24 的安全项是"**贴近阈值最优**"的**对称**二次型
      `u_safety = -w·[(THW_RV − TH)² + (THW_FV − TH)²]`。
      若在 `THW_RV` 已 ≥ TH 时仍加 bonus，会把"本来已安全"的状态**推离阈值**
      ⇒ **让行反被判为更危险**（符号错误）。
      实测：`thw_rv=2.0, thw_th=1.5` 时"走+让"的收益被无端压低，
      且既有回归用例 `test_thw_high_safer_than_low` 失败 —— 这正是该约束被发现的原因。

    健壮性约定：本函数在每帧热路径上被调用，**绝不抛异常**。
    · 非有限值（nan/inf）⇒ 原样返回（不放行 bonus），由调用方 `_fin()` 处理；
    · 不可数值化 ⇒ 原样返回（调用方只在 `is not None` 时调用，故不会污染支付）。
    """
    try:
        v = float(thw_rv)
    except (TypeError, ValueError):
        return thw_rv                       # 非法输入：原样返回，不制造偏差
    if (not EQ24_RV_COUPLING) or (not math.isfinite(v)):
        return v
    try:
        if int(rv_action) != 1:
            return v                        # RV 抢行 ⇒ 不变
        eff = v + RV_YIELD_THW_BONUS
        if thw_th is not None:              # 只能改善到阈值为止（对称二次型的约束）
            try:
                eff = min(eff, float(thw_th))
            except (TypeError, ValueError):
                pass
        return max(v, eff)                  # 不得比原值更差
    except (TypeError, ValueError):
        return v


def _safe_from_thw(thw_rv: float, thw_fv: float, rv_action: int,
                   thw_th: float, w_safe: float, mode: str = 'left_turn') -> float:
    """
    U_safe 安全项。两种模式：
      mode='eq24'     严格按论文式24：U_safe = -w_safe·[(THW_RV-TH_th)²+(THW_FV-TH_th)²]
                      （两侧都贴近阈值 TH_th 最优；支付越大越好故取负的平方偏差）
      mode='left_turn' 适配左转：min 短板（最弱侧不破底；两侧安全裕度此消彼长）
    THW 非有限值（无对应车）时按贴近阈值 TH_th 处理（无车 → 最安全）。
    """
    def _fin(x):
        try:
            fx = float(x)
            return fx if math.isfinite(fx) else None
        except (TypeError, ValueError):
            return None

    _frv, _ffv = _fin(thw_rv), _fin(thw_fv)
    if USAFE_NEUTRAL_MISSING:
        _vals = [x for x in (_frv, _ffv) if x is not None]
        if not _vals:
            # 两侧都没有对手 → 安全项**中性**。给奖励会让"无车 ⇒ 该走"变成常数偏置，
            # 而是否该走必须由效率项/等待代价决定，不能由"信息缺失"冒充"安全"。
            return 0.0
        if mode == 'eq24':
            # 只对**存在**的侧求和，再按两侧口径归一（避免"缺一侧 ⇒ 偏差减半 ⇒ 更安全"）
            # 【2026-10-12 修复 D3】RV 侧必须按 `rv_action` 修正（对手耦合通道）
            _devs = []
            if _frv is not None:
                _devs.append((_rv_thw_eff(_frv, rv_action, thw_th) - thw_th) ** 2)
            if _ffv is not None:
                _devs.append((_ffv - thw_th) ** 2)
            if not _devs:
                return 0.0
            return -w_safe * sum(_devs) * (2.0 / len(_devs))
        m = min(_vals)
    else:
        tv = _frv if _frv is not None else thw_th
        tf = _ffv if _ffv is not None else thw_th
        if mode == 'eq24':
            # 【2026-10-12 修复 D3】RV 让行 ⇒ 间隙打开 ⇒ 其 THW 更大（对手耦合通道）。
            #   仅当 RV 侧 THW **真实存在**时才加 bonus；缺失侧代入的 `thw_th`
            #   不得凭空产生偏差（否则"信息缺失"会伪装成"安全/危险"）。
            _tv_eff = _rv_thw_eff(tv, rv_action, thw_th) if _frv is not None else thw_th
            return -w_safe * ((_tv_eff - thw_th) ** 2 + (tf - thw_th) ** 2)
        # left_turn：两侧最小裕度（短板决定整体安全——抬高一侧救不了另一侧）
        m = min(float(tv), float(tf))
    m_eff = m + (0.5 if rv_action == 1 else 0.0)         # RV 让行 → 间隙打开
    # 【S11】`left_turn_pen`：**单边惩罚、无饱和奖励**。
    #  实测 `left_turn` 的形状缺陷：`m_eff >= thw_th` 给满额 **+w_safe*6 = +12**，
    #  而 `m_eff = m + 0.5`、`thw_th = 1.5` ⇒ **只要 THW ≥ 1.0 就拿满分**。
    #  实测四种交通状态 (inf,inf)/(1.0,1.0)/(2.9,inf)/(3.0,3.0) **全部**返回 +12.000，
    #  U_safe(走) 毫无区分度；而"等"净付 `+w_safe*2 − wait_penalty = 4 − 15 = −11`
    #  ⇒ **博弈恒判"走"**。这就是"放行判据偏松"的真正机制，也解释了 §25.3 调严
    #  `_gap_ok` 无效（改道给 Cournot 后仍判走）。
    #  正确形状：安全项只能**扣分**，安全时中性 0 ⇒ "走/不走"由效率项 vs 风险惩罚决定。
    if mode == 'left_turn_pen':
        if m_eff >= thw_th:
            return 0.0                                   # 安全 → 中性（不是奖励）
        elif m_eff > 0.0:
            return -w_safe * 8.0 * (1.0 - m_eff / max(thw_th, 1e-6))
        else:
            return -w_safe * 15.0                        # 会撞
    if m_eff >= thw_th:
        return w_safe * 6.0                              # 双侧都够安全
    elif m_eff > 0.0:
        return -w_safe * 8.0 * (1.0 - m_eff / max(thw_th, 1e-6))   # 软风险
    else:
        return -w_safe * 15.0                            # 会撞


# ==================== 【2026-10-12 修复 D3'】① 的授权口径 ====================
#: 授权口径（环境变量 `DSH_COURNOT_AUTHORITY`）：
#:   'gate'（**默认**）= 风险门是唯一授权通道，①仅"咨询"（= 修复前的**实际**行为，
#:                       但现在它是**显式**的，而不是一个注释与行为不符的死分支）
#:   'risk'（**推荐启用①**）= ①可在"**风险值本身合格**"时授权，即
#:                       `commit_risk ≤ cournot_risk_max`。语义：①**替代"稳定性要求"**，
#:                       但**不越过**风险值上限 ⇒ **安全**的启用方式。
#:   'game'（论文字面）  = ①判走即可授权，安全仅由式24 的 `u_safety` 定价
#:                       ⇒ 会越过风险值上限，**风险最高**，仅用于消融/敏感性分析。
COURNOT_AUTHORITY_MODES = ('gate', 'risk', 'game')


def resolve_cournot_gate(risk_only_gate: bool, authority: str,
                         commit_risk, commit_risk_fresh: bool,
                         cournot_risk_max: float):
    """解析 ① Cournot 的授权口径（**纯函数**，便于单测与消融）。

    返回 `(risk_gate_ok, reason, risk_value_ok)`。

    ⚠️ 调用本函数时，占用窗/机会约束判据**已失败**（`_gap_ok` 为 False）。
       而 `_gap_ok = (risk ≤ risk_max) and (streak ≥ stable_n)`
       ⇒ 失败有**两种成因**，必须区分（这决定①能否被**安全地**授权）：
         (a) `commit_risk > risk_max`                 ⇒ 'risk' 口径拒绝
         (b) `commit_risk ≤ risk_max` 但稳定帧数未满足 ⇒ 风险可接受，仅"稳定性"未达
       'gate' 始终仅咨询；'game' 或关闭 risk_only_gate 可绕过此风险门。

    `commit_risk_fresh=False`（本帧未计算风险值，例如在进入区外）时，
    `risk_value_ok` 恒为 False ⇒ 'risk' 口径**不会用陈旧值授权**（安全）。
    """
    try:
        risk_value_ok = bool(
            commit_risk_fresh and commit_risk is not None
            and float(commit_risk) <= float(cournot_risk_max))
    except (TypeError, ValueError):
        risk_value_ok = False

    if not risk_only_gate:
        return True, 'risk_gate_off', risk_value_ok
    a = str(authority or '').strip().lower()
    if a == 'game':
        return True, 'authority_game', risk_value_ok
    if a == 'risk':
        if risk_value_ok:
            return True, 'authority_risk_ok', True
        return False, 'authority_risk_blocked', False
    # 'gate'（默认，含任何未识别取值）⇒ ①仅咨询，行为与修复前实际一致
    return False, 'gate_only', risk_value_ok


def build_payoff_matrix(arc_to_cross: float,
                        rv_dist_to_conflict: float,
                        v_go: float = 5.0,
                        rv_v_rush: float = 10.0,
                        rv_v_yield: float = 3.0,
                        w_eff: float = 1.0,
                        w_safe: float = 2.0,
                        w_comf: float = 0.3,
                        wait_penalty: float = 15.0,
                        thw_rv: float = None, thw_fv: float = None,
                        thw_th: float = 1.5,
                        v_ref: float = None, jerk: float = None,
                        steer: float = None, jerk_th: float = 0.5,
                        steer_th: float = 0.3,
                        u_safe_mode: str = 'eq24') -> List[List[float]]:
    """
    构建零和支付矩阵 U[ego_action][rv_action]（U_rv = -U）。

    时间模型（与 dds_dcarl 让行判定一致）：
      t_ego_go    = arc / v_go        自车若走，到达冲突点时间
      t_rv(rush)  = dist / v_rush     RV 抢行到达时间
      t_rv(yield) = dist / v_yield    RV 让行到达时间（减速→更晚到→间隙打开）
      安全按 margin = t_rv - t_ego_go 连续评估（非二元灾难）。

    设计要点（论文 §III.C 前提：低俗高密度下必须完成切入）：
      - 等待不是免费的：强制完成代价 wait_penalty（拥堵下无限期等待=失败）
      - 走+让（间隙打开）→ 高效+安全；走+抢（间隙不足）→ 软风险/大负
      - 零和：U_rv = -U_ego（自车效率与 RV 安全裕度此消彼长）

    返回 U 矩阵（仅 ego 视角；RV 视角为 -U，零和）。
    """
    t_ego_go = arc_to_cross / max(v_go, 0.5)
    t_rv_rush = rv_dist_to_conflict / max(rv_v_rush, 0.5)
    t_rv_yield = rv_dist_to_conflict / max(rv_v_yield, 0.5)
    clearance = 4.0 / max(v_go, 0.5)

    def _payoff(ego_action: int, rv_action: int) -> float:
        # ===== 式24：速度效率项 U_speed（越贴近参考速度 v_ref 越好）=====
        if v_ref is not None:
            v_ego = v_go if ego_action == 1 else 0.0
            speed = -w_eff * (v_ego - v_ref) ** 2
        else:
            speed = w_eff * v_go if ego_action == 1 else 0.0

        # ===== 式24：舒适项 U_comfort = (J - J_TH)² + (δ - δ_TH)² =====
        if jerk is not None and steer is not None:
            j = jerk if ego_action == 1 else 0.0
            s = steer if ego_action == 1 else 0.0
            comf = -w_comf * ((j - jerk_th) ** 2 + (s - steer_th) ** 2)
        else:
            if ego_action == 0:
                comf = -w_comf * 2.0
            else:
                comf = -w_comf * (rv_v_rush - rv_v_yield) if rv_action == 1 else 0.0

        # ===== 安全项 U_safe（双侧 THW_boundary 或 后退 margin）=====
        if ego_action == 0:
            # 【S11】`left_turn_pen` 下等待也不拿"安全奖励"：等待的安全性是真的，
            #   但用 +w_safe*2 补贴它会让"等"变成有收益的动作，与"等待只是兜底"矛盾。
            #   保持中性 0；等待的代价只由 wait_penalty 承担。
            safe = 0.0 if u_safe_mode == 'left_turn_pen' else w_safe * 2.0
        elif thw_rv is not None and thw_fv is not None:
            # ① 双侧 THW_boundary 安全项（前后车安全裕度此消彼长）
            safe = _safe_from_thw(thw_rv, thw_fv, rv_action, thw_th, w_safe, mode=u_safe_mode)
        else:
            # 向后兼容：未提供双侧 THW → 走原"到达冲突点时间差 margin"分档
            t_rv = t_rv_yield if rv_action == 1 else t_rv_rush
            margin = t_rv - t_ego_go
            if margin >= clearance + 0.5:
                safe = w_safe * 6.0                     # 间隙充足，安全通过
            elif margin >= clearance:
                safe = w_safe * 6.0 * (margin - clearance) / 0.5   # 过渡
            elif margin >= 0.0:
                safe = -w_safe * 8.0 * (1.0 - margin / max(clearance, 1e-6))  # 软风险
            else:
                safe = -w_safe * 15.0                   # 会撞（margin < 0）

        if ego_action == 0:
            return speed + safe + comf - w_eff * wait_penalty
        return speed + safe + comf

    return [[_payoff(i, j) for j in range(len(RV_ACTIONS))] for i in range(len(EGO_ACTIONS))]


def solve_equilibrium(U: List[List[float]]) -> dict:
    """
    求解 2 人零和纯策略纳什均衡（鞍点）。
      ego（行玩家）最大化最坏情况：max_a min_b U[a][b]
      rv （列玩家）最小化最坏情况：min_b max_a U[a][b]
    两者相等 → 纯策略鞍点；否则无纯策略均衡 → 返回 maximin（保守策略）。
    返回: {'ego_action', 'rv_action', 'value', 'pure_nash', 'payoff_matrix'}
    """
    n_ego, n_rv = len(U), len(U[0])
    # ego 的 maximin（保守：选最坏情况下最好的）
    ego_vals = []
    for a in range(n_ego):
        ego_vals.append((min(U[a]), a))
    maximin = max(ego_vals)
    # rv 的 minimax
    rv_vals = []
    for b in range(n_rv):
        rv_vals.append((max(U[a][b] for a in range(n_ego)), b))
    minimax = min(rv_vals)

    pure_nash = abs(maximin[0] - minimax[0]) < 1e-9
    return {
        'ego_action': maximin[1],
        'rv_action': minimax[1],
        'value': maximin[0],
        'pure_nash': pure_nash,
        'payoff_matrix': U,
    }


def cournot_decision(arc_to_cross: float, rv_dist_to_conflict: float,
                     v_go: float = 5.0, p_yield: float = None, **kw) -> dict:
    """
    一步效用决策：构建支付矩阵 → 期望最优响应或纯策略 maximin → 输出建议。

    两种决策模式：
      p_yield=None  保守鞍点（maximin）：不假设 RV 会让行；只有"即使 RV 抢行也安全"
                    才走（密集车流下强制完成的权衡已计入 wait_penalty）。
      p_yield=给定  期望支付：用 RV 的让行概率（来自 rv_decision 动态阈值）加权
                    U_go = p·U[go][yield] + (1-p)·U[go][rush]，与 U_wait 比较——
                    "RV 让行概率高 → ego 更倾向走"（博弈耦合）。

    概率模式的 value 是所选动作的期望支付；u_go/u_wait 单独保留。
    rv_action 不控制实际对手，decision_mode 明确区分是否计算纯策略鞍点。
    """
    U = build_payoff_matrix(arc_to_cross, rv_dist_to_conflict, v_go=v_go, **kw)
    if p_yield is None:
        eq = solve_equilibrium(U)
        return {
            'ego_action': eq['ego_action'],
            'rv_action': eq['rv_action'],
            'ego_go': eq['ego_action'] == 1,
            'rv_yield': eq['rv_action'] == 1,
            'value': eq['value'],
            'pure_nash': eq['pure_nash'],
            'payoff_matrix': U,
            'decision_mode': 'pure_saddle' if eq['pure_nash'] else 'pure_maximin',
        }
    p = min(1.0, max(0.0, float(p_yield)))
    u_wait = U[0][0]                     # 等：安全恒定（与 RV 动作无关）
    u_go = p * U[1][1] + (1.0 - p) * U[1][0]
    return {
        'ego_action': 1 if u_go > u_wait else 0,
        'rv_action': 1 if p > 0.5 else 0,
        'ego_go': u_go > u_wait,
        'rv_yield': p > 0.5,
        'value': max(u_go, u_wait),
        'u_go': u_go,
        'u_wait': u_wait,
        'decision_mode': 'expected_response',
        'pure_nash': None,
        'payoff_matrix': U,
    }
