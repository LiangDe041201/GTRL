""" 实现一个二维空间下的 R-tree """
import numpy as np
import pickle
import os
from rtree import index

class R_tree:
    def __init__(self):
        """初始化2维R-Tree"""
        self.r_tree = index.Index(properties=index.Property(dimension=2))
        self.locations = []
        self.loc_id = 0
        self.b = 0.1    # 状态离散化参数
        self.state_bounds = None
        self.state_range = np.array([0, 0])  # 默认离散状态范围

        self.data_file = os.path.join("Saved_DCARL_model", "r_tree_data.pkl") 

        # 尝试加载已保存的数据
        self.load_data()

    def add_data(self, data_unit):
        """将数据插入R-Tree"""
        self.locations.append(data_unit)
        ((x, y), act, reward) = data_unit

        # 将数据索引与 mbr(id, (minx, miny, maxx, maxy)) 放入rtree
        self.r_tree.insert(self.loc_id, (x, y, x, y))    
        self.loc_id = self.loc_id + 1

        # 确定离散化状态范围
        state = data_unit[0]
        if self.state_bounds is None:
            self.state_bounds = np.array([state, state])
        else:
            self.state_bounds[0] = np.minimum(self.state_bounds[0], state)    # 逐元素比较
            self.state_bounds[1] = np.maximum(self.state_bounds[1], state)
        self.state_range = self.b * (self.state_bounds[1] - self.state_bounds[0])

        # 保存数据
        self.save_data()

    def search(self, state):
        """在2维R-Tree中搜索相似数据并返回"""
        if len(state) != 2:
            raise ValueError("State must be a 2-dimensional tuple")

        # 初始化收集数据集
        results = []

        # 确定查询区域
        min_x, min_y = state - self.state_range
        max_x, max_y = state + self.state_range
        query_area = (min_x, min_y, max_x, max_y)

        # 找到对应的数据在self.locations中的索引
        nearby_locations = [loc for loc in self.r_tree.intersection(query_area)]

        for loc in nearby_locations:
            results.append(self.locations[loc])
        
        return results
    
    def save_data(self):
        """保存数据到文件"""
        data = {
            'locations': self.locations,
            'loc_id': self.loc_id,
            'state_bounds': self.state_bounds
        }
        with open(self.data_file, 'wb') as f:
            pickle.dump(data, f)
        # print("数据已保存")

    def load_data(self):
        """从文件加载数据"""
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

            with open(self.data_file, 'rb') as f:
                data = pickle.load(f)
                self.locations = data['locations']
                self.loc_id = data['loc_id']
                self.state_bounds = data['state_bounds']

                # 重新构建 Rtree
                for loc_id, ((x, y), act, reward) in enumerate(self.locations):
                    self.r_tree.insert(loc_id, (x, y, x, y))
                    self.loc_id = loc_id

                # 防止后面新存的数据错位
                self.loc_id = self.loc_id + 1

                print("Rtree数据已加载")

        except FileNotFoundError:
            print("没有找到保存的文件，将创建新的Rtree")

            # 确保目录存在
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

        except Exception as e:
            print(f"加载Rtree数据时出错: {e}")
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

            self.r_tree = index.Index(properties=index.Property(dimension=3))
            self.locations = []
            self.loc_id = 0
            self.state_bounds = None


if __name__ == '__main__':
    """测试Rtree用"""
    tree = R_tree()

    # 假设我们有一些地点信息
    location = [
        ((51, -2), 1, 3),  # London
        ((40, -74), 2, 2),  # New York
        ((37, -122), 3, 3)  # San Francisco
    ]
    i = 0
    for ((x, y), act, reward) in location:
        i = i + 1
        data_unit = ((x, y), act, reward)
        tree.add_data(data_unit)
        if i >= 3:
            break

    state = (51.4, -2.3)
    result = tree.search(state)

    # 输出结果
    print(f"查询结果: {result}")