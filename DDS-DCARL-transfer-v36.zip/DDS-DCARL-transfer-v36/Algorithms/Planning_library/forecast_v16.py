"""Public-route candidate forecasts; independent of CARLA and mutable servos.

The 0/.4 s acceleration response family is a declared model hypothesis, not a
calibrated plant or a safety certificate. Pedal command semantics are shared;
an actuator's brake-rise setting is NOT a bound on measured vehicle jerk.
"""
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from Planning_library.trajectory_guard import execution_acceleration
from Planning_library.vehicle_observation import longitudinal_acceleration


def clean_points(path):
    points = np.asarray(path, dtype=float)
    if points.ndim != 2 or len(points) < 2 or points.shape[1] < 2:
        raise ValueError('Forecast needs at least two route points')
    points = points[:, :2]
    if not np.isfinite(points).all():
        raise ValueError('Nonfinite forecast route')
    points = points[np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1) > 1e-6]]
    if len(points) < 2:
        raise ValueError('Degenerate forecast route')
    return points.copy()


class Route:
    def __init__(self, path):
        self.points = clean_points(path)
        self.vectors = np.diff(self.points, axis=0)
        self.lengths = np.linalg.norm(self.vectors, axis=1)
        self.arc = np.r_[0., np.cumsum(self.lengths)]

    def project(self, point):
        t = np.clip(np.sum((np.asarray(point)-self.points[:-1])*self.vectors, axis=1)
                    /self.lengths**2, 0., 1.)
        projected = self.points[:-1]+t[:, None]*self.vectors
        distances = np.linalg.norm(projected-point, axis=1)
        i = int(np.argmin(distances))
        return float(self.arc[i]+t[i]*self.lengths[i]), float(distances[i])

    def at(self, s):
        s = min(max(float(s), 0.), self.arc[-1])
        i = min(int(np.searchsorted(self.arc, s, side='right')), len(self.arc)-1)-1
        return self.points[i]+(s-self.arc[i])*self.vectors[i]/self.lengths[i]


def prediction_geometry(geometry, route, revision='legacy'):
    result = dict(geometry)
    if revision not in ('legacy', 'route_v16'):
        raise ValueError('Unsupported forecast revision: '+revision)
    if revision == 'route_v16':
        result.update(forecast_model=revision, forecast_route=clean_points(route).tolist())
    return result


def covered_route(path, geometry):
    """Keep the MPC path; join only a nearby, aligned PUBLIC route continuation.

    No observation from later frames is used. A route end is a stop destination;
    a short local path with no matching continuation is an invalid six-second
    forecast, not an invented road or an automatically safe candidate.
    """
    local = Route(path)
    public = geometry.get('forecast_route')
    diag = dict(source='local_only', join_gap=None, join_angle=None, route_end=False)
    if public is None:
        return local, diag
    route = Route(public)
    s, gap = route.project(local.points[-1])
    tangent = route.at(min(s+1., route.arc[-1]))-route.at(max(s-1., 0.))
    last = local.vectors[-1]
    angle = math.acos(float(np.clip(np.dot(tangent, last)/
                                   max(np.linalg.norm(tangent)*np.linalg.norm(last), 1e-9), -1., 1.)))
    diag.update(join_gap=gap, join_angle=angle)
    if gap > 1. or angle > math.radians(45.):
        diag['source'] = 'join_rejected'
        return local, diag
    # Skip the perpendicular projection: it could introduce a lateral corner.
    # The connecting chord must also point forward along the existing path.
    indices = np.flatnonzero(route.arc >= s+max(1., 2.*gap))
    if len(indices):
        tail = route.points[indices[0]:]
        chord = tail[0]-local.points[-1]
        if np.dot(chord, last) <= 0.:
            diag['source'] = 'join_rejected'
            return local, diag
        local = Route(np.vstack((local.points, tail)))
    elif gap > .25 or np.linalg.norm(local.points[-1]-route.points[-1]) > 1.:
        diag['source'] = 'join_rejected'
        return local, diag
    diag.update(source='public_route', route_end=True)
    return local, diag


def command_acceleration(requested, speed, target):
    """Same stop/overspeed projection as the paper_v11 command interface."""
    a = execution_acceleration(requested, speed, target)
    if target > .01 and speed > target+.15:
        a = min(a, -min(3., 1.5*(speed-target)))
    if a < -.02 and speed < 1.2 and not (target <= .01 and speed < .1):
        a = max(a, -1.5*speed)  # PedalControllerV11.braking_target
    return max(-3., min(2., a))


def predict(ego, path, target, first_a, first_delta, previous, geometry,
            horizon=6., lag=.4, plan=None, plan_times=None):
    if geometry.get('forecast_model') == 'route_v18':
        from Planning_library.forecast_v18 import predict as predict_v18
        return predict_v18(ego,path,target,first_a,first_delta,previous,geometry,
            horizon=horizon,lag=lag,plan=plan,plan_times=plan_times)
    route, diag = covered_route(path, geometry)
    dt = .05 if horizon <= 3. else .1
    times = np.arange(0., horizon+dt*.1, dt)
    states = np.zeros((7, len(times)))
    x, y, yaw, speed = float(ego.x), float(ego.y), float(ego.yaw), max(0., float(ego.v))
    measured = longitudinal_acceleration(ego)
    actual_a = 0. if measured is None else max(-3., min(2., measured))
    delta, a = float(previous['df']), float(previous['a'])
    maximum, wheelbase = min(1., float(geometry['max_steer'])), float(geometry['wheelbase'])
    if plan is not None:
        plan, plan_times = np.asarray(plan, dtype=float), np.asarray(plan_times, dtype=float)
        if (plan.ndim != 2 or plan.shape[0] != 2 or plan.shape[1]+1 != len(plan_times)
                or not np.isfinite(plan).all() or not np.isfinite(plan_times).all()
                or np.any(np.diff(plan_times) <= 0.)):
            raise ValueError('Invalid forecast control plan')
    start_s, _ = route.project([x, y])
    projections, cross_track, desired = [], [], []
    exhausted = False
    for k, t in enumerate(times):
        s, distance = route.project([x, y])
        projections.append(s); cross_track.append(distance)
        beyond = float(np.dot(np.array([x, y])-route.points[-1],
                               route.vectors[-1]/route.lengths[-1]))
        exhausted = exhausted or beyond > .5
        states[0, k], states[1, k], states[5, k], states[6, k] = x, y, speed, yaw
        if k == len(times)-1:
            break
        effective_target = max(0., float(target))
        if diag['route_end'] and geometry.get('navigation_end_is_stop', True):
            effective_target = min(effective_target,
                math.sqrt(2.*1.2*max(0., route.arc[-1]-s-1.)))
        if k == 0:
            wanted_a, wanted_delta = float(first_a), float(first_delta)
        elif plan is not None and t < plan_times[-1]-1e-9:
            j = min(int(np.searchsorted(plan_times[1:], t, side='right')), plan.shape[1]-1)
            wanted_a, wanted_delta = map(float, plan[:, j])
        else:
            wanted_a = max(-2., min(1.2, 1.5*(effective_target-speed)))
            look = route.at(s+3.5+.4*speed)
            # Look along the terminal tangent, never back at a passed endpoint.
            # Any actual coverage overrun is still invalidated below.
            if s+3.5+.4*speed > route.arc[-1]:
                look = route.points[-1]+route.vectors[-1]/route.lengths[-1]*3.5
            dx, dy = look[0]-x, look[1]-y
            alpha = math.atan2(math.sin(math.atan2(dy, dx)-yaw),
                               math.cos(math.atan2(dy, dx)-yaw))
            wanted_delta = math.atan2(2.*wheelbase*math.sin(alpha), max(math.hypot(dx, dy), .5))
        a = command_acceleration(wanted_a, speed, effective_target)
        delta += max(-.9*dt, min(.9*dt, max(-maximum, min(maximum, wanted_delta))-delta))
        desired.append(a)
        fraction = 1. if lag <= 0. else min(1., dt/lag)
        actual_a += fraction*(a-actual_a)
        next_speed = max(0., speed+dt*actual_a)
        mid_speed = .5*(speed+next_speed)
        beta = math.atan(.5*math.tan(delta))
        x += dt*mid_speed*math.cos(yaw+beta)
        y += dt*mid_speed*math.sin(yaw+beta)
        yaw += dt*mid_speed*math.sin(beta)/(wheelbase/2.)
        speed = next_speed
    progress = float(projections[-1]-start_s)
    valid = not exhausted and max(cross_track) <= 2.
    diag.update(revision=geometry.get('forecast_model', 'route_v16'), valid=bool(valid), coverage_exhausted=bool(exhausted),
        max_cross_track=float(max(cross_track)), path_length=float(route.arc[-1]),
        start_s=start_s, end_s=float(projections[-1]), progress_m=max(0., progress),
        signed_progress_m=progress, max_speed=float(np.max(states[5])),
        end_speed=float(states[5, -1]), horizon=float(times[-1]), lag=float(lag),
        response='first_order_0_or_0.4s_uncalibrated',
        command_max=float(max(desired)), command_min=float(min(desired)))
    return states, times, diag


class ForecastRecorder:
    def __init__(self, directory, geometry):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        route = clean_points(geometry['forecast_route'])
        self.revision = geometry.get('forecast_model', 'route_v16')
        metadata = dict(revision=self.revision, route=route.tolist(),
            route_sha256=hashlib.sha256(np.asarray(route, dtype='<f8').tobytes()).hexdigest(),
            response_lags=[0., .4], measured_acceleration_is_initial_condition=True,
            response_calibrated=False, execution_profile='paper_v11',
            max_forecast_cross_track=2., terminal_overrun_tolerance=.5)
        if self.revision in ('route_v17','route_v18'):
            metadata.update(navigation_route=geometry['navigation_route'],
                navigation_end_is_stop=False, road_source=geometry['road_source'],
                opponent_model='recovery_family_v17', recovery_acceleration_bound=2.,
                recovery_delays=[0., 1.], opponent_cruise=geometry.get('opponent_cruise', 4.412022451715821))
        if self.revision == 'route_v18':
            metadata.update(opponent_model='leader_conditioned_v18',
                ego_predictor='dense_mpc_prefix_feedback_v18',integration_dt=.05,
                plan_prefix_max_s=.3,following_brake_bound=5.,leader_response_delays=[0.,.3],
                candidate_conditioned=True,stop_band_margin=.15)
        (self.directory/'forecast_metadata.json').write_text(
            json.dumps(metadata, allow_nan=False, indent=2), encoding='utf8')

    def record(self, episode, frame, audit, applied):
        candidates = [dict(c, gap=c['gap'] if math.isfinite(c['gap']) else None)
                      for c in audit['candidates']]
        row = dict(revision=self.revision, episode=int(episode), frame=int(frame),
            selected=audit['action'], safe=bool(audit['safe']), override=bool(audit['override']),
            candidates=candidates, applied_a=float(applied['a_cmd']),
            target=float(applied['actuator_speed_target']))
        with (self.directory/'forecast_audit.jsonl').open('a', encoding='utf8') as stream:
            stream.write(json.dumps(row, allow_nan=False)+'\n')
