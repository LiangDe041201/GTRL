""" 实现三维空间下的车道 R-tree（转弯版：3D 状态）"""
import numpy as np
import pickle
import os
from rtree import index

# ===== 统一保存路径（锚定到 Algorithms 目录，可用 DSH_SAVE_DIR 重定向）=====
try:
    from path_utils import get_model_dir
except ImportError:
    def get_model_dir():
        return os.environ.get('DSH_SAVE_DIR', os.path.join(os.getcwd(), "Saved_DCARL_model"))
_SAVE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # Planning_library -> Algorithms

class Rtree_lane:
    def __init__(self):
        """初始化 3 维 R-Tree（支持转弯版状态编码）"""
        self.r_tree = index.Index(properties=index.Property(dimension=3))
        self.locations = []
        self.loc_id = 0
        self.b = 0.1
        self.state_bounds = None
        self.state_range = np.array([0, 0, 0])

        # 使用独立文件名，避免与旧 2D 数据冲突（走统一定位，可用 DSH_SAVE_DIR 重定向）
        self.data_file = os.path.join(get_model_dir(), "rtree_lane_turn_data.pkl")
        self.state_info_file = os.path.join(get_model_dir(), "rtree_lane_turn_state_info.pkl")

        self.load_data()

    def add_data(self, data_unit, save=True):
        """将 3D 数据插入 R-Tree。save=False 时只入树不落盘（供批量写库，避免逐条全量 dump）"""
        self.locations.append(data_unit)
        ((x, y, z), lane_sign, act, reward) = data_unit

        self.r_tree.insert(self.loc_id, (x, y, z, x, y, z))
        self.loc_id += 1

        state = data_unit[0]
        if self.state_bounds is None:
            self.state_bounds = np.array([state, state])
        else:
            self.state_bounds[0] = np.minimum(self.state_bounds[0], state)
            self.state_bounds[1] = np.maximum(self.state_bounds[1], state)
        self.state_range = self.b * (self.state_bounds[1] - self.state_bounds[0])

        if save:
            self.save_state_info()
            self.save_data()

    def search(self, state):
        """在 3 维 R-Tree 中搜索相似数据"""
        if len(state) != 3:
            raise ValueError(f"State must be a 3-dimensional tuple, got len={len(state)}")

        results = []
        min_coords = np.array(state) - self.state_range
        max_coords = np.array(state) + self.state_range
        query_area = (*min_coords, *max_coords)

        nearby_locations = [loc for loc in self.r_tree.intersection(query_area)]
        for loc in nearby_locations:
            results.append(self.locations[loc])
        return results

    def save_data(self):
        data = {
            'locations': self.locations,
            'loc_id': self.loc_id,
            'state_bounds': self.state_bounds
        }
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
        with open(self.data_file, 'wb') as f:
            pickle.dump(data, f)

    def load_data(self):
        try:
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
            self.load_state_info()

            with open(self.data_file, 'rb') as f:
                data = pickle.load(f)
                self.locations = data['locations']
                self.loc_id = data['loc_id']

            # 重建 R-tree（3D）
            for loc_id, ((x, y, z), lane_sign, act, reward) in enumerate(self.locations):
                self.r_tree.insert(loc_id, (x, y, z, x, y, z))
                self.loc_id = loc_id
            self.loc_id += 1

            print(f"Rtree_lane(3D) 数据已加载 file={self.data_file}, entries={len(self.locations)}, state_range={self.state_range}")

        except FileNotFoundError:
            print("没有找到保存的文件，将创建新的 Rtree_lane(3D)")
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

        except Exception as e:
            print(f"加载 Rtree_lane(3D) 时出错: {e}，将重建")
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
            self.r_tree = index.Index(properties=index.Property(dimension=3))
            self.locations = []
            self.loc_id = 0
            self.state_bounds = None
            self.state_range = np.array([0, 0, 0])

    def save_state_info(self):
        try:
            os.makedirs(os.path.dirname(self.state_info_file), exist_ok=True)
            with open(self.state_info_file, 'wb') as f:
                pickle.dump({
                    'state_bounds': self.state_bounds,
                    'state_range': self.state_range
                }, f)
        except Exception as e:
            print(f"保存状态信息失败: {e}")

    def load_state_info(self):
        try:
            with open(self.state_info_file, 'rb') as f:
                state_info = pickle.load(f)
                self.state_bounds = state_info.get('state_bounds')
                self.state_range = state_info.get('state_range', np.array([0, 0, 0]))
                print(f"状态信息已加载 file={self.state_info_file}, state_range={self.state_range}")
        except (FileNotFoundError, EOFError, pickle.PickleError):
            self.state_bounds = None
            self.state_range = np.array([0, 0, 0])
            print("没有找到状态信息文件，将创建新的状态信息")