#!/usr/bin/env python3
"""
场景快照（Scenario Snapshot）：离线对拍的数据载体。

- 纯 numpy/math，无 CARLA 依赖，可在没有 CARLA 的机器上 import 和单测。
- 阶段 0：为 GTRL 改造提供统一的离线 fixture 数据格式。
- 后续阶段：间隙前/后车识别、LCTTC 边界度量、Cournot 博弈等纯函数都以
  本快照为输入；CARLA 侧训练时由 dynamic_map / objects 薄适配成快照。

与转弯场景的坐标约定（DDS-DCARL-Turn）：
  - 自车从北侧 (5.78, -103.23) 出发，向西行驶后左转 90° 向南；
  - 交叉口中心 INTERSECTION_CENTER = (6.00, -138.00)，冲突点取参考路径上
    y ≈ -138 的点；
  - 交叉车流沿 y = -138 由东向西（x 递减）直线行驶，vx < 0。
"""
import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

#: 默认冲突点坐标（与 TestScenario_Town03_turn.INTERSECTION_CENTER 一致）
CONFLICT_XY_DEFAULT: Tuple[float, float] = (6.00, -138.00)


@dataclass
class VehicleState:
    """一辆车的运动学快照（世界坐标系，弧度制）。"""
    x: float = 0.0
    y: float = 0.0
    yaw: float = 0.0            # 航向角（rad）
    v: float = 0.0              # 速度幅值（m/s）
    vx: float = 0.0             # 世界系 x 向速度分量
    vy: float = 0.0             # 世界系 y 向速度分量
    length: float = 4.5         # 车身长（m）
    width: float = 2.0          # 车身宽（m）
    role: str = "none"          # ego / rv / fv / none
    veh_id: int = -1
    # Missing acceleration is distinct from a measured zero. These values come
    # from observed motion, never the traffic manager's private decisions.
    ax: Optional[float] = None
    ay: Optional[float] = None
    acc: Optional[float] = None
    acc_source: str = 'unavailable'


@dataclass
class ScenarioSnapshot:
    """一个博弈局面的完整离线快照。"""
    ego: VehicleState
    vehicles: List[VehicleState] = field(default_factory=list)
    conflict_xy: Tuple[float, float] = CONFLICT_XY_DEFAULT
    arc_to_cross: float = 0.0   # 自车沿参考路径到冲突点的弧长（m）
    t_ego: float = 0.0          # 自车预计到达冲突点时间（s）
    committed: bool = False     # 自车是否已越过冲突点
    path: Optional[object] = None  # 可选参考路径（Nx2），仅供需要时使用
    #: 【P2-a】"计划到达时间"（s）：用**计划车速**（而非瞬时车速）算出的 t_ego。
    #:   rv/fv 角色划分必须用它 —— 用瞬时车速划分会让"自车减速 ⇒ t_ego↑ ⇒ 所有
    #:   交叉车被重分类为"已先通过"的 fv ⇒ rv 角色为空"，即博弈在状态层面静默消失，
    #:   自车可以靠减速把自己的对手"变没"（与 P1-f 奖励劫持同一机理）。
    #:   None 表示回落到 t_ego（旧口径，DSH_ROLE_MODE=time 时使用）。
    t_ego_plan: Optional[float] = None
    #: 【P2-b】博弈进行中的**空间**交互窗口（m）：交叉车到冲突点的纵向距离在此之内
    #:   才计入博弈。与自车速度无关（论文：game 是否进行由 LCV 质心是否越过车道线
    #:   决定，而非由 LCV 当前想开多慢决定）。
    game_window: float = 45.0

    def t_plan(self) -> float:
        """角色划分用的计划到达时间（t_ego_plan 缺失时回落到 t_ego）。"""
        return float(self.t_ego if self.t_ego_plan is None else self.t_ego_plan)

    def cross_vehicles(self) -> List[VehicleState]:
        """返回参与博弈的交叉车辆（rv/fv/其他），排除自车。"""
        return [v for v in self.vehicles if v.role != "ego"]


def make_fixture(case_id: int) -> ScenarioSnapshot:
    """
    确定性典型局面（固定数值，天然可复现，无需随机种子）。

    公共设定：冲突点 (6.0, -138.0)；自车在 (6.0, -135.0) 向南（yaw=-pi/2），
    到冲突点弧长 3.0 m，v=6 -> t_ego=0.5s；交叉车流 y=-138 向西行驶（vx=-v）。

    间隙语义（对标论文：ego 切入 fv 与 rv 之间的时间间隙）：
      fv（前车）= t_veh < t_ego 的最近接近车（ego 跟在它后面通过冲突点）
      rv（后车）= t_veh > t_ego 的最近接近车（ego 切入它前方）
      默认 fv 在 x=8.0（t_veh=0.2s）。

    case_id:
      1 间隙充足（rv 远 x=40，t_veh=3.4s）  -> 应"走"
      2 间隙临界（rv x=17.7，Δt≈清空时间0.67s）-> 应谨慎
      3 间隙不足（rv x=11，Δt≈0，与自车同时到）-> 应"让"
      4 rv 让行（x=15 减速至 6m/s 逼近）
      5 rv 不让行（对抗：x=15 全速 10m/s 匀速逼近）
      6 已越过冲突点（committed）
    """
    ego = VehicleState(x=6.0, y=-135.0, yaw=-math.pi / 2, v=6.0,
                       vx=0.0, vy=-6.0, length=4.5, width=2.0,
                       role="ego", veh_id=0)

    def cross(x, v, role, vid):
        return VehicleState(x=x, y=-138.0, yaw=math.pi, v=v, vx=-v, vy=0.0,
                            length=4.0, width=2.0, role=role, veh_id=vid)

    # 默认 fv：x=8 -> t_veh=(8-6)/10=0.2s < t_ego=0.5s（ego 跟在它后面）
    fv = cross(8.0, 10.0, "fv", 11)

    if case_id == 1:
        # rv x=40 -> t_veh=3.4s；Δgap=(3.4-0.2)=3.2s 充足
        rv = cross(40.0, 10.0, "rv", 12)
        return ScenarioSnapshot(ego=ego, vehicles=[fv, rv],
                                arc_to_cross=3.0, t_ego=0.5)
    if case_id == 2:
        # rv x=17.7 -> t_veh=1.17s；Δt=t_veh-t_ego≈0.67s ≈ 清空时间(4/6)
        rv = cross(17.7, 10.0, "rv", 12)
        return ScenarioSnapshot(ego=ego, vehicles=[fv, rv],
                                arc_to_cross=3.0, t_ego=0.5)
    if case_id == 3:
        # rv x=11 -> t_veh=0.5s == t_ego（同时到冲突点），Δgap 仅 0.3s，必让
        rv = cross(11.0, 10.0, "rv", 12)
        return ScenarioSnapshot(ego=ego, vehicles=[fv, rv],
                                arc_to_cross=3.0, t_ego=0.5)
    if case_id == 4:
        # rv 减速逼近（让行趋势）：x=15, v=6 -> t_veh=1.5s
        rv = cross(15.0, 6.0, "rv", 12)
        return ScenarioSnapshot(ego=ego, vehicles=[fv, rv],
                                arc_to_cross=3.0, t_ego=0.5)
    if case_id == 5:
        # rv 全速匀速逼近（对抗：不让行）：x=15, v=10 -> t_veh=0.9s
        rv = cross(15.0, 10.0, "rv", 12)
        return ScenarioSnapshot(ego=ego, vehicles=[fv, rv],
                                arc_to_cross=3.0, t_ego=0.5)
    if case_id == 6:
        # 自车已越过冲突点 1.8m（y=-139.8 < -138）
        ego_past = VehicleState(x=6.0, y=-139.8, yaw=-math.pi / 2, v=6.0,
                                vx=0.0, vy=-6.0, length=4.5, width=2.0,
                                role="ego", veh_id=0)
        rv = cross(9.0, 10.0, "rv", 12)
        return ScenarioSnapshot(ego=ego_past, vehicles=[rv],
                                arc_to_cross=-1.8, t_ego=0.05, committed=True)

    raise ValueError(f"未知 case_id: {case_id}")
