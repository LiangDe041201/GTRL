"""Keep the CG default; grant learning only guard-accepted alternatives."""
import math

from Planning_library.candidate_learning_v20 import CandidateLearnerV20
from Planning_library.execution_guard import select_execution
from Planning_library.matrix_turn_game_v19 import MatrixTurnGameV19
from Planning_library.trajectory_guard import execution_acceleration


def candidate_execution(ego,objects,candidates,path,previous,geometry):
    """Read-only proposal audit, using the exact final guard and command clamp.

    No solver state is changed. Backup selection is deliberately irrelevant:
    an alternative is eligible only if its own proposal is accepted as 'mpc'.
    The final guard still runs on the chosen request every frame.
    """
    rows=[]
    for i,c in enumerate(candidates):
        acceleration=execution_acceleration(c['a'],max(float(ego.v),0.),c['target'])
        _,audit=select_execution(ego,objects,path,c['target'],acceleration,c['delta'],previous,
            geometry,prediction=c.get('prediction'),prediction_times=c.get('times'),
            plan=c.get('plan'),solve_ok=c['solve_ok'],allow_clear=False)
        gap=audit['proposed_gap']
        proposal=next((p for p in audit['candidates'] if p['action']=='mpc'),{})
        rows.append(dict(candidate=i,accepted=bool(audit['action']=='mpc' and audit['safe']
            and not audit['override']),a=acceleration,delta=float(c['delta']),target=float(c['target']),
            proposed_gap=gap if gap is not None and math.isfinite(gap) else None,
            unbounded_gap=bool(gap is not None and gap==float('inf')),
            forecast_valid=bool(proposal.get('forecast_valid',False)),
            stop_feasible=bool(proposal.get('stop_feasible',False)),solve_ok=bool(c['solve_ok'])))
    return rows


class MatrixTurnGameV20(MatrixTurnGameV19):
    revision='matrix_entry_v20'
    controller='matrix_v20'
    learning_revision='candidate_learning_v20'
    learner_type=CandidateLearnerV20

    def learning_candidates(self,ego,objects,candidates,path,previous,baseline,active):
        usable=super().learning_candidates(ego,objects,candidates,path,previous,baseline,active)
        self._execution_rows=(candidate_execution(ego,objects,candidates,path,previous,self.geometry)
                              if active else [])
        # Preserve the CG/guard default even in an emergency. Filtering only
        # affects additional learning authority, never the frozen CG policy.
        return sorted({baseline}|{i for i in usable if active and self._execution_rows[i]['accepted']})

    def learning_diagnostics(self):
        return dict(candidate_execution=self._execution_rows,
                    eligibility='cg_default_or_guard_accepted_alternative_v20')
