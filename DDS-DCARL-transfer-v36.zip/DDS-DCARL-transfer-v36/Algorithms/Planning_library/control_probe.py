"""Measured-state stop/hold/restart probe for the empty-road check only."""
import math


class StopRestartProbe:
    STARTUP_DEADLINE = 5.
    STOP_DEADLINE = 4.
    HOLD_SECONDS = .5
    RECOVERY_DEADLINE = 3.
    STABLE_SECONDS = .25

    def __init__(self, dt=.05, cruise_speed=None):
        if cruise_speed is not None and (not math.isfinite(cruise_speed) or not 2. <= cruise_speed <= 4.):
            raise ValueError('Probe cruise speed must be in [2, 4] m/s')
        self.dt = dt
        self.cruise_speed = cruise_speed
        self.phase = 'startup'
        self.elapsed = 0.
        self.phase_elapsed = 0.
        self.stable = 0.
        self.failure = ''

    def _enter(self, phase):
        self.phase, self.phase_elapsed, self.stable = phase, 0., 0.

    def target(self, nominal):
        if self.phase in ('decelerate', 'hold', 'failed'):
            return 0.
        return float(nominal) if self.cruise_speed is None else min(float(nominal), self.cruise_speed)

    def observe(self, speed):
        """Advance AFTER a measured tick; the logged phase names its command."""
        if not math.isfinite(speed) or speed < 0.:
            raise ValueError('Invalid measured probe speed')
        phase = self.phase
        self.elapsed += self.dt
        self.phase_elapsed += self.dt
        if phase == 'startup':
            self.stable = self.stable+self.dt if speed >= 1. else 0.
            if self.stable+1e-9 >= self.STABLE_SECONDS:
                self._enter('cruise')
            elif self.phase_elapsed+1e-9 >= self.STARTUP_DEADLINE:
                self.failure = 'startup_timeout'
        elif phase == 'cruise':
            threshold = 2. if self.cruise_speed is None else .8*self.cruise_speed
            self.stable = self.stable+self.dt if speed >= threshold else 0.
            if self.elapsed >= 4. and self.stable+1e-9 >= .5:
                self._enter('decelerate')
            elif self.phase_elapsed >= 5.:
                self.failure = 'cruise_timeout'
        elif phase == 'decelerate':
            self.stable = self.stable+self.dt if speed < .1 else 0.
            if self.stable+1e-9 >= self.STABLE_SECONDS:
                self._enter('hold')
            elif self.phase_elapsed+1e-9 >= self.STOP_DEADLINE:
                self.failure = 'stop_timeout'
        elif phase == 'hold':
            if speed >= .1:
                self.failure = 'hold_drift'
            elif self.phase_elapsed+1e-9 >= self.HOLD_SECONDS:
                self._enter('recovery')
        elif phase == 'recovery':
            self.stable = self.stable+self.dt if speed >= 1. else 0.
            if self.stable+1e-9 >= self.STABLE_SECONDS:
                self._enter('done')
            elif self.phase_elapsed+1e-9 >= self.RECOVERY_DEADLINE:
                self.failure = 'recovery_timeout'
        if self.failure:
            self._enter('failed')
        return self.phase

