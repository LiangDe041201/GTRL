"""Shared spatial path conditioning and explicit entry-policy experiment.

No payoff, safety margin or actuator parameter is changed. Decimation replaces
time-clustered samples by bounded-error arc-length samples of the same route.
Both directions of the polyline distance are conservatively bounded; this is
a geometry representation repair, not a curvature clamp or a safety proof.
"""
import hashlib
import json
import math
from pathlib import Path

import numpy as np


def path_hash(path):
    points = np.asarray(path, dtype='<f8')[:, :2]
    return hashlib.sha256(points.tobytes()).hexdigest()


def _arc(points):
    return np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]


def _sample(points, spacing):
    arc = _arc(points)
    distances = np.linspace(0., arc[-1], max(2, int(math.ceil(arc[-1]/spacing)))+1)
    return np.column_stack([np.interp(distances, arc, points[:, i]) for i in (0, 1)])


def _distance(points, path):
    vectors = np.diff(path, axis=0)
    fractions = np.clip(np.sum((points[:, None, :]-path[None, :-1, :])*vectors, axis=2)
                        /np.sum(vectors*vectors, axis=1), 0., 1.)
    nearest = path[None, :-1, :]+fractions[:, :, None]*vectors
    return np.sqrt(np.min(np.sum((points[:, None, :]-nearest)**2, axis=2), axis=1))


def spatial_path(path, spacing=.5, tolerance=.05):
    """Preserve endpoints; refine spacing until the distance bound is <=5 cm.

    Distance to a set is 1-Lipschitz. A <=1 cm arc sampling grid therefore
    bounds the unsampled distance by sampled maximum + 0.5 cm, in BOTH
    directions. Invalid or unusually long inputs remain for the existing MPC
    recovery contract; geometry is never silently replaced by a straight line.
    """
    if not .005 < tolerance <= .1 or not .0625 <= spacing <= 1.:
        raise ValueError('Invalid spatial path parameters')
    try:
        raw = np.asarray(path, dtype=float)
    except (TypeError, ValueError):
        return path, dict(revision='spatial_v15', status='unchanged_invalid',
                          spacing=None, deviation_bound=None, input_points=0, output_points=0)
    diag = dict(revision='spatial_v15', status='unchanged_invalid',
                spacing=None, deviation_bound=None, input_points=len(raw) if raw.ndim else 0,
                output_points=len(raw) if raw.ndim else 0)
    if (raw.ndim != 2 or raw.shape[1] < 2 or len(raw) < 3
            or not np.isfinite(raw[:, :2]).all()):
        return path, diag
    points = raw[:, :2]
    points = points[np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1)>1e-9]]
    if len(points)<3 or not .5 <= _arc(points)[-1] <= 100.:
        return path, diag
    dense = _sample(points, .01)
    step = float(spacing)
    while step >= .0625-1e-9:
        result = _sample(points, step)
        bound = max(float(np.max(_distance(dense, result))),
                    float(np.max(_distance(_sample(result, .01), points))))+.005
        if bound <= tolerance:
            diag.update(status='resampled', spacing=step, deviation_bound=bound,
                        output_points=len(result), input_hash=path_hash(raw), output_hash=path_hash(result))
            return result, diag
        step *= .5
    diag.update(status='unchanged_deviation_limit', input_hash=path_hash(raw), output_hash=path_hash(raw))
    return path, diag


class ControlExperimentV15:
    """Only explicitly selected pure RULE/matrix arms can use this experiment."""
    def __init__(self, method, matrix, profile, path_revision='legacy', entry_policy='full', directory=None,
                 candidate_learning=False):
        if path_revision not in ('legacy', 'spatial_v15') or entry_policy not in ('full', 'minimal'):
            raise ValueError('Unsupported path revision or entry policy')
        if (entry_policy=='minimal' and (method!='RULE' or matrix or path_revision!='spatial_v15')):
            raise ValueError('Minimal entry is an explicit spatial_v15 RULE ablation only')
        learner_owner=bool(candidate_learning and method=='GTRL' and matrix)
        if candidate_learning and not learner_owner:
            raise ValueError('Candidate learning requires a GTRL matrix owner')
        if path_revision=='spatial_v15' and (profile!='paper_v11' or
                method not in ('RULE', 'CG') and not learner_owner or method=='CG' and not matrix):
            raise ValueError('Spatial experiment requires paper_v11 RULE or matrix CG')
        self.enabled = path_revision=='spatial_v15'
        self.matrix, self.entry_policy = bool(matrix), entry_policy
        self.advance_enabled = not matrix and entry_policy=='full'
        self.directory = Path(directory) if directory else None
        self.path_diag = dict(revision=path_revision, status='not_set')

    def condition(self, trajectory):
        if self.enabled:
            trajectory.trajectory, self.path_diag = spatial_path(trajectory.trajectory)

    def record(self, episode, frame, controller, audit, applied, ego,
               advance_called, selected=None, active=False):
        if not self.enabled or self.directory is None:
            return
        if audit is None:
            raise ValueError('The common final execution audit is mandatory')
        self.directory.mkdir(parents=True, exist_ok=True)
        row = dict(revision='entry_path_v15', episode=int(episode), frame=int(frame),
            entry_policy='matrix' if self.matrix else self.entry_policy,
            advance_enabled=self.advance_enabled, advance_called=bool(advance_called), final_guard_enabled=True,
            path=dict(self.path_diag), actual_path_hash=path_hash(controller.last_pathway),
            geometry_source=controller.geometry_source,
            mpc_kappa=float(controller.reference_path.frenet_convertor.get_kappa(ego.x, ego.y)),
            matrix_active=bool(active), matrix_selected=selected,
            guard_action=audit['action'], guard_override=bool(audit['override']),
            applied_target=float(applied['actuator_speed_target']),
            speed_before=float(applied['ego_v_before']), speed_after=float(applied['ego_v_after']),
            applied_a=float(applied['a_cmd']))
        with (self.directory/'entry_path_audit.jsonl').open('a', encoding='utf8') as stream:
            stream.write(json.dumps(row, allow_nan=False)+'\n')
