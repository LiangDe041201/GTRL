""" 实现一个 N 维空间下的 R-tree（转弯场景使用 5 维状态）"""
import numpy as np
import pickle
import os
from rtree import index

# ===== 统一保存路径（锚定到 Algorithms 目录）=====
try:
    from path_utils import get_model_dir
except ImportError:
    def get_model_dir():
        return os.path.join(os.getcwd(), "Saved_DCARL_model")
_SAVE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # Planning_library -> Algorithms

class Rtree_env:
    def __init__(self, dim=5):
        """初始化R-Tree"""
        self.dim = dim
        self.r_tree = index.Index(properties=index.Property(dimension=self.dim))
        self.locations = []
        self.loc_id = 0
        self.b = 0.1    # 状态离散化参数
        self.state_bounds = None
        self.state_range = np.zeros(self.dim)  # 默认离散状态范围

        self.data_file = os.path.join(get_model_dir(), "rtree_env_data.pkl")

        # 尝试加载已保存的数据
        self.load_data()

    def add_data(self, data_unit, save=True):
        """将数据插入R-Tree。save=False 时只入树不落盘（供批量写库，避免逐条全量 dump 的 O(N²) I/O）"""
        self.locations.append(data_unit)
        state = np.asarray(data_unit[0], dtype=float)
        if state.ndim != 1:
            self.locations.pop()
            return

        # 若状态维度与当前 R-tree 不一致（例如旧版 3 维 pkl + 新 5 维状态），
        # 旧数据语义已失效，直接丢弃重建，避免把低维点硬插进高维树导致 RTreeError 崩溃。
        if state.shape[0] != self.dim:
            print(f"[Rtree_env] 状态维度变化 {self.dim} -> {state.shape[0]}，"
                  f"旧数据({len(self.locations) - 1}条)已失效，重建 R-tree")
            self.dim = int(state.shape[0])
            self.state_bounds = None
            self.state_range = np.zeros(self.dim)
            self.locations = [data_unit]
            self.loc_id = 0
            self.r_tree = index.Index(properties=index.Property(dimension=self.dim))

        self.r_tree.insert(self.loc_id, (*state, *state))    
        self.loc_id = self.loc_id + 1

        # 确定离散化状态范围
        if self.state_bounds is None:
            self.state_bounds = np.array([state, state])
        else:
            self.state_bounds[0] = np.minimum(self.state_bounds[0], state)    #逐元素比较
            self.state_bounds[1] = np.maximum(self.state_bounds[1], state)
        self.state_range = self.b * (self.state_bounds[1] - self.state_bounds[0])

        # 保存数据
        if save:
            self.save_data()

    def search(self, state):
        """在R-Tree中搜索相似数据并返回"""
        # 初始化收集数据集
        results = []

        # 确定查询区域
        state = np.asarray(state, dtype=float)
        if state.shape[0] != self.dim:
            return results
        min_coords = state - self.state_range
        max_coords = state + self.state_range
        query_area = (*min_coords, *max_coords)

        # 找到对应的数据在self.locations中的索引
        nearby_locations = [loc for loc in self.r_tree.intersection(query_area)]

        for loc in nearby_locations:
            results.append(self.locations[loc])
        
        return results
    
    def save_data(self):
        """保存数据到文件"""
        data = {
            'locations': self.locations,
            'loc_id': self.loc_id,
            'state_bounds': self.state_bounds,
            'dim': self.dim,
        }
        with open(self.data_file, 'wb') as f:
            pickle.dump(data, f)

    def load_data(self):
        """从文件加载数据"""
        try:
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

            with open(self.data_file, 'rb') as f:
                data = pickle.load(f)
                self.locations = data['locations']
                self.loc_id = data['loc_id']
                self.state_bounds = data.get('state_bounds', None)
                self.dim = int(data.get('dim', 3))

                # 重新构建 Rtree
                self.r_tree = index.Index(properties=index.Property(dimension=self.dim))
                if len(self.locations) > 0:
                    first_state = np.asarray(self.locations[0][0], dtype=float)
                    if first_state.shape[0] != self.dim:
                        self.dim = int(first_state.shape[0])
                        self.r_tree = index.Index(properties=index.Property(dimension=self.dim))
                    for loc_id, (s, e, a, r) in enumerate(self.locations):
                        sv = np.asarray(s, dtype=float)
                        self.r_tree.insert(loc_id, (*sv, *sv))

                self.state_range = self.b * (self.state_bounds[1] - self.state_bounds[0]) \
                    if self.state_bounds is not None else np.zeros(self.dim)

                print(f"Rtree数据已加载 dim={self.dim} entries={len(self.locations)}")

        except FileNotFoundError:
            print("没有找到保存的文件，将创建新的Rtree")
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

        except Exception as e:
            print(f"加载Rtree数据时出错: {e}")
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)

            self.r_tree = index.Index(properties=index.Property(dimension=self.dim))
            self.locations = []
            self.loc_id = 0
            self.state_bounds = None
            self.state_range = np.zeros(self.dim)


    # ==================== 新增：按轮次保存 / 读取指定轮次（固定路径）====================
    def save_checkpoint_by_epoch(self, epoch):
        """
        新增：根据当前训练轮次，保存独立的 checkpoint PKL 文件
        固定路径：Saved_DCARL_model/check_point
        不会影响原有 save_data / load_data
        """
        # 固定 checkpoint 根目录（走统一定位，可用 DSH_SAVE_DIR 重定向）
        checkpoint_root = os.path.join(get_model_dir(), "check_point")
        checkpoint_file = os.path.join(checkpoint_root, f"rtree_env_checkpoint_epoch_{epoch}.pkl")

        # 保存内容与原逻辑完全一致
        data = {
            'locations': self.locations,
            'loc_id': self.loc_id,
            'state_bounds': self.state_bounds
        }

        # 确保目录存在
        os.makedirs(checkpoint_root, exist_ok=True)

        with open(checkpoint_file, 'wb') as f:
            pickle.dump(data, f)

        print(f"R-tree 轮次 {epoch} 已保存：{checkpoint_file}")

    def load_checkpoint_by_epoch(self, epoch):
        """
        新增：加载指定轮次的 checkpoint PKL 文件
        固定路径读取，不修改原有 load_data()
        """
        checkpoint_root = os.path.join(get_model_dir(), "check_point")
        checkpoint_file = os.path.join(checkpoint_root, f"rtree_env_checkpoint_epoch_{epoch}.pkl")

        try:
            with open(checkpoint_file, 'rb') as f:
                data = pickle.load(f)

            # 覆盖内存数据
            self.locations = data['locations']
            self.loc_id = data['loc_id']
            self.state_bounds = data.get('state_bounds', None)

            # 重建 R-tree
            if len(self.locations) > 0:
                self.dim = int(np.asarray(self.locations[0][0], dtype=float).shape[0])
            self.r_tree = index.Index(properties=index.Property(dimension=self.dim))
            for idx, item in enumerate(self.locations):
                sv = np.asarray(item[0], dtype=float)
                self.r_tree.insert(idx, (*sv, *sv))

            # 重新计算状态范围
            if self.state_bounds is not None:
                self.state_range = self.b * (self.state_bounds[1] - self.state_bounds[0])

            print(f"成功加载 R-tree 轮次 {epoch} checkpoint")
            return True

        except FileNotFoundError:
            print(f"未找到轮次 {epoch} 文件：{checkpoint_file}")
            return False

        except Exception as e:
            print(f"加载轮次 {epoch} 失败：{str(e)}")
            return False


# if __name__ == '__main__':
#     """测试Rtree用"""
#     tree = R_tree()

#     # 假设我们有一些地点信息
#     location = [
#         ((51, -2, 0), (1, 2, 1), 1, 1),  # London
#         ((40, -74, 0), (1, 2, 3), 2, 2),  # New York
#         ((37, -122, 0), (1, 2, 2), 3, 3)  # San Francisco
#     ]
#     i = 0
#     for ((x, y, z), env, act, reward) in location:
#         i = i + 1
#         data_unit = ((x, y, z), env, act, reward)
#         tree.add_data(data_unit)
#         if i >= 3:
#             break

#     state = (40.1, -74.1, 0)
#     result = tree.search(state)

#     # 输出结果
#     print(result)