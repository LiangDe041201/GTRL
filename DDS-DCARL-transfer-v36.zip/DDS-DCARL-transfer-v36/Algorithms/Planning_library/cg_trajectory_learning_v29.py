"""Trajectory learning with CG action zero as the behavioral baseline.

The geometry argmin is an observed proposal stratum only. It retains the old
state partition for auditable off-policy replay, never controls the default.
The uniform admissible reference is a neutral computational reference, not a
claim about CG confidence. KL and soft Bellman remain enabled.
"""
import json
import math

import numpy as np

from Planning_library.rolling_learning_v24 import RollingLearner


class CGTrajectoryLearnerV29(RollingLearner):
    SCHEMA='cg_trajectory_learning_v29'
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for key,node in self.nodes.items():
            parts=json.loads(key);allowed=node['allowed']
            expected=np.zeros(len(self.ACTION_NAMES));expected[allowed]=1./len(allowed)
            if (len(parts)!=4 or len(parts[0])!=16 or parts[3]!=allowed or 0 not in allowed
                    or node['default']!=0 or node.get('proposal_geometry_stratum')!=parts[2]
                    or parts[2] not in allowed or not np.allclose(node['prior'],expected,atol=1.e-12,rtol=0.)):
                raise ValueError('Invalid CG baseline, proposal stratum or reference')

    def signature(self):
        return dict(super().signature(),schema=self.SCHEMA,baseline_action=0,
            reference_policy='uniform_admissible_v29',
            state_partition='v24_physical_beta_proposal_geometry_stratum_mask',
            proposal_geometry_stratum='argmin_cost_context_only',
            information_units='utility_per_option_decision',confidence_guarantee=False)

    def begin(self,context,beta,default,allowed,costs,episode):
        x=np.asarray(context,dtype=float);costs=np.asarray(costs,dtype=float)
        allowed=sorted(set(int(a) for a in allowed))
        a,b=float(beta['alpha']),float(beta['beta'])
        count=len(self.ACTION_NAMES)
        if (int(default)!=0 or 0 not in allowed or x.shape!=(16,) or not np.isfinite(x).all()
                or costs.shape!=(count,) or not np.isfinite(costs).all()
                or any(v<0 or v>=count for v in allowed) or min(a,b)<1. or not math.isfinite(a+b)):
            raise ValueError('CG action zero and finite admissible trajectory context required')
        stratum=min(allowed,key=lambda action:(costs[action],action))
        mean,var=a/(a+b),a*b/((a+b)**2*(a+b+1.))
        key=json.dumps([np.rint(x/self.WIDTHS).astype(int).tolist(),
            [int(round(mean*4)),int(round(var/.02))],stratum,allowed],separators=(',',':'))
        if key not in self.nodes:
            prior=np.zeros(count);prior[allowed]=1./len(allowed)
            self.nodes[key]=dict(context=x.tolist(),beta=dict(alpha=a,beta=b),default=0,
                proposal_geometry_stratum=stratum,allowed=allowed,prior=prior.tolist())
            self.q[key]=np.zeros(count)
        self._close(key)
        self.current,self.episode=key,int(episode)
        self.context=x.tolist();self.beta=dict(alpha=a,beta=b)
        self.iterate(3)
        return key

    def choose(self,epsilon=0.,rng=None):
        action=super().choose(epsilon,rng)
        if self.last['source']=='fixed_default':self.last['source']='cg_default'
        self.last.update(baseline_action=0,reference_policy='uniform_admissible_v29',
            proposal_geometry_stratum=self.nodes[self.current]['proposal_geometry_stratum'])
        return action
