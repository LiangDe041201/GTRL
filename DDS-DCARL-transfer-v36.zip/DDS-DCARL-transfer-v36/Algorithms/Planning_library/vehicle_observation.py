"""Shared observable vehicle interface; no simulator decisions or private types.

CARLA actors, DynamicMap vehicles and VehicleState snapshots use different ID
names. All planners resolve identity here and consume the same motion evidence.
"""
import math

from Planning_library.rv_decision import idm_acceleration


def _get(vehicle, name, default=None):
    return vehicle.get(name, default) if isinstance(vehicle, dict) else getattr(vehicle, name, default)


def _finite(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def vehicle_id(vehicle):
    """Return a nonnegative actor identity, or None; never pool unknown actors."""
    for name in ('veh_id', 'carla_id', 'actor_id', 'id'):
        value = _get(vehicle, name)
        if isinstance(value, bool):
            continue
        number = _finite(value)
        if number is not None and number >= 0. and number.is_integer():
            return int(number)
    return None


def longitudinal_acceleration(vehicle):
    """Measured scalar acceleration, or projected measured ax/ay; None if absent."""
    acc = _finite(_get(vehicle, 'acc'))
    if acc is not None:
        return acc
    if _get(vehicle, 'acc_source') == 'unavailable':
        return None  # DynamicMap's legacy zero ax/ay defaults are not evidence.
    ax, ay = _finite(_get(vehicle, 'ax')), _finite(_get(vehicle, 'ay'))
    if ax is None or ay is None:
        return None
    vx, vy = _finite(_get(vehicle, 'vx')), _finite(_get(vehicle, 'vy'))
    speed = math.hypot(vx or 0., vy or 0.)
    if speed > 1e-6:
        return ((vx or 0.) * ax + (vy or 0.) * ay) / speed
    yaw = _finite(_get(vehicle, 'yaw'))
    return None if yaw is None else ax * math.cos(yaw) + ay * math.sin(yaw)


def motion_observation(vehicle, slow_threshold):
    """Three observable bins: braking/slow=0, steady=1, accelerating=2."""
    acc = longitudinal_acceleration(vehicle)
    speed = _finite(_get(vehicle, 'v'))
    if (acc is not None and acc < -.3) or (speed is not None and speed < slow_threshold):
        return 0
    return 2 if acc is not None and acc > .3 else 1


def vehicle_size(vehicle, dimension, default):
    value = _finite(_get(vehicle, dimension))
    if value is None or value <= 0.:
        value = _finite(_get(vehicle, 'boxx' if dimension == 'length' else 'boxy'))
    return value if value is not None and value > 0. else float(default)


class MotionHistory:
    """Finite differences of observed velocity using simulation seconds only.

    Duplicate reads of a frame reuse its estimate. Missing/reversed time, first
    sightings and reappearing actors never manufacture a zero acceleration.
    """
    def __init__(self):
        self.reset()

    def reset(self):
        self.previous = {}
        self.timestamp = None

    def update(self, vehicles, timestamp):
        timestamp = _finite(timestamp)
        if timestamp is None or (self.timestamp is not None and timestamp < self.timestamp):
            self.reset()
        current = {}
        for vehicle in vehicles:
            vehicle.acc, vehicle.acc_source = None, 'unavailable'
            vehicle.ax = vehicle.ay = 0.
            actor = vehicle_id(vehicle)
            vx, vy = _finite(_get(vehicle, 'vx')), _finite(_get(vehicle, 'vy'))
            if timestamp is None or actor is None or vx is None or vy is None:
                continue
            previous = self.previous.get(actor)
            if previous is not None:
                elapsed = timestamp - previous[0]
                if elapsed > 1e-9:
                    vehicle.ax = (vx-previous[1]) / elapsed
                    vehicle.ay = (vy-previous[2]) / elapsed
                    vehicle.acc_source = 'velocity_difference'
                    vehicle.acc = longitudinal_acceleration(vehicle)
                elif elapsed == 0. and (vx, vy) == previous[1:3]:
                    vehicle.ax, vehicle.ay, vehicle.acc, vehicle.acc_source = previous[3:]
            current[actor] = (timestamp, vx, vy, vehicle.ax, vehicle.ay,
                              vehicle.acc, vehicle.acc_source)
        self.previous, self.timestamp = current, timestamp


def following_acceleration(rv, vehicles, v0=6., T=.5, g0=2., a=2., b=2.5):
    """Declared IDM prediction from visible geometry, not an RV internal value.

    Select the nearest vehicle ahead in the RV's travel corridor. Other travel
    directions are excluded. Parameters are public modelling assumptions.
    """
    if rv is None:
        return None
    yaw = float(_get(rv, 'yaw', 0.))
    vx, vy = float(_get(rv, 'vx', 0.)), float(_get(rv, 'vy', 0.))
    speed = math.hypot(vx, vy)
    ux, uy = (vx/speed, vy/speed) if speed > .1 else (math.cos(yaw), math.sin(yaw))
    nearest, gap = None, float('inf')
    for other in vehicles:
        if other is rv or (vehicle_id(rv) is not None and vehicle_id(other) == vehicle_id(rv)):
            continue
        dx = float(_get(other, 'x'))-float(_get(rv, 'x'))
        dy = float(_get(other, 'y'))-float(_get(rv, 'y'))
        along, lateral = dx*ux+dy*uy, abs(-dx*uy+dy*ux)
        if along <= 0. or math.cos(float(_get(other, 'yaw', 0.))-yaw) < .5:
            continue
        if lateral > .5*(vehicle_size(rv, 'width', 2.)+vehicle_size(other, 'width', 2.))+.5:
            continue
        candidate = along-.5*(vehicle_size(rv, 'length', 4.)+vehicle_size(other, 'length', 4.))
        if candidate < gap:
            nearest, gap = other, candidate
    v = max(float(_get(rv, 'v')), 0.)
    front_v = v if nearest is None else max(float(_get(nearest, 'v')), 0.)
    return idm_acceleration(v, front_v, gap, v0=v0, T=T, g0=g0, a=a, b=b)
