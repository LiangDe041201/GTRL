"""Shared final audit with explicit stop admissibility and candidate retention."""
import math

from Planning_library.boundary_safety import wait_standoff
from Planning_library.execution_guard import clearance,path_steering,execution_forecast
from Planning_library.forecast_v18 import checked_prefix,predict
from Planning_library.vehicle_observation import vehicle_size


def select_execution(ego,objects,path,nominal,proposed_a,proposed_delta,previous,geometry,
                     prediction=None,prediction_times=None,plan=None,solve_ok=True,
                     allow_clear=True,alternative=None,stop_after=None):
    candidates = []
    geometry = dict(geometry,max_steer=min(1.,geometry['max_steer']))

    def evaluate(name,a,delta,target,pred=None,times=None,controls=None):
        gaps,forecasts = [],[]
        prefix_stop=stop_after if name=='mpc' else None
        if pred is not None:
            states,ts=checked_prefix(pred,times,prefix_stop)
            gaps.append(clearance(states,ts,objects,ego,geometry=geometry))
        for lag in (0.,.4):
            options=dict(horizon=geometry.get('execution_horizon',6.),lag=lag,plan=controls,plan_times=times)
            if prefix_stop is None:
                states,ts,diag=execution_forecast(ego,path,target,a,delta,previous,geometry,**options)
            else:
                states,ts,diag=predict(ego,path,target,a,delta,previous,geometry,stop_after=prefix_stop,**options)
            gaps.append(clearance(states,ts,objects,ego,geometry=geometry))
            forecasts.append(diag)
        gap,actor = min(gaps,key=lambda pair:pair[0])
        valid = all(d['valid'] for d in forecasts)
        stop_feasible = all(d['stop_before_band'] for d in forecasts)
        admissible = valid and stop_feasible
        result = dict(action=name,a=float(a),delta=float(delta),target=float(target),
            gap=float(gap),actor=actor,safe=bool(gap>=.2 and admissible),
            forecast_valid=bool(valid),stop_feasible=bool(stop_feasible),
            admissible=bool(admissible),forecasts=forecasts)
        candidates.append(result)
        return result

    def audit(selected,proposal):
        return selected,dict(action=selected['action'],safe=selected['safe'],
            unavoidable=not any(c['safe'] for c in candidates),override=selected['action']!='mpc',
            proposed_gap=None if proposal is None else proposal['gap'],candidates=candidates)

    proposal = None
    if solve_ok:
        proposal = evaluate('mpc',proposed_a,proposed_delta,nominal,prediction,prediction_times,plan)
        if proposal['safe']:
            return audit(proposal,proposal)
    steering = path_steering(ego.x,ego.y,ego.yaw,ego.v,path,geometry['wheelbase'],geometry['max_steer'])
    steering = max(previous['df']-.045,min(previous['df']+.045,steering))
    brake = evaluate('brake',-min(2.,max(.3,ego.v*1.5)),steering,0.)
    if allow_clear and stop_after is None:
        if alternative is not None and alternative['solve_ok'] and alternative['target']>.01:
            evaluate('clear',alternative['a'],alternative['delta'],alternative['target'],
                alternative.get('prediction'),alternative.get('times'),alternative.get('plan'))
        elif nominal>.01:
            evaluate('clear',1.2 if ego.v<nominal else 0.,steering,nominal)
    safe = [c for c in candidates if c['safe']]
    valid = [c for c in candidates if c['forecast_valid']]
    outside = wait_standoff(ego.x,ego.y,ego.yaw,vehicle_size(ego,'length',4.5),
                            vehicle_size(ego,'width',2.),-138.,1.)>0.
    if not valid:
        selected = brake
    elif outside and brake['safe']:
        selected = brake
    elif safe:
        selected = max(safe,key=lambda c:(c['gap'],c['action']=='clear'))
    else:
        # A stop inside the band is not an admissible normal retreat, but its
        # braking can still reduce collision penetration when every option is
        # unsafe. Never discard it solely to prefer an unsafe proceed request.
        selected = max(valid,key=lambda c:(c['gap'],c['action']=='brake'))
    return audit(selected,proposal)
