#!/usr/bin/env python3
"""
间隙前/后车识别与二维边界度量（纯 numpy/math，无 CARLA 依赖，离线可对拍）。

对标论文 ADVEI-D-26-08155（创新点④）的语义映射：
  rv（间隙后车）: ego 切入其前方、t_veh >= t_ego 且 |t_veh - t_ego| 最小的直行车
                 —— ego 的"后向"安全约束（它需让行/减速），对应论文 RV；
  fv（间隙前车）: ego 之前通过冲突点（t_veh < t_ego）且 |t_ego - t_veh| 最小的直行车
                 —— ego 的"前向"安全约束（跟在它后面），对应论文 FV。

与 CARLA 侧 crossing_conflict_detail 的既有语义保持一致：
  - 仅评估 |veh.y - cross_y| <= 8.0 的交叉车辆；
  - 仅统计正在接近冲突点的车辆（vx * sign(cross_x - veh.x) >= 0，速度方向指向冲突点）；
  - t_veh = |veh.x - cross_x| / max(veh.v, 0.1)。
"""
import math
import os
from typing import Dict

import numpy as np

from Planning_library.boundary_safety import boundary_metrics, lcttc_over_horizon
from Planning_library.scenario_snapshot import VehicleState, ScenarioSnapshot

#: 与 crossing_conflict_detail 一致：只评估交叉道路附近（±8m）的车辆
_Y_WINDOW = 8.0

#: 【P2-a】rv/fv 角色划分口径：
#:   'plan'（默认）= 用**计划车速**算出的到达时间 t_plan（自车减速不再改变对手集合）
#:   'time'        = 旧口径（用瞬时 t_ego，可被"减速把对手变没"套利，仅用于复现旧实验）
ROLE_MODE_DEFAULT = os.environ.get('DSH_ROLE_MODE', 'plan')


def _t_veh(veh: VehicleState, conflict_x: float) -> float:
    """直行车到达冲突点的时间（与 CARLA 侧公式一致）。"""
    return abs(float(veh.x) - conflict_x) / max(float(veh.v), 0.1)


def _approaching(veh: VehicleState, conflict_x: float) -> bool:
    """是否正在接近冲突点（速度方向指向冲突点，与旧循环语义一致）。"""
    sx = math.copysign(1.0, conflict_x - float(veh.x))
    vx = float(getattr(veh, "vx", 0.0))
    if abs(vx) < 0.1:
        vx = float(veh.v) * math.cos(float(veh.yaw))
    return vx * sx >= 0.0


# ============================================================
# 【P0-step0 验证】折线连续投影：把"路点量化弧长"换成"插值连续弧长"
# ============================================================
#: 参考路径的加密分辨率（TestScenario_Town03_turn.py: dense_polyline2d(ref_path_ori, 2)）
PATH_RESOLUTION_M = 2.0


def polyline_cumlen(path):
    """折线各顶点的累计弧长（长度 N，`s[0] = 0`）。"""
    p = np.asarray(path, dtype=float)
    if p.ndim != 2 or len(p) == 0:
        return np.zeros(0, dtype=float)
    if len(p) == 1:
        return np.zeros(1, dtype=float)
    seg = np.linalg.norm(np.diff(p, axis=0), axis=1)
    return np.concatenate([[0.0], np.cumsum(seg)])


def project_point_on_polyline(path, x, y, cumlen=None):
    """把点 (x, y) **连续投影**到折线上，返回沿折线的插值弧长与横向偏差。

    返回 dict:
      s      沿折线的连续弧长（m，从 path[0] 起算）
      lat    点到折线的垂直距离（m，>= 0；即"横向偏差"）
      seg    命中段号（投影落在 path[seg]~path[seg+1] 上）
      t      段内参数 [0,1]
      proj   (px, py) 投影点
      ok     False 表示输入非法（此时 s=0, lat=inf）

    【为什么要它 / 这是本步要验证的假设】
    `crossing_conflict_detail` 现在算 `arc_to_cross` 用的是"最近**路点**下标 × 路点间距"，
    而参考路径是 `dense_polyline2d(ref_path_ori, 2)` 按 2 m 加密的 ⇒ 该弧长**被量化成
    2.045 m 的整数倍**（实测一次 20 回合运行里只有 14 个取值）。
    于是"自车是否已越过停止线/回退位"这类亚米级判断，建立在 2 m 量化的坐标上：
    同一 `arc_to_cross` 下自车的**物理位置**实测可差 2~3 m（`arc=10.22` 时
    `ego_y` 从 -137.31 到 -134.47）。

    本函数把点投到**线段**上并按段内参数插值，故弧长连续；同时吐出横向偏差，
    用于区分"量化误差"与"自车横向偏离参考路径"这两种都会让弧长失真的原因。
    """
    p = np.asarray(path, dtype=float)
    if p.ndim != 2 or len(p) == 0:
        return {'s': 0.0, 'lat': float('inf'), 'seg': 0, 't': 0.0, 'proj': None, 'ok': False}
    q = np.array([float(x), float(y)], dtype=float)
    if len(p) == 1:
        return {'s': 0.0, 'lat': float(np.linalg.norm(q - p[0])), 'seg': 0, 't': 0.0,
                'proj': (float(p[0, 0]), float(p[0, 1])), 'ok': True}

    a = p[:-1]
    ab = p[1:] - a
    seg_len = np.linalg.norm(ab, axis=1)
    denom = np.where(seg_len < 1e-12, 1e-12, seg_len)
    # 段内参数 t = clamp( (q-a)·ab / |ab|² , 0, 1 )
    t = np.einsum('ij,ij->i', q - a, ab) / (denom ** 2)
    t = np.clip(t, 0.0, 1.0)
    proj = a + t[:, None] * ab
    d = np.linalg.norm(q - proj, axis=1)
    k = int(np.argmin(d))
    if cumlen is None:
        cumlen = polyline_cumlen(p)
    s = float(cumlen[k]) + float(t[k]) * float(seg_len[k])
    return {'s': s, 'lat': float(d[k]), 'seg': k, 't': float(t[k]),
            'proj': (float(proj[k, 0]), float(proj[k, 1])), 'ok': True}


def identify_gap_vehicles(snap: ScenarioSnapshot, role_mode: str = ROLE_MODE_DEFAULT) -> Dict:
    """
    识别间隙前/后车并统计冲突信息。

    返回 dict:
      rv / fv       VehicleState 或 None（无对应车辆）
      rv_t_veh      rv 到达冲突点时间（s，无 rv 则 inf）
      fv_t_veh      fv 到达冲突点时间（s，无 fv 则 inf）
      t_veh_min     所有接近车辆的最小到达时间（s，无则 inf）
      n_vehicles    参与评估的接近车辆数
      game_active   【P2-b】博弈是否进行中（未越过冲突点 且 窗口内存在接近车）
      t_plan        本帧角色划分所用的"计划到达时间"（s）

    【P2-a 为什么角色划分不能用瞬时 `t_ego`】
      `t_ego = arc / max(ego.v, 0.1)`，自车一减速 `t_ego → ∞`，于是判据
      `t_veh >= t_ego` 对**所有**交叉车都成立 → 全部归入 fv → **rv 角色为空**。
      后果有两个，都实测到了：① 博弈在状态层面静默消失（`lcttc_rv = inf`）；
      ② `rv` 为空使 `THW_boundary = inf`，被奖励当成"最安全"发满额安全分
      （P1-f 奖励劫持，实测 +20.41/帧 × 150 帧）。
      而"自车想开多慢"不该改变"谁是我的对手"——论文的 game 是否进行由 **LCV 质心
      是否越过车道线** 决定，对手集合由空间位置决定。
      故 role_mode='plan'（默认）使用 `snap.t_plan()`（计划车速算出的到达时间）。
      role_mode='time' 保留旧口径，仅用于复现历史实验。
    """
    conflict_x, conflict_y = snap.conflict_xy
    _t_split = snap.t_plan() if str(role_mode).lower() != "time" else float(snap.t_ego)
    rv, fv = None, None
    rv_dt, fv_dt = float("inf"), float("inf")
    t_veh_min, n_vehicles = float("inf"), 0
    t_veh_list = []
    for veh in snap.vehicles:
        if abs(float(veh.y) - conflict_y) > _Y_WINDOW:
            continue
        if not _approaching(veh, conflict_x):
            continue
        # 【P2-b】空间交互窗口：离冲突点太远的车不参与博弈（与自车速度无关）
        if abs(float(veh.x) - conflict_x) > float(snap.game_window):
            continue
        t_veh = _t_veh(veh, conflict_x)
        n_vehicles += 1
        t_veh_min = min(t_veh_min, t_veh)
        if t_veh >= _t_split:
            dt = t_veh - _t_split
            if dt < rv_dt:
                rv_dt, rv = dt, veh
        else:
            dt = _t_split - t_veh
            if dt < fv_dt:
                fv_dt, fv = dt, veh
        t_veh_list.append(t_veh)
    t_veh_list.sort()
    # 【P2-b】博弈进行中的显式判定（论文：由 LCV 质心是否越过车道线决定 game 是否进行）：
    #   未越过冲突点 且 空间交互窗口内存在接近车。**不含**任何"自车当前速度"项，
    #   因此不会被"减速"套利。rv/fv 都为空时博弈也不成立（没有对手就没有博弈）。
    game_active = (not bool(snap.committed)) and n_vehicles > 0 and (rv is not None or fv is not None)
    return {"rv": rv, "fv": fv,
            "rv_t_veh": rv_dt if rv is not None else float("inf"),
            "fv_t_veh": fv_dt if fv is not None else float("inf"),
            "t_veh_min": t_veh_min, "n_vehicles": n_vehicles,
            "t_veh_sorted": t_veh_list,
            "game_active": bool(game_active), "t_plan": float(_t_split)}


def compute_gap_metrics(snap: ScenarioSnapshot, horizon=2.0, dt=0.1,
                        role_mode: str = ROLE_MODE_DEFAULT) -> Dict:
    """
    对 rv / fv 分别计算二维边界度量（车身矩形边界模型）。

    返回 dict:
      lcttc_rv / lcttc_fv        预测时域内最小边界 TTC（无对应车辆为 inf）
      thw_boundary_rv / thw_boundary_fv  边界 THW（无对应车辆为 inf）
      d_ab_rv / d_ab_fv          当前最小边界距离（无对应车辆为 inf）
      game_active                【P2-b】博弈是否进行中
      rv / fv                    识别出的车（VehicleState 或 None）
    """
    ego = snap.ego
    out = {"lcttc_rv": float("inf"), "lcttc_fv": float("inf"),
           "thw_boundary_rv": float("inf"), "thw_boundary_fv": float("inf"),
           "d_ab_rv": float("inf"), "d_ab_fv": float("inf"),
           "game_active": False, "rv": None, "fv": None}
    ids = identify_gap_vehicles(snap, role_mode=role_mode)
    out["game_active"] = bool(ids.get("game_active", False))
    out["rv"] = ids.get("rv")
    out["fv"] = ids.get("fv")
    for key in ("rv", "fv"):
        veh = ids[key]
        if veh is None:
            continue
        ego_v = max(float(ego.v), 0.0)
        veh_v = max(float(veh.v), 0.0)
        bm = boundary_metrics(ego.x, ego.y, ego.yaw, ego_v,
                              veh.x, veh.y, veh.yaw, veh_v,
                              dt=dt, ego_len=ego.length, ego_wid=ego.width,
                              veh_len=veh.length, veh_wid=veh.width)
        L = lcttc_over_horizon(ego.x, ego.y, ego.yaw, ego_v,
                               veh.x, veh.y, veh.yaw, veh_v,
                               horizon=horizon, dt=dt,
                               ego_len=ego.length, ego_wid=ego.width,
                               veh_len=veh.length, veh_wid=veh.width)
        out[f"lcttc_{key}"] = L["lcttc"]
        out[f"thw_boundary_{key}"] = bm["thw_boundary"]
        out[f"d_ab_{key}"] = bm["d_ab"]
    return out


def fv_rv_spatial_gap(ids, veh_len_default: float = 4.0):
    """【论文式62 的 g_d】FV–RV 沿目标车道的**空间净间隙（米）**。

    论文原文（§VI-A）："the objective is defined as traffic efficiency, measured by the
    **gap length** between the front vehicle's FV and the rear vehicle's RV"；式62 的分段
    断点是 2.5 / 3.5 / 5.0 / 7.0，量纲是**米**（间隙长度），式63 的 g_rate 是
    "the rate of change of the gap at the simulation interval (0.05 s)"。

    几何（西向车流，x 递减；冲突点 x=x_c，两车都还在冲突点以东）：
      FV 先通过（更靠近冲突点 → x 更小），RV 在其后（x 更大）
      g_d = (x_RV − L/2) − (x_FV + L/2) = x_RV − x_FV − L
    返回 None 表示博弈不在进行中（FV 或 RV 缺失）。
    若两者重叠（g_d < 0）按实际负值返回——负间隙本身就是"不可插入"的真实信号。
    """
    rv, fv = ids.get("rv"), ids.get("fv")
    if rv is None or fv is None:
        return None
    L = 0.5 * (float(getattr(rv, "length", veh_len_default))
               + float(getattr(fv, "length", veh_len_default)))
    return float(rv.x) - float(fv.x) - L
