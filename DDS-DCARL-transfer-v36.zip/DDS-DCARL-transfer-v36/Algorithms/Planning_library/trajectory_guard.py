"""Geometry validation and final execution limits, independent of CARLA."""
import math

import numpy as np


def clean_path(path, min_spacing=.02, min_length=.5):
    """Reject invalid/collapsed geometry and remove consecutive duplicate points."""
    try:
        points = np.asarray(path, dtype=float)
    except (TypeError, ValueError):
        return None
    if (points.ndim != 2 or len(points) < 2 or points.shape[1] < 2 or
            not np.all(np.isfinite(points[:, :2]))):
        return None
    points = points[:, :2]
    kept = [points[0]]
    for point in points[1:]:
        if np.linalg.norm(point - kept[-1]) >= min_spacing:
            kept.append(point)
    points = np.asarray(kept)
    if len(points) < 2 or np.linalg.norm(np.diff(points, axis=0), axis=1).sum() < min_length:
        return None
    if len(points) == 2:
        points = np.vstack((points[0], .5 * (points[0] + points[1]), points[1]))
    return points


def road_geometry(reference, ego_x, ego_y, extension=8.):
    """Project onto the road and provide noncollapsed forward geometry.

    The tangent extension is only for steering geometry. It never grants motion
    beyond the destination; final goal and stop limits govern the speed.
    """
    road = clean_path(reference)
    if road is None:
        return None
    tangent = road[-1] - road[-2]
    tangent /= np.linalg.norm(tangent)
    tail = road[-1] + np.arange(.5, extension + .01, .5)[:, None] * tangent
    road = np.vstack((road, tail))
    segments = np.diff(road, axis=0)
    point = np.asarray([ego_x, ego_y], dtype=float)
    fractions = np.clip(np.sum((point - road[:-1]) * segments, axis=1) /
                        np.sum(segments ** 2, axis=1), 0., 1.)
    projections = road[:-1] + fractions[:, None] * segments
    nearest = int(np.argmin(np.linalg.norm(projections - point, axis=1)))
    return clean_path(np.vstack((projections[nearest], road[nearest + 1:])))


def execution_speed(requested, trajectory, ego_x, ego_y, goal_pose=None):
    """Apply fallback/goal limits after all rule and game speed increases."""
    speed = max(float(requested), 0.)
    reasons = []
    remaining = None
    if trajectory is None:
        return 0., 'missing_trajectory', remaining
    if bool(getattr(trajectory, 'force_stop', False)):
        speed = 0.
        reasons.append('planner_stop')
    limit = getattr(trajectory, 'speed_limit', None)
    if limit is not None:
        limit = float(limit)
        if not math.isfinite(limit) or limit < 0.:
            return 0., 'invalid_planner_limit', remaining
        if limit < speed:
            speed = limit
            reasons.append('planner_limit')
    if goal_pose is not None:
        gx, gy, heading = goal_pose
        dx, dy = float(gx) - ego_x, float(gy) - ego_y
        remaining = dx * math.cos(heading) + dy * math.sin(heading)
        if math.hypot(dx, dy) < 12. or remaining <= 0.:
            # Comfortable deceleration 1.5 m/s²; hold before crossing the goal plane.
            goal_limit = math.sqrt(3. * max(remaining - .5, 0.))
            if goal_limit < speed:
                speed = goal_limit
                reasons.append('goal_approach' if goal_limit > 0. else 'goal_hold')
    return speed, ';'.join(reasons), remaining


def execution_acceleration(requested, speed, target_speed):
    """Keep the final acceleration within the model/actuator contract.

    A zero target requires braking/holding even if the optimizer's slew limit
    still asks for positive acceleration. The actual command is fed back to MPC.
    """
    command = float(np.clip(requested, -3., 2.))
    if target_speed <= .01:
        return min(command, -min(3., max(.3, float(speed) * 1.5)))
    if speed > target_speed + .5 and command > 0.:
        command = 0.
    if speed > target_speed + 2.:
        command = min(command, -.8)
    return command
