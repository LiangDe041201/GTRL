"""Same 2x2 expected response, corrected road/recovery prediction inputs."""
from Planning_library.forecast_v17 import predict
from Planning_library.matrix_motion_v14 import rv_action_track
from Planning_library.matrix_turn_game_v16 import MatrixTurnGameV16, score_candidates as base_score
from Planning_library.opponent_forecast_v17 import tracks


def opponent_tracks(vehicle, objects, times, cruise, primary, column, acceleration):
    if primary and column == 1:
        return [rv_action_track(vehicle, objects, times, cruise, True, acceleration=acceleration)]
    return tracks(vehicle, times, cruise=cruise)


def score_candidates(*args, **kwargs):
    return base_score(*args, ego_predict=predict, track_provider=opponent_tracks, **kwargs)


class MatrixTurnGameV17(MatrixTurnGameV16):
    revision = 'matrix_entry_v17'
    forecast_revision = 'route_v17'
    controller = 'matrix_v17'
    scorer = staticmethod(score_candidates)
