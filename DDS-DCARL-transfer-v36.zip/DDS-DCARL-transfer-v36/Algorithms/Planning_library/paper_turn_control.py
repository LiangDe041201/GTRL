"""v7 left-turn deployment: deterministic feasibility, no hidden opponent policy.

This is an explicit left-turn adaptation, not the paper authors' unpublished
controller. RULE and CG share geometry, observations and execution protection.
"""
import math

from Planning_library.vehicle_observation import vehicle_id, vehicle_size


def rectangle_gap(x, y, yaw, length, width, ox, oy, oyaw, olen, owid):
    """Signed separating-axis clearance; positive means disjoint rectangles."""
    axes = (yaw, yaw + math.pi/2, oyaw, oyaw + math.pi/2)
    gaps = []
    for angle in axes:
        nx, ny = math.cos(angle), math.sin(angle)
        radius = (length/2*abs(math.cos(yaw-angle)) + width/2*abs(math.sin(yaw-angle))
                  + olen/2*abs(math.cos(oyaw-angle)) + owid/2*abs(math.sin(oyaw-angle)))
        gaps.append(abs((ox-x)*nx + (oy-y)*ny)-radius)
    return max(gaps)


def symbolic_interaction_cost(x, y, yaw, speed, other, ego_size, margin=.5):
    """Relative closing risk remains active when ego speed is zero.

    Four-axis rectangle clearance replaces ego-speed-only THW in v7. This is
    a soft preference, not a collision certificate. Future positions are
    evaluated along optimized ego dynamics and observed CV opponent forecasts.
    """
    import casadi as ca
    ox, oy, oyaw, olen, owid, vx, vy = other
    gaps = []
    for angle in (yaw, yaw+math.pi/2, oyaw, oyaw+math.pi/2):
        radius = (ego_size[0]/2*ca.fabs(ca.cos(yaw-angle))
                  + ego_size[1]/2*ca.fabs(ca.sin(yaw-angle))
                  + olen/2*ca.fabs(ca.cos(oyaw-angle))
                  + owid/2*ca.fabs(ca.sin(oyaw-angle)))
        gaps.append(ca.fabs((ox-x)*ca.cos(angle)+(oy-y)*ca.sin(angle))-radius)
    gap = gaps[0]
    for value in gaps[1:]:
        gap = ca.fmax(gap, value)
    distance = ca.sqrt((ox-x)**2+(oy-y)**2+1e-6)
    closing = ca.fmax(((speed*ca.cos(yaw)-vx)*(ox-x)
                      +(speed*ca.sin(yaw)-vy)*(oy-y))/distance, 0.)
    return 10.*ca.fmax((margin + .8*closing-gap)/2., 0.)**2


def smooth_interaction_cost(x, y, yaw, speed, other, ego_size, margin=.5):
    """v8 differentiable preference; exact SAT remains the execution checker.

    Smoothed max is offset downwards so it does not overstate separation.
    This improves the optimization surface without relaxing the exact audit.
    """
    import casadi as ca
    ox, oy, oyaw, olen, owid, vx, vy = other
    absolute = lambda z: ca.sqrt(z*z+1e-6)
    positive = lambda z: .5*(z+ca.sqrt(z*z+.02**2))
    gaps = []
    for angle in (yaw, yaw+math.pi/2, oyaw, oyaw+math.pi/2):
        radius = (ego_size[0]/2*absolute(ca.cos(yaw-angle))
                  + ego_size[1]/2*absolute(ca.sin(yaw-angle))
                  + olen/2*absolute(ca.cos(oyaw-angle))
                  + owid/2*absolute(ca.sin(oyaw-angle)))
        gaps.append(absolute((ox-x)*ca.cos(angle)+(oy-y)*ca.sin(angle))-radius)
    gap = gaps[0]
    for value in gaps[1:]:
        gap = .5*(gap+value+ca.sqrt((gap-value)**2+.02**2))-.01
    distance = ca.sqrt((ox-x)**2+(oy-y)**2+1e-6)
    closing = positive(((speed*ca.cos(yaw)-vx)*(ox-x)
                        +(speed*ca.sin(yaw)-vy)*(oy-y))/distance)
    return 10.*positive((margin+.8*closing-gap)/2.)**2


def nearby_vehicles(objects, ego, limit=6):
    """Keep observed threats independent of FV/RV and scalar conflict crossing.

    Rank by future rectangle proximity, then ID. No vehicle is discarded merely
    because its centre has passed conflict_x. Full gate checks remain uncapped.
    """
    found = {}
    for index, v in enumerate(objects):
        actor = vehicle_id(v)
        if actor is not None and actor == vehicle_id(ego):
            continue
        if actor is None and limit is not None:
            continue  # Unknown identities are still checked by the full gate.
        if math.hypot(v.x-ego.x, v.y-ego.y) > 45.:
            continue
        vx, vy = motion(v)
        score = min(rectangle_gap(ego.x+ego.v*math.cos(ego.yaw)*t,
                    ego.y+ego.v*math.sin(ego.yaw)*t, ego.yaw,
                    vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.),
                    v.x+vx*t, v.y+vy*t, v.yaw,
                    vehicle_size(v, 'length', 4.), vehicle_size(v, 'width', 2.))
                    for t in (0., .5, 1., 2.))
        identity = actor if actor is not None else ('unidentified', index)
        found[identity] = (score, str(identity), v)
    ordered = [item[2] for item in sorted(found.values(), key=lambda z: z[:2])]
    return ordered if limit is None else ordered[:limit]


def motion(vehicle):
    vx, vy = getattr(vehicle, 'vx', None), getattr(vehicle, 'vy', None)
    if vx is None or vy is None:
        vx, vy = vehicle.v*math.cos(vehicle.yaw), vehicle.v*math.sin(vehicle.yaw)
    values = (float(vx), float(vy))
    if not all(math.isfinite(v) for v in values):
        raise ValueError('Nonfinite observed vehicle velocity')
    return values


def motion_forecast(vehicle, times):
    if vehicle is None:
        return [[1000., 1000., 0., 4., 2., 0., 0.] for _ in times]
    vx, vy = motion(vehicle)
    return [[vehicle.x+vx*t, vehicle.y+vy*t, vehicle.yaw,
             vehicle_size(vehicle, 'length', 4.), vehicle_size(vehicle, 'width', 2.), vx, vy]
            for t in times]


def baseline_geometry_cost(path):
    """Eq.49-style geometry/jerk score, without speed or interaction rewards."""
    import numpy as np
    x, y = np.asarray(path.x), np.asarray(path.y)
    if len(x) < 4 or not np.isfinite(np.r_[x, y]).all():
        return float('inf')
    dx, dy = np.gradient(x), np.gradient(y)
    ds = np.maximum(np.hypot(dx, dy), .05)
    yaw = np.unwrap(np.arctan2(dy, dx))
    curvature = np.gradient(yaw)/ds
    change = np.gradient(curvature)
    rate = change/ds
    def hinge(values, threshold):
        return np.sum(values**2*(1.+10.*(np.abs(values) > threshold)))
    jerk = np.asarray(getattr(path, 's_ddd', []), dtype=float)
    lateral = np.asarray(getattr(path, 'd_ddd', []), dtype=float)
    value = (hinge(curvature, .1)+2.*hinge(change, .02)+5.*hinge(rate, .01)
             + np.sum(jerk**2)+np.sum(lateral**2))
    return float(value) if math.isfinite(float(value)) else float('inf')


def prediction_clearance(states, times, objects, ego):
    """Audit actual optimized x/y/yaw against every observed nearby box."""
    minimum, actor = float('inf'), None
    for v in nearby_vehicles(objects, ego, limit=None):
        vx, vy = motion(v)
        for k, t in enumerate(times):
            gap = rectangle_gap(float(states[0, k]), float(states[1, k]),
                float(states[6, k]), vehicle_size(ego, 'length', 4.5),
                vehicle_size(ego, 'width', 2.), v.x+vx*t, v.y+vy*t, v.yaw,
                vehicle_size(v, 'length', 4.), vehicle_size(v, 'width', 2.))
            if gap < minimum:
                minimum, actor = gap, vehicle_id(v)
    return minimum, actor


class TurnFeasibility:
    """One deterministic CV occupancy gate and one episode-local state machine.

    Forecast stopping/launching with previous *applied* acceleration command;
    include release time and a .4 s actuation delay. No inferred yield labels,
    type posterior, Bernoulli probability, risk streak or force-launch timeout.
    """
    def __init__(self):
        self.reset()

    def reset(self):
        self.launched = False
        self.last = {}

    def target(self, ego, objects, path, nominal, standoff, previous_a, committed=False):
        nominal = max(float(nominal), 0.)
        sd = float(standoff)
        vehicles = nearby_vehicles(objects, ego, limit=None)
        ids = [vehicle_id(v) for v in vehicles]
        inside = sd <= 0.
        self.last = dict(profile='paper_v7', phase='approach', safe=True,
                         min_gap=None, threat_ids=ids, conflict_id=None)
        if sd > 18. and not committed:
            return nominal
        points = [(float(p[0]), float(p[1])) for p in path]
        if len(points) < 2:
            self.last.update(safe=False, phase='invalid_path')
            return 0.
        nearest = min(range(len(points)), key=lambda i: math.hypot(points[i][0]-ego.x, points[i][1]-ego.y))
        points = [(ego.x, ego.y)] + points[nearest+1:]
        if len(points) < 2:
            self.last.update(safe=False, phase='path_end')
            return 0.
        lengths = [math.hypot(b[0]-a[0], b[1]-a[1]) for a, b in zip(points, points[1:])]
        cumulative = [0.]
        for length in lengths:
            cumulative.append(cumulative[-1]+length)
        distance, speed, command, segment = 0., max(ego.v, 0.), float(previous_a), 0
        minimum, conflict = float('inf'), None
        for k in range(61):
            t = k*.1
            while segment+1 < len(lengths) and cumulative[segment+1] < distance:
                segment += 1
            fraction = min(1., max(0., (distance-cumulative[segment])/max(lengths[segment], 1e-6)))
            a, b = points[segment:segment+2]
            x, y = a[0]+fraction*(b[0]-a[0]), a[1]+fraction*(b[1]-a[1])
            yaw = math.atan2(b[1]-a[1], b[0]-a[0])
            for v in vehicles:
                vx, vy = motion(v)
                gap = rectangle_gap(x, y, yaw, vehicle_size(ego, 'length', 4.5),
                    vehicle_size(ego, 'width', 2.), v.x+vx*t, v.y+vy*t, v.yaw,
                    vehicle_size(v, 'length', 4.), vehicle_size(v, 'width', 2.))
                if gap < minimum:
                    minimum, conflict = gap, vehicle_id(v)
            if t >= .4:
                desired = 1. if speed < nominal-.1 else -1. if speed > nominal+.1 else 0.
                command += max(-.2, min(.2, desired-command))
            next_speed = max(0., speed+.1*command)
            distance += .05*(speed+next_speed)
            speed = next_speed
            if distance >= cumulative[-1]:
                break
        safe = minimum >= .35
        # Before entering, a newly unsafe prediction can cancel a launch. Once
        # inside, never create the historical stop-in-the-band failure mode.
        if not inside and not committed:
            self.launched = bool(safe)
        phase = 'clearing' if inside or committed else 'entering' if safe else 'waiting'
        self.last.update(safe=safe, phase=phase,
                         min_gap=None if math.isinf(minimum) else minimum,
                         conflict_id=conflict)
        if safe or inside or committed:
            return nominal
        # Shared physical braking envelope: conservative effective deceleration,
        # delay and two metres stand-off. This is not a learned strategic gate.
        slack = max(sd-2.-max(ego.v, 0.)*.4, 0.)
        return min(nominal, math.sqrt(2.*1.2*slack))


def reset_driving_state(agent):
    """Reset driving memory; deliberately preserve cross-episode learner data."""
    for key in ('_commit_latched', '_last_commit_latched', '_last_committing',
                '_yield_was_stopped', '_inside_band_now', '_last_entry_granted'):
        setattr(agent, key, False)
    for key in ('_latch_age', '_risk_ok_streak', '_last_risk_streak', '_stopped_frames'):
        setattr(agent, key, 0)
    for key in ('_last_wait_standoff', '_last_commit_risk', '_last_gap_ok',
                '_wait_arc_ep', '_wait_arc_val', '_band_entry_ep', '_band_entry_x'):
        setattr(agent, key, None)
    agent._last_commit_risk_fresh = False
    if hasattr(agent, 'turn_feasibility'):
        agent.turn_feasibility.reset()
