"""2x2 expected response with execution-aware, route-covered candidate scores.

RV motion hypotheses, utility weights, probability estimator and switch cost
are the frozen v14 definitions. This branch repairs ego candidate forecasts.
"""
import time

import numpy as np

from Planning_library.cournot_game import expected_payoff_response
from Planning_library.forecast_v16 import predict
from Planning_library.matrix_motion_v14 import rv_action_track
from Planning_library.matrix_turn_game import observable_tracks, rectangle_gaps
from Planning_library.matrix_turn_game_v14 import MatrixTurnGameV14
from Planning_library.paper_turn_control import nearby_vehicles
from Planning_library.vehicle_observation import vehicle_id


def score_candidates(ego, objects, rv, candidates, geometry, path, previous, cruise,
                     observed_acceleration=None, ego_predict=predict, track_provider=None,
                     track_context=False, horizon=6., mpc_check_horizon=None):
    threats = nearby_vehicles(objects, ego, limit=None)
    matrix, components = [], []
    for candidate in candidates:
        plans = [ego_predict(ego, path, candidate['target'], candidate['a'], candidate['delta'],
            previous, geometry, horizon=horizon, lag=lag, plan=candidate.get('plan'),
            plan_times=candidate.get('times')) for lag in (0., .4)]
        representative, times, diag = plans[-1]
        valid = all(p[2]['valid'] for p in plans)
        checked = [(states, t) for states, t, _ in plans]
        if candidate.get('solve_ok') and candidate.get('prediction') is not None:
            prediction,mpc_times=candidate['prediction'],candidate['times']
            if mpc_check_horizon is not None:
                prefix=mpc_times<=mpc_check_horizon+1.e-9
                prediction,mpc_times=prediction[:,prefix],mpc_times[prefix]
            checked.append((prediction,mpc_times))
        progress = diag['progress_m']/max(4.*float(times[-1]), 1.)
        stopped = float(np.mean(representative[5] < .1))
        body_acc = np.diff(representative[5])/np.diff(times)
        jerk = np.diff(body_acc)/np.diff(times)[1:]
        comfort = float(np.mean(np.minimum((jerk/3.)**2, 25.))) if len(jerk) else 0.
        actor_columns = [[], []]
        for other in threats:
            primary = rv is not None and vehicle_id(other) == vehicle_id(rv)
            for column in ((0, 1) if primary else (0,)):
                actor_risk, actor_min = 0., float('inf')
                for states, forecast_times in checked:
                    tracks = (track_provider(other,objects,forecast_times,cruise,primary,column,
                        observed_acceleration,ego=ego,states=states) if track_context else
                        track_provider(other, objects, forecast_times, cruise, primary, column,
                        observed_acceleration) if track_provider is not None else
                        [rv_action_track(other, objects, forecast_times, cruise, bool(column),
                        acceleration=observed_acceleration)] if primary
                        else observable_tracks(other, forecast_times))
                    for track in tracks:
                        gaps = rectangle_gaps(states, ego, other, track)
                        deficit = np.maximum((.5-gaps)/.5, 0.)
                        actor_risk = max(actor_risk, float(np.mean(deficit**2)+np.max(deficit**2)))
                        actor_min = min(actor_min, float(np.min(gaps)))
                part = dict(actor_id=vehicle_id(other), primary=primary, risk=actor_risk,
                    min_gap=None if np.isinf(actor_min) else actor_min)
                actor_columns[column].append(part)
                if not primary:
                    actor_columns[1].append(dict(part))
        row, parts = [], []
        for actors in actor_columns:
            risk = sum(actor['risk'] for actor in actors)
            gaps = [a['min_gap'] for a in actors if a['min_gap'] is not None]
            penalty = 0. if valid else 1000.
            utility = (progress-.25*stopped-.05*comfort-4.*risk-penalty
                       -(0. if candidate.get('solve_ok', False) else 1000.))
            row.append(float(utility))
            parts.append(dict(progress=progress, stopped_fraction=stopped, comfort=comfort,
                risk=risk, min_gap=min(gaps) if gaps else None, utility=float(utility),
                switch_cost=0., actors=actors, forecast_valid=bool(valid), forecast_penalty=penalty,
                forecasts=[dict(p[2]) for p in plans]))
        matrix.append(row); components.append(parts)
    return matrix, components


class MatrixTurnGameV16(MatrixTurnGameV14):
    revision = 'matrix_entry_v16'
    forecast_revision = 'route_v16'
    controller = 'matrix_v16'
    scorer = staticmethod(score_candidates)
    invalid_mode = 'all_forecasts_invalid'
    invalid_override_mode = 'forecast_failure_override'

    def candidate_usable(self,candidate,parts):
        return bool(candidate['solve_ok']) and parts[0]['forecast_valid']

    def __init__(self, geometry, **kwargs):
        if geometry.get('forecast_model') != self.forecast_revision:
            raise ValueError(self.controller+' requires the same forecast as RULE/guard')
        super().__init__(geometry, **kwargs)

    def prepare(self, *args, **kwargs):
        result = super().prepare(*args, **kwargs)
        self.last.update(controller=self.controller, ego_forecast_model=self.forecast_revision)
        return result

    def choose(self, ego, objects, rv, conf, candidates, path, previous):
        started = time.perf_counter()
        if not self.last['active']:
            selected = 1
        else:
            matrix, parts = self.scorer(ego, objects, rv, candidates, self.geometry, path,
                previous, self.cruise, self._motion_evidence.get('acceleration'))
            previous_action = self.last_action
            usable = [self.candidate_usable(c,parts[i])
                      for i, c in enumerate(candidates)]
            all_safe = all(c['risk'] <= 1e-12 for row in parts for c in row)
            if (previous_action is not None and self.last_rv == vehicle_id(rv)
                    and all_safe and all(usable)):
                penalized = 1-previous_action
                for j in range(2):
                    matrix[penalized][j] -= .03
                    parts[penalized][j].update(switch_cost=.03, utility=matrix[penalized][j])
                self.last['switch_penalty'] = .03
            result = expected_payoff_response(matrix, self.last['p_yield'])
            selected = result['ego_action']
            if not any(c['solve_ok'] for c in candidates):
                selected = 0; result['decision_mode'] = 'all_candidates_failed'
            elif not any(usable):
                selected = 0; result['decision_mode'] = self.invalid_mode
            elif not usable[selected]:
                selected = 1-selected
                result['decision_mode'] = ('optimizer_failure_override' if
                    not candidates[1-selected]['solve_ok'] else self.invalid_override_mode)
            d0, d1 = matrix[1][0]-matrix[0][0], matrix[1][1]-matrix[0][1]
            self.last.update(result, components=parts, selected=selected,
                switch=previous_action is not None and previous_action != selected,
                critical_yield_probability=-d0/(d1-d0) if abs(d1-d0) > 1e-12 else None,
                model_safe_proceed_while_defer=bool(selected == 0 and usable[1] and
                    all(c['risk'] <= 1e-12 for c in parts[1]) and
                    parts[1][0]['progress'] > parts[0][0]['progress']+.05 and ego.v < .1))
        self.last_action = selected if self.last['active'] else None
        self.last_rv = vehicle_id(rv) if self.last['active'] else None
        self.last.update(selected=selected, decision_ms=(time.perf_counter()-started)*1000.,
            candidate_targets=[c['target'] for c in candidates], candidate_a=[c['a'] for c in candidates],
            candidate_delta=[c['delta'] for c in candidates],
            candidate_solve_ok=[bool(c['solve_ok']) for c in candidates])
        self._snapshot_inputs = (ego, list(objects), rv, candidates, path, dict(previous))
        return selected
