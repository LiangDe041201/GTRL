"""Executable same-intent trajectory-parameter evolution on the frozen CG.

Only one additional MPC candidate is solved per active frame. The frozen CG
payoff and intent remain untouched. A learned parameter request still passes
the same public forecast/guard; feedback belongs to the guarded request.
"""
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from Planning_library.candidate_learning_v19 import task_reward
from Planning_library.control_path_v15 import path_hash
from Planning_library.matrix_motion_v14 import visible_leaders
from Planning_library.matrix_turn_game_v18 import score_candidates
from Planning_library.matrix_turn_game_v20 import candidate_execution
from Planning_library.physical_belief_v22 import physical_state, ResponseBelief
from Planning_library.trajectory_evolution_learning_v22 import EvolutionLearner
from Planning_library.trajectory_probe_v21 import TrajectoryProbeV21, _description, _array_hash
from Planning_library.vehicle_observation import vehicle_id, longitudinal_acceleration


class TrajectoryEvolutionV22(TrajectoryProbeV21):
    def __init__(self, phase, geometry, controllers, cruise=4.412022451715821,
                 checkpoint=None, directory=None, seed=1, epsilon=.3, min_episodes=10):
        super().__init__('observe', geometry, controllers, cruise)
        if not 0. <= epsilon <= 1.:
            raise ValueError('Invalid trajectory exploration probability')
        self.phase, self.epsilon = phase, float(epsilon)
        self.learner = EvolutionLearner(phase=phase, checkpoint=checkpoint, min_episodes=min_episodes)
        self.belief = ResponseBelief()
        self.rng = np.random.RandomState(seed)
        self.directory = None if directory is None else Path(directory)
        self.episode_offset = max((r['episode'] for r in self.learner.records), default=0)
        self.local_episode = 1
        self.engaged, self.age, self.control_key = False, 0., None
        self.proposal = None
        if self.directory is not None:
            self.directory.mkdir(parents=True, exist_ok=True)
            metadata = dict(revision='trajectory_evolution_v22', phase=phase,
                signature=self.learner.signature(), efe_enabled=False, same_intent_only=True,
                physical_fields=['x', 'y', 'v', 'acc', 'phi'], beta_model=ResponseBelief.MODEL,
                beta_calibrated=False, lateral_path_learning=False,
                checkpoint_sha256=None if checkpoint is None else hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest())
            (self.directory/'trajectory_evolution_metadata.json').write_text(
                json.dumps(metadata, indent=2), encoding='utf8')
            if checkpoint is not None:
                frozen = self.directory/'trajectory_model/frozen_input.json'
                frozen.parent.mkdir(parents=True, exist_ok=True)
                frozen.write_bytes(Path(checkpoint).read_bytes())

    @staticmethod
    def context(dynamic, cg, previous, target):
        ego = dynamic.ego_vehicle
        rv = next((v for v in dynamic.objects if vehicle_id(v) == cg.get('rv_id')), None)
        acc = longitudinal_acceleration(rv)
        leaders = [] if rv is None else visible_leaders(rv, dynamic.objects+[ego])
        gap, speed = min(leaders, default=(50., 0.))
        phase = {'approach': 0., 'merging': 1., 'merged': 2.}[cg['phase']]
        return [float(cg['standoff']), float(ego.v), float(target),
                0. if rv is None else float(rv.x-ego.x), 0. if rv is None else float(rv.y-ego.y),
                0. if rv is None else float(rv.v), 0. if acc is None else float(acc),
                min(50., max(-5., float(gap))), float(speed),
                float(cg.get('tracking_l', 0.)), float(cg.get('tracking_epsi', 0.)),
                float(previous['a']), float(previous['df']), phase, float(rv is not None), float(acc is not None)]

    def propose(self, dynamic, candidates, baseline, cg_record, seed, road_right, center):
        started = time.perf_counter()
        primary = candidates[1]['controller']
        path = primary.last_pathway
        ego, objects = dynamic.ego_vehicle, dynamic.objects
        rv = next((v for v in objects if vehicle_id(v) == cg_record.get('rv_id')), None)
        beta = self.belief.update(vehicle_id(rv), None if rv is None else float(rv.v), .05,
            opportunity=bool(cg_record['active']), confounded=bool(cg_record.get('motion_evidence', {}).get(
                'visible_leader_explains_slowdown', False)))
        names = ('defer', 'proceed')
        records = [_description(c, names[i]+'_base', names[i]) for i, c in enumerate(candidates)]
        original = candidates[baseline]
        tracking = primary.last_tracking_state or {}
        cg_context = dict(cg_record, tracking_l=tracking.get('l', 0.), tracking_epsi=tracking.get('epsi', 0.))
        context = self.context(dynamic, cg_context, seed['previous'], original['target'])
        active = bool(cg_record['active'])
        self.engaged = self.engaged or active
        key = (baseline, vehicle_id(rv), cg_record['phase'])
        decision = self.engaged and (self.learner.pending is None or self.age >= .5-1e-9 or key != self.control_key)
        if decision:
            self.learner.begin(context, beta, baseline, self.episode_offset+self.local_episode)
            self.proposal = self.learner.propose()
            self.age, self.control_key = 0., key
        ratio = 1. if self.proposal is None else self.proposal['ratio']
        extra_ms, alternative, eligible = 0., None, False
        permitted = active and not primary.geometry_force_stop and primary.geometry_source == 'planned'
        target = float(original['target'])*ratio
        if permitted and ratio < 1. and target >= .2 and original['target']-target >= .05:
            controller = self.controllers[baseline]
            controller.reset_global_path(path, dynamic)
            controller.geometry_source = primary.geometry_source
            controller.geometry_force_stop = primary.geometry_force_stop
            controller.last_u = dict(seed['previous'])
            controller._previous_observed_speed = seed['observed_speed']
            controller._warm_controls = None if seed['warm'] is None else seed['warm'].copy()
            controller.set_game_context({}, ego)
            a, delta = controller.solve(dynamic, target, road_right, intersection_center=center)
            alternative = dict(controller=controller, target=target, a=a, delta=delta,
                solve_ok=bool(controller._solve_ok), prediction=controller.last_prediction,
                plan=controller.last_control_plan if controller._solve_ok else None, times=controller.prediction_times)
            extra_ms = float(controller.last_solve_ms)
            execution = candidate_execution(ego, objects, [alternative], path, seed['previous'], self.geometry)[0]
            _, parts = score_candidates(ego, objects, rv, [alternative], self.geometry, path,
                seed['previous'], self.cruise, cg_record.get('motion_evidence', {}).get('acceleration'))
            eligible = bool(alternative['solve_ok'] and execution['accepted'] and all(p['admissible'] for p in parts[0]))
            description = _description(alternative, names[baseline]+'_r%.2f' % ratio, names[baseline])
            description.update(ratio=ratio, execution=execution, components=parts[0], eligible=eligible)
            records.append(description)
        if self.engaged:
            # Close an invalidated option BEFORE crediting a different default
            # request. Counterfactual proposals never receive realized reward.
            if not decision and self.learner.choice != 1. and not eligible:
                self.learner.begin(context, beta, baseline, self.episode_offset+self.local_episode)
                decision, self.age = True, 0.
            if decision:
                requested = self.learner.select(ratio, eligible, epsilon=self.epsilon, rng=self.rng)
                self.learner.start(requested)
            else:
                requested = self.learner.choice
        else:
            requested = 1.
        changed = requested != 1. and eligible
        request_record = records[-1] if changed else records[baseline]
        self.last = dict(revision='trajectory_evolution_v22', phase=self.phase, active=active,
            baseline_intent=baseline, baseline_id=names[baseline]+'_base',
            request_id=request_record['id'], changed_request=changed, requested_ratio=requested,
            proposal=self.proposal, learning_enabled=self.phase == 'train', efe_reward_enabled=False,
            spatial_path_changed=False, beta=beta,
            physical=dict(ego=physical_state(ego), rv=physical_state(rv)),
            observation=dict(ego=physical_state(ego), others=[physical_state(v) for v in objects]),
            path=np.asarray(path, dtype=float)[:, :2].tolist(), path_hash=path_hash(path),
            previous=dict(seed['previous']), warm_hash=_array_hash(seed['warm']),
            candidates=records, request=dict(request_record), decision=decision,
            learning=dict(self.learner.last) if self.engaged else dict(source='inactive'),
            extra_solve_ms=extra_ms, decision_ms=(time.perf_counter()-started)*1000.)
        output = list(candidates)
        if changed:
            output[baseline] = alternative
        return output

    def feedback(self, episode, frame, audit, applied, outcome=None):
        if int(applied['control_submit_ok']) != 1:
            raise RuntimeError('Cannot learn from an unsubmitted trajectory control')
        intervention = bool(audit['override'] or audit['unavoidable'])
        reward = task_reward(applied, .05, outcome, intervention)
        if self.engaged:
            self.learner.reward(reward, intervention)
        self.age += .05
        self.last['feedback'] = dict(episode=int(episode), frame=int(frame), reward=reward,
            outcome=outcome, intervention=intervention, guard_action=audit['action'],
            requested_ratio=self.last['requested_ratio'], applied_a=float(applied['a_cmd']),
            applied_delta=float(applied['delta_rad']), applied_target=float(applied['actuator_speed_target']))
        if outcome is not None:
            self.learner.finish()
            self.local_episode = int(episode)+1
            if self.phase == 'train' and self.directory is not None:
                self.learner.save(self.directory/'trajectory_model/evolution_model.json')

    def reset(self):
        super().reset()
        if hasattr(self, 'belief'):
            self.belief.reset()
        self.engaged, self.age, self.control_key = False, 0., None
        self.proposal = None
