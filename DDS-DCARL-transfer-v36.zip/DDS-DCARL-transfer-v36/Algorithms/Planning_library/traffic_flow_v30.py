"""Explicit supply policy and event-keyed RV draws; no CARLA or global RNG."""
import hashlib


class _DecisionUniform:
    def __init__(self,seed,episode,spawn,decision):
        if any(isinstance(v,bool) or not isinstance(v,int) for v in (seed,episode,spawn,decision)):
            raise ValueError('Traffic draw keys must be integer identities')
        if episode<0 or spawn<1 or decision<1:
            raise ValueError('Invalid traffic episode/spawn/decision identity')
        self.key=(seed,episode,spawn,decision)
        raw=(':'.join(str(v) for v in self.key)).encode('ascii')
        self.value=(int.from_bytes(hashlib.sha256(raw).digest()[:8],'big')>>11)/float(2**53)

    def random(self):
        """One fixed uniform variate for this logical decision, not a stream."""
        return self.value


class TrafficSupplyV30:
    def __init__(self,mode='legacy',seed=0):
        if mode not in ('legacy','continuous_v30'):
            raise ValueError('Unknown traffic flow mode: '+str(mode))
        self.mode,self.seed=mode,int(seed)
        self.continuous=mode=='continuous_v30'

    def can_spawn(self,total,finite_limit):
        return self.continuous or total<finite_limit

    def interval_frames(self,total,ordinary,gap_after,long_interval):
        if self.continuous:
            if gap_after>0:raise ValueError('Continuous flow requires DSH_GAP_AFTER<=0; artificial gaps are forbidden')
            return ordinary
        return long_interval if gap_after>0 and total>0 and total%gap_after==0 else ordinary

    def decision_random(self,episode,spawn,decision):
        return _DecisionUniform(self.seed,episode,spawn,decision) if self.continuous else None

    def metadata(self,finite_limit,gap_after):
        if not self.continuous:return {}
        self.interval_frames(0,1,gap_after,1)
        return dict(flow_revision='traffic_flow_v30',flow_mode=self.mode,continuous_supply=True,
            finite_spawn_limit=None,artificial_long_gaps_enabled=False,
            spacing_semantics='minimum_birth_clearance_not_locked_runtime_gap',
            behavior_randomness='keyed_uniform_sha256_v30',traffic_seed=self.seed,
            decision_random_key=['traffic_seed','flow_episode','spawn_ordinal','rv_decision_ordinal'])
