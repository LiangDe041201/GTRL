"""Physical control units for the CARLA 0.9.15 Ackermann interface.

The server closes speed/acceleration feedback; acceleration is a *magnitude
limit*, not a signed pedal or a guarantee of achieved body acceleration.
Reference: https://carla.readthedocs.io/en/0.9.15/python_api/#carla.VehicleAckermannControl
"""
import math


def physical_geometry(physics):
    """Read wheel spacing (CARLA wheel positions in cm) and front steer limit.

    The midpoint between axles is the declared kinematic reference assumption;
    it is recorded, rather than retaining v7's unrelated 3.925 m wheelbase.
    Distances use vectors so the calculation is independent of world heading.
    """
    wheels = list(physics.wheels)
    if len(wheels) != 4:
        raise ValueError('v8 requires a four-wheel ego vehicle')
    centres = []
    for pair in (wheels[:2], wheels[2:]):
        centres.append(tuple(sum(float(getattr(w.position, axis)) for w in pair)/2.
                             for axis in ('x', 'y', 'z')))
    wheelbase = math.sqrt(sum((a-b)**2 for a, b in zip(*centres)))/100.
    angle = math.radians(min(float(w.max_steer_angle) for w in wheels[:2]))
    if not (1.5 < wheelbase < 4.5 and .2 < angle < 1.6):
        raise ValueError('Invalid ego physics geometry: wheelbase=%s steer=%s' % (wheelbase, angle))
    return dict(wheelbase=wheelbase, l_f=wheelbase/2., l_r=wheelbase/2.,
                max_steer=angle, reference='axle_midpoint')


def ackermann_target(acceleration, speed, target_speed, steering, max_steer):
    """Translate signed MPC acceleration into a bounded forward speed target.

    A one-second velocity preview supplies a non-vanishing error to the native
    feedback controller. Its acceleration magnitude is bounded by the requested
    acceleration. Zero acceleration must not be passed as CARLA's unlimited mode.
    Braking requests always target a lower speed, including below nominal speed.
    """
    values = [float(v) for v in (acceleration, speed, target_speed, steering, max_steer)]
    if not all(math.isfinite(v) for v in values) or max_steer <= 0.:
        raise ValueError('Nonfinite control or invalid steering limit')
    acceleration, speed, target_speed, steering, max_steer = values
    acceleration = max(-3., min(2., acceleration))
    speed, target_speed = max(speed, 0.), max(target_speed, 0.)
    preview = max(0., min(target_speed, speed+acceleration))
    if acceleration > .05 and speed < .1 and target_speed > .1:
        preview = min(target_speed, max(.3, preview))
    if target_speed <= .01:
        preview = 0.
    return dict(speed=preview, acceleration=max(.05, abs(acceleration)),
                steer=max(-max_steer, min(max_steer, steering)),
                steer_speed=.9, jerk=0.)


def body_clear_of_band(ego, cross_y=-138., band_half=1., margin=.1):
    """Whole rectangle beyond the far edge; passing one path point is insufficient."""
    from Planning_library.vehicle_observation import vehicle_size
    extent = (vehicle_size(ego, 'length', 4.5)/2.*abs(math.sin(ego.yaw))
              + vehicle_size(ego, 'width', 2.)/2.*abs(math.cos(ego.yaw)))
    return ego.y+extent < cross_y-band_half-margin
