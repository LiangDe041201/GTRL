#!/usr/bin/env python3
"""【0' 诊断】路径几何 dump（只写文件，绝不改变控制行为）。

目的：一次运行把回答"路口段 2~6 m 偏差从哪来"所需的**全部几何**落盘，
然后离线用 `path_diagnostics.py` 分析。要区分的三种可能：

  ① **样条拟合误差**：`csp` 偏离它的输入折线 → 换参考线表示
  ② **MPC 跟踪误差**：自车偏离被给定的轨迹     → 修控制器
  ③ **坐标系错配**：冲突几何与轨迹不是同一条线 → 统一基准

落盘内容：
  static   : ref_path_array（冲突几何用的折线）、frenet ref_path（规划器自己的折线）、
             route_raw（GlobalRoutePlanner 原始路点）、csp 密集采样(x,y,yaw,kappa,s)、
             csp 参数节点 s
  episodes : 每回合的决策记录 —— {frame, traj_id, target_speed, arc_to_cross, lat_dev,
             traj_xy(轨迹点), ego(x,y,yaw,v)}
              自车逐帧位置已在 interaction_ego.csv 里（用 traj_id 关联到轨迹区间）

所有写入都被 try/except 包住：本模块**不允许**影响训练。
"""
import os
import pickle
import time

import numpy as np


class PathDiagDumper:
    """逐回合 dump 路径几何。`enabled=False` 时所有方法都是 no-op。"""

    def __init__(self, out_dir=None, enabled=None, max_records_per_ep=10,
                 csp_step=0.2):
        if enabled is None:
            enabled = os.environ.get('DSH_PATH_DIAG', '1') == '1'
        self.enabled = bool(enabled)
        self.out_dir = out_dir
        self.max_records = max(1, int(max_records_per_ep))
        self.csp_step = float(csp_step)
        self._static = None
        self._records = []
        self._episode = None
        self.path = os.path.join(out_dir, 'path_diag.pkl') if out_dir else None

    # ---------------- 静态几何（每回合一次即可，内容不变）----------------
    def sample_static(self, ref_path_array=None, frenet_ref_path=None,
                      route_raw=None, csp=None):
        if not self.enabled or self._static is not None:
            return
        try:
            st = {}
            if ref_path_array is not None:
                st['ref_path_array'] = np.asarray(ref_path_array, dtype=float)
            if frenet_ref_path is not None:
                st['frenet_ref_path'] = np.asarray(frenet_ref_path, dtype=float)
            if route_raw is not None:
                st['route_raw'] = np.asarray(route_raw, dtype=float)
            if csp is not None:
                try:
                    s_nodes = np.asarray(csp.s, dtype=float)
                    st['csp_s_nodes'] = s_nodes
                    if len(s_nodes) > 1:
                        ss = np.arange(0.0, float(s_nodes[-1]), self.csp_step)
                        xs, ys, yaws, ks = [], [], [], []
                        for sv in ss:
                            try:
                                xx, yy = csp.calc_position(float(sv))
                            except Exception:
                                break
                            if xx is None or yy is None:
                                break
                            xs.append(float(xx))
                            ys.append(float(yy))
                            try:
                                yaws.append(float(csp.calc_yaw(float(sv))))
                            except Exception:
                                yaws.append(float('nan'))
                            try:
                                ks.append(float(csp.calc_curvature(float(sv))))
                            except Exception:
                                ks.append(float('nan'))
                        if xs:
                            st['csp_s'] = np.asarray(ss[:len(xs)], dtype=float)
                            st['csp_xy'] = np.stack([np.asarray(xs), np.asarray(ys)], axis=1)
                            st['csp_yaw'] = np.asarray(yaws, dtype=float)
                            st['csp_kappa'] = np.asarray(ks, dtype=float)
                except Exception as _e:
                    st['csp_error'] = f'{type(_e).__name__}: {_e}'
            if st:
                self._static = st
        except Exception:
            pass

    # ---------------- 逐回合 ----------------
    def begin_episode(self, episode):
        if not self.enabled:
            return
        self._episode = int(episode)
        self._records = []

    def decision(self, frame, target_speed, traj_xy, ego=None, arc_to_cross=None,
                 lat_dev=None, traj_id=None, extra=None):
        if not self.enabled or len(self._records) >= self.max_records:
            return
        try:
            rec = {'frame': int(frame), 'traj_id': traj_id,
                   'target_speed': float(target_speed) if target_speed is not None else None,
                   'arc_to_cross': None if arc_to_cross is None else float(arc_to_cross),
                   'lat_dev': None if lat_dev is None else float(lat_dev),
                   'traj_xy': np.asarray(traj_xy, dtype=float) if traj_xy is not None else None}
            if ego is not None:
                rec['ego'] = {'x': float(getattr(ego, 'x', float('nan'))),
                              'y': float(getattr(ego, 'y', float('nan'))),
                              'yaw': float(getattr(ego, 'yaw', float('nan'))),
                              'v': float(getattr(ego, 'v', float('nan')))}
            if extra:
                rec['extra'] = extra
            self._records.append(rec)
        except Exception:
            pass

    def end_episode(self, episode=None):
        """把本回合记录追加进 path_diag.pkl（读-改-写；数据量小，够用）。"""
        if not self.enabled or self.path is None:
            return
        try:
            data = {'static': self._static, 'episodes': []}
            if os.path.exists(self.path):
                try:
                    with open(self.path, 'rb') as f:
                        old = pickle.load(f)
                    if isinstance(old, dict):
                        data = old
                        data.setdefault('episodes', [])
                        if data.get('static') is None:
                            data['static'] = self._static
                except Exception:
                    pass
            ep = int(episode if episode is not None else (self._episode or 0))
            data['episodes'] = [e for e in data['episodes'] if e.get('episode') != ep]
            data['episodes'].append({'episode': ep, 'records': self._records,
                                     'ts': time.strftime('%H:%M:%S')})
            data['episodes'].sort(key=lambda e: e.get('episode', 0))
            with open(self.path, 'wb') as f:
                pickle.dump(data, f)
        except Exception:
            pass

    def close(self):
        self._records = []
