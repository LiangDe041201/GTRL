"""Local 2D membership in OpenDRIVE line/arc driving lanes.

CARLA x/y points are transformed to OpenDRIVE (x, -y). Lane widths and
offsets remain piecewise cubics, rather than a raster or a nearest-road
projection. This is a sampled planning constraint, not a 3D road-mesh proof.
Unsupported geometry fails at setup; no simulator query is used here.
"""
import math
import xml.etree.ElementTree as ET

import numpy as np


TOL=1.e-7


class Cubics:
    def __init__(self,elements,key,zero=False):
        rows=sorted([[float(e.get(key))]+[float(e.get(k,'0')) for k in ('a','b','c','d')]
                     for e in elements])
        if not rows and zero: rows=[[0.,0.,0.,0.,0.]]
        self.rows=np.asarray(rows,dtype=float)
        if (self.rows.ndim!=2 or self.rows.shape[1]!=5 or not np.isfinite(self.rows).all()
                or np.any(np.diff(self.rows[:,0])<=0.)):
            raise ValueError('Invalid or missing lane width/offset cubics')

    def __call__(self,s):
        s=np.asarray(s,dtype=float)
        i=np.searchsorted(self.rows[:,0],s,side='right')-1
        r=self.rows[np.maximum(i,0)]; ds=s-r[...,0]
        return ((r[...,4]*ds+r[...,3])*ds+r[...,2])*ds+r[...,1]

    def extent(self,start,end):
        """Include derivative roots, so the broad-phase box cannot cut a bulge."""
        values=[]
        for i,r in enumerate(self.rows):
            lo=max(start,r[0]); hi=min(end,self.rows[i+1,0] if i+1<len(self.rows) else end)
            if hi<lo: continue
            candidates=[lo-r[0],hi-r[0]]
            if abs(r[4])>1.e-15:
                roots=np.roots([3.*r[4],2.*r[3],r[2]])
            elif abs(r[3])>1.e-15: roots=[-r[2]/(2.*r[3])]
            else: roots=[]
            candidates += [float(np.real(v)) for v in roots if abs(np.imag(v))<1.e-10
                           and lo-r[0]<=np.real(v)<=hi-r[0]]
            values.extend(((r[4]*v+r[3])*v+r[2])*v+r[1] for v in candidates)
        if not values: raise ValueError('Lane cubic does not cover its interval')
        return min(values),max(values)


class LaneBand:
    def __init__(self,road,section,lane,junction,start,end,offset,inner,width,side):
        self.lane=(road,section,lane); self.junction=junction
        self.start,self.end=start,end
        self.offset,self.inner,self.width,self.side=offset,tuple(inner),width,side

    def edges(self,s):
        inner=self.offset(s)
        for width in self.inner: inner=inner+self.side*width(s-self.start)
        outer=inner+self.side*self.width(s-self.start)
        return np.minimum(inner,outer),np.maximum(inner,outer)


class Primitive:
    def __init__(self,g,band,lateral_bound):
        self.band=band
        self.s,self.x,self.y,self.h,self.length=[float(g.get(k)) for k in ('s','x','y','hdg','length')]
        if not all(math.isfinite(v) for v in (self.s,self.x,self.y,self.h,self.length)) or self.length<=0.:
            raise ValueError('Invalid road geometry')
        self.c,self.sn=math.cos(self.h),math.sin(self.h)
        self.lo=max(0.,band.start-self.s); self.hi=min(self.length,band.end-self.s)
        arc=g.find('arc'); self.k=0. if arc is None else float(arc.get('curvature'))
        if not math.isfinite(self.k): raise ValueError('Invalid arc curvature')
        if abs(self.k)<1.e-12: self.k=0.
        if self.k:
            if abs(self.k)*self.length>=2.*math.pi-TOL:
                raise ValueError('Full-circle OpenDRIVE arc is unsupported')
            self.cx=self.x-self.sn/self.k; self.cy=self.y+self.c/self.k
            self.radius=abs(1./self.k); self.sign=1. if self.k>0. else -1.
            self.theta0=self.h-self.sign*math.pi/2.
        self.bounds=self._bounds(lateral_bound)

    def reference(self,u):
        if not self.k: return self.x+u*self.c,self.y+u*self.sn
        h=self.h+self.k*u
        return self.x+(math.sin(h)-self.sn)/self.k,self.y-(math.cos(h)-self.c)/self.k

    def _bounds(self,margin):
        points=[self.reference(self.lo),self.reference(self.hi)]
        if self.k:
            for a in (0.,math.pi/2.,math.pi,3.*math.pi/2.):
                u=((self.sign*(a-self.theta0))%(2.*math.pi))/abs(self.k)
                if self.lo<=u<=self.hi: points.append(self.reference(u))
        # Convert the OpenDRIVE reference box to CARLA coordinates.
        p=np.asarray(points); p[:,1]*=-1.
        return np.r_[p.min(axis=0)-margin-TOL,p.max(axis=0)+margin+TOL]

    def broad(self,p):
        return ((p[:,0]>=self.bounds[0])&(p[:,1]>=self.bounds[1])&
                (p[:,0]<=self.bounds[2])&(p[:,1]<=self.bounds[3]))

    def contains(self,p):
        x,y=p[:,0],-p[:,1]
        if not self.k:
            dx,dy=x-self.x,y-self.y
            u=dx*self.c+dy*self.sn; t=-dx*self.sn+dy*self.c
        else:
            dx,dy=x-self.cx,y-self.cy
            advance=(self.sign*(np.arctan2(dy,dx)-self.theta0))%(2.*math.pi)
            advance=np.where(advance>2.*math.pi-1.e-9,0.,advance)
            u=advance/abs(self.k); t=self.sign*(self.radius-np.hypot(dx,dy))
        low,high=self.band.edges(self.s+np.clip(u,self.lo,self.hi))
        return ((u>=self.lo-TOL)&(u<=self.hi+TOL)&(t>=low-TOL)&
                (t<=high+TOL)&(high-low>TOL))


class LocalRoadRegion:
    def __init__(self,primitives,allowed_lanes,junctions,bounds):
        self.bounds=np.asarray(bounds,dtype=float)
        if (self.bounds.shape!=(4,) or not np.isfinite(self.bounds).all()
                or np.any(self.bounds[2:]<=self.bounds[:2])):
            raise ValueError('Finite nonempty local coverage bounds are required')
        self.allowed=frozenset(tuple(map(int,v)) for v in allowed_lanes)
        self.junctions=frozenset(map(int,junctions))
        if not self.allowed: raise ValueError('No task route lanes')
        def overlaps(p):
            return bool(np.all(p.bounds[2:]>=self.bounds[:2]) and np.all(p.bounds[:2]<=self.bounds[2:]))
        self.all=tuple(p for p in primitives if overlaps(p))
        self.task=tuple(p for p in self.all if p.band.lane in self.allowed or p.band.junction in self.junctions)
        if not self.task: raise ValueError('No task driving surface in local coverage')
        observed={p.band.lane for p in self.task}
        if not self.allowed<=observed: raise ValueError('Observed route lane missing from local OpenDRIVE region')

    @classmethod
    def from_opendrive(cls,text,allowed_lanes,junctions,bounds):
        root=ET.fromstring(text)
        if root.tag!='OpenDRIVE': raise ValueError('Expected an OpenDRIVE map')
        primitives=[]
        for road in root.findall('road'):
            road_id=int(road.get('id')); junction=int(road.get('junction','-1'))
            junction=None if junction<0 else junction
            length=float(road.get('length')); lanes=road.find('lanes')
            if lanes is None: continue
            offset=Cubics(lanes.findall('laneOffset'),'s',zero=True)
            if offset.rows[0,0]>TOL: raise ValueError('Lane offset starts after road origin')
            geometries=road.findall('planView/geometry')
            for g in geometries:
                shapes=list(g)
                if len(shapes)!=1 or shapes[0].tag not in ('line','arc'):
                    raise ValueError('Only OpenDRIVE line/arc geometry is supported')
            sections=sorted(lanes.findall('laneSection'),key=lambda s:float(s.get('s')))
            for section_id,section in enumerate(sections):
                start=float(section.get('s'))
                end=float(sections[section_id+1].get('s')) if section_id+1<len(sections) else length
                if not math.isfinite(end-start) or end<=start: raise ValueError('Invalid lane section interval')
                extent=offset.extent(start,end); lateral_bound=max(map(abs,extent))
                for side_name,side in (('left',1),('right',-1)):
                    children=sorted(section.findall(side_name+'/lane'),key=lambda e:abs(int(e.get('id'))))
                    inner=[]; distance=lateral_bound
                    for child in children:
                        identifier=int(child.get('id'))
                        if identifier*side<=0: raise ValueError('Lane ID has the wrong side')
                        width=Cubics(child.findall('width'),'sOffset')
                        if width.rows[0,0]>TOL: raise ValueError('Lane width starts after section origin')
                        minimum,maximum=width.extent(0.,end-start)
                        if minimum<-TOL: raise ValueError('Negative lane width')
                        distance+=max(0.,maximum)
                        if child.get('type')=='driving':
                            band=LaneBand(road_id,section_id,identifier,junction,start,end,offset,inner,width,side)
                            for g in geometries:
                                if float(g.get('s'))<end and float(g.get('s'))+float(g.get('length'))>start:
                                    primitives.append(Primitive(g,band,distance))
                        inner.append(width)
        return cls(primitives,allowed_lanes,junctions,bounds)

    def points(self,points):
        p=np.asarray(points,dtype=float)
        if p.ndim!=2 or p.shape[1]!=2 or not np.isfinite(p).all():
            raise ValueError('Finite Nx2 CARLA points are required')
        return p

    def covered(self,p):
        return np.all((p>=self.bounds[:2]-TOL)&(p<=self.bounds[2:]+TOL),axis=1)

    def classify(self,points):
        """Return union membership and points accepted only via task junctions."""
        p=self.points(points); coverage=self.covered(p)
        route=np.zeros(len(p),dtype=bool); junction=np.zeros(len(p),dtype=bool)
        for primitive in self.task:
            target=route if primitive.band.lane in self.allowed else junction
            indices=np.flatnonzero(coverage&~target&primitive.broad(p))
            if len(indices): target[indices]|=primitive.contains(p[indices])
        return route|junction,junction&~route

    def contains(self,points):
        return self.classify(points)[0]

    def describe(self,point):
        p=self.points([point]); covered=bool(self.covered(p)[0])
        accepted=bool(self.contains(p)[0]) if covered else False
        value=dict(covered=covered,accepted=accepted,driving=False,lane=None,
                   junction=None,is_junction=False,width=None)
        if not covered: return value
        # Prefer a task primitive at overlaps, matching the union constraint.
        for primitive in self.task+tuple(v for v in self.all if v not in self.task):
            if primitive.broad(p)[0] and primitive.contains(p)[0]:
                band=primitive.band
                value.update(driving=True,lane=list(band.lane),junction=band.junction,
                             is_junction=band.junction is not None)
                # Width is diagnostic; recover the road s coordinate locally.
                x,y=p[0,0],-p[0,1]
                if not primitive.k: u=(x-primitive.x)*primitive.c+(y-primitive.y)*primitive.sn
                else:
                    angle=(primitive.sign*(math.atan2(y-primitive.cy,x-primitive.cx)-primitive.theta0))%(2.*math.pi)
                    if angle>2.*math.pi-1.e-9: angle=0.
                    u=angle/abs(primitive.k)
                value['width']=float(band.width(primitive.s+u-band.start))
                return value
        return value
