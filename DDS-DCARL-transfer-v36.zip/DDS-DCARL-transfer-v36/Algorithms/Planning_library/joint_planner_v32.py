"""Choose and execute a qualified pair of lateral path and longitudinal target."""
import math

from Planning_library.cg_trajectory_planner_v29 import CGTrajectoryPlannerV29
from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
from Planning_library.longitudinal_planner_v31 import entry_times
from Planning_library.rolling_trajectory_v24 import RollingFamily
from Planning_library.vehicle_observation import vehicle_size


LATERAL_OFFSETS = (None, .5, 1., -.5, -1., 0.)
SPEEDS = (None, 4., 3., 2., 1.)
ACTION_PAIRS = tuple((offset, speed) for offset in LATERAL_OFFSETS for speed in SPEEDS)


class JointLearnerV32(CGTrajectoryLearnerV29):
    SCHEMA = 'cg_joint_trajectory_learning_v32'
    ACTION_PAIRS = ACTION_PAIRS
    ACTION_NAMES = tuple('path_%s_speed_%s' % ('cg' if offset is None else '%+.1f' % offset,
                        'cg' if speed is None else '%.0f' % speed) for offset, speed in ACTION_PAIRS)


class JointRollingFamilyV32(RollingFamily):
    MAX_OFFSET = 1.


class JointPlannerV32(CGTrajectoryPlannerV29):
    EXTRA_CONTROLLERS = len(ACTION_PAIRS) - 1
    ACTION_OFFSETS = LATERAL_OFFSETS
    FAMILY_CLASS = JointRollingFamilyV32
    LEARNER_CLASS = JointLearnerV32
    LEARNER_METADATA = dict(CGTrajectoryPlannerV29.LEARNER_METADATA,
        learner_revision=JointLearnerV32.SCHEMA, cg_intent_and_speed_frozen=False,
        joint_action_pairs=[list(pair) for pair in ACTION_PAIRS])

    def propose(self,dynamic,candidates,baseline,cg_record,seed,road_right,center):
        self._joint_path = candidates[1]['controller'].last_pathway
        self._speed_cap = float(candidates[1]['target'])
        for action in range(1,len(SPEEDS)):
            if action in self.profiles:
                self.profiles[action] = dict(path=self._joint_path)
        return super().propose(dynamic,candidates,baseline,cg_record,seed,road_right,center)

    def _permitted(self,primary,cg_record,original):
        return (cg_record['active'] and cg_record['phase']=='approach' and cg_record['standoff']>0.
                and primary.geometry_source=='planned' and not primary.geometry_force_stop
                and math.isfinite(self._speed_cap) and self._speed_cap>=.2)

    def _generate(self,ego,seed,target):
        # Generate each lateral geometry once so changing speed does not change its path.
        super()._generate(ego,seed,self._speed_cap)
        paths = dict(self.profiles)
        paths[0] = dict(path=self._joint_path)
        self.profiles = {path_slot*len(SPEEDS)+speed_slot:profile
                         for path_slot,profile in sorted(paths.items())
                         for speed_slot in range(len(SPEEDS)) if path_slot or speed_slot}

    def _candidate_target(self,action,cg_target):
        speed = ACTION_PAIRS[action][1]
        if speed is None:
            # A second path at zero target gives no distinct maneuver.
            return cg_target if cg_target>=.2 else None
        if speed>self._speed_cap+1.e-8 or abs(speed-cg_target)<=1.e-8:
            return None
        return speed

    def _qualify(self,candidate,description,action,ego,objects,forecasts):
        offset, speed = ACTION_PAIRS[action]
        entering = self.intent==0 and speed is not None
        description.update(lateral_offset_m=offset, speed_option_mps=speed)
        if entering:
            candidate['entry_intent'] = 1
            description['intent'] = 'proceed'
            half_width = max((vehicle_size(other,'width',1.97) for other in objects),default=1.97)/2.
            crossing = [entry_times(states,times,self.length,self.width,half_width)
                        for states,times,_ in forecasts]
            description['crossings'] = [list(pair) for pair in crossing]
            description['eligible'] = bool(description['eligible'] and len(crossing)==2
                and all(clear is not None for _,clear in crossing)
                and len(description['components'])==2 and all(
                    part['min_gap'] is None or part['min_gap']>=.2 for part in description['components']))

    def activate(self,current,chosen):
        # On rollback the CG plan can belong to the matrix peer, outside this pool.
        if chosen is self._base['controller'] and all(chosen is not solver for solver in self.controllers):
            return chosen
        return super().activate(current,chosen)
