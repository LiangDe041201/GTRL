#!/usr/bin/env python3
"""交互行为诊断日志 —— 回答一个关键归因问题：

    "车流（RV）是不是**提前刹车**了？如果是，那环境本身就变简单了，
     碰撞率下降不能全算到 ego 的学习头上。"

背景：t1_arch_spd 相比 t0c_g995 碰撞 33.7% → 8.1%，但其中"架构改动"里有一项
`zone A`（自车距冲突点 < R_A 时 RV 被我们自己的规则**强制让行**）直接改变了对手行为，
即改变了**环境难度**，而非 ego 策略。本模块把判断这件事所需的证据逐帧落盘：

  1) RV 刹车时刻（首次减速到达阈值的那一帧）：此时 RV 距冲突点多远、还在多快、
     自车弧长 arc_to_cross 是多少（**是否还没到停止线就刹了**）、是否 zone A 生效。
  2) 每次让行/抢行决策的原因分布：zoneA / committed / emergency / bernoulli。
  3) ego 越过冲突点(committed)那一刻，RV 已减速到什么程度、间隙有多大。
  4) 逐回合汇总，可直接统计"提前刹车率"与"zoneA 让行占比"。

输出（均在 DSH_SAVE_DIR / 运行目录下）：
  interaction_rv.csv      逐帧 RV 观测（决策区窗口内）
  interaction_ego.csv     逐帧 ego 动作/接管/安全量
  interaction_summary.csv 逐回合诊断汇总
  interaction_report.txt  人读汇总（每 report_every 回合刷新）

开关：DSH_ILOG=0 关闭（默认开）。纯 stdlib，无 CARLA 依赖。
"""
import csv
import json
import math
import os
import time

#: 判定"正在刹车"的加速度阈值 (m/s²)：小于它就记为一次减速
BRAKE_ACC_TH = -0.3

#: 运行目录缺省值（与 path_utils.get_model_dir 保持一致）
_DEFAULT_DIR = os.path.join(os.getcwd(), 'Saved_DCARL_model')


def _resolve_out_dir(out_dir=None):
    if out_dir:
        return str(out_dir)
    try:
        import sys
        _here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if _here not in sys.path:
            sys.path.insert(0, _here)
        from path_utils import get_model_dir
        return get_model_dir()
    except Exception:
        return os.environ.get('DSH_SAVE_DIR', _DEFAULT_DIR)


#: 【单一来源】interaction_ego.csv 的列定义。
#:   ⚠ 教训：表头（名字列表）与数据行（值列表）此前是**两次独立编辑**，锚点不同 ⇒
#:   16 号位起错开 8 位（列数都是 43，CSV 不报错，但**名字与值不对应**）。
#:   实测后果：`decision_src` 落在 `thw_rv_raw` 名下、`band_occupied` 里是浮点数。
#:   ⇒ 现在表头与数据行都由本常量派生，`ego_row` 还会做长度断言。
EGO_COLUMNS = [
    'episode', 'frame', 'ego_x', 'ego_y', 'ego_v', 'arc_to_cross',
    'arc_cont', 'lat_dev', 't_ego_cont',
    'proj_x', 'proj_y', 'dist_to_cross',
    'traj_id', 'path_src', 'path_n', 'path_fp',
    'decision_src',
    'thw_rv_raw', 'thw_rv_worst',
    'front_clearance', 'band_occupied', 'band_occ_pred',
    'band_nev', 'band_x_gap', 'band_t_entry',
    'committed', 'n_vehicles', 'lcttc_rv', 'thw_boundary_rv',
    'lcttc_fv', 'shield_danger', 'lcttc_min',
    'rv_id', 'rv_x', 'rv_v', 'action', 'rule_action', 'takeover',
    'reward', 'efe_active', 'efe_best_action', 'efe_min', 'efe_max',
    # 【S2 拆分】ε 的名义值与"本决策是否真的触发探索"（用于把 46% 拆成 ε vs 其它来源）
    'epsilon_now', 'eps_triggered',
    # 【S6-① 观测】实际下发给 MPC 的纵向目标速度，以及动作自身要求的速度。
    #   存在的理由：实测碰撞帧连续 28 帧 action=1(action_speed=0.0)、ego_v 恒定 2.8 m/s，
    #   怀疑 action 的纵向语义没到达控制器。这两列把"动作要求的速度"与"最终 v_ref"
    #   并排记录，可离线一眼看出是哪一层把速度抬上去的。**纯观测，不改行为。**
    'v_ref', 'v_ref_before_floor', 'action_speed', 'rl_speed_cap',
    # 【式(24)】舒适项分量（验收 V3：不同动作必须不同；全相同 ⇒ 没接）
    'comfort_j', 'comfort_s',
    # 【④ 2D】横向屏蔽（验收 V4：屏蔽必须纵向+横向都屏）
    'lat_mask', 'lat_screened',
    # 【V1 诊断】探索候选集掩码（区分"从未进入候选集" vs "可进但未被选中"）
    'cand_mask',
    # 【式(11)(12)(16)(17)】信息集落地证据（|I|、历史长度、是否完美信息、参与者数）
    'info_card', 'info_hlen', 'info_perfect', 'info_npart',
    # 【诊断】被静默 except 吞掉的异常（本会话第三次栽在这上面，必须显形）
    'info_err', 'causal_err',
    # 【式(64)】完成奖励（140）是否真的在本帧触发
    'complete_fired',
    # 【式(18)】对手动作频率熵（历史路径的真实消费者）
    'rv_action_entropy',
    # 【3.1/C2】等待位置纪律：y 域净距、是否被纪律强制停、累计次数、异常
    'wait_standoff', 'clamp_stopped', 'clamp_stop_num', 'clamp_err',
    # 【P1-g】配对切换/测量毛刺计数（ġ 被置 0 的帧）
    'gap_switch_num', 'gap_glitch_num',
    # 【§48 客观奖励】三项分量 + 三项客观输入（LCTTC/边界距离/PET）+ 异常列
    #   异常列必须能显形：`obj_err` 非空即"客观项这一帧没算成"，验收会 FAIL
    'r_safe_obj', 'r_prox_obj', 'r_pet_obj',
    'h_lcttc_min', 'd_ab_min', 'pet_min', 'pbrs_shaping', 'obj_err',
    # 【§51.3 几何修复】等待位超调计数：`wait_standoff <= 0`（车头已进交叉带）的帧数
    #   存在理由：这个 bug 之前**没有任何列能看见**，只能靠事后逐帧对齐才挖出来。
    'wait_overshoot_num',
    # 【§51.4 死锁修复】入口授权与"承诺清空"必须能看见：
    #   此前 `_last_entry_granted` 只存不记 ⇒ 死锁只能靠事后逐帧对齐才挖出来。
    'entry_granted', 'committing',
    # 【§53】闩锁状态 / 间隙是否已认证 / 强制清空路径的触发与拦截计数
    'commit_latched', 'gap_ok', 'force_clear_num', 'force_clear_blocked_num',
    # 【§54】真实运动清空模型的两个量（到达时间 / 占用冲突区时长）
    't_ego_go', 'clr_go',
    # 【§55】自车左转路径进入车流带的真实 x（自校准 conflict_x 用）
    'band_entry_x',
    # 【§60】机会约束授权的风险值与参与车辆数（授权判据的可见性）
    'commit_risk', 'risk_veh',
    # 【§62】逐车让行概率的推断成分（模型先验 / 后验均值 / 观测数）与式65的输入
    'pyield_prior', 'pyield_hat', 'pyield_n', 'thw_in',
    # 【§64 B 方案】自车意图 + 意图分箱观测到的让行率（判据侧校准的可见性）
    'ego_intent', 'intent_rate',
    # 【§75 诊断】Cournot 的"意见"及是否被风险门挡住（区分"设计无效"vs"授权权被移除"）
    'take_cournot', 'risk_gate_ok',
    # ===== 【2026-10-10 新增·离线判据分析的前置埋点】=====
    #   为什么必须加：`t_veh_min` / `t_veh_sorted` 此前**从未落盘**（已用 `grep -cx` 确认），
    #   而它们是占用窗判据（`entry_gap_is_safe`）与机会约束（`commit_risk`）的**唯一输入**。
    #   后果：无法离线重算 `gap_ok` / `commit_risk` ⇒ 任何"改判据会怎样"的分析都做不了，
    #   只能靠反复实跑（~100 分钟/轮）试错。
    #   加了这四列之后，一次短跑就能支撑后续全部离线分析。
    #   `t_veh_sorted` 是**列表**，序列化为 `v1;v2;v3`（保留 3 位小数），避免 CSV 引号问题。
    #   `conflict_x` 直接暴露 BUG-1 的几何量，便于逐帧核对（实测偏西 11.3 m）。
    't_veh_sorted', 't_veh_worst', 'n_cand', 'conflict_x',
    # ===== 【2026-10-12 奖励核账】把 reward 拆成可归因的分量 =====
    #   为什么必须加：实测逐帧 reward 均值 **−31.33**、正帧仅 10%，
    #   但逐个核账只找到 ≈ −2.3/帧 ⇒ **≈ −29/帧来源不明**。
    #   `rew_resid` 是 `reward − Σ(已记分量)`：**它就是"未识别项"的探针**。
    #   若 rew_resid ≈ 0 ⇒ 账目完整；若很大 ⇒ 还有没找到的奖励项。
    'rew_game', 'rew_thw', 'rew_yaw', 'rew_lat',
    'rew_safe', 'rew_prox', 'rew_pet',
    'rew_eff', 'rew_comfort_pos', 'rew_wait', 'rew_hesitate', 'rew_comfort', 'rew_smooth',
    'rew_terminal', 'rew_resid',
    # 【2026-10-12 修复 D2】式56/57：折进单步回报的 −ambiguity（②→③ 的耦合通道）
    'rew_efe_amb',
    # 【2026-10-13 修复 D2b】横向耦合用到的 Δψ（自车→冲突点的航向变化量）
    'efe_dpsi',
    # ===== 【2026-10-12 修复 D3'】① Cournot 的**授权口径**可观测 =====
    #   为什么必须落盘：修复前 `_risk_gate_ok` 是**恒 False 的死分支**，① 对决策影响为 0，
    #   但日志里只看到 `risk_gate_ok=False`，**无法区分**"被风险值挡住"与"被稳定性挡住"。
    #   这两者语义完全不同（前者合规，后者是①可以安全接管的场合）⇒ 不落盘就无法验证修复。
    'cournot_gate_reason', 'risk_value_ok',
    # 闭环核对：当前是否学习阶段、MPC 输出、实际施加控制和两种完成判据。
    'rl_active', 'a_mpc', 'delta_mpc_rad', 'a_cmd', 'delta_rad',
    'throttle', 'brake', 'steer', 'mpc_l', 'mpc_epsi', 'mpc_solve_ok',
    'complete_strict', 'complete_legacy', 'goal_distance', 'goal_path_distance',
    'goal_heading_error', 'goal_progress',
    'planning_status', 'trajectory_force_stop', 'trajectory_speed_limit',
    'execution_guard_reason', 'v_ref_before_guard', 'goal_remaining',
    'mpc_geometry_source', 'a_prev', 'steer_prev',
    'learning_mode', 'belief_rv_id', 'belief_vector', 'belief_entropy', 'belief_evidence',
    'soft_policy', 'baseline_policy', 'behavior_policy', 'soft_value',
    'soft_information_cost', 'information_cost', 'bellman_residual', 'bellman_sweeps',
    'learning_decision', 'behavior_model_valid',
    'learning_reward_mode', 'efe_learning_reward',
    'rv_acc_observed', 'rv_acc_source', 'rv_acc_follow_pred', 'rv_acc_follow_source',
    'game_controller', 'mpc_game_enabled', 'mpc_game_active',
    'mpc_game_rv_id', 'mpc_game_fv_id', 'mpc_game_safety_mode',
    'mpc_game_speed_cost', 'mpc_game_safety_cost', 'mpc_game_comfort_cost',
    'mpc_game_total_cost', 'stackelberg_active',
    'control_profile', 'feasibility_phase', 'feasibility_safe',
    'feasibility_min_gap', 'feasibility_conflict_id', 'feasibility_vehicle_ids',
    'mpc_game_participant_ids', 'mpc_prediction_horizon',
    'mpc_solve_ms',
    'mpc_audit_gap', 'mpc_audit_actor', 'mpc_audit_override',
    'actuator_mode', 'sim_frame_before', 'sim_frame_after',
    'sim_time_before', 'sim_time_after', 'sim_dt',
    'ego_v_before', 'ego_v_after', 'ego_acc_measured',
    'actuator_speed_target', 'actuator_accel_limit', 'physical_max_steer', 'wheelbase',
    'guard_action', 'guard_selected_gap', 'guard_safe', 'guard_unavoidable',
    'guard_candidates', 'body_clear', 'mpc_solver_status', 'mpc_failure_snapshot',
    'control_probe_phase',
    'control_probe_phase_seconds', 'control_probe_failure',
    'ego_v_signed_before', 'ego_v_signed_after', 'ego_acc_signed', 'ego_acc_sensor',
    'actuator_filtered_acc', 'actuator_integral', 'actuator_pedal_mode',
    'requested_throttle', 'requested_brake', 'requested_steer', 'brake_static_gain',
    'gear', 'reverse', 'hand_brake', 'manual_gear_shift',
    'control_transport', 'control_submit_ok', 'control_tick_frame', 'control_feedback_frame',
    'physics_max_substep_dt', 'brake_release_active', 'brake_release_seconds',
    'brake_release_events', 'actuator_a_target',
    # v30: same DynamicMap observation as ego_x/y; radians and full body sizes.
    'ego_yaw', 'ego_length', 'ego_width',
]


class InteractionLogger:
    """逐帧 + 逐回合的交互诊断记录器（单例使用，见 get_logger）。"""

    def __init__(self, out_dir=None, enabled=None, report_every=10, flush_every=500):
        if enabled is None:
            enabled = os.environ.get('DSH_ILOG', '1') == '1'
        self.enabled = bool(enabled)
        self.out_dir = _resolve_out_dir(out_dir)
        self.report_every = max(1, int(report_every))
        self.flush_every = max(1, int(flush_every))
        self.episode = 0
        self.frame = 0
        self._rv_rows_since_flush = 0
        self._rv_prev_v = {}          # actor_id -> 上一帧速度
        self._brake_onset = {}        # actor_id -> 首次减速记录
        self._last_decision = {}      # actor_id -> {'behavior','reason','zone_a',...}
        self._last_ego = {}           # 最近一次 ego_row 的 ego 侧量
        # 【碰撞埋点】actor_id -> 最近一帧的 {'behavior','reason','target','v'}
        self._last_rv_row = {}
        self._ep = self._new_ep()
        self._totals = self._new_ep()
        self._files = {}
        self._writers = {}
        self._fh = {}
        self._header_len = {}
        if self.enabled:
            self._open_files()

    # ---------------- 文件管理 ----------------
    def _new_ep(self):
        return {
            'n_rv_frames': 0, 'n_decision': 0,
            'n_yield_zoneA': 0, 'n_yield_committed': 0, 'n_yield_emergency': 0,
            'n_yield_bernoulli': 0, 'n_rush_bernoulli': 0,
            # 首次刹车的四类（互斥，见 rv_row 的分类逻辑）
            'n_early_brake': 0,       # 自车仍远(>EARLY_DIST) → 与我们的规则无关，RV 自己早刹
            'n_zoneA_brake': 0,       # 自车进入 zone A(R_A) 时刹 → 我们自己的规则在起作用
            'n_committed_brake': 0,   # 自车已越过冲突点才刹
            'n_other_brake': 0,       # 其余（R_A 与 EARLY_DIST 之间的过渡带）
            'first_brake_ego_arc': None,
            'first_brake_ego_dist': None,
            'first_brake_rv_dist': None,
            'first_brake_rv_v': None,
            'first_brake_zoneA': None,
            'first_brake_cat': None,
            'rv_min_v': None,
            'rv_v_at_commit': None,
            'rv_dist_at_commit': None,
            'n_commit_observed': 0,
            # 【创新点④·P1-g】边界安全动作屏蔽的命中统计
            'n_shield_block': 0,      # ④ 屏蔽改写了所选动作的次数
            'n_shield_block_nonzero': 0,   # 其中被拦下的**非刹车**动作次数
        }

    def _open_files(self):
        try:
            os.makedirs(self.out_dir, exist_ok=True)
        except Exception:
            pass
        specs = {
            'rv': ('interaction_rv.csv',
                   ['episode', 'frame', 'rv_id', 'rv_x', 'rv_y', 'rv_v', 'rv_acc',
                    'rv_dist_conflict', 'rv_t_veh', 'behavior', 'reason', 'target_speed',
                    'zone_a', 'in_zone', 'ego_x', 'ego_y', 'ego_v', 'ego_arc',
                    'ego_dist_conflict', 'ego_committed', 'ttc_boundary', 'brake_onset',
                    'since_decision']),
            'ego': ('interaction_ego.csv', EGO_COLUMNS),
            'sum': ('interaction_summary.csv',
                    ['episode', 'outcome', 'collision', 'stuck', 'n_rv_frames',
                     'n_decision', 'yield_zoneA', 'yield_committed', 'yield_emergency',
                     'yield_bernoulli', 'rush_bernoulli', 'yield_zoneA_ratio',
                     'yield_bernoulli_ratio', 'n_early_brake',
                     'n_zoneA_brake', 'n_committed_brake', 'n_other_brake',
                     'first_brake_ego_arc',
                     'first_brake_ego_dist', 'first_brake_rv_dist', 'first_brake_rv_v',
                     'first_brake_zoneA', 'first_brake_cat',
                     'rv_min_v', 'rv_v_at_commit', 'rv_dist_at_commit',
                     # 【④·P1-g】shield_* 放在 frames **之前**：保持 frames 仍是最后一列，
                     #   既有的按位取值（如 test_interaction_logger）与下游分析不受影响
                     'n_commit_observed', 'shield_block', 'shield_block_nonzero', 'frames']),
            # 【诊断埋点】碰撞的**真实对方**（来自 CARLA 碰撞传感器 event.other_actor）。
            #   每回合最多一行（只有碰撞回合才有）。有了它，A/B/C/D 分类就从
            #   "末帧最近 RV"的代理推断变成事实：撞的是谁、它当时让行还是抢行。
            'col': ('interaction_collision.csv',
                    ['episode', 'frame', 'other_id', 'other_type', 'other_role',
                     'other_x', 'other_y', 'other_yaw', 'other_v',
                     'ego_x', 'ego_y', 'ego_v', 'arc_to_cross', 'committed',
                     # 该对手在碰撞前的**博弈决策**（从车流侧日志里回查）
                     'rv_behavior', 'rv_reason', 'rv_target_speed', 'rv_v_logged',
                     'lcttc_rv', 'lcttc_fv', 'lcttc_min', 'n_vehicles']),
        }
        for key, (name, header) in specs.items():
            path = os.path.join(self.out_dir, name)
            is_new = not os.path.exists(path)
            fh = open(path, 'a', newline='')
            self._fh[key] = fh
            self._writers[key] = csv.writer(fh)
            self._header_len[key] = len(header)
            if is_new:
                self._writers[key].writerow(header)
                fh.flush()

    # ---------------- 回合/帧管理 ----------------
    def begin_episode(self, episode):
        self.episode = int(episode)
        self.frame = 0
        self._rv_prev_v = {}
        self._brake_onset = {}
        self._last_decision = {}
        self._ep = self._new_ep()
        if self.enabled:
            # 上个回合的行已落盘（end_episode 强制 flush），这里只需保证句柄可用
            for fh in self._fh.values():
                try:
                    fh.flush()
                except Exception:
                    pass

    def tick(self):
        """每仿真步调用一次（CrossTrafficManager.run_step 开头）。"""
        self.frame += 1
        return self.frame

    # ---------------- RV 观测 ----------------
    def rv_row(self, rv_id, rv_x, rv_y, rv_v, behavior=None, reason=None,
               target_speed=None, zone_a=False, in_zone=False,
               ego_dist=None, ego_arc=None, conflict_x=0.0, conflict_y=0.0,
               committed=False, ttc_boundary=None, dt=0.05, rv_acc=None,
               ego_x=None, ego_y=None, ego_v=None):
        """记录一辆 RV 在决策区窗口内的逐帧状态；返回 True 表示本帧是"开始刹车"。

        提前刹车判定（本模块要回答的核心问题）：
          在观测窗口内、由帧间速度差（或传入的 rv_acc）估计出 acc < BRAKE_ACC_TH，
          且该 RV 尚无刹车记录 → 记为刹车起点，并按 ego 当时的位置分成四类（互斥）：
            early     : ego 距冲突点 > EARLY_DIST(默认 12m) → RV 自己早刹，与我们的规则无关
            zoneA     : 我们自己的 zone A 规则生效时刹 → **环境被我们变简单**的直接证据
            committed : ego 已越过冲突点才刹
            other     : 其余（R_A 与 EARLY_DIST 之间的过渡带）
          同时记录首次刹车时的 ego 距离/弧长、RV 距离/车速。
        """
        if not self.enabled:
            return False
        self._ep['n_rv_frames'] += 1

        v = float(rv_v if rv_v is not None else 0.0)
        prev = self._rv_prev_v.get(rv_id)
        self._rv_prev_v[rv_id] = v
        acc_est = None
        if rv_acc is not None:
            acc_est = float(rv_acc)
        elif prev is not None and dt:
            acc_est = (v - prev) / float(dt)

        early_dist = float(os.environ.get('DSH_EARLY_BRAKE_D', '12.0'))
        brake_new = False
        if in_zone and acc_est is not None and acc_est < BRAKE_ACC_TH \
                and rv_id not in self._brake_onset:
            brake_new = True
            ed = None if ego_dist is None else float(ego_dist)
            # 刹车起点分类（互斥）：先看"自车是否已经过去"，再看"是不是离得很远时自己刹的"，
            # 然后是"我们自己的 zone A 规则生效时刹的"。注意 R_A(默认 8m) < EARLY_DIST(12m)，
            # 故 early 与 zoneA 天然互斥；若把 R_A 调大，early 判定优先（说明与规则无关）。
            if committed:
                cat = 'committed'
            elif ed is not None and ed > early_dist:
                cat = 'early'
            elif zone_a:
                cat = 'zoneA'
            else:
                cat = 'other'
            rec = {'frame': self.frame, 'ego_dist': ed, 'ego_arc': ego_arc,
                   'rv_dist': abs(float(rv_x) - float(conflict_x)),
                   'rv_v': v, 'zone_a': bool(zone_a), 'cat': cat,
                   'behavior': behavior, 'reason': reason}
            self._brake_onset[rv_id] = rec
            self._ep['n_%s_brake' % cat] += 1
            if self._ep['first_brake_ego_arc'] is None:
                self._ep['first_brake_ego_arc'] = ego_arc
                self._ep['first_brake_ego_dist'] = ed
                self._ep['first_brake_rv_dist'] = rec['rv_dist']
                self._ep['first_brake_rv_v'] = v
                self._ep['first_brake_zoneA'] = bool(zone_a)
                self._ep['first_brake_cat'] = cat

        if self._ep['rv_min_v'] is None:
            self._ep['rv_min_v'] = v
        else:
            self._ep['rv_min_v'] = min(self._ep['rv_min_v'], v)

        if self._last_decision.get(rv_id) and (behavior is None or reason is None):
            behavior = behavior or self._last_decision[rv_id].get('behavior')
            reason = reason or self._last_decision[rv_id].get('reason')
        # 距上次决策的帧数：用于区分"这次刹车是决策驱动的（≈0~2 帧）"
        # 还是"IDM 阻抗/前车导致的（远离决策时刻）"——避免把"进决策区就按让行决策"
        # 误判成"RV 提前刹车把环境变简单"
        _last_dec = self._last_decision.get(rv_id)
        _since = (self.frame - int(_last_dec['frame'])) if _last_dec else None
        # 【碰撞埋点】缓存该 RV 本帧的决策/速度，供 collision_row 回查"撞的那一刻
        #   对手在让行还是抢行、目标速度多少"（按 (episode, rv_id) 存最新一帧）
        self._last_rv_row[rv_id] = {
            'behavior': behavior, 'reason': reason, 'target': target_speed,
            'v': v, 'frame': self.frame,
        }

        self._write('rv', [
            self.episode, self.frame, rv_id,
            _r(rv_x), _r(rv_y), _r(v), _r(acc_est),
            _r(abs(float(rv_x) - float(conflict_x))),
            _r(_safe_div(abs(float(rv_x) - float(conflict_x)), max(v, 0.1))),
            behavior, reason, _r(target_speed), int(bool(zone_a)), int(bool(in_zone)),
            _r(ego_x), _r(ego_y), _r(ego_v), _r(ego_arc),
            _r(ego_dist), int(bool(committed)), _r(ttc_boundary), int(brake_new),
            _since])
        return brake_new

    def rv_decision(self, rv_id, behavior, reason, p_yield=None, ttc=None,
                    zone_a=False, rv_x=None, rv_v=None, ego=None,
                    arc_to_cross=0.0, committed=False):
        """记录一次 RV 让行/抢行决策（2s 周期或首次进入决策区触发）。"""
        if not self.enabled:
            return
        self._ep['n_decision'] += 1
        self._last_decision[rv_id] = {'behavior': behavior, 'reason': reason,
                                      'zone_a': zone_a, 'frame': self.frame}
        r = str(reason or '')
        if behavior == 'yield':
            if r.startswith('zoneA'):
                self._ep['n_yield_zoneA'] += 1
            elif r.startswith('committed'):
                self._ep['n_yield_committed'] += 1
            elif r.startswith('emergency'):
                self._ep['n_yield_emergency'] += 1
            else:
                self._ep['n_yield_bernoulli'] += 1
        else:
            self._ep['n_rush_bernoulli'] += 1

    # ---------------- ego 观测 ----------------
    def ego_row(self, conf=None, ego=None, action=None, rule_action=None,
                takeover=None, reward=None, efe_last=None,
                shield_danger=None, shield_lcttc_min=None, traj_id=None,
                decision_src=None, thw_worst=None, band=None,
                epsilon_now=None, eps_triggered=None,
                v_ref=None, v_ref_before_floor=None, action_speed=None,
                rl_speed_cap=None,
                comfort_j=None, comfort_s=None, lat_mask=None, lat_screened=None,
                cand_mask=None,
                info_card=None, info_hlen=None, info_perfect=None, info_npart=None,
                info_err=None, causal_err=None, complete_fired=None,
                rv_action_entropy=None,
                wait_standoff=None, clamp_stopped=None, clamp_stop_num=None, clamp_err=None,
                gap_switch_num=None, gap_glitch_num=None,
                r_safe_obj=None, r_prox_obj=None, r_pet_obj=None,
                h_lcttc_min=None, d_ab_min=None, pet_min=None,
                pbrs_shaping=None, obj_err=None, wait_overshoot_num=None,
                entry_granted=None, committing=None,
                commit_latched=None, gap_ok=None,
                force_clear_num=None, force_clear_blocked_num=None,
                t_ego_go=None, clr_go=None, band_entry_x=None,
                commit_risk=None, risk_veh=None,
                pyield_prior=None, pyield_hat=None, pyield_n=None, thw_in=None,
                ego_intent=None, intent_rate=None,
                take_cournot=None, risk_gate_ok=None,
                t_veh_sorted=None, t_veh_worst=None, n_cand=None, conflict_x=None,
                rew_parts=None, rew_resid=None,
                cournot_gate_reason=None, risk_value_ok=None, efe_dpsi=None,
                rl_active=None, control=None, completion=None):
        """记录 ego 逐帧状态/动作/接管/安全量与 EFE 诊断（EFE 关闭时留空）。"""
        if not self.enabled:
            return
        conf = conf or {}
        rv = conf.get('rv_veh')
        e = self._ep
        rv_v = getattr(rv, 'v', None)
        committed = bool(conf.get('committed', False))
        if committed and rv is not None and e['n_commit_observed'] == 0:
            e['n_commit_observed'] += 1
            e['rv_v_at_commit'] = _r(rv_v)
            e['rv_dist_at_commit'] = _r(abs(float(getattr(rv, 'x', 0.0))
                                            - float(conf.get('conflict_x', 0.0))))
        ef = efe_last or {}
        ef_efe = ef.get('efe') or {}
        # 缓存 ego 侧量（arc/committed），供车流管理器在下一帧记 RV 刹车事件时引用
        # （RV 的 run_step 发生在 ego 的奖励计算之前，故存在 1 帧≈0.05s 的滞后）
        self._last_ego = {
            'x': getattr(ego, 'x', None), 'y': getattr(ego, 'y', None),
            'v': getattr(ego, 'v', None),
            'arc': conf.get('arc_to_cross'), 'committed': committed,
            'dist': conf.get('dist_to_cross'),
            # 【P0-step0】连续弧长/横向偏差也缓存，供碰撞行回填
            'arc_cont': conf.get('arc_cont'), 'lat_dev': conf.get('lat_dev'),
            't_ego_cont': conf.get('t_ego_cont'),
            # 【碰撞埋点】把边界量与车辆数也缓存，供 collision_row 回填
            'lcttc_rv': conf.get('lcttc_rv'), 'lcttc_fv': conf.get('lcttc_fv'),
            'n_vehicles': conf.get('n_vehicles'),
        }
        _ego_vals = [
            self.episode, self.frame,
            _r(getattr(ego, 'x', None)), _r(getattr(ego, 'y', None)),
            _r(getattr(ego, 'v', None)),
            _r(conf.get('arc_to_cross')),
            _r(conf.get('arc_cont')), _r(conf.get('lat_dev')), _r(conf.get('t_ego_cont')),
            _r(conf.get('proj_x')), _r(conf.get('proj_y')), _r(conf.get('dist_to_cross')),
            traj_id,
            conf.get('path_src'), conf.get('path_n'), conf.get('path_fp'),
            decision_src,
            _r(conf.get('thw_boundary_rv')), _r(thw_worst),
            _r((band or {}).get('front_clearance')),
            None if not band else int(bool(band.get('occupied'))),
            None if not band else int(bool(band.get('occupied_pred'))),
            None if not band else band.get('nev_in_band'),
            _r((band or {}).get('min_x_gap')),
            _r((band or {}).get('t_entry')),
            int(committed), conf.get('n_vehicles'),
            _r(conf.get('lcttc_rv')), _r(conf.get('thw_boundary_rv')),
            _r(conf.get('lcttc_fv')),
            None if shield_danger is None else int(bool(shield_danger)),
            _r(shield_lcttc_min),
            # 【修正】`VehicleState` 的字段是 `veh_id`；原用 `.id` ⇒ 该列**一直是空的**
            (getattr(rv, 'veh_id', None) if rv is not None else None),
            _r(getattr(rv, 'x', None)), _r(rv_v),
            action, rule_action, int(bool(takeover)), _r(reward),
            int(bool(ef.get('active'))), ef.get('argmin_efe_action'),
            _r(min(ef_efe.values())) if ef_efe else None,
            _r(max(ef_efe.values())) if ef_efe else None,
            epsilon_now, None if eps_triggered is None else int(bool(eps_triggered)),
            _r(v_ref), _r(v_ref_before_floor), _r(action_speed), _r(rl_speed_cap),
            _r(comfort_j), _r(comfort_s),
            (None if lat_mask is None else ''.join('1' if x else '0' for x in lat_mask)),
            lat_screened, cand_mask,
            info_card, info_hlen,
            (None if info_perfect is None else int(bool(info_perfect))), info_npart,
            info_err, causal_err,
            (None if complete_fired is None else int(bool(complete_fired))),
            _r(rv_action_entropy),
            _r(wait_standoff), clamp_stopped, clamp_stop_num, clamp_err,
            gap_switch_num, gap_glitch_num,
            _r(r_safe_obj), _r(r_prox_obj), _r(r_pet_obj),
            _r(h_lcttc_min), _r(d_ab_min), _r(pet_min), _r(pbrs_shaping), obj_err,
            wait_overshoot_num,
            (None if entry_granted is None else int(bool(entry_granted))),
            (None if committing is None else int(bool(committing))),
            (None if commit_latched is None else int(bool(commit_latched))),
            (None if gap_ok is None else int(bool(gap_ok))),
            force_clear_num, force_clear_blocked_num,
            _r(t_ego_go), _r(clr_go), _r(band_entry_x),
            _r(commit_risk), risk_veh,
            _r(pyield_prior), _r(pyield_hat), pyield_n, _r(thw_in),
            _r(ego_intent), _r(intent_rate),
            (None if take_cournot is None else int(bool(take_cournot))),
            (None if risk_gate_ok is None else int(bool(risk_gate_ok))),
            # 【2026-10-10 新增】离线判据分析的前置埋点（见 EGO_COLUMNS 末尾注释）
            _serialize_float_list(t_veh_sorted),
            _serialize_float_list(t_veh_worst),
            n_cand, _r(conflict_x),
            # 【2026-10-12 奖励核账】各分量 + 残差探针
            _r((rew_parts or {}).get('game')), _r((rew_parts or {}).get('thw')),
            _r((rew_parts or {}).get('yaw')), _r((rew_parts or {}).get('lat')),
            _r((rew_parts or {}).get('safe')), _r((rew_parts or {}).get('prox')),
            _r((rew_parts or {}).get('pet')),
            _r((rew_parts or {}).get('eff')),
            # 【2026-10-12 正奖励项】平稳正分（与既有 comfort 惩罚互补）
            _r((rew_parts or {}).get('comfort_pos')),
            # 等待代价在两条奖励路径上同名合并（只记实际发生的那一个）
            _r((rew_parts or {}).get('wait_paper') if (rew_parts or {}).get('wait_paper') is not None
               else (rew_parts or {}).get('wait_adhoc')),
            _r((rew_parts or {}).get('hesitate')), _r((rew_parts or {}).get('comfort')),
            _r((rew_parts or {}).get('smooth')),
            _r((rew_parts or {}).get('terminal')), _r(rew_resid),
            # 【2026-10-12 修复 D2】−ambiguity（②→③ 耦合通道）
            _r((rew_parts or {}).get('efe_amb')),
            _r(efe_dpsi),
            # 【2026-10-12 修复 D3'】① 授权口径
            (str(cournot_gate_reason) if cournot_gate_reason is not None else ''),
            _r(risk_value_ok)]
        control = control or {}
        completion = completion or {}
        _ego_vals.extend([
            None if rl_active is None else int(bool(rl_active)),
            *[_r(control.get(key), 6) for key in (
                'a_mpc', 'delta_mpc_rad', 'a_cmd', 'delta_rad',
                'throttle', 'brake', 'steer', 'mpc_l', 'mpc_epsi')],
            (None if control.get('mpc_solve_ok') is None
             else int(bool(control['mpc_solve_ok']))),
            (None if completion.get('strict_complete') is None
             else int(bool(completion['strict_complete']))),
            (None if completion.get('legacy_complete') is None
             else int(bool(completion['legacy_complete']))),
            *[_r(completion.get(key)) for key in (
                'goal_distance', 'path_distance', 'heading_error', 'path_progress')],
            control.get('planning_status'),
            (None if control.get('trajectory_force_stop') is None
             else int(bool(control['trajectory_force_stop']))),
            _r(control.get('trajectory_speed_limit')),
            control.get('execution_reason'), _r(control.get('v_ref_before_guard')),
            _r(control.get('goal_remaining')), control.get('geometry_source'),
            _r(control.get('a_prev')), _r(control.get('steer_prev')),
        ])
        learning = control.get('learning') or {}
        def _distribution(key):
            value = learning.get(key)
            return '' if value is None else json.dumps(value, separators=(',', ':'), allow_nan=False)
        _ego_vals.extend([
            learning.get('learning_mode'), learning.get('belief_rv_id'), _distribution('belief'),
            _r(learning.get('belief_entropy'), 6), _r(learning.get('belief_evidence'), 6),
            _distribution('soft_policy'), _distribution('baseline_policy'), _distribution('behavior_policy'),
            _r(learning.get('soft_value'), 6), _r(learning.get('soft_information_cost'), 6),
            _r(learning.get('information_cost'), 6), _r(learning.get('bellman_residual'), 6),
            learning.get('bellman_sweeps'),
            None if 'learning_decision' not in learning else int(bool(learning['learning_decision'])),
            None if 'behavior_model_valid' not in learning else int(bool(learning['behavior_model_valid'])),
            learning.get('learning_reward_mode'), _r(learning.get('efe_learning_reward'), 6),
        ])
        _ego_vals.extend([
            _r(conf.get('rv_acc'), 6), conf.get('rv_acc_source'),
            _r(conf.get('rv_acc_follow'), 6), conf.get('rv_acc_follow_source'),
        ])
        game = control.get('mpc_game') or {}
        _ego_vals.extend([
            control.get('game_controller'),
            None if 'enabled' not in game else int(bool(game['enabled'])),
            None if 'active' not in game else int(bool(game['active'])),
            game.get('rv_id'), game.get('fv_id'), game.get('safety_mode'),
            *[_r(game.get(key), 6) for key in ('speed', 'safety', 'comfort', 'total')],
            None if 'stackelberg_active' not in control else int(bool(control['stackelberg_active'])),
        ])
        gate = control.get('feasibility') or {}
        _ego_vals.extend([
            control.get('control_profile'), gate.get('phase'),
            None if 'safe' not in gate else int(bool(gate['safe'])),
            _r(gate.get('min_gap'), 6), gate.get('conflict_id'),
            ';'.join(str(v) for v in gate.get('threat_ids', [])),
            ';'.join(str(v) for v in game.get('participant_ids', [])),
            _r(control.get('prediction_horizon'), 6),
            _r(control.get('mpc_solve_ms'), 3),
            _r(control.get('mpc_audit_gap'), 6), control.get('mpc_audit_actor'),
            None if 'mpc_audit_override' not in control else int(bool(control['mpc_audit_override'])),
        ])
        audit = control.get('execution_audit') or {}
        candidates = audit.get('candidates', [])
        selected = next((c for c in candidates if c['action'] == audit.get('action')), {})
        _ego_vals.extend([
            control.get('actuator_mode'), control.get('sim_frame_before'), control.get('sim_frame_after'),
            *[_r(control.get(key), 6) for key in ('sim_time_before', 'sim_time_after', 'sim_dt',
                'ego_v_before', 'ego_v_after', 'ego_acc_measured', 'actuator_speed_target',
                'actuator_accel_limit', 'physical_max_steer', 'wheelbase')],
            audit.get('action'), _r(selected.get('gap'), 6),
            None if 'safe' not in audit else int(bool(audit['safe'])),
            None if 'unavoidable' not in audit else int(bool(audit['unavoidable'])),
            ';'.join('%s:%s' % (c['action'], _r(c['gap'], 6)) for c in candidates),
            None if 'body_clear' not in gate else int(bool(gate['body_clear'])),
            control.get('mpc_solver_status'), control.get('mpc_failure_snapshot'),
            control.get('control_probe_phase'),
            _r(control.get('control_probe_phase_seconds'), 6), control.get('control_probe_failure'),
            *[_r(control.get(key), 6) for key in ('ego_v_signed_before', 'ego_v_signed_after',
                'ego_acc_signed', 'ego_acc_sensor', 'actuator_filtered_acc', 'actuator_integral')],
            control.get('actuator_pedal_mode'),
            *[_r(control.get(key), 6) for key in ('requested_throttle', 'requested_brake',
                'requested_steer', 'brake_static_gain')],
            *[control.get(key) for key in ('gear', 'reverse', 'hand_brake', 'manual_gear_shift')],
            *[control.get(key) for key in ('control_transport', 'control_submit_ok', 'control_tick_frame',
                                         'control_feedback_frame')],
            _r(control.get('physics_max_substep_dt'), 6), control.get('brake_release_active'),
            _r(control.get('brake_release_seconds'), 6), control.get('brake_release_events'),
            _r(control.get('actuator_a_target'), 6),
        ])
        # DynamicMap.boxx/boxy already contain 2 * bounding_box.extent.
        # Do not query a newer CARLA frame or substitute nominal dimensions.
        for index, name in enumerate(('yaw', 'boxx', 'boxy')):
            value = getattr(ego, name, None)
            observed = None if isinstance(value, bool) else _r(value, 6)
            if index > 0 and observed is not None and observed <= 0.:
                observed = None
            _ego_vals.append(observed)
        # 【单一来源守卫】表头与数据行长度不一致时**立即报错**（而不是静默错位）
        if len(_ego_vals) != len(EGO_COLUMNS):
            raise RuntimeError(
                f'interaction_ego 列数不一致: 值={len(_ego_vals)} 表头={len(EGO_COLUMNS)}; '
                f'请在 EGO_COLUMNS 与 ego_row 之间同步增删列')
        self._write('ego', _ego_vals)

    def last_ego(self):
        """最近一次 ego_row 缓存的 ego 侧量（车流管理器用来记 RV 刹车事件）。"""
        return getattr(self, '_last_ego', None) or {}

    def shield_block(self, blocked=None, fallback=None):
        """【创新点④·P1-g】记录一次"边界安全屏蔽改写了动作"。

        每次调用天然就是一次判定；`self.frame` 由 `tick()` 推进，故这里直接
        计入当前**回合**与**累计**两套计数器。
        """
        for d in (self._ep, self._totals):
            try:
                d['n_shield_block'] = int(d.get('n_shield_block', 0)) + 1
                if blocked is not None and int(blocked) != 0:
                    d['n_shield_block_nonzero'] = int(d.get('n_shield_block_nonzero', 0)) + 1
            except Exception:
                pass

    # ---------------- 回合结束 ----------------
    def collision_row(self, event=None, other_id=None):
        """【诊断埋点】写一行"碰撞的**真实对方**"到 interaction_collision.csv。

        `event` 来自 `TestScenario_Town03_turn._on_ego_collision`（CARLA 碰撞传感器的
        `event.other_actor`），含 other_id/type/位置/速度。再回查：
          · ego 侧：上一帧缓存（位置/速度/arc/committed/边界量）
          · 对手侧：`_last_rv_row[other_id]`（让行/抢行、原因、目标速度、日志速度）
        `other_id` 显式传入时优先（用于事件缺 id 的兜底）。
        """
        if not self.enabled:
            return
        ev = event or {}
        oid = other_id if other_id is not None else ev.get('other_id')
        ego = self._last_ego or {}
        rvl = {}
        try:
            if oid is not None and int(oid) in self._last_rv_row:
                rvl = self._last_rv_row[int(oid)]
        except (TypeError, ValueError):
            rvl = {}
        _lc_rv = ego.get('lcttc_rv')
        _lc_fv = ego.get('lcttc_fv')
        try:
            _lc_min = min([v for v in (float(_lc_rv), float(_lc_fv)) if v == v] or [None])
        except (TypeError, ValueError):
            _lc_min = None
        self._write('col', [
            self.episode, ev.get('frame', self.frame),
            oid, ev.get('other_type'), ev.get('other_role'),
            _r(ev.get('other_x')), _r(ev.get('other_y')), _r(ev.get('other_yaw')),
            _r(ev.get('other_v')),
            _r(ev.get('ego_x', ego.get('x'))), _r(ev.get('ego_y', ego.get('y'))),
            _r(ego.get('v')), _r(ego.get('arc')), None if ego.get('committed') is None
            else int(bool(ego.get('committed'))),
            rvl.get('behavior'), rvl.get('reason'), _r(rvl.get('target')),
            _r(rvl.get('v')),
            _r(_lc_rv), _r(_lc_fv), _r(_lc_min), ego.get('n_vehicles'),
        ], force_flush=True)

    def end_episode(self, outcome='', collision=False, stuck=False, frames=None,
                    collision_event=None):
        if not self.enabled:
            return
        # 【诊断埋点】碰撞回合额外写一行"真实对方"
        if collision_event is not None or collision:
            try:
                self.collision_row(event=collision_event)
            except Exception as _e:
                print(f'[InteractionLog] collision_row 失败: {type(_e).__name__}: {_e}')
        e = self._ep
        row = self._summary_row(e, outcome, collision, stuck, frames)
        self._write('sum', row, force_flush=True)
        for k in self._totals:
            if isinstance(self._totals[k], (int, float)) and isinstance(e.get(k), (int, float)):
                self._totals[k] += e[k]
        self._totals['n_commit_observed'] += e['n_commit_observed']
        if self.episode % self.report_every == 0:
            self._write_report()
        return row

    def _summary_row(self, e, outcome, collision, stuck, frames):
        nd = max(e['n_decision'], 1)
        nb = max(e['n_yield_bernoulli'] + e['n_rush_bernoulli'], 1)
        return [
            self.episode, outcome, int(bool(collision)), int(bool(stuck)),
            e['n_rv_frames'], e['n_decision'],
            e['n_yield_zoneA'], e['n_yield_committed'], e['n_yield_emergency'],
            e['n_yield_bernoulli'], e['n_rush_bernoulli'],
            _r(e['n_yield_zoneA'] / nd), _r(e['n_yield_bernoulli'] / nb),
            e['n_early_brake'], e['n_zoneA_brake'], e['n_committed_brake'],
            e['n_other_brake'],
            _r(e['first_brake_ego_arc']), _r(e['first_brake_ego_dist']),
            _r(e['first_brake_rv_dist']), _r(e['first_brake_rv_v']),
            None if e['first_brake_zoneA'] is None else int(e['first_brake_zoneA']),
            e.get('first_brake_cat'),
            _r(e['rv_min_v']), e['rv_v_at_commit'], e['rv_dist_at_commit'],
            e['n_commit_observed'],
            e.get('n_shield_block', 0), e.get('n_shield_block_nonzero', 0),
            frames if frames is not None else self.frame,
        ]

    # ---------------- 报告 ----------------
    def _write_report(self, path=None):
        t = self._totals
        lines = []
        lines.append('=' * 78)
        lines.append(f'交互诊断汇总（截至第 {self.episode} 回合，累计）')
        lines.append(f'时间: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        lines.append('=' * 78)
        nd = max(t['n_decision'], 1)
        lines.append(f'RV 决策次数            : {t["n_decision"]}')
        lines.append(f'  让行·zoneA(强制)     : {t["n_yield_zoneA"]:5d}  '
                     f'({t["n_yield_zoneA"] / nd * 100:5.1f}%)   ← 我们自己规则造成的让行')
        lines.append(f'  让行·committed       : {t["n_yield_committed"]:5d}  '
                     f'({t["n_yield_committed"] / nd * 100:5.1f}%)')
        lines.append(f'  让行·emergency       : {t["n_yield_emergency"]:5d}  '
                     f'({t["n_yield_emergency"] / nd * 100:5.1f}%)')
        lines.append(f'  让行·bernoulli(博弈) : {t["n_yield_bernoulli"]:5d}  '
                     f'({t["n_yield_bernoulli"] / nd * 100:5.1f}%)   ← 真正的博弈让行')
        lines.append(f'  抢行·bernoulli       : {t["n_rush_bernoulli"]:5d}  '
                     f'({t["n_rush_bernoulli"] / nd * 100:5.1f}%)')
        nbr = t['n_early_brake'] + t['n_zoneA_brake'] + t['n_committed_brake'] \
            + t['n_other_brake']
        lines.append('-' * 78)
        lines.append(f'首次刹车事件           : {nbr}')
        lines.append(f'  提前刹车(ego 仍远)    : {t["n_early_brake"]:5d}'
                     + (f'  ({t["n_early_brake"] / nbr * 100:5.1f}%)' if nbr else '')
                     + '   ← 与我们规则无关，RV 自己早刹')
        lines.append(f'  zone A 生效时刹       : {t["n_zoneA_brake"]:5d}'
                     + (f'  ({t["n_zoneA_brake"] / nbr * 100:5.1f}%)' if nbr else '')
                     + '   ← 我们自己的规则在起作用')
        lines.append(f'  ego 已越过才刹        : {t["n_committed_brake"]:5d}')
        lines.append(f'  其余(过渡带)          : {t["n_other_brake"]:5d}')
        lines.append('-' * 78)
        _nsb = int(t.get('n_shield_block', 0))
        _nsbn = int(t.get('n_shield_block_nonzero', 0))
        lines.append(f'【④ 边界安全动作屏蔽】 命中 {_nsb} 帧，'
                     f'其中拦下"非刹车"动作 {_nsbn} 帧'
                     + (f'（{_nsbn / _nsb * 100:.1f}%）' if _nsb else ''))
        lines.append('=' * 78)
        text = '\n'.join(lines) + '\n'
        try:
            p = path or os.path.join(self.out_dir, 'interaction_report.txt')
            with open(p, 'w') as fw:
                fw.write(text)
        except Exception:
            pass
        print('[InteractionLog] ' + ' | '.join(lines[2:5]))
        print(f'[InteractionLog] 刹车分类 early={t["n_early_brake"]} '
              f'zoneA={t["n_zoneA_brake"]} committed={t["n_committed_brake"]} '
              f'other={t["n_other_brake"]} | 决策 {t["n_decision"]}，'
              f'zoneA让行占比 {t["n_yield_zoneA"] / nd * 100:.1f}%')

    # ---------------- 写盘 ----------------
    def _write(self, key, row, force_flush=False):
        w = self._writers.get(key)
        if w is None:
            return
        expect = self._header_len.get(key)
        if expect is not None and len(row) != expect:
            # 列数不一致会让 CSV 错位到无法分析，必须显式暴露（只在开发期触发）
            print(f"[InteractionLog]: {key} 行列数 {len(row)} != 表头 {expect}，已跳过该行")
            return
        try:
            w.writerow(row)
        except Exception:
            return
        if key == 'rv':
            self._rv_rows_since_flush += 1
            if not force_flush and self._rv_rows_since_flush < self.flush_every:
                return
            self._rv_rows_since_flush = 0
        try:
            self._fh[key].flush()
        except Exception:
            pass

    def close(self):
        for fh in self._fh.values():
            try:
                fh.flush()
                fh.close()
            except Exception:
                pass
        self._fh = {}
        self._writers = {}


# ============================================================
# 单例
# ============================================================
_LOGGER = None


def get_logger(out_dir=None, enabled=None):
    """进程内单例（车流管理器与 agent 共用同一份日志）。"""
    global _LOGGER
    if _LOGGER is None:
        _LOGGER = InteractionLogger(out_dir=out_dir, enabled=enabled)
    return _LOGGER


def reset_logger():
    """测试用：丢弃当前单例。"""
    global _LOGGER
    if _LOGGER is not None:
        _LOGGER.close()
    _LOGGER = None


# ---------------- 小工具 ----------------
def _r(x, nd=3):
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(f):
        return None
    return round(f, nd)


def _safe_div(a, b):
    try:
        b = float(b)
        return float(a) / b if abs(b) > 1e-9 else float('inf')
    except (TypeError, ValueError):
        return float('inf')


def _serialize_float_list(xs, nd=3, max_n=12):
    """把浮点列表序列化成 `v1;v2;v3`（供 CSV 单列承载列表用）。

    【2026-10-10 新增】为什么需要：
      `t_veh_sorted` / `t_veh_worst` 是**列表**，而它们是占用窗判据与机会约束的
      唯一输入。此前没有落盘 ⇒ 无法离线重算 `gap_ok` / `commit_risk`。
    为什么用 `;` 而不是 `,`：CSV 的分隔符是逗号，用分号可避免加引号，
    下游 `pandas.read_csv` 与 `csv.DictReader` 都能直接读出字符串再 split。
    `max_n` 截断：机会约束的 `max_veh` 默认 8，取 12 足够且避免异常长行。
    非有限值（inf/nan）写成 `inf`/`nan` 字面量，便于下游识别"无车"语义。
    """
    if xs is None:
        return None
    try:
        items = list(xs)
    except TypeError:
        return None
    if not items:
        return ''
    out = []
    for v in items[:max_n]:
        try:
            fv = float(v)
        except (TypeError, ValueError):
            continue
        if math.isinf(fv):
            out.append('inf' if fv > 0 else '-inf')
        elif math.isnan(fv):
            out.append('nan')
        else:
            out.append(str(round(fv, nd)))
    return ';'.join(out)
