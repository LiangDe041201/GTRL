import os
import numpy as np
import math
from scipy import stats
from .rtree_env import Rtree_env
from .rtree_lane import Rtree_lane
# ③ 式60 方差修正的 WCV/BCV（主动推理置信修正，纯函数）
from .active_inference import wcv_bcv

# ============================================================================
# 【标定·2026-10-15】env_sign 的 8 维容差基准值
# ----------------------------------------------------------------------------
# 容差**直接决定**状态条件化后的样本量 n，进而决定式(43) 的
#     δ = (R_max − R_min)·√(ln(1/α)/(2n))
# 而接管条件是 WCV(替代) > BCV(规则)，即 **ΔQ̂ > δ(替代) + δ(规则)**。
#
# 实测（A6fix100，R-tree 44047 样本，R(p1–p99)=3331）：
#   · 现状容差下，每动作的**局部**样本数中位仅 **140** ⇒ δ≈400
#     ⇒ 接管需 ΔQ̂ > 800，而实测动作间差只有 ~150
#     ⇒ **机制结构上无法行动**（可接管邻域占比 **0.8%**）
#   · 逐维定位：瓶颈是 `[2]`（右前方最近车辆距离）。左转场景中横向车流会不断
#     穿过该扇区 ⇒ 该维逐帧剧变，±3.0m 的窄窗把邻域切碎
#
# 放宽倍数 k 的离线实测（`Tools/offline_wcv_replay.py` 同源方法）：
#     k=1 ⇒ n中位 140、可接管 0.8%      k=5 ⇒ n 480、19.1%
#     k=3 ⇒ n 365、可接管 7.6%          k=8 ⇒ n 600、40.0%
#   且**所有倍数的接管方向检验均为 100%**（即被选中的替代动作，其状态匹配
#   均值确实更高）⇒ 放宽是**偏差-方差权衡**，不是引入噪声。
#
# ⚠️ `DSH_ENV_TOL_SCALE` 默认 **1.0 = 保持原行为**，以免静默改变任何历史基线。
#    推荐标定值 **5.0**（最小够用 + 保留较多状态特异性）。
# ============================================================================
_ENV_TOL_BASE = np.array([3.0, 3.0, 3.0, 3.0, 0.8, 3.0, 0.02, 1.5])
_ENV_TOL_SCALE_CACHE = [None]


def env_tol_scale():
    """读取 `DSH_ENV_TOL_SCALE`（惰性缓存；非法值回退 1.0 = 原行为）。"""
    if _ENV_TOL_SCALE_CACHE[0] is None:
        try:
            v = float(os.environ.get('DSH_ENV_TOL_SCALE', '1.0'))
            if not math.isfinite(v) or v <= 0.0:
                v = 1.0
        except (TypeError, ValueError):
            v = 1.0
        _ENV_TOL_SCALE_CACHE[0] = v
    return _ENV_TOL_SCALE_CACHE[0]


class Trustset:
    def __init__(self):
        """
        初始化信任区域管理器
        """
        self.rule_dataset = []
        self.RL_dataset = []
        self.relevant_data = []
        # ===== 【0' 诊断·D4】哨兵/样本量统计（只计数，不改变任何决策）=====
        #   动机：`n_thres=10` 是硬编码，且 `dateset_rtree` **只按动作索引、不按状态**
        #   （全局池化）。所以动作数从 8 -> 12 -> 48 时，每动作样本 ~137 -> ~92 -> ~23，
        #   哨兵（±1e9）触发率会显著上升。历史 300 回合崩溃即源于此。
        self.diag = {
            'calls': 0,
            'sentinel_empty_neighborhood': 0,   # not relevant_data -> ±1e9
            'sentinel_thin_data': 0,            # len(dateset_rtree[act]) < n_thres -> ±1e9
            'thin_detail': {},                  # act -> 触发 thin 的次数
            'min_count_seen': {},               # act -> 观测到的最小样本数
        }

        # 使用 R-tree 的时候开启
        self.Rtree_env = Rtree_env()
        self.Rtree_lane = Rtree_lane()
        self.dateset_rtree = {}
        self.sample = {}

        # 不同驾驶风格向量
        # note：感觉奖励方程只有前两个有效
        self.efficient_style = np.array([1, 0, 1, 1])
        self.comfortable_style = np.array([0, 1, 1, 1])

        # 获取当前驾驶风格
        # self.driving_style = self.efficient_style
        self.driving_style = [1, 1, 1, 1]
        # 论文式60 方差修正系数：WCV = Q̂ − var_weight·4σ/(n+1) − δ
        # var_weight=1.0 即论文原式；调大更保守
        self.var_weight = 1.0
        # 【论文式44】δ=(R_max-R_min)·√(ln(1/Pf)/(2n)) 中的 (R_max-R_min)。
        #
        # ⚠【2026-10-12 修复 D1】原实现硬编码 **80**，是历史遗留值，与奖励的**真实范围**
        #   差 1~2 个数量级。实测存进 R-tree 的回报 G（=式58 折扣回报，n=42645）：
        #       min/max = −37012 / +822   ⇒ 全极差      37834
        #       p5 / p95 = −1366 / +403   ⇒ 稳健极差     1769
        #       p1 / p99                  ⇒ 稳健极差    ~3300
        #   n=12967 时 δ 仅 **0.86**，而逐动作 G 的标准差是 **300~2600**
        #   ⇒ **WCV/BCV 失去统计保守性**。离线复算（见 HANDOFF §14）：
        #        range=80    ⇒ **95.6%** 的状态都存在"可接管"的替代动作（几乎永远愿意接管）
        #        range=3300  ⇒  2.7%
        #        range=37834 ⇒  0.0%
        #   ⇒ 机制在**噪声**上接管 ⇒ 这是"全开(57%) 低于纯规则(76%)"的重要原因之一。
        #
        # 取值口径（环境变量 `DSH_REWARD_RANGE`）：
        #   'auto'（**新默认**）⇒ 用已存回报的**经验分位数**估计 (R_max−R_min)，随数据自适应
        #   <数值>              ⇒ 显式指定；**`DSH_REWARD_RANGE=80` 可完整复现修复前行为**（消融）
        #
        # ⚠️ 严谨声明（不得隐去）：分位数截断**不是严格合法的 Hoeffding 界**
        #   （随机变量的支撑集可能超出分位区间）。这是**有意的实用折中**：
        #   用全极差(37834) 会使 δ 大到机制永不接管（离线复算 0.0%），等价于废掉 ③ 的执行层。
        #   可用 `DSH_REWARD_RANGE_Q_LO=0 DSH_REWARD_RANGE_Q_HI=1` 取全极差做对照。
        self.reward_range_env = os.environ.get('DSH_REWARD_RANGE', 'auto').strip()
        #: 数据不足/异常时的回退值（实测 p1–p99 稳健极差，见上文）
        self.reward_range_fallback = float(
            os.environ.get('DSH_REWARD_RANGE_FALLBACK', '3300'))
        #: auto 模式的分位区间
        self.reward_range_q_lo = float(os.environ.get('DSH_REWARD_RANGE_Q_LO', '0.01'))
        self.reward_range_q_hi = float(os.environ.get('DSH_REWARD_RANGE_Q_HI', '0.99'))
        #: auto 模式的**最少样本数**，不足则回退
        self.reward_range_min_n = int(os.environ.get('DSH_REWARD_RANGE_MIN_N', '200'))
        #: auto 模式的缓存（避免每帧重算 4 万条的分位数）
        self._rr_cache = None
        self._rr_cache_next_n = 0
        #: 诊断：最近一次 effective_reward_range() 的取值来源
        self._rr_last_source = 'init'

    # ==================== 【2026-10-12 修复 D1】式44 的 (R_max−R_min) ====================
    def effective_reward_range(self):
        """返回式44 的 (R_max − R_min)，按 `DSH_REWARD_RANGE` 解析。

        · `'auto'`（默认）：从 `Rtree_env.locations` 里已存回报 G 的**经验分位数**估计，
          带缓存（样本量增长 20% 才重算），随奖励函数变化自适应。
        · 数值（如 `80`）：直接返回 ⇒ **可完整复现修复前行为**，用于消融。
        · 数据不足 / 非法输入 / 异常 ⇒ 回退 `reward_range_fallback`，**绝不抛异常**
          （本方法在每帧热路径上被调用 13×2 次）。
        """
        raw = str(getattr(self, 'reward_range_env', '') or '').strip().lower()
        if raw and raw not in ('auto', 'adaptive'):
            try:
                v = float(raw)
                if math.isfinite(v) and v > 0.0:
                    self._rr_last_source = 'explicit(%s)' % raw
                    return v
            except (TypeError, ValueError):
                pass          # 非法 ⇒ 落到 auto
        # ===== auto：从已存回报估计 =====
        try:
            locs = getattr(getattr(self, 'Rtree_env', None), 'locations', None) or []
            n = len(locs)
            if n < int(getattr(self, 'reward_range_min_n', 200)):
                self._rr_last_source = 'fallback(样本不足 n=%d)' % n
                return float(getattr(self, 'reward_range_fallback', 3300.0))
            if self._rr_cache is not None and n < self._rr_cache_next_n:
                return float(self._rr_cache)
            g = np.array([float(u[3]) for u in locs], dtype=float)
            g = g[np.isfinite(g)]
            if g.size < 2:
                self._rr_last_source = 'fallback(有效样本<2)'
                return float(self.reward_range_fallback)
            lo = float(np.percentile(g, float(self.reward_range_q_lo) * 100.0))
            hi = float(np.percentile(g, float(self.reward_range_q_hi) * 100.0))
            r = hi - lo
            if not (math.isfinite(r) and r > 0.0):
                self._rr_last_source = 'fallback(极差非正)'
                return float(self.reward_range_fallback)
            self._rr_cache = float(r)
            self._rr_cache_next_n = int(n * 1.2) + 1
            self._rr_last_source = 'auto(p%.2f-p%.2f,n=%d)' % (
                self.reward_range_q_lo, self.reward_range_q_hi, n)
            return float(r)
        except Exception:
            self._rr_last_source = 'fallback(异常)'
            return float(getattr(self, 'reward_range_fallback', 3300.0))

    @property
    def reward_range(self):
        """兼容旧读取点（配置打印 / 两个 ConfidenceValue）：自动返回**当前生效**值。

        用 property 而非普通属性，是为了保证**任何**读取 `self.reward_range` 的地方
        都拿到修复后的值，不会遗漏调用点。
        """
        return self.effective_reward_range()

    def add_traj_data(self, state, env_sign, action, reward, save=True):
        """添加新的经验数据到信任域。save=False 时只入树不落盘（批量写库用，避免逐条全量 dump）"""
        data_unit = (np.array(state), env_sign, int(action), reward)
        self.Rtree_env.add_data(data_unit, save=save)

    def add_lane_data(self, state, lane_sign, action, reward, save=True):
        """添加新的经验数据到信任域。save=False 时只入树不落盘（批量写库用，避免逐条全量 dump）"""
        data_unit = (np.array(state), lane_sign, int(action), reward)
        self.Rtree_lane.add_data(data_unit, save=save)

    def compare_signs(self, current_sign, tree_sign):
        """
        比较两个环境标志位是否"足够接近"（容差比较，替代原来的精确相等）
        参数:
            current_sign: 当前环境标志位
            tree_sign: 树中存储的环境标志位
        返回:
            bool
        说明:
            环境标志位已改为连续编码（距离/TTC/曲率等），精确相等几乎永不成立，
            因此按维度容差比较：
              env_sign(8维): [前距, 左前距, 右前距, 后距, 冲突时间差, 距冲突点, 曲率, 路权]
        """
        if current_sign is None or tree_sign is None:
            return False
        try:
            cur = np.asarray(current_sign, dtype=float)
            tree = np.asarray(tree_sign, dtype=float)
        except (ValueError, TypeError):
            return False
        if cur.shape != tree.shape:
            return False

        if cur.ndim == 2:
            # lane_sign(4x2矩阵)：元素级容差 1.0（TTC取整后允许±1s）
            return bool(np.all(np.abs(cur - tree) <= 1.0))

        if cur.shape[0] >= 8:
            # env_sign 8 维容差（基准值 × DSH_ENV_TOL_SCALE；默认 1.0 = 原行为）
            tol = _ENV_TOL_BASE * env_tol_scale()
        else:
            tol = np.full(cur.shape[0], 2.0)
        return bool(np.all(np.abs(cur - tree) <= tol))

    # def TS_lane_ConfidenceValue(self, state, lane_sign, act, rule_act, action_num):

    #     b_thres = 10    # Bootstrapped method 数据阈值
    #     g_thres = 30    # 高斯分布数据阈值
    #     alpha = 0.05    # 置信度

    #     # 使用 R-tree 存储的数据进行置信度计算 
    #     idx = self._get_state_key(state)
    #     if act == 0:
    #         # 清空缓冲数据集
    #         for a in range(action_num):
    #             self.dateset_rtree[a] = []
    #             self.sample[a] = []

    #         # 从 R-tree 中查询数据并存入缓冲数据集
    #         # print("[Trustset] : Search lane data", np.array(state))
    #         self.relevant_data = self.Rtree_lane.search(np.array(state))
    #         if self.relevant_data and len(self.relevant_data) > 0:
    #             for data_unit in self.relevant_data:
    #                 _, tree_lane_sign, action, reward = data_unit

    #                 # 比较环境标志位
    #                 if self.compare_signs(lane_sign, tree_lane_sign):
    #                     hybrid_reward = self.driving_style[0]*reward[0] + self.driving_style[1]*reward[1] + self.driving_style[2]*reward[2] + self.driving_style[3]*reward[3]
    #                     self.dateset_rtree.setdefault(action, []).append(hybrid_reward)

    #             # # Bootstrapped method 加速置信度收敛    记得还要开启下面的 self.sample[act]
    #             # max_sample_len = 0
    #             # for action_sample in range(action_num):
    #             #     if len(self.dateset_rtree[action_sample]) > max_sample_len:
    #             #         max_sample_len = len(self.dateset_rtree[action_sample])    # 找出最大动作数据长度
    #             # # 采样缓冲数据集中的数据
    #             # for action_sample in range(action_num):
    #             #     if len(self.dateset_rtree[action_sample]) >= 10:
    #             #         if len(self.dateset_rtree[action_sample]) == max_sample_len:
    #             #             self.sample[action_sample] = self.dateset_rtree[action_sample]
    #             #         else:
    #             #             sample_rewards = np.array(self.dateset_rtree[action_sample]).flatten()
    #             #             self.sample[action_sample] = np.random.choice(sample_rewards, size=max_sample_len, replace=True)

    #     if not self.relevant_data:
    #         if act == rule_act:
    #             BCV = float('inf') 
    #             return BCV
    #         else:
    #             WCV = float('-inf')
    #             return WCV

    #     else:
    #         if act == rule_act:
    #             # self.rule_dataset = self.sample[rule_act]    # Bootstrapped method
    #             self.rule_dataset = self.dateset_rtree.get(rule_act, [])

    #             if len(self.rule_dataset) <= b_thres:
    #                 BCV = float('inf')
    #                 return BCV
                
    #             elif b_thres < len(self.rule_dataset) <= g_thres:
    #                 # 将数据转换为numpy数组并排序
    #                 rule_data_array = np.array(self.rule_dataset)
    #                 rule_sorted_data = np.sort(rule_data_array)

    #                 BCV = np.percentile(rule_sorted_data, (1-alpha)*100)

    #                 print(f"idx: {idx[0]:.2f}, {idx[1]:.2f}, rule_lane: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
    #                 return BCV

    #             else:
    #                 # 将数据转换为numpy数组并排序
    #                 rule_data_array = np.array(self.rule_dataset)
    #                 rule_sorted_data = np.sort(rule_data_array)

    #                 # 使用高斯分布拟合数据
    #                 rule_mu,rule_sigma = stats.norm.fit(rule_sorted_data)

    #                 # 计算基于高斯分布的理论分位数
    #                 BCV = stats.norm.ppf(1-alpha, loc=rule_mu, scale=rule_sigma)

    #                 print(f"idx: {idx[0]}, {idx[1]}, rule_lane: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
    #                 return BCV

    #         else:
    #             # self.RL_dataset = self.sample[act]    # Bootstrapped method
    #             self.RL_dataset = self.dateset_rtree.get(act, [])

    #             if len(self.RL_dataset) <= b_thres:
    #                 WCV = float('-inf')
    #                 return WCV

    #             elif b_thres < len(self.RL_dataset) <= g_thres:
    #                 # 将数据转换为numpy数组并排序
    #                 data_array = np.array(self.RL_dataset)
    #                 sorted_data = np.sort(data_array)

    #                 WCV = np.percentile(sorted_data, (alpha)*100)

    #                 print(f"idx: {idx[0]:.2f}, {idx[1]:.2f}, lane: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
    #                 return WCV

    #             else:
    #                 # 将数据转换为numpy数组并排序
    #                 data_array = np.array(self.RL_dataset)
    #                 sorted_data = np.sort(data_array)

    #                 # 使用高斯分布拟合数据
    #                 mu,sigma = stats.norm.fit(sorted_data)

    #                 # 计算基于高斯分布的理论分位数
    #                 WCV = stats.norm.ppf(alpha, loc=mu, scale=sigma)

    #                 print(f"idx: {idx[0]}, {idx[1]}, lane: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
    #                 return WCV

    # def TS_traj_ConfidenceValue(self, state, env_sign, act, rule_act, action_num):

    #     b_thres = 10    # Bootstrapped method 数据阈值
    #     g_thres = 30    # 高斯分布数据阈值
    #     alpha = 0.05    # 置信度

    #     # 使用 R-tree 存储的数据进行置信度计算 
    #     idx = self._get_state_key(state)
    #     if act == 0:
    #         # 清空缓冲数据集
    #         for a in range(action_num):
    #             self.dateset_rtree[a] = []
    #             self.sample[a] = []

    #         # 从 R-tree 中查询数据并存入缓冲数据集
    #         self.relevant_data = self.Rtree_env.search(np.array(state))
    #         if self.relevant_data and len(self.relevant_data) > 0:
    #             for data_unit in self.relevant_data:
    #                 _, tree_env_sign, action, reward = data_unit

    #                 # 比较环境标志位
    #                 if self.compare_signs(env_sign, tree_env_sign):
    #                     hybrid_reward = self.driving_style[0]*reward[0] + self.driving_style[1]*reward[1] + self.driving_style[2]*reward[2] + self.driving_style[3]*reward[3]
    #                     self.dateset_rtree.setdefault(action, []).append(hybrid_reward)

    #             # # Bootstrapped method 加速置信度收敛    记得还要开启下面的 self.sample[act]
    #             # max_sample_len = 0
    #             # for action_sample in range(action_num):
    #             #     if len(self.dateset_rtree[action_sample]) > max_sample_len:
    #             #         max_sample_len = len(self.dateset_rtree[action_sample])    # 找出最大动作数据长度
    #             # # 采样缓冲数据集中的数据
    #             # for action_sample in range(action_num):
    #             #     if len(self.dateset_rtree[action_sample]) >= 10:
    #             #         if len(self.dateset_rtree[action_sample]) == max_sample_len:
    #             #             self.sample[action_sample] = self.dateset_rtree[action_sample]
    #             #         else:
    #             #             sample_rewards = np.array(self.dateset_rtree[action_sample]).flatten()
    #             #             self.sample[action_sample] = np.random.choice(sample_rewards, size=max_sample_len, replace=True)

    #     if not self.relevant_data:
    #         if act == rule_act:
    #             BCV = float('inf') 
    #             return BCV
    #         else:
    #             WCV = float('-inf')
    #             return WCV

    #     else:
    #         if act == rule_act:
    #             # self.rule_dataset = self.sample[rule_act]    # Bootstrapped method
    #             self.rule_dataset = self.dateset_rtree.get(rule_act, [])

    #             if len(self.rule_dataset) <= b_thres:
    #                 BCV = float('inf')
    #                 return BCV
                
    #             elif b_thres < len(self.rule_dataset) <= g_thres:
    #                 # 将数据转换为numpy数组并排序
    #                 rule_data_array = np.array(self.rule_dataset)
    #                 rule_sorted_data = np.sort(rule_data_array)

    #                 BCV = np.percentile(rule_sorted_data, (1-alpha)*100)

    #                 # print(f"idx: {idx[0]:.2f}, {idx[1]:.2f}, rule_lane: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
    #                 return BCV

    #             else:
    #                 # 将数据转换为numpy数组并排序
    #                 rule_data_array = np.array(self.rule_dataset)
    #                 rule_sorted_data = np.sort(rule_data_array)

    #                 # 使用高斯分布拟合数据
    #                 rule_mu,rule_sigma = stats.norm.fit(rule_sorted_data)

    #                 # 计算基于高斯分布的理论分位数
    #                 BCV = stats.norm.ppf(1-alpha, loc=rule_mu, scale=rule_sigma)

    #                 # print(f"idx: {idx[0]:.2f}, {idx[1]:.2f}, rule_lane: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
    #                 return BCV

    #         else:
    #             # self.RL_dataset = self.sample[act]    # Bootstrapped method
    #             self.RL_dataset = self.dateset_rtree.get(act, [])

    #             if len(self.RL_dataset) <= b_thres:
    #                 WCV = float('-inf')
    #                 return WCV

    #             elif b_thres < len(self.RL_dataset) <= g_thres:
    #                 # 将数据转换为numpy数组并排序
    #                 data_array = np.array(self.RL_dataset)
    #                 sorted_data = np.sort(data_array)

    #                 WCV = np.percentile(sorted_data, (alpha)*100)

    #                 # print(f"idx: {idx[0]}, {idx[1]}, lane: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
    #                 return WCV

    #             else:
    #                 # 将数据转换为numpy数组并排序
    #                 data_array = np.array(self.RL_dataset)
    #                 sorted_data = np.sort(data_array)

    #                 # 使用高斯分布拟合数据
    #                 mu,sigma = stats.norm.fit(sorted_data)

    #                 # 计算基于高斯分布的理论分位数
    #                 WCV = stats.norm.ppf(alpha, loc=mu, scale=sigma)

    #                 # print(f"idx: {idx[0]}, {idx[1]}, lane: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
    #                 return WCV


    # 使用霍夫丁不等式计算置信度
    def TS_lane_ConfidenceValue(self, state, lane_sign, act, rule_act, action_num):

        n_thres = 10    # 数据阈值
        alpha = 0.05
        loc = -50
        scale = self.reward_range   # 【式44】(R_max-R_min)，可用 DSH_REWARD_RANGE 调
        bcv_max = 1e9   # 「数据不足」哨兵：必须取极端值，否则会被表现差的规则动作(BCV 可低至 -300+)反超，
        wcv_min = -1e9  # 导致"接管到毫无数据的动作"（实测 300 回合性能崩溃的根因）

        # 使用 R-tree 存储的数据进行置信度计算 
        idx = self._get_state_key(state)
        if act == 0:
            # 两层共用查询缓存；必须清除上一邻域的所有动作。
            self.dateset_rtree.clear()
            self.sample.clear()

            # 从 R-tree 中查询数据并存入缓冲数据集
            self.relevant_data = self.Rtree_lane.search(np.array(state))
            if self.relevant_data and len(self.relevant_data) > 0:
                for data_unit in self.relevant_data:
                    _, tree_lane_sign, action, reward = data_unit
                    # print("[Trustset] : Get lane data one", data_unit)
                    # 比较环境标志位
                    if self.compare_signs(lane_sign, tree_lane_sign):
                        # print("[Trustset] : Get lane data two", data_unit)

                        # P0: 支持标量因果奖励（原为 4 维环境奖励向量）
                        if np.isscalar(reward):
                            hybrid_reward = float(reward)
                        else:
                            hybrid_reward = self.driving_style[0]*reward[0] + self.driving_style[1]*reward[1] + self.driving_style[2]*reward[2] + self.driving_style[3]*reward[3]
                        self.dateset_rtree.setdefault(action, []).append(hybrid_reward)

                # # Bootstrapped method 加速置信度收敛    记得还要开启下面的 self.sample[act]
                # max_sample_len = 0
                # for action_sample in range(action_num):
                #     if len(self.dateset_rtree[action_sample]) > max_sample_len:
                #         max_sample_len = len(self.dateset_rtree[action_sample])    # 找出最大动作数据长度
                # # 采样缓冲数据集中的数据
                # for action_sample in range(action_num):
                #     if len(self.dateset_rtree[action_sample]) >= 10:
                #         if len(self.dateset_rtree[action_sample]) == max_sample_len or len(self.dateset_rtree[action_sample]) > 30:
                #             self.sample[action_sample] = self.dateset_rtree[action_sample]
                #         else:
                #             sample_rewards = np.array(self.dateset_rtree[action_sample]).flatten()
                #             self.sample[action_sample] = np.random.choice(sample_rewards, size=max_sample_len, replace=True)

        self.diag['calls'] = self.diag.get('calls', 0) + 1
        if not self.relevant_data:
            # 【0' 诊断】空邻域 -> 哨兵
            self.diag['sentinel_empty_neighborhood'] = \
                self.diag.get('sentinel_empty_neighborhood', 0) + 1
            if act == rule_act:
                BCV = bcv_max
                return BCV
            else:
                WCV = wcv_min
                return WCV
        else:
            if act == rule_act:
                # self.rule_dataset = self.sample[rule_act]    # Bootstrapped method
                self.rule_dataset = self.dateset_rtree.get(rule_act, [])
                if len(self.rule_dataset) < n_thres:
                    # 【0' 诊断】样本不足 -> 哨兵
                    self.diag['sentinel_thin_data'] = \
                        self.diag.get('sentinel_thin_data', 0) + 1
                    _d = self.diag.setdefault('thin_detail', {})
                    _d[act] = _d.get(act, 0) + 1
                    BCV = bcv_max
                    return BCV
                else:
                    BCV = min(bcv_max, np.mean(np.array(self.rule_dataset))+scale*math.sqrt(math.log(1/alpha)/2/len(np.array(self.rule_dataset))))
                    # print(f"idx: {idx[0]}, {idx[1]}, rule_lane: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
                    return BCV
            else:
                # self.RL_dataset = self.sample[act]    # Bootstrapped method
                self.RL_dataset = self.dateset_rtree.get(act, [])
                if len(self.RL_dataset) < n_thres:
                    # 【0' 诊断】样本不足 -> 哨兵
                    self.diag['sentinel_thin_data'] = \
                        self.diag.get('sentinel_thin_data', 0) + 1
                    _d = self.diag.setdefault('thin_detail', {})
                    _d[act] = _d.get(act, 0) + 1
                    WCV = wcv_min
                    return WCV
                else:
                    # ③ 式60 方差修正 WCV：WCV = Q̂ - δ - var_weight·4σ/(n+1)（δ 为式43 Hoeffding 临界偏差）
                    #   reward_range 用 scale 作 (R_max-R_min) 代理；var_weight 控制式60方差修正强度
                    WCV, _, _, _ = wcv_bcv(self.RL_dataset, alpha=alpha,
                                           reward_range=scale, var_weight=self.var_weight)
                    # print(f"idx: {idx[0]}, {idx[1]}, lane: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
                    return WCV

    def diag_snapshot(self):
        """返回哨兵计数及最近一次查询中逐动作的局部匹配样本数。

        `dateset_rtree` 在每次查询时重建，不能用它估计持久化数据库的总量。
        这里的计数用于核查当前邻域的 `n_thres` 和 Hoeffding 临界偏差。
        """
        try:
            counts = {int(k): len(v) for k, v in (self.dateset_rtree or {}).items()}
        except Exception:
            counts = {}
        d = dict(getattr(self, 'diag', {}) or {})
        d['per_action_counts'] = counts
        d['total_samples'] = int(sum(counts.values()))
        # 【2026-10-12 修复 D1】把式44 的 (R_max−R_min) **生效值 + 取值来源**一并落盘。
        #   为什么必须可观测：修复前该值是硬编码 80（与真实范围差 1~2 个量级），
        #   而它支配整个 WCV/BCV 的保守程度。不落盘就无法验证"到底用了多少"。
        try:
            d['reward_range_effective'] = float(self.effective_reward_range())
            d['reward_range_source'] = str(getattr(self, '_rr_last_source', '?'))
            d['reward_range_env'] = str(getattr(self, 'reward_range_env', '?'))
        except Exception:
            pass
        return d

    def TS_traj_ConfidenceValue(self, state, env_sign, act, rule_act, action_num):
        """
            功能：计算动作置信度
            逻辑：
                1.Rtree_env.search去搜索相关的数据    note：搜索的逻辑是   十分之一总范围的检索范围内
                2.fixme:比较环境位：环境不一样的剔除掉，这里需要修改把博弈对象软编码到查询树内      风格项先去掉
                3.Bootstrapped方法。感觉没用
                4.置信度计算
                    （1）.没有相关数据：
                        【1】规则动作，置信度最大
                        【2】非规则动作，置信度最低
                    （2）.有相关数据
                        [1].规则小于数据量阈值，置信度给最大
                        [2].规则大于数据量阈值，置信度按照各个数据奖励来算
                        [3].非规则小于阈值，置信度给最小
                        [4].非规则大于阈值，置信度按照各个数据奖励来算
        """


        n_thres = 10    # 数据阈值
        alpha = 0.05
        loc = -50
        scale = self.reward_range   # 【式44】(R_max-R_min)，可用 DSH_REWARD_RANGE 调
        bcv_max = 1e9   # 「数据不足」哨兵：必须取极端值，否则会被表现差的规则动作(BCV 可低至 -300+)反超，
        wcv_min = -1e9  # 导致"接管到毫无数据的动作"（实测 300 回合性能崩溃的根因）

        # 使用 R-tree 存储的数据进行置信度计算
        idx = self._get_state_key(state)
        # fixme:这个编号混乱 避开无用的第一个首次规划
        if act == 0:
            # 此接口的 action_num 是最大动作编号；range(action_num) 会漏掉最后一档。
            # 整体清空也隔离车道查询、动作空间变化和环境标志位变化。
            self.dateset_rtree.clear()
            self.sample.clear()

            # 从 R-tree 中查询数据并存入缓冲数据集
            self.relevant_data = self.Rtree_env.search(np.array(state))
            if self.relevant_data and len(self.relevant_data) > 0:
                for data_unit in self.relevant_data:
                    _, tree_env_sign, action, reward = data_unit
                    # print("[Trustset] : Get traj data one", data_unit)

                    # 比较环境标志位
                    if self.compare_signs(env_sign, tree_env_sign):
                        # print("[Trustset] : Get traj data two", data_unit)

                        # P0: 支持标量因果奖励（原为 4 维环境奖励向量）
                        if np.isscalar(reward):
                            hybrid_reward = float(reward)
                        else:
                            hybrid_reward = self.driving_style[0]*reward[0] + self.driving_style[1]*reward[1] + self.driving_style[2]*reward[2] + self.driving_style[3]*reward[3]
                        self.dateset_rtree.setdefault(action, []).append(hybrid_reward)

                    # hybrid_reward = self.driving_style[0] * reward[0] + self.driving_style[1] * reward[1] + \
                    #                 self.driving_style[2] * reward[2] + self.driving_style[3] * reward[3]
                    # self.dateset_rtree.setdefault(action, []).append(hybrid_reward)

                # Bootstrapped method 加速置信度收敛    记得还要开启下面的 self.sample[act]
                # max_sample_len = 0
                # for action_sample in range(action_num):
                #     if len(self.dateset_rtree[action_sample]) > max_sample_len:
                #         max_sample_len = len(self.dateset_rtree[action_sample])    # 找出最大动作数据长度
                # # 采样缓冲数据集中的数据
                # for action_sample in range(action_num):
                #     if len(self.dateset_rtree[action_sample]) >= 10:
                #         if len(self.dateset_rtree[action_sample]) == max_sample_len or len(self.dateset_rtree[action_sample]) > 30:
                #             self.sample[action_sample] = self.dateset_rtree[action_sample]
                #         else:
                #             sample_rewards = np.array(self.dateset_rtree[action_sample]).flatten()
                #             self.sample[action_sample] = np.random.choice(sample_rewards, size=max_sample_len, replace=True)

        self.diag['calls'] = self.diag.get('calls', 0) + 1
        if not self.relevant_data: 
            # 【0' 诊断】空邻域 -> 哨兵（车道层）
            self.diag['sentinel_empty_neighborhood'] = \
                self.diag.get('sentinel_empty_neighborhood', 0) + 1
            if act == rule_act:
                BCV = bcv_max
                return BCV
            else:
                WCV = wcv_min
                return WCV
        else:
            if act == rule_act:
                # self.rule_dataset = self.sample[rule_act]    # Bootstrapped method
                self.rule_dataset = self.dateset_rtree.get(rule_act, [])
                if len(self.rule_dataset) < n_thres:
                    # 【0' 诊断】样本不足 -> 哨兵
                    self.diag['sentinel_thin_data'] = \
                        self.diag.get('sentinel_thin_data', 0) + 1
                    _d = self.diag.setdefault('thin_detail', {})
                    _d[act] = _d.get(act, 0) + 1
                    BCV = bcv_max
                    return BCV
                else:
                    BCV = min(bcv_max, np.mean(np.array(self.rule_dataset))+scale*math.sqrt(math.log(1/alpha)/2/len(np.array(self.rule_dataset))))
                    print(f"idx: {idx[0]}, {idx[1]}, {idx[2]}, rule_act: {rule_act}, BCV: {BCV:.2f}, rule_reward_len: {len(self.rule_dataset)}")
                    return BCV
            else:
                # self.RL_dataset = self.sample[act]    # Bootstrapped method
                self.RL_dataset = self.dateset_rtree.get(act, [])
                if len(self.RL_dataset) < n_thres:
                    # 【0' 诊断】样本不足 -> 哨兵
                    self.diag['sentinel_thin_data'] = \
                        self.diag.get('sentinel_thin_data', 0) + 1
                    _d = self.diag.setdefault('thin_detail', {})
                    _d[act] = _d.get(act, 0) + 1
                    WCV = wcv_min
                    return WCV
                else:
                    # ③ 式60 方差修正 WCV：WCV = Q̂ - δ - var_weight·4σ/(n+1)（δ 为式43 Hoeffding 临界偏差）
                    WCV, _, _, _ = wcv_bcv(self.RL_dataset, alpha=alpha,
                                           reward_range=scale, var_weight=self.var_weight)
                    print(f"idx: {idx[0]}, {idx[1]}, {idx[2]}, act: {act}, WCV: {WCV:.2f}, RL_reward_len: {len(self.RL_dataset)}")
                    return WCV
        
    def _get_state_key(self, state):
        """将状态向量转换为可哈希的键"""
        try:
            # 尝试将numpy数组转换为元组
            return tuple(state.flatten())
        except:
            # 如果不是numpy数组，尝试其他方法
            try:
                return tuple(state)
            except:
                # 如果都不行，使用字符串表示
                return str(state)
