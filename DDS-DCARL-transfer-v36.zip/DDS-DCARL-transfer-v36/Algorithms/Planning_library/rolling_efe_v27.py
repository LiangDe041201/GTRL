"""Non-controlling candidate EFE and a final-request diagnostic ledger.

The outcome CDF and Beta-mean/response-column mapping are explicit provisional
models. Robust envelopes are not calibrated probabilities. This shadow object
never selects an action, writes a reward, or calls a predictor/MPC/map API.
"""
import copy
import hashlib
import json
import math

import numpy as np

from Planning_library.efe_core_v27 import evaluate_efe,integrated_cost
from Planning_library.trajectory_guard import execution_acceleration


def signature(value):
    def plain(v):
        if isinstance(v,np.ndarray): return v.tolist()
        if isinstance(v,np.generic): return v.item()
        raise TypeError('Unsupported EFE evidence type')
    data=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False,default=plain)
    return hashlib.sha256(data.encode('utf8')).hexdigest()


class Unavailable(ValueError):
    pass


class EFEShadowLedger:
    def __init__(self,preference=(.94,.02,.03,.01),gap_sigma=.25,progress_sigma=1.):
        p=np.asarray(preference,dtype=float)
        evaluate_efe(np.eye(4),[.25]*4,p)
        if not all(math.isfinite(float(v)) and v>0. for v in (gap_sigma,progress_sigma)):
            raise ValueError('Positive finite outcome scales are required')
        self.metadata=dict(revision='rolling_efe_shadow_v27',mode='shadow',reward_applied=False,
            calibrated=False,opponent_type_identified=False,
            outcome_model='robust_envelope_cdf_proxy_v27',
            response_belief='beta_mean_to_response_columns_hypothesis_only',
            outcomes=['clear','tight','stalled','blocked'],preference=p.tolist(),
            gap_sigma_m=float(gap_sigma),progress_sigma_m=float(progress_sigma),
            blocked_gap_m=.15,tight_gap_m=.5,cost_units='normalized_EFE_times_actual_simulation_seconds',
            additional_mpc_solves=0,additional_map_queries=0)
        self.model_hash=signature(self.metadata)
        self.preference=p.copy(); self.gap_sigma=float(gap_sigma); self.progress_sigma=float(progress_sigma)
        self.reset()

    def reset(self):
        self.last=None; self.context=None; self.requests={}

    def _distribution(self,part):
        if not part.get('forecast_valid',False): raise Unavailable('invalid_forecast')
        forecasts=part.get('forecasts')
        if not forecasts: raise Unavailable('missing_forecast_summaries')
        progress=min(float(v['progress_m']) for v in forecasts)
        if not math.isfinite(progress): raise Unavailable('invalid_progress')
        gap=part.get('min_gap',part.get('gap'))
        gap=100. if gap is None or gap==float('inf') else float(gap)
        if not math.isfinite(gap): raise Unavailable('invalid_gap')
        cdf=lambda x:.5*(1.+math.erf(x/math.sqrt(2.)))
        blocked=cdf((.15-gap)/self.gap_sigma)
        tight=max(0.,cdf((.5-gap)/self.gap_sigma)-blocked)
        clear=max(0.,1.-blocked-tight)
        stall=cdf((max(0.,self.context['standoff'])-progress)/self.progress_sigma)
        z=np.array([clear*(1.-stall),tight*(1.-stall),(clear+tight)*stall,blocked])
        if not np.isfinite(z).all() or np.any(z<0.) or not math.isclose(float(z.sum()),1.,abs_tol=1.e-12):
            raise Unavailable('invalid_outcome_distribution')
        return z

    def _belief(self):
        beta=self.context['beta']; actor=self.context['rv_id']
        if actor is None or beta.get('actor_id') is None: raise Unavailable('response_unidentified')
        if str(actor)!=str(beta['actor_id']): raise Unavailable('belief_actor_mismatch')
        a,b=float(beta['alpha']),float(beta['beta']); mean=float(beta['mean'])
        if (not all(math.isfinite(v) for v in (a,b,mean)) or min(a,b)<1.
                or not math.isclose(mean,a/(a+b),abs_tol=1.e-12)):
            raise Unavailable('invalid_response_belief')
        return [1.-mean,mean]

    @staticmethod
    def _request(c):
        return {key:c.get(key) for key in ('action','id','path_hash','plan_hash','prediction_hash','a','delta','target')}

    def propose(self,payload,cg_record):
        self.context=copy.deepcopy(dict(observation=payload['observation'],previous=payload['previous'],
            beta=payload['beta'],standoff=float(cg_record['standoff']),rv_id=cg_record.get('rv_id')))
        self.requests={c['action']:copy.deepcopy(c) for c in payload['candidates']}
        rows=[]
        for c in payload['candidates']:
            row=dict(action=c['action'],request_id=c['id'],path_hash=c['path_hash'],
                     input_signature=None,available=False,reason=None,score=None)
            try:
                if c['action']==0:
                    all_parts=cg_record.get('components')
                    parts=None if all_parts is None else all_parts[cg_record['selected']]
                else: parts=c.get('components')
                row['input_signature']=signature(dict(model=self.model_hash,context=self.context,
                                                       request=self._request(c),components=parts))
                if not payload['active']: raise Unavailable('inactive')
                if parts is None or len(parts)!=2: raise Unavailable('missing_candidate_components')
                belief=self._belief()
                score=evaluate_efe([self._distribution(p) for p in parts],belief,self.preference)
                row.update(available=True,score=score)
            except Unavailable as exc: row['reason']=str(exc)
            except (KeyError,ValueError,TypeError,IndexError,OverflowError) as exc:
                row.update(reason='invalid_candidate_evidence',error_type=type(exc).__name__)
            rows.append(row)
        self.last=dict(revision='rolling_efe_shadow_v27',mode='shadow',model_sha256=self.model_hash,
            calibrated=False,reward_applied=False,candidates=rows,feedback=None)
        return self.last

    @staticmethod
    def _matches(control,command):
        return all(math.isclose(float(control[k]),command[k],abs_tol=1.e-8,rel_tol=0.)
                   for k in ('a','delta','target'))

    def feedback(self,payload,audit,applied,episode,frame,dt=.05):
        if int(applied['control_submit_ok'])!=1: raise ValueError('No submitted control for EFE attribution')
        actual=int(payload['actual_action']); request=payload['request']
        command=dict(a=float(applied['a_cmd']),delta=float(applied['delta_rad']),
                     target=float(applied['actuator_speed_target']))
        reward=float(payload['feedback']['reward'])
        if (not all(math.isfinite(v) for v in command.values()) or not math.isfinite(reward)
                or not math.isfinite(float(dt)) or dt<=0.): raise ValueError('Invalid actual EFE feedback')
        final=dict(episode=int(episode),frame=int(frame),dt=float(dt),owner_action=actual,
            request_id=request['id'],path_hash=request['path_hash'],command=command,
            control_signature=signature(command),model_sha256=self.model_hash,
            guard_action=audit['action'],guard_override=bool(audit['override']),
            reward_applied=False,actual_task_reward=reward,available=False,reason=None,
            source='unavailable',score=None,cost_seconds=None)
        try:
            if self.last is None or actual not in self.requests: raise Unavailable('owner_not_proposed')
            original=self.requests[actual]
            if self._request(original)!=self._request(request): raise Unavailable('request_changed_without_proposal')
            expected=dict(a=execution_acceleration(original['a'],self.context['observation']['ego']['v'],original['target']),
                          delta=original['delta'],target=original['target'])
            row=next(c for c in self.last['candidates'] if c['action']==actual)
            if not audit['override'] and audit['action']=='mpc' and self._matches(expected,command):
                if not row['available']: raise Unavailable(row['reason'])
                score=copy.deepcopy(row['score']); source='candidate_prediction'
                evidence=None
            else:
                chosen=next((c for c in audit.get('candidates',[]) if c['action']==audit['action']
                    and self._matches(c,command)),None)
                if chosen is None: raise Unavailable('unmatched_final_control')
                evidence=copy.deepcopy(chosen)
                if evidence['gap']==float('inf'): evidence['gap']=None
                final['evidence']=evidence
                dist=self._distribution(chosen)
                score=evaluate_efe([dist],[1.],self.preference)
                source='guard_envelope'
            final.update(available=True,score=score,source=source,cost_seconds=integrated_cost(score,dt),
                evidence=evidence,
                input_signature=signature(dict(model=self.model_hash,context=self.context,
                    request=self._request(request),command=command,source=source,conditional=score['conditional'])))
        except Unavailable as exc: final['reason']=str(exc)
        except (KeyError,ValueError,TypeError,IndexError,OverflowError,StopIteration) as exc:
            final.update(reason='invalid_final_evidence',error_type=type(exc).__name__)
        if self.last is not None: self.last['feedback']=final
        return final
