"""Concentrate training on within-state comparisons against the CG action."""
from collections import defaultdict

from Planning_library.select_first_planner_v33 import SelectFirstLearnerV33, SelectFirstPlannerV33


class PairedLearnerV34(SelectFirstLearnerV33):
    SCHEMA='cg_joint_paired_exploration_v34'
    WIDE_EXPLORATION=.2
    DEPRIORITIZE_EPISODES=3

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.audit_rejections=defaultdict(set)

    def signature(self):
        return dict(super().signature(),wide_exploration=self.WIDE_EXPLORATION,
                    deprioritize_episodes=self.DEPRIORITIZE_EPISODES)

    def note_rejection(self,state,action,episode):
        self.audit_rejections[state,action].add(episode)

    def _exploration_action(self,node,bounds,rng):
        baseline=node['default']
        base=bounds[baseline]
        options=[a for a in node['allowed'] if a!=baseline
                 and self.episode not in self.audit_rejections.get((self.current,a),())]
        if not options: return None
        if rng.random_sample()<self.WIDE_EXPLORATION:
            return int(rng.choice([baseline]+options))

        priority={}
        for action in options:
            other=bounds[action]
            n=min(base['n'],other['n'])
            rejected=len(self.audit_rejections.get((self.current,action),()))
            if (n>=self.min_episodes or (n>=self.DEPRIORITIZE_EPISODES and other['bcv']<base['wcv'])
                    or (rejected>=self.DEPRIORITIZE_EPISODES and rejected>other['n'])):
                continue
            priority[action]=(n,other['n'])
        if not priority: return None
        best=max(priority.values())
        alternative=int(rng.choice([a for a,score in priority.items() if score==best]))
        return baseline if base['n']<bounds[alternative]['n'] else alternative


class PairedPlannerV34(SelectFirstPlannerV33):
    LEARNER_CLASS=PairedLearnerV34
    LEARNER_METADATA=dict(SelectFirstPlannerV33.LEARNER_METADATA,
        learner_revision=PairedLearnerV34.SCHEMA, exploration='paired_exact_state_v34')

    def feedback(self,episode,frame,audit,applied,outcome=None):
        if self.phase=='train' and self.last['retracted']:
            if int(applied['control_submit_ok'])!=1: raise RuntimeError('Control was not submitted')
            credited_episode=self.episode_offset+self.local_episode
            self.learner.note_rejection(self.last['learning']['state'],self.last['requested_action'],credited_episode)
            context,beta,costs=self._frame_context
            # Preserve the executed CG outcome without treating rejection as a paired CG trial.
            self.learner.begin(context,beta,0,[0],costs,credited_episode)
        return super().feedback(episode,frame,audit,applied,outcome)
