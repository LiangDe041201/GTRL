"""Record raw optimizer evidence without changing a candidate or its controls."""


def control_evidence(candidate,action):
    controller=candidate['controller']
    valid=bool(candidate['solve_ok']); plan=candidate.get('plan')
    first=None if plan is None else [float(plan[0][0]),float(plan[1][0])]
    return dict(revision='rolling_control_evidence_v28',optimizer_valid=valid,
        fallback_only=bool(action==0 and not valid),raw_first=first,
        requested_first=[float(candidate['a']),float(candidate['delta'])],
        bounds=[[float(controller.a_min),float(controller.a_max)],
                [-float(controller.max_steering),float(controller.max_steering)]],
        numerical_projection_limit=1.e-6)
