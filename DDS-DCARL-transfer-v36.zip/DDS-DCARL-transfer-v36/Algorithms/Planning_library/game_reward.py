#!/usr/bin/env python3
"""
论文 GTRL（ADVEI-D-26-08155 §VI-A）奖励函数合成（纯函数，无 CARLA，离线可对拍）。

严格对齐论文原式（依据 OMML 公式汇总逐条核对）：
  式62  r_gap-dist ：基于「间隙 g_d」的分段奖励
  式63  r_gap-rate ：基于「间隙变化率 ġ」的分段奖励
  式64  r_game     = r_gap-rate + 0.5·r_gap-dist（进行中）；= 140（完成）
  式65  r_thw      = 10·min(2.0, THW_boundary)
  式66  p_yaw = 1.0·ψ² + 4.0·max(|ψ̇|−0.2,0)² + 25.0·max(|ψ̇|−0.4,0)²
        r_yaw = −10·min(p_yaw, 5)
  式67  Δy = y_ego − y_target；r_lat = −10.0·Δy²
  式68  r_total = r_game + r_thw + r_yaw + r_lat
"""
import math
import os


def _env_float(name, default):
    """读环境变量为 float；缺失/非法 ⇒ 返回 default。"""
    try:
        v = os.environ.get(name)
        return float(v) if v is not None and str(v).strip() != '' else float(default)
    except (TypeError, ValueError):
        return float(default)


#: 式62 间隙分段断点（论文原值）
GAP_LO, GAP_MID, GAP_HI, GAP_MAX = 2.5, 3.5, 5.0, 7.0
#: 式64 完成奖励（论文原值）
COMPLETE_REWARD = 140.0


def gap_dist_reward(g_d, lo=GAP_LO, mid=GAP_MID, hi=GAP_HI, top=GAP_MAX):
    """式62：r_gap-dist（间隙 g_d 的分段奖励）。

        g_d < lo      : −50(lo − g_d) − 20
        lo ≤ g_d < mid: −20 + 40(g_d − lo)
        mid ≤ g_d < hi:  20 + 30(g_d − mid)
        hi ≤ g_d < top:  65 − 10(g_d − hi)
        g_d ≥ top     :  0
    """
    g = float(g_d)
    if g < lo:
        return -50.0 * (lo - g) - 20.0
    elif g < mid:
        return -20.0 + 40.0 * (g - lo)
    elif g < hi:
        return 20.0 + 30.0 * (g - mid)
    elif g < top:
        return 65.0 - 10.0 * (g - hi)
    else:
        return 0.0


def gap_rate_reward(g_rate):
    """式63：r_gap-rate（间隙变化率 ġ 的分段奖励）。

        ġ > 0.5          : 40·ġ
        0.1 < ġ ≤ 0.5    : 20·ġ
        −0.1 < ġ ≤ 0.1   : 0
        ġ ≤ −0.1         : 60·ġ
    """
    gr = float(g_rate)
    if gr > 0.5:
        return 40.0 * gr
    elif gr > 0.1:
        return 20.0 * gr
    elif gr > -0.1:
        return 0.0
    else:
        return 60.0 * gr


def game_reward(g_rate, g_d, complete=False):
    """式64：r_game = r_gap-rate + 0.5·r_gap-dist（博弈进行中）；完成时 = 140。"""
    if complete:
        return COMPLETE_REWARD
    return gap_rate_reward(g_rate) + 0.5 * gap_dist_reward(g_d)


#: 【P1-f 默认】无 RV（THW 非有限）时式65 是否中性(0)。False = 旧口径(=thw_cap，奖励劫持源)
MISSING_THW_NEUTRAL = True


#: 【§62】式(65) 的形式选择
#:   'penalty'（默认）= ≤0 形式：`−w·max(0, 1 − THW/th)²`，THW ≥ th 时**恰好 0**
#:   'paper'          = 论文原式 `10·min(2, THW)`（正奖励，仅用于消融/复现）
#: 【为什么要改（实测）】论文原式对 THW **单调递增并饱和在 2 s** ⇒ THW ≥ 2 s 的
#:   每一帧白拿 +20。而"停在停止线不动"天然让 `thw_boundary_rv` 很大
#:   （实测等待帧中位 **659.79 s**，99.4% 的等待帧 ≥ 2 s）⇒ **每帧 +20 无限累积**。
#:   实测：等待帧 reward 中位 **+17.12**、80.4% 的帧为正；20 回合里卡死回合的
#:   等待帧奖励总和 **+13000~+21700**，而卡死终局罚只有 −1000 ⇒ **等 15 倍赚**。
#:   这违反 P4（安全项必须 ≤0、上界 0）—— P1-f 只堵了 `THW=inf` 分支，
#:   **有限值分支同样可套利**。
THW_PENALTY_W = 10.0
THW_PENALTY_TH = 2.0


def thw_safe_penalty(thw, th=THW_PENALTY_TH, w=THW_PENALTY_W):
    """【§62 式(65) 的 ≤0 形式】`−w·max(0, 1 − THW/th)²`，恒 ≤ 0、上界 0。

    与论文原式的区别：**没有"安全就加分"的正项**。THW 足够大 ⇒ 0（不奖不罚），
    THW 逼近 0 ⇒ 二次加重惩罚。这样"停在停止线"不再产生任何收益。
    非有限 THW（无对手）⇒ 0（中性；没有边界要维持，就不该给分，同 P1-f 口径）。
    """
    t = float('inf') if thw is None else float(thw)
    if not math.isfinite(t):
        return 0.0
    th = max(float(th), 1e-6)
    r = max(0.0, 1.0 - max(t, 0.0) / th)
    return -float(w) * r * r


def thw_reward(thw_boundary, missing_thw_neutral=MISSING_THW_NEUTRAL):
    """式65：r_thw = 10·min(2.0, THW_boundary)。

    ⚠【P1-f 奖励劫持修复，2026-09-17】论文式65 只在**存在 RV 边界**时才有定义
    （论文说 "THW_boundary_model of the reference vehicle (RV) relative to the LCV"）。
    旧实现把"无 RV / 无测量"（THW=inf/NaN）当作 `THW = thw_cap` → **+20/帧**，
    也就是"没有对手 = 最安全 = 满分"。旧口径下自车**减速就能制造**这个状态
    （t_ego = arc/v → v↓ ⇒ t_ego↑ ⇒ 所有交叉车被重分类为已通过的 FV ⇒ rv 为空），
    于是"停在停止线白拿 +20/帧"成为最优策略。
    实测（重验 `expE_p0_100`）：`ep88` 连续 48 帧 reward≈+20.37 而 `rv_id` 全空、`n_vehicles`=3~4。
    ⚠️ 该洞**已被两头堵上**：奖励端（本函数，P1-f）+ 角色划分端
       （`gap_analysis`/`define_state_space_turn` 的 P2-a：改用计划车速 `t_ego_plan`，
        分母被 `T_EGO_V_MIN=3.0` 兜住 ⇒ 减速不再能把对手"变没"）。
    修复：非有限 THW ⇒ 中性 0（没有边界要维持，就不该给安全分）。
    旧口径可用 DSH_MISSING_THW=cap 复现做消融对照。
    """
    t = float('inf') if thw_boundary is None else float(thw_boundary)
    if not math.isfinite(t):
        return 10.0 * (0.0 if missing_thw_neutral else 2.0)
    return 10.0 * min(2.0, max(0.0, t))


#: 【2026-10-12 曲率加权】式66 的"必要转向"放宽系数。
#:   依据（文献）：`arXiv:2412.16248` §3.3（**低速自动驾驶专文**）指出
#:     大转向惩罚会 **"discourage necessary adjustments"**、导致 **"overly cautious
#:     behavior"**，尤其在**急弯**；其解法是按曲率加权：
#:         R_steer = −k·|Δθ|·(1 − w_curve),   w_curve = κ/(κ+γ)
#:   ⇒ 本实现对式66 采用同一形式。见 `PAPER_DRAFT/EVIDENCE_reward_literature.md` L3。
#:   物理解释：左转必经 ~90° 转角，转弯段"转向"是**必要的**，不该与直道同样受罚。
#:   `DSH_YAW_CURVE_GAMMA=0` ⇒ w_curve≡0 ⇒ 完全复现论文原式（消融对照）。
YAW_CURVE_GAMMA_DEFAULT = 0.05      # 1/m；κ≈0.1（R≈10m 的转弯）时 w_curve≈0.67


def yaw_curve_weight(curvature, gamma=None):
    """曲率加权因子 w_curve = κ/(κ+γ) ∈ [0,1)。

    κ 越大（越急的弯）⇒ w_curve 越接近 1 ⇒ 对转向的惩罚越宽松。
    κ≤0 或 γ≤0 ⇒ 返回 0（退化为论文原式）。
    """
    try:
        k = abs(float(curvature))
    except (TypeError, ValueError):
        return 0.0
    g = float(gamma) if gamma is not None else _env_float('DSH_YAW_CURVE_GAMMA',
                                                          YAW_CURVE_GAMMA_DEFAULT)
    if not (g > 0.0) or not math.isfinite(k):
        return 0.0
    return float(k / (k + g))


def yaw_reward(psi, curvature=None, w_curve=None):
    """式66（论文原式 + **曲率加权**）：
        p_yaw = 1.0·|ψ|² + 4.0·max(|ψ|−0.2,0)² + 25.0·max(|ψ|−0.4,0)²
        r_yaw = −10·min(p_yaw, 5) · (1 − w_curve)        → 值域 [−50, 0]

    `curvature`（1/m）非空时按 `w_curve = κ/(κ+γκ)` 放宽转弯段的惩罚
    （依据 `arXiv:2412.16248` §3.3：大转向惩罚会抑制必要的转向调整）。
    传 `curvature=None` 或 `DSH_YAW_CURVE_GAMMA=0` ⇒ **完全复现论文原式**。

    注意 ψ 的**取值口径**由调用方决定（见 dds_dcarl_turn._yaw_for_reward）：
      · 论文字面：自车绝对横摆角（适合直道换道，=0 为理想）
      · 左转专用：|自车航向 − 参考转弯路径切线航向|（左转必经 ~90° 转角，
                  用绝对横摆角会把"转弯本身"也罚掉，故改用航向跟踪误差）
    本函数只负责论文的公式形式，不预设 ψ 的来源。
    """
    x = abs(float(psi))
    p_yaw = 1.0 * (x ** 2) + 4.0 * (max(x - 0.2, 0.0) ** 2) + 25.0 * (max(x - 0.4, 0.0) ** 2)
    base = -10.0 * min(p_yaw, 5.0)
    # ===== 【2026-10-12】曲率加权：转弯段的"必要转向"放宽 =====
    if w_curve is None:
        if curvature is None:
            return base                      # 未给曲率 ⇒ 论文原式
        w_curve = yaw_curve_weight(curvature)
    try:
        wc = max(0.0, min(1.0, float(w_curve)))
    except (TypeError, ValueError):
        wc = 0.0
    return base * (1.0 - wc)


#: 【2026-10-12 奖励重标定】式67 `r_lat = −10·Δy²` 的**有界上限**
#:   为什么需要（实测依据，见 HANDOFF_2026-10-10.md §10）：
#:     · 奖励核账显示 `rew_lat` 均值 −13.28/帧，占**全部负向总量的 41.4%**（最大单项）；
#:     · 但它**不是稳定的逐帧偏差**：中位仅 −0.09，而 p10 = −42.2、min = **−144.5**
#:       ⇒ 反推横向偏差中位 0.10 m，但 p90 = 2.13 m、max = **3.80 m**；
#:     · **最差 5% 的帧（38/765）贡献了该项负向总量的 50.0%**。
#:   ⇒ 后果：期望被**罕见尖峰**支配，而"不动"是回避尖峰的最优手段
#:     （不动 ⇒ 横向偏差不增 ⇒ 不触发尖峰）⇒ **RL 学会"停车"在它自己的目标下是正确的**。
#:   本上限把单帧最大惩罚从 −144 压到 −w·cap，使"推进"与"停车"的期望可比。
#:   `DSH_LAT_CAP=0` 可恢复论文原式（无界）做消融对照。
LAT_CAP_DEFAULT = 6.0
#: 式67 的权重（论文原式 = 10.0）
LAT_W_DEFAULT = 10.0
#: 【2026-10-12 形状改造】横向偏差的**指数尺度**（m）。
#:   依据（文献）：UniPD thesis 明确指出 **"quadratic penalty that can cause overly
#:   cautious behavior"**，改用**线性化**的居中惩罚；`arXiv:1907.05246` 的安全项也用
#:   **指数衰减**而不是二次。见 `PAPER_DRAFT/EVIDENCE_reward_literature.md` L1。
#:   为什么必须改形状（而不只是调小权重）：
#:     二次型在**大偏差处斜率无上界** ⇒ "越偏越致命" ⇒ 罕见尖峰支配期望
#:     （实测最差 5% 帧占该项负向总量的 50%）⇒ RL 学会"别动"来回避尖峰。
#:     指数型 `−w·(1−exp(−|Δy|/scale))` 在**大偏差处斜率饱和**（有界 ∈[−w,0]），
#:     既保留"小偏差近似线性"的跟线引导，又不再制造致命尖峰。
LAT_SCALE_DEFAULT = 1.5
#: 式67 的形状：'exp'（默认，指数饱和）| 'linear'（线性有界）| 'quad'（论文原式，无界二次）
LAT_SHAPE_DEFAULT = 'exp'


def lat_reward(y_ego, y_target, cap=None, w=None, shape=None, scale=None):
    """式67（改造版）：Δy = y_ego − y_target；r_lat ∈ [−w, 0]。

    三种形状（`DSH_LAT_SHAPE` / `shape` 参数）：
      'exp'（默认）  : r = −w·(1 − exp(−|Δy|/scale))       ← 指数饱和，大偏差处斜率→0
      'linear'       : r = −w·min(|Δy|, scale)/scale        ← 线性有界
      'quad'（原式） : r = −w·min(Δy², cap)                 ← 论文原式（二次，无界/可加 cap）
    `DSH_LAT_SHAPE=quad` ⇒ 完整复现论文原式（消融对照）。

    ⚠️ 与论文原式的差异（**故意，且可回退**）：论文是**无界二次** `−10·Δy²`。
       文献明确二次惩罚会导致**过度保守行为**（UniPD thesis），且实测该项被罕见尖峰
       支配（最差 5% 帧占其负向总量 50%）⇒ RL 学会"停车回避尖峰"。
       详见 `LAT_SHAPE_DEFAULT` / `LAT_SCALE_DEFAULT` 的注释与
       `PAPER_DRAFT/EVIDENCE_reward_literature.md`。
    """
    try:
        dy = float(y_ego) - float(y_target)
    except (TypeError, ValueError):
        # 本函数在每帧热路径上；非法输入返回中性 0，绝不抛异常
        return 0.0
    ww = float(w) if w is not None else _env_float('DSH_LAT_W', LAT_W_DEFAULT)
    sh = (shape if shape is not None else
          os.environ.get('DSH_LAT_SHAPE', LAT_SHAPE_DEFAULT)).strip().lower()
    ady = abs(dy)

    if sh in ('quad', 'quadratic', 'paper'):
        # ===== 论文原式（消融对照）=====
        sq = dy * dy
        if cap is None:
            cap = _env_float('DSH_LAT_CAP', LAT_CAP_DEFAULT)
        if cap is not None and float(cap) > 0.0:
            sq = min(sq, float(cap))
        return -ww * sq

    sc = float(scale) if scale is not None else _env_float('DSH_LAT_SCALE', LAT_SCALE_DEFAULT)
    if not (sc > 0.0):
        sc = LAT_SCALE_DEFAULT
    if sh == 'linear':
        # ===== 线性有界 =====
        return -ww * (min(ady, sc) / sc)
    # ===== 指数饱和（默认）=====
    return -ww * (1.0 - math.exp(-ady / sc))


def total_reward(r_game, r_thw, r_yaw, r_lat):
    """式68：r_total = r_game + r_thw + r_yaw + r_lat。"""
    return float(r_game) + float(r_thw) + float(r_yaw) + float(r_lat)
