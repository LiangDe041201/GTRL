"""Conditional EFE mathematics, independent of trajectories or CARLA.

Inputs are declared normalized distributions. They are never clipped into a
plausible model. Risk compares outcome distributions; the policy KL used by
soft Bellman remains a separate calculation in the learner.
"""
import math

import numpy as np


def evaluate_efe(conditional,belief,preference):
    try:
        z=np.asarray(conditional,dtype=float)
        b=np.asarray(belief,dtype=float)
        p=np.asarray(preference,dtype=float)
    except (TypeError,ValueError) as exc: raise ValueError('Numeric EFE distributions are required') from exc
    if (z.ndim!=2 or not z.shape[0] or not z.shape[1] or b.shape!=(z.shape[0],)
            or p.shape!=(z.shape[1],) or not np.isfinite(z).all() or not np.isfinite(b).all()
            or not np.isfinite(p).all() or np.any(z<0.) or np.any(b<0.) or np.any(p<=0.)
            or not np.allclose(z.sum(axis=1),1.,atol=1.e-10,rtol=0.)
            or not math.isclose(float(b.sum()),1.,abs_tol=1.e-10,rel_tol=0.)
            or not math.isclose(float(p.sum()),1.,abs_tol=1.e-10,rel_tol=0.)):
        raise ValueError('EFE requires normalized conditionals, belief and positive preference')

    def entropy(row):
        positive=row[row>0.]
        return -float(np.dot(positive,np.log(positive)))

    q=b.dot(z); mask=q>0.
    risk=max(0.,float(np.sum(q[mask]*(np.log(q[mask])-np.log(p[mask])))))
    ambiguity=float(sum(float(w)*entropy(row) for w,row in zip(b,z)))
    marginal_entropy=entropy(q)
    information=max(0.,marginal_entropy-ambiguity)
    value=risk+ambiguity
    maximum=-math.log(float(p.min()))
    if not math.isfinite(value) or value>maximum+1.e-8*max(1.,maximum):
        raise ValueError('EFE exceeds the finite preference bound')
    normalized=0. if maximum==0. else max(0.,min(1.,value/maximum))
    return dict(risk=risk,ambiguity=ambiguity,efe=value,normalized_efe=normalized,
        maximum_efe=maximum,marginal=q.tolist(),conditional=z.tolist(),belief=b.tolist(),
        preference=p.tolist(),marginal_entropy=marginal_entropy,mutual_information=information,
        preference_cross_entropy=-float(np.dot(q,np.log(p))))


def integrated_cost(score,dt):
    """Unit-weight model cost over actual simulation time; not a reward write."""
    try:
        value=float(score['normalized_efe']); dt=float(dt)
    except (TypeError,KeyError,ValueError) as exc: raise ValueError('Finite score and simulation dt required') from exc
    if not math.isfinite(value) or not 0.<=value<=1. or not math.isfinite(dt) or dt<=0.:
        raise ValueError('Finite normalized EFE and positive simulation dt required')
    return value*dt
