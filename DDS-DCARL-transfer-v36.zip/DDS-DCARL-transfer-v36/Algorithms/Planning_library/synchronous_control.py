"""Checked CARLA control submission; this module never advances world time."""
import math


def configure_physics(world, dt=.05, substep=.005):
    """Read back effective settings; a requested setting is not evidence."""
    if not all(math.isfinite(v) and v > 0. for v in (dt, substep)) or substep > .01:
        raise ValueError('Invalid v10 physics timing')
    settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = dt
    settings.substepping = True
    settings.max_substep_delta_time = substep
    settings.max_substeps = max(10, int(math.ceil(dt/substep)))
    world.apply_settings(settings)
    actual = world.get_settings()
    result = dict(synchronous_mode=bool(actual.synchronous_mode),
        fixed_delta_seconds=float(actual.fixed_delta_seconds), substepping=bool(actual.substepping),
        max_substep_delta_time=float(actual.max_substep_delta_time), max_substeps=int(actual.max_substeps))
    if (not result['synchronous_mode'] or not result['substepping'] or
            abs(result['fixed_delta_seconds']-dt) > 1e-6 or
            abs(result['max_substep_delta_time']-substep) > 1e-6 or
            result['max_substeps']*result['max_substep_delta_time'] < dt-1e-6):
        raise RuntimeError('Server physics settings differ from request: %s' % result)
    return result


def submit_control(client, commands, actor_id, control):
    """Wait for a successful ApplyVehicleControl response, without a tick cue.

    The caller sends its single world.tick() after all control submissions.
    False is intentional: True here plus world.tick() would advance two frames.
    """
    responses = client.apply_batch_sync([commands.ApplyVehicleControl(actor_id, control)], False)
    if len(responses) != 1 or responses[0].error:
        raise RuntimeError('Vehicle control submission failed: %s' %
                           ([response.error for response in responses],))
    return True

