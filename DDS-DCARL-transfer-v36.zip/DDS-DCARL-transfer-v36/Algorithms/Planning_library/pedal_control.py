"""Explicit forward-only actuator for v9; no hidden native pedal integrator.

The brake feedforward is a static torque estimate, not a calibrated plant.
Acceleration feedback corrects that estimate. CARLA must verify the gains.
"""
import math


def clip(value, low, high):
    return max(low, min(high, value))


def brake_deceleration(physics):
    mass = float(physics.mass)
    wheels = list(physics.wheels)
    if not math.isfinite(mass) or mass <= 0. or len(wheels) != 4:
        raise ValueError('Invalid mass or wheel count for pedal controller')
    force = 0.
    for wheel in wheels:
        radius = float(wheel.radius)/100.  # CARLA wheel radius in cm
        torque = float(wheel.max_brake_torque)  # Nm
        if not all(math.isfinite(v) for v in (radius, torque)) or radius <= 0. or torque < 0.:
            raise ValueError('Invalid brake torque/radius')
        force += torque/radius
    gain = force/mass
    if not 1. < gain < 200.:
        raise ValueError('Invalid static brake deceleration: %s' % gain)
    return gain


def signed_speed(velocity, yaw_degrees):
    yaw = math.radians(float(yaw_degrees))
    return float(velocity.x)*math.cos(yaw)+float(velocity.y)*math.sin(yaw)


class PedalController:
    """Command acceleration with bounded feedforward + measured feedback.

    Mode changes discard integral history. A negative request never emits
    throttle; a positive request releases the brake immediately. No full-brake
    threshold or reverse gear is used at low speed. Both experiment arms use
    the same gains, physics and feedback, without opponent information.
    """
    def __init__(self, brake_gain, max_steer, dt=.05):
        if not all(math.isfinite(float(v)) and float(v) > 0.
                   for v in (brake_gain, max_steer, dt)):
            raise ValueError('Invalid actuator configuration')
        self.brake_gain, self.max_steer, self.dt = brake_gain, max_steer, dt
        self.integral, self.acceleration = 0., 0.
        self.throttle, self.brake, self.steer = 0., 0., 0.
        self.mode = ''
        self.raw_acceleration = 0.

    def observe(self, before, after, elapsed):
        if not math.isfinite(elapsed) or abs(elapsed-self.dt) > .0001:
            raise ValueError('Unexpected actuator feedback interval')
        self.raw_acceleration = (after-before)/elapsed
        # A bounded low pass prevents one noisy velocity difference from
        # saturating the next pedal command. The raw measurement is still logged.
        weight = elapsed/(.15+elapsed)
        self.acceleration += weight*(clip(self.raw_acceleration, -6., 4.)-self.acceleration)

    def command(self, acceleration, speed, target_speed, steering):
        if not all(math.isfinite(float(v)) for v in (acceleration, speed, target_speed, steering)):
            raise ValueError('Nonfinite pedal request')
        a = clip(float(acceleration), -3., 2.)
        speed, target = max(0., float(speed)), max(0., float(target_speed))
        # Keep signed MPC acceleration as the primary command. Speed is only
        # an overspeed/stop ceiling, never an independent traffic decision.
        if target <= .01:
            a = min(a, -min(3., max(.3, 1.5*speed)))
        elif speed > target+.15:
            a = min(a, -min(3., 1.5*(speed-target)))
        mode = 'hold' if target <= .01 and speed < .1 else ('brake' if a < -.02 else 'drive')
        if mode != self.mode:
            self.integral = 0.
        self.mode = mode
        error = a-self.acceleration
        # Integrate only when the preceding output was not saturated.
        if mode == 'drive' and self.throttle < .649 or mode == 'brake' and self.brake < .399:
            self.integral = clip(self.integral+.4*error*self.dt, -.8, .8)
        effort = a+.35+.25*error+self.integral
        throttle, brake = 0., 0.
        if mode == 'hold':
            brake = min(.1, max(.02, .5/self.brake_gain))
            self.integral = 0.
        elif mode == 'brake':
            desired = clip(-effort/self.brake_gain, 0., .4)
            # Release immediately if actual deceleration exceeds the requested
            # envelope; otherwise limit the increase in brake torque.
            brake = 0. if self.raw_acceleration < -4.5 else min(desired, self.brake+3.*self.dt/self.brake_gain)
        else:
            desired = clip(effort/3., 0., .65)
            throttle = min(desired, self.throttle+self.dt)
        delta = clip(float(steering), -self.max_steer, self.max_steer)
        normalized = delta/self.max_steer
        normalized = clip(normalized, self.steer-.9*self.dt/self.max_steer,
                          self.steer+.9*self.dt/self.max_steer)
        self.throttle, self.brake, self.steer = throttle, brake, normalized
        return dict(throttle=throttle, brake=brake, steer=normalized,
                    hand_brake=False, reverse=False, manual_gear_shift=False)


class PedalControllerV10(PedalController):
    """Measured brake feedback with a persistent release/settle state.

    Retain the v9 drive/hold behavior to limit this revision's scope. Braking
    no longer ramps toward a static feedforward target while lagged feedback
    still reports insufficient deceleration. The static gain only scales the
    incremental correction, and remains explicitly an uncalibrated estimate.
    """
    brake_rise_acceleration = .75

    def __init__(self, brake_gain, max_steer, dt=.05):
        super().__init__(brake_gain, max_steer, dt)
        self.release_active = False
        self.release_seconds = 0.
        self.release_stable_seconds = 0.
        self.release_events = 0
        self.target_acceleration = 0.

    def observe(self, before, after, elapsed):
        if not all(math.isfinite(float(v)) for v in (before, after)):
            raise ValueError('Nonfinite actuator observation')
        super().observe(before, after, elapsed)
        if self.raw_acceleration < -4.5:
            if not self.release_active:
                self.release_events += 1
            self.release_active = True
            self.release_seconds = self.release_stable_seconds = 0.
        elif self.release_active:
            self.release_seconds += elapsed
            self.release_stable_seconds = (self.release_stable_seconds+elapsed
                if abs(self.raw_acceleration) <= 1.5 else 0.)
            if self.release_seconds >= .25-1e-9 and self.release_stable_seconds >= .15-1e-9:
                self.release_active = False

    def acknowledge_pedals(self, throttle, brake, steer):
        # Use actual feedback as the starting point of the next correction,
        # even when the independent submission/feedback contract fails.
        values = [float(v) for v in (throttle, brake, steer)]
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Nonfinite applied pedals')
        self.throttle, self.brake, self.steer = values

    def braking_target(self, acceleration, speed):
        return acceleration

    def command(self, acceleration, speed, target_speed, steering):
        values = [float(v) for v in (acceleration, speed, target_speed, steering)]
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Nonfinite pedal request')
        acceleration, speed, target_speed, steering = values
        a = clip(acceleration, -3., 2.)
        speed, target = max(speed, 0.), max(target_speed, 0.)
        if target <= .01:
            a = min(a, -min(3., max(.3, 1.5*speed)))
        elif speed > target+.15:
            a = min(a, -min(3., 1.5*(speed-target)))
        a = self.braking_target(a, speed)
        self.target_acceleration = a
        if a >= -.02 or target <= .01 and speed < .1:
            return super().command(acceleration, speed, target, steering)
        self.mode, self.integral = 'brake', 0.
        # More braking only when the latest measurement needs it. At the
        # measured v9 gain (~5.31), initial increments are ~0.007, not 0.028.
        correction = .8*(self.raw_acceleration-a)*self.dt/self.brake_gain
        change = clip(correction, -2.*self.dt/self.brake_gain, self.brake_rise_acceleration*self.dt/self.brake_gain)
        brake = 0. if self.release_active else clip(self.brake+change, 0., .4)
        normalized = clip(steering, -self.max_steer, self.max_steer)/self.max_steer
        normalized = clip(normalized, self.steer-.9*self.dt/self.max_steer,
                          self.steer+.9*self.dt/self.max_steer)
        self.throttle, self.brake, self.steer = 0., brake, normalized
        return dict(throttle=0., brake=brake, steer=normalized,
                    hand_brake=False, reverse=False, manual_gear_shift=False)


class PedalControllerV11(PedalControllerV10):
    """Low-speed torque taper and drive anti-windup; gains need CARLA checks."""
    revision = 11
    brake_rise_acceleration = 2.

    def braking_target(self, acceleration, speed):
        return max(acceleration, -1.5*speed) if speed < 1.2 else acceleration

    def command(self, acceleration, speed, target_speed, steering):
        previous_throttle = self.throttle
        request = super().command(acceleration, speed, target_speed, steering)
        speed = max(0., float(speed))
        if self.mode == 'brake' and speed < 1.2:
            # v10 built up brake=0.155 at 0.76 m/s before a measured shock.
            # Bleed accumulated torque before that speed range is reached.
            request['brake'] = min(request['brake'], .12*clip((speed-.1)/1.1, 0., 1.))
            self.integral = 0.
        elif self.mode == 'hold':
            request['brake'] = .02
            self.integral = 0.
        elif self.mode == 'drive':
            cap = min(.65, .35+.25*speed)
            request['throttle'] = min(request['throttle'], cap, previous_throttle+.5*self.dt)
            if self.raw_acceleration > 4.5:
                request['throttle'] = 0.
            if request['throttle'] < self.throttle or self.raw_acceleration > 4.5:
                self.integral = 0.
        self.throttle, self.brake = request['throttle'], request['brake']
        return request

