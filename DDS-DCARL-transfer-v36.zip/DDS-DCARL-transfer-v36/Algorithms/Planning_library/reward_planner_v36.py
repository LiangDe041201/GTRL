"""Evaluate task outcome and elapsed time without rewarding cruising speed."""
import math

from Planning_library.entry_planner_v35 import EntryLearnerV35, EntryPlannerV35


HALF_LIFE_S = 60.
TIME_COST_PER_SECOND = .06
TERMINAL_REWARDS = {None: 0., 'complete': 5., 'collision': -10., 'stuck': -5.}


def task_reward_v36(applied, dt=.05, outcome=None, intervention=False):
    acceleration = float(applied['a_cmd'])
    if (not math.isfinite(dt) or dt <= 0. or not math.isfinite(acceleration)
            or outcome not in TERMINAL_REWARDS):
        raise ValueError('Invalid realized task outcome, control or time step')
    control_cost = .01*min((acceleration/3.)**2,1.)
    intervention_cost = .02*bool(intervention)
    return TERMINAL_REWARDS[outcome] - dt*(TIME_COST_PER_SECOND+control_cost+intervention_cost)


class RewardLearnerV36(EntryLearnerV35):
    SCHEMA = 'cg_joint_task_time_reward_v36'

    def __init__(self, phase='train', checkpoint=None, min_episodes=10):
        super().__init__(phase,checkpoint,gamma=2.**(-.05/HALF_LIFE_S),min_episodes=min_episodes)

    def signature(self):
        return dict(super().signature(),reward='task_outcome_time_v36',
                    discount_half_life_s=HALF_LIFE_S,time_cost_per_second=TIME_COST_PER_SECOND)


class RewardPlannerV36(EntryPlannerV35):
    LEARNER_CLASS = RewardLearnerV36
    LEARNER_METADATA = dict(EntryPlannerV35.LEARNER_METADATA,learner_revision=RewardLearnerV36.SCHEMA)
    frame_reward = staticmethod(task_reward_v36)
