# -*- coding: utf-8 -*-
"""论文 §III.A「博弈六要素」的信息建模 —— 式(11)(12)(13)(14)(15)(16)(17)

审计结论（PLAN §30）：本模块对应的公式在改造前**整仓 0 命中**，即论文的
"不完全信息 + 类型 + 共同知识"博弈在代码里只有语义近似（Harsanyi 类型后验
散落在 `type_inference.py`），**没有形式化的信息集与历史路径**。本模块补齐它。

逐式对应
--------
式(11) 信息集   ``I_i = {s_0, s_1, …, s_j, …, s_n, U_0, U_1, …, U_j, …, U_n}``
        —— agent i 的信息集 = **全体参与者的历史状态序列 + 效用序列**。
        ⇒ `InformationSetTracker.info_set(pid)`

式(12) 历史路径 ``p_t = (a_0, a_1, …, a_{t-1})``
        —— t 之前**所有参与者**的完整动作序列。
        ⇒ `HistoryPath`（按帧序记录联合动作，可界定一条路径的边界）

式(13) 完美信息 ``∀t, ∀i, |I_{i,t}| = 1, I_{i,t} = {p_t}``
        —— 每个信息集只含一个决策点。
        ⇒ `InformationSetTracker.is_perfect_information()`

式(14) 初始信息集 ``I_{i,0} = {(∅)}, |I_{i,0}| > 1, ∀a_{-i}``
        —— t=0 无历史；对**他人动作组合** `a_{-i}` 的不确定性使基数 > 1。
        ⇒ `initial_cardinality()`

式(15) 同集内两条不同历史 ``p' ∈ I_{i,t}, p'' ∈ I_{i,t}, p' ≠ p''``
        ⇒ `has_distinct_histories(pid)`

式(16) 不完全信息的存在性 ``∃t, ∃i, |I_{i,t}| > 1``
        ⇒ `is_imperfect()`

式(17) 共同知识 / 私有类型 ``∀k ≥ 1, ∀i_1, …, i_k, Θ_{i_k} ∈ I_{i_1}``
        —— 类型**空间** Θ 是共同知识；每个参与者的**私有类型** β_j 是它自己的。
        ⇒ `TYPE_SPACE`（共同知识）+ 每参与者的 `private_type`

式(9) 状态 ``s_i = [x_i, y_i, v_i, acc_i, φ_i, β_i]``
        —— β_i 是**隐藏博弈参数**。审计发现代码状态向量**没有 β 这一维**、
        且 `crossing_conflict_detail(beta=…)` 的 β 是死参数（只回传进 dict）。
        ⇒ `with_beta(state, beta)` 把 β 接到状态第 6 维。

为什么"信息集"必须显式建模（而不是只留一个类型后验）
--------------------------------------------------
`|I_{i,t}|` 的语义是"**与自车观测序列相容的、不同的完整历史有几条**"。
只有当它 > 1 时，博弈才真的是不完全信息的；而 (13)(15)(16) 都是关于它的
**可检验命题**。把类型后验直接塞进一个概率值（改造前的做法）丢掉了这个基数，
于是：策略 σ_i 无法以 I_i 为输入（式19）、共同知识无法表达（式17）、
"完美 vs 不完全"也无法判定。本模块把基数补回来。
"""
import math
from collections import OrderedDict


# ============================================================
# 式(17)：类型空间 Θ —— **共同知识**（所有参与者都知道这个集合与先验）
# ============================================================
#: 隐藏博弈参数 β 的取值空间（有序，便于稳定索引）。与 `rv_decision.RV_THETA`
#: 保持同一语义（aggressiveness 档位），但这里作为**类型空间的正式定义**。
TYPE_SPACE = ('conservative', 'normal', 'aggressive')
#: 共同知识先验（式17 的 common knowledge：先验本身也是公开的）
TYPE_PRIOR = {t: 1.0 / len(TYPE_SPACE) for t in TYPE_SPACE}


def with_beta(state, beta):
    """式(9)：把隐藏类型 β 接到状态向量第 6 维 `s_i = [x,y,v,acc,φ,β]`。

    改造前的代码状态是 5 维 `(curvature, lat_error, speed_ratio, cross_gap_norm,
    dist_to_cross_norm)`，**不含 β**；β 只被写进一个没有任何消费者的 dict 键。
    本函数是"β 进状态"的唯一入口，保证第 6 维一定被填。
    """
    st = tuple(state)
    return st + (float(beta),)


class HistoryPath(object):
    """式(12)：历史路径 `p_t = (a_0, a_1, …, a_{t-1})`。

    与经验池的区别（审计 §30.2）：经验池 `rtree_env_data.pkl` 的元组是
    `(state, sign, action, reward-to-go)`，**无 episode/frame 索引**、跨回合累积、
    且只按 R-tree 空间邻域被消费 —— **从不按顺序回放**，因此不能充当 `p_t`。
    本类按 `(episode, step)` 严格有序记录**联合动作**，可界定一条路径的边界。
    """

    def __init__(self):
        self.episode = None
        #: OrderedDict[(episode, step)] = {pid: action}
        self._joint = OrderedDict()

    def reset(self, episode):
        self.episode = episode
        self._joint.clear()

    def append(self, episode, step, actions):
        """记录一步的**联合动作** `a_t = (a_t^0, …, a_t^n)`。"""
        self._joint[(int(episode), int(step))] = dict(actions or {})

    def up_to(self, step, episode=None):
        """`p_t = (a_0, …, a_{t-1})`：严格早于 `step` 的联合动作序列。"""
        ep = self.episode if episode is None else int(episode)
        out = []
        for (e, s), acts in self._joint.items():
            if e == ep and s < int(step):
                out.append(acts)
        return tuple(out)

    def actions_of(self, pid, step=None, episode=None):
        """某个参与者的动作子序列 `(a_0^j, …, a_{t-1}^j)`。"""
        return tuple(a.get(pid) for a in self.up_to(
            step if step is not None else (10 ** 9), episode) if pid in a)

    def __len__(self):
        return len(self._joint)


class ParticipantStep(object):
    """式(11) 里的一个元素：参与者 j 在某一步的 `(s_j, a_j, U_j)`。"""

    __slots__ = ('step', 'pid', 'state', 'action', 'utility')

    def __init__(self, step, pid, state, action, utility):
        self.step = int(step)
        self.pid = pid
        self.state = tuple(state) if state is not None else ()
        self.action = action
        self.utility = utility

    def as_tuple(self):
        return (self.step, self.pid, self.state, self.action, self.utility)

    def __repr__(self):
        return 'ParticipantStep(step=%d, pid=%r, U=%r)' % (self.step, self.pid, self.utility)


def rv_action_entropy(actions, base=2.0):
    """【式(18) 正确口径】`H = −Σ_{L∈A} p_L·log p_L`，`p_L` = **对手执行动作 L 的统计频率**。

    ⚠️ 口径修正（PLAN §30 的 B6）：改造前代码里的 `rv_intent_entropy` 是对
    **二元让行/抢行意图** 或 **类型后验 τ** 求熵，而论文式(18) 的 `p_L` 明确是
    "对手执行**动作** L 的统计频率"（分布定义在**动作集 A** 上）。
    本函数从**历史路径** `p_t` 里统计对手实际执行过的动作频率，再求熵 ⇒ 口径与论文一致。
    它同时给 `HistoryPath`（式12）一个**真实消费者**（此前历史只被记录、无人使用）。
    """
    acts = [a for a in (actions or []) if a is not None]
    if not acts:
        return 0.0
    cnt = {}
    for a in acts:
        cnt[a] = cnt.get(a, 0) + 1
    n = float(len(acts))
    h = 0.0
    for c in cnt.values():
        p = c / n
        if p > 0.0:
            h -= p * math.log(p, base)
    return float(h)


class InformationSetTracker(object):
    """式(11) 信息集 + 式(13)(14)(15)(16) 的可检验性质。

    参数
    ----
    type_space : 式(17) 的共同知识类型空间
    consistency_eps : 类型后验低于该值即视为"与观测不相容"，不再计入 `|I_{i,t}|`
    """

    def __init__(self, type_space=TYPE_SPACE, consistency_eps=0.05, ego_pid=0):
        self.type_space = tuple(type_space)
        self.type_prior = {t: 1.0 / len(self.type_space) for t in self.type_space}
        self.consistency_eps = float(consistency_eps)
        #: 自车参与者 id。式(17) 的私有类型意味着**自车知道自己的 β**，
        #: 所以算 `|I_{i,t}|` 时它自己不贡献不确定性（否则会多乘一个 |Θ|）。
        self.ego_pid = ego_pid
        self.episode = None
        #: 每参与者的 (s,a,U) 序列 —— 式(11) 的 `{s_j…, U_j…}`
        self._records = {}
        #: 每参与者的私有类型 β_j（式17 私有类型 / 式9 状态第 6 维）
        self._private_type = {}
        #: 对每个对手的类型后验（ego 视角）
        self._posterior = {}
        self.history = HistoryPath()

    # ---------- 生命周期 ----------
    def reset(self, episode, participants=()):
        self.episode = int(episode)
        self._records = {p: [] for p in participants}
        self._private_type = {}
        self._posterior = {}
        self.history.reset(self.episode)

    def set_private_type(self, pid, beta):
        """式(17)：设定某参与者的私有类型 `β_j`（仅它自己与"上帝视角"知道）。"""
        self._private_type[pid] = float(beta)
        self._records.setdefault(pid, [])

    def set_posterior(self, pid, posterior):
        """ego 对参与者 `pid` 类型的**信念**（Harsanyi 类型博弈的后验）。"""
        tot = sum(max(0.0, float(v)) for v in (posterior or {}).values())
        self._posterior[pid] = ({k: max(0.0, float(v)) / tot
                                 for k, v in (posterior or {}).items()} if tot > 0 else {})

    # ---------- 式(11)：信息集 ----------
    def observe(self, step, pid, state, action, utility):
        """记录参与者 `pid` 在第 `step` 步的 `(s_j, a_j, U_j)`。"""
        self._records.setdefault(pid, []).append(
            ParticipantStep(step, pid, state, action, utility))

    def append_joint_action(self, step, actions):
        """式(12)：把该步的联合动作并入历史路径 `p_t`。"""
        self.history.append(self.episode, step, actions)

    def info_set(self, pid):
        """式(11) `I_i = {s_0..s_n, U_0..U_n}`：**全体参与者**的历史状态与效用序列。

        返回 `{'states': {j: (s_j^0…)}, 'utilities': {j: (U_j^0…)},
        'history_path': p_t, 'cardinality': |I_{i,t}|}`。
        注意 `states`/`utilities` 覆盖**所有**已登记的参与者（含 ego 自己），
        这正是式(11) 与"单帧特征包"的本质区别。
        """
        states, utils = {}, {}
        for j, recs in self._records.items():
            states[j] = tuple(r.state for r in recs)
            utils[j] = tuple(r.utility for r in recs)
        return {
            'pid': pid,
            'states': states,
            'utilities': utils,
            'history_path': self.history.up_to(self._step_now()),
            'cardinality': self.cardinality(pid),
        }

    def _step_now(self):
        m = 0
        for recs in self._records.values():
            if recs:
                m = max(m, recs[-1].step + 1)
        return m

    # ---------- 式(13)(14)(15)(16)：信息集的基数与性质 ----------
    def _n_types(self, j):
        """参与者 j 在 ego 眼中**仍可能**的私有类型个数（式17 的 β_j）。"""
        if j == self.ego_pid:
            return 1                      # 式(17)：自车知道自己的私有类型 β_0
        post = self._posterior.get(j)
        if post:
            return max(1, sum(1 for v in post.values() if v > self.consistency_eps))
        return max(1, len(self.type_space))

    def cardinality(self, pid):
        """`|I_{i,t}|`：与 agent i 的信息**相容**的不同完整历史条数。

        历史的分歧来自**别人的私有类型 β_j**（i 观测不到）。agent i 知道自己的 β_i，
        所以 `|I_{i,t}| = Π_{j≠i} (# 仍可能的 β_j)`。
        这是可检验、且与式(14)(16) 一致的建模 —— 也正是 (13) 能被判定为 False 的原因。
        """
        others = [p for p in self._records if p != pid]
        if not others:
            return 1                      # 只有自己 ⇒ 没有不确定性 ⇒ 完美信息
        n = 1
        for j in others:
            n *= self._n_types(j)
        return n

    def initial_cardinality(self, pid=None):
        """式(14) `|I_{i,0}| > 1`：t=0（无历史）时对 `a_{-i}` 的不确定性。

        在类型博弈的等价表述下，t=0 时所有类型都可能 ⇒ `|I_{i,0}| = |Θ|`。
        """
        return max(1, len(self.type_space))

    def is_perfect_information(self):
        """式(13)：`∀t, ∀i, |I_{i,t}| = 1`。任一参与者基数 > 1 即不成立。"""
        return all(self.cardinality(p) == 1 for p in self._records)

    def has_distinct_histories(self, pid):
        """式(15)：同一信息集内存在两条不同历史 `p' ≠ p''`。"""
        return self.cardinality(pid) > 1

    def is_imperfect(self):
        """式(16)：`∃t, ∃i, |I_{i,t}| > 1`。"""
        return any(self.cardinality(p) > 1 for p in self._records)

    def info_state(self):
        """把式(11)–(17) 的可检验量打成一行，供日志/离线核对。"""
        return {
            'episode': self.episode,
            'n_participants': len(self._records),
            'history_len': len(self.history),
            'perfect': bool(self.is_perfect_information()),
            'imperfect': bool(self.is_imperfect()),
            'cardinality': {p: self.cardinality(p) for p in self._records},
            'initial_cardinality': self.initial_cardinality(),
            'private_types': dict(self._private_type),
            'posterior': {p: dict(v) for p, v in self._posterior.items()},
        }
