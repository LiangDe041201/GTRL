#!/usr/bin/env python3
"""
交叉车流（RV）让行/抢行决策模型（纯函数，无 CARLA 依赖，离线可对拍）。

对标论文 ADVEI-D-26-08155 §VI-A 与 PRB_STA-check_point_rl 原版后车决策模型：
  - zone A（强制让行区）：自车已越过冲突点（committed）或边界 TTC 低于紧急阈值
    -> 强制让行（刹停），对应原版 stop_flag / emergency_switch；
  - zone B（选择让行区）：Bernoulli 采样，让行概率 p_yield 由"抢行难度"动态决定，
    对应原版 update_yield_prob / try_switch 与论文式 61 的动态阈值思想。

决策周期由调用方控制（默认 2s 一次），周期内行为保持稳定。
"""
import math
import random
from typing import Dict, Optional


#: RV 类型空间（对手 private type，论文 §III-A 的类型空间/隐藏参数 θ）
#: θ=aggressiveness ∈ [0,1]：θ 越大 RV 越激进（越倾向抢行、让行概率越低）。
#: θ=0 保守(易让行) / 0.5 正常 / 1 激进(难让行)。默认 0.5 与旧行为完全一致。
RV_THETA = {'aggressive': 0.8, 'normal': 0.5, 'conservative': 0.2}
RV_THETA_DEFAULT = 0.5

#: IDM / 车辆默认最大加速度 (m/s²)，式61 中 acc_max 的兜底
ACC_MAX_DEFAULT = 2.0


def intercept_acceleration(d_gap: float, v_rv: float, t_avail: float) -> float:
    """RV 要在 t_avail 内到达冲突点所需的加速度（运动学，用于式61 的 acc_need）。

        d = v·t + ½·a·t²  ⇒  a_need = 2(d − v·t)/t²
    返回值 >0 表示需要加速抢行；<0 表示需要减速。
    """
    t = max(float(t_avail), 1e-3)
    return 2.0 * (float(d_gap) - float(v_rv) * t) / (t * t)


def time_to_cover(dist: float, v0: float, v_target: float,
                  a_acc: float = 2.0, a_dec: float = 3.0) -> float:
    """运动学：从 v0 出发、以限幅加/减速度趋向 v_target，走完 dist 所需时间 (s)。

    分段匀变速解析解（先按限幅变化到 v_target，之后匀速）：
      加速：d_acc = (v_t² − v0²)/(2·a_acc)；减速：d_dec = (v0² − v_t²)/(2·a_dec)
      dist ≤ 该距离 → 用 v_end² = v0² ± 2·a·dist 求末速再求时间；否则剩余距离按 v_t 匀速。
    v_target ≤ 0 表示"减速到停"：若停车距离 v0²/(2·a_dec) < dist，则在时域内到不了 → 返回 inf。
    dist ≤ 0 → 0。本函数是【式56/57 EFE(s,a) 的观测预测】所需的到达时间估计。

    【多智能体一致性】自车与 RV 的到达时间都用本函数，只是限幅不同（自车 a_acc/a_dec 取 MPC
    的 a_max/a_min；RV 取 IDM 的 a 与让行减速度），保证两边"同一套运动学、同一口径"。
    """
    d = float(dist)
    if d <= 0.0:
        return 0.0
    v0 = max(float(v0), 0.0)
    vt = max(float(v_target), 0.0)
    aa = max(float(a_acc), 1e-6)
    ad = max(float(a_dec), 1e-6)
    if vt <= 1e-6:
        d_stop = v0 * v0 / (2.0 * ad)
        if d_stop < d:
            return float('inf')                     # 停住也到不了
        v_end = math.sqrt(max(v0 * v0 - 2.0 * ad * d, 0.0))
        return (v0 - v_end) / ad
    if v0 < vt:                                     # 需要加速
        d_acc = (vt * vt - v0 * v0) / (2.0 * aa)
        if d <= d_acc:
            v_end = math.sqrt(v0 * v0 + 2.0 * aa * d)
            return (v_end - v0) / aa
        return (vt - v0) / aa + (d - d_acc) / vt
    if v0 > vt:                                     # 需要减速到 vt（非 0）
        d_dec = (v0 * v0 - vt * vt) / (2.0 * ad)
        if d <= d_dec:
            v_end = math.sqrt(max(v0 * v0 - 2.0 * ad * d, 0.0))
            return (v0 - v_end) / ad
        return (v0 - vt) / ad + (d - d_dec) / vt
    return d / vt                                   # 已匀速


def difficulty_eta(acc_need: float, acc_current: float,
                   acc_follow: float, acc_max: float = ACC_MAX_DEFAULT) -> float:
    """【论文式61】RV 通过难度（动态阈值，替代固定 cooperation 参数）：

        η_difficulty = (acc_need − acc_current) / (acc_rest − acc_current)
        acc_rest     = min(acc_follow, acc_max)

    含义：RV 想抢行时"需要的加速度"相对"剩余加速能力"的比例。η 越大表示抢行越难
    （RV 越倾向让行）。分母为 0 时退化为阶跃（acc_need>acc_current → 1，否则 0）。
    """
    acc_rest = min(float(acc_follow), float(acc_max))
    denom = acc_rest - float(acc_current)
    if abs(denom) < 1e-6:
        return 1.0 if float(acc_need) > float(acc_current) else 0.0
    return (float(acc_need) - float(acc_current)) / denom


def yield_prob_from_difficulty(eta: float, theta_bias: float = 0.0,
                               lo: float = 0.1, hi: float = 0.9) -> float:
    """把式61 的难度 η 映射为 Bernoulli 让行概率 p。

    论文中 η 直接替代固定 cooperation 参数；此处用有界单调映射
        p = clip(0.5 + 0.5·tanh(η) + theta_bias, lo, hi)
    —— η 越大（RV 越难抢行）→ p 越大（越倾向让行）；theta_bias 承载对手类型 θ，
    以加性偏置施加，保证在 η 偏离 0 时 θ 仍然有效（直接 clip(η) 会让 θ 在极端 η 下失效）。
    """
    p = 0.5 + 0.5 * math.tanh(float(eta))
    return min(float(hi), max(float(lo), p + float(theta_bias)))


def idm_leader_index(xs, i: int):
    """【IDM 前车索引】返回第 i 辆车的前车索引（x 更小=更靠西=更靠前，且距离最近）。

    ⚠ 这里修的是一个**真实存在的旧 bug**：原 CrossTrafficManager 的写法是
        vehicles 按 x 升序排序后，从 `range(i+1, n)` 里找 `x < x_i` 的车
      —— 升序列表中 i+1 之后的 x 只会更大，条件**永远不成立** ⇒ front_data 恒为 None
      ⇒ **IDM 的跟车/避撞项从未生效**，每辆车都按自由流加速、无视前车。
      实测后果：RV 队列中心距被压到 3.68 m（≈ 车身长，即已经贴死/互相顶），
      也就是肉眼看到的"后车碰前车"。
    正确做法：前车 = x 比 x_i 小的车中 x 最大的那一辆（升序列表即 i−1）；
    本函数对未排序输入也稳健。无前车 → None。
    """
    if not xs or i < 0 or i >= len(xs):
        return None
    xi = float(xs[i])
    best, best_gap = None, float('inf')
    for j, xj in enumerate(xs):
        if j == i:
            continue
        d = xi - float(xj)
        if 0.0 < d < best_gap:
            best, best_gap = j, d
    return best


def idm_acceleration(v: float, front_v: float, gap: float,
                     v0: float = 10.0, T: float = 0.5, g0: float = 2.0,
                     a: float = 2.0, b: float = 2.5, delta: float = 4.0) -> float:
    """IDM 跟车加速度（纯函数；论文 §VI-A 明确用 IDM 控制 FV/SV/RV）。

        s* = g0 + max(0, v·T + v(v − v_front)/(2√(a·b)))
        acc = a·[1 − (v/v0)^delta − (s*/gap)²]

    gap ≤ 0 → 严重制动（−2b）。返回 clip(acc, −2b, a)。
    抽成纯函数的目的：可在**离线**验证"出生间距是否满足 IDM 平衡"——
    即证明"新车一出生就被判大减速 → 幽灵刹车 → 队列压死 → 后车碰前车"已被修好。
    """
    if gap <= 0:
        return -b * 2.0
    v = max(float(v), 0.0)
    front_v = max(float(front_v), 0.0)
    v0 = max(float(v0), 1e-6)
    s_star = g0 + max(0.0, v * T + (v * (v - front_v)) / (2.0 * math.sqrt(a * b)))
    acc = a * (1.0 - (v / v0) ** delta - (s_star / gap) ** 2)
    return max(-b * 2.0, min(a, acc))


def traffic_speed_step(v, front_v, gap, v_const=4.41, T=0.5, g0=2.0,
                       a=2.0, b=2.5, delta=4.0, dt=0.05, v_min=0.5):
    """【§63】交叉车流的速度更新：**恒定速度 + 安全距离跟车**（纯函数，可离线对拍）。

    与标准 IDM 的三点区别（用户口径）：
      1. **没有"趋向 v0=6.0 的自由流加速"**：目标速度就是恒定速度 `v_const`。
         实测问题：`desired_speed=6.0` 时，IDM 平衡净间距 `s*(v)=g0+v·T`
         最大只有 5.0 m，而 ego 穿越需要 **8.5 m** ⇒ 稳态车流永远插不进去；
         唯一机会是让行造成的暂态间隙，而自由流加速会在 ~2 s 内把它关掉
         （ego 需要窗口维持 6.1 s）。
      2. `gap ≥ s_safe` ⇒ **只允许恢复到 v_const，不做跟车制动**（`acc` 非负但受上限约束）
         ⇒ **大间隙不会被自己关掉** —— 这是插入窗口能存活的前提。
      3. `gap < s_safe` ⇒ 用 IDM 交互项**只制动**（≤0）。
      4. 硬上限 `v ≤ v_const`：**绝不超过恒定速度**（但仍允许从低速恢复回来）。
        用户确认：恒定速度 4.41，允许回到 4.41。

    `front_v` 为 None 表示无前车（同样只恢复到 v_const，不加速到 v0）。
    返回 `(new_speed, acc)`。
    """
    v = max(float(v), 0.0)
    v_const = max(float(v_const), 1e-6)
    s_safe = float(g0) + v * float(T)          # 安全净间距（IDM 平衡间距）
    if front_v is None or float(gap) >= s_safe:
        # 间距足够 / 无前车 ⇒ 只"恢复到恒定速度"，**不做跟车制动**
        if v < v_const:
            acc = float(a) * (1.0 - (v / v_const) ** float(delta))
        else:
            acc = 0.0
    else:
        # 间距不足 ⇒ 只制动
        acc = min(0.0, idm_acceleration(v, front_v, float(gap), v0=v_const,
                                        T=T, g0=g0, a=a, b=b, delta=delta))
    new_v = v + acc * float(dt)
    new_v = max(float(v_min), min(new_v, v_const))      # 硬上限：绝不超过恒定速度
    return new_v, acc


def idm_equilibrium_speed(gap: float, v0: float = 10.0, T: float = 0.5,
                          g0: float = 2.0, a: float = 2.0, b: float = 2.5,
                          delta: float = 4.0, lo: float = 0.0,
                          hi: float = None, iters: int = 60) -> float:
    """给定净间隙 gap，求 IDM 跟车的**稳态车速** v_ss（acc = 0 的解）。

    为什么需要它：IDM 在跟车时**不存在 v = v0 的稳态** ——
        acc = a·[1 − (v/v0)^δ − (s*/gap)²] = 0 且 v = v0 ⇒ (s*/gap)² = 0 ⇒ 需 gap → ∞。
    也就是说"设计间隙为 5 m 却要求车流跑到 v0=6 m/s"是自相矛盾的：车流一定会自己
    减速到某个 v_ss < v0。若出生时按 v0 投放，就会出现一段减速暂态（本项目的
    幽灵刹车/队列压缩正来源于此类不一致）。正确做法是**按间隙求稳态速度**，
    出生时就以 v_ss 投放 → 队列零暂态、间距恒定。

    用二分法求解（acc(v) 关于 v 单调递减：v↑ → (v/v0)^δ↑ 且 s*↑）。
    """
    gap = float(gap)
    if gap <= 0.0:
        return 0.0
    v0 = max(float(v0), 1e-6)
    hi = float(hi) if hi is not None else v0

    def _acc(v):
        return idm_acceleration(v, v, gap, v0=v0, T=T, g0=g0, a=a, b=b, delta=delta)

    if _acc(lo) <= 0.0:
        return float(lo)
    if _acc(hi) >= 0.0:
        return float(hi)
    for _ in range(int(iters)):
        mid = 0.5 * (lo + hi)
        if _acc(mid) > 0.0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def idm_equilibrium_center(v: float, T: float = 0.5, g0: float = 2.0,
                           veh_len: float = 3.6) -> float:
    """等速车流的 IDM 平衡**中心距**（米）= g0 + v·T + 车身长。

    出生间距必须 ≥ 它，否则每辆新车一出生就在前车的安全距离内 → 幽灵刹车。
    """
    return float(g0) + max(float(v), 0.0) * float(T) + float(veh_len)


def platoon_ids_behind(ids_sorted_asc, rv_id, k: int):
    """【让行编队】给定按 x 升序（队首在前）排列的车辆 id 列表，
    返回 rv_id **及其后方 k 辆**的 id 集合。

    为什么需要：只让"被切入的那一辆 RV"减速时，间隙虽然会在它前方张开，但
    **它后面的车紧跟上来**（IDM 跟车）→ 窗口太短 → ego 进得去、出不来。
    实测（expE_p0_100）车流稳态中心距只有 8.6 m，单车间隙 ≈5 m，
    按 4.4 m/s 巡航算只有 ~1.1 s —— 不足以让 ego 完成一次左转。
    把让行沿队列向后传播 k 辆，可把窗口从"1 个间隙"扩到"(k+1) 个间隙"，
    这也符合拥堵队列里"后车本来也超不过去"的物理现实。

    返回集合包含 rv_id 本身（调用方自行排除）。
    """
    if rv_id is None:
        return set()
    try:
        j = list(ids_sorted_asc).index(rv_id)
    except ValueError:
        return {rv_id}
    out = set()
    for m in range(0, max(int(k), 0) + 1):
        if j + m < len(ids_sorted_asc):
            out.add(ids_sorted_asc[j + m])
    return out


def rv_yield_probability(ego_state: Dict, rv_state: Dict, conflict_x: float,
                         ttc_boundary: Optional[float] = None,
                         theta: Optional[float] = None,
                         acc_current: float = 0.0,
                         acc_follow: Optional[float] = None,
                         acc_max: float = ACC_MAX_DEFAULT,
                         t_ego: Optional[float] = None) -> float:
    """
    纯函数：RV 让行概率 p（无采样，供 ego 侧 Cournot 博弈直接使用）。

    仅 zone B；zone A（committed / 紧急）的强制让行由调用方处理。

    【论文式61 路径】优先用通过难度 η_difficulty 决定让行概率：
        η = (acc_need − acc_current)/(acc_rest − acc_current)，acc_rest = min(acc_follow, acc_max)

    【t_avail 口径·严格按论文原文】论文 §VI-A：
        "the boundary model estimates **the time it will take for the LCV to enter Area A
         from a potential conflict node**, and based on this, calculates the acceleration
         required for the RV to intercept the LCV, acc_need."
      ⇒ 可用时间 = **自车(LCV)到冲突点的时间** t_ego（不是 ego-RV 的边界 TTC）。
    故本函数优先用 t_ego；只有 t_ego 缺失/非有限时才退回 ttc_boundary 作代理，
    以保持向后兼容（旧调用点未传 t_ego 时行为不变）。
    【兜底路径】两者都缺失时，退回旧的三因子启发式 (prox/urgency/headroom)。

    theta: RV 类型 aggressiveness（θ 高=激进→让行概率低）。两种路径都会叠加该类型偏置。
    """
    th = RV_THETA_DEFAULT if theta is None else float(theta)
    base = (RV_THETA_DEFAULT - th)          # 保守(+)/激进(−)，θ=0.5 → 0 不改变行为

    _t_ok = t_ego is not None and math.isfinite(float(t_ego))
    _ttc_ok = ttc_boundary is not None and math.isfinite(float(ttc_boundary))
    if _t_ok or _ttc_ok:
        # 式61：acc_need 用「RV 到冲突点距离、当前速度、可用时间 t_avail」的运动学估计
        _rv_v = max(float(rv_state.get('v', 10.0)), 0.1)
        d_gap = abs(float(rv_state.get('x', 0.0)) - float(conflict_x))
        t_avail = max(float(t_ego) if _t_ok else float(ttc_boundary), 1e-3)
        acc_need = intercept_acceleration(d_gap, _rv_v, t_avail)
        _acc_follow = ACC_MAX_DEFAULT if acc_follow is None else float(acc_follow)
        eta = difficulty_eta(acc_need, acc_current, _acc_follow, acc_max)
        return yield_prob_from_difficulty(eta, theta_bias=base)

    # 兜底：三因子启发式（旧行为）
    ego_dist = abs(float(ego_state.get('x', 0.0)) - conflict_x)
    prox = math.exp(-ego_dist / 15.0)                 # 0~1，接近冲突点趋近 1
    urgency = math.exp(-4.0 / 1.5)                    # ttc 缺失，按默认 4.0s
    _rv_v = float(rv_state.get('v', 10.0))
    headroom = min(1.0, max(0.2, _rv_v / 10.0))       # 速度余量
    return min(0.9, max(0.1, base + 0.5 * prox + 0.3 * urgency + 0.2 * headroom))


def select_conflict_rv(vehicles, conflict_x: float, t_ego: float,
                       clear_time: float, margin: float = 0.5):
    """【论文 zone A 的作用对象】选出"与 ego 时空冲突的那一辆 RV"。

    论文 §VI-A："when the LCV enters zone A, **the** RV is required to yield" ——
    被强制让行的是**与 ego 冲突的那一辆**，不是决策窗内的所有车。
    （原实现"ego 距冲突点 < R_A 就对窗内每辆车强制让行"会把整条车流同时压死：
      实测 RV–RV 中心距被压到 3.68 m、82% 的间隙 < 5 m，ego 永远没有可插入窗口。）

    判定：车辆仍在冲突点以东（x > conflict_x，即尚未通过），
          其到达冲突点时间 t_rv 与自车到达时间 t_ego 的差
              |t_rv − t_ego| < clear_time + margin
          即"若两者都按当前态势前进，会在清空窗口内相遇"。
          多个满足时取 |Δt| 最小者（最危险的那一辆）。

    参数:
      vehicles: 可迭代元素，需能取到 id / x / v（支持对象属性或 dict 键）
      conflict_x: 冲突点 x
      t_ego:     自车到冲突点的时间 (s)
      clear_time: 自车清空冲突点所需时间 (s)，通常 = 车身长 / 车速
      margin:    额外裕度 (s)
    返回:
      (actor_id, best_dt)；无冲突车 → (None, inf)
    """
    best_id, best_dt = None, float('inf')
    if t_ego is None or not math.isfinite(float(t_ego)):
        return best_id, best_dt
    need = max(float(clear_time), 0.0) + max(float(margin), 0.0)
    for veh in vehicles or []:
        if isinstance(veh, dict):
            x = veh.get('x')
            v = veh.get('v', veh.get('speed', 0.0))
            vid = veh.get('id')
        else:
            x = getattr(veh, 'x', None)
            v = getattr(veh, 'v', getattr(veh, 'speed', 0.0))
            vid = getattr(veh, 'id', None)
        if x is None:
            continue
        x = float(x)
        if x <= float(conflict_x):          # 已通过/正在驶离冲突点
            continue
        t_rv = (x - float(conflict_x)) / max(float(v or 0.0), 0.1)
        dt_conf = abs(t_rv - float(t_ego))
        if dt_conf < need and dt_conf < best_dt:
            best_id, best_dt = vid, dt_conf
    return best_id, best_dt


#: 【§64 B 方案】意图耦合的几何范围（m）：自车中心距冲突点 y 向多远开始算"有进入意图"
INTENT_RANGE_DEFAULT = 8.0


def ego_intent(ego_y, conflict_y, band_half=1.0, range_m=INTENT_RANGE_DEFAULT,
               ego_half_len=2.25):
    """【§64 B 方案】自车"进入意图"的几何度量 ∈ [0,1]。

    **为什么需要它**：真实无信号路口里，左转车**把车头探出去（nose-in）**会让
    交叉车**主动让行** —— 让行是**由自车意图触发**的，不是独立随机事件。
    而现有实现里对手只是按 `rv_yield_probability`（难度耦合）独立采样，
    **与"我是否明确要进"无关** ⇒ 机会约束判据要求"所有视界的车即使全抢行也不撞我"，
    而实测 `p_yield≈0.63`、视界内 3~4 辆 ⇒ `risk≈1−0.37^3.5≈0.96` ⇒ 永远进不去。

    定义：自车车头到交叉带北边缘的净空越小、意图越强。
      `d = (ego_y − ego_half_len) − (conflict_y + band_half)`   （>0 = 车头在带外）
      `intent = clip(1 − max(d,0)/range_m, 0, 1)`
    即"车头贴线" ⇒ intent→1；"离得远" ⇒ 0。
    **纯几何、与自车是否在动无关**，因此判据侧可以用**同一个函数**从观测中
    估计"意图条件让行率"，而不必假设耦合强度（避免引入新的可套利假设）。
    """
    try:
        d = (float(ego_y) - float(ego_half_len)) - (float(conflict_y) + float(band_half))
    except (TypeError, ValueError):
        return 0.0
    rng = max(float(range_m), 1e-6)
    return max(0.0, min(1.0, 1.0 - max(d, 0.0) / rng))


def apply_intent_coupling(p_base, intent, gain=0.8, lo=0.05, hi=0.95):
    """【§64 B 方案】把难度让行概率 `p_base` 与意图耦合，得到实际采样概率。

        p_eff = p_base + (1 − p_base) · gain · intent

    然后夹到 `[lo, hi]`。`gain=0` 退化为旧行为（无耦合，可做消融对照）。
    **注意**：这个耦合是**对手的行为假设**；判据侧**不能**直接采用它，
    必须从**观测**到的意图条件让行率去估计（见 §64 的 ego 侧实现），
    否则就会变成"我假装要进 ⇒ 我假设别人让我 ⇒ 我进"的自证循环（P1-f 同类风险）。
    """
    try:
        pb = max(0.0, min(1.0, float(p_base)))
        it = max(0.0, min(1.0, float(intent)))
        g = max(0.0, float(gain))
    except (TypeError, ValueError):
        return 0.5
    return max(float(lo), min(float(hi), pb + (1.0 - pb) * g * it))


def decide_rv_behavior(ego_state: Dict, rv_state: Dict, conflict_x: float,
                       committed: bool, ttc_boundary: Optional[float],
                       yield_prob_override: Optional[float] = None,
                       rng: Optional[random.Random] = None,
                       theta: Optional[float] = None,
                       acc_current: float = 0.0,
                       acc_follow: Optional[float] = None,
                       acc_max: float = ACC_MAX_DEFAULT,
                       zone_a: bool = False,
                       t_ego: Optional[float] = None,
                       yield_target_speed: float = 3.0,
                       intent: Optional[float] = None,
                       intent_gain: float = 0.0) -> Dict:
    """
    单次让行/抢行决策。

    输入:
      ego_state: {'x','y','v'} 自车状态
      rv_state:  {'x','y','v','vx'} 交叉车状态（vx<0 表示向西）
      conflict_x: 冲突点 x 坐标（自车左转轨迹与车流交点）
      committed:  自车是否已越过冲突点
      ttc_boundary: 自车与 RV 的边界 TTC（s；None/inf 表示无逼近）
      yield_prob_override: 外部指定让行概率（调试/对抗测试用；None=按难度计算）
      rng: random.Random 实例（确定性测试用；None=用全局 random）
      theta: RV 类型 aggressiveness（保守/激进；None=0.5 正常）
      acc_current / acc_follow / acc_max: 论文式61 所需的加速度量（RV 当前加速度 /
          IDM 跟车加速度 / 最大加速度），由车流侧 IDM 提供
      zone_a: **该车**是否是需要强制让行的那辆冲突车（论文 zone A 的作用对象）。
          注意：调用方必须只对"与 LCV 时空冲突的那一辆 RV"传 True ——
          论文的 zone A 是"LCV 进入 A 区 → **该** RV 必须让行"，
          不是"对窗内所有 RV 无差别强制让行"（后者会把整条车流压死）。
      t_ego: 自车到冲突点的时间（式61 的 t_avail 口径，见 rv_yield_probability）
      yield_target_speed: 让行目标速度（m/s）；论文里 RV 通过减速后退来张开 FV–RV 间隙

    输出 dict:
      behavior:    'yield' | 'rush'
      yield_prob:  本次采样所用让行概率
      reason:      'emergency' | 'committed' | 'zoneA' | 'bernoulli'
      target_speed: 让行 -> 减速目标速度(m/s)；抢行 -> 维持原速
    """
    r = rng if rng is not None else random

    # ===== zone A：强制让行（仅对"冲突的那一辆"生效，见参数说明）=====
    if committed or zone_a:
        return {'behavior': 'yield', 'yield_prob': 1.0,
                'reason': 'committed' if committed else 'zoneA',
                'target_speed': 0.0}
    if ttc_boundary is not None and math.isfinite(float(ttc_boundary)) and float(ttc_boundary) < 0.8:
        return {'behavior': 'yield', 'yield_prob': 1.0, 'reason': 'emergency',
                'target_speed': 0.0}

    # ===== zone B：论文式61 动态让行阈值（η_difficulty）=====
    if yield_prob_override is not None:
        p = min(0.9, max(0.1, float(yield_prob_override)))
    else:
        p = rv_yield_probability(ego_state, rv_state, conflict_x, ttc_boundary, theta=theta,
                                 acc_current=acc_current, acc_follow=acc_follow,
                                 acc_max=acc_max, t_ego=t_ego)

    # 【§64 B 方案】意图耦合：自车"车头贴线/明确要进" ⇒ 提高对手让行概率。
    #   这是**对手的行为假设**（真实路口 nose-in 会逼停交叉车）；判据侧不直接采用它，
    #   而是从**观测**到的"意图条件让行率"去估计，避免自证循环（见 §64 ego 侧）。
    _p_base = float(p)
    if intent is not None and float(intent_gain) > 0.0:
        p = apply_intent_coupling(_p_base, intent, gain=intent_gain)

    behavior = 'yield' if r.random() <= p else 'rush'
    target_speed = float(yield_target_speed) if behavior == 'yield' \
        else float(rv_state.get('v', 10.0))
    return {'behavior': behavior, 'yield_prob': p, 'reason': 'bernoulli',
            'target_speed': target_speed,
            'yield_prob_base': _p_base, 'intent': (None if intent is None else float(intent))}
