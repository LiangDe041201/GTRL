"""2x2 response with shared candidate-conditioned forecasts and stop validity."""
from Planning_library.forecast_v18 import predict
from Planning_library.opponent_forecast_v18 import tracks
from Planning_library.matrix_turn_game_v16 import MatrixTurnGameV16,score_candidates as base_score


def opponent_tracks(vehicle,objects,times,cruise,primary,column,acceleration,ego,states):
    return tracks(vehicle,times,cruise=cruise,ego=ego,ego_states=states,objects=objects,
                  yielding=bool(primary and column==1),
                  acceleration=acceleration if primary else None)


def score_candidates(*args,**kwargs):
    matrix,parts = base_score(*args,ego_predict=predict,track_provider=opponent_tracks,
                             track_context=True,**kwargs)
    for i,row in enumerate(parts):
        for j,part in enumerate(row):
            feasible = all(d['stop_before_band'] for d in part['forecasts'])
            penalty = 0. if feasible else 1000.
            matrix[i][j] -= penalty
            part.update(stop_feasible=bool(feasible),admissible=bool(part['forecast_valid'] and feasible),
                        admissibility_penalty=penalty,utility=matrix[i][j])
    return matrix,parts


class MatrixTurnGameV18(MatrixTurnGameV16):
    revision = 'matrix_entry_v18'
    forecast_revision = 'route_v18'
    controller = 'matrix_v18'
    scorer = staticmethod(score_candidates)
    invalid_mode = 'all_candidates_inadmissible'
    invalid_override_mode = 'admissibility_override'

    def candidate_usable(self,candidate,parts):
        return bool(candidate['solve_ok']) and parts[0]['admissible']
