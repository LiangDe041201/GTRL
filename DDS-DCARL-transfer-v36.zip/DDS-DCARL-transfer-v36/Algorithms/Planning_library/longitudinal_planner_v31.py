"""GTRL may select the original CG proceed plan when its entry is qualified."""
import math
import time

import numpy as np

from Planning_library.cg_trajectory_learning_v29 import CGTrajectoryLearnerV29
from Planning_library.control_path_v15 import path_hash
from Planning_library.rolling_audit_v25 import CandidateAudit
from Planning_library.rolling_planner_v24 import RollingPlannerV24
from Planning_library.rolling_trajectory_v24 import path_cost
from Planning_library.trajectory_probe_v21 import _array_hash, _vehicle
from Planning_library.vehicle_observation import vehicle_id, vehicle_size


class LongitudinalLearnerV31(CGTrajectoryLearnerV29):
    ACTION_NAMES=('cg_default','enter_cg_speed')
    SCHEMA='cg_longitudinal_learning_v31'


def entry_times(states,times,length,width,band_half):
    """Same body-strip and alignment geometry as the v30 merge report."""
    x,y,yaw=states[0],states[1],states[6]
    hx=abs(np.cos(yaw))*length/2+abs(np.sin(yaw))*width/2
    hy=abs(np.sin(yaw))*length/2+abs(np.cos(yaw))*width/2
    overlap=abs(y+138.)<hy+band_half
    angle=abs(np.arctan2(np.sin(yaw-math.pi),np.cos(yaw-math.pi)))
    aligned=overlap & (abs(y+138.)<=band_half) & (x+hx<4.) & (angle<=math.radians(10.))
    first,clear=np.flatnonzero(overlap),np.flatnonzero(aligned)
    return (float(times[first[0]]) if len(first) else None,
            float(times[clear[0]]) if len(clear) else None)


def entry_candidate_permitted(baseline,record,candidate):
    controller=candidate['controller']
    if (baseline!=0 or not record['active'] or record['phase']!='approach' or record['standoff']<=0.
            or controller.geometry_force_stop or controller.geometry_source!='planned'
            or not candidate['solve_ok'] or not math.isfinite(candidate['target']) or candidate['target']<.2):
        return False
    # Reuse the CG game forecasts as a cheap rejection before the execution audit.
    parts=record['components'][1]
    return len(parts)==2 and all(p['admissible'] and (p['min_gap'] is None or p['min_gap']>=.2)
                                for p in parts)


class LongitudinalPlannerV31(RollingPlannerV24):
    EXTRA_CONTROLLERS=0
    ACTION_OFFSETS=(None,None)
    LEARNER_CLASS=LongitudinalLearnerV31
    LEARNER_METADATA=dict(learner_revision=LongitudinalLearnerV31.SCHEMA,baseline_action=0,
        reference_policy='uniform_admissible_v29',action_space='original_cg_or_qualified_proceed_v31',
        cg_intent_and_speed_frozen=False)

    def activate(self,current,chosen):
        # The two existing CG controllers stay owned by the agent.
        if chosen is current or chosen is self._base['controller']:
            return chosen
        raise ValueError('Longitudinal planner can restore only its CG baseline controller')

    def _audit_entry(self,candidate,ego,objects,rv,path,record,previous):
        audit=CandidateAudit(ego,objects,rv,path,previous,self.geometry,self.cruise,
                             record['motion_evidence'].get('acceleration'))
        execution,parts,forecasts=audit.evaluate(candidate)
        for key,value in audit.profile.items(): self._timing[key]+=value
        half=max([vehicle_size(other,'width',1.97) for other in objects] or [1.97])/2.
        crossing=[entry_times(states,times,self.length,self.width,half) for states,times,_ in forecasts]
        started=time.perf_counter()
        road=[self.corridor.audit(states[[0,1,6]].T,self.length,self.width) for states,_,_ in forecasts]
        if candidate['prediction'] is not None:
            road.append(self.corridor.audit(candidate['prediction'][[0,1,6]].T,self.length,self.width))
        self._timing['road_audit_ms']+=(time.perf_counter()-started)*1000.
        eligible=bool(execution['accepted'] and len(road)==3 and all(r['accepted'] for r in road)
                      and all(p['admissible'] and (p['min_gap'] is None or p['min_gap']>=.2) for p in parts)
                      and all(clear is not None for _,clear in crossing))
        return dict(execution=execution,components=parts,road_predictions=road,
                    crossings=[list(t) for t in crossing],eligible=eligible)

    def propose(self,dynamic,candidates,baseline,cg_record,seed,road_right,center):
        started=time.perf_counter(); ego,objects=dynamic.ego_vehicle,dynamic.objects
        original,_,path,context,beta,rv=self._prepare_frame(dynamic,candidates,baseline,cg_record,seed)
        names=('defer','proceed')
        cost=path_cost(path)
        records=[dict(self.description(original,0,names[baseline],path),eligible=True,cost=cost)]
        choices={0:dict(original,path=path)}
        starting_from_hold=ego.v<.2 and original['target']<=.01
        if (starting_from_hold or self.action==1) and entry_candidate_permitted(baseline,cg_record,candidates[1]):
            audit=self._audit_entry(candidates[1],ego,objects,rv,path,cg_record,seed['previous'])
            records.append(dict(self.description(candidates[1],1,'proceed',path),
                cost=cost,source='cg_proceed_reuse',**audit))
            choices[1]=dict(candidates[1],path=path,entry_intent=1)
        allowed=[r['action'] for r in records if r['eligible']]
        key=(baseline,vehicle_id(rv),cg_record['phase'],tuple(allowed))
        # Do not turn an audited entry into repeated start/stop pulses. The
        # option ends at the CG handoff or immediately if its audit fails.
        continuing_entry=self.action==1 and 1 in allowed
        decision=bool(self.engaged and not continuing_entry and
                      (self.action is None or self.age>=self.period-1e-9 or key!=self.control_key))
        costs=[cost,cost]
        if decision:
            self.generation_id+=1
            select_started=time.perf_counter()
            self.learner.begin(context,beta,0,allowed,costs,self.episode_offset+self.local_episode)
            self.action=self.learner.choose(self.epsilon,self.rng)
            self._timing['selection_ms']=(time.perf_counter()-select_started)*1000.
            self.age,self.control_key=0.,key
        action=self.action if self.action in allowed else 0
        request=next(r for r in records if r['action']==action)
        self._base=choices[0]; self._frame_context=(context,beta,costs)
        self.last=dict(self.LEARNER_METADATA,revision='rolling_trajectory_v24',phase=self.phase,
            active=bool(cg_record['active']),road_revision=self.corridor.metadata['revision'],
            execution_revision='isolated_cg_v25',cg_reference_hash=path_hash(self._cg_reference['path']),
            baseline_intent=baseline,baseline_path_hash=path_hash(path),base_candidates=[
                self.description(c,0,names[i],path) for i,c in enumerate(candidates)],
            previous=dict(seed['previous']),warm_hash=_array_hash(seed['warm']),
            observation=dict(ego=_vehicle(ego),others=[_vehicle(v) for v in objects]),
            beta=beta,learning_context=list(context),decision=decision,replanned=decision,
            invalidated=False,generation_id=self.generation_id,candidates=records,allowed=allowed,
            request_id=request['id'],request=dict(request),requested_action=action,actual_action=action,
            changed_request=bool(action),retracted=False,final_reviewed=False,
            disable_foreign_clear_backup=bool(action),
            learning=dict(self.learner.last) if self.engaged else dict(source='inactive'),
            learning_enabled=self.phase=='train',efe_enabled=False,extra_solve_ms=0.,
            decision_ms=(time.perf_counter()-started)*1000.,timing=self._timing)
        output=list(candidates)
        if action: output[baseline]=choices[action]
        return output
