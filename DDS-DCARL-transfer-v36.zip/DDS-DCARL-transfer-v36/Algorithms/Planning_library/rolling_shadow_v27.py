"""Optional EFE diagnostics on the unchanged rolling control/learning chain."""
import json
import time

from Planning_library.rolling_efe_v27 import EFEShadowLedger
from Planning_library.rolling_planner_v24 import RollingPlannerV24


class RollingShadowPlannerV27(RollingPlannerV24):
    def __init__(self,*args,**kwargs):
        self.efe_shadow=EFEShadowLedger()
        super().__init__(*args,**kwargs)
        if self.directory is not None:
            metadata=dict(self.efe_shadow.metadata,model_sha256=self.efe_shadow.model_hash,
                learning_signature=self.learner.signature())
            (self.directory/'efe_shadow_metadata_v27.json').write_text(
                json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf8')

    def _error(self,stage,exc):
        return dict(revision='rolling_efe_shadow_v27',mode='shadow',status='error',
            model_sha256=self.efe_shadow.model_hash,calibrated=False,reward_applied=False,
            error_stage=stage,error_type=type(exc).__name__,error=str(exc),candidates=[],feedback=None)

    def propose(self,*args,**kwargs):
        output=super().propose(*args,**kwargs)
        # The parent has already selected the request. Diagnostics do not call
        # choose(), predictors, solvers or any random-number generator.
        started=time.perf_counter()
        try:
            cg_record=args[3] if len(args)>3 else kwargs['cg_record']
            shadow=self.efe_shadow.propose(self.last,cg_record)
            shadow['status']='ok'
        except Exception as exc:
            # A diagnostic defect is visible to the independent validator but
            # cannot change the baseline drive or its realized experience.
            shadow=self._error('proposal',exc)
        shadow['proposal_ms']=(time.perf_counter()-started)*1000.
        self.last['efe_shadow']=shadow
        return output

    def feedback(self,episode,frame,audit,applied,outcome=None):
        super().feedback(episode,frame,audit,applied,outcome)
        started=time.perf_counter(); shadow=self.last['efe_shadow']
        if shadow['status']=='ok':
            try: self.efe_shadow.feedback(self.last,audit,applied,episode,frame,dt=.05)
            except Exception as exc:
                shadow.update(status='error',error_stage='feedback',error_type=type(exc).__name__,error=str(exc))
        if shadow['status']=='error':
            shadow['feedback']=dict(episode=int(episode),frame=int(frame),owner_action=self.last['actual_action'],
                actual_task_reward=self.last['feedback']['reward'],reward_applied=False,
                available=False,reason='shadow_observer_error',score=None,cost_seconds=None)
        shadow['feedback_ms']=(time.perf_counter()-started)*1000.

    def reset(self):
        super().reset()
        self.efe_shadow.reset()
