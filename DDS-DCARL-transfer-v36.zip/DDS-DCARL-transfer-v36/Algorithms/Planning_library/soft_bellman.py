"""Explicit belief-space, KL-regularized empirical Bellman learning.

Paper IV-B eq.33-37, with an observed-context / finite-hidden-state model.
Trajectory decisions are options: r=sum(gamma**t*r_t), continuation=gamma**n.
Confidence statistics use episode clusters, not correlated individual frames.
Bootstrapped empirical bounds are diagnostics, NOT a Hoeffding guarantee for Q*.
"""
from collections import defaultdict
import json
import math
from pathlib import Path

import numpy as np

from Planning_library.belief_space import probability


def information_cost(policy, prior, alpha):
    p, p0 = probability(policy), probability(prior)
    if p.shape != p0.shape or not math.isfinite(alpha) or alpha <= 0.:
        raise ValueError('Invalid policy dimensions or information cost coefficient')
    active = p > 0.
    if np.any(p0[active] == 0.):
        return float('inf')
    return max(0., float(alpha * np.sum(p[active] * np.log(p[active] / p0[active]))))


def soft_value_policy(q_values, prior, alpha):
    """Eq.33/34, stable log-sum-exp; zero prior support stays impossible."""
    q, p0 = np.asarray(q_values, dtype=float), probability(prior)
    if q.shape != p0.shape or not np.all(np.isfinite(q)) or not math.isfinite(alpha) or alpha <= 0.:
        raise ValueError('Invalid action values or alpha')
    active = p0 > 0.
    peak = float(q[active].max())
    with np.errstate(over='ignore', under='ignore'):
        logits = np.log(p0[active]) + (q[active] - peak) / alpha
    shift = float(logits.max())
    weights = np.exp(logits - shift)
    log_z = shift + math.log(float(weights.sum()))
    pi = np.zeros(len(q))
    pi[active] = weights / weights.sum()
    return peak + alpha * log_z, pi


def baseline_prior(action_count, rule_action, allowed, support_mass=.05):
    """A deterministic baseline needs declared smoothing to allow finite KL.

    support_mass is total uniform mass on safe actions, not exploration epsilon.
    It does not itself authorize a takeover.
    """
    if not 0. < support_mass <= 1.:
        raise ValueError('Baseline support mass must be in (0,1]')
    allowed = sorted(set(int(a) for a in allowed))
    if not allowed or int(rule_action) not in allowed or any(a < 0 or a >= action_count for a in allowed):
        raise ValueError('Baseline action must belong to the admissible action set')
    p0 = np.zeros(action_count)
    p0[allowed] = support_mass / len(allowed)
    p0[int(rule_action)] += 1. - support_mass
    return p0


def bellman_target(reward, continuation_discount, next_q, next_prior, alpha, terminal=False):
    if terminal:
        return float(reward)
    return float(reward) + float(continuation_discount) * soft_value_policy(next_q, next_prior, alpha)[0]


def negative_efe_return_range(preference, w_cognition, w_behavior, gamma):
    """Known conservative range for -EFE returns with no extra reward terms.

    KL(q||p) <= log(1/min p), H(o|s) <= log |O|. Soft V lies between
    min Q and max Q, so this range also bounds recursive continuation targets.
    It does NOT establish independence of bootstrapped samples.
    """
    p = probability(preference)
    weights = (float(w_cognition), float(w_behavior))
    if np.any(p <= 0.) or not 0. < gamma < 1. or any(not math.isfinite(w) or w < 0. for w in weights):
        raise ValueError('Negative-EFE bound needs positive preferences and nonnegative weights')
    return (weights[0] * math.log(1. / float(p.min())) + weights[1] * math.log(len(p))) / (1. - gamma)


class BeliefSoftLearner:
    SCHEMA = 'belief_soft_bellman_v1'
    # Geometry (5), environment (8), presence (1), joint motion observation (10):
    # ego x/y/v/yaw, RV relative x/y/v/yaw/acceleration, committed phase.
    CONTEXT_WIDTHS = (.02, .5, .5, .125, .1, 5., 5., 5., 5., 1., 5., .02, 1., 1.,
                      2., 2., .5, .1, 3., 3., 1., .1, .5, 1.)

    def __init__(self, action_count, gamma=.98, alpha=1., support_mass=.05,
                 belief_resolution=.2, min_episodes=10, significance=.05,
                 range_fallback=3300., out_dir=None, reward_contract='task_ambiguity',
                 filter_contract=None):
        self.action_count, self.gamma, self.alpha = int(action_count), float(gamma), float(alpha)
        self.support_mass, self.belief_resolution = float(support_mass), float(belief_resolution)
        self.min_episodes, self.significance = int(min_episodes), float(significance)
        self.range_fallback = float(range_fallback)
        self.reward_contract = str(reward_contract)
        self.filter_contract = dict(filter_contract or {})
        if (self.action_count < 1 or not 0. < self.gamma < 1. or not math.isfinite(self.alpha) or
                self.alpha <= 0. or not 0. < self.belief_resolution <= 1. or self.min_episodes < 2 or
                not 0. < self.significance < 1. or not math.isfinite(self.range_fallback) or self.range_fallback <= 0.):
            raise ValueError('Invalid belief learner configuration')
        baseline_prior(self.action_count, 0, range(self.action_count), self.support_mass)
        self.nodes, self.q, self.records = {}, {}, []
        self.edges = defaultdict(list)
        self.pending, self.current, self.choice = None, None, None
        self.last = {}
        self.sweeps, self.residual = 0, None
        self.out_dir = Path(out_dir) if out_dir is not None else None
        if self.out_dir is not None:
            self.out_dir.mkdir(parents=True, exist_ok=True)
            if (self.out_dir / 'belief_soft_model.json').is_file():
                self.load()

    def state(self, context, belief, rule_action, allowed):
        context, belief = np.asarray(context, dtype=float), probability(belief)
        if context.shape != (len(self.CONTEXT_WIDTHS),) or not np.all(np.isfinite(context)) or len(belief) != 6:
            raise ValueError('Expected 24 observed context features and six hidden-state probabilities')
        allowed = tuple(sorted(set(int(a) for a in allowed)))
        prior = baseline_prior(self.action_count, rule_action, allowed, self.support_mass)
        key = json.dumps([np.rint(context / self.CONTEXT_WIDTHS).astype(int).tolist(),
                          np.rint(belief / self.belief_resolution).astype(int).tolist(),
                          int(rule_action), list(allowed)], separators=(',', ':'))
        if key not in self.nodes:
            self.nodes[key] = dict(context=context.tolist(), belief=belief.tolist(),
                                   rule=int(rule_action), allowed=list(allowed), prior=prior.tolist())
            self.q[key] = np.zeros(self.action_count)
        return key

    def _close(self, next_key=None):
        p = self.pending
        if p is not None and p['steps'] and not p['forced']:
            record = dict(state=p['state'], action=p['action'], reward=p['reward'],
                          discount=p['discount'], steps=p['steps'], next=next_key,
                          episode=p['episode'], behavior_information_cost=p['information_cost'],
                          belief=p['belief'], context=p['context'],
                          next_belief=self.current_belief.tolist() if next_key is not None else None,
                          next_context=self.current_context.tolist() if next_key is not None else None)
            self.records.append(record)
            self.edges[(record['state'], record['action'])].append(record)
            if self.out_dir is not None:
                with (self.out_dir / 'belief_transitions.jsonl').open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps(record, allow_nan=False) + '\n')
        self.pending = None

    def begin(self, context, belief, rule_action, allowed, episode):
        self.current = self.state(context, belief, rule_action, allowed)
        self.current_belief = probability(belief)
        self.current_context = np.asarray(context, dtype=float)
        self._close(self.current)
        self.episode = int(episode)
        self.choice = None
        # A few synchronous sweeps per decision; full residual is reported at end.
        self.iterate(max_sweeps=3)
        return self.current

    def _targets(self, records, values):
        return [r['reward'] + (0. if r['next'] is None else r['discount'] * values[r['next']])
                for r in records]

    def _cluster_targets(self, records, values):
        by_episode = defaultdict(list)
        for record, target in zip(records, self._targets(records, values)):
            by_episode[record['episode']].append(target)
        return [float(np.mean(samples)) for samples in by_episode.values()]

    def iterate(self, max_sweeps=50, tolerance=1e-6):
        if not self.edges:
            return
        for _ in range(max_sweeps):
            values = {key: soft_value_policy(self.q[key], node['prior'], self.alpha)[0]
                      for key, node in self.nodes.items()}
            updates = {edge: float(np.mean(self._cluster_targets(records, values)))
                       for edge, records in self.edges.items()}
            self.residual = max(abs(self.q[key][a] - value) for (key, a), value in updates.items())
            for (key, a), value in updates.items():
                self.q[key][a] = value
            self.sweeps += 1
            if self.residual <= tolerance:
                break
        values = {key: soft_value_policy(self.q[key], node['prior'], self.alpha)[0]
                  for key, node in self.nodes.items()}
        self.residual = max(abs(self.q[key][a] - float(np.mean(self._cluster_targets(records, values))))
                            for (key, a), records in self.edges.items())

    def confidence(self, key):
        """Episode-clustered empirical target bounds, with explicit bootstrap bias.

        Unlike the paper's independent full trajectory returns, targets contain
        learned continuation values and quantized states. These intervals do not
        certify the theoretical optimal Q or remove model/aggregation error.
        """
        values = {k: soft_value_policy(self.q[k], node['prior'], self.alpha)[0]
                  for k, node in self.nodes.items()}
        groups, all_targets = {}, []
        for a in self.nodes[key]['allowed']:
            records = self.edges.get((key, a), [])
            groups[a] = self._cluster_targets(records, values)
            all_targets.extend(groups[a])
        # Conservative fallback retained from the existing estimator. Empirical
        # extrema are a practical scale estimate, not a known support of Q*.
        scale = max(self.range_fallback, max(all_targets)-min(all_targets)) if all_targets else self.range_fallback
        stats = {}
        for a, samples in groups.items():
            n = len(samples)
            delta = scale * math.sqrt(math.log(1. / self.significance) / (2*n)) if n else float('inf')
            sigma = float(np.std(samples, ddof=1)) if n > 1 else 0.
            mean = float(np.mean(samples)) if samples else 0.
            stats[a] = dict(n=n, mean=mean, wcv=mean-delta-4*sigma/(n+1), bcv=mean+delta)
        return stats

    def select(self, explore_action=None, trust_enabled=True, rng=None):
        if self.current is None:
            raise RuntimeError('Begin a belief decision before selecting an action')
        node, q = self.nodes[self.current], self.q[self.current]
        prior = np.asarray(node['prior'])
        value, optimum = soft_value_policy(q, prior, self.alpha)
        stats, rule = self.confidence(self.current), node['rule']
        certified = [a for a, s in stats.items() if a != rule and
                     s['n'] >= self.min_episodes and stats[rule]['n'] >= self.min_episodes and
                     s['wcv'] > stats[rule]['bcv']]
        eligible = [rule] + (certified if trust_enabled else [])
        policy = np.zeros(self.action_count)
        if explore_action is not None and int(explore_action) in node['allowed']:
            action = int(explore_action)
            policy[action] = 1.
            source = 'explore'
        else:
            # Safety/confidence constraints restrict behavior, while off-policy
            # value iteration uses the full admissible soft Bellman operator.
            restricted = prior.copy()
            restricted[[a for a in range(self.action_count) if a not in eligible]] = 0.
            _, policy = soft_value_policy(q, restricted, self.alpha)
            action = int((rng or np.random).choice(self.action_count, p=policy))
            source = 'takeover' if action != rule else 'rule'
        self.choice = action
        self.last = dict(learning_mode='soft_belief', belief=self.current_belief.tolist(),
                         soft_policy=optimum.tolist(), behavior_policy=policy.tolist(),
                         baseline_policy=prior.tolist(), soft_value=float(value),
                         soft_information_cost=information_cost(optimum, prior, self.alpha),
                         information_cost=information_cost(policy, prior, self.alpha),
                         belief_entropy=float(-np.sum(self.current_belief *
                             np.log(np.maximum(self.current_belief, 1e-300)))),
                         bellman_residual=self.residual, bellman_sweeps=self.sweeps,
                         source=source, q=q.tolist(), samples={a: s['n'] for a, s in stats.items()},
                         certified=certified, confidence_kind='episode_clustered_bootstrap_heuristic')
        indices = [stats[a]['bcv'] if a == rule else stats[a]['wcv'] if a in stats else -1e9
                   for a in range(self.action_count)]
        return action, indices

    def start_action(self, action, forced=False):
        node = self.nodes[self.current]
        if self.choice is None:
            self.select(trust_enabled=False)
            self.last['source'] = 'rule_noRL'
        forced = bool(forced or int(action) != self.choice or int(action) not in node['allowed'])
        if forced:
            self.last['information_cost'] = None
            self.last['behavior_policy'] = None
        self.last['behavior_model_valid'] = not forced
        self.pending = dict(state=self.current, action=int(action), episode=self.episode,
                            reward=0., discount=1., steps=0,
                            belief=self.current_belief.tolist(), context=self.current_context.tolist(),
                            forced=forced,
                            information_cost=self.last['information_cost'])

    def record_reward(self, reward, forced=False):
        if self.pending is None:
            return
        if not math.isfinite(float(reward)):
            raise ValueError('Nonfinite learning reward')
        p = self.pending
        p['reward'] += p['discount'] * float(reward)
        p['discount'] *= self.gamma
        p['steps'] += 1
        p['forced'] = p['forced'] or bool(forced)

    def finish(self):
        self._close(None)  # Terminal V is exactly zero, never the next episode.
        self.iterate()
        self.save()
        self.current, self.choice = None, None

    def signature(self):
        return dict(schema=self.SCHEMA, actions=self.action_count, gamma=self.gamma,
                    alpha=self.alpha, support_mass=self.support_mass,
                    belief_resolution=self.belief_resolution, context_widths=list(self.CONTEXT_WIDTHS),
                    reward_contract=self.reward_contract, filter_contract=self.filter_contract)

    def save(self):
        if self.out_dir is None:
            return
        data = dict(signature=self.signature(), nodes=self.nodes,
                    q={k: v.tolist() for k, v in self.q.items()}, records=self.records,
                    sweeps=self.sweeps, residual=self.residual)
        temporary = self.out_dir / 'belief_soft_model.json.tmp'
        temporary.write_text(json.dumps(data, allow_nan=False), encoding='utf-8')
        temporary.replace(self.out_dir / 'belief_soft_model.json')

    def load(self):
        data = json.loads((self.out_dir / 'belief_soft_model.json').read_text(encoding='utf-8'))
        if data['signature'] != self.signature():
            raise ValueError('Belief learner schema/configuration changed; use a fresh result directory')
        self.nodes, self.records = data['nodes'], data['records']
        self.q = {k: np.asarray(v, dtype=float) for k, v in data['q'].items()}
        self.sweeps, self.residual = data['sweeps'], data['residual']
        self.edges = defaultdict(list)
        for record in self.records:
            self.edges[(record['state'], record['action'])].append(record)
