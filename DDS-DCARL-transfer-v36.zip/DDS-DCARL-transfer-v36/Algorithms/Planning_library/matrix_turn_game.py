"""Observable-state 2x2 entry timing, with public MPC candidates and audit.

Rows are defer/proceed; columns are continue/yield by one identified RV.
The RV columns are hypotheses, never commands to the simulator. Only the ego
best response is executed. Negative ego utility defines the formal RV payoff;
no claim is made that the real traffic policy optimizes it.
"""
import json
import math
from pathlib import Path
import time

import numpy as np

from Planning_library.cournot_game import cournot_decision, expected_payoff_response
from Planning_library.execution_guard import rollout
from Planning_library.paper_turn_control import nearby_vehicles, motion
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration)


def _get(obj, key, default=None):
    return obj.get(key, default) if isinstance(obj, dict) else getattr(obj, key, default)


def _finite(value, default=None):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _angle(value):
    return math.atan2(math.sin(value), math.cos(value))


class MergePhase:
    """Episode-local geometric phase; completion does not require leaving a lane.

    A completed merge is past the local entry point, aligned with the route's
    final lane tangent and close to that lane, for 0.25 simulation seconds.
    This is an explicitly declared detection threshold, not a safety proof.
    """
    def __init__(self):
        self.reset()

    def reset(self):
        self.entered = False
        self.aligned_seconds = 0.
        self.merged = False

    def update(self, ego, standoff, conflict, goal, dt=.05):
        self.entered = self.entered or standoff <= 0.
        if self.entered and goal is not None:
            gx, gy, heading = map(float, goal)
            nx, ny = -math.sin(heading), math.cos(heading)
            lateral = abs((ego.x-gx)*nx+(ego.y-gy)*ny)
            passed = ((ego.x-conflict[0])*math.cos(heading)
                      +(ego.y-conflict[1])*math.sin(heading))
            aligned = (lateral <= .4 and abs(_angle(ego.yaw-heading)) <= math.radians(10.)
                       and passed >= vehicle_size(ego, 'length', 4.5)/2.+1.)
            self.aligned_seconds = self.aligned_seconds+dt if aligned else 0.
            self.merged = self.merged or self.aligned_seconds >= .25-1e-9
        return 'merged' if self.merged else 'merging' if self.entered else 'approach'


def observable_tracks(vehicle, times):
    """CV and at most one second of bounded observed acceleration, as in audit."""
    vx, vy = motion(vehicle)
    speed = math.hypot(vx, vy)
    ux, uy = ((vx/speed, vy/speed) if speed > .05
              else (math.cos(vehicle.yaw), math.sin(vehicle.yaw)))
    measured = longitudinal_acceleration(vehicle)
    accelerations = [0.] if measured is None else [0., max(-3., min(2., measured))]
    result = []
    for acceleration in accelerations:
        track = []
        for t in times:
            active = min(float(t), 1.)
            if acceleration < 0.:
                active = min(active, speed/-acceleration)
            future_speed = max(0., speed+acceleration*active)
            distance = speed*active+.5*acceleration*active**2+future_speed*(t-active)
            track.append((vehicle.x+ux*distance, vehicle.y+uy*distance, vehicle.yaw))
        result.append(np.asarray(track))
    return result


def rv_action_track(rv, objects, times, cruise, yielding):
    """Bounded longitudinal action, with same-corridor following response.

    The public cruise and response limits are model assumptions. They do not
    expose the traffic manager's private labels, sampled intent or commands.
    """
    vx, vy = motion(rv)
    speed = math.hypot(vx, vy)
    ux, uy = ((vx/speed, vy/speed) if speed > .05
              else (math.cos(rv.yaw), math.sin(rv.yaw)))
    length, width = vehicle_size(rv, 'length', 4.), vehicle_size(rv, 'width', 2.)
    leaders = []
    for other in objects:
        if vehicle_id(other) == vehicle_id(rv):
            continue
        dx, dy = other.x-rv.x, other.y-rv.y
        along, across = dx*ux+dy*uy, abs(-dx*uy+dy*ux)
        ovx, ovy = motion(other)
        ov = ovx*ux+ovy*uy
        if along > 0. and across < .5*(width+vehicle_size(other, 'width', 2.)) and ov >= -.1:
            leaders.append((along-.5*(length+vehicle_size(other, 'length', 4.)), max(ov, 0.)))
    position, track = 0., []
    target = min(speed, .3*cruise) if yielding else cruise
    previous_t = 0.
    for t in times:
        duration = float(t)-previous_t
        wanted = max(-2.5, min(2., (target-speed)/max(duration, .05)))
        if leaders:
            gap, front_speed = min(((gap+front_speed*previous_t-position, front_speed)
                                     for gap, front_speed in leaders), key=lambda pair: pair[0])
            if gap < 2.+.5*speed:
                wanted = min(wanted, -min(2.5, max(0., speed-front_speed)+max(0., 2.+.5*speed-gap)))
        next_speed = max(0., speed+wanted*duration)
        next_position = position+.5*(speed+next_speed)*duration
        # An impossible late stop remains a predicted risk. Never teleport or
        # instantaneously zero the RV speed to manufacture a safe payoff cell.
        position, speed = next_position, next_speed
        track.append((rv.x+ux*position, rv.y+uy*position, rv.yaw))
        previous_t = float(t)
    return np.asarray(track)


def _progress(states, path):
    points = np.asarray(path, dtype=float)[:, :2]
    lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    arc = np.r_[0., np.cumsum(lengths)]
    segments = np.diff(points, axis=0)
    def project(point):
        fractions = np.clip(np.sum((point-points[:-1])*segments, axis=1)
                            /np.maximum(lengths**2, 1e-12), 0., 1.)
        distances = np.sum((points[:-1]+fractions[:, None]*segments-point)**2, axis=1)
        i = int(np.argmin(distances))
        return arc[i]+fractions[i]*lengths[i]
    # Endpoint arc progress, not travelled distance or nearest-waypoint jumps.
    return max(0., float(project(states[:2, -1])-project(states[:2, 0])))


def rectangle_gaps(states, ego, other, track):
    """Batch the public four-axis rectangle test without changing its formula."""
    eyaw, oyaw = states[6], track[:, 2]
    axes = np.vstack((eyaw, eyaw+math.pi/2., oyaw, oyaw+math.pi/2.))
    radii = (vehicle_size(ego, 'length', 4.5)/2.*np.abs(np.cos(eyaw-axes))
             + vehicle_size(ego, 'width', 2.)/2.*np.abs(np.sin(eyaw-axes))
             + vehicle_size(other, 'length', 4.)/2.*np.abs(np.cos(oyaw-axes))
             + vehicle_size(other, 'width', 2.)/2.*np.abs(np.sin(oyaw-axes)))
    projections = np.abs((track[:, 0]-states[0])*np.cos(axes)
                         +(track[:, 1]-states[1])*np.sin(axes))
    return np.max(projections-radii, axis=0)


def score_candidates(ego, objects, rv, candidates, geometry, path, previous, cruise):
    """Four cells from two fixed ego candidates; no column-dependent ego solve."""
    matrix, components = [], []
    threats = nearby_vehicles(objects, ego, limit=None)
    for candidate in candidates:
        target, a, delta = candidate['target'], candidate['a'], candidate['delta']
        plans = [rollout(ego, path, target, a, delta, previous, geometry,
                        horizon=6., lag=lag, plan=candidate.get('plan'),
                        plan_times=candidate.get('times')) for lag in (0., .4)]
        representative, times = plans[-1]
        checked_plans = list(plans)
        if candidate.get('prediction') is not None:
            checked_plans.append((candidate['prediction'], candidate['times']))
        duration = float(times[-1])
        progress = _progress(representative, path)/max(4.*duration, 1.)
        stopped = float(np.mean(representative[5] < .1))
        body_acc = np.diff(representative[5])/np.diff(times)
        jerk = np.diff(body_acc)/np.diff(times)[1:]
        comfort = float(np.mean(np.minimum((jerk/3.)**2, 25.))) if len(jerk) else 0.
        row, parts = [], []
        for yielding in (False, True):
            risk, minimum = 0., float('inf')
            for other in threats:
                primary = rv is not None and vehicle_id(other) == vehicle_id(rv)
                actor_risk, actor_min = 0., float('inf')
                for states, forecast_times in checked_plans:
                    tracks = ([rv_action_track(other, objects, forecast_times, cruise, yielding)] if primary
                              else observable_tracks(other, forecast_times))
                    for track in tracks:
                        gaps = rectangle_gaps(states, ego, other, track)
                        deficit = np.maximum((.5-gaps)/.5, 0.)
                        actor_risk = max(actor_risk, float(np.mean(deficit**2)+np.max(deficit**2)))
                        actor_min = min(actor_min, float(np.min(gaps)))
                risk += actor_risk
                minimum = min(minimum, actor_min)
            utility = progress-.25*stopped-.05*comfort-4.*risk
            if not candidate.get('solve_ok', False):
                utility -= 1000.
            row.append(float(utility))
            parts.append(dict(progress=progress, stopped_fraction=stopped, comfort=comfort,
                              risk=risk, min_gap=None if math.isinf(minimum) else minimum,
                              utility=float(utility)))
        matrix.append(row)
        components.append(parts)
    return matrix, components


class MatrixTurnGame:
    """Entry authority plus transparent expected-response payoffs.

    The same final execution guard is still called by the production driver.
    The legacy arm retains the old payoff expression, but shares the repaired
    control interface, observations and public execution constraints.
    """
    revision = 'matrix_entry_v13'

    def __init__(self, geometry, cruise=4.412022451715821, legacy=False, directory=None):
        self.geometry, self.cruise = dict(geometry), float(cruise)
        self.legacy = bool(legacy)
        self.directory = None if directory is None else Path(directory)
        self.phase = MergePhase()
        self.reset()

    def reset(self):
        self.phase.reset()
        self.last_action = None
        self.last_rv = None
        self.last = {}

    def prepare(self, ego, objects, conf, nominal, standoff, goal):
        conflict = (float(conf.get('conflict_x', 4.)), float(conf.get('conflict_y', -138.)))
        phase = self.phase.update(ego, standoff, conflict, goal)
        threats = nearby_vehicles(objects, ego, limit=None)
        rv = next((v for v in threats if vehicle_id(v) == vehicle_id(conf.get('rv_veh'))), None)
        incoming = [v for v in threats if v.x+vehicle_size(v, 'length', 4.)/2. > conflict[0]
                    and motion(v)[0] < -.1]
        if rv is None and incoming:
            rv = min(incoming, key=lambda v: max(0., v.x-conflict[0])/max(v.v, .1))
        active = phase == 'approach' and standoff <= 18. and rv is not None and nominal > .01
        p, evidence = self.yield_probability(rv, threats)
        if not active:
            deferred = nominal
        elif self.legacy:
            deferred = 0.
        else:
            vx, _ = motion(rv)
            release_time = max(0., (rv.x+vehicle_size(rv, 'length', 4.)/2.-conflict[0])
                               /max(abs(vx), .5))+.8
            # Arrive behind this RV with a feasible rolling approach; at the
            # stand-off line this becomes a stop, not a forced-entry timeout.
            deferred = min(nominal, max(0., standoff-2.)/max(release_time, .5))
        self.last = dict(revision=self.revision, controller='matrix_legacy' if self.legacy else 'matrix_v13',
            active=bool(active), phase=phase, standoff=float(standoff), rv_id=vehicle_id(rv),
            p_yield=p, probability_source=evidence, nominal=float(nominal),
            targets=[float(deferred), float(nominal)], authority='matrix_entry',
            payoff_matrix=None, rv_payoff_matrix=None, components=None, selected=1,
            decision_mode='inactive', pure_nash=None, switch=False)
        return rv, self.last['targets']

    def yield_probability(self, rv, objects):
        if rv is None:
            return .5, 'no_rv'
        acc = longitudinal_acceleration(rv)
        if acc is None:
            return .5, 'unavailable_motion_neutral_prior'
        vx, vy = motion(rv)
        speed = math.hypot(vx, vy)
        if speed < .05:
            return .5, 'stopped_cause_unknown'
        ux, uy = vx/speed, vy/speed
        for front in objects:
            if vehicle_id(front) == vehicle_id(rv):
                continue
            dx, dy = front.x-rv.x, front.y-rv.y
            along, across = dx*ux+dy*uy, abs(-dx*uy+dy*ux)
            fv = sum(a*b for a, b in zip(motion(front), (ux, uy)))
            gap = along-.5*(vehicle_size(rv, 'length', 4.)+vehicle_size(front, 'length', 4.))
            if (along > 0. and across < .5*(vehicle_size(rv, 'width', 2.)+vehicle_size(front, 'width', 2.))
                    and gap < 2.+.5*speed+1. and fv < speed+.2):
                return .5, 'following_brake_not_yield_evidence'
        # Fixed, declared motion proxy, not a calibrated intent posterior.
        p = .5-.3*math.tanh(acc/.8)
        return max(.2, min(.8, p)), 'bounded_observed_acceleration_proxy'

    def choose(self, ego, objects, rv, conf, candidates, path, previous):
        started = time.perf_counter()
        if not self.last['active']:
            selected = 1
        else:
            matrix, parts = score_candidates(ego, objects, rv, candidates, self.geometry,
                                            path, previous, self.cruise)
            if self.legacy:
                old = cournot_decision(max(0., float(conf.get('arc_to_cross', 0.))),
                    max(0., rv.x-float(conf.get('conflict_x', 4.))),
                    v_go=max(candidates[1]['target'], .1), p_yield=self.last['p_yield'],
                    v_ref=self.last['nominal'], thw_rv=conf.get('thw_boundary_rv'),
                    thw_fv=conf.get('thw_boundary_fv'), jerk=0., steer=0.)
                matrix = old['payoff_matrix']
            result = expected_payoff_response(matrix, self.last['p_yield'])
            selected = result['ego_action']
            if not any(c['solve_ok'] for c in candidates):
                selected = 0
                result['decision_mode'] = 'all_candidates_failed'
            elif not candidates[selected]['solve_ok'] and candidates[1-selected]['solve_ok']:
                selected = 1-selected
                result['decision_mode'] = 'optimizer_failure_override'
            self.last.update(result, components=parts, selected=selected,
                switch=self.last_action is not None and self.last_action != selected)
        self.last_action = selected if self.last['active'] else None
        self.last.update(selected=selected, decision_ms=(time.perf_counter()-started)*1000.,
            candidate_targets=[c['target'] for c in candidates],
            candidate_a=[c['a'] for c in candidates], candidate_delta=[c['delta'] for c in candidates],
            candidate_solve_ok=[bool(c['solve_ok']) for c in candidates])
        return selected

    def record(self, episode, frame, selected_a, selected_delta, selected_target, audit, applied):
        if self.directory is None:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        row = dict(self.last, episode=int(episode), frame=int(frame),
            pre_audit_a=float(selected_a), pre_audit_delta=float(selected_delta),
            pre_audit_target=float(selected_target), guard_action=audit['action'],
            guard_override=bool(audit['override']), guard_safe=bool(audit['safe']),
            applied_a=float(applied['a_cmd']), applied_delta=float(applied['delta_rad']),
            applied_target=float(applied['actuator_speed_target']),
            control_submit_ok=int(applied['control_submit_ok']))
        with (self.directory/'matrix_decisions.jsonl').open('a', encoding='utf8') as stream:
            stream.write(json.dumps(row, allow_nan=False)+'\n')


def solve_candidates(primary, alternate, dynamic_map, nominal, deferred, road_right, center, active):
    """Two independent solves from the same applied-control/warm-start state.

    Return order is defer/proceed, matching matrix rows. Both solvers receive
    the actual applied control after execution; neither imaginary RV column
    changes a candidate's ego controls.
    """
    previous = dict(primary.last_u)
    if active:
        alternate.reset_global_path(primary.last_pathway, dynamic_map)
        # A recovered path is clean geometry, but it is still a recovery path.
        # Preserve its speed/stop provenance when the selected solver changes.
        alternate.geometry_source = primary.geometry_source
        alternate.geometry_force_stop = primary.geometry_force_stop
        alternate.last_u = dict(previous)
        alternate._previous_observed_speed = primary._previous_observed_speed
        warm = primary._warm_controls
        alternate._warm_controls = None if warm is None else warm.copy()
    candidates = []
    for controller, target in ((primary, nominal), (alternate, deferred)):
        if controller is alternate and not active:
            candidates.append(candidates[0])
            break
        controller.set_game_context({}, dynamic_map.ego_vehicle)
        a, delta = controller.solve(dynamic_map, target, road_right, intersection_center=center)
        candidates.append(dict(controller=controller, target=float(target), a=float(a), delta=float(delta),
            solve_ok=bool(controller._solve_ok), prediction=controller.last_prediction,
            plan=controller.last_control_plan if controller._solve_ok else None,
            times=controller.prediction_times))
    return [candidates[1], candidates[0]]
