#!/usr/bin/env python3
"""
二维边界安全评估模块（对标论文 ADVEI-D-26-08155 的式 3-7，创新点④）

在交叉口左转博弈中，"到冲突点的点/径向 TTC"无法度量两车车身边界的真实
危险距离。本模块用矩形车身 + 分离轴定理(SAT) 计算真实边界距离 d_AB，
并据此定义：

  d_AB        自车车身矩形 与 他车车身矩形 的最短边界距离（m）
              重叠时 <= 0（负穿透深度近似），否则 > 0
  d_AB_dot    d_AB 对时间的导数（m/s），由预测轨迹有限差分得到，<0 表示在接近
  TTC_boundary -d_AB / d_AB_dot，d_AB_dot<0（逼近中）时有限，否则 +inf
  THW_boundary d_AB / v_ego，以自车当前速度到达边界所需时间（s）
  LCTTC       预测时域内所有 TTC_boundary 的最小值（最危险瞬间）

用途（后续 Phase 接线点）:
  - crossing_conflict_detail() 增加 ttc_boundary / thw_boundary / lcttc 字段
  - DCARL 因果奖励的安全项替换点/加权点
  - Cournot 博弈支付矩阵的 U_safe(THW_boundary) 项
  - LaneTrajectoryPlanner 中被注释的 check_paths 矩形轨迹过滤

本文件纯 numpy/math，无 CARLA 依赖，可离线单测。
"""
import math
import os
import numpy as np

from Agent.tools_dds.rectangle_tools import Rectangle_SAT, Point


# ============================================================
# 1. 矩形间最短距离（精确解，无需采样）
# ============================================================

def _point_segment_dist(px, py, ax, ay, bx, by):
    """点 (px,py) 到线段 AB 的最短距离"""
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    c1 = vx * wx + vy * wy
    if c1 <= 0.0:
        return math.hypot(px - ax, py - ay)
    c2 = vx * vx + vy * vy
    if c2 <= 1e-12:
        return math.hypot(px - ax, py - ay)
    t = c1 / c2
    if t >= 1.0:
        return math.hypot(px - bx, py - by)
    return math.hypot(px - (ax + t * vx), py - (ay + t * vy))


def _closest_pt_on_segment(px, py, ax, ay, bx, by):
    """点 P 到线段 AB 的最近点坐标 及 距离。返回 (dist, (cpx, cpy))。"""
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    c1 = vx * wx + vy * wy
    c2 = vx * vx + vy * vy
    if c1 <= 0.0:
        return math.hypot(px - ax, py - ay), (ax, ay)
    if c2 <= 1e-12:
        return math.hypot(px - ax, py - ay), (ax, ay)
    t = c1 / c2
    if t >= 1.0:
        return math.hypot(px - bx, py - by), (bx, by)
    cx, cy = ax + t * vx, ay + t * vy
    return math.hypot(px - cx, py - cy), (cx, cy)


def closest_boundary_points(rect_a, rect_b):
    """
    两矩形间最短边界距离 + **最近点对（危险点）**。
    返回 dict:
      d        最短边界距离（>0 分离；重叠/相切=0）
      pa       rect_a 上最近点坐标 (x,y)（重叠时 None）
      pb       rect_b 上最近点坐标 (x,y)（重叠时 None）
    这对应论文④"从车辆中搜索危险点 → 匹配到 ego 车"的那组角点/边最近点。
    """
    if Rectangle_SAT.rectangles_intersect(rect_a, rect_b):
        return {'d': 0.0, 'pa': None, 'pb': None}
    ca, cb = rect_a.corners, rect_b.corners
    best = (float('inf'), None, None)
    # A 每条边 -> B 每个顶点（最近点可能是 B 的角点或 A 边上投影点）
    for i in range(4):
        ax, ay = ca[i].x, ca[i].y
        bx, by = ca[(i + 1) % 4].x, ca[(i + 1) % 4].y
        for p in cb:
            dist, (cxp, cyp) = _closest_pt_on_segment(p.x, p.y, ax, ay, bx, by)
            if dist < best[0]:
                best = (dist, (cxp, cyp), (p.x, p.y))
    # B 每条边 -> A 每个顶点
    for i in range(4):
        ax, ay = cb[i].x, cb[i].y
        bx, by = cb[(i + 1) % 4].x, cb[(i + 1) % 4].y
        for p in ca:
            dist, (cxp, cyp) = _closest_pt_on_segment(p.x, p.y, ax, ay, bx, by)
            if dist < best[0]:
                best = (dist, (p.x, p.y), (cxp, cyp))
    return {'d': best[0], 'pa': best[1], 'pb': best[2]}


def rect_distance(rect_a, rect_b):
    """
    两个旋转矩形的最短边界距离（精确）：
      >0 分离；==0 相切/重叠（用 SAT 判定重叠则直接 0）。
    凸多边形最小距离必然出现在"顶点-边"或"顶点-顶点"之间，穷举即可。
    """
    return closest_boundary_points(rect_a, rect_b)['d']


def signed_rect_distance(rect_a, rect_b):
    """
    带符号的边界距离：分离 >0；重叠 <=0（用负的粗略穿透量表达，便于 TTC 计算）。
    """
    d = rect_distance(rect_a, rect_b)
    if d > 0.0:
        return d
    # 重叠：给一个小的负值（量级=沿 x 方向的重叠长度，近似足够）
    return -min(rect_a.width, rect_b.width) * 0.5


def make_rect(x, y, yaw, length=4.5, width=2.0):
    """由 (x, y, 航向角, 长, 宽) 构造车身矩形"""
    return Rectangle_SAT(Point(x, y), length, width, yaw)


# ============================================================
# 2. 边界度量：d_AB / d_AB_dot / TTC_boundary / THW_boundary
# ============================================================

def boundary_metrics(ego_x, ego_y, ego_yaw, ego_v,
                     veh_x, veh_y, veh_yaw, veh_v,
                     dt=0.1, ego_len=4.5, ego_wid=2.0,
                     veh_len=4.0, veh_wid=2.0, thw_mode='conn'):
    """
    计算当前与下一预测时刻的边界距离，用有限差分求 d_AB_dot，
    输出 (d_ab, d_ab_dot, ttc_boundary, thw_boundary)。

    匀速预测：t 时刻位置 = 当前 + v*(cos,sin)*t（两车均保持当前航向与速度）。

    THW_boundary（论文式6/7）：`d_AB / (v_A·n⃗)`。论文式7 取 n⃗ = 车 A 航向的法向
    （换道场景即"侧向"，v_A·n 为侧向速度）。**左转场景该法向退化**（自车速度基本沿
    航向 → v·n≈0 → THW→∞ 失效），故默认 thw_mode='conn'：取式3 最近点对连线方向
    n⃗=(pb−pa)/|pb−pa| 作为一般化——换道时二者一致，左转时即"接近方向"。
    thw_mode='raw' 为旧的 d_AB/|v|（不投影，仅作对照）。
    """
    rect_ego = make_rect(ego_x, ego_y, ego_yaw, ego_len, ego_wid)
    rect_veh = make_rect(veh_x, veh_y, veh_yaw, veh_len, veh_wid)
    # 当前帧最近点对（危险点）：d>0 时 pa/pb 为两车边界上最先逼近的几何位置
    cp0 = closest_boundary_points(rect_ego, rect_veh)
    d0 = cp0['d'] if cp0['d'] > 0.0 else -min(rect_ego.width, rect_veh.width) * 0.5

    ex1 = ego_x + ego_v * math.cos(ego_yaw) * dt
    ey1 = ego_y + ego_v * math.sin(ego_yaw) * dt
    vx1 = veh_x + veh_v * math.cos(veh_yaw) * dt
    vy1 = veh_y + veh_v * math.sin(veh_yaw) * dt
    rect_ego1 = make_rect(ex1, ey1, ego_yaw, ego_len, ego_wid)
    rect_veh1 = make_rect(vx1, vy1, veh_yaw, veh_len, veh_wid)
    d1 = signed_rect_distance(rect_ego1, rect_veh1)

    d_ab = float(d0)
    d_dot = float((d1 - d0) / max(dt, 1e-6))

    # TTC_boundary：只在逼近时有限
    if d_dot < -1e-6:
        ttc_boundary = -d_ab / d_dot if d_ab > 0.0 else 0.0
    else:
        ttc_boundary = float('inf')

    # THW_boundary（式6/7）：分母用「接近速度」v_A·n，而不是总速度 |v_A|
    #   ⚠️ 论文式7 的 n⃗ 是"车 A 航向的法向"；换道时=侧向，v_A·n 有意义。
    #   本场景是**交叉式接近**（ego 朝南、RV 在其东侧横向驶来），此时"最近点连线方向"
    #   与 ego 速度近似垂直 → v_A·n≈0 → 严格式会退化为 ∞（指标失效）。
    #   故采用：**投影优先，投影≤0 时回退到 d_AB/|v_A|**，保证 THW 始终有限且仍是安全裕度。
    thw_boundary = float('inf')
    if d_ab > 0.0:
        thw_raw = d_ab / max(ego_v, 1e-3)
        if thw_mode == 'raw':
            thw_boundary = thw_raw
        else:
            _v_close = None
            if cp0['pa'] is not None and cp0['pb'] is not None:
                _nx = float(cp0['pb'][0] - cp0['pa'][0])
                _ny = float(cp0['pb'][1] - cp0['pa'][1])
                _nn = math.hypot(_nx, _ny)
                if _nn > 1e-6:
                    _v_close = (ego_v * math.cos(ego_yaw)) * (_nx / _nn) + \
                               (ego_v * math.sin(ego_yaw)) * (_ny / _nn)
            thw_boundary = (d_ab / _v_close) if (_v_close is not None and _v_close > 1e-6) else thw_raw
    else:
        thw_boundary = 0.0          # 两车边界已重叠 → THW=0（碰撞）

    return {'d_ab': d_ab, 'd_ab_dot': d_dot,
            'ttc_boundary': ttc_boundary, 'thw_boundary': thw_boundary,
            # 【④ 危险点识别】两车边界上最先逼近的最远点对（重叠时 None）
            'danger_pt_ego': cp0['pa'], 'danger_pt_veh': cp0['pb']}


def lcttc_over_horizon(ego_x, ego_y, ego_yaw, ego_v,
                       veh_x, veh_y, veh_yaw, veh_v,
                       horizon=3.0, dt=0.1, ego_len=4.5, ego_wid=2.0,
                       veh_len=4.0, veh_wid=2.0):
    """
    预测时域内最小边界 TTC（LCTTC）与最小边界距离。

    返回 dict:
      lcttc       min TTC_boundary（无逼近则为 inf）
      lcttc_t     对应时刻
      min_d_ab    时域内最小边界距离
      ttc_seq     各步 TTC_boundary 序列
    """
    ttc_seq = []
    d_seq = []
    n = max(1, int(round(horizon / max(dt, 1e-6))))
    for k in range(n + 1):
        t = k * dt
        ex = ego_x + ego_v * math.cos(ego_yaw) * t
        ey = ego_y + ego_v * math.sin(ego_yaw) * t
        vx = veh_x + veh_v * math.cos(veh_yaw) * t
        vy = veh_y + veh_v * math.sin(veh_yaw) * t
        m = boundary_metrics(ex, ey, ego_yaw, ego_v,
                             vx, vy, veh_yaw, veh_v,
                             dt=dt, ego_len=ego_len, ego_wid=ego_wid,
                             veh_len=veh_len, veh_wid=veh_wid)
        d_seq.append(m['d_ab'])
        ttc_seq.append(m['ttc_boundary'])
    lcttc = min(ttc_seq)
    return {'lcttc': float(lcttc),
            'lcttc_t': float(ttc_seq.index(lcttc) * dt),
            'min_d_ab': float(min(d_seq)),
            'ttc_seq': ttc_seq,
            'd_seq': d_seq}


# ============================================================
# 2b.【创新点④】边界安全的"保守确定性策略"门（动作屏蔽）
# ============================================================
#: 触发屏蔽的 LCTTC 阈值（s）。论文 ④ 定义边界模型 TTC/THW_boundary；
#: 论文 §IV 明确：对手意图不确定时"提高触发**保守确定性策略**的概率"。
#: 这里把"保守确定性策略"落到动作空间上，分**两档**（见 boundary_shield_mask）。
SHIELD_LCTTC_DEFAULT = 0.8
#: 【第二档·临界】LCTTC 低于它 ⇒ 只允许最慢档（全力刹车）。
#: 为什么必须分两档：`lcttc=0.005s` 时"只禁止加速"仍会放行 2.0 m/s 的**滑行**，
#: 而 5 ms 的边界 TTC 已经没有滑行余地了（实测 expF_paper100 回合 5 帧 214~220
#: 就是 ego_v≈2.8 m/s 一路滑到撞上）。
SHIELD_LCTTC_CRITICAL = 0.3
#: 【P4-⓪b】THW 档阈值（s）：用**抢行最坏情况 THW** 取代 lcttc 作触发量。
#:   lcttc 是"物理边界距离/接近速度"，只有贴上才变小 ⇒ 实测碰撞前 10 帧 95% 已在刹车
#:   却仍撞（无提前量），同时占 39% 的帧（又太频繁）。worst-case THW 以秒为单位、
#:   把"对手恢复巡航"也算进去 ⇒ 既有提前量、又只在真有近期冲突时触发。
SHIELD_THW_DEFAULT = 1.5           # 一级：低于它 → 只允许"不加速"
SHIELD_THW_CRITICAL_DEFAULT = 0.6  # 二级：低于它 → 只允许最慢档（刹车）
#: 第一档允许的速度余量（m/s）：候选档位 <= ego_v + margin 才算"不加速"。
#: 默认 0.0 = **目标速度不得超过当前速度**（严格不加速）。
SHIELD_RELEASE_MARGIN = 0.0


def boundary_shield_active(lcttc_rv, thw_boundary_rv, committed,
                           shield_lcttc=SHIELD_LCTTC_DEFAULT,
                           shield_thw=SHIELD_THW_DEFAULT):
    """④ 边界安全是否处于"危险"状态（需要保守确定性策略）。

    危险 ⟺ 自车**尚未越过冲突点**(not committed)
            且 (LCTTC_rv < shield_lcttc 或 THW_boundary_rv < shield_thw)

    · `committed=True`（已越过冲突点）不屏蔽 —— 此时"加速驶离路口"才是正确的
      保守动作（论文把 game 结束判定放在 ego 质心是否越过车道线，同理）。
    · 非有限（inf/nan，表示"无 RV / 无逼近"）一律**不危险**：不能因为"没测到"
      就锁死自车（这与 P1-f 的"没测到 != 满分"是对称的）。
    """
    if committed:
        return False
    try:
        lc = float('inf') if lcttc_rv is None else float(lcttc_rv)
    except (TypeError, ValueError):
        lc = float('inf')
    try:
        th = float('inf') if thw_boundary_rv is None else float(thw_boundary_rv)
    except (TypeError, ValueError):
        th = float('inf')
    if math.isfinite(lc) and lc < float(shield_lcttc):
        return True
    if float(shield_thw) > 0.0 and math.isfinite(th) and th < float(shield_thw):
        return True
    return False


def boundary_shield_mask(speeds, lcttc_rv, thw_boundary_rv, committed, ego_v,
                         shield_lcttc=SHIELD_LCTTC_DEFAULT,
                         shield_thw=SHIELD_THW_DEFAULT,
                         release_margin=SHIELD_RELEASE_MARGIN,
                         shield_lcttc_critical=SHIELD_LCTTC_CRITICAL,
                         shield_thw_critical=SHIELD_THW_CRITICAL_DEFAULT):
    """④ 动作屏蔽：返回与 `speeds` 等长的 bool 表，True = 该档位允许执行。

    两档"保守确定性策略"（论文 §IV 的 conservative deterministic strategy）：
      · 非危险                        → 全 True
      · 第一档 `lcttc < 0.8s`         → 只允许 `speed <= ego_v + release_margin`
                                        （默认严格不加速：目标速度不得超过当前速度）
      · 第二档 `lcttc < 0.3s`（临界） → **只允许最慢档**（全力刹车）
    并保证**至少保留一个**允许档位，否则自车无路可走。

    为什么不做成"靠 RL 自己学不加速"：实测 expF_paper100 在 `lcttc_rv < 1.0s` 的
    1491 帧里有 1240 帧（83%）最终动作不是刹车 —— RL 没有、也不该被指望学会这条硬约束。
    RL 仍在允许集合内做博弈选择（EFE 逐动作比较、WCV 接管都作用在允许集合上）。
    """
    speeds = [float(s) for s in speeds]
    if not speeds:
        return []
    if not boundary_shield_active(lcttc_rv, thw_boundary_rv, committed,
                                  shield_lcttc=shield_lcttc, shield_thw=shield_thw):
        return [True] * len(speeds)
    _vmin = min(float(s) for s in speeds)
    # ---- 第二档：临界 → 只剩全力刹车 ----
    try:
        lc = float('inf') if lcttc_rv is None else float(lcttc_rv)
    except (TypeError, ValueError):
        lc = float('inf')
    try:
        th = float('inf') if thw_boundary_rv is None else float(thw_boundary_rv)
    except (TypeError, ValueError):
        th = float('inf')
    _crit = (math.isfinite(lc) and lc < float(shield_lcttc_critical)) or \
            (float(shield_thw_critical) > 0.0 and math.isfinite(th)
             and th < float(shield_thw_critical))
    if _crit:
        # ⚠ 这里曾经是 `allowed[_slowest] = True`（只放行**最慢档里序号最小**的那个）。
        #   在"动作 = 速度档"的空间里这是对的；换成 2d 动作空间
        #   （`a = i_speed*3 + i_lat`，i_lat=0 即 di=-1.5 m）后，它退化成
        #   "只放行 index 0 = 刹停 + 向左切 1.5 m" —— 屏蔽层于是每个屏蔽帧都在打方向。
        #   本函数对速度是**分层**的，正确语义是放行**整个最慢速度层**；
        #   横向由调用方（`shield_fallback_action`）保留策略自己的选择。
        #   （实测 expKK_2d_100：shield 帧 5669/5669 全是 action 0，占全部帧 46%。）
        return [float(s) <= _vmin + 1e-9 for s in speeds]
    # ---- 第一档：只允许不加速 ----
    v = max(float(ego_v), 0.0)
    allowed = [(s <= v + float(release_margin)) for s in speeds]
    if not any(allowed):
        # 理论上不会发生（最慢档 0 <= v），兜底：保留最慢速度层
        allowed = [float(s) <= _vmin + 1e-9 for s in speeds]
    return allowed


# ============================================================
# 2c.【创新点④·P3】进入冲突区的清空时间与"能否安全插入"判据
# ============================================================
#: 交叉车流横向带宽度（m）：自车必须**整车穿过**这条带才算清空。
#: 实测该场景直行车体带宽约 2 m（单车道、车宽 2 m），另加车道余量取 4 m。
CLEAR_BAND_DEFAULT = 4.0
#: 安全余量（s）：论文 §VI-A 用"LCV 进入 Area A 所需时间"做判据，此处额外留时间余量。
CLEAR_MARGIN_DEFAULT = 1.0


#: 【§54】转弯中的**实际可行**纵向加速度（m/s²）。
#:   为什么需要它：旧判据 `_t_ego_go = arc/_go_speed`、`_clr_go=(车长+带宽)/_go_speed`
#:   都假设自车**全程恒定 `_go_speed`（实测代码里 `_go_speed = max(4.0, ...)`）**。
#:   而真实自车是**从等待线静止起步、在 90° 转弯中缓慢加速**（实测转弯中
#:   `ego_v` 中位仅 1.46 m/s）⇒ 旧式把清空时间低估约 2~3 倍。
GO_ACCEL_DEFAULT = 1.2
#: 【§54】转弯中可达速度上限（m/s）
GO_VMAX_DEFAULT = 3.0


def _time_to_cover(s, v0, v_max, a):
    """匀加速到 `v_max` 后匀速，走完距离 `s` 所需时间（s）。"""
    s = max(float(s), 0.0)
    if s <= 0.0:
        return 0.0
    v0 = max(float(v0), 0.0)
    v_max = max(float(v_max), v0)
    a = max(float(a), 1e-3)
    d_acc = (v_max * v_max - v0 * v0) / (2.0 * a)
    if d_acc >= s:
        return (-v0 + math.sqrt(v0 * v0 + 2.0 * a * s)) / a
    return (v_max - v0) / a + (s - d_acc) / max(v_max, 1e-3)


def required_clearance(d_to_conflict, v0, ego_len=4.5, band=CLEAR_BAND_DEFAULT,
                       v_max=GO_VMAX_DEFAULT, a_go=GO_ACCEL_DEFAULT,
                       margin=CLEAR_MARGIN_DEFAULT, dt_lag=0.0):
    """【§54】基于**真实运动**的 (到达时间, 占用冲突区时长)。

    为什么必须换掉旧式（实测依据，见 §53.3）：
      闩锁修复后的碰撞帧全部满足 `committing=1`（**合法承诺**）且 `gap_ok=0`
      ⇒ 自车是"完全合法地承诺进入的"，只是**当初批准它进入的间隙没有维持到穿越结束**。
      根因：旧判据用恒定 `_go_speed≥4.0 m/s` 估清空时间（3.125 s），而自车实际从
      静止起步、转弯中只有 ~1.46 m/s ⇒ **清空时间被低估约 2~3 倍** ⇒
      `entry_gap_is_safe` 把"插不进去"判成"能过"。

    与旧式的区别：
      · 旧 `t_arrive = arc / v_go`（恒定速度，且 `v_go≥4.0`）
      · 旧 `my_clearance = (ego_len+band)/v_go + margin`（按 v_go 穿越，而不是按
        到达时的**实际速度**）
      · 新：从**当前速度 v0** 匀加速到 `v_max`，含执行滞后 `dt_lag`；
        穿越段的初速度用**到达冲突点时的实际速度** `v_arr`。

    返回 `(t_arrive, t_clear_duration)`，语义与 `entry_gap_is_safe`
    的 `t_ego_go` / `my_clearance` 完全一致（占用窗 = [t_arrive, t_arrive+t_clear]）。
    """
    d = max(float(d_to_conflict), 0.0)
    v0 = max(float(v0), 0.0)
    a = max(float(a_go), 1e-3)
    t_arr = _time_to_cover(d, v0, v_max, a) + float(dt_lag)
    v_arr = min(float(v_max), math.sqrt(v0 * v0 + 2.0 * a * d))
    t_cross = _time_to_cover(float(ego_len) + float(band), v_arr, v_max, a)
    return t_arr, t_cross + float(margin)


def required_clearance_from_standoff(standoff, v0, ego_len=4.5, band=CLEAR_BAND_DEFAULT,
                                     v_max=GO_VMAX_DEFAULT, a_go=GO_ACCEL_DEFAULT,
                                     margin=CLEAR_MARGIN_DEFAULT, dt_lag=0.0):
    """【§54b 关键修复】用**车头到交叉带北边缘的净空**锚定占用窗。

    为什么必须这样锚定（实测反证，见 §54）：
      旧式（含 §54 的"真实运动"版）都用 `arc_to_cross`（到**冲突点**的距离）算：
          `t_ego_go = 时间(arc 走完)`，占用窗 = `[t_ego_go, t_ego_go + t_cross]`。
      问题：自车**蹭得越慢 ⇒ `t_ego_go` 越大 ⇒ 评估的窗口越靠未来** ⇒ 带里当前的车
      "已经过去了" ⇒ **判据必然判"安全"**。实测铁证：
        · `expS86_REAL_ON` 把 `t_ego_go` 中位从 3.38 调到 **5.83**，
          结果 `gap_ok` 占比从 **36.6% 膨胀到 79.3%**（判据变得**更宽松**）；
        · 碰撞帧 `gap_ok = 1.0`（判据说安全）而 `wait_standoff = −0.04 ~ −2.40`
          （**车头已经在带内**）。
      ⇒ **"慢"会让判据变宽松，是一个方向相反的激励**，与安全目标完全相反。

    正确锚定：
      · `t_enter` = 车头**抵达带北边缘**的时间；若车头已在带内（`standoff ≤ 0`）则 **= 0**
        （占用从"现在"开始，当前带内的车必然造成冲突 ⇒ `gap_ok=False`）。
      · 穿越段初速度 = 抵达带边缘时的实际速度。
    这样"蹭进带内"会**立刻**让判据变严，而不是变松。
    """
    sd = float(standoff)
    v0 = max(float(v0), 0.0)
    a = max(float(a_go), 1e-3)
    if sd <= 0.0:
        t_enter = 0.0                      # 已在带内 ⇒ 占用从现在开始
        v_at = v0
    else:
        t_enter = _time_to_cover(sd, v0, v_max, a) + float(dt_lag)
        v_at = min(float(v_max), math.sqrt(v0 * v0 + 2.0 * a * sd))
    t_cross = _time_to_cover(float(ego_len) + float(band), v_at, v_max, a)
    return t_enter, t_cross + float(margin)


#: 【§60】车辆"自身占用冲突区"的时长兜底（s）——作为**安全关键参数**，
#:   取值由 §59.4 的敏感性扫描确定：
#:     VEH_CLEAR=0.5 ⇒ 假放行率 17.3%      (太短，不安全)
#:     VEH_CLEAR=1.0 ⇒ 0.0%                (安全)
#:     VEH_CLEAR=1.5 ⇒ 0.0%（默认，留余量） (安全)
#:     VEH_CLEAR=2.0 ⇒ 13.6%，但放行数从 139 掉到 44 (过于保守)
#:   （车长 3.6 m / 巡航 4.41 m/s = 0.82 s 是物理下界，1.5 是带余量的工程值。）
VEH_CLEAR_SAFE = 1.5


def occupancy_window_clear(t_list, t0, t1, veh_clear_time=VEH_CLEAR_SAFE):
    """【§60】占用窗判据：`[t0,t1]` 内不得有到达，且窗前那辆必须已清空。

    这是 §59 验证过的形式：把"对每一辆车的时序合取"完整保留，
    而不是先取 `min` 再和阈值比（取 min 会丢掉结构信息，见 §59.2）。
    返回 True = 该窗口可用。
    """
    try:
        t0 = float(t0)
        t1 = float(t1)
    except (TypeError, ValueError):
        return False
    if not (math.isfinite(t0) and math.isfinite(t1)) or t1 < t0:
        return False
    before = []
    for tv in (t_list or []):
        # 【§60】类型检查代替 try/except（同 dds_dcarl_turn 的理由）
        if isinstance(tv, bool) or not isinstance(tv, (int, float)):
            continue
        x = float(tv)
        if not math.isfinite(x):
            continue
        if t0 <= x <= t1:
            return False
        if x < t0:
            before.append(x)
    if before and (max(before) + float(veh_clear_time) > t0):
        return False
    return True


def commit_risk(candidates, t0, t1, p_yield=0.5, veh_clear_time=VEH_CLEAR_SAFE,
                max_veh=8):
    """【§60】机会约束：冲突风险的精确值 = P(存在某辆车落在我的占用窗内)。

    `candidates` = [(t_yield, t_rush), ...]，即每辆接近车的两个分支到达时刻：
      · 让行分支（概率 `p_yield`）：维持当前速度 ⇒ `t_yield = d / max(v,0.1)`
      · 抢行分支（概率 `1-p_yield`）：加速到巡航 ⇒ 由 IDM 最坏情况估算
    对各车独立枚举抢行子集（`max_veh` 上限，取最近的若干辆），累加导致重叠的概率。

    ⚠ 为什么必须用"概率"而不是"一律最坏情况"（§59.3/§59.4 实测）：
      一律最坏 ⇒ 假放行率 18%（改善）但**错失 87% 的可用窗口** ⇒ 仍然卡死；
      纯标量阈值 ⇒ 假放行率 60%。
      机会约束在 `VEH_CLEAR=1.5, p_yield=0.5, δ=0.30` 下达到 **0 假放行**。
    ⚠ 安全性对 `p_yield` 极敏感（假设 0.7 而实际 0.5 ⇒ 假放行率 42~52%）
      ⇒ `p_yield` 必须取**保守值或在线估计**，绝不能乐观。

    返回 `(risk, k)`；`candidates` 为空时返回 `(0.0, 0)`（没有对手 ⇒ 无风险）。
    """
    cands = list(candidates or [])[:max(int(max_veh), 1)]
    k = len(cands)
    if k == 0:
        return 0.0, 0
    # 【§62】`p_yield` 支持**逐车**传入（标量=所有车同一概率，向后兼容）。
    #   为什么要逐车：一辆**已被观测到在让行**的车，其抢行概率远低于常数 0.5；
    #   用常数 0.5 会把"单辆车的不确定性"放大成整体否决（实测 risk≥0.5 占 99.1% 帧）。
    if isinstance(p_yield, (int, float)) and not isinstance(p_yield, bool):
        pgs = [min(max(float(p_yield), 0.0), 1.0)] * k
    else:
        pgs = [min(max(float(x), 0.0), 1.0) for x in list(p_yield or [])[:k]]
        while len(pgs) < k:
            pgs.append(0.5)
    risk = 0.0
    for mask in range(1 << k):
        pr = 1.0
        for i in range(k):
            pi = pgs[i]
            pr *= ((1.0 - pi) if (mask >> i) & 1 else pi)
            if pr <= 1e-12:
                break
        if pr <= 1e-12:
            continue
        arr = [cands[i][1] if (mask >> i) & 1 else cands[i][0] for i in range(k)]
        if not occupancy_window_clear(arr, t0, t1, veh_clear_time):
            risk += pr
    return min(risk, 1.0), k


def entry_clearance_time(v_go, ego_len=4.5, band=CLEAR_BAND_DEFAULT,
                         margin=CLEAR_MARGIN_DEFAULT, min_go=0.5):
    """【论文 §VI-A】自车以 `v_go` 进入并**清空**冲突区所需的时间（s）。

    论文原文：the boundary model "estimates the time it will take for the LCV to enter
    Area A from a potential conflict node"。要让"插入"真的安全，必须把**整个车身穿过
    冲突带**的时间算进去，而不是只算车头到达冲突点的时间：

        t_clear = (ego_len + band) / v_go + margin

    ⚠ 这里修的是一个实测到的乐观偏差：旧代码用 `4.0/v_go`（只有自车车身长，不含
    交叉带宽度），于是判据 `t_rv − t_ego_go ≥ 4.0/v_go + 0.5` 在车流带较宽时
    会把"其实插不进去"判成"能过"。实测 expJ_paper_p100：碰撞前末帧自车正处于
    `committed=0 / arc≈10.2m` 的**进入阶段**，最终以侧刮形式撞上正在通过的车
    （自车车头 y≈−137.02，正好压在交叉车体带 [−139,−137] 的边界上）。
    """
    return (float(ego_len) + float(band)) / max(float(v_go), float(min_go)) + float(margin)


def can_clear_safely(t_ego_go, t_rv, v_go, ego_len=4.5, band=CLEAR_BAND_DEFAULT,
                     margin=CLEAR_MARGIN_DEFAULT):
    """能否在"第一个晚于自车到达的交叉车(RV)"之前清空冲突区。

    `t_ego_go` = 自车以目标速度到达冲突点的时间；`t_rv` = RV 到达冲突点的时间。
    返回 True 表示即使 RV 抢行也不会撞（可按 v_go 通过）。
    `t_rv` 非有限（窗口内没有 RV）→ True。
    """
    try:
        t_rv = float(t_rv)
    except (TypeError, ValueError):
        return True
    if not math.isfinite(t_rv):
        return True
    return (t_rv - float(t_ego_go)) >= entry_clearance_time(v_go, ego_len=ego_len,
                                                            band=band, margin=margin)


#: 交叉车"自身占用冲突区"的时间（s）：车身长 / 车速的兜底估计
VEH_CLEAR_TIME_DEFAULT = 1.0


def entry_gap_is_safe(t_ego_go, t_veh_list, my_clearance,
                      veh_clear_time=VEH_CLEAR_TIME_DEFAULT):
    """【P4-①】间隙占用窗口不重叠判据（比"只看第一辆晚到车"严格且正确）。

    我占用冲突区的时间窗：`[t_ego_go, t_ego_go + my_clearance]`
    对方车辆占用窗：      `[t_veh,   t_veh + veh_clear_time]`

    **任何一辆车的占用窗与我重叠 ⇒ 不安全。**

    为什么必须改成这样（实测依据）：
      旧判据只检查"第一个晚于 `t_ego_go` 到达的车"的 `t_rv − t_ego_go ≥ clearance`。
      这漏掉两种情况：
        · 对方**早于**我到达、但**还没清空**（它仍在带内）→ 我进去就侧刮；
        · 更早/更晚的**其它**车辆（不是被选中的那一辆 RV）落进我的占用窗。
      实测 expJ_paper100 的碰撞全部是**进入阶段**（`committed=0`、`arc≈6~12m`）的
      侧刮：车头 y≈−137 正压在交叉车体带 `[−139,−137]` 上，说明"带里当时有车"。

    `t_veh_list` 里非有限值（无车/到不了）按"不构成冲突"跳过。
    返回 True = 可安全进入。
    """
    try:
        t0 = float(t_ego_go)
        mc = float(my_clearance)
    except (TypeError, ValueError):
        return False
    if not math.isfinite(t0) or mc < 0.0:
        return False
    for t_v in (t_veh_list or []):
        try:
            tv = float(t_v)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(tv):
            continue
        if tv >= t0:
            # 对方在我之后或同时到：必须等我把带清空
            if tv < t0 + mc:
                return False
        else:
            # 对方在我之前到：它必须在**我开始进之前**就清空
            if tv + float(veh_clear_time) > t0:
                return False
    return True


def worst_case_thw(thw_now, ego_v, v_rush, floor=0.0):
    """【P4-②】抢行假设下的 THW_boundary（秒）。

    我们的 `thw_boundary = d_ab / (v_ego·n̂)` **只用自车速度**，因此对手提速不会
    反映进去 —— 一辆"当前在让行"的 RV 即使恢复巡航，THW 读数也不变（系统性高估安全）。

    最坏情况：把对手的速度也算进接近速度 ⇒
        THW_worst = d_ab / (v_close_ego + v_rush) = thw_now · v_close_ego / (v_close_ego + v_rush)
    用 `ego_v` 作 `v_close_ego` 的估计（与 thw_boundary 的兜底口径一致）。

    例（ego_v=2.8, v_rush=4.41）：thw_now=3.0 -> 1.17 s；6.0 -> 2.33 s。
    在 `u_safe_mode='left_turn'`（阈值 1.5）下，前者落入风险区、后者仍算安全 —— 正是所要的区分。

    非有限输入原样返回（无 RV 时不参与裁决）。
    """
    try:
        t = float(thw_now)
        if not math.isfinite(t):
            return thw_now
        ve = max(float(ego_v), 0.1)
        vr = max(float(v_rush), 0.0)
        return max(float(floor), t * ve / (ve + vr))
    except (TypeError, ValueError):
        return thw_now


def worst_case_arrival_time(time_to_cover_fn, dist, v_now, v_rush, acc_max,
                            decel=3.0):
    """【P4-①】"最坏情况"到达时间：假设对手**恢复到抢行目标速度**。

    为什么要这个：`identify_gap_vehicles` 的 `t_veh = |x−x_c| / max(v,0.1)` 是
    **匀速假设**。对一辆"当前正在让行、速度已降到 1.3 m/s"的 RV，匀速假设给出
    t_veh ≈ 7 s（看起来极安全），但它**随时可能按 2 s 周期重新决策为抢行**
    并加速回巡航 ⇒ 真实到达时间只有 ~2.6 s。旧判据因此系统性高估安全裕度。

    `time_to_cover_fn(d, v0, v_target, acc, decel)` 由 rv_decision.time_to_cover 提供。
    """
    try:
        d = float(dist)
        v0 = max(float(v_now), 0.1)
        vt = max(float(v_rush), v0)          # 抢行目标不低于当前速度
        return float(time_to_cover_fn(d, v0, vt, acc_max, decel))
    except Exception:
        return float('inf')


# ============================================================
# 2d.【P5】横向扫掠带占用判据（车头进带 vs 带内是否有车）
# ============================================================
#: 交叉车流带半宽（m）：车体宽/2。实测带为 [cross_y-1, cross_y+1]。
BAND_HALF_DEFAULT = 1.0
#: 【S7-②】等待位的车头安全间隙（m）：车头保险杠到交叉带近边的裕量。
WAIT_MARGIN_DEFAULT = 1.5


#: 【缺陷修复】横向屏蔽第一档的**默认 y 投影预算**（m）。
#:   原先 `standoff` 未知时 `_budget = 0.0`，第一档退化成"任何增大 y 投影的横向档都屏掉"
#:   ⇒ 实测 `di=−1.5` 被屏 34% 的帧，V1 验收失败（动作 3/6/9 零样本）。
#:   预算的物理含义 = "允许为横向机动额外吃掉多少车头 y 向净距"。
#:   取 1.0 m ≈ 半个车宽，是一个保守但有意义的值；可用 `DSH_LAT_BUDGET` 覆盖。
LATERAL_BUDGET_DEFAULT = float(os.environ.get('DSH_LAT_BUDGET', '1.0'))


def lateral_shield_mask(laterals, danger_tier, ego_yaw, arc_to_cross,
                        ego_len=4.5, ego_wid=2.0, standoff=None,
                        margin=WAIT_MARGIN_DEFAULT,
                        budget_default=None):
    """【④ 二维屏蔽·横向分量】返回与 `laterals` 等长的 bool 表，True = 该横向档允许。

    为什么必须有它：改造前 ④ 屏蔽只作用于**纵向**（`boundary_shield_mask` 只吃
    `ACTION_SPEEDS`）。用户验收标准 V4 明确："只屏纵向不屏横向 ⇒ 没扩 2D"。

    物理依据（与纵向屏蔽同源，都出自论文 §II 车身边界模型）：
      候选横向偏移 `di` 会在剩余弧长 `arc` 上引入额外航向 ≈ `2·di/max(arc,1)`
      （小角度），使自车矩形的 **y 向半投影** `ey = ½L·|sin ψ| + ½W·|cos ψ|` 变大
      ⇒ 车头**更早**侵入交叉带 `[cross_y−band_half, cross_y+band_half]`。
    因此：
      · `danger_tier == 0`（非危险）      → 全部放行
      · `danger_tier == 1`（lcttc<默认档）→ 只放行"额外 y 投影不超过可用净距"的档
      · `danger_tier == 2`（临界）        → 只放行 `ey` **最小**的档
    保证**至少保留一个**档位（否则自车无路可走），与纵向屏蔽同一约定。
    """
    laterals = [float(x) for x in (laterals or [])]
    if not laterals:
        return []
    if int(danger_tier) <= 0:
        return [True] * len(laterals)

    def _ey(psi):
        c, sn = abs(math.cos(psi)), abs(math.sin(psi))
        return float(ego_len) / 2.0 * sn + float(ego_wid) / 2.0 * c

    _yaw = float(ego_yaw)
    _arc = max(float(arc_to_cross), 1.0)
    _base = _ey(_yaw)
    _eys = [_ey(_yaw + 2.0 * _d / _arc) for _d in laterals]
    _i_best = min(range(len(_eys)), key=lambda k: _eys[k])

    if int(danger_tier) >= 2:
        allowed = [False] * len(laterals)
        allowed[_i_best] = True
        return allowed

    # 第一档：额外 y 投影不得吃掉可用净距。
    #   【缺陷修复】`standoff` 未知（`DSH_WAIT_CLAMP=0` 时恒为 None）⇒ 用**默认预算**
    #   而不是 0，否则第一档退化成"只放行不增大 y 投影的档"，横向动作被系统性屏死。
    if standoff is not None:
        _budget = max(0.0, float(standoff) - float(margin))
    else:
        _budget = float(LATERAL_BUDGET_DEFAULT if budget_default is None else budget_default)
    allowed = [(_eys[k] - _base) <= _budget + 1e-9 for k in range(len(laterals))]
    if not any(allowed):
        allowed = [False] * len(laterals)
        allowed[_i_best] = True
    return allowed


def safe_wait_arc(ref_path, cross_y, ego_len=4.5, band_half=BAND_HALF_DEFAULT,
                  margin=WAIT_MARGIN_DEFAULT):
    """【S7-②】参考路径上"整车(含车长)完全停在交叉带之外"的**弧长位置**（连续插值）。

    为什么需要它：等待点原先是写死的 `hold_arc = 12.2 m ≈ 10.22 + 2 m 几何余量`，
    而那个 10.22 是"碰撞弧长"的**量化伪影**（`arc_to_cross` 旧式只有 2.045 m 分辨率），
    于是"加 2 m 余量"落在同一个量化步长内 ⇒ 名义余量 2 m、实际分辨力 2.045 m，
    余量被吃掉。实测碰撞 `arc_to_cross` 中位正是 12.262（车就停在配置的等待点上被撞）。

    正确做法是**由地图几何反推**，而不是拟合旧的碰撞弧长：
      自车沿 −y 方向接近交叉带 `[cross_y − band_half, cross_y + band_half]`，
      车头（`ego_y − ego_len/2`）触到带的近边（`cross_y + band_half`）即侵入。
      要求整车停稳后车头仍带 `margin` 裕量 ⇒ 停车时的车身中心应满足
          `ego_y >= cross_y + band_half + ego_len/2 + margin`
      取参考路径上**第一个**满足该 y 的点（参考路径在接近段 y 单调递减），
      用线性插值得到连续弧长。

    参数
    ----
    ref_path : (N,2) 参考路径点（沿自车行进方向排列）
    cross_y  : 交叉带中心线 y（东西向道路中心线）
    返回     : 该位置的累计弧长 (m)；无法解析时返回 None（调用方回退到旧默认值）
    """
    try:
        p = [(float(a), float(b)) for a, b in ref_path]
    except Exception:
        return None
    if len(p) < 2:
        return None
    y_stop = float(cross_y) + float(band_half) + float(ego_len) / 2.0 + float(margin)

    def _cum(i):
        return sum(math.hypot(p[k][0] - p[k - 1][0], p[k][1] - p[k - 1][1])
                   for k in range(1, i + 1))

    # ① 等待位：从起点扫描（接近段 y 单调递减），找第一个 y <= y_stop 的位置
    s_wait = None
    for i in range(1, len(p)):
        y0, y1 = p[i - 1][1], p[i][1]
        if y0 > y_stop >= y1:
            seg = math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1])
            t = 0.0 if y0 == y1 else (y0 - y_stop) / (y0 - y1)
            s_wait = _cum(i - 1) + t * seg
            break
    if s_wait is None:
        return None

    # ② 冲突点：路径上 y 最接近 cross_y 的点，其累计弧长
    ci = min(range(len(p)), key=lambda k: abs(p[k][1] - float(cross_y)))
    s_cross = _cum(ci)

    # ③ 【关键】返回**到冲突点的剩余弧长**，与 `crossing_conflict_detail` 的
    #    `arc_to_cross` 同口径。此前直接返回"从起点的累计弧长"，与 `arc_to_cross`
    #    相差一个路径总长（实测 margin=0 时 33.2 vs 12.3）⇒ 若拿来当 hold_arc，
    #    会把自车压在距离冲突点 33 m 之外（或按错误的量判停）。
    return float(s_cross - s_wait)


def rect_axis_extents(yaw, half_len, half_wid):
    """矩形在 x/y 轴上的半投影长度：(ex, ey)，对任意航向都成立。"""
    c, sn = abs(math.cos(yaw)), abs(math.sin(yaw))
    return (half_len * c + half_wid * sn, half_len * sn + half_wid * c)


def wait_standoff(ego_x, ego_y, ego_yaw, ego_len, ego_wid,
                  cross_y, band_half=BAND_HALF_DEFAULT):
    """【S7-③】自车矩形**车头**到交叉带近边的净距（m）。>0 = 整车仍在带外。

    为什么不用弧长：等待位原先靠 `arc_to_cross`（"参考路径投影弧长 + 车长/2"）实现，
    有两个漏洞，实测各贡献一半误差：
      1. **忽略横向偏移**：等待时实测 `lat_dev ≈ 1.5 m`，车头**角点**因此比
         "路径投影 + 车长/2"更靠前，余量被算乐观了。
      2. **只限速不钳位**：等待位是靠速度剖面 `v_ref = sqrt(2a(arc−hold_arc))` 实现的，
         它只限速 ⇒ 允许"蠕动着越过等待位"（2 m 量化时看不出来，`arc` 连续后
         显形为车头侵入）。
    本函数直接用自车的 `(x, y, yaw, length, width)` 算 y 向半投影 `ey`
    （`rect_axis_extents`），车头即 `ego_y − ey` —— **天然含横向偏移与航向**，
    且与弧长参数化无关，可作位置硬钳制的判据。

    实测（`expOO_vref_20` / `expSS_wait20`，26 次碰撞逐次核对）：撞自车的车**恒在
    `y = −138.00`**（交叉车流中心线），自车 `ego_y ≈ −134.70` ⇒ 车头 −136.95；
    交叉车半宽 1.0 ⇒ 带近边 −137.00 ⇒ **侵入 0.05 m**。即"停在带边线上、车头贴着过路车"。
    """
    try:
        _, ey = rect_axis_extents(float(ego_yaw), float(ego_len) / 2.0, float(ego_wid) / 2.0)
    except Exception:
        return None
    return float(ego_y) - float(ey) - (float(cross_y) + float(band_half))


def band_occupancy(ego_x, ego_y, ego_yaw, ego_v, ego_len, ego_wid,
                   cross_y, veh_list, band_half=BAND_HALF_DEFAULT,
                   lat_margin=1.0, horizon_extra=2.0):
    """【P5】车头扫掠带占用：自车车头进入/穿越交叉带时，带内是否有车。

    为什么需要它（实测依据，见 RUN_GUIDE P5）：
      · `lcttc`（物理边界距离）没有提前量：碰撞前 10 帧 95% 已在刹车却仍撞；
      · `thw` / `thw_worst` 对"即将碰撞"**没有区分度**：碰撞前 20 帧的中位 thw_worst
        是 2.38 s，反而**高于**接近区全体帧的中位 1.78 s ⇒ 阈值无法分离两类帧。
      · 观测到的碰撞形态是**进入阶段的侧刮**：自车车头 y≈−137 压在交叉车体带
        [−139,−137] 上。⇒ 真正的失效量是"**横向扫掠带被占用**"，不是时间裕度。

    几何（自车自北向南接近，cross_y 为交叉道中心线）：
      band_near = cross_y + band_half            # 带的北边缘（自车先遇到它）
      ego_front_y = ego_y − rect 在 y 方向的下半投影（= 车头最南点）
      front_clearance = ego_front_y − band_near  # >0 = 车头仍在带外（安全侧）

    返回 dict:
      front_clearance 车头到带北边缘的有符号距离（m，>0 在带外）
      occupied        当前"带内且落在车头 x 邻域"是否有车（bool）
      nev_in_band     带内（y 方向）车辆数
      min_x_gap       车头 x 到最近带内车 x 的净间隙（m，越小越危险）
      t_entry         车头按当前速度抵达带北边缘的预测时间（s，inf=到不了）
      occupied_pred   预测"车头进带那一刻"的占用（bool）—— 这才是**带提前量**的判据
      pred_x_gap      预测时刻的净 x 间隙（m）
    """
    out = {'front_clearance': float('nan'), 'occupied': False, 'nev_in_band': 0,
           'min_x_gap': float('inf'), 't_entry': float('inf'),
           'occupied_pred': False, 'pred_x_gap': float('inf')}
    try:
        ex_h, ey_h = rect_axis_extents(float(ego_yaw), float(ego_len) / 2.0,
                                       float(ego_wid) / 2.0)
        ego_front_y = float(ego_y) - ey_h
        ego_front_x = float(ego_x) + (float(ego_len) / 2.0) * math.cos(float(ego_yaw))
        band_near = float(cross_y) + float(band_half)
        out['front_clearance'] = ego_front_y - band_near
        # 车头沿 y 的接近速度分量（向南为正）
        v_south = -float(ego_v) * math.sin(float(ego_yaw))
        t_entry = (out['front_clearance'] / v_south) if v_south > 0.05 else float('inf')
        out['t_entry'] = float(t_entry)
        # 逐车
        for v in (veh_list or []):
            try:
                vx_, vy_ = float(v.get('x')), float(v.get('y'))
                yaw_ = float(v.get('yaw', 0.0))
                a_v = float(v.get('length', 4.0)) / 2.0
                b_v = float(v.get('width', 2.0)) / 2.0
                vvx = float(v.get('vx', -float(v.get('v', 0.0))))
                _, ey_v = rect_axis_extents(yaw_, a_v, b_v)
                if abs(vy_ - float(cross_y)) > float(band_half) + ey_v:
                    continue                     # 不在带内
                out['nev_in_band'] += 1
                gap = abs(vx_ - ego_front_x) - (a_v + float(ego_wid) / 2.0)
                out['min_x_gap'] = min(out['min_x_gap'], gap)
                if gap < float(lat_margin):
                    out['occupied'] = True
                # 预测：车头进带时刻，对方 x 平移到哪
                if math.isfinite(t_entry) and t_entry <= float(horizon_extra) * 4.0:
                    x_pred = vx_ + vvx * t_entry
                    gap_pred = abs(x_pred - ego_front_x) - (a_v + float(ego_wid) / 2.0)
                    out['pred_x_gap'] = min(out['pred_x_gap'], gap_pred)
                    if gap_pred < float(lat_margin):
                        out['occupied_pred'] = True
            except (TypeError, ValueError):
                continue
    except (TypeError, ValueError):
        pass
    return out



# ============================================================
# 3. 离线几何自检（纯数学对拍，无仿真）
# ============================================================

def _self_test():
    print("=" * 60)
    print("boundary_safety 离线几何自检")
    print("=" * 60)
    ok = True

    # T1: 端对端排列（中心距 6m，各长 4.5m → 边界距 6-4.5=1.5m）
    ra = make_rect(0.0, 0.0, 0.0, 4.5, 2.0)
    rb = make_rect(6.0, 0.0, 0.0, 4.5, 2.0)
    d = rect_distance(ra, rb)
    t1 = abs(d - 1.5) < 1e-6
    ok &= t1
    print("T1 端对端距离 1.5m: got %.3f -> %s" % (d, "PASS" if t1 else "FAIL"))

    # T2: 前后排列（中心距 10m，各长4.5m → 边界距 5.5m）
    rc = make_rect(0.0, 0.0, 0.0, 4.5, 2.0)
    rd = make_rect(10.0, 0.0, 0.0, 4.5, 2.0)
    d2 = rect_distance(rc, rd)
    t2 = abs(d2 - 5.5) < 1e-6
    ok &= t2
    print("T2 分离距离(前后 5.5m): got %.3f -> %s" % (d2, "PASS" if t2 else "FAIL"))

    # T3: 旋转 90° 矩形（T 型交叉），重叠 → 0
    re = make_rect(0.0, 0.0, 0.0, 4.5, 2.0)
    rf = make_rect(1.0, 0.0, math.pi / 2.0, 4.5, 2.0)
    d3 = rect_distance(re, rf)
    t3 = d3 == 0.0
    ok &= t3
    print("T3 重叠(T型) → 0: got %.3f -> %s" % (d3, "PASS" if t3 else "FAIL"))

    # T4: 对向逼近 TTC（中心距 10m，车身半长和 4.25m → 边界距 5.75m，合速 20m/s → TTC≈0.29s）
    m = boundary_metrics(0.0, 0.0, 0.0, 10.0,     # ego 向东 10 m/s
                         10.0, 0.0, math.pi, 10.0, # veh 向西 10 m/s
                         dt=0.1)
    t4 = abs(m['d_ab'] - 5.75) < 0.1 and abs(m['ttc_boundary'] - 0.2875) < 0.05
    ok &= t4
    print("T4 对向逼近 TTC≈%.2fs (d=%.2f) -> %s" % (m['ttc_boundary'], m['d_ab'], "PASS" if t4 else "FAIL"))

    # T5: 垂直交叉（ego 向东，veh 向南 yaw=-π/2）。veh 长 4m 沿 y 向 → 边界距 = 2(veh前缘) - (-7 ego后缘) = 7m，合速 8m/s → TTC≈0.875s
    m5 = boundary_metrics(0.0, -8.0, 0.0, 8.0,
                          0.0, 2.0, -math.pi / 2.0, 8.0,
                          dt=0.1)
    t5 = abs(m5['d_ab'] - 7.0) < 0.1 and abs(m5['ttc_boundary'] - 0.875) < 0.05
    ok &= t5
    print("T5 垂直交叉 TTC=%.2fs (d=%.2f) -> %s" % (m5['ttc_boundary'], m5['d_ab'], "PASS" if t5 else "FAIL"))

    # T6: 同向同速（不接近）→ TTC=inf
    m6 = boundary_metrics(0.0, 0.0, 0.0, 8.0,
                          10.0, 0.0, 0.0, 8.0,
                          dt=0.1)
    t6 = math.isinf(m6['ttc_boundary'])
    ok &= t6
    print("T6 同向不逼近 TTC=inf -> %s" % ("PASS" if t6 else "FAIL"))

    # T7: LCTTC 时域最小（对向逼近，时域 2s 内必碰撞 → LCTTC 极小(<0.4s)，min_d_ab<=0）
    L = lcttc_over_horizon(0.0, 0.0, 0.0, 10.0,
                           10.0, 0.0, math.pi, 10.0,
                           horizon=2.0, dt=0.1)
    t7 = L['lcttc'] < 0.4 and L['min_d_ab'] <= 0.0
    ok &= t7
    print("T7 LCTTC=%.2fs min_d=%.2f -> %s" % (L['lcttc'], L['min_d_ab'], "PASS" if t7 else "FAIL"))

    # T8: 随机对拍（与"四边稠密采样"的参考距离比较，误差 < 0.15m）
    def _edge_samples(rect, n=40):
        pts = []
        c = rect.corners
        for i in range(4):
            ax, ay = c[i].x, c[i].y
            bx, by = c[(i + 1) % 4].x, c[(i + 1) % 4].y
            for k in range(n):
                t = k / n
                pts.append((ax + t * (bx - ax), ay + t * (by - ay)))
        return pts

    rng = np.random.RandomState(42)
    worst = 0.0
    for _ in range(200):
        xa, ya, ya_ = rng.uniform(-5, 5, 3).tolist()
        xb, yb, yb_ = rng.uniform(-5, 5, 3).tolist()
        r1 = make_rect(xa, ya, ya_, 4.5, 2.0)
        r2 = make_rect(xb, yb, yb_, 4.5, 2.0)
        exact = rect_distance(r1, r2)
        p1 = _edge_samples(r1)
        p2 = _edge_samples(r2)
        ref = min(math.hypot(a[0] - b[0], a[1] - b[1]) for a in p1 for b in p2)
        if exact > 0:
            worst = max(worst, abs(exact - ref))
    t8 = worst < 0.15
    ok &= t8
    print("T8 随机对拍 200 组, 最大偏差=%.3fm -> %s" % (worst, "PASS" if t8 else "FAIL"))

    print("=" * 60)
    print("SELF-TEST %s" % ("ALL PASS" if ok else "SOME FAIL"))
    return ok


if __name__ == "__main__":
    _self_test()
