"""Same-intent motion-trajectory probes; no learning or new safety thresholds.

The frozen CG still selects the intent and retains its original two payoffs.
An explicitly selected experiment can request a slower trajectory of that SAME
intent only after the common guard accepts it. Unexecuted predictions are not
experience, and these probes make no claim of learned or globally optimal paths.
"""
import hashlib
import time

import numpy as np

from Planning_library.control_path_v15 import path_hash
from Planning_library.matrix_turn_game_v18 import score_candidates
from Planning_library.matrix_turn_game_v20 import candidate_execution
from Planning_library.paper_turn_control import motion
from Planning_library.vehicle_observation import vehicle_id, vehicle_size, longitudinal_acceleration


def _array_hash(value):
    if value is None:
        return None
    return hashlib.sha256(np.asarray(value, dtype='<f8').tobytes()).hexdigest()


def _vehicle(v):
    if v is None:
        return None
    vx, vy = motion(v)
    return dict(id=vehicle_id(v), x=float(v.x), y=float(v.y), v=float(v.v),
                vx=float(vx), vy=float(vy), yaw=float(v.yaw), acc=longitudinal_acceleration(v),
                acc_source=getattr(v, 'acc_source', 'unavailable'),
                length=vehicle_size(v,'length',4.), width=vehicle_size(v,'width',2.))


def _description(candidate, identity, intent):
    data = lambda name: (None if candidate.get(name) is None else
                         np.asarray(candidate[name], dtype=float).tolist())
    return dict(id=identity, intent=intent, target=float(candidate['target']),
        a=float(candidate['a']), delta=float(candidate['delta']), solve_ok=bool(candidate['solve_ok']),
        plan=data('plan'), prediction=data('prediction'), times=data('times'),
        plan_hash=_array_hash(candidate.get('plan')), prediction_hash=_array_hash(candidate.get('prediction')),
        source='cg' if identity.endswith('_base') else 'parameterized_planner')


class TrajectoryProbeV21:
    SCALE = .75

    def __init__(self, mode, geometry, controllers, cruise=4.412022451715821):
        if mode not in ('observe', 'defer', 'proceed') or len(controllers) != 2:
            raise ValueError('Expected observe/defer/proceed and two isolated probe solvers')
        if geometry.get('forecast_model') != 'route_v18':
            raise ValueError('Trajectory probes require the frozen v18 public forecast')
        self.mode, self.geometry = mode, geometry
        self.cruise = float(cruise)
        self.controllers, self.last = list(controllers), None

    @staticmethod
    def capture(primary):
        """Capture BEFORE either CG solve; no candidate's hypothetical control leaks."""
        return dict(previous=dict(primary.last_u),
            observed_speed=primary._previous_observed_speed,
            warm=None if primary._warm_controls is None else primary._warm_controls.copy())

    def propose(self, dynamic, candidates, baseline, cg_record, seed, road_right, center):
        started = time.perf_counter()
        if len(candidates) != 2 or baseline not in (0, 1):
            raise ValueError('The frozen CG must provide exactly two ordered candidates')
        primary = candidates[1]['controller']
        path = primary.last_pathway
        ego, objects = dynamic.ego_vehicle, dynamic.objects
        rv = next((v for v in objects if vehicle_id(v)==cg_record.get('rv_id')), None)
        names = ('defer', 'proceed')
        records = [_description(c, names[i]+'_base', names[i]) for i, c in enumerate(candidates)]
        choices = dict((r['id'], c) for r, c in zip(records, candidates))
        self.last = dict(revision='trajectory_probe_v21', mode=self.mode, active=bool(cg_record['active']),
            baseline_intent=int(baseline), baseline_id=names[baseline]+'_base',
            request_id=names[baseline]+'_base', changed_request=False, scale=self.SCALE,
            learning_enabled=False, efe_reward_enabled=False, spatial_path_changed=False,
            beta=dict(status='unidentified', value=None), observation=dict(ego=_vehicle(ego),
                others=[_vehicle(v) for v in objects], phase=cg_record['phase'],
                standoff=float(cg_record['standoff']),
                lateral_error=(primary.last_tracking_state or {}).get('l'),
                heading_error=(primary.last_tracking_state or {}).get('epsi')),
            path_hash=path_hash(path), previous=dict(seed['previous']), warm_hash=_array_hash(seed['warm']),
            path=np.asarray(path, dtype=float)[:, :2].tolist(),
            generation=dict(target_scale=self.SCALE, minimum_rolling_target=.2, minimum_target_change=.05),
            skip_reason=None, candidates=records, request=None, extra_solve_ms=0., decision_ms=0.)
        if not cg_record['active']:
            self.last['skip_reason'] = 'inactive'
        elif primary.geometry_force_stop or primary.geometry_source != 'planned':
            self.last['skip_reason'] = 'forced_stop'
        else:
            for i, original in enumerate(candidates):
                target = float(original['target'])*self.SCALE
                # Preserve the v14 stop/rolling distinction; never turn a stop
                # into creep or create a nearly identical action for coverage.
                if target < .2 or original['target']-target < .05:
                    continue
                controller = self.controllers[i]
                controller.reset_global_path(path, dynamic)
                controller.geometry_source = primary.geometry_source
                controller.geometry_force_stop = primary.geometry_force_stop
                controller.last_u = dict(seed['previous'])
                controller._previous_observed_speed = seed['observed_speed']
                controller._warm_controls = None if seed['warm'] is None else seed['warm'].copy()
                controller.set_game_context({}, ego)
                a, delta = controller.solve(dynamic, target, road_right, intersection_center=center)
                c = dict(controller=controller, target=target, a=a, delta=delta,
                    solve_ok=bool(controller._solve_ok), prediction=controller.last_prediction,
                    plan=controller.last_control_plan if controller._solve_ok else None,
                    times=controller.prediction_times)
                self.last['extra_solve_ms'] += float(controller.last_solve_ms)
                identity = names[i]+'_slow'
                execution = candidate_execution(ego, objects, [c], path, seed['previous'], self.geometry)[0]
                _, parts = score_candidates(ego, objects, rv, [c], self.geometry,
                    path, seed['previous'], self.cruise,
                    cg_record.get('motion_evidence', {}).get('acceleration'))
                r = _description(c, identity, names[i])
                r.update(execution=execution, components=parts[0],
                    eligible=bool(c['solve_ok'] and execution['accepted']
                                  and all(p['admissible'] for p in parts[0])))
                records.append(r)
                choices[identity] = c
            requested = names[baseline]+'_slow'
            alternative = next((r for r in records if r['id']==requested), None)
            if self.mode==names[baseline] and alternative is not None and alternative['eligible']:
                self.last.update(request_id=requested, changed_request=True)
        self.last['request'] = next(dict(r) for r in records if r['id']==self.last['request_id'])
        self.last['decision_ms'] = (time.perf_counter()-started)*1000.
        output = list(candidates)
        output[baseline] = choices[self.last['request_id']]
        return output

    def activate(self, current, chosen):
        if chosen is current:
            return current
        try:
            index = next(i for i, c in enumerate(self.controllers) if c is chosen)
        except StopIteration:
            raise ValueError('Selected controller does not belong to the probe pool')
        self.controllers[index] = current
        return chosen

    def acknowledge(self, acceleration, delta):
        for controller in self.controllers:
            controller.acknowledge_applied_control(acceleration, delta)

    def reset(self):
        for controller in self.controllers:
            controller.reset_controller()
        self.last = None
