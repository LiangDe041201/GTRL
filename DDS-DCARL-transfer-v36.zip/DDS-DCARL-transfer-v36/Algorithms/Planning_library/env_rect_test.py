import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from Agent.tools_dds.rectangle_tools import Point, Rectangle_SAT

def plot_rect(rect, ax, color='b', alpha=0.5):   
    # 使用 rect.corners 获取角点
    corners = rect.corners
    # 将角点坐标转换为 matplotlib 需要的格式
    poly = Polygon([(p.x, p.y) for p in corners], closed=True, 
                  fill=True, color=color, alpha=alpha)
    ax.add_patch(poly)

# 创建自车周围矩形,车头朝向为正前方
"""--------------------------------[下面放置之前的所有矩形创建代码]--------------------------------"""

# 初始化自车参数
ego_x, ego_y = 10, 5                            # 自车位置
ego_yaw = -0.33                                 # 使用弧度,已转换carla相同显示
ego_boxx = 4.89                                 # 车长
ego_boxy = 1.89                                 # 车宽
rect_x = ego_boxx                               # 检测框长
rect_y = 3.5                                    # 检测框宽
rect_y_mid = 3*rect_y/2 - ego_boxy/2            # 中部检测框宽
forward_offset = ego_boxx * 0.25                # 前方偏移量
sides_offset_mid = 3*rect_y/4 + ego_boxy/4      # 中间两侧偏移量
sides_offset = 3*rect_y/2 - ego_boxy            # 两侧偏移量

# 正前方
f_rect_center_x = ego_x + ego_boxx * np.cos(ego_yaw)    
f_rect_center_y = ego_y + ego_boxx * np.sin(ego_yaw)
ego_rect_f = Rectangle_SAT(Point(f_rect_center_x, f_rect_center_y), rect_x, rect_y, ego_yaw)

# 正后方
b_rect_center_x = ego_x - ego_boxx * np.cos(ego_yaw)    
b_rect_center_y = ego_y - ego_boxx * np.sin(ego_yaw)
ego_rect_b = Rectangle_SAT(Point(b_rect_center_x, b_rect_center_y), rect_x, rect_y, ego_yaw)

# 正左方前
lf_rect_center_x = (ego_x + forward_offset * np.cos(ego_yaw) + sides_offset_mid * np.sin(ego_yaw))      
lf_rect_center_y = (ego_y + forward_offset * np.sin(ego_yaw) - sides_offset_mid * np.cos(ego_yaw))      
ego_rect_lf = Rectangle_SAT(Point(lf_rect_center_x, lf_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# 正左方后
lb_rect_center_x = (ego_x - forward_offset * np.cos(ego_yaw) + sides_offset_mid * np.sin(ego_yaw))      
lb_rect_center_y = (ego_y - forward_offset * np.sin(ego_yaw) - sides_offset_mid * np.cos(ego_yaw))      
ego_rect_lb = Rectangle_SAT(Point(lb_rect_center_x, lb_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# 前左方前
flf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))   
flf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
ego_rect_flf = Rectangle_SAT(Point(flf_rect_center_x, flf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 前左方后
flb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))    
flb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
ego_rect_flb = Rectangle_SAT(Point(flb_rect_center_x, flb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 后左方前
blf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))   
blf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
ego_rect_blf = Rectangle_SAT(Point(blf_rect_center_x, blf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 后左方后
blb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))    
blb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
ego_rect_blb = Rectangle_SAT(Point(blb_rect_center_x, blb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 正右方前
rf_rect_center_x = (ego_x + forward_offset * np.cos(ego_yaw) - sides_offset_mid * np.sin(ego_yaw))       
rf_rect_center_y = (ego_y + forward_offset * np.sin(ego_yaw) + sides_offset_mid * np.cos(ego_yaw))       
ego_rect_rf = Rectangle_SAT(Point(rf_rect_center_x, rf_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# 正右方后
rb_rect_center_x = (ego_x - forward_offset * np.cos(ego_yaw) - sides_offset_mid * np.sin(ego_yaw))       
rb_rect_center_y = (ego_y - forward_offset * np.sin(ego_yaw) + sides_offset_mid * np.cos(ego_yaw))       
ego_rect_rb = Rectangle_SAT(Point(rb_rect_center_x, rb_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# 前右方前
frf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))    
frf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
ego_rect_frf = Rectangle_SAT(Point(frf_rect_center_x, frf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 前右方后
frb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))    
frb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
ego_rect_frb = Rectangle_SAT(Point(frb_rect_center_x, frb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 后右方前
brf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))   
brf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
ego_rect_brf = Rectangle_SAT(Point(brf_rect_center_x, brf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# 后右方后
brb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))   
brb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
ego_rect_brb = Rectangle_SAT(Point(brb_rect_center_x, brb_rect_center_y), rect_x/2, rect_y, ego_yaw)    

"""--------------------------------[上面放置之前的所有矩形创建代码]--------------------------------"""


# 创建图形
fig, ax = plt.subplots(figsize=(10, 10))

# 调整坐标轴
ax.invert_yaxis()                     # 反转Y轴，使坐标系与CARLA一致
ax.xaxis.tick_top()                   # 将X轴移到顶部
ax.xaxis.set_label_position('top')    # 将X轴标签移到顶部

# 绘制自车矩形（中心）
ego_rect = Rectangle_SAT(Point(ego_x, ego_y), ego_boxx, ego_boxy, ego_yaw)
plot_rect(ego_rect, ax, 'black', 0.7)

# 绘制所有方向的矩形，使用不同颜色
rects = {
    'f': ('red', ego_rect_f),
    'b': ('blue', ego_rect_b),
    'lf': ('green', ego_rect_lf),
    'lb': ('green', ego_rect_lb),
    'rf': ('purple', ego_rect_rf),
    'rb': ('purple', ego_rect_rb),
    'flf': ('orange', ego_rect_flf),
    'flb': ('orange', ego_rect_flb),
    'frf': ('pink', ego_rect_frf),
    'frb': ('pink', ego_rect_frb),
    'blf': ('brown', ego_rect_blf),
    'blb': ('brown', ego_rect_blb),
    'brf': ('gray', ego_rect_brf),
    'brb': ('gray', ego_rect_brb)
}

for name, (color, rect) in rects.items():
    plot_rect(rect, ax, color)
    ax.text(rect.center.x, rect.center.y, name, 
            ha='center', va='center', fontsize=8, fontweight='bold')

# 添加图例
from matplotlib.lines import Line2D
legend_elements = [Line2D([0], [0], color='black', lw=4, label='ego')] + \
                 [Line2D([0], [0], color=color, lw=4, label=name) 
                  for name, (color, _) in rects.items()]
ax.legend(handles=legend_elements, loc='lower left')

# 设置图形范围和标签
# ax.set_xlim(ego_x - ego_boxx*3, ego_x + ego_boxx*3)
# ax.set_ylim(ego_y - ego_boxy*3, ego_y + ego_boxy*3)

margin = max(ego_boxx, rect_y) * 2  # 使用较大的边距
ax.set_xlim(ego_x - margin, ego_x + margin)
ax.set_ylim(ego_y - margin, ego_y + margin)

ax.set_aspect('equal')
ax.grid(True)
ax.set_title('Ego Vehicle and Surrounding Rectangles')

# 设置X轴在顶部
ax.xaxis.tick_top()
ax.xaxis.set_label_position('top')

# 设置Y轴在右侧
ax.yaxis.tick_right()
ax.yaxis.set_label_position('right')

# 反转Y轴方向，使Y轴向下为正
ax.invert_yaxis()

# 设置坐标轴标签
ax.set_xlabel('X')
ax.set_ylabel('Y', rotation=0, va='bottom')  # 使Y标签水平显示

plt.tight_layout()
plt.show()


# # 检测框形 1 -------------------------------------------------------------------------------------------
# # 初始化自车参数
# ego_x, ego_y = 10, 5                            # 自车位置
# ego_yaw = -0.33                                 # 使用弧度,已转换carla相同显示
# ego_boxx = 4.89                                 # 车长
# ego_boxy = 1.89                                 # 车宽
# rect_x = ego_boxx                               # 检测框长
# rect_y = 3.5                                    # 检测框宽
# rect_y_mid = 3*rect_y/2 - ego_boxy/2            # 中部检测框宽
# forward_offset = ego_boxx * 0.25                # 前方偏移量
# sides_offset_mid = 3*rect_y/4 + ego_boxy/4      # 中间两侧偏移量
# sides_offset = 3*rect_y/2 - ego_boxy            # 两侧偏移量

# # 正前方
# f_rect_center_x = ego_x + ego_boxx * np.cos(ego_yaw)    
# f_rect_center_y = ego_y + ego_boxx * np.sin(ego_yaw)
# ego_rect_f = Rectangle_SAT(Point(f_rect_center_x, f_rect_center_y), rect_x, rect_y, ego_yaw)

# # 正后方
# b_rect_center_x = ego_x - ego_boxx * np.cos(ego_yaw)    
# b_rect_center_y = ego_y - ego_boxx * np.sin(ego_yaw)
# ego_rect_b = Rectangle_SAT(Point(b_rect_center_x, b_rect_center_y), rect_x, rect_y, ego_yaw)

# # 正左方前
# lf_rect_center_x = (ego_x + forward_offset * np.cos(ego_yaw) + sides_offset_mid * np.sin(ego_yaw))      
# lf_rect_center_y = (ego_y + forward_offset * np.sin(ego_yaw) - sides_offset_mid * np.cos(ego_yaw))      
# ego_rect_lf = Rectangle_SAT(Point(lf_rect_center_x, lf_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# # 正左方后
# lb_rect_center_x = (ego_x - forward_offset * np.cos(ego_yaw) + sides_offset_mid * np.sin(ego_yaw))      
# lb_rect_center_y = (ego_y - forward_offset * np.sin(ego_yaw) - sides_offset_mid * np.cos(ego_yaw))      
# ego_rect_lb = Rectangle_SAT(Point(lb_rect_center_x, lb_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# # 前左方前
# flf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))   
# flf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
# ego_rect_flf = Rectangle_SAT(Point(flf_rect_center_x, flf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 前左方后
# flb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))    
# flb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
# ego_rect_flb = Rectangle_SAT(Point(flb_rect_center_x, flb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 后左方前
# blf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))   
# blf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
# ego_rect_blf = Rectangle_SAT(Point(blf_rect_center_x, blf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 后左方后
# blb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) + rect_y * np.sin(ego_yaw))    
# blb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) - rect_y * np.cos(ego_yaw))
# ego_rect_blb = Rectangle_SAT(Point(blb_rect_center_x, blb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 正右方前
# rf_rect_center_x = (ego_x + forward_offset * np.cos(ego_yaw) - sides_offset_mid * np.sin(ego_yaw))       
# rf_rect_center_y = (ego_y + forward_offset * np.sin(ego_yaw) + sides_offset_mid * np.cos(ego_yaw))       
# ego_rect_rf = Rectangle_SAT(Point(rf_rect_center_x, rf_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# # 正右方后
# rb_rect_center_x = (ego_x - forward_offset * np.cos(ego_yaw) - sides_offset_mid * np.sin(ego_yaw))       
# rb_rect_center_y = (ego_y - forward_offset * np.sin(ego_yaw) + sides_offset_mid * np.cos(ego_yaw))       
# ego_rect_rb = Rectangle_SAT(Point(rb_rect_center_x, rb_rect_center_y), rect_x/2, rect_y_mid, ego_yaw)

# # 前右方前
# frf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))    
# frf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
# ego_rect_frf = Rectangle_SAT(Point(frf_rect_center_x, frf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 前右方后
# frb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))    
# frb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
# ego_rect_frb = Rectangle_SAT(Point(frb_rect_center_x, frb_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 后右方前
# brf_rect_center_x = ego_x + forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))   
# brf_rect_center_y = ego_y + forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
# ego_rect_brf = Rectangle_SAT(Point(brf_rect_center_x, brf_rect_center_y), rect_x/2, rect_y, ego_yaw)

# # 后右方后
# brb_rect_center_x = ego_x - forward_offset * np.cos(ego_yaw) + (-ego_boxx * np.cos(ego_yaw) - rect_y * np.sin(ego_yaw))   
# brb_rect_center_y = ego_y - forward_offset * np.sin(ego_yaw) + (-ego_boxx * np.sin(ego_yaw) + rect_y * np.cos(ego_yaw))
# ego_rect_brb = Rectangle_SAT(Point(brb_rect_center_x, brb_rect_center_y), rect_x/2, rect_y, ego_yaw) 

# # 绘制所有方向的矩形，使用不同颜色
# rects = {
#     'f': ('red', ego_rect_f),
#     'b': ('blue', ego_rect_b),
#     'lf': ('green', ego_rect_lf),
#     'lb': ('green', ego_rect_lb),
#     'rf': ('purple', ego_rect_rf),
#     'rb': ('purple', ego_rect_rb),
#     'flf': ('orange', ego_rect_flf),
#     'flb': ('orange', ego_rect_flb),
#     'frf': ('pink', ego_rect_frf),
#     'frb': ('pink', ego_rect_frb),
#     'blf': ('brown', ego_rect_blf),
#     'blb': ('brown', ego_rect_blb),
#     'brf': ('gray', ego_rect_brf),
#     'brb': ('gray', ego_rect_brb)
# }   

# # 检测框形 2 -------------------------------------------------------------------------------------------
# # 创建自车周围矩形,车头朝向为正前方
# f_rect_center_x = ego_x + ego_boxx * np.cos(ego_yaw)    # 正前方
# f_rect_center_y = ego_y + ego_boxx * np.sin(ego_yaw)
# ego_rect_f = Rectangle_SAT(Point(f_rect_center_x, f_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# b_rect_center_x = ego_x - ego_boxx * np.cos(ego_yaw)    # 正后方
# b_rect_center_y = ego_y - ego_boxx * np.sin(ego_yaw)
# ego_rect_b = Rectangle_SAT(Point(b_rect_center_x, b_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# l_rect_center_x = ego_x + ego_boxy * np.sin(ego_yaw)    # 正左方
# l_rect_center_y = ego_y - ego_boxy * np.cos(ego_yaw)
# ego_rect_l = Rectangle_SAT(Point(l_rect_center_x, l_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# r_rect_center_x = ego_x - ego_boxy * np.sin(ego_yaw)    # 正右方
# r_rect_center_y = ego_y + ego_boxy * np.cos(ego_yaw)
# ego_rect_r = Rectangle_SAT(Point(r_rect_center_x, r_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# fl_rect_center_x = ego_x + (ego_boxx * np.cos(ego_yaw) + ego_boxy * np.sin(ego_yaw))    # 左前方
# fl_rect_center_y = ego_y + (ego_boxx * np.sin(ego_yaw) - ego_boxy * np.cos(ego_yaw))
# ego_rect_fl = Rectangle_SAT(Point(fl_rect_center_x, fl_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# fr_rect_center_x = ego_x + (ego_boxx * np.cos(ego_yaw) - ego_boxy * np.sin(ego_yaw))    # 右前方
# fr_rect_center_y = ego_y + (ego_boxx * np.sin(ego_yaw) + ego_boxy * np.cos(ego_yaw))
# ego_rect_fr = Rectangle_SAT(Point(fr_rect_center_x, fr_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# bl_rect_center_x = ego_x + (-ego_boxx * np.cos(ego_yaw) + ego_boxy * np.sin(ego_yaw))   # 左后方
# bl_rect_center_y = ego_y + (-ego_boxx * np.sin(ego_yaw) - ego_boxy * np.cos(ego_yaw))
# ego_rect_bl = Rectangle_SAT(Point(bl_rect_center_x, bl_rect_center_y), ego_boxx, ego_boxy, ego_yaw)

# br_rect_center_x = ego_x + (-ego_boxx * np.cos(ego_yaw) - ego_boxy * np.sin(ego_yaw))   # 右后方
# br_rect_center_y = ego_y + (-ego_boxx * np.sin(ego_yaw) + ego_boxy * np.cos(ego_yaw))
# ego_rect_br = Rectangle_SAT(Point(br_rect_center_x, br_rect_center_y), ego_boxx, ego_boxy, ego_yaw)