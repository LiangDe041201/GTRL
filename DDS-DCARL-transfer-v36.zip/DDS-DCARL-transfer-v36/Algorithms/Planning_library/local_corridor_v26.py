"""Startup public-map capture followed by batched local body checks."""
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np

from Planning_library.control_path_v15 import path_hash
from Planning_library.forecast_v16 import clean_points
from Planning_library.local_road_v26 import LocalRoadRegion
from Planning_library.road_corridor_v23 import RoadCorridor


class LocalRoadCorridorV26:
    def __init__(self,region,metadata=None):
        self.region=region
        self.allowed,self.junctions=region.allowed,region.junctions
        self.statistics=dict(map_queries=0,map_cache_hits=0,map_query_ms=0.,audit_calls=0,
                             local_points=0,local_query_ms=0.)
        self.metadata=dict(metadata or {},revision='analytic_local_road_v26',
            source='startup_opendrive_task_region',geometry='line_arc_piecewise_cubic_lanes_2d',
            route_lanes=[list(v) for v in sorted(self.allowed)],route_junctions=sorted(self.junctions),
            bounds_xyxy=region.bounds.tolist(),task_primitives=len(region.task),
            local_driving_primitives=len(region.all),project_to_road=False,
            margin_m=.15,body_sample_spacing_m=.75,pose_spacing_m=.3,heading_spacing_rad=.08,
            runtime_map_queries=False,membership='union_of_task_lanes_and_task_junction_driving_lanes',
            guarantee=False)

    @classmethod
    def from_carla(cls,road_map,location_factory,driving_type,reference,z,directory=None):
        started=time.perf_counter()
        points=clean_points(reference)
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
        samples=np.linspace(0.,arc[-1],int(math.ceil(arc[-1]/.5))+1)
        lanes,junctions,missing=set(),set(),0
        # The only point API calls: identify the public route once at setup.
        for s in samples:
            wp=road_map.get_waypoint(location_factory(x=float(np.interp(s,arc,points[:,0])),
                y=float(np.interp(s,arc,points[:,1])),z=float(z)),
                project_to_road=False,lane_type=driving_type)
            if wp is None: missing+=1; continue
            lanes.add((int(wp.road_id),int(wp.section_id),int(wp.lane_id)))
            if wp.is_junction:
                junction=wp.get_junction()
                if junction is None: raise ValueError('Missing public route junction ID')
                junctions.add(int(junction.id))
        data=road_map.to_opendrive().encode('utf8')
        # Covers the route, local proposals and full vehicle bodies; points beyond
        # this recorded region are rejected, not projected onto a nearby lane.
        bounds=np.r_[points.min(axis=0)-15.,points.max(axis=0)+15.]
        region=LocalRoadRegion.from_opendrive(data,lanes,junctions,bounds)
        meta=dict(map_name=str(getattr(road_map,'name','unknown')),reference_hash=path_hash(points),
            route_samples=len(samples),missing_route_samples=missing,map_query_z=float(z),
            setup_map_queries=len(samples),setup_map_exports=1,
            setup_ms=(time.perf_counter()-started)*1000.,coverage_padding_m=15.,
            opendrive_sha256=hashlib.sha256(data).hexdigest())
        result=cls(region,meta)
        if directory is not None:
            directory=Path(directory); directory.mkdir(parents=True,exist_ok=True)
            (directory/'public_map_v24.xodr').write_bytes(data)
            (directory/'local_road_region_v26.json').write_text(
                json.dumps(result.metadata,ensure_ascii=False,indent=2),encoding='utf8')
        return result

    def audit(self,poses,length,width):
        self.statistics['audit_calls']+=1
        result=dict(accepted=False,complete=False,checked_points=0,witness_hash=None,
                    reason=None,first_rejection=None,accepted_junction_points=0)
        started=time.perf_counter(); digest=hashlib.sha256()
        try:
            if not all(math.isfinite(v) and v>0. for v in (length,width)): raise ValueError('Invalid body')
            poses=RoadCorridor.dense(poses)
            hl,hw=length/2.+.15,width/2.+.15
            u=np.linspace(-hl,hl,int(math.ceil(2*hl/.75))+1)
            v=np.linspace(-hw,hw,int(math.ceil(2*hw/.75))+1)
            box=np.array([(x,y) for x in u for y in v]+[(0.,0.)])
            c,s=np.cos(poses[:,2,None]),np.sin(poses[:,2,None])
            points=np.stack([box[None,:,0]*c-box[None,:,1]*s+poses[:,0,None],
                             box[None,:,0]*s+box[None,:,1]*c+poses[:,1,None]],axis=-1).reshape(-1,2)
            accepted,junction=self.region.classify(points)
            self.statistics['local_points']+=len(points)
            rejected=np.flatnonzero(~accepted)
            count=int(rejected[0])+1 if len(rejected) else len(points)
            # Same x/y/accepted witness format as v24, without a Python API loop.
            witness=np.empty(count,dtype=[('x','<f8'),('y','<f8'),('accepted','?')])
            witness['x'],witness['y'],witness['accepted']=points[:count,0],points[:count,1],accepted[:count]
            digest.update(witness.tobytes())
            result.update(checked_points=count,accepted_junction_points=int(np.sum(junction[:count])))
            if len(rejected):
                p=points[count-1]; detail=self.region.describe(p)
                reason=('outside_local_coverage' if not detail['covered'] else
                        'outside_task_corridor' if detail['driving'] else 'outside_driving_surface')
                result.update(reason=reason,first_rejection=dict(x=float(p[0]),y=float(p[1]),
                    lane=detail['lane'],junction=detail['junction'],is_junction=detail['is_junction'],
                    lane_width=detail['width']))
            else: result.update(accepted=True,complete=True)
        except (TypeError,ValueError,OverflowError,KeyError): result['reason']='invalid_geometry'
        finally: self.statistics['local_query_ms']+=(time.perf_counter()-started)*1000.
        return dict(result,witness_hash=digest.hexdigest())
