"""Traffic spacing contracts independent of CARLA and ego/game decisions."""
import math

from Planning_library.rv_decision import idm_equilibrium_speed


def positive(value, name):
    value = float(value)
    if not math.isfinite(value) or value <= 0.:
        raise ValueError('%s must be finite and positive' % name)
    return value


class FlowSpacing:
    """Choose cruise independently of density, then derive spawn cadence.

    The 5 m reference preserves the previous nominal cruise (~4.412 m/s at
    free_speed=6). Changing requested_clear_gap must not silently change it.
    Explicitly short interval overrides are errors, not a new speed request.
    """
    revision = 'spacing_v12'

    def __init__(self, free_speed=6., clear_gap=5., length=3.6, dt=.05,
                 cruise_speed=None, interval=None, min_center=None, g0=2., headway=.5):
        self.free_speed = positive(free_speed, 'free speed')
        self.requested_clear_gap = positive(clear_gap, 'clear gap')
        self.dt = positive(dt, 'dt')
        self.g0 = positive(g0, 'minimum following gap')
        self.headway = positive(headway, 'following headway')
        self.cruise_speed = (idm_equilibrium_speed(5., v0=self.free_speed,
            T=self.headway, g0=self.g0, a=2., b=2.5, delta=4.)
            if cruise_speed is None else positive(cruise_speed, 'cruise speed'))
        self.cruise_speed = positive(self.cruise_speed, 'cruise speed')
        self.interval_override = None if interval is None else positive(interval, 'spawn interval')
        self.min_center = None if min_center is None else positive(min_center, 'minimum center distance')
        self.length_source = 'nominal_pending_first_actor'
        self.set_length(length)

    def set_length(self, length, source=None):
        self.length = positive(length, 'vehicle length')
        self.target_clear_gap = max(self.requested_clear_gap,
            0. if self.min_center is None else self.min_center-self.length)
        self.following_gap = self.g0+self.cruise_speed*self.headway
        if self.target_clear_gap+1e-9 < self.following_gap:
            raise ValueError('Requested gap %.3f is below this model following requirement %.3f'
                             % (self.target_clear_gap, self.following_gap))
        self.target_center = self.target_clear_gap+self.length
        required = self.target_center/self.cruise_speed
        interval = required if self.interval_override is None else self.interval_override
        if interval+1e-9 < required:
            raise ValueError('Spawn interval %.3f is too short for actual cruise/length; need >= %.3f s'
                             % (interval, required))
        self.interval_frames = max(1, int(math.ceil(interval/self.dt-1e-9)))
        self.interval_seconds = self.interval_frames*self.dt
        self.predicted_center = self.cruise_speed*self.interval_seconds
        self.predicted_clear_gap = self.predicted_center-self.length
        if source is not None:
            self.length_source = source

    def metadata(self):
        return dict(revision=self.revision, free_speed=self.free_speed, cruise_speed=self.cruise_speed,
            requested_clear_gap=self.requested_clear_gap, target_clear_gap=self.target_clear_gap,
            measured_length=self.length, length_source=self.length_source,
            target_center=self.target_center, interval_seconds=self.interval_seconds,
            interval_frames=self.interval_frames, predicted_center=self.predicted_center,
            predicted_clear_gap=self.predicted_clear_gap, following_gap=self.following_gap, dt=self.dt)


def box_bounds(vertices):
    """World-axis bounds from all 8 physical bounding-box vertices.

    Using CARLA's transformed vertices includes box offsets, pitch and roll.
    It avoids treating actor origins or the nominal 3.6 m length as bumper ends.
    """
    points = list(vertices)
    if len(points) != 8:
        raise ValueError('Expected 8 CARLA bounding-box vertices')
    xs, ys = [float(p.x) for p in points], [float(p.y) for p in points]
    if not all(math.isfinite(v) for v in xs+ys):
        raise ValueError('Nonfinite traffic bounding box')
    bounds = min(xs), max(xs), min(ys), max(ys)
    if bounds[1] <= bounds[0] or bounds[3] <= bounds[2]:
        raise ValueError('Collapsed traffic bounding box')
    return bounds


def spawn_clearance(candidate, others):
    """Minimum bumper separation in the same corridor, including overlaps.

    others contains (actor_id, bounds). Vehicles on either side of a displaced
    spawn point are considered; all overlap/touching cases remain blocked.
    """
    minimum, actor = float('inf'), None
    for identity, bounds in others:
        if bounds[3] < candidate[2] or bounds[2] > candidate[3]:
            continue
        gap = max(candidate[0]-bounds[1], bounds[0]-candidate[1])
        if gap < minimum:
            minimum, actor = gap, identity
    return (None, None) if actor is None else (minimum, actor)
