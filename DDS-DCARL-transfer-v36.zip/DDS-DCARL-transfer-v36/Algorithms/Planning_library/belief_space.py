"""Finite hidden-state model for paper IV-A/B, equations 27-29 and 50-51.

Hidden state = (private driver type, current yield/rush intention). Observed
kinematics remain context; a type mean is never substituted for this belief.
The finite state space and likelihoods are an explicit left-turn approximation.
"""
import numpy as np

from Planning_library.rv_decision import RV_THETA


TYPES = ('conservative', 'normal', 'aggressive')
INTENTS = ('yield', 'rush')
HIDDEN_STATES = tuple((t, i) for t in TYPES for i in INTENTS)


def probability(values):
    p = np.asarray(values, dtype=float)
    if p.ndim != 1 or not len(p) or not np.all(np.isfinite(p)) or np.any(p < 0.):
        raise ValueError('Probability must be a finite nonnegative vector')
    total = float(p.sum())
    if total <= 0.:
        raise ValueError('Probability has zero mass')
    return p / total


def stochastic_matrix(values):
    m = np.asarray(values, dtype=float)
    if m.ndim != 2 or not np.all(np.isfinite(m)) or np.any(m < 0.) or not np.allclose(m.sum(1), 1.):
        raise ValueError('Transition/observation rows must sum to one')
    return m


def belief_step(belief, transition, likelihood, observation):
    """Eq.28 observation evidence and Bayes b'(s') proportional to Z*T*b.

    Rows of T are current states, columns next states; rows of Z are next
    states, columns observations. Impossible evidence is an error, not a reset.
    """
    b = probability(belief)
    t, z = stochastic_matrix(transition), stochastic_matrix(likelihood)
    if t.shape != (len(b), len(b)) or z.shape[0] != len(b):
        raise ValueError('Belief, transition and observation dimensions disagree')
    predicted = b.dot(t)
    evidence = predicted.dot(z)
    weight = predicted * z[:, int(observation)]
    if weight.sum() <= 0.:
        raise ValueError('Observation has zero probability under this model')
    return probability(weight), evidence, predicted


class DrivingBelief:
    """Causal, per-actor filter. Never consumes simulator yield labels/types.

    One update per trajectory decision. The transition queued for the previously
    executed action is used at the NEXT observation, never for a candidate that
    has merely been evaluated. Static private types and dynamic intentions have
    distinct roles. Tracks reset at episode boundaries.
    """
    def __init__(self, persistence=.8, likelihood=None):
        self.persistence = float(persistence)
        if not 0. <= self.persistence < 1.:
            raise ValueError('Intention persistence must be in [0,1)')
        # Observation bins: braking / slow, steady, accelerating. Engineering
        # likelihoods, not paper-provided or CARLA-calibrated probabilities.
        z = [[.75, .20, .05], [.05, .65, .30]] * len(TYPES)
        self.likelihood = stochastic_matrix(z if likelihood is None else likelihood)
        if self.likelihood.shape != (len(HIDDEN_STATES), 3):
            raise ValueError('Expected six hidden states and three observation bins')
        self.reset()

    def reset(self):
        self.tracks = {}
        self.pending = {}
        self.actor_id = None
        self.last_evidence = None
        self.updates = 0

    def vector(self, actor_id=None):
        actor_id = self.actor_id if actor_id is None else actor_id
        return self.tracks.get(actor_id, np.full(len(HIDDEN_STATES), 1. / len(HIDDEN_STATES))).copy()

    def transition(self, yield_by_type):
        t = np.zeros((len(HIDDEN_STATES), len(HIDDEN_STATES)))
        for k, kind in enumerate(TYPES):
            p = float(yield_by_type[kind])
            if not np.isfinite(p) or not 0. <= p <= 1.:
                raise ValueError('Yield probabilities must be in [0,1]')
            block = self.persistence * np.eye(2) + (1. - self.persistence) * np.asarray([[p, 1.-p]] * 2)
            t[2*k:2*k+2, 2*k:2*k+2] = block
        return t

    def observe(self, actor_id, observation):
        self.actor_id = actor_id
        if actor_id is None:
            self.last_evidence = None
            return self.vector()
        prior = self.vector(actor_id)
        transition = self.pending.pop(actor_id, np.eye(len(HIDDEN_STATES)))
        posterior, evidence, _ = belief_step(prior, transition, self.likelihood, observation)
        self.tracks[actor_id] = posterior
        self.last_evidence = float(evidence[int(observation)])
        self.updates += 1
        return posterior.copy()

    def execute(self, actor_id, yield_by_type):
        if actor_id is not None:
            self.pending[actor_id] = self.transition(yield_by_type)

    def predicted_yield(self, actor_id, yield_by_type):
        predicted = self.vector(actor_id).dot(self.transition(yield_by_type)).reshape(len(TYPES), 2)
        return {kind: (float(row[0] / row.sum()) if row.sum() > 0. else float(yield_by_type[kind]))
                for kind, row in zip(TYPES, predicted)}

    def type_posterior(self):
        return dict(zip(TYPES, self.vector().reshape(len(TYPES), 2).sum(1).tolist()))

    def theta(self):
        return sum(self.type_posterior()[kind] * RV_THETA[kind] for kind in TYPES)

    def entropy(self):
        p = self.vector()
        return float(-np.sum(p[p > 0.] * np.log(p[p > 0.])))
