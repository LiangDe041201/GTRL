"""Separate navigation completion from physical road forecast coverage."""
import math
import numpy as np

from Planning_library.forecast_v16 import clean_points, predict as base_predict


def road_continuation(navigation_route, last_waypoint, length=40., step=2.):
    """Append actual map Waypoint.next samples; never invent a terminal road.

    Same-lane successors are preferred, then the smallest heading change.
    Ambiguous branching, reverse geometry or missing coverage fails at setup.
    The returned path is forecast-only, not the task route or MPC path.
    """
    points = clean_points(navigation_route).tolist()
    waypoint, travelled = last_waypoint, 0.
    origin = waypoint.transform.location
    if math.hypot(origin.x-points[-1][0], origin.y-points[-1][1]) > 1.:
        raise ValueError('Navigation route endpoint does not match map waypoint')
    while travelled < length:
        tail = np.asarray(points[-1])-np.asarray(points[-2])
        choices = []
        for candidate in waypoint.next(step):
            loc = candidate.transform.location
            chord = np.asarray([loc.x, loc.y])-points[-1]
            distance = float(np.linalg.norm(chord))
            cosine = float(np.dot(tail, chord)/max(np.linalg.norm(tail)*distance, 1e-9))
            if not math.isfinite(distance+cosine) or distance < .1 or distance > 2.5*step or cosine < .7:
                continue
            same_lane = (getattr(candidate, 'road_id', None), getattr(candidate, 'lane_id', None)) == (
                         getattr(waypoint, 'road_id', None), getattr(waypoint, 'lane_id', None))
            choices.append((same_lane, cosine, candidate, distance))
        choices.sort(key=lambda c: (c[0], c[1]), reverse=True)
        if not choices or (len(choices) > 1 and choices[0][0] == choices[1][0]
                           and abs(choices[0][1]-choices[1][1]) < .02):
            raise ValueError('Missing or ambiguous physical road continuation after navigation goal')
        _, _, waypoint, distance = choices[0]
        loc = waypoint.transform.location
        points.append([float(loc.x), float(loc.y)])
        travelled += distance
    return clean_points(points)


def prediction_geometry(geometry, road_route, navigation_route):
    road, navigation = clean_points(road_route), clean_points(navigation_route)
    if len(road) <= len(navigation) or not np.allclose(road[:len(navigation)], navigation):
        raise ValueError('Forecast road must extend the unchanged navigation route')
    return dict(geometry, forecast_model='route_v17', forecast_route=road.tolist(),
        navigation_route=navigation.tolist(), navigation_end_is_stop=False,
        road_source='carla_waypoint_next', opponent_model='recovery_family_v17')


def predict(*args, **kwargs):
    return base_predict(*args, **kwargs)
