"""Observed motion plus an explicit, limited hidden response-parameter model.

beta is P(observed deceleration in an exposed, unconfounded 0.5 s window),
not a driver's private intent or the paper's uniquely identified game type.
The Beta posterior uses observable outcomes; exchangeability/calibration of
those windows is an assumption, not a demonstrated confidence guarantee.
"""
import math

from Planning_library.vehicle_observation import longitudinal_acceleration


def physical_state(vehicle):
    if vehicle is None:
        return None
    acc = (None if getattr(vehicle, 'acc_source', None) == 'unavailable'
           else longitudinal_acceleration(vehicle))
    values = [float(vehicle.x), float(vehicle.y), float(vehicle.v), acc, float(vehicle.yaw)]
    if any(v is not None and not math.isfinite(v) for v in values):
        raise ValueError('Physical state contains nonfinite observations')
    return dict(motion=values, fields=['x', 'y', 'v', 'acc', 'phi'], beta_true=None,
                acceleration_source=getattr(vehicle, 'acc_source', 'unavailable'))


class ResponseBelief:
    MODEL = 'exposed_deceleration_probability_beta_v22'

    def __init__(self, window=.5, threshold=-.3):
        if not math.isfinite(window) or window <= 0. or not math.isfinite(threshold) or threshold >= 0.:
            raise ValueError('Invalid observation window or deceleration threshold')
        self.window, self.threshold = float(window), float(threshold)
        self.reset()

    def reset(self):
        self.actor = None
        self.alpha = self.beta = 1.
        self.observations = 0
        self.start_speed = None
        self.elapsed = 0.
        self.exposed = False
        self.previous_eligible = False

    def update(self, actor, speed, dt, opportunity=False, confounded=False):
        if not math.isfinite(dt) or not 0. < dt <= 1.:
            raise ValueError('Belief update requires positive observed simulation time')
        if actor != self.actor:
            self.reset()
            self.actor = actor
        eligible = bool(actor is not None and opportunity and not confounded)
        applied, acceleration = False, None
        if speed is None or actor is None:
            self.start_speed, self.elapsed, self.exposed = None, 0., False
        else:
            speed = float(speed)
            if not math.isfinite(speed) or speed < 0.:
                raise ValueError('Invalid observed speed')
            if self.start_speed is None:
                self.start_speed, self.elapsed, self.exposed = speed, 0., True
            else:
                # Evidence describes the elapsed interval, whose opportunity
                # flag was known BEFORE the current observation/action.
                self.elapsed += dt
                self.exposed = self.exposed and self.previous_eligible
                if self.elapsed >= self.window-1e-9:
                    acceleration = (speed-self.start_speed)/self.elapsed
                    if self.exposed:
                        decelerated = acceleration < self.threshold
                        self.alpha += bool(decelerated)
                        self.beta += not bool(decelerated)
                        self.observations += 1
                        applied = True
                    self.start_speed, self.elapsed, self.exposed = speed, 0., True
        self.previous_eligible = eligible
        total = self.alpha+self.beta
        return dict(model=self.MODEL, actor_id=actor, alpha=self.alpha, beta=self.beta,
                    mean=self.alpha/total,
                    variance=self.alpha*self.beta/(total*total*(total+1.)),
                    observations=self.observations, evidence_applied=applied,
                    observed_window_acceleration=acceleration,
                    window_s=self.window, threshold_mps2=self.threshold,
                    status='posterior' if self.observations else 'prior',
                    private_intent_identified=False, calibrated=False)
