"""Short observable motion history and bounded RV counterfactuals.

No traffic-manager intent, action, zone label, future sample or learned reward
is used. These fixed engineering models are not calibrated intent posteriors.
"""
from collections import deque
import math

import numpy as np

from Planning_library.paper_turn_control import motion
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration)


def visible_leaders(rv, objects):
    vx, vy = motion(rv)
    speed = math.hypot(vx, vy)
    ux, uy = ((vx/speed, vy/speed) if speed > .05
              else (math.cos(rv.yaw), math.sin(rv.yaw)))
    result = []
    for other in objects:
        if vehicle_id(other) == vehicle_id(rv):
            continue
        dx, dy = other.x-rv.x, other.y-rv.y
        along, across = dx*ux+dy*uy, abs(-dx*uy+dy*ux)
        ovx, ovy = motion(other)
        front_speed = ovx*ux+ovy*uy
        if (along > 0. and front_speed >= -.1 and
                across < .5*(vehicle_size(rv, 'width', 2.)+vehicle_size(other, 'width', 2.))):
            gap=along-.5*(vehicle_size(rv, 'length', 4.)+vehicle_size(other, 'length', 4.))
            result.append((gap, max(front_speed, 0.)))
    return result


class MotionHistory:
    """Actor-specific two-second memory; reset at every episode boundary."""
    def __init__(self, cruise, dt=.05):
        self.cruise, self.dt = float(cruise), float(dt)
        self.actors = {}
        self.frame = 0

    def observe(self, objects, frame):
        self.frame = int(frame)
        for actor in objects:
            identity=vehicle_id(actor)
            if identity is None:
                continue
            speed=math.hypot(*motion(actor))
            state=self.actors.get(identity)
            if state is None or (frame-state['samples'][-1][0])*self.dt > .1+1e-9:
                state=dict(samples=deque(maxlen=int(round(2./self.dt))+1),p=.5,estimate_frame=None)
                self.actors[identity]=state
            if state['samples'] and state['samples'][-1][0] == frame:
                continue
            acceleration=longitudinal_acceleration(actor)
            if acceleration is None and state['samples']:
                old_frame, old_speed, _=state['samples'][-1]
                acceleration=(speed-old_speed)/((frame-old_frame)*self.dt)
            if acceleration is not None:
                acceleration=max(-3.,min(2.,acceleration))
            state['samples'].append((int(frame),speed,acceleration))
        self.actors={identity:state for identity,state in self.actors.items()
                     if (frame-state['samples'][-1][0])*self.dt <= 2.+1e-9}

    def estimate(self, rv, objects):
        identity=vehicle_id(rv)
        state=self.actors.get(identity)
        if rv is None or state is None or state['samples'][-1][0]!=self.frame:
            return .5, 'unavailable_motion_neutral_prior', dict(samples=0,span_s=0.,acceleration=None)
        if state['estimate_frame']==self.frame:
            return state['p'], state['source'], dict(state['evidence'])
        samples=list(state['samples'])
        frame,speed,acceleration=samples[-1]
        span=(frame-samples[0][0])*self.dt
        recent=[s for s in samples if (frame-s[0])*self.dt <= .5+1e-9]
        full_window=(recent[-1][0]-recent[0][0])*self.dt >= .5-1e-9
        explained=any(gap < 3.+.5*speed and fv < speed+.2
                      for gap,fv in visible_leaders(rv,objects))
        base=.5 if acceleration is None else .5-.3*math.tanh(acceleration/.8)
        if explained:
            probability,source=.5,'visible_leader_cause_ambiguous'
        elif acceleration is not None and acceleration > .3:
            # Recovery evidence takes effect immediately; old low-speed memory
            # must never keep a newly accelerating RV labelled as yielding.
            probability,source=min(state['p'],base),'observed_recovery'
        else:
            if full_window and max(s[1] for s in recent) <= .5*self.cruise:
                target,source=.8,'sustained_low_speed_unblocked'
            elif full_window and min(s[1] for s in recent) >= .85*self.cruise:
                target,source=.2,'sustained_cruise_unblocked'
            else:
                target,source=base,'bounded_observed_acceleration_proxy'
            fraction=1.-math.exp(-self.dt/.25)
            probability=state['p']+fraction*(target-state['p'])
        probability=max(.2,min(.8,float(probability)))
        evidence=dict(samples=len(samples),span_s=float(span),speed=float(speed),
                      acceleration=acceleration,visible_leader_explains_slowdown=explained)
        state.update(p=probability,source=source,evidence=evidence,estimate_frame=self.frame)
        return probability,source,dict(evidence)


def rv_action_track(rv, objects, times, cruise, yielding, acceleration=None):
    """Continue observed motion vs bounded slowing, never an invented recovery.

    The continue column uses current observed acceleration for at most one
    second, then holds that speed, as in the public execution audit. Future
    unobserved accelerations remain model uncertainty, not a safety guarantee.
    The yield column only slows toward min(current speed, 0.3*cruise).
    Visible following constraints can brake either column without teleporting.
    """
    vx,vy=motion(rv);speed=math.hypot(vx,vy)
    ux,uy=((vx/speed,vy/speed) if speed>.05 else (math.cos(rv.yaw),math.sin(rv.yaw)))
    observed=longitudinal_acceleration(rv) if acceleration is None else acceleration
    observed=0. if observed is None else max(-2.5,min(2.,float(observed)))
    leaders=visible_leaders(rv,objects)
    target=min(speed,.3*cruise)
    previous_t,position=0.,0.
    track=[]
    for value in times:
        t=float(value);duration=t-previous_t
        if duration < -1e-9:
            raise ValueError('Forecast times must be increasing')
        if yielding:
            wanted=min(0.,max(-2.5,(target-speed)/max(duration,.05)))
            if previous_t < 1.:
                wanted=min(wanted,observed)
        else:
            active=max(0.,min(t,1.)-min(previous_t,1.))
            wanted=observed*active/duration if duration>0. else 0.
        if leaders:
            gap,front_speed=min(((g+fv*previous_t-position,fv) for g,fv in leaders),key=lambda x:x[0])
            if gap < 2.+.5*speed:
                wanted=min(wanted,-min(2.5,max(0.,speed-front_speed)+max(0.,2.+.5*speed-gap)))
        next_speed=max(0.,speed+wanted*duration)
        position+=.5*(speed+next_speed)*duration
        speed=next_speed
        track.append((rv.x+ux*position,rv.y+uy*position,rv.yaw))
        previous_t=t
    return np.asarray(track)
