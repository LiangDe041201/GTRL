"""Rolling local trajectory selection on the frozen matrix-CG control chain.

Five geometric actions plus the original CG request form a six-action pool.
The CG intent/speed remain context; both rolling-defer and proceed paths can
be selected. A final guard override retracts the new path BEFORE submission.
EFE is deliberately disabled until this spatial learning chain is verified.
"""
import hashlib
import json
import math
from pathlib import Path
import time
import numpy as np
from Planning_library.candidate_learning_v19 import task_reward
from Planning_library.control_path_v15 import path_hash
from Planning_library.execution_guard import select_execution
from Planning_library.forecast_v18 import checked_prefix
from Planning_library.rolling_audit_v25 import CandidateAudit
from Planning_library.physical_belief_v22 import ResponseBelief,physical_state
from Planning_library.rolling_learning_v24 import RollingLearner
from Planning_library.rolling_trajectory_v24 import RollingFamily,OFFSETS,path_cost
from Planning_library.trajectory_evolution_v22 import TrajectoryEvolutionV22
from Planning_library.trajectory_guard import execution_acceleration
from Planning_library.trajectory_probe_v21 import TrajectoryProbeV21,_description,_vehicle,_array_hash
from Planning_library.vehicle_observation import vehicle_id,vehicle_size
from Planning_library.rolling_contract_v28 import control_evidence


class RollingPlannerV24(TrajectoryProbeV21):
    EXTRA_CONTROLLERS=5
    ACTION_OFFSETS=OFFSETS
    FAMILY_CLASS=RollingFamily
    LEARNER_CLASS=RollingLearner
    LEARNER_METADATA={}

    @staticmethod
    def default_action(allowed,costs):
        return min(allowed,key=lambda a:(costs[a],a))

    def __init__(self,phase,geometry,controllers,corridor,cruise=4.412022451715821,
                 checkpoint=None,directory=None,seed=1,epsilon=.3,period=.5,min_episodes=10):
        if (len(controllers)!=self.EXTRA_CONTROLLERS or not .1<=period<=2. or not 0.<=epsilon<=1.
                or geometry.get('forecast_model')!='route_v18'):
            raise ValueError('Invalid rolling solver pool, decision period or forecast')
        self.mode,self.geometry,self.cruise,self.last='observe',geometry,float(cruise),None
        self.controllers=list(controllers)
        self.phase,self.corridor,self.period,self.epsilon=phase,corridor,float(period),float(epsilon)
        self.family=self.FAMILY_CLASS(geometry.get('navigation_route',geometry['forecast_route']))
        self.learner=self.LEARNER_CLASS(phase,checkpoint,min_episodes=min_episodes)
        self.belief=ResponseBelief(); self.rng=np.random.RandomState(seed)
        self.directory=None if directory is None else Path(directory)
        self.local_episode=1; self.episode_offset=max((r['episode'] for r in self.learner.records),default=0)
        self.age=0.; self.action=None; self.control_key=None; self.engaged=False
        self.generation_id=0; self.profiles={}; self.profile_audits={}; self.proposals=[]
        self.generation=None; self._base=None; self.pose_reader=None
        self._cg_reference=None; self._cg_memory=None
        self.cg_restore_ms=0.
        if self.directory is not None:
            self.directory.mkdir(parents=True,exist_ok=True)
            metadata=dict(revision='rolling_trajectory_v24',phase=phase,actions=list(self.LEARNER_CLASS.ACTION_NAMES),
                offsets_m=list(self.ACTION_OFFSETS),decision_period_s=self.period,signature=self.learner.signature(),
                reference=self.family.reference.tolist(),reference_hash=self.family.reference_hash,
                execution_revision='isolated_cg_v25',
                audit_revision='shared_forecast_v25',
                candidate_contract_revision='rolling_control_evidence_v28',
                coordinate='reference_chord_arc',cg_intent_and_speed_frozen=True,
                beta_model=ResponseBelief.MODEL,beta_calibrated=False,efe_enabled=False,
                corridor=corridor.metadata,confidence_guarantee=False)
            metadata.update(self.LEARNER_METADATA)
            if checkpoint is not None:
                metadata['checkpoint_sha256']=hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest()
                target=self.directory/'rolling_model/frozen_input.json'; target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(Path(checkpoint).read_bytes())
            (self.directory/'rolling_metadata_v24.json').write_text(json.dumps(metadata,indent=2),encoding='utf8')

    def remember_cg_reference(self,controller):
        """Only the upper baseline planner may replace this geometry snapshot."""
        self._cg_reference=dict(path=np.array(controller.last_pathway,dtype=float,copy=True),
            source=controller.geometry_source,force_stop=bool(controller.geometry_force_stop))

    def restore_cg_reference(self,controller,dynamic):
        """Restore CG geometry/memory before every frame, keeping applied history.

        The active controller may have been exchanged with a spatial solver.
        Its last_u is the REAL applied control and must never be rolled back.
        CG warm starts are saved before a spatial candidate is activated.
        """
        reference=self._cg_reference
        if reference is None: return
        started=time.perf_counter()
        if controller.last_pathway is None or not np.array_equal(controller.last_pathway,reference['path']):
            controller.reset_global_path(reference['path'].copy(),dynamic)
        controller.geometry_source=reference['source']
        controller.geometry_force_stop=reference['force_stop']
        if self._cg_memory is not None:
            memory=self._cg_memory
            controller._warm_controls=None if memory['warm'] is None else memory['warm'].copy()
            controller._previous_observed_speed=memory['observed_speed']
            controller._solve_ok=memory['solve_ok']
        self.cg_restore_ms=(time.perf_counter()-started)*1000.

    @classmethod
    def description(cls,c,action,intent,path):
        identity=cls.LEARNER_CLASS.ACTION_NAMES[action] if action else intent+'_base'
        return dict(_description(c,identity,intent),action=action,path=np.asarray(path,dtype=float).tolist(),
                    path_hash=path_hash(path),control_evidence=control_evidence(c,action))

    def _generate(self,ego,seed,target):
        self.generation_id+=1
        self.profiles,self.profile_audits,self.proposals={},{},[]
        self.generation=dict(anchor=_vehicle(ego),previous=dict(seed['previous']),
            reference_progress=float(self.family.project(ego.x,ego.y)),reference_hash=self.family.reference_hash)
        for action,offset in enumerate(self.ACTION_OFFSETS[1:],1):
            proposal=dict(action=action,offset_m=offset,status='generation_rejected',error=None)
            try:
                p=self.family.generate(ego,seed['previous'],self.geometry['wheelbase'],offset,target)
                started=time.perf_counter()
                road=self.corridor.audit(p['poses'],self.length,self.width)
                self._timing['road_audit_ms']+=(time.perf_counter()-started)*1000.
                maximum=float(np.max(np.abs(p['curvature'])))
                limit=math.tan(min(1.,self.geometry['max_steer']))/self.geometry['wheelbase']
                proposal.update(parameters=p['parameters'],coefficients=p['coefficients'],initial=p['initial'],
                    start_arc=p['start_arc'],end_arc=p['end_arc'],path_hash=path_hash(p['path']),
                    max_curvature=maximum,curvature_limit=limit,path_road=road,
                    status='ready' if road['accepted'] and maximum<=limit else
                           'outside_corridor' if not road['accepted'] else 'curvature_limit')
                if proposal['status']=='ready': self.profiles[action],self.profile_audits[action]=p,road
            except ValueError as exc: proposal['error']=str(exc)
            self.proposals.append(proposal)

    def _solve(self,action,dynamic,seed,target,cg,road_right,center):
        p=self.profiles[action]; ego=dynamic.ego_vehicle
        controller=self._controller_for_action(action)
        started=time.perf_counter()
        controller.reset_global_path(p['path'],dynamic)
        controller.last_u=dict(seed['previous']); controller._previous_observed_speed=seed['observed_speed']
        controller._warm_controls=None; controller.set_game_context({},ego)
        self._timing['mpc_reset_ms']+=(time.perf_counter()-started)*1000.
        started=time.perf_counter()
        a,delta=controller.solve(dynamic,target,road_right,intersection_center=center)
        self._timing['mpc_solve_ms']+=(time.perf_counter()-started)*1000.
        c=dict(controller=controller,target=target,a=a,delta=delta,solve_ok=bool(controller._solve_ok),
            prediction=controller.last_prediction,plan=controller.last_control_plan if controller._solve_ok else None,
            times=controller.prediction_times,path=controller.last_pathway)
        desc=self._audit_candidate(c,action,dynamic,seed,cg)
        return c,desc,float(controller.last_solve_ms)

    def _audit_candidate(self,c,action,dynamic,seed,cg,horizon=6.,stop_after=None):
        ego,objects=dynamic.ego_vehicle,dynamic.objects
        rv=next((v for v in objects if vehicle_id(v)==cg.get('rv_id')),None)
        audit=CandidateAudit(ego,objects,rv,c['path'],seed['previous'],self.geometry,self.cruise,
            cg.get('motion_evidence',{}).get('acceleration'),stop_after=stop_after)
        execution,parts,forecasts=audit.evaluate(c,horizon)
        for key,value in audit.profile.items(): self._timing[key]+=value
        road=[]
        started=time.perf_counter()
        if c['prediction'] is not None:
            mpc_prefix,_=checked_prefix(c['prediction'],c['times'],stop_after)
            road.append(self.corridor.audit(mpc_prefix[[0,1,6]].T,self.length,self.width))
        for states,_,_ in forecasts:
            road.append(self.corridor.audit(states[[0,1,6]].T,self.length,self.width))
        self._timing['road_audit_ms']+=(time.perf_counter()-started)*1000.
        eligible=bool(c['solve_ok'] and execution['accepted'] and len(road)==3
                      and all(r['accepted'] for r in road) and all(v['admissible'] for v in parts))
        desc=self.description(c,action,('defer','proceed')[self.intent],c['path'])
        desc.update(execution=execution,components=parts,road_predictions=road,audit_profile=dict(audit.profile),
            eligible=eligible,cost=path_cost(c['path']),generation_id=self.generation_id)
        self._qualify(c,desc,action,ego,objects,forecasts)
        return desc

    def _controller_for_action(self,action):
        return self.controllers[action-1]

    def _qualify(self,candidate,description,action,ego,objects,forecasts):
        """Apply additional branch-specific requirements after the common audit."""

    def _permitted(self,primary,cg_record,original):
        return (cg_record['active'] and not primary.geometry_force_stop
                and primary.geometry_source=='planned' and original['target']>=.2)

    def _candidate_target(self,action,cg_target):
        return cg_target

    def _prepare_frame(self,dynamic,candidates,baseline,cg_record,seed):
        ego,objects=dynamic.ego_vehicle,dynamic.objects
        self._timing=dict(generation_ms=0.,mpc_reset_ms=0.,mpc_solve_ms=0.,execution_ms=0.,
            score_ms=0.,prediction_ms=0.,road_audit_ms=0.,selection_ms=0.,prediction_calls=0,
            prediction_hits=0,cg_restore_ms=self.cg_restore_ms,feedback_road_ms=0.)
        self._map_statistics=dict(getattr(self.corridor,'statistics',{}))
        self.intent=baseline; original=candidates[baseline]; primary=candidates[1]['controller']
        base_path=primary.last_pathway
        if self._cg_reference is None: self.remember_cg_reference(primary)
        cg_controller=original['controller']
        self._cg_memory=dict(warm=None if cg_controller._warm_controls is None else cg_controller._warm_controls.copy(),
            observed_speed=cg_controller._previous_observed_speed,solve_ok=bool(cg_controller._solve_ok))
        self.length,self.width=vehicle_size(ego,'length',4.5),vehicle_size(ego,'width',2.)
        rv=next((v for v in objects if vehicle_id(v)==cg_record.get('rv_id')),None)
        beta=self.belief.update(vehicle_id(rv),None if rv is None else float(rv.v),.05,
            opportunity=bool(cg_record['active']),confounded=bool(cg_record.get('motion_evidence',{}).get(
                'visible_leader_explains_slowdown',False)))
        tracking=primary.last_tracking_state or {}
        context=TrajectoryEvolutionV22.context(dynamic,dict(cg_record,tracking_l=tracking.get('l',0.),
            tracking_epsi=tracking.get('epsi',0.)),seed['previous'],original['target'])
        self.engaged=self.engaged or bool(cg_record['active'])
        return original,primary,base_path,context,beta,rv

    def propose(self,dynamic,candidates,baseline,cg_record,seed,road_right,center):
        started=time.perf_counter(); ego,objects=dynamic.ego_vehicle,dynamic.objects
        original,primary,base_path,context,beta,rv=self._prepare_frame(dynamic,candidates,baseline,cg_record,seed)
        key=(baseline,vehicle_id(rv),cg_record['phase'])
        decision=bool(self.engaged and (self.action is None or self.age>=self.period-1e-9 or key!=self.control_key))
        replanned=decision
        permitted=self._permitted(primary,cg_record,original)
        if decision:
            if permitted:
                generation_started=time.perf_counter()
                self._generate(ego,seed,float(original['target']))
                self._timing['generation_ms']=(time.perf_counter()-generation_started)*1000.
            else:
                self.profiles,self.proposals={},[]
                self.generation_id+=1
                self.generation=dict(anchor=_vehicle(ego),previous=dict(seed['previous']),
                    reference_progress=float(self.family.project(ego.x,ego.y)),reference_hash=self.family.reference_hash)
        names=('defer','proceed')
        records=[self.description(original,0,names[baseline],base_path)]
        records[0].update(eligible=True,cost=path_cost(base_path))
        choices={0:dict(original,path=base_path)}; extra_ms=0.
        solve_actions=list(self.profiles) if decision and permitted else (
            [self.action] if permitted and self.action in self.profiles else [])
        for action in solve_actions:
            target=self._candidate_target(action,float(original['target']))
            if target is None: continue
            c,desc,ms=self._solve(action,dynamic,seed,target,cg_record,road_right,center)
            choices[action]=c; records.append(desc); extra_ms+=ms
        allowed=sorted(c['action'] for c in records if c['eligible'])
        costs=[1e6]*len(self.LEARNER_CLASS.ACTION_NAMES)
        for c in records: costs[c['action']]=c['cost']
        invalidated=bool(not decision and self.action not in allowed and self.action is not None)
        if invalidated: decision=True; self.age=self.period
        if decision:
            selection_started=time.perf_counter()
            default=self.default_action(allowed,costs)
            self.learner.begin(context,beta,default,allowed,costs,self.episode_offset+self.local_episode)
            self.action=self.learner.choose(self.epsilon,self.rng)
            self.age,self.control_key=0.,key
            if invalidated: self.age=self.period
            self._timing['selection_ms']=(time.perf_counter()-selection_started)*1000.
        elif self.action is None: self.action=0
        action=self.action if self.action in allowed else 0
        chosen=choices[action]; request=next(c for c in records if c['action']==action)
        self._base=dict(original,path=base_path)
        self._frame_context=(context,beta,costs)
        self.last=dict(revision='rolling_trajectory_v24',phase=self.phase,active=bool(cg_record['active']),
            road_revision=self.corridor.metadata['revision'],
            execution_revision='isolated_cg_v25',cg_reference_hash=path_hash(self._cg_reference['path']),
            baseline_intent=baseline,baseline_path_hash=path_hash(base_path),base_candidates=[
                self.description(c,0,names[i],base_path) for i,c in enumerate(candidates)],
            reference_hash=self.family.reference_hash,previous=dict(seed['previous']),warm_hash=_array_hash(seed['warm']),
            observation=dict(ego=_vehicle(ego),others=[_vehicle(v) for v in objects]),
            physical=dict(ego=physical_state(ego),rv=physical_state(rv)),beta=beta,
            learning_context=list(context),
            decision=decision,replanned=replanned,invalidated=invalidated,generation_id=self.generation_id,
            generation=self.generation,proposals=self.proposals,candidates=records,allowed=allowed,
            request_id=request['id'],request=dict(request),requested_action=int(action),actual_action=int(action),
            changed_request=bool(action),retracted=False,final_reviewed=False,
            disable_foreign_clear_backup=bool(action and baseline==0),
            learning=dict(self.learner.last) if self.engaged else dict(source='inactive'),
            learning_enabled=self.phase=='train',efe_enabled=False,extra_solve_ms=extra_ms,
            decision_ms=(time.perf_counter()-started)*1000.,timing=self._timing)
        output=list(candidates)
        if action: output[baseline]=chosen
        return output

    def review_execution(self,current,ego,objects,previous,audit):
        self.last['final_reviewed']=True
        if not self.last['changed_request']: return None
        if audit['action']=='mpc' and audit['safe'] and not audit['override']:
            if path_hash(current.last_pathway)==self.last['request']['path_hash']: return None
        ms=current.last_solve_ms; base=self._base
        restored=self.activate(current,base['controller']); restored.last_solve_ms=ms
        selected,fallback=select_execution(ego,objects,base['path'],base['target'],
            execution_acceleration(base['a'],max(0.,ego.v),base['target']),base['delta'],previous,self.geometry,
            prediction=base['prediction'],prediction_times=base['times'],plan=base['plan'],solve_ok=base['solve_ok'])
        original=self.last['candidates'][0]
        self.last.update(actual_action=0,changed_request=False,retracted=True,
                         request_id=original['id'],request=dict(original))
        self.action=0; self.age=self.period
        return dict(controller=restored,candidate=base,selected=selected,audit=fallback)

    frame_reward = staticmethod(task_reward)

    def feedback(self,episode,frame,audit,applied,outcome=None):
        if int(applied['control_submit_ok'])!=1: raise RuntimeError('Control was not submitted')
        actual=self.last['actual_action']; intervention=bool(audit['override'] or audit['unavoidable'])
        reward=self.frame_reward(applied,.05,outcome,intervention)
        option_started=False
        if self.engaged:
            pending=self.learner.pending
            if pending is not None and pending['action']!=actual:
                context,beta,costs=self._frame_context
                self.learner.begin(context,beta,0,[0],costs,self.episode_offset+self.local_episode)
            if self.learner.pending is None:
                self.learner.start(actual); option_started=True
            self.learner.reward(reward,intervention)
        observed,pose=None,None
        if self.pose_reader is not None:
            p=self.pose_reader(); pose=[float(p.location.x),float(p.location.y),math.radians(p.rotation.yaw)]
            started=time.perf_counter()
            observed=self.corridor.audit([pose],self.length,self.width)
            self._timing['feedback_road_ms']=(time.perf_counter()-started)*1000.
        self.last['map_statistics']={key:value-self._map_statistics.get(key,0)
                                   for key,value in getattr(self.corridor,'statistics',{}).items()}
        self.last['feedback']=dict(episode=int(episode),frame=int(frame),reward=reward,outcome=outcome,
            intervention=intervention,actual_action=actual,guard_action=audit['action'],
            credited_state=self.learner.current if self.engaged else None,
            credited_episode=self.episode_offset+self.local_episode if self.engaged else None,
            option_started=option_started,
            applied_a=float(applied['a_cmd']),applied_delta=float(applied['delta_rad']),
            applied_target=float(applied['actuator_speed_target']),observed_pose=pose,observed_body=observed,
            observed_sim_frame=applied.get('sim_frame_after'))
        self.age+=.05
        if outcome is not None:
            self.learner.finish(); self.local_episode=int(episode)+1
            if self.phase=='train' and self.directory is not None:
                self.learner.save(self.directory/'rolling_model/rolling_model.json')

    def reset(self):
        super().reset(); self.belief.reset()
        self.age=0.; self.action=None; self.control_key=None; self.engaged=False
        self.profiles,self.proposals={},[]; self.generation=None; self._base=None
        self._cg_reference=None; self._cg_memory=None
        self.cg_restore_ms=0.
