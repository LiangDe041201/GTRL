"""Executed-return-driven search over a declared trajectory-parameter lattice.

CG still supplies the intent and default ratio 1. New ratios are proposals,
not certified improvements. Q uses empirical soft Bellman option backups;
episode-clustered WCV/BCV is a heuristic, not a guarantee for optimal Q.
The ratio lattice is an engineering limit, not arbitrary continuous RL.
"""
from collections import defaultdict
import json
import math
from pathlib import Path

import numpy as np

from Planning_library.soft_bellman import baseline_prior, soft_value_policy


class EvolutionLearner:
    RATIOS = tuple(round(.5+.05*i, 2) for i in range(11))
    WIDTHS = (3., .75, .5, 5., 5., 1., 1., 5., 1., .25, .1, 1., .15, 1., 1., 1.)

    def __init__(self, phase='train', checkpoint=None, gamma=2.**(-.05/10.),
                 alpha=.1, support=.05, min_episodes=10):
        if (phase not in ('train', 'eval', 'observe') or not 0. < gamma < 1.
                or not math.isfinite(alpha) or alpha <= 0. or not 0. < support <= 1.
                or min_episodes < 2):
            raise ValueError('Invalid trajectory learner configuration')
        self.phase, self.gamma, self.alpha, self.support = phase, float(gamma), float(alpha), float(support)
        self.min_episodes = int(min_episodes)
        self.prior = baseline_prior(len(self.RATIOS), self.index(1.), range(len(self.RATIOS)), support)
        self.nodes, self.q, self.records = {}, {}, []
        self.edges = defaultdict(list)
        self.current = self.pending = self.choice = None
        self.last, self.sweeps, self.residual = {}, 0, None
        if phase == 'eval' and checkpoint is None:
            raise ValueError('Frozen evaluation requires a new-schema checkpoint')
        if checkpoint is not None:
            data = json.loads(Path(checkpoint).read_text(encoding='utf8'))
            if data.get('signature') != self.signature():
                raise ValueError('Trajectory checkpoint action/state/reward signature differs')
            self.nodes, self.records = data['nodes'], data['records']
            self.q = {k: np.asarray(v, dtype=float) for k, v in data['q'].items()}
            if set(self.q) != set(self.nodes) or any(v.shape != (11,) or not np.isfinite(v).all() for v in self.q.values()):
                raise ValueError('Invalid saved trajectory values')
            for record in self.records:
                if record['state'] not in self.nodes or record['next'] is not None and record['next'] not in self.nodes:
                    raise ValueError('Invalid saved trajectory transition')
                self.edges[(record['state'], self.index(record['ratio']))].append(record)
        self.checkpoint_keys = frozenset(self.nodes)

    def signature(self):
        return dict(schema='trajectory_parameter_evolution_v22', ratios=list(self.RATIOS),
                    widths=list(self.WIDTHS), beta='exposed_deceleration_probability_beta_v22',
                    gamma=self.gamma, alpha=self.alpha, support=self.support,
                    min_episodes=self.min_episodes, option='same_intent_guarded_ratio_request',
                    belief_key='posterior_mean_quarter_and_variance_0.02',
                    reward='measured_task_v19_without_EFE', confidence_guarantee=False)

    @classmethod
    def index(cls, ratio):
        try:
            return cls.RATIOS.index(round(float(ratio), 8))
        except (ValueError, TypeError):
            raise ValueError('Ratio must belong to the declared 0.05 trajectory lattice')

    def begin(self, context, belief, intent, episode):
        x = np.asarray(context, dtype=float)
        a, b = float(belief['alpha']), float(belief['beta'])
        if (x.shape != (16,) or not np.isfinite(x).all() or intent not in (0, 1)
                or not all(math.isfinite(v) and v >= 1. for v in (a, b))):
            raise ValueError('Invalid physical context, response posterior or intent')
        beta_mean, variance = a/(a+b), a*b/((a+b)**2*(a+b+1.))
        posterior = dict(alpha=a, beta=b)
        key = json.dumps([np.rint(x/self.WIDTHS).astype(int).tolist(),
                          [int(round(beta_mean*4)), int(round(variance/.02))], int(intent)],
                         separators=(',', ':'))
        if key not in self.nodes:
            self.nodes[key] = dict(context=x.tolist(), belief=posterior, intent=int(intent),
                                   proposed=[.75], last_mutation_episodes=0)
            self.q[key] = np.zeros(11)
        self._close(key, posterior)
        self.current, self.episode = key, int(episode)
        self.current_belief = posterior
        self.choice = None
        self.iterate(3)
        return key

    def _values(self):
        return {k: soft_value_policy(q, self.prior, self.alpha)[0] for k, q in self.q.items()}

    def _samples(self, key, ratio, values=None):
        values = self._values() if values is None else values
        clusters = defaultdict(list)
        for r in self.edges.get((key, self.index(ratio)), []):
            target = r['reward'] + (r['discount']*values[r['next']] if r['next'] is not None else 0.)
            clusters[r['episode']].append(target)
        return [float(np.mean(v)) for v in clusters.values()]

    def bounds(self, ratio):
        values = self._values()
        groups = {r: self._samples(self.current, r, values) for r in self.RATIOS}
        targets = [x for v in groups.values() for x in v]
        span = max(targets)-min(targets) if targets else 0.
        samples = groups[float(ratio)]
        n = len(samples)
        mean = float(np.mean(samples)) if n else 0.
        sigma = float(np.std(samples, ddof=1)) if n > 1 else 0.
        delta = span*math.sqrt(math.log(20.)/(2*n)) if n else float('inf')
        cost = -self.alpha*math.log(self.prior[self.index(ratio)])
        return dict(n=n, mean=mean, sigma=sigma, delta=delta,
                    wcv=mean-delta-4*sigma/(n+1)-cost, bcv=mean+delta-cost)

    def propose(self):
        node = self.nodes[self.current]
        known = [r for r in self.RATIOS if self.edges.get((self.current, self.index(r)))]
        if self.phase != 'train':
            alt = [r for r in known if r != 1.]
            ratio = max(alt, key=lambda r: self.bounds(r)['wcv']) if alt else 1.
            return dict(ratio=ratio, parent=None, source='frozen_supported_proposal')
        proposed = node['proposed']
        counts = {r: len(self._samples(self.current, r)) for r in [1.]+proposed}
        episodes = {r['episode'] for r in self.records if r['state'] == self.current}
        if (len(proposed) < 3 and min(counts.values()) >= 2
                and len(episodes) >= node['last_mutation_episodes']+2):
            parent = max([1.]+proposed, key=lambda r: self.q[self.current][self.index(r)])
            for delta in (.1, -.1, .05, -.05):
                child = round(parent+delta, 2)
                if child in self.RATIOS and child != 1. and child not in proposed:
                    proposed.append(child)
                    node['last_mutation_episodes'] = len(episodes)
                    return dict(ratio=child, parent=parent, source='return_driven_mutation')
        ratio = min(proposed, key=lambda r: (counts.get(r, 0), -self.q[self.current][self.index(r)]))
        return dict(ratio=ratio, parent=None, source='coverage_proposal')

    def select(self, proposed, eligible, forced_ratio=None, epsilon=.3, rng=None):
        if self.current is None or not 0. <= epsilon <= 1.:
            raise ValueError('Begin a decision and provide a valid epsilon')
        proposed = float(proposed)
        self.index(proposed)
        allowed = [1.] + ([proposed] if eligible and proposed != 1. else [])
        if forced_ratio is not None and (self.phase != 'train' or float(forced_ratio) not in allowed):
            raise ValueError('Forced exploration is train-only and must be executable')
        base, alt = self.bounds(1.), self.bounds(proposed)
        certified = (proposed != 1. and eligible and min(base['n'], alt['n']) >= self.min_episodes
                     and alt['wcv'] > base['bcv'])
        selected = proposed if certified else 1.
        source = 'takeover' if certified else 'cg'
        if self.phase == 'observe':
            selected, source = 1., 'observe'
        elif forced_ratio is not None:
            selected, source = float(forced_ratio), 'explore'
        elif self.phase == 'train' and len(allowed) > 1 and epsilon > 0.:
            rng = np.random if rng is None else rng
            undercovered = min(base['n'], alt['n']) < self.min_episodes
            if rng.random_sample() < max(epsilon, .5 if undercovered else 0.):
                counts = {r: len(self._samples(self.current, r)) for r in allowed}
                least = [r for r in allowed if counts[r] == min(counts.values())]
                selected = float(rng.choice(least))
                source = 'explore'
        finite = lambda d: {k: (v if not isinstance(v, float) or math.isfinite(v) else None) for k, v in d.items()}
        self.choice = selected
        self.last = dict(source=source, proposed=proposed, requested=selected, eligible=bool(eligible),
                         certified=bool(certified), baseline_bounds=finite(base), candidate_bounds=finite(alt),
                         confidence_guarantee=False, unseen=self.current not in self.checkpoint_keys,
                         state=self.current, epsilon=epsilon if self.phase == 'train' else 0.)
        return selected

    def start(self, ratio):
        if self.pending is not None or self.choice != ratio:
            raise ValueError('Start only the selected actual request after closing the previous option')
        self.pending = dict(state=self.current, ratio=float(ratio), episode=self.episode,
                            belief=dict(self.current_belief), reward=0., discount=1., steps=0, interventions=0)

    def reward(self, value, intervention=False):
        if not math.isfinite(value):
            raise ValueError('Nonfinite measured reward')
        if self.pending is not None:
            self.pending['reward'] += self.pending['discount']*value
            self.pending['discount'] *= self.gamma
            self.pending['steps'] += 1
            self.pending['interventions'] += bool(intervention)

    def _close(self, next_key=None, next_belief=None):
        if self.pending is not None and self.pending['steps'] and self.phase == 'train':
            r = dict(self.pending, next=next_key, next_belief=next_belief)
            self.records.append(r)
            self.edges[(r['state'], self.index(r['ratio']))].append(r)
        self.pending = None

    def iterate(self, sweeps=50):
        if self.phase != 'train' or not self.edges:
            return
        for _ in range(sweeps):
            values = self._values()
            updates = {(k, a): float(np.mean(self._samples(k, self.RATIOS[a], values)))
                       for k, a in self.edges}
            self.residual = max(abs(self.q[k][a]-v) for (k, a), v in updates.items())
            for (k, a), v in updates.items():
                self.q[k][a] = v
            self.sweeps += 1
            if self.residual < 1e-7:
                break

    def finish(self):
        self._close()
        self.iterate()

    def save(self, path):
        if self.phase != 'train':
            raise ValueError('Only training can write a trajectory checkpoint')
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = dict(signature=self.signature(), nodes=self.nodes, records=self.records,
                    q={k: v.tolist() for k, v in self.q.items()})
        path.write_text(json.dumps(data, allow_nan=False), encoding='utf8')
