"""v8 common physical execution checks, independent of opponent policy labels.

RULE and CG receive identical checks. Safe means a sampled forecast meets the
declared margin, not a proof against every future manoeuvre by another driver.
"""
import math

import numpy as np

from Planning_library.actuator_interface import body_clear_of_band
from Planning_library.paper_turn_control import nearby_vehicles, motion, rectangle_gap
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration)


def path_steering(ego_x, ego_y, yaw, speed, path, wheelbase, maximum):
    points = np.asarray(path, dtype=float)
    if points.ndim != 2 or len(points) < 2 or not np.isfinite(points[:, :2]).all():
        raise ValueError('Execution guard requires a finite forward path')
    nearest = int(np.argmin(np.sum((points[:, :2]-[ego_x, ego_y])**2, axis=1)))
    distance, target = 0., points[-1]
    for i in range(nearest, len(points)-1):
        distance += float(np.linalg.norm(points[i+1, :2]-points[i, :2]))
        target = points[i+1]
        if distance >= 3.5+.4*max(speed, 0.):
            break
    dx, dy = float(target[0])-ego_x, float(target[1])-ego_y
    alpha = math.atan2(math.sin(math.atan2(dy, dx)-yaw),
                       math.cos(math.atan2(dy, dx)-yaw))
    delta = math.atan2(2.*wheelbase*math.sin(alpha), max(math.hypot(dx, dy), .5))
    return max(-maximum, min(maximum, delta))


def rollout(ego, path, target, first_a, first_delta, previous, geometry,
            horizon=2.3, lag=.3, plan=None, plan_times=None):
    """Bicycle rollout with bounded command rates and declared actuator lag.

    A plan contains optimized a/physical-steer columns; backups follow the same
    path using Pure Pursuit. No alternative strategic route is selected here.
    """
    dt = .05 if horizon <= 3. else .1
    times = np.arange(0., horizon+dt*.1, dt)
    states = np.zeros((7, len(times)))
    x, y, yaw, speed = float(ego.x), float(ego.y), float(ego.yaw), max(float(ego.v), 0.)
    measured = longitudinal_acceleration(ego)
    actual_a = 0. if measured is None else max(-3., min(2., measured))
    a, delta = float(previous['a']), float(previous['df'])
    wheelbase, maximum = geometry['wheelbase'], geometry['max_steer']
    for k, t in enumerate(times):
        states[0, k], states[1, k], states[5, k], states[6, k] = x, y, speed, yaw
        if k == len(times)-1:
            break
        if k == 0:
            a, delta = float(first_a), float(first_delta)
        elif plan is not None and (geometry.get('execution_horizon', 2.3) <= 2.3 or t < plan_times[-1]):
            j = min(int(np.searchsorted(plan_times[1:], t, side='right')), plan.shape[1]-1)
            a, delta = float(plan[0, j]), float(plan[1, j])
        else:
            wanted = max(-2., min(1.2, 1.5*(target-speed)))
            # Releasing brakes at standstill does not create body jerk.
            if speed < .1 and a < 0. and wanted >= 0.:
                a = 0.
            a += max(-2.*dt, min(2.*dt, wanted-a))
            wanted_delta = path_steering(x, y, yaw, speed, path, wheelbase, maximum)
            delta += max(-.9*dt, min(.9*dt, wanted_delta-delta))
        a, delta = max(-3., min(2., a)), max(-maximum, min(maximum, delta))
        if speed > target+.3 and a > 0.:
            a = 0.
        if target <= .01:
            a = min(a, -min(2., max(.3, speed*1.5)))
        if 'low_speed_brake_taper' in geometry and speed < 1.2:
            # Do not forecast full braking after the pedal layer releases
            # low-speed torque. This is a conservative hypothesis, not a
            # calibrated stopping-distance guarantee.
            a = max(a, -geometry['low_speed_brake_taper']*speed)
            actual_a = max(actual_a, -geometry['low_speed_brake_taper']*speed)
        fraction = 1. if lag <= 0. else min(1., dt/lag)
        change = fraction*(a-actual_a)
        # v10's brake servo cannot be audited as an instantaneous acceleration
        # actuator. Include a slower declared response in the sampled forecast.
        if 'brake_response_jerk' in geometry and change < 0.:
            change = max(change, -geometry['brake_response_jerk']*dt)
        actual_a += change
        next_speed = max(0., speed+dt*actual_a)
        mid_speed = .5*(speed+next_speed)
        beta = math.atan(.5*math.tan(delta))
        x += dt*mid_speed*math.cos(yaw+beta)
        y += dt*mid_speed*math.sin(yaw+beta)
        yaw += dt*mid_speed*math.sin(beta)/(wheelbase/2.)
        speed = next_speed
    return states, times


def clearance(states, times, objects, ego, measured_forecast=True, geometry=None):
    """Audit all observed boxes with CV and one-second measured-accel forecasts."""
    minimum, actor = float('inf'), None
    if geometry is not None and geometry.get('forecast_model') == 'route_v18':
        from Planning_library.opponent_forecast_v18 import tracks
        from Planning_library.matrix_turn_game import rectangle_gaps
        for v in nearby_vehicles(objects,ego,limit=None):
            for track in tracks(v,times,cruise=geometry.get('opponent_cruise',4.412022451715821),
                                ego=ego,ego_states=states,objects=objects):
                gap = float(np.min(rectangle_gaps(states,ego,v,track)))
                if gap < minimum:
                    minimum,actor = gap,vehicle_id(v)
        return minimum,actor
    if geometry is not None and geometry.get('forecast_model') == 'route_v17':
        from Planning_library.opponent_forecast_v17 import tracks
        for v in nearby_vehicles(objects, ego, limit=None):
            for track in tracks(v, times, cruise=geometry.get('opponent_cruise', 4.412022451715821)):
                for k in range(len(times)):
                    gap = rectangle_gap(float(states[0, k]), float(states[1, k]), float(states[6, k]),
                        vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.),
                        *track[k], vehicle_size(v, 'length', 4.), vehicle_size(v, 'width', 2.))
                    if gap < minimum:
                        minimum, actor = float(gap), vehicle_id(v)
        return minimum, actor
    for v in nearby_vehicles(objects, ego, limit=None):
        vx, vy = motion(v)
        speed = math.hypot(vx, vy)
        ux, uy = (vx/speed, vy/speed) if speed > .05 else (math.cos(v.yaw), math.sin(v.yaw))
        observed = longitudinal_acceleration(v) if measured_forecast else None
        accelerations = [0.] if observed is None else [0., max(-3., min(2., observed))]
        for acc in accelerations:
            for k, t in enumerate(times):
                active = min(float(t), 1.)
                if acc < 0.:
                    active = min(active, speed/-acc)
                future_speed = max(0., speed+acc*active)
                distance = speed*active+.5*acc*active**2+future_speed*(t-active)
                gap = rectangle_gap(float(states[0, k]), float(states[1, k]), float(states[6, k]),
                    vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.),
                    v.x+ux*distance, v.y+uy*distance, v.yaw,
                    vehicle_size(v, 'length', 4.), vehicle_size(v, 'width', 2.))
                if gap < minimum:
                    minimum, actor = float(gap), vehicle_id(v)
    return minimum, actor


def execution_forecast(ego, path, target, a, delta, previous, geometry, **kwargs):
    """Versioned forecast; the legacy numerical rollout remains frozen."""
    if geometry.get('forecast_model') in ('route_v16', 'route_v17', 'route_v18'):
        from Planning_library.forecast_v16 import predict
        return predict(ego, path, target, a, delta, previous, geometry, **kwargs)
    states, times = rollout(ego, path, target, a, delta, previous, geometry, **kwargs)
    return states, times, None


class TurnFeasibilityV8:
    """One launch check; an all-phase execution audit follows the MPC solve."""
    def __init__(self, geometry):
        self.geometry = dict(geometry, max_steer=min(1., geometry['max_steer']))
        self.reset()

    def reset(self):
        self.launched, self.last = False, {}

    def target(self, ego, objects, path, nominal, standoff, previous_a, committed=False):
        nominal, sd = max(0., float(nominal)), float(standoff)
        actors = nearby_vehicles(objects, ego, limit=None)
        inside = sd <= 0.
        phase = 'cleared' if body_clear_of_band(ego) else 'merging' if inside else 'approach'
        gap, conflict, forecast_valid = float('inf'), None, True
        if sd <= 18. or inside:
            steer = path_steering(ego.x, ego.y, ego.yaw, ego.v, path,
                                 self.geometry['wheelbase'], self.geometry['max_steer'])
            states, times, forecast = execution_forecast(ego, path, nominal, previous_a, steer,
                dict(a=previous_a, df=steer), self.geometry, horizon=6.)
            gap, conflict = clearance(states, times, actors, ego, measured_forecast=False, geometry=self.geometry)
            forecast_valid = forecast is None or forecast['valid']
            if not forecast_valid and self.geometry.get('forecast_model') not in ('route_v17','route_v18'):
                gap = -1000.  # Unknown coverage is never an authorization.
        safe = gap >= .35 and forecast_valid
        if not inside:
            self.launched = safe
            if sd <= 18.:
                phase = 'entering' if safe else 'waiting'
        self.last = dict(profile='paper_v8', phase=phase, safe=safe,
            min_gap=None if math.isinf(gap) else gap, conflict_id=conflict,
            forecast_valid=forecast_valid,
            threat_ids=[vehicle_id(v) for v in actors], body_clear=body_clear_of_band(ego))
        # Inside requests still undergo the same execution audit as every other
        # frame. Neither committed nor body_clear exempts any nearby opponent.
        if safe or inside:
            return nominal
        return min(nominal, math.sqrt(2.*1.2*max(sd-2.-max(ego.v, 0.)*.4, 0.)))


def select_execution(ego, objects, path, nominal, proposed_a, proposed_delta, previous,
                     geometry, prediction=None, prediction_times=None, plan=None,
                     solve_ok=True, allow_clear=True, alternative=None, stop_after=None):
    """Keep an admissible MPC request; otherwise compare brake and clear backups.

    All phases, and failed-solve fallback controls, pass through this function.
    If every sampled option is unsafe the least-penetrating option is returned
    with unavoidable=True; that condition can never pass as a safety success.
    """
    if geometry.get('forecast_model') == 'route_v18':
        from Planning_library.execution_guard_v18 import select_execution as select_v18
        return select_v18(ego,objects,path,nominal,proposed_a,proposed_delta,previous,geometry,
            prediction=prediction,prediction_times=prediction_times,plan=plan,solve_ok=solve_ok,
            allow_clear=allow_clear,alternative=alternative,stop_after=stop_after)
    if stop_after is not None:
        raise ValueError('Reversible entry requires the route_v18 execution forecast')
    candidates = []
    geometry = dict(geometry, max_steer=min(1., geometry['max_steer']))
    actors = nearby_vehicles(objects, ego, limit=None)

    def evaluate(name, a, delta, target, optimized=False):
        gaps, threats, forecasts = [], [], []
        if optimized and prediction is not None:
            gap, threat = clearance(prediction, prediction_times, actors, ego, geometry=geometry)
            gaps.append(gap); threats.append(threat)
        for lag in (0., .4):
            states, times, forecast = execution_forecast(ego, path, target, a, delta, previous, geometry, lag=lag,
                horizon=geometry.get('execution_horizon', 2.3),
                plan=plan if optimized else None, plan_times=prediction_times if optimized else None)
            gap, threat = clearance(states, times, actors, ego, geometry=geometry)
            if forecast is not None:
                forecasts.append(forecast)
                if not forecast['valid'] and geometry.get('forecast_model') != 'route_v17':
                    gap = -1000.
            gaps.append(gap); threats.append(threat)
        i = min(range(len(gaps)), key=lambda j: gaps[j])
        candidate = dict(action=name, a=float(a), delta=float(delta), target=float(target),
                         gap=float(gaps[i]), actor=threats[i], safe=bool(gaps[i] >= .2))
        if forecasts:
            candidate.update(forecasts=forecasts, forecast_valid=all(f['valid'] for f in forecasts))
            if geometry.get('forecast_model') == 'route_v17':
                candidate['safe'] = candidate['safe'] and candidate['forecast_valid']
        candidates.append(candidate)
        return candidate

    if solve_ok and prediction is not None:
        proposal = evaluate('mpc', proposed_a, proposed_delta, nominal, optimized=True)
        if proposal['safe']:
            selected = proposal
            return selected, dict(action='mpc', safe=True, unavoidable=False, override=False,
                                  proposed_gap=proposal['gap'], candidates=candidates)
    else:
        proposal = None  # Never trust a failed optimizer's open-loop fallback.
    steering = path_steering(ego.x, ego.y, ego.yaw, ego.v, path,
                            geometry['wheelbase'], geometry['max_steer'])
    steering = max(previous['df']-.045, min(previous['df']+.045, steering))
    brake = evaluate('brake', -min(2., max(.3, ego.v*1.5)), steering, 0.)
    if allow_clear and nominal > .01:
        evaluate('clear', 1.2 if ego.v < nominal else 0., steering, nominal)
    safe = [c for c in candidates if c['safe']]
    # Outside the band a safe stop has priority over forcing a new launch.
    from Planning_library.boundary_safety import wait_standoff
    outside = wait_standoff(ego.x, ego.y, ego.yaw, vehicle_size(ego, 'length', 4.5),
                            vehicle_size(ego, 'width', 2.), -138., 1.) > 0.
    if not any(c.get('forecast_valid', True) for c in candidates):
        selected = brake
    elif outside and brake['safe']:
        selected = brake
    else:
        valid = [c for c in candidates if c.get('forecast_valid', True)]
        pool = (safe or valid) if geometry.get('forecast_model') == 'route_v17' else (safe or candidates)
        selected = max(pool, key=lambda c: (c['gap'], c['action'] == 'clear'))
    return selected, dict(action=selected['action'], safe=selected['safe'], unavoidable=not bool(safe),
        override=selected['action'] != 'mpc',
        proposed_gap=None if proposal is None else proposal['gap'], candidates=candidates)
