"""Shared-candidate belief/EFE and empirical soft learning, without CARLA.

Actions are requests to the COMMON GUARDED controller, not unshielded controls.
T describes observable-motion-conditioned intent persistence in seconds; direct
ego influence on private intent is not identified. Action-dependent physical
outcomes come from the same v18 MPC/traffic forecasts used by the game.
Confidence remains an episode-clustered bootstrap heuristic, not a Q* bound.
"""
from collections import defaultdict
import json
import math
from pathlib import Path

import numpy as np

from Planning_library.active_inference import preferred_observation, observation_entropy
from Planning_library.belief_space import DrivingBelief, probability, stochastic_matrix
from Planning_library.soft_bellman import BeliefSoftLearner, information_cost, soft_value_policy


def frame_discount(half_life_seconds, dt=.05):
    if not math.isfinite(half_life_seconds) or half_life_seconds <= 0. or not 0. < dt <= 1.:
        raise ValueError('Discount half-life and simulation step must be positive')
    return 2.**(-dt/half_life_seconds)


def joint_efe(conditional, belief, preference=None):
    z, b = stochastic_matrix(conditional), probability(belief)
    if z.shape != (6,4) or len(b) != 6:
        raise ValueError('EFE requires six joint hidden states and four outcomes')
    pref = preferred_observation() if preference is None else probability(preference)
    if len(pref) != 4 or np.any(pref <= 0.):
        raise ValueError('All four outcome preferences need positive support')
    marginal = b.dot(z)
    mask = marginal > 0.
    risk = float(np.sum(marginal[mask]*np.log(marginal[mask]/pref[mask])))
    ambiguity = float(sum(b[i]*observation_entropy(z[i]) for i in range(6)))
    return dict(risk=max(0.,risk),ambiguity=ambiguity,reward=-max(0.,risk)-ambiguity,
                marginal=marginal.tolist(),conditional=z.tolist(),belief=b.tolist())


def outcome_distribution(part, standoff, gap_sigma=.25, progress_sigma=1.):
    """Declared soft observation model of existing robust forecast summaries.

    All hypotheses are conservative envelopes, not calibrated probabilities.
    Collision classification has priority over stalled/inefficient progress.
    A near-zero target cannot hide a collision in a 'safe waiting' category.
    """
    if not (math.isfinite(gap_sigma) and gap_sigma > 0. and progress_sigma > 0.):
        raise ValueError('Outcome prediction scales must be positive')
    if not part.get('forecast_valid',False):
        return np.array([0.,0.,0.,1.])
    gap = part.get('min_gap',part.get('gap'))
    gap = 100. if gap is None else float(gap)
    if not math.isfinite(gap):
        raise ValueError('Nonfinite outcome clearance')
    cdf = lambda x: .5*(1.+math.erf(x/math.sqrt(2.)))
    blocked = cdf((.15-gap)/gap_sigma)
    tight = max(0.,cdf((.5-gap)/gap_sigma)-blocked)
    clear = max(0.,1.-blocked-tight)
    forecasts = part['forecasts']
    progress = min(float(f['progress_m']) for f in forecasts)
    # Passing the common entry boundary is a progress outcome, not a proof of
    # completed merging; all six-second collision envelopes still apply.
    stall = cdf((max(0.,float(standoff))-progress)/progress_sigma)
    return probability([clear*(1.-stall),tight*(1.-stall),(clear+tight)*stall,blocked])


def candidate_efe(components, belief, standoff, preference=None, gap_sigma=.25):
    result = []
    for row in components:
        if len(row) != 2:
            raise ValueError('Expected continue/yield columns')
        columns = [outcome_distribution(p,standoff,gap_sigma) for p in row]
        # Hidden-state order is (conservative,normal,aggressive) x (yield,rush).
        conditional = np.array([columns[1],columns[0]]*3)
        result.append(joint_efe(conditional,belief,preference))
    return result


def task_reward(applied, dt=.05, outcome=None, intervention=False):
    """Bounded measured driving utility, separate from legacy task reporting.

    Rate terms use simulation seconds; terminal utility occurs exactly once.
    There is no predicted safety penalty here: EFE owns that shaping term.
    """
    speed = max(0.,float(applied['ego_v_after']))
    acc = float(applied['a_cmd'])
    rate = .1*min(speed/4.,1.)-.02-.01*min((acc/3.)**2,1.)-.02*bool(intervention)
    terminal = {None:0.,'complete':5.,'collision':-10.,'stuck':-5.}
    if outcome not in terminal or not math.isfinite(rate):
        raise ValueError('Invalid realized task outcome/control')
    return dt*rate+terminal[outcome]


class CandidateBelief(DrivingBelief):
    """Time-aware motion filter; evaluated/requested actions are never queued."""
    def __init__(self,persistence=.8,likelihood=None,observation_period=.5):
        if not math.isfinite(observation_period) or observation_period <= 0.:
            raise ValueError('Observation period must be positive')
        self.observation_period = float(observation_period)
        super().__init__(persistence,likelihood)

    def reset(self):
        super().reset()
        self._elapsed = {}
        self.observation_applied = False

    def transition(self,p_yield,seconds):
        if not 0. <= p_yield <= 1. or not math.isfinite(seconds) or seconds < 0.:
            raise ValueError('Invalid intent forecast probability/time')
        persistence = self.persistence**seconds
        t = np.zeros((6,6))
        for k,bias in enumerate((.15,0.,-.15)):
            p = max(.05,min(.95,p_yield+bias))
            t[2*k:2*k+2,2*k:2*k+2] = persistence*np.eye(2)+(1.-persistence)*np.array([[p,1.-p]]*2)
        return t

    def update(self,actor,observation,p_yield,dt,following=False):
        if not math.isfinite(dt) or dt <= 0.:
            raise ValueError('Belief updates need elapsed simulation time')
        new = actor not in self.tracks or actor != self.actor_id
        self.actor_id = actor
        self.observation_applied,self.last_evidence = False,None
        if actor is None:
            return self.vector()
        # A reappearing selected actor starts a fresh prior rather than silently
        # applying one old transition over an unknown observation gap.
        prior = np.full(6,1./6.) if new else self.vector(actor)
        predicted = prior if new else prior.dot(self.transition(p_yield,dt))
        elapsed = self.observation_period if new else self._elapsed.get(actor,0.)+dt
        if elapsed >= self.observation_period-1e-9:
            elapsed = 0.
            if observation is not None and not following:
                likelihood = self.likelihood[:,int(observation)]
                self.last_evidence = float(predicted.dot(likelihood))
                predicted = probability(predicted*likelihood)
                self.updates += 1
                self.observation_applied = True
        self.tracks[actor],self._elapsed[actor] = probability(predicted),elapsed
        return self.vector(actor)

    def predicted(self,actor,p_yield,seconds):
        return probability(self.vector(actor).dot(self.transition(p_yield,seconds)))


class CandidateLearner(BeliefSoftLearner):
    """Empirical option backups; exact paper-style WCV action selection.

    Baseline is the same-frame CG request. Context uses relative motion,
    applied-control history and phase; this grid is an approximation.
    Eval creates zero-valued RAM nodes for unseen states but never trains/saves.
    """
    SCHEMA = 'guarded_candidate_soft_v19'
    CONTEXT_WIDTHS = (3.,1.,5.,1.,1.,3.,1.,1.,.15,1.)

    def __init__(self,phase='train',checkpoint=None,trust_enabled=True,
                 confidence_range='local_empirical',**kwargs):
        if phase not in ('train','eval'):
            raise ValueError('Candidate phase must be train/eval')
        self.phase,self.trust_enabled = phase,bool(trust_enabled)
        if confidence_range not in ('local_empirical','known_support'):
            raise ValueError('Unknown confidence range interpretation')
        self.confidence_range=confidence_range
        self._episode_records = []
        self._unseen = False
        super().__init__(2,**kwargs)
        if phase=='eval' and checkpoint is None:
            raise ValueError('Frozen evaluation requires a trained checkpoint')
        if checkpoint is not None:
            data = json.loads(Path(checkpoint).read_text(encoding='utf8'))
            if data['signature'] != self.signature():
                raise ValueError('Candidate checkpoint configuration differs')
            self.nodes,self.records = data['nodes'],data['records']
            self.q = {k:np.array(v,dtype=float) for k,v in data['q'].items()}
            self.sweeps,self.residual = data['sweeps'],data['residual']
            self.edges = defaultdict(list)
            for r in self.records:self.edges[(r['state'],r['action'])].append(r)

    def signature(self):
        return dict(super().signature(),min_episodes=self.min_episodes,significance=self.significance,
            range_fallback=self.range_fallback,selection='paper_wcv' if self.trust_enabled else 'soft_policy_argmax',
            trust_enabled=self.trust_enabled,
            confidence_range=self.confidence_range,
            action_semantics='defer_proceed_requests_to_common_guard')

    def confidence(self,key):
        values={k:soft_value_policy(self.q[k],n['prior'],self.alpha)[0] for k,n in self.nodes.items()}
        groups={a:self._cluster_targets(self.edges.get((key,a),[]),values)
                for a in self.nodes[key]['allowed']}
        targets=[v for samples in groups.values() for v in samples]
        span=max(targets)-min(targets) if targets else 0.
        self._range_used=(max(self.range_fallback,span) if self.confidence_range=='known_support' else span)
        result={}
        for a,samples in groups.items():
            n=len(samples);mean=float(np.mean(samples)) if n else 0.
            sigma=float(np.std(samples,ddof=1)) if n>1 else 0.
            delta=self._range_used*math.sqrt(math.log(1./self.significance)/(2*n)) if n else float('inf')
            result[a]=dict(n=n,mean=mean,sigma=sigma,delta=delta,wcv=mean-delta-4*sigma/(n+1),bcv=mean+delta)
        return result

    def state(self,*args):
        n = len(self.nodes)
        key = super().state(*args)
        self._unseen = len(self.nodes)>n
        return key

    def iterate(self,*args,**kwargs):
        if self.phase=='train':return super().iterate(*args,**kwargs)

    def select(self,explore_action=None,trust_enabled=None,rng=None,epsilon=0.):
        if self.current is None or not 0. <= epsilon <= 1.:
            raise ValueError('Begin decision and provide a valid exploration probability')
        rng = np.random if rng is None else rng
        node,q = self.nodes[self.current],self.q[self.current]
        rule,allowed = node['rule'],node['allowed']
        prior = node['prior']
        value,optimum = soft_value_policy(q,prior,self.alpha)
        stats = self.confidence(self.current)
        enabled = self.trust_enabled if trust_enabled is None else bool(trust_enabled)
        certified = [a for a in allowed if a!=rule and stats[a]['n']>=self.min_episodes
                     and stats[rule]['n']>=self.min_episodes and stats[a]['wcv']>stats[rule]['bcv']]
        greedy = max(certified,key=lambda a:stats[a]['wcv']) if certified and enabled else rule
        if not enabled and not self._unseen:
            greedy = max(allowed,key=lambda a:optimum[a])
        if self.phase=='eval':epsilon=0.
        counts = {a:len({r['episode'] for r in self.edges.get((self.current,a),[])}) for a in allowed}
        least = [a for a in allowed if counts[a]==min(counts.values())]
        if self.phase=='train' and epsilon>0. and len(allowed)>1 and min(counts.values())<self.min_episodes:
            epsilon=max(epsilon,.5)
        policy = np.zeros(2);policy[greedy]=1.-epsilon
        policy[least] += epsilon/len(least)
        source = 'takeover' if greedy!=rule else 'cg'
        if explore_action is not None:
            if self.phase=='eval' or int(explore_action) not in allowed:
                raise ValueError('Exploration is forbidden in eval/outside admissible requests')
            action=int(explore_action);policy[:]=0.;policy[action]=1.;source='explore'
        elif epsilon and rng.random_sample()<epsilon:
            action=int(rng.choice(least));source='explore'
        else:action=int(greedy)
        self.choice=action
        self.last=dict(source=source,selection_rule='paper_wcv' if enabled else 'soft_policy_argmax',certified=certified,
            behavior_policy=policy.tolist(),baseline_policy=list(prior),soft_policy=optimum.tolist(),
            information_cost=information_cost(policy,prior,self.alpha),
            soft_information_cost=information_cost(optimum,prior,self.alpha),soft_value=float(value),
            q=q.tolist(),samples=counts,unseen_state=self._unseen,epsilon=epsilon,
            confidence_kind='episode_clustered_bootstrap_heuristic',
            range_mode=self.confidence_range,range_used=self._range_used,
            known_return_range=self.range_fallback,confidence_guarantee=False,
            bounds={a:{k:(v if math.isfinite(v) else None) for k,v in s.items()} for a,s in stats.items()})
        return action,[stats[a]['bcv'] if a==rule else stats[a]['wcv'] if a in stats else -1e9
                       for a in range(2)]

    def record_reward(self,reward,forced=False):
        if self.phase=='eval' or self.pending is None:return
        # The action is a GUARDED REQUEST. Retain failures/interventions rather
        # than censoring risky requests and calling them unshielded samples.
        self.pending['intervention_steps']=self.pending.get('intervention_steps',0)+int(forced)
        super().record_reward(reward,forced=False)

    def _close(self,next_key=None):
        p=self.pending
        if self.phase=='train' and p is not None and p['steps']:
            r=dict(state=p['state'],action=p['action'],reward=p['reward'],discount=p['discount'],
                steps=p['steps'],next=next_key,episode=p['episode'],
                behavior_information_cost=p['information_cost'],belief=p['belief'],context=p['context'],
                next_belief=self.current_belief.tolist() if next_key is not None else None,
                next_context=self.current_context.tolist() if next_key is not None else None,
                intervention_steps=p.get('intervention_steps',0))
            self.records.append(r);self.edges[(r['state'],r['action'])].append(r)
            self._episode_records.append(r)
        self.pending=None

    def finish(self):
        self._close(None)
        if self.phase=='train':
            tail=0.
            for r in reversed(self._episode_records):
                tail=r['reward']+r['discount']*tail
                r['mc_behavior_return']=tail
            if self.out_dir is not None and self._episode_records:
                with (self.out_dir/'belief_transitions.jsonl').open('a',encoding='utf8') as stream:
                    for r in self._episode_records:stream.write(json.dumps(r,allow_nan=False)+'\n')
            self.iterate();self.save()
        self._episode_records=[]
        self.current,self.choice=None,None

    def save(self):
        if self.phase=='train':super().save()
