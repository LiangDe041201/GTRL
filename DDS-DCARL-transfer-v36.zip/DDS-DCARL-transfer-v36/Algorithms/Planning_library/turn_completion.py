"""Geometric completion checks shared by the simulator and offline tests."""
import math

import numpy as np


def completion_metrics(x, y, yaw, goal_x, goal_y, goal_yaw, reference,
                       max_goal_distance=4., max_lateral_distance=2.,
                       max_heading_error=math.radians(20), min_progress=.9):
    """Require arrival, path proximity and alignment with the destination lane.

    The 2 m path tolerance includes the configured +/-1.5 m lateral targets.
    Thresholds are evaluation choices, not claims about the paper's criteria.
    """
    result = dict(strict_complete=False, goal_distance=None,
                  path_distance=None, heading_error=None, path_progress=None)
    pose = np.asarray([x, y, yaw, goal_x, goal_y, goal_yaw], dtype=float)
    path = np.asarray(reference, dtype=float)
    if (not np.all(np.isfinite(pose)) or path.ndim != 2 or
            path.shape[0] < 2 or path.shape[1] < 2 or
            not np.all(np.isfinite(path[:, :2]))):
        return result
    path = path[:, :2]
    segments = np.diff(path, axis=0)
    lengths = np.linalg.norm(segments, axis=1)
    valid = lengths > 1e-9
    if not np.any(valid):
        return result
    starts = path[:-1][valid]
    segments = segments[valid]
    lengths = lengths[valid]
    fractions = np.clip(np.sum((pose[:2] - starts) * segments, axis=1) /
                        lengths ** 2, 0., 1.)
    projections = starts + fractions[:, None] * segments
    distances = np.linalg.norm(projections - pose[:2], axis=1)
    nearest = int(np.argmin(distances))
    cumulative = np.r_[0., np.cumsum(lengths)]
    progress = float((cumulative[nearest] + fractions[nearest] * lengths[nearest]) /
                     cumulative[-1])
    goal_distance = math.hypot(x - goal_x, y - goal_y)
    heading_error = abs(math.atan2(math.sin(yaw - goal_yaw),
                                  math.cos(yaw - goal_yaw)))
    path_distance = float(distances[nearest])
    result.update(goal_distance=goal_distance, path_distance=path_distance,
                  heading_error=heading_error, path_progress=progress,
                  strict_complete=bool(goal_distance < max_goal_distance and
                                       path_distance <= max_lateral_distance and
                                       heading_error <= max_heading_error and
                                       progress >= min_progress))
    return result
