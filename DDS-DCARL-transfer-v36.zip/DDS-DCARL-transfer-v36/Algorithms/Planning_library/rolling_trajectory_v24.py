"""Receding local d(s) candidates; reference route and CG speed stay explicit.

This adapts the paper's polynomial action selection to a turning reference.
It is not the paper's quartic s(t)/quintic d(t) implementation. Geometry is
rebuilt at each upper-level decision and tracked only until the next decision.
"""
import math
import numpy as np
from Planning_library.spatial_trajectory_v23 import SpatialFamily, quintic_boundary, evaluate


OFFSETS = (None, -.4, -.2, 0., .2, .4)
ACTION_NAMES = ('cg_default','offset_-0.40','offset_-0.20','offset_+0.00','offset_+0.20','offset_+0.40')


def path_cost(path):
    """Fixed geometry cost, no learned values and no observed future outcome."""
    p=np.asarray(path,dtype=float)[:,:2]
    ds=np.linalg.norm(np.diff(p,axis=0),axis=1)
    if len(p)<4 or not np.isfinite(p).all() or np.any(ds<1e-7):
        return 1e6
    p=p[np.r_[True,np.cumsum(ds)<=12.]]
    if len(p)<4: return 1e6
    ds=np.linalg.norm(np.diff(p,axis=0),axis=1)
    arc=np.r_[0.,np.cumsum(ds)]
    yaw=np.unwrap(np.arctan2(np.gradient(p[:,1],arc),np.gradient(p[:,0],arc)))
    k=np.gradient(yaw,arc)
    dk=np.gradient(k,arc)
    # Normalize by declared geometry scales; this is a fixed heuristic.
    return float(np.mean((k/.1)**2+2*(dk/.02)**2))


class RollingFamily(SpatialFamily):
    MAX_OFFSET = .5

    def generate(self,ego,previous,wheelbase,offset,target):
        scalars=[ego.x,ego.y,ego.yaw,ego.v,previous['df'],wheelbase,offset,target]
        if not all(math.isfinite(float(v)) for v in scalars) or wheelbase<=0. or target<0. or abs(offset)>self.MAX_OFFSET:
            raise ValueError('Invalid rolling trajectory observation/action')
        s0=self.project(ego.x,ego.y)
        span=max(4.,min(8.,2.*max(float(ego.v),float(target))))
        if self.arc[-1]-s0<span+2.:
            raise ValueError('Insufficient public route for local action')
        g,gp,k,kp,t,n=self.differential(np.asarray(s0))
        displacement=np.array([ego.x,ego.y])-self.curve(s0)
        if abs(float(displacement.dot(t)))>.01:
            raise ValueError('Projection outside public reference')
        d0=float(displacement.dot(n))
        psi=math.atan2(math.sin(ego.yaw-math.atan2(t[1],t[0])),
                       math.cos(ego.yaw-math.atan2(t[1],t[0])))
        if abs(psi)>.7 or 1.-k*d0<.3:
            raise ValueError('Rolling action leaves local Frenet chart')
        a0=float(g*(1.-k*d0)); dp0=a0*math.tan(psi)
        t2=gp*(1.-k*d0)-g*kp*d0-2*g*k*dp0
        initial_kappa=math.tan(float(previous['df']))/wheelbase
        dd0=float((initial_kappa*(a0*a0+dp0*dp0)**1.5+dp0*t2)/a0-a0*g*k)
        coefficients=quintic_boundary((d0,dp0,dd0),(offset,0.,0.),span)
        end=min(float(self.arc[-1]),s0+max(span+2.,6.*max(float(ego.v),float(target))+4.))
        first=np.linspace(s0,s0+span,int(math.ceil(span/.25))+1)
        rest=np.linspace(s0+span,end,int(math.ceil((end-s0-span)/.25))+1)[1:]
        s=np.r_[first,rest]
        d=np.full(len(s),float(offset)); dp=np.zeros(len(s)); dd=np.zeros(len(s))
        for values,order in ((d,0),(dp,1),(dd,2)):
            values[:len(first)]=evaluate(coefficients,first-s0,order)
        g,gp,k,kp,t,n=self.differential(s)
        a,b=g*(1.-k*d),dp
        if np.any(a<=.2*g): raise ValueError('Folded local trajectory')
        t2=gp*(1.-k*d)-g*kp*d-2*g*k*dp
        n2=a*g*k+dd
        curvature=(a*n2-b*t2)/(a*a+b*b)**1.5
        path=self.curve(s)+d[:,None]*n
        derivative=a[:,None]*t+b[:,None]*n
        poses=np.c_[path,np.arctan2(derivative[:,1],derivative[:,0])]
        return dict(path=path,poses=poses,curvature=curvature,arc=s,d=d,d_d=dp,d_dd=dd,
            start_arc=float(s0),end_arc=float(end),transition_end_arc=float(s0+span),
            coefficients=coefficients.tolist(),reference_hash=self.reference_hash,
            parameters=dict(offset_m=float(offset),transition_m=float(span),planning_length_m=float(end-s0)),
            initial=dict(d=d0,slope=float(dp0),second=dd0,kappa=initial_kappa),
            cost=path_cost(path))
