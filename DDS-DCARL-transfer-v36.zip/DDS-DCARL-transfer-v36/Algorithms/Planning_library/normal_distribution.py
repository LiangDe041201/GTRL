import numpy as np
from scipy import stats

def analyze_extreme_values(data):
    """
    对数组进行排序，使用高斯分布拟合，并分析前5%和后5%的值
    
    参数:
    data: 输入数组，至少包含30个数字
    
    返回:
    dict: 包含实际观测值和理论值的字典
    """
    # 确保输入数据足够长
    if len(data) < 30:
        raise ValueError("输入数组必须至少包含30个元素")
    
    # 将数据转换为numpy数组并排序
    data_array = np.array(data)
    sorted_data = np.sort(data_array)
    
    # 使用高斯分布拟合数据
    mu, sigma = stats.norm.fit(sorted_data)
    
    # 计算前5%和后5%的分界点（实际观测值）
    n = len(sorted_data)
    lower_index = int(0.05 * n)  # 前5%的索引
    upper_index = int(0.95 * n)  # 后5%的索引
    
    # 提取前5%和后5%的实际观测值
    lower_5_percent_observed = sorted_data[:lower_index]
    upper_5_percent_observed = sorted_data[upper_index:]
    
    # 计算基于高斯分布的理论分位数
    lower_theoretical = stats.norm.ppf(0.05, loc=mu, scale=sigma)
    upper_theoretical = stats.norm.ppf(0.95, loc=mu, scale=sigma)
    
    # 找出数据中低于理论下分位数和高于理论上分位数的值
    lower_theoretical_values = sorted_data[sorted_data < lower_theoretical]
    upper_theoretical_values = sorted_data[sorted_data > upper_theoretical]
    
    return {
        'observed': {
            'lower_5%': lower_5_percent_observed,
            'upper_5%': upper_5_percent_observed
        },
        'theoretical': {
            'lower_threshold': lower_theoretical,
            'upper_threshold': upper_theoretical,
            'values_below_threshold': lower_theoretical_values,
            'values_above_threshold': upper_theoretical_values
        },
        'distribution_params': {
            'mean': mu,
            'std_dev': sigma
        }
    }

# 示例使用
if __name__ == "__main__":
    # # 生成示例数据（至少30个数字）
    # np.random.seed(42)  # 为了可重复性
    # sample_data = np.random.normal(50, 15, 100)  # 生成100个符合正态分布的数据

    sample_data = np.arange(1, 10001) 
    
    # print("原始数据示例（前10个）:", sample_data)
    # print("数据长度:", len(sample_data))
    
    # 分析极端值
    results = analyze_extreme_values(sample_data)
    
    # print("\n=== 基于排序的实际观测值 ===")
    # print("前5%的观测值:", results['observed']['lower_5%'])
    # print("后5%的观测值:", results['observed']['upper_5%'])
    
    print("\n=== 基于高斯分布拟合的理论值 ===")
    print(f"理论下分位数(5%): {results['theoretical']['lower_threshold']:.4f}")
    print(f"理论上分位数(95%): {results['theoretical']['upper_threshold']:.4f}")
    # print("低于理论下分位数的值:", results['theoretical']['values_below_threshold'])
    # print("高于理论上分位数的值:", results['theoretical']['values_above_threshold'])
    
    print("\n=== 分布参数 ===")
    print(f"均值: {results['distribution_params']['mean']:.4f}")
    print(f"标准差: {results['distribution_params']['std_dev']:.4f}")
    
    # # 统计信息
    # print("\n=== 统计信息 ===")
    # print(f"前5%观测值数量: {len(results['observed']['lower_5%'])}")
    # print(f"后5%观测值数量: {len(results['observed']['upper_5%'])}")
    # print(f"低于理论下分位数的值数量: {len(results['theoretical']['values_below_threshold'])}")
    # print(f"高于理论上分位数的值数量: {len(results['theoretical']['values_above_threshold'])}")