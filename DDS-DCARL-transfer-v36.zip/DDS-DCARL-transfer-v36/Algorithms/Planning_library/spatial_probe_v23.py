"""Own-path spatial candidates on frozen CG, without Q training or EFE.

This bounded experiment only replaces a proceed request. Keeping defer and
its original clear backup together avoids passing a different path's plan to
the frozen shared-path guard. Cross-intent path learning needs a later API.
"""
import json
import math
from pathlib import Path
import time
import numpy as np

from Planning_library.control_path_v15 import path_hash
from Planning_library.execution_guard import select_execution
from Planning_library.forecast_v18 import predict
from Planning_library.matrix_turn_game_v18 import score_candidates
from Planning_library.matrix_turn_game_v20 import candidate_execution
from Planning_library.spatial_trajectory_v23 import SpatialFamily
from Planning_library.trajectory_guard import execution_acceleration
from Planning_library.trajectory_probe_v21 import TrajectoryProbeV21, _description, _array_hash, _vehicle
from Planning_library.vehicle_observation import vehicle_id, vehicle_size


class SpatialProbeV23(TrajectoryProbeV21):
    OFFSETS = dict(observe=0., center=0., plus=.5, minus=-.5)

    def __init__(self, mode, geometry, controllers, corridor, cruise=4.412022451715821,
                 directory=None, pose_reader=None):
        if mode not in self.OFFSETS:
            raise ValueError('Unknown spatial probe mode')
        super().__init__('observe', geometry, controllers, cruise)
        self.mode, self.corridor, self.pose_reader = mode, corridor, pose_reader
        self.family = SpatialFamily(geometry.get('navigation_route', geometry['forecast_route']))
        self.profile = self.profile_audit = self.profile_error = None
        self.anchor = None
        self._base = None
        if directory is not None:
            directory = Path(directory)
            directory.mkdir(parents=True, exist_ok=True)
            metadata = dict(revision='spatial_probe_v23', mode=mode,
                reference=self.family.reference.tolist(), reference_hash=self.family.reference_hash,
                offset_m=self.OFFSETS[mode], transition_m=8., recovery_m=8.,
                reference_coordinate='chord_arc', learning_enabled=False, efe_enabled=False,
                proceed_only=True, corridor=corridor.metadata,
                positive_offset='normal_minus_tangent_y_tangent_x')
            (directory/'spatial_metadata_v23.json').write_text(json.dumps(metadata, indent=2), encoding='utf8')

    @staticmethod
    def description(candidate, identity, intent, path):
        return dict(_description(candidate, identity, intent), path=np.asarray(path, dtype=float).tolist(),
                    path_hash=path_hash(path))

    def propose(self, dynamic, candidates, baseline, cg_record, seed, road_right, center):
        started = time.perf_counter()
        ego, objects = dynamic.ego_vehicle, dynamic.objects
        self._vehicle_length = vehicle_size(ego, 'length', 4.5)
        self._vehicle_width = vehicle_size(ego, 'width', 2.)
        nominal = candidates[1]['controller']
        base_path = nominal.last_pathway
        names = ('defer', 'proceed')
        records = [self.description(c, names[i]+'_base', names[i], base_path) for i, c in enumerate(candidates)]
        eligible, extra_ms, candidate = False, 0., None
        status = 'inactive'
        permitted = bool(cg_record['active'] and not nominal.geometry_force_stop and nominal.geometry_source == 'planned')
        if permitted and self.profile is None and self.profile_error is None and baseline == 1:
            try:
                self.profile = self.family.generate(ego, seed['previous'], self.geometry['wheelbase'], self.OFFSETS[self.mode])
                self.anchor = dict(ego=_vehicle(ego), previous=dict(seed['previous']))
                self.profile_audit = self.corridor.audit(self.profile['poses'],
                    vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.))
            except ValueError as exc:
                self.profile_error = str(exc)
        proposal = dict(offset_m=self.OFFSETS[self.mode], reference_hash=self.family.reference_hash,
                        generated=self.profile is not None, error=self.profile_error, anchor=self.anchor)
        if permitted and self.profile is not None:
            profile = self.profile
            max_curvature = float(np.max(np.abs(profile['curvature'])))
            curvature_limit = math.tan(min(1., self.geometry['max_steer']))/self.geometry['wheelbase']
            proposal.update(max_curvature=max_curvature, curvature_limit=curvature_limit,
                path_road=self.profile_audit, parameters=profile['parameters'], coefficients=profile['coefficients'],
                initial=profile['initial'], start_arc=profile['start_arc'], peak_arc=profile['peak_arc'], join_arc=profile['join_arc'])
            if not self.profile_audit['accepted']:
                status = 'path_outside_corridor'
            elif max_curvature > curvature_limit:
                status = 'curvature_limit'
            else:
                controller = self.controllers[0]
                controller.reset_global_path(profile['path'], dynamic)
                controller.last_u = dict(seed['previous'])
                controller._previous_observed_speed = seed['observed_speed']
                # The CG warm plan belongs to a different reference geometry.
                controller._warm_controls = None
                controller.set_game_context({}, ego)
                target = float(candidates[1]['target'])
                a, delta = controller.solve(dynamic, target, road_right, intersection_center=center)
                extra_ms = float(controller.last_solve_ms)
                candidate = dict(controller=controller, target=target, a=a, delta=delta,
                    solve_ok=bool(controller._solve_ok), prediction=controller.last_prediction,
                    plan=controller.last_control_plan if controller._solve_ok else None,
                    times=controller.prediction_times, path=controller.last_pathway)
                own_path = candidate['path']
                execution = candidate_execution(ego, objects, [candidate], own_path, seed['previous'], self.geometry)[0]
                rv = next((v for v in objects if vehicle_id(v) == cg_record.get('rv_id')), None)
                _, parts = score_candidates(ego, objects, rv, [candidate], self.geometry, own_path,
                    seed['previous'], self.cruise, cg_record.get('motion_evidence', {}).get('acceleration'))
                road_predictions = []
                if candidate['prediction'] is not None:
                    road_predictions.append(self.corridor.audit(candidate['prediction'][[0, 1, 6]].T,
                        vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.)))
                for lag in (0., .4):
                    states, _, _ = predict(ego, own_path, target,
                        execution_acceleration(a, max(0., ego.v), target), delta, seed['previous'],
                        self.geometry, lag=lag, plan=candidate['plan'], plan_times=candidate['times'])
                    road_predictions.append(self.corridor.audit(states[[0, 1, 6]].T,
                        vehicle_size(ego, 'length', 4.5), vehicle_size(ego, 'width', 2.)))
                road_ok = len(road_predictions) == 3 and all(r['accepted'] for r in road_predictions)
                eligible = bool(candidate['solve_ok'] and execution['accepted'] and road_ok
                                and all(p['admissible'] for p in parts[0]))
                desc = self.description(candidate, 'proceed_offset_%+.2f' % self.OFFSETS[self.mode], 'proceed', own_path)
                desc.update(execution=execution, components=parts[0], eligible=eligible,
                            road_predictions=road_predictions, road_predictions_ok=road_ok)
                records.append(desc)
                status = 'ready' if eligible else 'prediction_or_execution_rejected'
        elif permitted:
            status = 'generation_rejected' if self.profile_error else 'waiting_for_proceed_anchor'
        changed = bool(eligible and baseline == 1 and self.mode != 'observe')
        request = records[-1] if changed else records[baseline]
        self._base = dict(candidates[baseline], path=base_path)
        self.last = dict(revision='spatial_probe_v23', mode=self.mode, active=bool(cg_record['active']),
            baseline_intent=baseline, baseline_id=names[baseline]+'_base', baseline_path_hash=path_hash(base_path),
            reference_hash=self.family.reference_hash, proposal=proposal, proposal_status=status,
            observation=dict(ego=_vehicle(ego), others=[_vehicle(v) for v in objects],
                phase=cg_record['phase'], standoff=cg_record['standoff'],
                reference_progress=self.family.project(ego.x, ego.y)),
            previous=dict(seed['previous']), warm_hash=_array_hash(seed['warm']),
            candidates=records, request_id=request['id'], request=dict(request), changed_request=changed,
            retracted=False, final_reviewed=False, learning_enabled=False, efe_reward_enabled=False,
            extra_solve_ms=extra_ms, decision_ms=(time.perf_counter()-started)*1000.)
        output = list(candidates)
        if changed:
            output[1] = candidate
        return output

    def review_execution(self, current, ego, objects, previous, audit):
        self.last['final_reviewed'] = True
        if not self.last['changed_request']:
            return None
        if (audit['action'] == 'mpc' and audit['safe'] and not audit['override']
                and path_hash(current.last_pathway) == self.last['request']['path_hash']):
            return None
        total_ms = current.last_solve_ms
        base = self._base
        restored = self.activate(current, base['controller'])
        restored.last_solve_ms = total_ms
        selected, fallback_audit = select_execution(ego, objects, base['path'], base['target'],
            execution_acceleration(base['a'], max(0., ego.v), base['target']), base['delta'], previous,
            self.geometry, prediction=base['prediction'], prediction_times=base['times'],
            plan=base['plan'], solve_ok=base['solve_ok'])
        original = self.last['candidates'][self.last['baseline_intent']]
        self.last.update(changed_request=False, retracted=True, request_id=original['id'], request=dict(original))
        return dict(controller=restored, candidate=base, selected=selected, audit=fallback_audit)

    def feedback(self, episode, frame, audit, applied, outcome=None):
        if int(applied['control_submit_ok']) != 1:
            raise RuntimeError('Spatial trajectory control was not submitted')
        observed, observed_pose = None, None
        if self.pose_reader is not None:
            pose = self.pose_reader()
            observed_pose = [float(pose.location.x), float(pose.location.y), math.radians(pose.rotation.yaw)]
            observed = self.corridor.audit([observed_pose],
                self._vehicle_length, self._vehicle_width)
        self.last['feedback'] = dict(episode=int(episode), frame=int(frame), outcome=outcome,
            applied_a=float(applied['a_cmd']), applied_delta=float(applied['delta_rad']),
            applied_target=float(applied['actuator_speed_target']), guard_action=audit['action'],
            observed_body=observed, observed_pose=observed_pose,
            observed_sim_frame=applied.get('sim_frame_after'))

    def reset(self):
        super().reset()
        self.profile = self.profile_audit = self.profile_error = self._base = None
        self.anchor = None
