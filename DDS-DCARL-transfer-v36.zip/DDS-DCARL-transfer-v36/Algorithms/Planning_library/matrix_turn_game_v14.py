"""v14 observable-motion 2x2 branch, retaining v13 as a frozen comparison.

The shared MPC and final execution guard are unchanged. Risk weights, six-
second scoring horizon and probability bounds are retained. This branch
changes RV forecasts, observable memory and the stop/roll candidate semantics.
"""
import json
import math
import time

import numpy as np

from Planning_library.cournot_game import expected_payoff_response
from Planning_library.execution_guard import rollout
from Planning_library.matrix_motion_v14 import MotionHistory, rv_action_track
from Planning_library.matrix_turn_game import (
    MatrixTurnGame, _progress, observable_tracks, rectangle_gaps)
from Planning_library.paper_turn_control import nearby_vehicles, motion
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration)


def score_candidates(ego, objects, rv, candidates, geometry, path, previous, cruise,
                     observed_acceleration=None):
    """Same utility scale as v13, with observed-motion RV columns and audit geometry."""
    geometry=dict(geometry,max_steer=min(1.,geometry['max_steer']))
    threats=nearby_vehicles(objects,ego,limit=None)
    matrix,components=[],[]
    for candidate in candidates:
        target,a,delta=candidate['target'],candidate['a'],candidate['delta']
        plans=[rollout(ego,path,target,a,delta,previous,geometry,horizon=6.,lag=lag,
                       plan=candidate.get('plan'),plan_times=candidate.get('times')) for lag in (0.,.4)]
        representative,times=plans[-1]
        checked=list(plans)
        if candidate.get('solve_ok') and candidate.get('prediction') is not None:
            checked.append((candidate['prediction'],candidate['times']))
        progress=_progress(representative,path)/max(4.*float(times[-1]),1.)
        stopped=float(np.mean(representative[5]<.1))
        body_acc=np.diff(representative[5])/np.diff(times)
        jerk=np.diff(body_acc)/np.diff(times)[1:]
        comfort=float(np.mean(np.minimum((jerk/3.)**2,25.))) if len(jerk) else 0.
        actor_columns=[[],[]]
        for other in threats:
            primary=rv is not None and vehicle_id(other)==vehicle_id(rv)
            columns=(0,1) if primary else (0,)
            for column in columns:
                actor_risk,actor_min=0.,float('inf')
                for states,forecast_times in checked:
                    tracks=([rv_action_track(other,objects,forecast_times,cruise,bool(column),
                                              acceleration=observed_acceleration)] if primary
                            else observable_tracks(other,forecast_times))
                    for track in tracks:
                        gaps=rectangle_gaps(states,ego,other,track)
                        deficit=np.maximum((.5-gaps)/.5,0.)
                        actor_risk=max(actor_risk,float(np.mean(deficit**2)+np.max(deficit**2)))
                        actor_min=min(actor_min,float(np.min(gaps)))
                part=dict(actor_id=vehicle_id(other),primary=primary,risk=actor_risk,
                          min_gap=None if math.isinf(actor_min) else actor_min)
                actor_columns[column].append(part)
                if not primary:
                    actor_columns[1].append(dict(part))
        row,parts=[],[]
        for actors in actor_columns:
            risk=sum(actor['risk'] for actor in actors)
            gaps=[actor['min_gap'] for actor in actors if actor['min_gap'] is not None]
            utility=progress-.25*stopped-.05*comfort-4.*risk
            if not candidate.get('solve_ok',False):
                utility-=1000.
            row.append(float(utility))
            parts.append(dict(progress=progress,stopped_fraction=stopped,comfort=comfort,
                risk=risk,min_gap=min(gaps) if gaps else None,utility=float(utility),
                switch_cost=0.,actors=actors))
        matrix.append(row);components.append(parts)
    return matrix,components


def _observed_vehicle(vehicle):
    vx,vy=motion(vehicle)
    return dict(veh_id=vehicle_id(vehicle),x=float(vehicle.x),y=float(vehicle.y),
        yaw=float(vehicle.yaw),v=float(vehicle.v),vx=vx,vy=vy,
        length=vehicle_size(vehicle,'length',4.5),width=vehicle_size(vehicle,'width',2.),
        acc=longitudinal_acceleration(vehicle),
        acc_source=str(getattr(vehicle,'acc_source','unavailable')))


class MatrixTurnGameV14(MatrixTurnGame):
    revision='matrix_entry_v14'

    def __init__(self,geometry,cruise=4.412022451715821,legacy=False,directory=None):
        if legacy:
            raise ValueError('Use the frozen v13 class for the legacy comparison')
        super().__init__(dict(geometry,max_steer=min(1.,geometry['max_steer'])),cruise,False,directory)

    def reset(self):
        super().reset()
        self.history=MotionHistory(self.cruise)
        self._frame=0
        self._defer_stopped=False
        self._motion_evidence={}
        self._snapshot_inputs=None
        self._last_snapshot_active=False

    def yield_probability(self,rv,objects):
        probability,source,evidence=self.history.estimate(rv,objects)
        self._motion_evidence=evidence
        return probability,source

    def prepare(self,ego,objects,conf,nominal,standoff,goal):
        self._frame+=1
        self.history.observe(objects,self._frame)
        rv,targets=super().prepare(ego,objects,conf,nominal,standoff,goal)
        active=self.last['active']
        raw=float(targets[0])
        if active:
            # A stopped candidate stays stopped until a meaningful rolling
            # reference is available. There is no 0.010... m/s launch target.
            if self._defer_stopped:
                self._defer_stopped=raw < .5
            else:
                self._defer_stopped=raw < .2
            targets[0]=0. if self._defer_stopped else raw
        else:
            self._defer_stopped=False
        equivalent=active and abs(targets[1]-targets[0])<=.05
        if equivalent:
            # Equal speed references are one action, not a game/tie/label switch.
            targets[0]=targets[1]
            self.last['active']=False
        self.last.update(controller='matrix_v14',targets=list(targets),
            forecast_model='observed_motion_v14',motion_evidence=dict(self._motion_evidence),
            defer_raw_target=raw,defer_stop_latched=self._defer_stopped,
            equivalent_targets=bool(equivalent),switch_penalty=0.,
            model_safe_proceed_while_defer=False)
        return rv,targets

    def choose(self,ego,objects,rv,conf,candidates,path,previous):
        started=time.perf_counter()
        if not self.last['active']:
            selected=1
        else:
            matrix,parts=score_candidates(ego,objects,rv,candidates,self.geometry,path,previous,
                self.cruise,observed_acceleration=self._motion_evidence.get('acceleration'))
            previous_action=self.last_action
            all_safe=all(cell['risk']<=1e-12 for row in parts for cell in row)
            if (previous_action is not None and self.last_rv==vehicle_id(rv) and all_safe
                    and all(c['solve_ok'] for c in candidates)):
                # A declared small switching cost only in fully risk-free
                # comparisons. Never delay a safety-driven strategy change.
                penalized=1-previous_action
                for j in range(2):
                    matrix[penalized][j]-=.03
                    parts[penalized][j].update(switch_cost=.03,utility=matrix[penalized][j])
                self.last['switch_penalty']=.03
            result=expected_payoff_response(matrix,self.last['p_yield'])
            selected=result['ego_action']
            if not any(c['solve_ok'] for c in candidates):
                selected=0;result['decision_mode']='all_candidates_failed'
            elif not candidates[selected]['solve_ok'] and candidates[1-selected]['solve_ok']:
                selected=1-selected;result['decision_mode']='optimizer_failure_override'
            d0,d1=matrix[1][0]-matrix[0][0],matrix[1][1]-matrix[0][1]
            critical=-d0/(d1-d0) if abs(d1-d0)>1e-12 else None
            opportunity=(selected==0 and candidates[1]['solve_ok'] and
                all(cell['risk']<=1e-12 for cell in parts[1]) and
                parts[1][0]['progress']>parts[0][0]['progress']+.05 and ego.v<.1)
            self.last.update(result,components=parts,selected=selected,
                switch=previous_action is not None and previous_action!=selected,
                critical_yield_probability=critical,
                model_safe_proceed_while_defer=bool(opportunity))
        self.last_action=selected if self.last['active'] else None
        self.last_rv=vehicle_id(rv) if self.last['active'] else None
        self.last.update(selected=selected,decision_ms=(time.perf_counter()-started)*1000.,
            candidate_targets=[c['target'] for c in candidates],
            candidate_a=[c['a'] for c in candidates],candidate_delta=[c['delta'] for c in candidates],
            candidate_solve_ok=[bool(c['solve_ok']) for c in candidates])
        self._snapshot_inputs=(ego,list(objects),rv,candidates,path,dict(previous))
        return selected

    def record(self,episode,frame,selected_a,selected_delta,selected_target,audit,applied):
        super().record(episode,frame,selected_a,selected_delta,selected_target,audit,applied)
        active=self.last['active']
        save=(frame%20==0 or self.last.get('switch') or audit['override']
              or active and not self._last_snapshot_active)
        self._last_snapshot_active=active
        if self.directory is None or not save or self._snapshot_inputs is None:
            return
        ego,objects,rv,candidates,path,previous=self._snapshot_inputs
        encoded=[]
        for candidate in candidates:
            encoded.append(dict({key:candidate[key] for key in ('target','a','delta','solve_ok')},
                **{key:None if candidate.get(key) is None else np.asarray(candidate[key]).tolist()
                   for key in ('prediction','plan','times')}))
        row=dict(revision=self.revision,episode=int(episode),frame=int(frame),
            ego=_observed_vehicle(ego),objects=[_observed_vehicle(o) for o in objects],
            rv_id=vehicle_id(rv),path=np.asarray(path).tolist(),previous=previous,
            geometry=self.geometry,cruise=self.cruise,candidates=encoded,
            decision=dict(self.last),guard_action=audit['action'],guard_override=bool(audit['override']))
        with (self.directory/'matrix_snapshots.jsonl').open('a',encoding='utf8') as stream:
            stream.write(json.dumps(row,allow_nan=False)+'\n')
