"""Share exact candidate forecasts without changing frozen CG/guard kernels.

This object is created for ONE spatial candidate in ONE observed frame. The
final execution guard still independently reviews the selected request. For
proposal eligibility only its MPC branch matters: any backup means rejection.
"""
import math
import time

import numpy as np
from Planning_library.execution_guard import clearance
from Planning_library.forecast_v18 import checked_prefix, predict
from Planning_library.matrix_turn_game_v16 import score_candidates as base_score
from Planning_library.matrix_turn_game_v18 import opponent_tracks
from Planning_library.trajectory_guard import execution_acceleration


def _array_key(value):
    if value is None: return None
    array=np.asarray(value,dtype='<f8')
    return array.shape,array.tobytes()


class CandidateAudit:
    def __init__(self,ego,objects,rv,path,previous,geometry,cruise,observed_acceleration=None,
                 predictor=predict,stop_after=None):
        self.ego,self.objects,self.rv=ego,objects,rv
        self.path,self.previous,self.geometry=path,previous,geometry
        self.cruise,self.observed_acceleration=cruise,observed_acceleration
        self.predictor=predictor; self.stop_after=stop_after; self.cache={}
        self.profile=dict(prediction_calls=0,prediction_hits=0,prediction_ms=0.,
                          execution_ms=0.,score_ms=0.)

    def _predict(self,ego,path,target,a,delta,previous,geometry,horizon=6.,lag=.4,
                 plan=None,plan_times=None):
        # Physical inputs/path/geometry are fixed within this candidate audit.
        # Controls and every plan element remain part of the cache identity.
        key=(float(target),float(a),float(delta),float(horizon),float(lag),
             _array_key(plan),_array_key(plan_times))
        if key not in self.cache:
            started=time.perf_counter()
            options=dict(horizon=horizon,lag=lag,plan=plan,plan_times=plan_times)
            if self.stop_after is not None:
                options['stop_after']=self.stop_after
            self.cache[key]=self.predictor(ego,path,target,a,delta,previous,geometry,**options)
            self.profile['prediction_ms']+=(time.perf_counter()-started)*1000.
            self.profile['prediction_calls']+=1
        else: self.profile['prediction_hits']+=1
        return self.cache[key]

    def forecasts(self,candidate,acceleration,horizon=6.):
        return [self._predict(self.ego,self.path,candidate['target'],acceleration,
            candidate['delta'],self.previous,self.geometry,horizon=horizon,lag=lag,
            plan=candidate.get('plan'),plan_times=candidate.get('times')) for lag in (0.,.4)]

    def evaluate(self,candidate,horizon=6.):
        started=time.perf_counter()
        acceleration=execution_acceleration(candidate['a'],max(float(self.ego.v),0.),candidate['target'])
        plans=self.forecasts(candidate,acceleration,horizon)
        guard_horizon=float(self.geometry.get('execution_horizon',6.))
        if horizon>6.:
            guard_horizon=max(horizon,guard_horizon)
        guard_plans=plans if guard_horizon==horizon else self.forecasts(candidate,acceleration,guard_horizon)
        proposal_gap=None; valid=stop=False
        if candidate['solve_ok']:
            checked=[(states,times) for states,times,_ in guard_plans]
            if candidate.get('prediction') is not None:
                checked.insert(0,checked_prefix(candidate['prediction'],candidate['times'],self.stop_after))
            proposal_gap=min(clearance(states,times,self.objects,self.ego,geometry=self.geometry)[0]
                             for states,times in checked)
            valid=all(diag['valid'] for _,_,diag in guard_plans)
            stop=all(diag['stop_before_band'] for _,_,diag in guard_plans)
        execution=dict(candidate=0,accepted=bool(candidate['solve_ok'] and valid and stop and proposal_gap>=.2),
            a=acceleration,delta=float(candidate['delta']),target=float(candidate['target']),
            proposed_gap=proposal_gap if proposal_gap is not None and math.isfinite(proposal_gap) else None,
            unbounded_gap=bool(proposal_gap is not None and proposal_gap==float('inf')),
            forecast_valid=bool(valid),stop_feasible=bool(stop),solve_ok=bool(candidate['solve_ok']))
        self.profile['execution_ms']=(time.perf_counter()-started)*1000.
        started=time.perf_counter()
        matrix,parts=base_score(self.ego,self.objects,self.rv,[candidate],self.geometry,self.path,
            self.previous,self.cruise,self.observed_acceleration,ego_predict=self._predict,
            track_provider=opponent_tracks,track_context=True,horizon=horizon,
            mpc_check_horizon=self.stop_after)
        # Same postprocessing as matrix_turn_game_v18.score_candidates.
        for column,part in enumerate(parts[0]):
            feasible=all(d['stop_before_band'] for d in part['forecasts'])
            penalty=0. if feasible else 1000.
            matrix[0][column]-=penalty
            part.update(stop_feasible=bool(feasible),admissible=bool(part['forecast_valid'] and feasible),
                        admissibility_penalty=penalty,utility=matrix[0][column])
        self.profile['score_ms']=(time.perf_counter()-started)*1000.
        return execution,parts[0],plans
