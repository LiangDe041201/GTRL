#!/usr/bin/env python3
"""训练可视化窗口（客户端相机 + pygame）—— 与 DSH_RENDER 的区别：

  DSH_RENDER  控制**服务器端**是否渲染（CARLA settings.no_rendering_mode）。
              本机用带窗口的方式启动服务器会在软件 Vulkan 下崩溃
              （GameThread timed out waiting for RenderThread），故不可用。
  DSH_VIEW    控制**本模块**：训练进程内挂两个相机传感器（前视追车 + 俯视），
              用 pygame 开一个窗口实时显示。服务器仍然用 -RenderOffScreen 离屏运行，
              因此既能看到画面，又不会因为服务器窗口渲染线程而崩溃。

  ⚠ 相机传感器需要服务器的渲染管线，故 DSH_VIEW=1 时会把
    no_rendering_mode 置为 False（服务器保持离屏启动即可，没有窗口就没有窗口崩溃）。
    代价：仿真明显变慢，且 UE4 渲染内存随回合累积 —— 长跑请分段、靠运行目录续看日志。

窗口布局（默认 2×560×315 + 40px 信息条）：
  [ 左：前视追车视角 ]  [ 右：俯视视角 ]
  [ 底部：episode/frame/动作/接管/车速/RV 状态/奖励 ]
"""
import os
import sys

import numpy as np

#: 相机挂载位姿（相对自车）
CHASE_TRANSFORM = dict(x=-7.5, y=0.0, z=3.2, pitch=-14.0, yaw=0.0, roll=0.0)
BIRD_TRANSFORM = dict(x=0.0, y=0.0, z=26.0, pitch=-90.0, yaw=0.0, roll=0.0)


def bgra_to_rgb(raw, width, height):
    """CARLA sensor.camera.rgb 的 raw_data(BGRA) → RGB 的 (h, w, 3) uint8 数组。

    纯函数，便于离线单测（不依赖 CARLA / pygame）。
    """
    arr = np.frombuffer(raw, dtype=np.uint8)
    arr = arr.reshape((int(height), int(width), 4))
    return np.ascontiguousarray(arr[:, :, 2::-1])      # BGR→RGB（丢弃 alpha）


class LiveView:
    """pygame 实时可视化（前视 + 俯视），DSH_VIEW=1 开启。"""

    def __init__(self, cam_w=None, cam_h=None, enabled=None, every_n=1):
        if enabled is None:
            enabled = os.environ.get('DSH_VIEW', '0') == '1'
        self.enabled = bool(enabled)
        self.cam_w = int(cam_w or os.environ.get('DSH_VIEW_W', '560'))
        self.cam_h = int(cam_h or os.environ.get('DSH_VIEW_H', '315'))
        self.tick = float(os.environ.get('DSH_VIEW_TICK', '0.1'))   # 相机采样周期 (s)
        self.every_n = max(1, int(every_n))
        self.bar_h = 46
        self._n = 0
        self.closed = False
        self.ego_id = None
        self._frames = {}
        self._sensors = []
        self._screen = None
        self._font = None
        # 【截图】`DSH_SHOT=<目录>` 时把每帧合成画面存成 PNG。
        #   为什么需要：窗口只在**服务器所在机器的桌面**上可见。若通过 Web GUI /
        #   远程会话查看，窗口看不到；截图可以当作附件直接呈现，且便于离线比对。
        #   `DSH_SHOT_EVERY=<N>` 控制抽帧间隔（默认 1 = 每帧都存，注意磁盘）。
        self.shot_dir = os.environ.get('DSH_SHOT') or None
        self.shot_every = max(1, int(os.environ.get('DSH_SHOT_EVERY', '1')))
        self._shots = 0
        if self.shot_dir:
            try:
                os.makedirs(self.shot_dir, exist_ok=True)
            except Exception as _e:
                print(f"[LiveView] 截图目录创建失败，已关闭截图: {_e!r}")
                self.shot_dir = None
        if self.enabled:
            try:
                self._init_pygame()
            except Exception as _e:      # 打不开窗口不能拖垮训练
                print(f"[LiveView] 可视化窗口初始化失败，已自动关闭: {_e!r}")
                self.enabled = False

    # ---------------- 初始化 ----------------
    def _init_pygame(self):
        import pygame
        pygame.init()
        pygame.display.set_caption('DDS-DCARL 左转博弈 训练可视化 (ESC 退出)')
        self._screen = pygame.display.set_mode(
            (self.cam_w * 2, self.cam_h + self.bar_h))
        try:
            self._font = pygame.font.SysFont('dejavusans,arial', 17)
        except Exception:
            self._font = pygame.font.Font(None, 18)
        self._pygame = pygame
        self._screen.fill((18, 18, 22))
        pygame.display.flip()

    # ---------------- 传感器 ----------------
    def attach(self, world, ego):
        """把两个相机挂到自车（每回合自车会重建，故需要重新挂）。"""
        if not self.enabled or ego is None:
            return
        self.detach()
        try:
            import carla
        except Exception:
            return
        bp_lib = world.get_blueprint_library()
        for key, tf in (('chase', CHASE_TRANSFORM), ('bird', BIRD_TRANSFORM)):
            bp = bp_lib.find('sensor.camera.rgb')
            bp.set_attribute('image_size_x', str(self.cam_w))
            bp.set_attribute('image_size_y', str(self.cam_h))
            bp.set_attribute('fov', '95' if key == 'chase' else '70')
            bp.set_attribute('sensor_tick', str(self.tick))
            transform = carla.Transform(
                carla.Location(x=tf['x'], y=tf['y'], z=tf['z']),
                carla.Rotation(pitch=tf['pitch'], yaw=tf['yaw'], roll=tf['roll']))
            sensor = world.spawn_actor(bp, transform, attach_to=ego,
                                       attachment_type=carla.AttachmentType.Rigid)
            sensor.listen(self._make_cb(key))
            self._sensors.append(sensor)
        self.ego_id = getattr(ego, 'id', None)
        self._frames = {}

    def _make_cb(self, key):
        def _cb(image):
            try:
                self._frames[key] = image
            except Exception:
                pass
        return _cb

    def detach(self):
        for s in self._sensors:
            try:
                s.stop()
                s.destroy()
            except Exception:
                pass
        self._sensors = []

    # ---------------- 每帧刷新 ----------------
    def update(self, info=None, world=None, ego=None):
        """刷新窗口；ESC/关闭窗口 → 抛 KeyboardInterrupt（由训练入口统一清理）。

        其余异常一律吞掉：可视化绝不能干扰训练主流程。
        """
        if not self.enabled or self.closed:
            return
        pygame = self._pygame
        # 自车重建（每回合 reset）→ 重新挂相机
        try:
            if ego is not None and getattr(ego, 'id', None) != self.ego_id:
                self.attach(world, ego)
        except Exception:
            pass
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT or (
                    ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE):
                self.closed = True
                raise KeyboardInterrupt('用户关闭可视化窗口')
        self._n += 1
        if self._n % self.every_n:
            return
        try:
            screen = self._screen
            screen.fill((18, 18, 22))
            for i, key in enumerate(('chase', 'bird')):
                img = self._frames.get(key)
                if img is None:
                    continue
                rgb = bgra_to_rgb(img.raw_data, img.width, img.height)
                surf = pygame.image.frombuffer(rgb.tobytes(),
                                               (img.width, img.height), 'RGB')
                screen.blit(surf, (i * self.cam_w, 0))
            self._draw_bar(info or {})
            pygame.display.flip()
            self._save_shot(pygame, info or {})
        except KeyboardInterrupt:
            raise
        except Exception:
            pass

    def _save_shot(self, pygame, info):
        """把当前合成画面存成 PNG（`DSH_SHOT=<目录>` 时启用）。

        绝不抛异常：截图失败不能影响训练。
        """
        if not self.shot_dir:
            return
        self._shots += 1
        if self._shots % self.shot_every:
            return
        try:
            ep = info.get('episode', 0)
            fr = info.get('frame', self._n)
            # 文件名带 episode/frame，便于按回合挑选与排序
            name = 'ep%03d_f%05d.png' % (int(ep), int(fr))
            pygame.image.save(self._screen, os.path.join(self.shot_dir, name))
        except Exception:
            pass

    def _draw_bar(self, info):
        pygame = self._pygame
        y = self.cam_h + 6
        pygame.draw.rect(self._screen, (28, 28, 34),
                         pygame.Rect(0, self.cam_h, self.cam_w * 2, self.bar_h))
        parts = [
            f"ep {info.get('episode', '-')}",
            f"frame {info.get('frame', '-')}",
            f"v {_f(info.get('v'))} m/s",
            f"action {info.get('action', '-')} / rule {info.get('rule', '-')}",
            f"takeover {'Y' if info.get('takeover') else 'n'}",
            f"reward {_f(info.get('reward'))}",
            f"RV v {_f(info.get('rv_v'))} x {_f(info.get('rv_x'))}",
            f"arc {_f(info.get('arc'))} committed {'Y' if info.get('committed') else 'n'}",
            f"LCTTC {_f(info.get('lcttc_rv'))} THW {_f(info.get('thw'))}",
        ]
        text = ' | '.join(parts)
        try:
            surf = self._font.render(text, True, (232, 232, 236))
            self._screen.blit(surf, (8, y))
            if info.get('efe_active'):
                t2 = (f"EFE: best_a={info.get('efe_best')} "
                      f"min={_f(info.get('efe_min'))} max={_f(info.get('efe_max'))}")
                self._screen.blit(self._font.render(t2, True, (250, 210, 120)), (8, y + 20))
            else:
                self._screen.blit(self._font.render(
                    'EFE: off (DSH_EFE=0)', True, (140, 140, 150)), (8, y + 20))
        except Exception:
            pass

    def close(self):
        self.detach()
        if self.enabled:
            try:
                self._pygame.quit()
            except Exception:
                pass
        self.closed = True


def _f(x, nd=1):
    try:
        return f"{float(x):.{nd}f}"
    except (TypeError, ValueError):
        return '-'


def get_view(**kw):
    """按环境变量创建视图（DSH_VIEW=0 时返回一个 disabled 对象，调用开销可忽略）。"""
    return LiveView(**kw)
