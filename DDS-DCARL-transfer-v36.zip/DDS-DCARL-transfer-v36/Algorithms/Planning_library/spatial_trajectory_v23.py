"""Quintic lateral boundary-value trajectories on a fixed public reference.

The independent variable is reference chord-arc, not time. Longitudinal speed
remains the CG target in this experiment. This is a spatial candidate family,
not the complete paper planner or a learned arbitrary-route generator.
"""
import math
import numpy as np
from scipy.interpolate import CubicSpline

from Planning_library.control_path_v15 import path_hash
from Planning_library.forecast_v16 import clean_points


def quintic_boundary(start, end, span):
    values = np.asarray(list(start)+list(end)+[span], dtype=float)
    if values.shape != (7,) or not np.isfinite(values).all() or span <= 0.:
        raise ValueError('Invalid quintic boundary conditions')
    c = np.zeros(6)
    c[:3] = [start[0], start[1], start[2]/2.]
    a = np.array([[span**3, span**4, span**5],
                  [3*span**2, 4*span**3, 5*span**4], [6*span, 12*span**2, 20*span**3]])
    b = [end[0]-c[0]-c[1]*span-c[2]*span**2,
         end[1]-c[1]-2*c[2]*span, end[2]-2*c[2]]
    c[3:] = np.linalg.solve(a, b)
    return c


def evaluate(coefficients, distance, derivative=0):
    c = np.asarray(coefficients, dtype=float)
    for _ in range(derivative):
        c = np.arange(1, len(c))*c[1:]
    return np.polynomial.polynomial.polyval(distance, c)


class SpatialFamily:
    def __init__(self, reference):
        self.reference = clean_points(reference)
        self.arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(self.reference, axis=0), axis=1))]
        if self.arc[-1] < 5.:
            raise ValueError('Spatial reference is too short')
        self.curve = CubicSpline(self.arc, self.reference, bc_type='natural')
        self.reference_hash = path_hash(self.reference)
        self.dense_s = np.linspace(0., self.arc[-1], int(math.ceil(self.arc[-1]/.1))+1)
        self.dense = self.curve(self.dense_s)

    def project(self, x, y):
        point = np.array([x, y], dtype=float)
        s = self.dense_s[int(np.argmin(np.sum((self.dense-point)**2, axis=1)))]
        for _ in range(12):
            r, first, second = self.curve(s), self.curve(s, 1), self.curve(s, 2)
            denominator = float(first.dot(first)+(r-point).dot(second))
            if abs(denominator) < 1e-8:
                raise ValueError('Ambiguous spatial projection')
            change = float((r-point).dot(first))/denominator
            s = float(np.clip(s-change, 0., self.arc[-1]))
            if abs(change) < 1e-10:
                break
        return s

    def differential(self, s):
        first, second, third = self.curve(s, 1), self.curve(s, 2), self.curve(s, 3)
        g = np.linalg.norm(first, axis=-1)
        if np.any(g < .2):
            raise ValueError('Reference has a singular tangent')
        tangent = first/g[..., None]
        normal = np.stack([-tangent[..., 1], tangent[..., 0]], axis=-1)
        gp = np.sum(first*second, axis=-1)/g
        k = (first[..., 0]*second[..., 1]-first[..., 1]*second[..., 0])/g**3
        kp = (first[..., 0]*third[..., 1]-first[..., 1]*third[..., 0])/g**3-3*k*gp/g
        return g, gp, k, kp, tangent, normal

    def generate(self, ego, previous, wheelbase, peak_offset, transition=8., recovery=8.):
        scalars = [ego.x, ego.y, ego.yaw, previous['df'], wheelbase, peak_offset, transition, recovery]
        if not all(math.isfinite(float(x)) for x in scalars) or wheelbase <= 0. or min(transition, recovery) < 1.:
            raise ValueError('Invalid spatial trajectory parameters')
        s0 = self.project(float(ego.x), float(ego.y))
        if s0+transition+recovery+2. > self.arc[-1]:
            raise ValueError('Insufficient public route for offset and rejoining')
        g, gp, k, kp, tangent, normal = self.differential(np.asarray(s0))
        displacement = np.array([ego.x, ego.y])-self.curve(s0)
        if abs(float(displacement.dot(tangent))) > .01:
            raise ValueError('Ego is outside the reference projection range')
        d0 = float(displacement.dot(normal))
        psi = math.atan2(math.sin(ego.yaw-math.atan2(tangent[1], tangent[0])),
                         math.cos(ego.yaw-math.atan2(tangent[1], tangent[0])))
        if abs(psi) > .7 or 1.-k*d0 < .3:
            raise ValueError('Initial heading/offset leaves the local Frenet chart')
        a0 = float(g*(1.-k*d0))
        dp0 = a0*math.tan(psi)
        tangent_second = gp*(1.-k*d0)-g*kp*d0-2*g*k*dp0
        initial_kappa = math.tan(float(previous['df']))/float(wheelbase)
        dd0 = float((initial_kappa*(a0*a0+dp0*dp0)**1.5+dp0*tangent_second)/a0-a0*g*k)
        out = quintic_boundary((d0, dp0, dd0), (peak_offset, 0., 0.), transition)
        back = quintic_boundary((peak_offset, 0., 0.), (0., 0., 0.), recovery)
        peak, join = s0+transition, s0+transition+recovery
        sample = lambda a, b: np.linspace(a, b, int(math.ceil((b-a)/.25))+1)
        s = np.r_[sample(s0, peak), sample(peak, join)[1:], sample(join, self.arc[-1])[1:]]
        d, dp, dd = np.zeros(len(s)), np.zeros(len(s)), np.zeros(len(s))
        first = s <= peak+1e-9
        second = (s > peak+1e-9) & (s <= join+1e-9)
        for values, order in [(d, 0), (dp, 1), (dd, 2)]:
            values[first] = evaluate(out, s[first]-s0, order)
            values[second] = evaluate(back, s[second]-peak, order)
        g, gp, k, kp, tangent, normal = self.differential(s)
        a, b = g*(1.-k*d), dp
        if np.any(a <= .2*g):
            raise ValueError('Candidate folds through the reference normal')
        t2 = gp*(1.-k*d)-g*kp*d-2*g*k*dp
        n2 = a*g*k+dd
        curvature = (a*n2-b*t2)/(a*a+b*b)**1.5
        points = self.curve(s)+d[:, None]*normal
        derivative = a[:, None]*tangent+b[:, None]*normal
        yaw = np.arctan2(derivative[:, 1], derivative[:, 0])
        return dict(path=points, poses=np.c_[points, yaw], curvature=curvature,
            arc=s, d=d, d_d=dp, d_dd=dd, peak_arc=peak, join_arc=join,
            start_arc=s0, reference_hash=self.reference_hash,
            parameters=dict(offset_m=float(peak_offset), transition_m=float(transition), recovery_m=float(recovery)),
            coefficients=dict(out=out.tolist(), back=back.tolist()),
            initial=dict(d=d0, slope=dp0, second=dd0, kappa=initial_kappa))
