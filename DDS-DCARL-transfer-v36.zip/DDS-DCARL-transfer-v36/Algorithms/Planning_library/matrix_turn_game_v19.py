"""Learning authority on v18's actual defer/proceed MPC candidates.

The frozen v18 payoff, utility weights, motion proxy, solver and final guard
are reused. EFE reads those candidate forecasts rather than a second ETA model.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import time

import numpy as np

from Planning_library.active_inference import preferred_observation
from Planning_library.candidate_learning_v19 import (
    CandidateBelief,CandidateLearner,candidate_efe,frame_discount,joint_efe,task_reward)
from Planning_library.matrix_turn_game_v18 import MatrixTurnGameV18
from Planning_library.matrix_motion_v14 import visible_leaders
from Planning_library.vehicle_observation import vehicle_id,longitudinal_acceleration,motion_observation


class MatrixTurnGameV19(MatrixTurnGameV18):
    revision='matrix_entry_v19'
    controller='matrix_v19'
    learner_type=CandidateLearner
    learning_revision='candidate_learning_v19'

    def __init__(self,geometry,learning_phase='train',checkpoint=None,efe_enabled=True,
                 trust_enabled=True,half_life=10.,alpha=.1,support_mass=.05,
                 min_episodes=10,epsilon=.3,decision_period=.5,seed=1,
                 reward_mode='task_efe',efe_weight=.1,belief_model=None,
                 confidence_range='local_empirical',**kwargs):
        if (learning_phase not in ('off','train','eval') or not 0.<=epsilon<=1.
                or not .05<=decision_period<=2. or not math.isfinite(efe_weight) or efe_weight<0.
                or reward_mode not in ('task_efe','negative_efe')
                or reward_mode=='negative_efe' and not efe_enabled):
            raise ValueError('Invalid common-candidate learning configuration')
        super().__init__(geometry,**kwargs)
        self.learning_phase,self.epsilon=learning_phase,float(epsilon)
        self.decision_period,self.reward_mode=float(decision_period),reward_mode
        self.efe_enabled,self.efe_weight=bool(efe_enabled),float(efe_weight)
        self.rng,self.episode=np.random.RandomState(seed),1
        config={} if belief_model is None else json.loads(Path(belief_model).read_text(encoding='utf8'))
        unknown=set(config)-{'persistence','likelihood','preference','gap_sigma'}
        if unknown:raise ValueError('Unknown belief model keys: '+str(sorted(unknown)))
        self.belief=CandidateBelief(persistence=float(config.get('persistence',.8)),
                                   likelihood=config.get('likelihood'))
        if 'preference' in config:
            p=np.asarray(config['preference'],dtype=float)
            if p.shape!=(4,) or not np.isfinite(p).all() or np.any(p<=0.):
                raise ValueError('Calibration requires four strictly positive finite preferences')
        self.preference=preferred_observation(config.get('preference'))
        self.gap_sigma=float(config.get('gap_sigma',.25))
        if not math.isfinite(self.gap_sigma) or self.gap_sigma<=0.:
            raise ValueError('Clearance observation sigma must be positive metres')
        gamma=frame_discount(half_life)
        efe_bound=math.log(1./float(self.preference.min()))+math.log(4.)
        # Known reward support for the declared bounded RATE and terminal
        # utilities. It does not establish independence or correct aggregation.
        reward_range=((.13+self.efe_weight*efe_bound)*.05/(1.-gamma)+15.
                      if reward_mode=='task_efe' else efe_bound*.05/(1.-gamma)+efe_bound)
        contract=dict(common_forecast='route_v18',opponent_model='leader_conditioned_v18',
            dt=.05,half_life_seconds=float(half_life),decision_period=self.decision_period,
            persistence_per_second=self.belief.persistence,likelihood=self.belief.likelihood.tolist(),
            preference=self.preference.tolist(),gap_sigma_m=self.gap_sigma,
            efe_enabled=self.efe_enabled,efe_weight=self.efe_weight,
            inference='observed_motion_time_filter_no_hypothetical_action_queue',
            direct_private_intent_response_identified=False,probabilities_calibrated=False,
            action_model='same_v18_candidates_and_guard',terminal='complete_5_collision_minus10_stuck_minus5')
        directory=None if self.directory is None else self.directory/'candidate_model'
        self.learner=(None if learning_phase=='off' else self.learner_type(
            phase=learning_phase,checkpoint=checkpoint,trust_enabled=trust_enabled,
            gamma=gamma,alpha=alpha,support_mass=support_mass,min_episodes=min_episodes,
            out_dir=directory,range_fallback=reward_range,reward_contract=reward_mode,
            filter_contract=contract,confidence_range=confidence_range))
        self.metadata=dict(revision=self.learning_revision,phase=learning_phase,config=contract,
            model_signature=None if self.learner is None else self.learner.signature(),
            checkpoint_sha256=None if checkpoint is None else hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest(),
            confidence_guarantee=False,calibrated=False)
        if self.directory is not None:
            self.directory.mkdir(parents=True,exist_ok=True)
            if learning_phase=='eval':
                frozen=self.directory/'candidate_model/frozen_input.json'
                frozen.parent.mkdir(parents=True,exist_ok=True)
                frozen.write_bytes(Path(checkpoint).read_bytes())
            (self.directory/'candidate_learning_metadata.json').write_text(
                json.dumps(self.metadata,indent=2,allow_nan=False),encoding='utf8')
        self._engaged=False;self._policy_age=0.;self._control_key=None;self._last_request=None

    @classmethod
    def from_environment(cls,geometry,**kwargs):
        return cls(geometry,learning_phase=os.environ.get('DSH_CANDIDATE_PHASE','train'),
            checkpoint=os.environ.get('DSH_CANDIDATE_CHECKPOINT') or None,
            efe_enabled=os.environ.get('DSH_EFE','1')=='1',
            trust_enabled=os.environ.get('DSH_WCV_BCV','1')=='1',
            half_life=float(os.environ.get('DSH_DISCOUNT_HALF_LIFE','10')),
            alpha=float(os.environ.get('DSH_SOFT_ALPHA','.1')),
            support_mass=float(os.environ.get('DSH_BASELINE_SUPPORT','.05')),
            min_episodes=int(os.environ.get('DSH_BELIEF_MIN_EPISODES','10')),
            seed=int(os.environ.get('DSH_SEED','1')),
            epsilon=float(os.environ.get('DSH_CANDIDATE_EPSILON','.3')),
            reward_mode=os.environ.get('DSH_CANDIDATE_REWARD','task_efe'),
            efe_weight=float(os.environ.get('DSH_CANDIDATE_EFE_WEIGHT','.1')),
            confidence_range=os.environ.get('DSH_CANDIDATE_CONFIDENCE_RANGE','local_empirical'),
            belief_model=os.environ.get('DSH_CANDIDATE_BELIEF_MODEL') or None,**kwargs)

    def reset(self):
        super().reset()
        if hasattr(self,'belief'):self.belief.reset()
        self._engaged=False;self._policy_age=0.;self._control_key=None;self._last_request=None

    def learning_candidates(self,ego,objects,candidates,path,previous,baseline,active):
        return ([i for i,c in enumerate(candidates) if self.candidate_usable(c,self.last['components'][i])]
                if active else [1])

    def learning_diagnostics(self):
        return {}

    def choose(self,ego,objects,rv,conf,candidates,path,previous):
        started=time.perf_counter()
        baseline=super().choose(ego,objects,rv,conf,candidates,path,previous)
        self.last.update(baseline_selected=baseline,baseline_decision_mode=self.last['decision_mode'],
                         cg_decision_ms=self.last['decision_ms'])
        self._efe=None
        if self.learner is None:return baseline
        active=self.last['active']
        acc=longitudinal_acceleration(rv)
        observation=None if rv is None or acc is None else motion_observation(rv,.5*self.cruise)
        posterior=self.belief.update(vehicle_id(rv),observation,self.last['p_yield'],.05,
            following=bool(self._motion_evidence.get('visible_leader_explains_slowdown',False)))
        predicted=self.belief.predicted(vehicle_id(rv),self.last['p_yield'],6.)
        if active:
            self._efe=candidate_efe(self.last['components'],predicted,self.last['standoff'],
                                    self.preference,self.gap_sigma)
        allowed=self.learning_candidates(ego,objects,candidates,path,previous,baseline,active)
        emergency=not allowed
        if emergency:allowed=[baseline]
        self._engaged=self._engaged or active
        phase={'approach':0.,'merging':1.,'merged':2.}[self.last['phase']]
        leaders=[] if rv is None else visible_leaders(rv,objects+[ego])
        gap,front_v=min(leaders,default=(50.,0.))
        context=[self.last['standoff'],ego.v,0. if rv is None else rv.x-float(conf.get('conflict_x',4.)),
            0. if rv is None else rv.v,0. if acc is None else max(-5.,min(2.,acc)),
            max(-5.,min(50.,gap)),front_v,previous['a'],previous['df'],phase]
        key=(vehicle_id(rv),baseline,tuple(allowed),phase)
        decision=self._engaged and (self.learner.pending is None or self._control_key!=key
                                    or self._policy_age>=self.decision_period-1e-9)
        if decision:
            self.learner.begin(context,posterior,baseline,allowed,self.episode)
            epsilon=0. if self.learning_phase=='eval' or not active or self.epsilon==0. else max(.05,self.epsilon*.97**(self.episode-1))
            selected,_=self.learner.select(epsilon=epsilon,rng=self.rng)
            self.learner.start_action(selected)
            self._policy_age=0.;self._control_key=key
        else:
            selected=baseline if not self._engaged else self.learner.choice
        if selected not in allowed:raise RuntimeError('Candidate request left its admissible option')
        if self._engaged:
            self.last['decision_mode']='candidate_learning'
        self.last.update(selected=selected,switch=self._last_request is not None and self._last_request!=selected,
            learning=dict(self.learner.last if self._engaged else {},
                active=bool(active),engaged=self._engaged,decision=bool(decision),phase=self.learning_phase,
                cg=baseline,requested=selected,emergency_only=emergency,allowed=allowed,
                belief=posterior.tolist(),predicted_belief=predicted.tolist(),
                observation_applied=self.belief.observation_applied,evidence=self.belief.last_evidence,
                rv_id=vehicle_id(rv),efe=self._efe,
                state_key=self.learner.current if self._engaged else None,
                **self.learning_diagnostics()))
        self._last_request=selected
        self.last_action=selected if active else None
        self.last['decision_ms']=(time.perf_counter()-started)*1000.
        return selected

    def feedback(self,episode,frame,audit,applied,outcome=None):
        if self.learner is None:return
        if int(applied['control_submit_ok'])!=1:
            raise RuntimeError('Cannot learn from an unsubmitted control')
        self.episode=int(episode)
        row=self.last['learning']
        intervention=bool(audit['override'] or audit['unavoidable'])
        realized_efe=0.
        executed_distribution=None
        if self.efe_enabled and self._efe is not None:
            if intervention:
                selected=next(c for c in audit['candidates'] if c['action']==audit['action'])
                part=dict(selected)
                # Same already-computed guard forecast; no imaginary requested
                # action is charged after a physically different intervention.
                from Planning_library.candidate_learning_v19 import outcome_distribution
                dist=outcome_distribution(part,self.last['standoff'],self.gap_sigma)
                executed_distribution=dist.tolist()
                realized_efe=-joint_efe([dist]*6,row['predicted_belief'],self.preference)['reward']
            else:realized_efe=-self._efe[row['requested']]['reward']
        realized_task=task_reward(applied,.05,outcome,intervention)
        if self.reward_mode=='negative_efe':
            terminal=0.
            if outcome is not None:
                index=0 if outcome=='complete' else 3
                terminal=math.log(float(self.preference[index]))
            reward=-.05*realized_efe+terminal
        else:reward=realized_task-self.efe_weight*.05*realized_efe
        if self._engaged:self.learner.record_reward(reward,forced=intervention)
        self._policy_age+=.05
        row.update(episode=int(episode),frame=int(frame),intervention=intervention,
            guard_action=audit['action'],executed_a=float(applied['a_cmd']),
            executed_delta=float(applied['delta_rad']),executed_target=float(applied['actuator_speed_target']),
            executed_speed=float(applied['ego_v_after']),executed_distribution=executed_distribution,
            outcome=outcome,task_reward=realized_task,realized_efe=realized_efe,reward=reward,
            reward_mode=self.reward_mode,dt=.05,
            posterior_action_queue=False,model_updated=self.learning_phase=='train' and self._engaged)
        if self.directory is not None:
            with (self.directory/'candidate_learning.jsonl').open('a',encoding='utf8') as stream:
                stream.write(json.dumps(row,allow_nan=False)+'\n')
        if outcome is not None:
            self.learner.finish()
            self.episode=int(episode)+1
