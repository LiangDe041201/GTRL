"""Motion families conditioned on visible leaders and each ego candidate.

Only public pose, box and velocity observations are read. Recovery is retained
when space opens. Braking is bounded, so a late cut-in remains a risk instead
of being erased by a position/speed clamp. Response delays are hypotheses,
not calibrated driver parameters or a safety certificate.
"""
import math
import numpy as np

from Planning_library.paper_turn_control import motion
from Planning_library.vehicle_observation import vehicle_id,vehicle_size,longitudinal_acceleration
from Planning_library.rv_decision import idm_acceleration


def tracks(vehicle,times,cruise=4.412022451715821,ego=None,ego_states=None,
           objects=(),yielding=False,acceleration=None):
    times = np.asarray(times,dtype=float)
    if (times.ndim != 1 or len(times)<2 or times[0] != 0. or
            not np.isfinite(times).all() or np.any(np.diff(times)<=0.) or
            not math.isfinite(cruise) or cruise<=0.):
        raise ValueError('Invalid conditional forecast times/cruise')
    grid = np.linspace(0.,float(times[-1]),max(1,int(math.ceil(times[-1]/.05)))+1)
    vx,vy = motion(vehicle)
    initial_speed = math.hypot(vx,vy)
    ux,uy = (vx/initial_speed,vy/initial_speed) if initial_speed>.05 else (math.cos(vehicle.yaw),math.sin(vehicle.yaw))
    yaw = math.atan2(uy,ux)
    half_length,half_width = vehicle_size(vehicle,'length',4.)/2.,vehicle_size(vehicle,'width',2.)/2.
    leaders = []

    def add_leader(other,x,y,heading,speed):
        difference = heading-yaw
        length = vehicle_size(other,'length',4.5)/2.
        width = vehicle_size(other,'width',2.)/2.
        leaders.append(((x-vehicle.x)*ux+(y-vehicle.y)*uy,
            np.abs(-(x-vehicle.x)*uy+(y-vehicle.y)*ux),
            length*np.abs(np.cos(difference))+width*np.abs(np.sin(difference)),
            length*np.abs(np.sin(difference))+width*np.abs(np.cos(difference)),speed))

    if ego is not None:
        states = np.asarray(ego_states,dtype=float)
        if states.shape != (7,len(times)) or not np.isfinite(states).all():
            raise ValueError('Conditional forecast needs the complete ego rollout')
        x,y,heading = (np.interp(grid,times,states[i]) for i in (0,1,6))
        forward = np.gradient(x,grid)*ux+np.gradient(y,grid)*uy
        add_leader(ego,x,y,heading,np.maximum(forward,0.))
    for other in objects:
        identity = vehicle_id(other)
        if (other is vehicle or identity is not None and identity==vehicle_id(vehicle)
                or ego is not None and (other is ego or identity is not None and identity==vehicle_id(ego))):
            continue
        ovx,ovy = motion(other)
        if ovx*ux+ovy*uy < -.1:
            continue
        add_leader(other,other.x+ovx*grid,other.y+ovy*grid,
                   np.full(len(grid),other.yaw),np.full(len(grid),max(0.,ovx*ux+ovy*uy)))
    observed = longitudinal_acceleration(vehicle) if acceleration is None else acceleration
    observed = 0. if observed is None else max(-3.,min(2.,float(observed)))
    family = []
    modes = ('yield',) if yielding else ('cv','observed','recover_now','recover_later')
    for mode in modes:
        for response_delay in (0.,.3):
            speed,position = initial_speed,0.
            positions = [0.]
            seen = {}
            for k in range(len(grid)-1):
                t,dt = float(grid[k]),float(grid[k+1]-grid[k])
                if mode == 'yield':
                    desired = min(0.,max(-2.5,(min(initial_speed,.3*cruise)-speed)/dt))
                    if t<1.:
                        desired = min(desired,observed)
                elif mode == 'cv':
                    desired = 0.
                elif mode == 'observed' or mode == 'recover_later' and t<1.-1e-9:
                    desired = observed if t<1.-1e-9 else 0.
                else:
                    desired = max(0.,2.*(1.-(speed/cruise)**4)) if speed<cruise else 0.
                for j,(along,across,long_extent,lat_extent,front_speed) in enumerate(leaders):
                    present = along[k]>position and across[k]<half_width+lat_extent[k]-.05
                    if not present:
                        seen.pop(j,None)
                        continue
                    seen.setdefault(j,t)
                    if t-seen[j]+1e-9 >= response_delay:
                        gap = along[k]-position-half_length-long_extent[k]
                        desired = min(desired,idm_acceleration(speed,front_speed[k],max(.01,float(gap)),
                            v0=max(6.,cruise),T=.5,g0=2.,a=2.,b=2.5,delta=4.))
                acc = max(-5.,min(2.,float(desired)))
                next_speed = max(0.,speed+acc*dt)
                position += .5*(speed+next_speed)*dt
                speed = next_speed
                positions.append(position)
            distances = np.interp(times,grid,positions)
            family.append(np.c_[vehicle.x+ux*distances,vehicle.y+uy*distances,
                                np.full(len(times),vehicle.yaw)])
    return family
