"""Method dispatch and the retained v6 Cournot utility.

Default paper_v7 control uses shared efficiency/comfort terms in MPC.py and
relative-motion interaction risk from paper_turn_control.py. The stage_cost
and two-role selection below are retained for the explicit legacy profile;
they are not appended to the v7 controller objective.

The opponent forecast is an observed-state, constant-velocity approximation;
it is not an optimized RV action. Equation 24 supplies the three cost families.
For the left-turn deployment, ``deficit`` penalizes insufficient THW only;
``eq24`` exposes the paper's symmetric threshold-deviation objective explicitly.
Neither objective grants permission to cross the separate entry safety gate.
"""
import math

from Planning_library.vehicle_observation import vehicle_id, vehicle_size


def game_configuration(method, enabled=True, mode='mpc'):
    method, mode = str(method).upper(), str(mode).lower()
    if method not in ('GTRL', 'CG', 'SG', 'RULE'):
        raise ValueError('DSH_METHOD must be GTRL, CG, SG or RULE')
    if mode not in ('mpc', 'discrete', 'matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20'):
        raise ValueError('DSH_COURNOT_MODE must be mpc/discrete/matrix/matrix_legacy/matrix_v14/matrix_v16')
    if mode in ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18') and method not in ('RULE', 'CG'):
        raise ValueError('Matrix experiment requires RULE or CG; learning is tested separately')
    candidate_learning = mode in ('matrix_v19','matrix_v20')
    if candidate_learning and (method != 'GTRL' or not enabled):
        raise ValueError('Candidate learning requires GTRL and the common matrix controller')
    cournot = bool(enabled) and method in ('CG', 'GTRL')
    return dict(controller=('mpc_cournot' if mode == 'mpc' else
                            'matrix_v13' if mode == 'matrix' else
                            'matrix_v14' if mode == 'matrix_v14' else
                            'matrix_v16' if mode == 'matrix_v16' else
                            'matrix_v17' if mode == 'matrix_v17' else
                            'matrix_v18' if mode == 'matrix_v18' else
                            'matrix_v19' if mode == 'matrix_v19' else
                            'matrix_v20' if mode == 'matrix_v20' else
                            'matrix_legacy' if mode == 'matrix_legacy' else 'discrete_cournot')
                if cournot else 'stackelberg' if method == 'SG' else 'none',
                mpc=cournot and mode == 'mpc', discrete=cournot and mode == 'discrete',
                matrix=cournot and mode in ('matrix', 'matrix_legacy', 'matrix_v14', 'matrix_v16', 'matrix_v17', 'matrix_v18', 'matrix_v19', 'matrix_v20'),
                stackelberg=method == 'SG', learning=method == 'GTRL' and not candidate_learning,
                candidate_learning=candidate_learning)


def validate_cost_parameters(weights, thw_threshold, jerk_threshold, steering_threshold,
                             safety_mode):
    numbers = tuple(float(x) for x in weights)
    thresholds = tuple(float(x) for x in (thw_threshold, jerk_threshold, steering_threshold))
    if (len(numbers) != 3 or any(not math.isfinite(x) or x < 0. for x in numbers)
            or any(not math.isfinite(x) or x < 0. for x in thresholds)
            or safety_mode not in ('deficit', 'eq24')):
        raise ValueError('Invalid Cournot MPC weights, thresholds or safety mode')
    return numbers, thresholds


def stage_cost(speed, reference_speed, headways, jerk, steering_rate,
               weights=(1., 2., .3), thw_threshold=1.5,
               jerk_threshold=.5, steering_threshold=.3,
               safety_mode='deficit', terminal=False):
    """Return cost components; headways contains (THW, presence) for each role.

    CasADi expressions remain symbolic. Missing roles contribute zero rather
    than a fabricated safe observation. Rates use actual successive controls,
    not yaw rate or a constant trajectory proxy. The deployment's deficit mode
    also treats the comfort thresholds as limits, not nonzero desired rates.
    """
    import casadi as ca
    present = ca.fmin(1., sum(mask for _, mask in headways))
    safety = 0.
    for thw, mask in headways:
        error = thw - thw_threshold if safety_mode == 'eq24' else ca.fmax(thw_threshold-thw, 0.)
        safety += mask * error ** 2
    if terminal:
        comfort = 0.
    elif safety_mode == 'eq24':
        comfort = (jerk-jerk_threshold) ** 2 + (steering_rate-steering_threshold) ** 2
    else:
        comfort = (ca.fmax(ca.fabs(jerk)-jerk_threshold, 0.) ** 2
                   + ca.fmax(ca.fabs(steering_rate)-steering_threshold, 0.) ** 2)
    components = dict(speed=present*weights[0]*(speed-reference_speed) ** 2,
                      safety=weights[1]*safety, comfort=present*weights[2]*comfort)
    components['total'] = sum(components.values())
    return components


def observed_game_vehicles(conf, entry_zone=15.):
    """Use the exact FV/RV snapshot selected by the conflict observer.

    Do not silently substitute lane.rear_vehicles[0], which can be a different
    participant. The entry zone and committed phase are shared with the agent.
    """
    if (not conf or bool(conf.get('committed'))
            or float(conf.get('arc_to_cross', float('inf'))) > float(entry_zone)):
        return (None, None)
    result, used = [], set()
    for role in ('rv_veh', 'fv_veh'):
        vehicle = conf.get(role)
        actor = vehicle_id(vehicle)
        if vehicle is None or actor is None or actor in used:
            result.append(None)
        else:
            used.add(actor)
            result.append(vehicle)
    return tuple(result)


def vehicle_forecast(vehicle, count, dt):
    """Observed kinematics and actual box dimensions at count future instants."""
    if vehicle is None:
        return [[1000., 1000., 0., 4., 2.] for _ in range(count)]
    x, y, yaw = (float(getattr(vehicle, k)) for k in ('x', 'y', 'yaw'))
    vx, vy = getattr(vehicle, 'vx', None), getattr(vehicle, 'vy', None)
    if vx is None or vy is None:
        speed = max(float(vehicle.v), 0.)
        vx, vy = speed*math.cos(yaw), speed*math.sin(yaw)
    vx, vy = float(vx), float(vy)
    if not all(math.isfinite(v) for v in (x, y, yaw, vx, vy)):
        raise ValueError('Nonfinite observed Cournot participant motion')
    length, width = vehicle_size(vehicle, 'length', 4.), vehicle_size(vehicle, 'width', 2.)
    return [[x+vx*k*dt, y+vy*k*dt, yaw, length, width] for k in range(count)]
