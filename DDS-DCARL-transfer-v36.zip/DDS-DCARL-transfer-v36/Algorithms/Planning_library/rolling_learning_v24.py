"""Six semantic rolling actions, empirical soft backups and clustered trust.

Only actually submitted action owners collect experience. Bounds on empirical
bootstrapped targets are diagnostics, not a Hoeffding guarantee for optimal Q.
The reference distribution is a declared softened fixed geometry policy; it
is not a measured confidence that the CG action is correct.
"""
from collections import defaultdict
import json
import math
from pathlib import Path
import numpy as np
from Planning_library.soft_bellman import soft_value_policy
from Planning_library.rolling_trajectory_v24 import ACTION_NAMES


class RollingLearner:
    ACTION_NAMES=ACTION_NAMES
    WIDTHS=(3.,1.,1.,6.,4.,1.,1.,5.,1.,.25,.1,1.,.15,1.,1.,1.)

    def __init__(self,phase='train',checkpoint=None,gamma=2.**(-.05/10.),alpha=.1,min_episodes=10):
        if (phase not in ('observe','fixed','train','eval') or not 0.<gamma<1.
                or not math.isfinite(alpha) or alpha<=0. or min_episodes<2):
            raise ValueError('Invalid rolling learner configuration')
        self.phase,self.gamma,self.alpha,self.min_episodes=phase,float(gamma),float(alpha),int(min_episodes)
        self.nodes,self.q,self.records={}, {}, []
        self.edges=defaultdict(list)
        self.pending=self.current=None
        self.last={}; self.sweeps=0; self.residual=None
        if phase=='eval' and checkpoint is None: raise ValueError('Evaluation requires a rolling checkpoint')
        if checkpoint is not None:
            data=json.loads(Path(checkpoint).read_text(encoding='utf8'))
            if data.get('signature')!=self.signature(): raise ValueError('State/action/reward schema differs')
            self.nodes,self.records=data['nodes'],data['records']
            self.q={k:np.asarray(v,dtype=float) for k,v in data['q'].items()}
            if set(self.q)!=set(self.nodes) or any(v.shape!=(len(self.ACTION_NAMES),) or not np.isfinite(v).all() for v in self.q.values()):
                raise ValueError('Invalid rolling values')
            for r in self.records:
                if (r['state'] not in self.nodes or r['next'] is not None and r['next'] not in self.nodes
                        or r['action'] not in self.nodes[r['state']]['allowed']):
                    raise ValueError('Invalid recorded transition')
                self.edges[(r['state'],r['action'])].append(r)
        self.checkpoint_keys=frozenset(self.nodes)

    def signature(self):
        return dict(schema='rolling_trajectory_learning_v24',actions=list(self.ACTION_NAMES),widths=list(self.WIDTHS),
            gamma=self.gamma,alpha=self.alpha,min_episodes=self.min_episodes,
            beta='exposed_deceleration_probability_beta_v22',reward='measured_task_v19_without_EFE',
            reference_policy='exp_minus_fixed_cost_clipped_0_2',confidence_guarantee=False)

    def begin(self,context,beta,default,allowed,costs,episode):
        x=np.asarray(context,dtype=float); costs=np.asarray(costs,dtype=float)
        allowed=sorted(set(int(a) for a in allowed)); default=int(default)
        a,b=float(beta['alpha']),float(beta['beta'])
        count=len(self.ACTION_NAMES)
        if (x.shape!=(16,) or not np.isfinite(x).all() or costs.shape!=(count,)
                or not np.isfinite(costs).all() or not allowed or default not in allowed
                or any(v<0 or v>=count for v in allowed) or min(a,b)<1. or not math.isfinite(a+b)):
            raise ValueError('Invalid rolling decision context')
        mean,var=a/(a+b),a*b/((a+b)**2*(a+b+1.))
        key=json.dumps([np.rint(x/self.WIDTHS).astype(int).tolist(),
                        [int(round(mean*4)),int(round(var/.02))],default,allowed],separators=(',',':'))
        if key not in self.nodes:
            logits=-np.clip((costs[allowed]-min(costs[allowed]))/(1.+abs(min(costs[allowed]))),0.,2.)
            prior=np.zeros(count); prior[allowed]=np.exp(logits); prior/=prior.sum()
            self.nodes[key]=dict(context=x.tolist(),beta=dict(alpha=a,beta=b),default=default,
                                 allowed=allowed,prior=prior.tolist())
            self.q[key]=np.zeros(count)
        self._close(key)
        self.current,self.episode=key,int(episode)
        self.context=x.tolist(); self.beta=dict(alpha=a,beta=b)
        self.iterate(3)
        return key

    def _values(self):
        # The offline rebuild uses a scalar check of the batched result.
        return {key:soft_value_policy(q,self.nodes[key]['prior'],self.alpha)[0] for key,q in self.q.items()}

    def _samples(self,key,action,values=None):
        values = {} if values is None else values
        episodes = defaultdict(list)
        for record in self.edges.get((key,action), ()):
            next_key = record['next']
            target = record['reward']
            if next_key is not None:
                if next_key not in values:
                    values[next_key] = soft_value_policy(
                        self.q[next_key],self.nodes[next_key]['prior'],self.alpha)[0]
                target += record['discount']*values[next_key]
            episodes[record['episode']].append(target)
        return [float(np.mean(samples)) for samples in episodes.values()]

    def _bound_inputs(self):
        values = {}
        groups = {action:self._samples(self.current,action,values)
                  for action in self.nodes[self.current]['allowed']}
        targets = [value for samples in groups.values() for value in samples]
        return groups, max(targets)-min(targets) if targets else 0.

    def bounds(self,action):
        return self._bounds(int(action),*self._bound_inputs())

    def _bounds(self,action,groups,span):
        node=self.nodes[self.current]
        samples=groups.get(action,[]); n=len(samples)
        mean=float(np.mean(samples)) if n else 0.
        sigma=float(np.std(samples,ddof=1)) if n>1 else 0.
        delta=span*math.sqrt(math.log(20.)/(2*n)) if n else float('inf')
        probability=node['prior'][action]
        cost=-self.alpha*math.log(probability) if probability>0. else float('inf')
        return dict(n=n,mean=mean,sigma=sigma,delta=delta,information_cost=cost,
                    wcv=mean-delta-4.*sigma/(n+1)-cost,bcv=mean+delta-cost)

    def _exploration_action(self,node,bounds,rng):
        least=min(v['n'] for v in bounds.values())
        return int(rng.choice([a for a in node['allowed'] if bounds[a]['n']==least]))

    def choose(self,epsilon=0.,rng=None):
        if self.current is None or not 0.<=epsilon<=1.: raise ValueError('Begin before selecting')
        node=self.nodes[self.current]; default=node['default']
        groups, span = self._bound_inputs()
        bounds={a:self._bounds(a,groups,span) for a in node['allowed']}
        alternatives=[a for a in node['allowed'] if a!=default
            and min(bounds[a]['n'],bounds[default]['n'])>=self.min_episodes
            and bounds[a]['wcv']>bounds[default]['bcv']]
        choice=max(alternatives,key=lambda a:bounds[a]['wcv']) if alternatives else default
        source='takeover' if alternatives else 'fixed_default'
        if self.phase=='observe': choice,source=0,'observe_cg'
        elif self.phase=='fixed': choice,source=default,'fixed_default'
        elif self.phase=='train' and epsilon>0. and len(node['allowed'])>1:
            rng=np.random if rng is None else rng
            under=min(v['n'] for v in bounds.values())<self.min_episodes
            if rng.random_sample()<max(epsilon,.5 if under else 0.):
                explore=self._exploration_action(node,bounds,rng)
                if explore is not None: choice,source=explore,'explore'
        finite=lambda d:{k:(v if not isinstance(v,float) or math.isfinite(v) else None) for k,v in d.items()}
        self.last=dict(state=self.current,default=default,requested=choice,source=source,
            certified=source=='takeover',bounds={str(a):finite(v) for a,v in bounds.items()},
            prior=list(node['prior']),unseen=self.current not in self.checkpoint_keys,
            epsilon=epsilon if self.phase=='train' else 0.,confidence_guarantee=False)
        return choice

    def start(self,actual_action):
        action=int(actual_action)
        if self.pending is not None or self.current is None or action not in self.nodes[self.current]['allowed']:
            raise ValueError('Start only an actual admissible action with no pending option')
        self.pending=dict(state=self.current,action=action,episode=self.episode,
            context=list(self.context),beta=dict(self.beta),reward=0.,discount=1.,steps=0,interventions=0)

    def reward(self,value,intervention=False):
        if not math.isfinite(value): raise ValueError('Nonfinite realized reward')
        if self.pending is not None:
            self.pending['reward']+=self.pending['discount']*float(value)
            self.pending['discount']*=self.gamma
            self.pending['steps']+=1
            self.pending['interventions']+=int(bool(intervention))

    def _close(self,next_key=None):
        if self.pending is not None and self.pending['steps'] and self.phase=='train':
            r=dict(self.pending,next=next_key)
            self.records.append(r); self.edges[(r['state'],r['action'])].append(r)
        self.pending=None

    def iterate(self,sweeps=50):
        if self.phase!='train' or not self.edges or sweeps<=0: return
        keys = list(self.q)
        state_index = {key:index for index,key in enumerate(keys)}
        q = np.stack([self.q[key] for key in keys])
        priors = np.asarray([self.nodes[key]['prior'] for key in keys],dtype=float)
        totals = priors.sum(axis=1,keepdims=True)
        if (priors.shape!=q.shape or not np.isfinite(priors).all() or np.any(priors<0.)
                or not np.isfinite(totals).all() or np.any(totals<=0.)):
            raise ValueError('Invalid rolling action prior')
        priors = priors/totals
        supported = priors>0.
        log_prior = np.full_like(priors,-np.inf)
        log_prior[supported] = np.log(priors[supported])

        edge_states, edge_actions, cluster_edges = [], [], []
        record_clusters, next_states, rewards, discounts = [], [], [], []
        for edge, ((state,action),records) in enumerate(self.edges.items()):
            edge_states.append(state_index[state])
            edge_actions.append(action)
            episode_clusters = {}
            for record in records:
                episode, next_key = record['episode'], record['next']
                if episode not in episode_clusters:
                    episode_clusters[episode] = len(cluster_edges)
                    cluster_edges.append(edge)
                record_clusters.append(episode_clusters[episode])
                next_states.append(len(keys) if next_key is None else state_index[next_key])
                rewards.append(record['reward'])
                discounts.append(0. if next_key is None else record['discount'])
        edge_states, edge_actions, cluster_edges, record_clusters, next_states = (
            np.asarray(items,dtype=np.intp) for items in
            (edge_states,edge_actions,cluster_edges,record_clusters,next_states))
        rewards, discounts = np.asarray(rewards,dtype=float),np.asarray(discounts,dtype=float)
        cluster_sizes = np.bincount(record_clusters)
        edge_sizes = np.bincount(cluster_edges)

        for _ in range(sweeps):
            # Synchronous soft Bellman backup, with zero continuation for terminal records.
            if not np.isfinite(q).all(): raise ValueError('Invalid rolling action values')
            peak = np.max(np.where(supported,q,-np.inf),axis=1,keepdims=True)
            with np.errstate(over='ignore',under='ignore'):
                logits = log_prior+(np.where(supported,q,peak)-peak)/self.alpha
                shift = logits.max(axis=1,keepdims=True)
                log_z = shift[:,0]+np.log(np.exp(logits-shift).sum(axis=1))
            values = np.append(peak[:,0]+self.alpha*log_z,0.)
            targets = rewards+discounts*values[next_states]
            cluster_means = np.bincount(record_clusters,weights=targets)/cluster_sizes
            updates = np.bincount(cluster_edges,weights=cluster_means)/edge_sizes
            self.residual = float(np.max(np.abs(q[edge_states,edge_actions]-updates)))
            q[edge_states,edge_actions] = updates
            self.sweeps+=1
            if self.residual<1e-7: break
        for key,row in zip(keys,q): self.q[key][:] = row

    def finish(self): self._close(); self.iterate()

    def save(self,path):
        if self.phase!='train': raise ValueError('Frozen/observe/fixed modes cannot save models')
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
        data=dict(signature=self.signature(),nodes=self.nodes,records=self.records,
                  q={k:v.tolist() for k,v in self.q.items()})
        path.write_text(json.dumps(data,allow_nan=False),encoding='utf8')
