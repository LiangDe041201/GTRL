#!/usr/bin/env python3
"""【0' 诊断】参考线几何诊断（纯 numpy/math，无 CARLA，离线可对拍）。

背景：实测自车在**路口转弯段**偏离参考路线 2~6 m（`arc<6 m` 时 `lat` 中位 4.1~5.0 m，
100% 的帧 >2 m；直线段 ≤0.5 m）。但代码结构决定了 `di=0` 的生成轨迹**就是那条三次样条**：

    self.ref_path = dense_polyline2d(lane_path, 2)   # env.ref_path_array 同一条折线
    self.csp      = Spline2D(ref_path.x, ref_path.y) # 自然三次样条（弦长参数化）
    fx = csp.calc_position(s) + di·cos(yaw+π/2)      # Frenet→笛卡尔

所以 5 m 的偏差只可能是三者之一，且修法完全不同：
  ① **样条拟合误差**：样条在路口段偏离其输入折线   → 换参考线表示（不是修 Frenet）
  ② **MPC 跟踪误差**：自车偏离它被给定的轨迹       → 修控制器
  ③ **坐标系错配**：冲突几何与轨迹不是同一条线     → 统一基准
本模块只提供**测量**这三个量的纯函数，不改任何行为。
"""
import math

import numpy as np


def cumulative_arclength(xy):
    """折线累计弧长（长度 N，s[0]=0）。"""
    p = np.asarray(xy, dtype=float)
    if len(p) == 0:
        return np.zeros(0)
    if len(p) == 1:
        return np.zeros(1)
    seg = np.linalg.norm(np.diff(p, axis=0), axis=1)
    return np.concatenate([[0.0], np.cumsum(seg)])


def discrete_curvature(xy, closed=False):
    """逐点离散曲率（相邻三点外接圆），返回 (kappa, radius)。

    kappa[i] = 2·cross(v1,v2) / (|v1|·|v2|·|v1+v2|)   （三点外接圆公式）
    端点沿用相邻点的值（前向/后向差分）。
    `radius = 1/|kappa|`；直线处 kappa=0 -> radius=inf。
    """
    p = np.asarray(xy, dtype=float)
    n = len(p)
    k = np.zeros(n, dtype=float)
    if n < 3:
        return k, np.full(n, float('inf'))
    for i in range(1, n - 1):
        v1 = p[i] - p[i - 1]
        v2 = p[i + 1] - p[i]
        a = float(np.linalg.norm(v1))
        b = float(np.linalg.norm(v2))
        c = float(np.linalg.norm(v1 + v2))
        if a < 1e-9 or b < 1e-9 or c < 1e-9:
            k[i] = 0.0
            continue
        cross = float(v1[0] * v2[1] - v1[1] * v2[0])
        k[i] = 2.0 * cross / (a * b * c)
    k[0] = k[1]
    k[-1] = k[-2]
    with np.errstate(divide='ignore'):
        r = np.where(np.abs(k) > 1e-12, 1.0 / np.abs(k), np.inf)
    return k, r


def spline_applicability(xy):
    """三次样条的适用性判据：逐点 `Δs / R`（路点间距 / 曲率半径）。

    ⚠ 一个重要性质（推导）：对半径 R、角度步长 Δa 的圆弧，
        Δs/R = 2·sin(Δa/2)
    **与 R 无关**，只取决于**角度步长**。所以该判据本质是"角度分辨率"判据：

        Δa = 30° → 0.52     Δa = 60° → 1.00（临界）
        Δa = 45° → 0.77     Δa = 75° → 1.22    Δa = 90° → 1.41

    含义：同样是 2 m 的路点间距，在直线段（R=∞）完全没问题，在紧弯里
    （角度步长 > 60°）就进入自然三次样条的振荡区。**这就是"直线段贴合、
    路口段跑偏"的可能机理**，本函数就是用来证实/否证它的。

    经验阈值：
      Δs/R < 0.5  → 样条拟合良好
      0.5 ~ 1.0   → 临界，会出现可见过冲
      > 1.0       → 严重欠采样，样条与输入折线的偏差可达米级 ⇒ 应换参考线表示
                    （加密采样 / 改用圆弧或螺旋线 / 直接以折线做 Frenet 基）

    返回 dict: ds(每点前后间距均值), ratio(Δs/R), kappa, radius,
               max_ratio, n_over_0p5, n_over_1p0, worst_idx
    """
    p = np.asarray(xy, dtype=float)
    n = len(p)
    k, r = discrete_curvature(p)
    if n < 2:
        return {'ds': np.zeros(n), 'ratio': np.zeros(n), 'kappa': k, 'radius': r,
                'max_ratio': 0.0, 'n_over_0p5': 0, 'n_over_1p0': 0, 'worst_idx': 0}
    seg = np.linalg.norm(np.diff(p, axis=0), axis=1)
    ds = np.empty(n, dtype=float)
    ds[0] = seg[0]
    ds[-1] = seg[-1]
    if n > 2:
        ds[1:-1] = 0.5 * (seg[:-1] + seg[1:])
    with np.errstate(divide='ignore'):
        ratio = np.where(np.isfinite(r), ds / np.maximum(r, 1e-9), 0.0)
    return {'ds': ds, 'ratio': ratio, 'kappa': k, 'radius': r,
            'max_ratio': float(np.max(ratio)) if n else 0.0,
            'n_over_0p5': int(np.sum(ratio > 0.5)),
            'n_over_1p0': int(np.sum(ratio > 1.0)),
            'worst_idx': int(np.argmax(ratio)) if n else 0}


def lateral_deviation(reference_xy, query_xy, cumlen=None):
    """把 `query_xy` 的每个点投影到 `reference_xy` 折线，返回逐点横向偏差（m）。

    返回 (lat[N], s[N])：lat=垂距，s=投影点沿参考线的弧长。
    """
    ref = np.asarray(reference_xy, dtype=float)
    q = np.asarray(query_xy, dtype=float)
    if len(ref) < 2 or len(q) == 0:
        return np.zeros(len(q)), np.zeros(len(q))
    if cumlen is None:
        cumlen = cumulative_arclength(ref)
    a = ref[:-1]
    ab = ref[1:] - a
    seg = np.linalg.norm(ab, axis=1)
    den = np.where(seg < 1e-12, 1e-12, seg)
    lats = np.empty(len(q), dtype=float)
    ss = np.empty(len(q), dtype=float)
    for j, pt in enumerate(q):
        t = np.einsum('ij,ij->i', pt - a, ab) / (den ** 2)
        t = np.clip(t, 0.0, 1.0)
        proj = a + t[:, None] * ab
        d = np.linalg.norm(pt - proj, axis=1)
        i = int(np.argmin(d))
        lats[j] = float(d[i])
        ss[j] = float(cumlen[i]) + float(t[i]) * float(seg[i])
    return lats, ss


def deviation_summary(reference_xy, query_xy, label=''):
    """横向偏差的统计摘要（含"最差点落在哪个弧长区间"）。"""
    lat, s = lateral_deviation(reference_xy, query_xy)
    if len(lat) == 0:
        return {}
    i = int(np.argmax(lat))
    return {'label': label, 'n': int(len(lat)),
            'lat_mean': float(np.mean(lat)), 'lat_p50': float(np.median(lat)),
            'lat_p90': float(np.percentile(lat, 90)), 'lat_max': float(np.max(lat)),
            'worst_s': float(s[i]),
            's_at_max_lat': float(s[i])}


def param_vs_arclength_error(samples_xy, param_s):
    """样条的"参数 s"与"真实弧长"的偏差。

    `Spline2D` 用**输入路点的弦长**做参数（`__calc_s` 累加相邻点距离），
    而 `calc_position(s)` 是按该参数插值；若样条实际弧长 ≠ 弦长参数，
    则 `s` 作为"里程"使用会系统性偏短/偏长，Frenet 的 s 也就不是里程。

    返回 (err[N], max_abs_err, rel_err_max)
    """
    p = np.asarray(samples_xy, dtype=float)
    s = np.asarray(param_s, dtype=float)
    if len(p) < 2:
        return np.zeros(len(p)), 0.0, 0.0
    true_s = cumulative_arclength(p)
    err = np.asarray(s, dtype=float) - true_s
    denom = np.maximum(np.abs(true_s), 1e-9)
    return err, float(np.max(np.abs(err))), float(np.max(np.abs(err) / denom))


def curvature_exceeds_limit(xy, max_curvature=0.2):
    """曲率是否超出常用车辆/样条适用范围（默认 |κ|>0.2 即 R<5m 视为超限）。"""
    k, r = discrete_curvature(xy)
    if len(k) == 0:
        return False, 0.0, float('inf')
    mk = float(np.max(np.abs(k)))
    with np.errstate(divide='ignore'):
        mr = 1.0 / mk if mk > 1e-12 else float('inf')
    return bool(mk > max_curvature), mk, mr
