"""Finite closed-loop forecast hypothesis, not an identified CARLA plant.

The dense .3s MPC prefix is retained; after it, path feedback approximates
future replanning instead of holding a stale 2.3s open-loop steering plan.
All six seconds retain physical states, clearance checks and route validity.
"""
import math
import numpy as np

from Planning_library.forecast_v16 import covered_route, command_acceleration
from Planning_library.vehicle_observation import longitudinal_acceleration, vehicle_size
from Planning_library.boundary_safety import wait_standoff


def checked_prefix(states,times,stop_after):
    if stop_after is None:
        return states,times
    count=int(np.searchsorted(times,stop_after+1.e-9,side='right'))
    return states[:,:count],times[:count]


def prediction_geometry(geometry,road_route,navigation_route):
    from Planning_library.forecast_v17 import prediction_geometry as base_geometry
    result = base_geometry(geometry,road_route,navigation_route)
    result.update(forecast_model='route_v18',opponent_model='leader_conditioned_v18')
    return result


def predict(ego,path,target,first_a,first_delta,previous,geometry,
            horizon=6.,lag=.4,plan=None,plan_times=None,stop_after=None):
    if (not math.isfinite(horizon) or horizon <= 0. or lag < 0.
            or stop_after is not None and not 0. < stop_after < horizon):
        raise ValueError('Invalid forecast horizon/response')
    route,diag = covered_route(path,geometry)
    dt = .05
    times = np.r_[np.arange(0.,horizon,dt),horizon]
    if plan is not None:
        plan,plan_times = np.asarray(plan,dtype=float),np.asarray(plan_times,dtype=float)
        if (plan.ndim != 2 or plan.shape[0] != 2 or plan.shape[1]+1 != len(plan_times)
                or not np.isfinite(plan).all() or not np.isfinite(plan_times).all()
                or plan_times[0] != 0. or np.any(np.diff(plan_times) <= 0.)):
            raise ValueError('Invalid forecast control plan')
    prefix = min(.3,float(plan_times[-1])) if plan is not None else 0.
    x,y,yaw,speed = float(ego.x),float(ego.y),float(ego.yaw),max(0.,float(ego.v))
    actual_a = longitudinal_acceleration(ego)
    actual_a = 0. if actual_a is None else max(-3.,min(2.,actual_a))
    delta = float(previous['df'])
    wheelbase,maximum = float(geometry['wheelbase']),min(1.,float(geometry['max_steer']))
    states = np.zeros((7,len(times)))
    projections,errors,standoffs,commands = [],[],[],[]
    exhausted = False
    for k,t in enumerate(times):
        s,distance = route.project([x,y])
        projections.append(s); errors.append(distance)
        standoffs.append(wait_standoff(x,y,yaw,vehicle_size(ego,'length',4.5),
                                      vehicle_size(ego,'width',2.),-138.,1.))
        exhausted |= float(np.dot(np.array([x,y])-route.points[-1],route.vectors[-1]/route.lengths[-1])) > .5
        states[0,k],states[1,k],states[5,k],states[6,k] = x,y,speed,yaw
        if k == len(times)-1:
            break
        step = float(times[k+1]-t)
        braking = stop_after is not None and t >= stop_after-1.e-9
        step_target = 0. if braking else target
        if k == 0:
            wanted_a,wanted_delta = float(first_a),float(first_delta)
        elif plan is not None and t < prefix-1e-9:
            j = min(int(np.searchsorted(plan_times[1:],t+1e-9,side='right')),plan.shape[1]-1)
            wanted_a,wanted_delta = map(float,plan[:,j])
        else:
            wanted_a = max(-2.,min(1.2,1.5*(max(0.,step_target)-speed)))
            look = route.at(s+3.5+.4*speed)
            if s+3.5+.4*speed > route.arc[-1]:
                look = route.points[-1]+route.vectors[-1]/route.lengths[-1]*3.5
            dx,dy = look[0]-x,look[1]-y
            alpha = math.atan2(math.sin(math.atan2(dy,dx)-yaw),math.cos(math.atan2(dy,dx)-yaw))
            wanted_delta = math.atan2(2.*wheelbase*math.sin(alpha),max(math.hypot(dx,dy),.5))
        command = command_acceleration(wanted_a,speed,max(0.,float(step_target)))
        if braking and 'low_speed_brake_taper' in geometry:
            command = max(command, -geometry['low_speed_brake_taper']*speed)
        commands.append(command)
        delta += max(-.9*step,min(.9*step,max(-maximum,min(maximum,wanted_delta))-delta))
        change = (1. if lag == 0. else min(1.,step/lag))*(command-actual_a)
        if braking:
            change = max(change, -float(geometry.get('brake_response_jerk', .5))*step)
        actual_a += change
        next_speed = max(0.,speed+step*actual_a)
        mid_speed = .5*(speed+next_speed)
        beta = math.atan(.5*math.tan(delta))
        x += step*mid_speed*math.cos(yaw+beta)
        y += step*mid_speed*math.sin(yaw+beta)
        yaw += step*mid_speed*math.sin(beta)/(wheelbase/2.)
        speed = next_speed
    signed = float(projections[-1]-projections[0])
    stop_check = bool(stop_after is not None or target <= .01 and standoffs[0] > 0.)
    stop_feasible = (not stop_check or min(standoffs)>=.15)
    if stop_after is not None:
        stop_feasible = stop_feasible and speed<=.05
    diag.update(revision='route_v18',valid=bool(not exhausted and max(errors)<=2.),
        coverage_exhausted=bool(exhausted),max_cross_track=float(max(errors)),
        path_length=float(route.arc[-1]),start_s=projections[0],end_s=projections[-1],
        progress_m=max(0.,signed),signed_progress_m=signed,max_speed=float(np.max(states[5])),
        end_speed=float(states[5,-1]),horizon=float(times[-1]),lag=float(lag),
        response='first_order_0_or_0.4s_uncalibrated',command_max=float(max(commands)),
        command_min=float(min(commands)),integration_dt=.05,plan_prefix_s=prefix,
        future_control='path_feedback_after_dense_mpc_prefix',
        stop_check_required=stop_check,min_standoff=float(min(standoffs)),
        stop_before_band=bool(stop_feasible))
    return states,times,diag
