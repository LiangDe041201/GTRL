#!/usr/bin/env python3
"""
主动推理 (Active Inference) / 期望自由能 (EFE) 纯函数组件（无 CARLA 依赖，离线可对拍）。

对标论文 ADVEI-D-26-08155 §V 与 §IV：
  - 式18   信息熵 H = -Σ p_i·log2(p_i)        （对手让行意图的不确定性）
  - 式52   VFE(s) = D_KL[q(s)‖p(s)] − E_s[ln p(o|s)]
  - 式54/55 EFE 第一项 risk(期望偏好偏离) / 第二项 ambiguity(观测不确定)
            式55 的观测熵 H 用**自然对数 ln**（区别于式18 的 log2）
  - 式56   奖励 R(s,a) = -EFE(s,a)             （把负期望自由能当作即时奖励）
  - 式57   EFE(s,a) = r_cognition + r_behavior
             r_cognition = D_KL[q(o_g'|a) ‖ p̃(o_g')]
             r_behavior  = E_{s'}[H(p(o'|s'))]
           ★ 自变量是 (s,a)：必须逐候选动作评估，见 `efe_by_action`
  - 式58/59 蒙特卡洛 Q̂(s,a) = mean( Σ γ^k · (-EFE) )（单步即时回报 = -EFE）
  - 式42/43 Hoeffding 置信临界偏差 ε = (R_max - R_min)·√(ln(1/α)/(2n))
  - 式44/45 WCV = Q̂ - ε；BCV = Q̂ + ε
  - 式60    方差修正后的保守 WCV 下界（对手意图模糊时回报方差 σ² 增大 → 压低 WCV）
            论文明确：ambiguity 在实现上"直接体现为蒙特卡洛回报的离散波动 σ²"，
            故 r_behavior 通过式60 的方差修正进入价值估计
  - 式46    接管规则：∃a: WCV(a) > BCV(默认) 时取 argmax WCV(a)，否则跟随默认策略

本模块只做「确定性数学」，实际的状态/对手意图/回报方差由调用方（dds_dcarl_turn /
trustset_dds）注入，保证离线可用 pytest / offline_check 严格对拍。
"""
import math

import numpy as np


# ============================================================
# 式18：信息熵（对手让行意图的不确定性）
# ============================================================
def rv_intent_entropy(p_yield: float, eps: float = 1e-9) -> float:
    """对手使行/抢行意图分布的 Shannon 熵（论文式18）。

    【论文式18】H = −Σ_{L∈A} p_L·log2(p_L)   —— 注意底数是 2（不是自然对数）。
    p_yield ∈ [0,1]：p=0.5 时熵最大(=1 bit)，p=0 或 1 时熵为 0（意图完全确定）。
    采用信息熵约定 x·log2(x) → 0 (x→0)，即概率为 0 的项贡献为 0。
    """
    p = min(1.0, max(0.0, float(p_yield)))
    q = 1.0 - p
    h = 0.0
    for x in (p, q):
        if x > 0.0:
            h -= x * (math.log(x) / math.log(2.0))   # log2
    return h


# ============================================================
# 【旧口径·仅供对照】式57 的状态级标量近似：EFE = (偏离)² + 意图熵 + σ²
# ------------------------------------------------------------
# 注意：这不是论文的 EFE(s,a)。论文式56/57 的自变量是 (s_t, a_t)，必须在**候选动作**
# 之间可比较；而这里的三个输入（game_objective_deviation / intent_entropy /
# sample_variance）在**同一状态内对所有动作取值相同**，因此没有动作区分能力，
# 且 (偏离)² 与式62-68 的 r_game 重复计数。保留它只为：① 回归测试；② 消融对照。
# 真正按论文原式的 EFE(s,a) 见下方 `efe_by_action`。
# ============================================================
def risk_term(game_objective_deviation: float, w_risk: float = 1.0) -> float:
    """EFE 的 risk 项（式57第一项）——「与博弈目标的偏离成本」。

    game_objective_deviation 为标量偏离量（如安全裕度相对目标裕度的缺额，
    或当前间隙相对目标间隙的偏差）。卡在博弈目标之外（安全/效率不达标）→ 偏离大。
    """
    return w_risk * float(game_objective_deviation) ** 2


def ambiguity_term(intent_entropy: float, sample_variance: float,
                   w_amb: float = 1.0) -> float:
    """EFE 的 ambiguity 项（式57第二项）——「推断对手隐藏意图的不确定性」。

    由两部分构成：
      intent_entropy   对手使行意图分布的信息熵（式18）——认知不确定
      sample_variance  蒙特卡洛回报样本方差 σ² ——统计不确定（对手意图模糊时增大）
    """
    return w_amb * (float(intent_entropy) + float(sample_variance))


def expected_free_energy(game_objective_deviation: float, intent_entropy: float,
                         sample_variance: float, w_risk: float = 1.0,
                         w_amb: float = 1.0) -> float:
    """式57：EFE(s,a) = risk + ambiguity（恒 ≥ 0）。"""
    return (risk_term(game_objective_deviation, w_risk)
            + ambiguity_term(intent_entropy, sample_variance, w_amb))


def efe_reward(game_objective_deviation: float, intent_entropy: float,
               sample_variance: float, w_risk: float = 1.0,
               w_amb: float = 1.0) -> float:
    """式56：reward = -EFE（恒 ≤ 0）。最大化奖励 = 最小化风险+模糊。"""
    return -expected_free_energy(game_objective_deviation, intent_entropy,
                                 sample_variance, w_risk, w_amb)


# ============================================================
# 式52/54/55/56/57：按【动作】评估的 EFE(s_t, a_t) —— 论文原式
# ------------------------------------------------------------
# 论文原文（ADVEI-D-26-08155 §V-B/C）：
#   式52  VFE(s) = D_KL[q(s)‖p(s)] − E_s[ln p(o|s)]
#   式54  EFE 第一项 = 期望偏好(与目标偏离) → 称 "risk"
#         第二项 = 采取动作后"隐状态→观测"转移的不确定性 → 称 "ambiguity"
#   式55  H(p(o_{t+1}|s_{t+1})) = −Σ_o P(o_{t+1}|s_{t+1})·ln P(o_{t+1}|s_{t+1})   ← 自然对数
#   式56  R_t(s_t,a_t) = −EFE(s_t,a_t)
#   式57  EFE(s_t,a_t) = r_cognition + r_behavior
#         r_cognition = D_KL[q(o_g,t+1 | a_t) ‖ p̃(o_g,t+1)]      （risk：与博弈目标偏离）
#         r_behavior  = E_{s'}[H(p(o_g,t+1 | s_{t+1}))]           （ambiguity：观测不确定）
#
# 【本场景的观测模型（论文未给左转场景的具体形式，此处为我们的显式设计选择）】
#   博弈观测 o_g 取"自车以该动作到达冲突点的结果"，离散为 4 类（含**效率**维度）：
#     clear  : 到达且 margin ≥ clearance + 0.5s  —— 博弈目标达成（安全且高效）★最偏好
#     tight  : 到达且 clearance ≤ margin < +0.5s  —— 临界（部分达成）
#     stalled: 在预测时域内**到不了**冲突点（如刹停/蠕行）—— 安全但损失效率
#     blocked: 到达且 margin < clearance          —— 目标未达成（会与对手冲突）★最差
#   为什么要 stalled 这一类：论文 §VI-A 明确"目标定义为交通效率（FV-RV 间隙长度）"。
#   若观测只含安全性，则"停在停止线不动"与"安全通过"同属 clear → EFE 会系统性偏好刹车。
#   把效率损失单列一类、并在偏好分布 p̃ 中置于 blocked 之上，才与论文"效率+安全"的目标一致。
#   q(o'|a,τ) 由"动作 a + 对手类型 τ 下的预测裕度/到达时间"经**正态 CDF + sigmoid 软化**
#   得到（σ=预测噪声），故为合法分布而非独热；p̃(o') 为期望偏好分布（式54 第一项）。
# ============================================================

#: 博弈观测的 4 类标签（顺序与 p̃ / q 的分量一一对应）
OBS_CLASSES = ('clear', 'tight', 'stalled', 'blocked')

#: p̃(o_g) 的默认偏好权重：clear ≫ tight > stalled > blocked
#: （效率-安全权衡：宁可短暂等待/让行，也不进入冲突；"临界"优于"停车"优于"冲突"）
PREF_WEIGHTS = (0.94, 0.02, 0.03, 0.01)


def observation_entropy(probs) -> float:
    """【式55】观测熵 H(p(o|s)) = −Σ p·ln p（**自然对数**，与式18 的 log2 口径不同）。

    约定 0·ln0 → 0；输入会自动归一化，非正值被忽略。
    """
    p = np.asarray(probs, dtype=float)
    p = np.clip(p, 0.0, None)
    s = float(p.sum())
    if s <= 0.0:
        return 0.0
    p = p / s
    h = 0.0
    for x in p:
        if x > 0.0:
            h -= float(x) * math.log(float(x))
    return h


def kl_divergence(q, p, floor: float = 1e-9) -> float:
    """【式52/57 第一项】D_KL[q ‖ p̃] = Σ q·(ln q − ln p̃)（nats，恒 ≥ 0）。

    q 会被归一化；p 的分量下限为 floor（避免 ln0，也对应"偏好分布留 floor"）。
    """
    qa = np.clip(np.asarray(q, dtype=float), 0.0, None)
    sq = float(qa.sum())
    if sq <= 0.0:
        return 0.0
    qa = qa / sq
    pa = np.clip(np.asarray(p, dtype=float), float(floor), None)
    sp = float(pa.sum())
    if sp <= 0.0:
        return 0.0
    pa = pa / sp
    d = 0.0
    for qi, pi in zip(qa, pa):
        if qi > 0.0:
            d += float(qi) * (math.log(float(qi)) - math.log(float(pi)))
    return float(d)


def preferred_observation(pref_weights=None):
    """p̃(o_g)：期望观测分布（式54 第一项"期望偏好"，定义为 agent 的目标）。

    默认 PREF_WEIGHTS = (clear .94, tight .02, stalled .03, blocked .01)：
    偏好"安全且高效通过" ≫ "临界通过" > "停滞等待" > "冲突"。分量均为正，
    既保证 KL 有限，也用相对大小表达博弈目标下的偏好次序。
    """
    w = np.asarray(PREF_WEIGHTS if pref_weights is None else pref_weights, dtype=float)
    w = np.clip(w, 1e-9, None)
    return w / float(w.sum())


def predicted_observation(margin: float, clearance: float = 0.0,
                          sigma: float = 0.35, t_ego: float = None,
                          horizon: float = None):
    """q(o'|a,·)：把"预测裕度 + 预测到达时间"软分配到 4 类观测。

        P(blocked) = (1−p_stall)·Φ((clearance − margin)/σ)
        P(tight)   = (1−p_stall)·[Φ((clearance+0.5 − margin)/σ) − P(blocked)/(1−p_stall)]
        P(clear)   = (1−p_stall)·[1 − Φ((clearance+0.5 − margin)/σ)]
        P(stalled) = p_stall = sigmoid((t_ego − horizon)/σ)      （t_ego=inf → 1）

    margin  = |t_RV − t_ego|（谁先到不关键，差得开就安全），单位 s
    t_ego   = 该动作下自车到达冲突点的预测时间；None/未给 horizon 时不做停滞判定
    σ       = 预测噪声（s）：σ→0 退化为独热，σ 越大分布越平
    """
    s = max(float(sigma), 1e-6)
    c = float(clearance)
    m = abs(float(margin))
    if t_ego is not None and horizon is not None:
        te = float(t_ego)
        p_stall = 1.0 if not math.isfinite(te) else _sigmoid((te - float(horizon)) / s)
    else:
        p_stall = 0.0
    p_stall = min(1.0, max(0.0, p_stall))
    hi = _norm_cdf((c + 0.5 - m) / s)
    lo = _norm_cdf((c - m) / s)
    p_blocked = (1.0 - p_stall) * lo
    p_tight = (1.0 - p_stall) * max(0.0, hi - lo)
    p_clear = (1.0 - p_stall) * max(0.0, 1.0 - hi)
    v = np.array([p_clear, p_tight, p_stall, p_blocked], dtype=float)
    tot = float(v.sum())
    if tot <= 0.0:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=float)
    return v / tot


def _sigmoid(x: float) -> float:
    """数值稳定的 logistic 函数。"""
    x = float(x)
    if x >= 0.0:
        return 1.0 / (1.0 + math.exp(-min(x, 60.0)))
    e = math.exp(max(x, -60.0))
    return e / (1.0 + e)


def _norm_cdf(x: float) -> float:
    """标准正态 CDF（用 math.erf，避免引入 scipy 依赖）。"""
    return 0.5 * (1.0 + math.erf(float(x) / math.sqrt(2.0)))


def _belief_pairs(cond_dists, belief):
    """把 (cond_dists, belief) 归一为 [(b(τ), q(·|τ)), ...]。

    cond_dists 为 dict → 按 belief 的同名键取概率；belief 为序列时按 dict 插入顺序对齐。
    cond_dists 为序列 → belief 为 dict 时按键序对齐，否则按位置对齐。
    """
    if isinstance(cond_dists, dict):
        if isinstance(belief, dict):
            return [(float(belief.get(k, 0.0)), np.asarray(v, dtype=float))
                    for k, v in cond_dists.items()]
        bs = list(belief)
        return [(float(b), np.asarray(v, dtype=float))
                for b, (_, v) in zip(bs, cond_dists.items())]
    seq = [np.asarray(v, dtype=float) for v in cond_dists]
    bs = list(belief.values()) if isinstance(belief, dict) else list(belief)
    return [(float(b), d) for b, d in zip(bs, seq)]


def behavior_ambiguity(cond_dists, belief) -> float:
    """【式57 第二项 + 式55】r_behavior = E_{s'~b}[H(p(o'|s'))] = Σ_τ b(τ)·H(q_τ)。

    cond_dists: {τ: q(o'|a,τ)}（或与 belief 同序的序列）
    belief    : 类型后验 b(τ)
    ——注意这是"给定隐状态后的**条件**观测熵"，不是边缘熵：对手行为越确定
      （无论让行还是抢行），条件熵越小；越是"连给定意图都预测不准"，越大。
    """
    items = _belief_pairs(cond_dists, belief)
    tot = sum(b for b, _ in items)
    if tot <= 0.0:
        return 0.0
    return float(sum((b / tot) * observation_entropy(d) for b, d in items))


def cognitive_risk(cond_dists, belief, p_tilde=None) -> float:
    """【式57 第一项 + 式52】r_cognition = D_KL[q(o_g'|a) ‖ p̃(o_g')]。

    q(o_g'|a) 为对类型后验取期望后的**边缘**预测观测分布：q = Σ_τ b(τ)·q(o'|a,τ)。
    """
    if p_tilde is None:
        p_tilde = preferred_observation()
    items = _belief_pairs(cond_dists, belief)
    tot = sum(b for b, _ in items)
    if tot <= 0.0 or not items:
        return 0.0
    q = np.zeros_like(items[0][1])
    for b, d in items:
        q = q + (b / tot) * d
    return kl_divergence(q, p_tilde)


def action_efe(cond_dists, belief, p_tilde=None,
               w_cognition: float = 1.0, w_behavior: float = 1.0) -> float:
    """【式57】EFE(s_t, a_t) = r_cognition + r_behavior（恒 ≥ 0，代价）。"""
    return (float(w_cognition) * cognitive_risk(cond_dists, belief, p_tilde)
            + float(w_behavior) * behavior_ambiguity(cond_dists, belief))


def action_efe_reward(cond_dists, belief, p_tilde=None,
                      w_cognition: float = 1.0, w_behavior: float = 1.0) -> float:
    """【式56】R(s_t, a_t) = −EFE(s_t, a_t)（恒 ≤ 0）。"""
    return -action_efe(cond_dists, belief, p_tilde, w_cognition, w_behavior)


def ambiguity_reward(ambiguity_by_action, action, w: float = 1.0):
    """【式56/57 + 式60】把逐动作 **ambiguity** 折进单步回报。

    返回 `(term, ambiguity_used)`；任何异常/缺失 ⇒ `(0.0, None)`（绝不抛异常）。

    为什么要单独抽出来：
      式60 的方差修正 `WCV = Q̂ − Hoeffding − 4σ/(n+1)` 的成立前提是
      **"对手意图越模糊 ⇒ 轨迹回报的方差 σ² 越大"**。而 σ 是对**回报样本**取的，
      所以 ambiguity 必须真的进入**单步回报**，σ 才会随模糊增大
      ⇒ 方差修正项才会压低 WCV ⇒ 才会触发"模糊时更保守"。
      若 ambiguity 只出现在别处（如仅加进动作置信度 score），σ 与模糊无关，
      **② 对 ③ 就没有任何影响**（这正是修复前的状态）。

    ⚠️ 只加 ambiguity、**不加整个 −EFE**：调用方的行为奖励（式62-68）已承载
      EFE 的 **risk** 面向；再叠加 `−r_cognition` 会把 risk 重复计数
      （两者定义不同：一个是已实现后果奖励，一个是预测观测分布的 KL）。
      论文 §V 的表述是 "**combines** the reward function specifications with
      mechanistic theory" ⇒ 组合"行为奖励 + 认知模糊代价"。

    ⚠️ 符号：`term = −w·ambiguity ≤ 0` ⇒ **越模糊回报越低**（与式56 一致）。
      ambiguity 是熵（式55，自然对数）故 ≥ 0；若上游给出负值（异常），
      本函数把它**截到 0**（不制造"越模糊越赚"的反向激励）。
    """
    try:
        if ambiguity_by_action is None:
            return 0.0, None
        key = int(action)
        raw = ambiguity_by_action.get(key)
        if raw is None:
            return 0.0, None
        amb = float(raw)
        if not math.isfinite(amb):
            return 0.0, None
        if amb < 0.0:
            amb = 0.0                      # 熵不可能为负 ⇒ 防反向激励
        return -float(w) * amb, amb
    except (TypeError, ValueError, AttributeError):
        return 0.0, None


def lateral_arc_correction(arc: float, lateral_offset: float, dpsi: float,
                           min_arc: float = 0.5) -> float:
    """【D2b】横向 offset 对"到冲突点弧长"的**一阶修正**。

        arc_eff = max(arc − lateral_offset · Δψ, min_arc)

    严格依据（**不是拟合**）：
      路径弧长与横向 offset 的关系由 Frenet 基本关系给出 `κ = dψ/ds`。
      把路径横向平移 `d`，对弧长的一阶影响为
          Δarc = −d · ∫κ(s) ds = **−d · Δψ**
      其中 `Δψ` 是"自车 → 冲突点"沿参考路径的**航向变化量**（∫κ ds ≡ Δψ）。
      ⇒ 只需两端航向差，**无需逐点曲率**。

    符号约定：
      `lateral_offset` 是 Frenet 横向 offset，**正 = 左**
        （依据 `LaneTrajectoryPlanner.calc_global_paths`：
         `fx = ix + di·cos(iyaw + π/2)` ⇒ +d 指向航向左转 90° 方向）。
      左转时曲率中心在**左侧** ⇒ 正 d 使半径变小 ⇒ **弧长变短** ⇒ `arc − d·Δψ`（Δψ>0）。

    ⚠️ 为什么必须用 Δψ 而不是"局部 κ × arc"：
      参考路径前约 40% 是直线（实测 κ=0），转弯发生在中段
      ⇒ 自车在接近段时局部 κ≈0，但到冲突点仍可能有很大 Δψ
      ⇒ 局部近似会**严重低估**横向灵敏度。

    健壮性：非法/非有限输入 ⇒ 原样返回 `arc`（退化为修复前行为），绝不抛异常。
    """
    try:
        a = float(arc)
        d = float(lateral_offset)
        p = float(dpsi)
        if not (math.isfinite(a) and math.isfinite(d) and math.isfinite(p)):
            return float(arc)
        return float(max(a - d * p, float(min_arc)))
    except (TypeError, ValueError):
        return float(arc) if isinstance(arc, (int, float)) else 0.0


def efe_by_action(margins_by_action, yield_prob_by_action, belief,
                  clearance_by_action=None, t_ego_by_action=None,
                  horizon: float = None, sigma: float = 0.35,
                  pref_weights=None,
                  w_cognition: float = 1.0, w_behavior: float = 1.0,
                  info_cardinality=None, w_info: float = 0.0,
                  action_entropy=None, w_action_entropy: float = 0.0):
    """【式56/57 逐动作】对每个候选动作 a 计算 EFE(s,a) 与 R(s,a) = −EFE(s,a)。

    观测模型（见本段上方说明）：
      对每个对手**隐类型** τ（论文 §III-A 的私有类型，此处为 aggressiveness 档位），
      用让行概率模型给出该类型下 RV 的行为分布 p_τ = P(yield|τ)，于是

          【式(16) 钩子】`info_cardinality = |I_{i,t}|`（与 ego 观测相容的历史条数）。
      论文 §III-A 式(16) 定义不完全信息博弈的条件是 `|I_{i,t}| > 1`；
      §V 又说 ambiguity 项度量"当前博弈观测区分对手隐藏意图的可靠性"。
      ⇒ 把 `w_info·log2|I_{i,t}|` 加进 `r_behavior`：`|I|` 越大 ⇒ 对手意图越不可辨
      ⇒ 模糊代价越高。（式18 的信息熵用 log2，此处同底数。）
      ⚠️ 口径说明：本量的作用是**帧级**的（同一帧内对所有动作相同），
      因此它**不改变 argmin**，只改变 EFE 的绝对水平与置信度尺度；
      **逐动作**的信息集基数（不同动作导致不同观测 ⇒ 不同 |I|）是后续细化项。

    q(o' | a, τ) = p_τ · q(o' | a, yield) + (1 − p_τ) · q(o' | a, rush)

      即"给定对手隐状态 τ 时，自车会观测到什么"的分布（行为混合）；
      再对类型后验 b(τ) 取期望得到边缘 q(o'|a)（用于 risk）。

    参数:
      margins_by_action[a][behavior] : 动作 a 下、RV 行为为 yield/rush 时自车到达冲突点
                                       的时间裕度(s)（到达时间差的绝对值）
      yield_prob_by_action[a][τ]     : 该动作下类型 τ 的让行概率 P(yield|τ)
      belief[τ]                      : 类型后验 b(τ)
      clearance_by_action[a]         : 动作 a 所需清空时间(s)；None → 0.0
      t_ego_by_action[a]             : 动作 a 下自车到达冲突点的预测时间(s)（判 stalled）
      horizon                        : 预测时域(s)：t_ego 超过它即判为 stalled
      sigma                          : 预测噪声(s)，进入 q(o'|·) 的软化
      pref_weights                   : p̃ 的偏好权重，默认 PREF_WEIGHTS
    返回:
      {a: {'r_cognition','r_behavior','efe','reward',   # reward = −EFE（式56）
           'cond_dists': {τ: array}, 'q_marginal': array, 'p_tilde': array}}
    """
    p_tilde = preferred_observation(pref_weights)
    out = {}
    for a, by_behavior in margins_by_action.items():
        clr = 0.0 if clearance_by_action is None else float(
            clearance_by_action.get(a, 0.0))
        t_ego = None if t_ego_by_action is None else t_ego_by_action.get(a)
        q_beh = {bh: predicted_observation(m, clr, sigma, t_ego, horizon)
                 for bh, m in by_behavior.items()}
        yp = (yield_prob_by_action or {}).get(a, {})
        cond_dists = {}
        for tau in belief:
            p_y = min(1.0, max(0.0, float(yp.get(tau, 0.5))))
            cond_dists[tau] = p_y * q_beh.get('yield', q_beh.get('rush')) + \
                (1.0 - p_y) * q_beh.get('rush', q_beh.get('yield'))
        r_cog = cognitive_risk(cond_dists, belief, p_tilde)
        r_beh = behavior_ambiguity(cond_dists, belief)
        # 【式(16)→式(57)】**逐动作**信息集基数进入模糊项：
        #   `|I(a)|` 越大 ⇒ 该动作带来的观测越分不清对手类型 ⇒ 模糊代价越高。
        #   式(18) 的信息熵用 log2，此处同底数。
        #   ⚠️ 优先用**逐动作**口径（由本动作的 `cond_dists` 算出，会改变 argmin）；
        #      外部传入的 `info_cardinality` 仅作退化兜底（它是帧级量，对动作不可比）。
        _info_term = 0.0
        _card_a = None
        try:
            if float(w_info) > 0.0:
                _card_a = info_cardinality_by_action(cond_dists, belief)
                _info_term = float(w_info) * math.log(max(1.0, _card_a), 2.0)
        except (TypeError, ValueError):
            _info_term = 0.0
        # 【式(18)】对手**动作频率**熵（由历史路径算出，口径见 information_set.rv_action_entropy）
        #   作为模糊项的第二分量；它让式(12) 的历史路径有了真实消费者（PLAN §41 的 L7）。
        _act_term = 0.0
        try:
            if action_entropy is not None and float(w_action_entropy) > 0.0:
                _act_term = float(w_action_entropy) * max(0.0, float(action_entropy))
        except (TypeError, ValueError):
            _act_term = 0.0
        r_beh = float(r_beh) + _info_term + _act_term
        efe = float(w_cognition) * r_cog + float(w_behavior) * r_beh
        q_marg = np.zeros_like(p_tilde)
        tot = sum(float(belief.get(k, 0.0)) for k in cond_dists) or 1.0
        for k, d in cond_dists.items():
            q_marg = q_marg + (float(belief.get(k, 0.0)) / tot) * d
        out[a] = {'r_cognition': float(r_cog), 'r_behavior': float(r_beh),
                  'r_info': float(_info_term),
                  'info_card_action': (None if _card_a is None else float(_card_a)),
                  'r_action_entropy': float(_act_term),
                  'efe': float(efe), 'reward': float(-efe),
                  'cond_dists': cond_dists, 'q_marginal': q_marg,
                  'p_tilde': p_tilde}
    return out


# ============================================================
# 式58/59：蒙特卡洛 Q̂(s,a)
# ============================================================
def info_cardinality_by_action(cond_dists, belief, eps=0.02):
    """【式(16) **逐动作**】`|I_{i,t}(a)|`：采取动作 a 并观测后，仍相容的对手类型数（期望）。

    为什么必须逐动作：帧级的 `|I|` 在同一帧内对所有动作相同 ⇒ **不改变 argmin**
    ⇒ 它对决策零影响（PLAN §41 的 L4）。论文式(16) 的信息集是**决策点之后**的信息集，
    因此必须按动作分别评估。

    口径（式(11)(16) + 式(28) 的观测模型）：
      取动作 a，观测 o 后仍相容的对手类型集合 = `{τ : b(τ)·q(o|a,τ) > eps}`
      对其取期望（按边缘观测分布 `q(o|a)=Σ_τ b(τ)q(o|a,τ)`）：
          `|I(a)| = Σ_o q(o|a) · max(1, #{τ : b(τ)·q(o|a,τ) > eps})`
    `|I(a)|` 越大 ⇒ 该动作带来的观测越分不清对手类型 ⇒ 认知不确定性越高。
    """
    try:
        taus = list(cond_dists.keys())
        if not taus:
            return 1.0
        mat = np.array([np.asarray(cond_dists[k], dtype=float).ravel() for k in taus])
        if mat.ndim != 2 or mat.shape[1] == 0:
            return 1.0
        b = np.array([max(0.0, float(belief.get(k, 0.0))) for k in taus], dtype=float)
        tot = float(b.sum())
        b = b / tot if tot > 0 else np.full(len(taus), 1.0 / len(taus))
        q_marg = b @ mat                                   # (O,)
        card = 0.0
        for oi in range(mat.shape[1]):
            n = int(np.sum((b * mat[:, oi]) > float(eps)))
            card += float(q_marg[oi]) * max(1, n)
        return float(max(1.0, card))
    except Exception:
        return 1.0


def reward_to_go_window(rewards, gamma=0.98, horizon=20):
    """【式(38)】有限时域动作值 `Q̃_t = E[Σ_{t=h}^{h+H-1} γ^{t−h} R(s_t,a_t)]`。

    与 `reward_to_go`（式58，到**回合结束**的全轨迹回报）的区别：
      · 式(58) `G_t = Σ_{k≥t} γ^{k−t} r_k`      —— 无限/回合长度时域，用于 §V 的 MC 轨迹回报
      · 式(38) `Q̃_t = Σ_{k=t}^{t+H−1} γ^{k−t} r_k` —— **固定 H 步**窗口，用于 §IV 的价值估计
    改造前 `window_causal` 在环境里被算出来**只 print、不写库、无消费者**
    （PLAN §34.2 第 4 条），式(38) 属"打印级空壳"。本函数让它有真正的消费者。
    """
    rs = [float(x) for x in (rewards or [])]
    H = max(1, int(horizon))
    out = []
    for t in range(len(rs)):
        acc = 0.0
        for k in range(t, min(t + H, len(rs))):
            acc += (float(gamma) ** (k - t)) * rs[k]
        out.append(acc)
    return out


def monte_carlo_q(returns, discount: float = 0.98) -> float:
    """式58/59：Q̂(s,a) = mean( Σ γ^k · (-EFE) ) 的点估计（用轨迹回报均值近似）。

    returns: 该 (s,a) 下的折扣累计回报样本序列（每个元素已是 Σ γ^k·(-EFE)）。
    """
    returns = np.asarray(returns, dtype=float)
    if returns.size == 0:
        return 0.0
    return float(np.mean(returns))


def reward_to_go(rewards, gamma: float = 0.98):
    """【论文式58/59】单条轨迹的折扣回报（reward-to-go）：

        G_t = Σ_{k>=t} γ^{k-t} · r_k        （原文："the total discounted return of
                                              the entire trajectory after performing action"）

    输入：按时间顺序排列的每帧即时奖励 r_0..r_T（已是 −EFE / 因果奖励）。
    输出：同长度的 G_0..G_T。终局奖励（碰撞 −300 / 完成 +150）位于末帧，
    经 γ^{k−t} 回传到轨迹上的**每一个**时刻——这是论文 Q̂ 的信用分配方式
    （对比：滑动窗口只回传固定帧数，终局惩罚无法到达更早的致因动作）。
    """
    r = np.asarray(rewards, dtype=float)
    if r.size == 0:
        return []
    G = np.zeros_like(r)
    acc = 0.0
    for t in range(len(r) - 1, -1, -1):
        acc = float(r[t]) + float(gamma) * acc
        G[t] = acc
    return G.tolist()


# ============================================================
# 式43/44/45 + 式60：方差修正的 WCV/BCV
# ============================================================
def variance_corrected_wcv(samples, alpha: float = 0.05, reward_range: float = None,
                           var_weight: float = 1.0):
    """Hoeffding 置信下界 WCV / 上界 BCV，带论文式60 方差修正。

    【式43/44】δ_{P_f} = (R_max - R_min)·√(ln(1/P_f)/(2n))；WCV = Q̂ - δ；BCV = Q̂ + δ
    【式60】WCV_n(b,a) = Q̂_n(b,a) − 4σ/(n+1) − δ_{P_f}
            —— 方差修正项 = 4σ/(n+1)（标准差 σ，系数 4/(n+1)，随 n 衰减）。
            var_weight 默认 1.0 即为论文原式；调大更保守、调小更激进。

    返回 (wcv, bcv, mean, var)：
      wcv  方差修正后的保守下界（式60）
      bcv  上界（式46）
      mean 样本均值 Q̂
      var  样本方差 σ²
    """
    samples = np.asarray(samples, dtype=float)
    n = len(samples)
    if n == 0:
        return 0.0, 0.0, 0.0, 0.0
    mean = float(np.mean(samples))
    var = float(np.var(samples))
    std = math.sqrt(max(var, 0.0))
    rng = float(reward_range) if reward_range is not None else (
        float(np.max(samples) - np.min(samples)) if n > 1 else 0.0)
    eps = (rng) * math.sqrt(math.log(1.0 / alpha) / (2.0 * n))
    # 【论文式60】WCV_n(b,a) = Q̂_n(b,a) − 4σ/(n+1) − δ_{P_f}
    #   方差修正项是「4σ/(n+1)」——用标准差 σ（不是 σ²），系数 4/(n+1)，随 n 增大而衰减。
    #   （曾因误用 σ² 导致 WCV 被淹没、只剩哨兵值能触发接管而性能崩溃。）
    var_corr = var_weight * (4.0 * std / (n + 1.0))
    wcv = mean - eps - var_corr
    bcv = mean + eps
    return wcv, bcv, mean, var


def wcv_bcv(samples, alpha: float = 0.05, reward_range: float = None,
            var_weight: float = 1.0):
    """别名：与论文式44/45/60 的 WCV/BCV 接口（trustset / 决策层共用）。"""
    return variance_corrected_wcv(samples, alpha, reward_range, var_weight)


# ============================================================
# 式46：接管规则
# ============================================================
def takeover_rule(wcv_by_action, bcv_default: float, default_act: int):
    """式46 接管规则：BCV(默认动作) < 某非默认动作的 WCV → 改选 argmax WCV，否则跟随默认。

    wcv_by_action: 可迭代 (action -> WCV 值) 的映射（不含默认动作或含均可，默认动作会被排除）
    default_act:   默认/基线策略当前选中的动作
    返回 (action, took_over)：
      action    最终选定的动作
      took_over 是否发生接管（True=RL 接管了默认策略；False=继续用默认）
    """
    best_act, best_wcv, best_found = default_act, None, False
    for a, w in wcv_by_action.items():
        if a == default_act:
            continue
        if float(w) > float(bcv_default):
            if not best_found or float(w) > float(best_wcv):
                best_act, best_wcv, best_found = a, w, True
    if best_found:
        return best_act, True
    return default_act, False
