"""
转弯场景的 R-tree 状态空间定义
将环境状态编码为三维特征，用于强化学习的查询与搜索

设计思路:
  维度1 - curvature (前方弯道曲率): 从 waypoint 获取，反映转弯难度
          取值范围: 0 ~ 0.2 (1/m)，曲率越大转弯越急
  维度2 - lateral_error (横向偏差): 自车到当前车道中心线的距离
          正值 = 偏左，负值 = 偏右
  维度3 - speed_ratio (速度比值): 当前速度 / 安全过弯速度
          > 1 表示超速，< 1 表示安全
"""

import numpy as np
import math
import os

# 【S7-①】连续弧长投影（模块级 import：原来它在函数体内的 try 里，本函数每次调用都会
#   重新 import；而 arc 现在依赖它，放在函数里会让"投影失败"静默退化成量化 arc）
from Planning_library.gap_analysis import polyline_cumlen, project_point_on_polyline
# 【BUG-1 修复】冲突点必须用**同一个**带宽常量：`wait_standoff`（y 域判据）用的就是
#   `boundary_safety.BAND_HALF_DEFAULT`。若两处各写一个数，`arc_to_cross` 与
#   `wait_standoff` 又会不一致（那正是 BUG-1 的成因模式）。
from Planning_library.boundary_safety import BAND_HALF_DEFAULT
from Planning_library.vehicle_observation import (
    vehicle_id, vehicle_size, longitudinal_acceleration, following_acceleration)

# ============================================================
# 【P2 博弈区间】口径与阈值（环境变量可调，纯模块级常量便于离线对拍）
# ============================================================
#: 角色划分用的**计划车速下限**（m/s）：t_ego_plan = arc / max(v, 该值)。
#:   让行/蠕动时自车速度趋 0，但"我的计划"仍是正常过弯速度，故对手集合不随之改变。
#:   这直接堵住"减速 ⇒ t_ego→∞ ⇒ 所有车变 fv ⇒ rv 为空 ⇒ 博弈消失"的通道。
T_EGO_V_MIN = float(os.environ.get('DSH_T_EGO_V_MIN', '3.0'))
#: 【P2-b】博弈交互窗口（m）：交叉车到冲突点的纵向距离在此之内才计入博弈。
GAME_WINDOW_M = float(os.environ.get('DSH_GAME_WINDOW', '45.0'))


# ============================================================
# 【BUG-1 修复 2026-10-10】冲突点定位（纯函数，可离线单测）
# ============================================================
def _find_conflict_point(path, cross_y, nose_offset=2.25, mode='crossing',
                         band_half=None):
    """在参考路径上定位"自车车头抵达交叉带北边缘"的那一点（冲突点）。

    【旧实现为什么错】`argmin |path[:,1] - cross_y|`：
      参考路径由 `global_routing()` 从 `goal_point=(-21, -138.51)` 生成，
      而该目标点**正落在交叉路中心线 y=-138 上** ⇒ 路径在转弯完成后有约 27 m
      **沿着 y≈-138 一路向西**。于是 argmin 是在约 10 个几乎等距的点里随便挑，
      实测挑中最西端的 **x=-7.109**，而真实冲突点是 **x≈4.187**（60 回合实测中位）
      ⇒ **误差 11.3 m**。
      后果：所有直行车到达时间 `t_veh = |x - conflict_x| / v` 被系统性高估
      （碰撞帧中位高估 **9 倍**：代码认为 2.87 s，实际 0.14 s），
      角色划分 rv/fv 随之错位（29 次碰撞里 28 次 rv_id 与真实碰撞车差 ±1 个车位）。

    【新实现】沿行进方向的**首次穿越**检测（与 `boundary_safety.safe_wait_arc`
    同一模式）：自车自北向南接近，取"车头触到带北边缘"那一点。
      目标 y = cross_y + band_half + nose_offset
    这样 `arc_to_cross` 与 y 域判据 `wait_standoff`
    （= 车头到带北边缘的净距）变成**同一个量的两种坐标表示**，不再相差 ~10 m。

    参数
    ----
    path        : (N,2) 参考路径点（沿自车行进方向排列）
    cross_y     : 交叉带中心线 y
    nose_offset : 车身中心到车头的纵向距离（m）
    mode        : 'crossing'（默认，新口径）| 其它（旧 argmin 口径）
    band_half   : 交叉带半宽（m），None ⇒ 用 `BAND_HALF_DEFAULT`

    返回 (cross_idx, cross_x, s_cross, mode_used)
      cross_idx : 穿越段起点索引（旧口径兜底/量化 arc 用）
      cross_x   : 冲突点 x（连续插值）
      s_cross   : 冲突点的连续弧长（沿 path 从起点累计）
      mode_used : 实际生效的口径（穿越失败会变成 'legacy(fallback)'）
    """
    p = np.asarray(path, dtype=float)
    if p.ndim != 2 or len(p) < 2:
        return 0, 0.0, 0.0, 'legacy(empty)'
    bh = float(BAND_HALF_DEFAULT if band_half is None else band_half)
    if str(mode).strip().lower() != 'legacy':
        y_nose = float(cross_y) + bh + abs(float(nose_offset))
        # 逐段累计弧长（步长 ~2 m，路点数很少，代价可忽略）
        cum = [0.0]
        for i in range(1, len(p)):
            cum.append(cum[-1] + math.hypot(float(p[i][0]) - float(p[i - 1][0]),
                                            float(p[i][1]) - float(p[i - 1][1])))
        for i in range(1, len(p)):
            y0, y1 = float(p[i - 1][1]), float(p[i][1])
            if y0 > y_nose >= y1:            # 由北向南穿越（y 递减）
                t = 0.0 if y0 == y1 else (y0 - y_nose) / (y0 - y1)
                cx = float(p[i - 1][0] + t * (float(p[i][0]) - float(p[i - 1][0])))
                seglen = cum[i] - cum[i - 1]
                return i - 1, cx, float(cum[i - 1] + t * seglen), 'crossing'
    # 兜底：旧口径（路径在目标 y 上不单调 ⇒ 无法判定首次穿越）
    ci = int(np.argmin(np.abs(p[:, 1] - float(cross_y))))
    cum2 = [0.0]
    for i in range(1, len(p)):
        cum2.append(cum2[-1] + math.hypot(float(p[i][0]) - float(p[i - 1][0]),
                                          float(p[i][1]) - float(p[i - 1][1])))
    return ci, float(p[ci][0]), float(cum2[ci]), 'legacy(fallback)'


def get_turn_rtree_obs(dynamic_map, env=None):
    """
    功能: 把转弯场景的环境状态编码到 R-tree 查询的 5 维向量中

    (curvature, lat_error, speed_ratio, cross_gap_norm, dist_to_cross_norm)
      1. curvature   - 前方道路曲率 (1/m)
      2. lat_error   - 自车到车道中心横向偏差 (m)
      3. speed_ratio - 当前速度 / 安全过弯速度
      4. cross_gap   - 与交叉直行车流的冲突点时间差(归一化 [0,1]，越小越危险)
      5. dist_cross  - 自车到冲突点的距离(归一化 [0,1])

    新增的 4、5 维让 R-tree 能区分"前方是否有直行车流逼近"这一关键博弈状态，
    修复原 3 维状态下"空旷 vs 有车逼近"编码几乎一致的问题。
    """
    ego_vehicle = dynamic_map.ego_vehicle

    # 维度1: 弯道曲率
    curvature = _get_curvature(dynamic_map)

    # 维度2: 横向偏差
    lat_error = _get_lateral_error(dynamic_map)

    # 维度3: 速度比值
    current_speed = max(ego_vehicle.v, 0.1)
    safe_speed = _get_safe_turn_speed(curvature)
    speed_ratio = current_speed / max(safe_speed, 0.1)
    speed_ratio = np.clip(speed_ratio, 0.0, 5.0)

    # 维度4/5: 交叉冲突信息（博弈关键）
    cross_gap, dist_to_cross = crossing_gap_info(dynamic_map, env)
    cross_gap_norm = float(np.clip(cross_gap, 0.0, 8.0) / 8.0)   # 时间差8s以上视为安全
    dist_norm = float(np.clip(dist_to_cross, 0.0, 40.0) / 40.0)  # 40m 以外视为无影响

    return (round(curvature, 4), round(lat_error, 4), round(speed_ratio, 4),
            round(cross_gap_norm, 4), round(dist_norm, 4))


def crossing_gap_info(dynamic_map, env=None):
    """
    兼容旧接口: 返回 (min_gap, dist_to_cross)，实际逻辑委托给 crossing_conflict_detail
    """
    d = crossing_conflict_detail(dynamic_map, env)
    return d['gap'], d['dist_to_cross']


def crossing_conflict_detail(dynamic_map, env=None, beta=None):
    """
    计算自车与交叉方向直行车流的冲突细节（左转博弈的核心量）:
      gap          - 冲突点时间差 |t_ego - t_veh| (s)，无车时 30
      dist_to_cross- 自车到冲突点直线距离 (m)
      t_ego        - 自车沿路径到达冲突点的时间 (s)
      t_veh        - 最近交叉车辆到达冲突点的时间 (s)，无车时 inf
      arc_to_cross - 自车沿路径到冲突点的弧长 (m)
      committed    - 自车是否已越过冲突点（沿路径越过 >2m）
      n_vehicles   - 参与评估的交叉车辆数

    冲突点: 参考路径上 y≈东西向道路中心线的点（自车左转轨迹与直行车流相交处）。
    对 90° 交叉场景，径向相对速度法(原 conflict_detection)计算出的 TTC 恒≈0，
    无法识别冲突；本函数改用"到冲突点的时间差"，是交叉口博弈的标准度量。
    """
    path = _get_ref_path_array(dynamic_map)
    ego = dynamic_map.ego_vehicle

    empty = {'gap': 30.0, 'dist_to_cross': 50.0, 't_ego': 30.0, 't_veh': float('inf'),
             'arc_to_cross': 0.0, 'committed': False, 'n_vehicles': 0,
             'gap_spatial': None}
    if path is None or len(path) < 3:
        return empty

    # 东西向道路中心线 y 坐标
    if env is not None:
        inter = getattr(env, 'INTERSECTION_CENTER', None)
        cross_y = float(inter[1]) if inter is not None else -138.0
    else:
        cross_y = -138.0

    # ===== 【BUG-1 修复 2026-10-10】冲突点定义 =====
    # 【旧实现（错）】`cross_idx = argmin |path[:,1] - cross_y|`
    #   为什么错（实测铁证，见 HANDOFF_2026-10-10.md §2 BUG-1）：
    #     参考路径由 `global_routing()` 从 `goal_point = (-21, -138.51)` 生成，
    #     而该目标点**正落在交叉路中心线（y=-138）上** ⇒ 路径转弯完成后有 ~27 m
    #     **沿着 y≈-138 一路向西**。于是 argmin 是在 10 个几乎等距的点里随便挑一个，
    #     挑中了最西端的 x=-7.109。
    #   真实冲突点：自车车头跨过交叉带北边缘的位置 = x≈4.187（60 回合实测中位）。
    #   ⇒ **误差 11.3 m** ⇒ 所有直行车到达时间 `t_veh = |x - conflict_x| / v`
    #     被系统性高估（碰撞帧中位高估 **9 倍**：代码认为 2.87 s，实际 0.14 s）。
    #
    # 【新实现】沿行进方向**首次穿越**检测（与 `boundary_safety.safe_wait_arc` 同一模式）：
    #   自车自北向南接近，取"车头抵达交叉带北边缘"那一点作为冲突点 ——
    #   与 y 域判据 `wait_standoff` **完全对齐**（那里也是"车头到带北边缘"）。
    #   这样 `arc_to_cross` 与 `wait_standoff` 变成同一个量的两种坐标表示，
    #   不再相差 10.2 m。
    #
    # 【为什么用"车头"而不是"带中心线"】正确性与一致性：
    #   占用窗判据（`required_clearance_from_standoff`）本来就是从**车头到带边缘**
    #   开始算的；把冲突点也锚在车头，`t_ego_go` 与 `arc` 才自洽。
    #
    # 【可回退】`DSH_CONFLICT_POINT=legacy` 走旧的 argmin（仅用于复现历史实验）。
    _cp_mode = os.environ.get('DSH_CONFLICT_POINT', 'crossing').strip().lower()
    #: 车头到车身中心的纵向距离（m）。默认 4.5/2；与 `wait_standoff` 的
    #: “车头到带北边缘”口径保持一致。可用 `DSH_NOSE_OFFSET` 覆盖。
    _nose_off = float(os.environ.get('DSH_NOSE_OFFSET', '2.25'))
    cross_idx, cross_x, s_cross_cross, _cp_mode = _find_conflict_point(
        path, cross_y, nose_offset=_nose_off, mode=_cp_mode)

    # 自车在路径上的最近索引
    d = np.sqrt((path[:, 0] - ego.x) ** 2 + (path[:, 1] - ego.y) ** 2)
    nearest_idx = int(np.argmin(d))

    # ===== 连续弧长 / 横向偏差（必须先算：arc 与 committed 要在这里做选择）=====
    # 旧式 `arc` 是"最近**路点下标**之间的整段长度之和"：`int(np.argmin(d))` 只取顶点，
    # 不用自车在线段内的位置 ⇒ **量化步长 = 路点间距**。参考路径按
    # `dense_polyline2d(..., 2)` 加密 ⇒ 实测 `arc_to_cross` 只取 4 个值
    # `6.135 / 8.179 / 10.221 / 12.262`（间隔 **2.045 m**）。后果（实测）：
    #   · 等待点 `hold_arc = 12.2 m ≈ 10.22 + 2 m 几何余量` —— "加 2 m"落在**同一个
    #     量化步长之内**，名义余量 2 m、实际分辨力 2.045 m，余量被量化误差吃掉。
    #     实测碰撞 `arc_to_cross` 中位正是 **12.262**（车就停在配置的等待点上被撞）。
    #   · 停止线 `_stop_arc=5.0`、进入区 `15.0`、`hold_arc` 全部只有 ~2 m 粒度。
    # 本块把"自车投到线段上插值"的连续量先算出来，供下面按开关选择。
    arc_cont = 0.0
    lat_dev = 0.0
    s_ego_cont = 0.0
    s_cross_cont = 0.0
    _proj_ego = {}
    # 【0''-a】参考路径来源/指纹（只观测）
    try:
        _pfp = ref_path_fingerprint(dynamic_map)
    except Exception:
        _pfp = {}
    try:
        _cumlen = polyline_cumlen(path)
        _proj_ego = project_point_on_polyline(path, ego.x, ego.y, cumlen=_cumlen)
        if _cp_mode.startswith('legacy'):
            # 旧口径：冲突点 = 最近的**路点**（量化到 2 m 网格）
            _proj_cross = project_point_on_polyline(path, path[cross_idx][0], path[cross_idx][1],
                                                    cumlen=_cumlen)
            s_cross_cont = float(_proj_cross['s'])
        else:
            # 【BUG-1 修复】冲突点 = 首次穿越点，弧长在检测时就已插值算出
            #   ⇒ 不再经过"最近路点"，没有 2.045 m 量化误差
            s_cross_cont = float(s_cross_cross)
        s_ego_cont = float(_proj_ego['s'])
        arc_cont = float(abs(s_cross_cont - s_ego_cont))   # 连续弧长（恒正）
        lat_dev = float(_proj_ego['lat'])                  # 自车到参考路径的垂距
    except Exception:
        pass

    # 旧式（量化）弧长：保留原算法作为可回退路径
    lo, hi = min(nearest_idx, cross_idx), max(nearest_idx, cross_idx)
    arc_q = 0.0
    for i in range(lo + 1, hi + 1):
        arc_q += math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])

    # 已越过冲突点（沿路径越过 >1m 即视为清空冲突区，此后不再评估冲突）
    signed_arc_q = 0.0
    if nearest_idx >= cross_idx:
        for i in range(cross_idx, nearest_idx):
            signed_arc_q += math.hypot(path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
    else:
        for i in range(cross_idx, nearest_idx, -1):
            signed_arc_q -= math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])

    # 【S7-①】决策用弧长是否走连续值。默认 0 = 保持历史行为（量化），便于干净 A/B。
    #   项目里所有"余量 / 停止线 / 进入区"判据都建在 arc 上；只有 arc 连续，
    #   那些余量才是真的（否则任何"加 2 m 余量"都可能被 2.045 m 的量化吃掉）。
    _use_cont = os.environ.get('DSH_ARC_CONT', '1') == '1'   # 【3.1】默认打开连续弧长 and arc_cont > 0.0
    arc = float(arc_cont) if _use_cont else float(arc_q)
    t_ego = arc / max(ego.v, 0.1)
    signed_arc = float(s_ego_cont - s_cross_cont) if _use_cont else float(signed_arc_q)
    committed = signed_arc > 1.0

    dist_to_cross = math.hypot(ego.x - path[cross_idx][0], ego.y - path[cross_idx][1])

    # ===== 【Phase 1 ④】间隙前/后车识别 + 二维边界度量（纯函数，离线可对拍）=====
    # 委托 Planning_library.gap_analysis（与旧循环语义一致：y 窗口 ±8m、仅统计
    # 接近冲突点的车辆、t_veh = |x-cross_x|/v）：
    #   rv = ego 切入其前方（t_veh >= t_ego）的最近车；fv = ego 之前通过的最近车；
    #   对两者分别计算 TTC_boundary / THW_boundary / LCTTC（车身矩形边界模型）。
    from Planning_library.gap_analysis import (identify_gap_vehicles, compute_gap_metrics,
                                               fv_rv_spatial_gap)
    from Planning_library.scenario_snapshot import VehicleState, ScenarioSnapshot

    def _to_state(v):
        acc = longitudinal_acceleration(v)
        actor = vehicle_id(v)
        return VehicleState(
            x=float(v.x), y=float(v.y), yaw=float(getattr(v, 'yaw', 0.0)),
            v=float(getattr(v, 'v', 0.0)), vx=float(getattr(v, 'vx', 0.0)),
            vy=float(getattr(v, 'vy', 0.0)),
            length=vehicle_size(v, 'length', 4.0),
            width=vehicle_size(v, 'width', 2.0),
            veh_id=actor if actor is not None else -1,
            ax=getattr(v, 'ax', None), ay=getattr(v, 'ay', None), acc=acc,
            acc_source=(getattr(v, 'acc_source', 'observed_projection')
                        if acc is not None else 'unavailable'))

    veh_states = []
    if hasattr(dynamic_map, 'objects'):
        for veh in dynamic_map.objects:
            if not hasattr(veh, 'x') or not hasattr(veh, 'v'):
                continue
            veh_states.append(_to_state(veh))

    # 【P2-a】角色划分用的"计划到达时间"：用**计划车速**而非瞬时车速。
    #   否则自车一减速 t_ego→∞，`t_veh >= t_ego` 对所有车成立 → rv 角色为空
    #   → 博弈静默消失 + THW=inf 被奖励当成满分（P1-f 劫持）。详见 gap_analysis 注释。
    #   计划车速 = max(自车当前速度, DSH_T_EGO_V_MIN)：蠕动/让行时不改变"谁是对手"，
    #   但正在正常行驶时仍如实反映到达时间。
    _v_plan = max(float(getattr(ego, 'v', 0.0)), float(T_EGO_V_MIN))
    t_ego_plan = arc / max(_v_plan, 0.1)

    snap = ScenarioSnapshot(
        ego=_to_state(ego),
        vehicles=veh_states,
        conflict_xy=(cross_x, cross_y),
        arc_to_cross=arc, t_ego=t_ego, committed=committed,
        t_ego_plan=t_ego_plan, game_window=GAME_WINDOW_M)
    ids = identify_gap_vehicles(snap)
    met = compute_gap_metrics(snap)

    gap = abs(t_ego - ids['t_veh_min']) if ids['t_veh_min'] < float('inf') else 30.0
    # 【论文式62 口径】g_d = FV–RV 空间净间隙（米）。注意与上面的 `gap` 区分：
    #   gap       = |t_ego − t_veh_min|（秒，时间差代理；保留供旧路径/状态编码使用）
    #   gap_spatial = RV 与 FV 之间的米制净间隙，才是论文式62/63 的 g_d 与式61 的口径
    gap_spatial = fv_rv_spatial_gap(ids, veh_len_default=4.0)
    # 【P2-b】博弈是否进行中（不含"自车当前速度"项，不可被减速套利）
    game_active = bool(ids.get('game_active', False))

    # 【② 打通①②③ 预备】显式博弈状态 game_state：ego + rv/fv 的观测状态 + 博弈量。
    # 供①博弈判断、②EFE(风险/模糊项)、③WCV/BCV(对手类型推断) 共用。
    def _st(veh):
        if veh is None:
            return None
        return {'x': float(veh.x), 'y': float(veh.y), 'v': float(veh.v),
                'yaw': float(getattr(veh, 'yaw', 0.0)),
                # 【论文式9】状态 s_i=[x,y,v,acc,φ,β]：补上加速度 acc
                'acc': veh.acc, 'acc_source': veh.acc_source, 'veh_id': veh.veh_id}
    _rv_veh = ids['rv']
    _rv_x = float(_rv_veh.x) if _rv_veh is not None else None
    _rv_dist = abs(_rv_x - cross_x) if _rv_x is not None else None
    game_state = {
        'ego': {'x': float(ego.x), 'y': float(ego.y), 'v': float(ego.v),
                'yaw': float(getattr(ego, 'yaw', 0.0))},
        'rv': _st(_rv_veh), 'fv': _st(ids['fv']),
        'arc_to_cross': float(arc), 't_ego': float(t_ego),
        't_ego_plan': float(t_ego_plan),
        'rv_dist_to_conflict': _rv_dist,
        # 【P2-b】博弈进行中（显式判定；不含自车速度项，不可被减速套利）
        'game_active': bool(game_active),
        'thw_rv': met['thw_boundary_rv'], 'thw_fv': met['thw_boundary_fv'],
        'lcttc_rv': met['lcttc_rv'], 'lcttc_fv': met['lcttc_fv'],
        'gap': gap, 'committed': bool(committed),
        'conflict': (float(cross_x), float(cross_y)),
        # 【论文式9】状态含隐藏类型 β：此处填 ego 对对手类型的**推断值**（非真实值，避免泄露）
        'beta': beta,
    }

    # Eq.61 inputs have different contracts: observed current acceleration and
    # an explicitly declared IDM prediction from visible traffic geometry.
    # Never read cross_traffic._rv_state or a simulator yield/rush label.
    _rv_obj = ids.get('rv')
    _rv_acc = _rv_obj.acc if _rv_obj is not None else None
    _rv_acc_follow = following_acceleration(
        _rv_obj, veh_states, v0=float(os.environ.get('DSH_TRAFFIC_V', '6.0')))

    return {'gap': gap, 'dist_to_cross': dist_to_cross, 't_ego': t_ego,
            # 【P2-a/b】计划到达时间与显式博弈进行中标志
            't_ego_plan': t_ego_plan, 'game_active': game_active,
            't_veh': ids['t_veh_min'], 'arc_to_cross': arc, 'committed': committed,
            # 【P0-step0】连续弧长 / 横向偏差 / 连续坐标（仅观测，暂无消费者）
            'arc_cont': arc_cont, 'lat_dev': lat_dev,
            's_ego_cont': s_ego_cont, 's_cross_cont': s_cross_cont,
            # 【0''-a 诊断】本帧几何实际用的参考路径来源与指纹
            'path_src': _pfp.get('src'), 'path_n': _pfp.get('n'),
            'path_fp': _pfp.get('fp'),
            'proj_x': _proj_ego.get('proj', (None, None))[0] if isinstance(_proj_ego, dict) else None,
            'proj_y': _proj_ego.get('proj', (None, None))[1] if isinstance(_proj_ego, dict) else None,
            't_ego_cont': (arc_cont / max(ego.v, 0.1)) if arc_cont else 0.0,
            'n_vehicles': ids['n_vehicles'],
            't_veh_sorted': ids['t_veh_sorted'],
            # 【论文式62/63】g_d = FV–RV 空间净间隙（米）；None = 博弈不在进行中
            'gap_spatial': gap_spatial,
            'conflict_x': cross_x, 'conflict_y': cross_y,
            'ttc_boundary': met['lcttc_rv'], 'thw_boundary': met['thw_boundary_rv'],
            'lcttc': met['lcttc_rv'],
            'lcttc_rv': met['lcttc_rv'], 'lcttc_fv': met['lcttc_fv'],
            'thw_boundary_rv': met['thw_boundary_rv'], 'thw_boundary_fv': met['thw_boundary_fv'],
            'rv_t_veh': ids['rv_t_veh'], 'fv_t_veh': ids['fv_t_veh'],
            # 【① Cournot 接线】间隙后车/前车的车辆状态（VehicleState 或 None），
            # 供让行判定块取 RV 实际位置/速度构建博弈输入（距离、让行概率）。
            'rv_veh': ids['rv'], 'fv_veh': ids['fv'],
            # Measured and predicted inputs stay distinguishable in logs.
            'rv_acc': _rv_acc, 'rv_acc_follow': _rv_acc_follow,
            'rv_actor_id': vehicle_id(_rv_obj),
            'rv_acc_source': _rv_obj.acc_source if _rv_obj is not None else 'unavailable',
            'rv_acc_follow_source': ('idm_from_observation'
                                     if _rv_acc_follow is not None else 'unavailable'),
            # 【式9】隐藏类型 β 的 ego 推断值（None=未推断）
            'beta': beta,
            # 【② 显式博弈状态】ego + rv/fv 观测状态 + 博弈量（供①/②/③共用）
            'game_state': game_state}



def _get_ref_path_array(dynamic_map):
    """从多种来源获取参考路径点数组 (Nx2 numpy array)
    优先级: env.ref_path_array > dynamic_map.lanes[0].central_path_array > dynamic_map.ref_path.central_path_array
    """
    # 来源1: 环境对象上的 dense polyline ref_path_array
    env = getattr(dynamic_map, 'env', None)
    if env is not None:
        arr = getattr(env, 'ref_path_array', None)
        if arr is not None and hasattr(arr, '__len__') and len(arr) > 2:
            return np.asarray(arr, dtype=float)
    # 来源2: 动态地图的车道中心线
    if hasattr(dynamic_map, 'lanes') and len(dynamic_map.lanes) > 0:
        arr = getattr(dynamic_map.lanes[0], 'central_path_array', None)
        if arr is not None and hasattr(arr, '__len__') and len(arr) > 2:
            return np.asarray(arr, dtype=float)
    # 来源3: dynamic_map 上的 ref_path 对象
    rp = getattr(dynamic_map, 'ref_path', None)
    if rp is not None:
        arr = getattr(rp, 'central_path_array', None)
        if arr is not None and hasattr(arr, '__len__') and len(arr) > 2:
            return np.asarray(arr, dtype=float)
    return None


def ref_path_fingerprint(dynamic_map):
    """【0''-a 诊断】返回"本帧几何实际用的参考路径"的来源 + 指纹。

    动机：实测同一自车位置 (5.78, -103.36) 在不同回合的**首帧**报出不同的
    `lat_dev`（3.558 vs 1.538）与 `arc`（6.13 vs 10.22）。而 `lat_dev` 只依赖
    (path, ego.x, ego.y) ⇒ **这两回合首帧用的不是同一条路径**。
    本函数把"用了哪个来源、路径长什么样"暴露出来，用于定位是哪个来源在首帧不稳。

    返回 dict: src(1/2/3/0), n, x0,y0, xn,yn（首尾点）, fp（首中尾三点指纹字符串）
    """
    out = {'src': 0, 'n': 0}
    try:
        env = getattr(dynamic_map, 'env', None)
        arr = None
        if env is not None:
            cand = getattr(env, 'ref_path_array', None)
            if cand is not None and hasattr(cand, '__len__') and len(cand) > 2:
                arr, out['src'] = np.asarray(cand, dtype=float), 1
        if arr is None and hasattr(dynamic_map, 'lanes') and len(dynamic_map.lanes) > 0:
            cand = getattr(dynamic_map.lanes[0], 'central_path_array', None)
            if cand is not None and hasattr(cand, '__len__') and len(cand) > 2:
                arr, out['src'] = np.asarray(cand, dtype=float), 2
        if arr is None:
            rp = getattr(dynamic_map, 'ref_path', None)
            cand = getattr(rp, 'central_path_array', None) if rp is not None else None
            if cand is not None and hasattr(cand, '__len__') and len(cand) > 2:
                arr, out['src'] = np.asarray(cand, dtype=float), 3
        if arr is None:
            return out
        out['n'] = int(len(arr))
        out['x0'], out['y0'] = float(arr[0][0]), float(arr[0][1])
        out['xn'], out['yn'] = float(arr[-1][0]), float(arr[-1][1])
        m = len(arr) // 2
        out['fp'] = (f'{out["n"]}|{out["x0"]:.2f},{out["y0"]:.2f}'
                     f'|{arr[m][0]:.2f},{arr[m][1]:.2f}|{out["xn"]:.2f},{out["yn"]:.2f}')
    except Exception:
        pass
    return out




def _ang_diff(a, b):
    d = a - b
    while d > math.pi: d -= 2*math.pi
    while d < -math.pi: d += 2*math.pi
    return d


def _nang(a):
    while a > math.pi: a -= 2*math.pi
    while a < -math.pi: a += 2*math.pi
    return a


def _path_length(path):
    total = 0.0
    for i in range(1, len(path)):
        total += math.sqrt((path[i][0]-path[i-1][0])**2 + (path[i][1]-path[i-1][1])**2)
    return total


def _lookahead_path_points(dynamic_map):
    path = _get_ref_path_array(dynamic_map)
    if path is None:
        return None
    ego = dynamic_map.ego_vehicle
    ego_x, ego_y = ego.x, ego.y
    d = np.sqrt((path[:,0]-ego_x)**2 + (path[:,1]-ego_y)**2)
    idx = int(np.argmin(d))
    return path[idx:idx+40] if idx+40 <= len(path) else path[idx:]


def _get_curvature(dynamic_map):
    """
    获取前方道路曲率
    优先级: waypoint > 路径几何 > yaw变化率
    """
    ego_vehicle = dynamic_map.ego_vehicle
    
    # 方法1: 尝试从动态地图获取曲率
    if hasattr(dynamic_map, 'get_current_curvature'):
        return abs(dynamic_map.get_current_curvature())
    
    # 方法2: 从参考路径点计算曲率（ref_path_array / central_path_array）
    path = _get_ref_path_array(dynamic_map)
    if path is not None and len(path) > 10:
        try:
            # 找到离自车最近的点
            ego_x, ego_y = ego_vehicle.x, ego_vehicle.y
            distances = np.sqrt((path[:, 0] - ego_x)**2 + (path[:, 1] - ego_y)**2)
            nearest_idx = np.argmin(distances)
            # 在最近点的前后取点计算曲率
            idx1 = max(0, nearest_idx - 5)
            idx2 = nearest_idx
            idx3 = min(len(path) - 1, nearest_idx + 5)
            if idx3 - idx1 > 3:
                curv = _calc_curvature_3pt(
                    path[idx1][0], path[idx1][1],
                    path[idx2][0], path[idx2][1],
                    path[idx3][0], path[idx3][1]
                )
                return abs(curv)
        except Exception:
            pass

    # 方法3: fallback - 用距交叉口距离 + 参考路径航向变化估算转弯
    # 即使在弯道中，用路径首尾航向差粗略估计，避免曲率恒为 0
    try:
        nxt = _lookahead_path_points(dynamic_map)
        if nxt is not None and len(nxt) > 10:
            a1 = math.atan2(nxt[5][1] - nxt[0][1], nxt[5][0] - nxt[0][0])
            a2 = math.atan2(nxt[-1][1] - nxt[-5][1], nxt[-1][0] - nxt[-5][0])
            dtheta = abs(_nang(a2 - a1))
            dlen = _path_length(nxt)
            if dlen > 0.5:
                curv = dtheta / max(dlen, 0.1)
                return min(curv, 0.2)
    except Exception:
        pass

    return 0.0


def _calc_curvature_3pt(x1, y1, x2, y2, x3, y3):
    """三点法计算曲率"""
    a = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    b = math.sqrt((x3 - x2)**2 + (y3 - y2)**2)
    c = math.sqrt((x3 - x1)**2 + (y3 - y1)**2)
    if a * b * c < 1e-10:
        return 0.0
    s = (a + b + c) / 2.0
    area = math.sqrt(max(0, s * (s-a) * (s-b) * (s-c)))
    if area < 1e-10:
        return 0.0
    radius = (a * b * c) / (4.0 * area)
    return 1.0 / radius


def _get_lateral_error(dynamic_map):
    """获取自车到当前车道中心的横向偏差"""
    ego_vehicle = dynamic_map.ego_vehicle
    
    # 方法1: 如果 dynamic_map 有 Frenet l 值
    if hasattr(ego_vehicle, 'l'):
        return ego_vehicle.l
    
    # 方法2: 从参考路径计算横向偏差
    path = _get_ref_path_array(dynamic_map)
    if path is not None and len(path) > 0:
        ego_x, ego_y = ego_vehicle.x, ego_vehicle.y
        distances = np.sqrt((path[:, 0] - ego_x)**2 + (path[:, 1] - ego_y)**2)
        nearest_idx = np.argmin(distances)
        nearest_x, nearest_y = path[nearest_idx][0], path[nearest_idx][1]
        
        # 计算横向偏差（垂直距离）
        dx = ego_x - nearest_x
        dy = ego_y - nearest_y
        
        # 获取路径点切线方向
        if nearest_idx < len(path) - 1:
            tx = path[nearest_idx + 1][0] - nearest_x
            ty = path[nearest_idx + 1][1] - nearest_y
        else:
            tx = nearest_x - path[nearest_idx - 1][0]
            ty = nearest_y - path[nearest_idx - 1][1]
        norm = math.sqrt(tx**2 + ty**2)
        if norm > 0:
            tx, ty = tx / norm, ty / norm
        
        # 法向量（逆时针旋转90°）
        nx, ny = -ty, tx
        lat_error = dx * nx + dy * ny
        
        return round(lat_error, 4)
    
    return 0.0


def _get_safe_turn_speed(curvature):
    """
    计算安全过弯速度
    基于简化的摩擦圆模型: v_max = sqrt(μ * g * R)
    μ = 0.7 (干燥沥青路面的摩擦系数)
    g = 9.8 m/s²
    最大不超过 60 km/h (16.67 m/s)
    """
    if abs(curvature) < 1e-6:
        return 16.67  # 直道限速 60 km/h
    
    radius = 1.0 / abs(curvature)
    mu = 0.7
    g = 9.8
    safe_speed = math.sqrt(mu * g * radius)
    # 限速 60 km/h = 16.67 m/s，最低 1 m/s
    return np.clip(safe_speed, 1.0, 16.67)


def conflict_detection(dynamic_map):
    """
    功能: 识别交叉口冲突车辆
    替代原版的 gap_recognition()
    
    输入:
        dynamic_map: 动态地图对象
    
    输出:
        conflict_ids: 冲突车辆 ID 列表
        min_ttc: 最小碰撞时间 (s)
    """
    ego_vehicle = dynamic_map.ego_vehicle
    ego_x, ego_y = ego_vehicle.x, ego_vehicle.y
    ego_v = max(ego_vehicle.v, 0.1)
    ego_yaw = ego_vehicle.yaw
    
    conflict_ids = []
    min_ttc = float('inf')
    
    # 遍历所有环境车辆
    if hasattr(dynamic_map, 'objects'):
        for vehicle in dynamic_map.objects:
            # 计算两车的相对位置和速度
            dx = vehicle.x - ego_x
            dy = vehicle.y - ego_y
            dist = math.sqrt(dx**2 + dy**2)
            
            if dist > 50 or dist < 0.5:  # 忽略太远或太近的车
                continue
            
            # 计算相对速度的径向分量
            if vehicle.v > 0.1:
                relative_speed = _radial_relative_speed(ego_x, ego_y, ego_v, ego_yaw,
                                                       vehicle.x, vehicle.y, vehicle.v, vehicle.yaw)
                if dist > 0 and relative_speed > 0.1:
                    ttc = dist / relative_speed
                    if ttc < min_ttc:
                        min_ttc = ttc
                    if ttc < 3.0:  # TTC < 3s 视为冲突
                        if hasattr(vehicle, 'carla_id'):
                            conflict_ids.append(vehicle.carla_id)
    
    return conflict_ids, min_ttc


def _radial_relative_speed(x1, y1, v1, yaw1, x2, y2, v2, yaw2):
    """计算两车沿连线方向的相对接近速度"""
    dx = x2 - x1
    dy = y2 - y1
    dist = max(math.sqrt(dx**2 + dy**2), 0.01)
    nx, ny = dx / dist, dy / dist  # 从车1指向车2的单位向量
    
    vx1 = v1 * math.cos(yaw1)
    vy1 = v1 * math.sin(yaw1)
    vx2 = v2 * math.cos(yaw2)
    vy2 = v2 * math.sin(yaw2)
    
    # 相对速度在连线上的投影
    rel_v = (vx2 - vx1) * nx + (vy2 - vy1) * ny
    return max(0, rel_v)  # 只关心接近的情况
