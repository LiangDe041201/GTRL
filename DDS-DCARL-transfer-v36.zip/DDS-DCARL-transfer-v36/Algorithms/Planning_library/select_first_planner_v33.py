"""Joint choices are ranked before a single native MPC solve and full audit."""
import time

from Planning_library.control_path_v15 import path_hash
from Planning_library.joint_planner_v32 import JointLearnerV32, JointPlannerV32
from Planning_library.rolling_trajectory_v24 import path_cost


class SelectFirstLearnerV33(JointLearnerV32):
    SCHEMA = 'cg_joint_select_first_v33'


class SelectFirstPlannerV33(JointPlannerV32):
    EXTRA_CONTROLLERS = 1
    LEARNER_CLASS = SelectFirstLearnerV33
    LEARNER_METADATA = dict(JointPlannerV32.LEARNER_METADATA,
                            learner_revision=SelectFirstLearnerV33.SCHEMA,
                            selection_screen='road_geometry_and_target_v33')

    def _controller_for_action(self,action):
        return self.controllers[0]

    def _screen_intent(self,speed,action):
        return 'proceed' if self.intent==1 or speed is not None else 'defer'

    def _solve(self,action,dynamic,seed,target,cg,road_right,center):
        """Supply geometry/target screening evidence for the learner's action mask."""
        path = self.profiles[action]['path']
        identity = id(path)
        if identity not in self._screen_paths:
            self._screen_paths[identity] = path_hash(path), path_cost(path)
        digest,cost = self._screen_paths[identity]
        offset,speed = self.LEARNER_CLASS.ACTION_PAIRS[action]
        screened = dict(action=action,id=self.LEARNER_CLASS.ACTION_NAMES[action],
            target=target,path_hash=digest,cost=cost,eligible=True,screened=True,
            lateral_offset_m=offset,speed_option_mps=speed,
            intent=self._screen_intent(speed,action))
        return dict(path=path,target=target),screened,0.

    def propose(self,dynamic,candidates,baseline,cg_record,seed,road_right,center):
        started = time.perf_counter()
        self._screen_paths = {}
        result = super().propose(dynamic,candidates,baseline,cg_record,seed,road_right,center)
        requested = self.last['requested_action']
        self.last.update(extra_solve_count=0,verified_candidate=None,exact_audit_rejected=False,
                         reused_cg_index=None)
        if requested:
            target = result[baseline]['target']
            offset = self.LEARNER_CLASS.ACTION_PAIRS[requested][0]
            proceed = candidates[1]
            if (baseline==0 and offset is None and proceed.get('solve_ok')
                    and target==float(proceed['target'])):
                candidate = dict(proceed,path=proceed['controller'].last_pathway)
                proof = self._audit_candidate(candidate,requested,dynamic,seed,cg_record)
                self.last['reused_cg_index'] = 1
            else:
                candidate,proof,solve_ms = super()._solve(requested,dynamic,seed,target,cg_record,road_right,center)
                self.last.update(extra_solve_count=1,extra_solve_ms=solve_ms)
            self.last['verified_candidate'] = proof
            if proof['eligible']:
                result[baseline] = candidate
                self.last.update(request=dict(proof),request_id=proof['id'])
            else:
                original = self.last['candidates'][0]
                result[baseline] = self._base
                self.action = 0
                self.last.update(actual_action=0,changed_request=False,retracted=True,
                    request=dict(original),request_id=original['id'],disable_foreign_clear_backup=False,
                    exact_audit_rejected=True)
        self.last['decision_ms'] = (time.perf_counter()-started)*1000.
        return result
