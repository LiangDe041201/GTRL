#!/usr/bin/env python3
"""
对手（RV）隐藏类型推断 —— 对齐论文 ADVEI-D-26-08155：
  §III-A 式17：对手带**私有类型** θ ∈ Θ（类型空间，common knowledge）
  §IV-C   ："…frequentist statistical iteration is used to replace explicit
             Bayesian filtering updates"（用**频率统计**替代显式贝叶斯滤波）
  §V-B/C  ：式57 `r_behavior`（ambiguity）= **推断对手隐藏状态的不确定性**

本模块给出：
  1) 类型空间 RV_THETA（aggressive/normal/conservative，来自 rv_decision）
  2) 观测更新：ego 只能观测对手**运动**（是否减速让行），据此递推类型后验
     （论文说用频率统计；此处用其递推（贝叶斯）形式实现，等价且可在线）
  3) θ 的**频率反解**：由观测到的让行频率 p̂，用 `rv_yield_probability` 模型反解 θ
  4) ambiguity：类型后验的熵 H(τ)（式55 的 Shannon 熵口径，式18 用 log2）

纯函数 + 一个轻量有状态类，无 CARLA 依赖，可离线单测。
"""
import math

from Planning_library.rv_decision import RV_THETA, rv_yield_probability


# ============================================================
# 纯函数
# ============================================================
def uniform_prior(types=None):
    """类型均匀先验 P(τ)。"""
    types = types or RV_THETA
    n = max(len(types), 1)
    return {k: 1.0 / n for k in types}


def posterior_update(prior, yield_prob_by_type, observed_yield):
    """一次观测后的类型后验（频率统计的递推形式）：

        P(τ | o) ∝ P(τ) · P(o | τ)，其中 P(yield|τ)=yield_prob_by_type[τ]，
        P(rush|τ)=1−P(yield|τ)。观测到"让行"则 observed_yield=True。

    返回归一化后的后验 dict（若全为 0 则退回先验）。
    """
    post = {}
    for k, pr in prior.items():
        p_y = float(yield_prob_by_type.get(k, 0.5))
        p_y = min(1.0 - 1e-9, max(1e-9, p_y))
        like = p_y if observed_yield else (1.0 - p_y)
        post[k] = float(pr) * like
    s = sum(post.values())
    if s <= 0.0:
        return dict(prior)
    return {k: v / s for k, v in post.items()}


def posterior_entropy(post):
    """类型后验的 Shannon 熵（式55/式18 口径，log2），单位 bit。"""
    h = 0.0
    for v in post.values():
        if v > 0.0:
            h -= v * (math.log(v) / math.log(2.0))
    return h


def posterior_mean_theta(post, types=None):
    """类型后验均值 → θ 的点估计。"""
    types = types or RV_THETA
    return float(sum(float(post.get(k, 0.0)) * float(types[k]) for k in types))


def invert_theta_from_frequency(p_hat, ego_state, rv_state, conflict_x,
                                ttc_boundary=None, types=None,
                                lo=0.0, hi=1.0, iters=40):
    """【θ 频率反解】已知观测到的让行频率 p̂，反解出 θ。

    `rv_yield_probability(..., theta)` 对 θ 单调递减（θ 大=激进 → 让行概率低），
    故用二分法求 θ 使模型输出 ≈ p̂。返回 (theta, residual)。
    """
    types = types or RV_THETA

    def model_p(th):
        return rv_yield_probability(ego_state, rv_state, conflict_x, ttc_boundary, theta=th)

    a, b = float(lo), float(hi)
    pa, pb = model_p(a), model_p(b)
    for _ in range(int(iters)):
        m = 0.5 * (a + b)
        pm = model_p(m)
        # 单调递减：p 随 θ 增大而减小
        if pm > p_hat:
            a = m
        else:
            b = m
    th = 0.5 * (a + b)
    return th, abs(model_p(th) - p_hat)


# ============================================================
# 有状态推断器（在线）
# ============================================================
class TypeInference:
    """在线类型推断器（跨回合持续，因为类型是对手的固有属性）。"""

    def __init__(self, types=None):
        self.types = dict(types or RV_THETA)
        self.posterior = uniform_prior(self.types)
        self.n_obs = 0
        self.n_yield = 0

    def observe(self, ego_state, rv_state, conflict_x, observed_yield,
                ttc_boundary=None, acc_current=0.0, acc_follow=None):
        """观测一次对手行为（observed_yield: True=让行 / False=抢行）并更新后验。"""
        # 各类型在该态势下的让行概率（模型似然）
        yp = {}
        for k, th in self.types.items():
            yp[k] = rv_yield_probability(ego_state, rv_state, conflict_x, ttc_boundary,
                                         theta=th, acc_current=acc_current,
                                         acc_follow=acc_follow)
        self.posterior = posterior_update(self.posterior, yp, observed_yield)
        self.n_obs += 1
        if observed_yield:
            self.n_yield += 1

    def theta(self):
        """当前 θ 点估计（后验均值）。"""
        return posterior_mean_theta(self.posterior, self.types)

    def ambiguity(self):
        """当前类型不确定性（后验熵，bit）。"""
        return posterior_entropy(self.posterior)

    def empirical_yield_frequency(self):
        """观测到的让行频率 p̂（频率统计口径；无观测时返回 None）。"""
        return (self.n_yield / self.n_obs) if self.n_obs > 0 else None
