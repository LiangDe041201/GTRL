#!/usr/bin/env bash
# v30: 150 new 8 m continuous-flow training + 150 CG + 150 frozen CG/GTRL.
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUTF8=1
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
cd "$SCRIPT_DIR/Algorithms"
exec "$PYTHON_BIN" -u Tools/run_dense_validation_v30.py "$@"
