#!/usr/bin/env bash
# ============================================================
# 启动 CARLA 服务器（离屏渲染，纯训练用，看不到画面）
#
# 用途：规避两类崩溃：
#   1) 新内核/驱动的启动崩溃（Signal 11）-> setarch -R 关闭进程 ASLR
#   2) 长训练(~40回合)时 UE4 渲染内存累积导致的服务器崩溃
#      -> 服务器用 -RenderOffScreen 离屏渲染；训练端在连接时设
#         no_rendering_mode=True 真正关掉渲染线程（标准 RL 训练做法）。
#
# 注意：本版 CARLA 0.9.15 不支持 -nullrhi（实测启动即 Signal 11），
#       用 -RenderOffScreen 代替。
#
# 若 setarch -R 后仍崩溃，永久修复（需 root）：
#   sudo sysctl vm.mmap_rnd_bits=28
#   echo 'vm.mmap_rnd_bits=28' | sudo tee /etc/sysctl.d/99-ue4-fix.conf
#
# 用法：
#   bash start_headless_server.sh                 # 默认 ~/carla
#   bash start_headless_server.sh /path/to/carla  # 指定 CARLA 根目录
#   CARLA_ROOT=/path/to/carla bash start_headless_server.sh
#
# 碰撞传感器是物理层的，不受无渲染影响，训练可正常判定碰撞。
# ============================================================
set -e

CARLA_ROOT="${1:-${CARLA_ROOT:-$HOME/carla}}"

if [ ! -f "$CARLA_ROOT/CarlaUE4.sh" ]; then
    echo "[start_headless] 找不到 $CARLA_ROOT/CarlaUE4.sh，请传入正确的 CARLA 根目录" >&2
    exit 1
fi

echo "[start_headless] CARLA_ROOT = $CARLA_ROOT"
cd "$CARLA_ROOT"

# 离屏渲染（本版不支持 -nullrhi）；-quality-level=Low 降低负载
RUN_CMD="./CarlaUE4.sh -RenderOffScreen -quality-level=Low"

# 规避新内核上 UE4.26 的 ASLR 启动崩溃（setarch -R = 本进程关闭地址随机化）
if command -v setarch >/dev/null 2>&1; then
    echo "[start_headless] 启动命令: setarch $(uname -m) -R $RUN_CMD"
    exec setarch "$(uname -m)" -R $RUN_CMD
else
    echo "[start_headless] 未找到 setarch，直接启动: $RUN_CMD"
    exec $RUN_CMD
fi
